package com.anthem.wgs.payment.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.wgs.payment.exception.handler.MemberPayException;
import com.anthem.wgs.payment.request.DateRequest;
import com.anthem.wgs.payment.request.GetPaymentMethodRequest;
import com.anthem.wgs.payment.request.UpdatePaymentMethodRequest;
import com.anthem.wgs.payment.response.BaseResponse;
import com.anthem.wgs.payment.response.GetPaymentMethodResponse;
import com.anthem.wgs.payment.response.UpdatePaymentMethodResponse;
import com.anthem.wgs.payment.service.WGSPaymentService;
import com.anthem.wgs.payment.util.WGSPaymentConstants;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class WGSPaymentController implements WGSPaymentConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(WGSPaymentController.class);
	
	@Autowired
	private WGSPaymentService wgsPaymentService;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/getUpdatedDate", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "EST time correction", notes = "The api call is used to get updated date with EST time correction")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = DateRequest.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = MemberPayException.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = MemberPayException.class) })
	public ResponseEntity<BaseResponse> getUpdatedDate(@RequestBody @Valid DateRequest request, @RequestHeader HttpHeaders headers) throws MemberPayException  {
		
		
		DateRequest correctedDate = getCorrectedDate(request.getDateString());
		

		return new ResponseEntity(correctedDate, HttpStatus.OK);
	}
	
	public DateRequest getCorrectedDate(String requestDate) {
		DateRequest correctedDate = new DateRequest();
		correctedDate.setDateString(requestDate);
		System.out.println("requestDate : " + requestDate);
		
		String HOUR_FORMAT = "HH:mm";
		Calendar cal = Calendar.getInstance(Locale.US);
        SimpleDateFormat sdfHour = new SimpleDateFormat(HOUR_FORMAT);
        String now = sdfHour.format(cal.getTime());
        System.out.println("now : " + now);
	    String start = "00:00";
	    String end   = "03:00";
	    boolean isHourInTheInterval = ((now.compareTo(start) >= 0) && (now.compareTo(end) <= 0));
	    System.out.println("isHourInTheInterval : " + isHourInTheInterval);
	      
	    String MMDDYYYY = "MM/dd/yyyy";
	    SimpleDateFormat mmddyyyyFormat = new SimpleDateFormat(MMDDYYYY);
	    Date paymentDate = convertStringToDate(requestDate, "MM/dd/yyyy");
	    Date currentDate = convertStringToDate(mmddyyyyFormat.format(Calendar.getInstance(Locale.US).getTime()), "MM/dd/yyyy");
	    
	    System.out.println("paymentDate.compareTo(currentDate) : " + paymentDate.compareTo(currentDate));
	    long diff = currentDate.getTime() - paymentDate.getTime();
	    int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
		System.out.println("difference between days: " + diffDays);
		
	    if(paymentDate.compareTo(currentDate) < 0 && isHourInTheInterval && diffDays == 1) {
			correctedDate.setDateString(mmddyyyyFormat.format(Calendar.getInstance(Locale.US).getTime()));
	    }
	    
	    System.out.println("**************************************************************************");
		return correctedDate;
	}
	
	public static Date convertStringToDate(String strDate, String format)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
		formatter.setLenient(false);
		Date date = null;
		try
		{
			date = formatter.parse(strDate);
		} catch (ParseException e)
		{
			LOGGER.error("Parse Exception occured while converting string to date" + e);
		}
		return date;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/updatePaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Update Payment Method", notes = "The api call is used to update payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = MemberPayException.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = MemberPayException.class) })
	public ResponseEntity<BaseResponse> updatePaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws MemberPayException  {
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - start");
		
		UpdatePaymentMethodResponse updatePaymentMethodResponse = wgsPaymentService.updatePaymentMethod(updatePaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/getPaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Method", notes = "The api call is used to update payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = MemberPayException.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = MemberPayException.class) })
	public ResponseEntity<BaseResponse> getPaymentMethod(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws MemberPayException  {
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethod - start");
		
		GetPaymentMethodResponse getPaymentMethodResponse = wgsPaymentService.getPaymentMethods(getPaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethod - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}

}
