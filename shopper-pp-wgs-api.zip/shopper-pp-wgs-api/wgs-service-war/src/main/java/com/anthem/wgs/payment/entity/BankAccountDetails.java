package com.anthem.wgs.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class BankAccountDetails {

	@Field("bankAccountNumber")
	private String bankAccountNumber;
	@Field("bankAccountType")
	private String bankAccountType;
	@Field("institutionName")
	private String institutionName;
	@Field("routingNumber")
	private String routingNumber;

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}
	
}
