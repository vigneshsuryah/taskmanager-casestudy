package com.anthem.wgs.payment.bo;

import java.io.Serializable;

public class MemberPayPaymentMethod implements Serializable
{
	private static final long serialVersionUID = 6395871222978991940L;
	private String accNickName;
	private String accountStatus;
	private String routingNumber;
	private String accountName;
	private MemberPayPaymentTypeEnum paymentType;
	private String requestType;
	private MemberPayAddress billingAddress;
	private MemberPayAcctTypeEnum bankAccountType;  
	private String expiration;
	private String confirmAccountNo;
	private String tokenId;
	private String maskedAccountNumber;
	private String tokenStatus;
	private boolean recurringPaymentAssociated;
	private String hcid;

	public String getAccNickName()
	{
		return accNickName;
	}

	public void setAccNickName(String accNickName)
	{
		this.accNickName = accNickName;
	}

	public String getAccountStatus()
	{
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus)
	{
		this.accountStatus = accountStatus;
	}

	public String getRoutingNumber()
	{
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber)
	{
		this.routingNumber = routingNumber;
	}

	public String getAccountName()
	{
		return accountName;
	}

	public void setAccountName(String accountName)
	{
		this.accountName = accountName;
	}

	public MemberPayPaymentTypeEnum getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(MemberPayPaymentTypeEnum paymentType)
	{
		this.paymentType = paymentType;
	}

	public String getRequestType()
	{
		return requestType;
	}

	public void setRequestType(String requestType)
	{
		this.requestType = requestType;
	}

	public MemberPayAddress getBillingAddress()
	{
		return billingAddress;
	}

	public void setBillingAddress(MemberPayAddress billingAddress)
	{
		this.billingAddress = billingAddress;
	}

	public MemberPayAcctTypeEnum getBankAccountType()
	{
		return bankAccountType; 
	}

	public void setBankAccountType(MemberPayAcctTypeEnum bankAccountType)
	{
		this.bankAccountType = bankAccountType;
	}

	public String getExpiration()
	{
		return expiration;
	}

	public void setExpiration(String expiration)
	{
		this.expiration = expiration;
	}

	public String getConfirmAccountNo()
	{
		return confirmAccountNo;
	}

	public void setConfirmAccountNo(String confirmAccountNo)
	{
		this.confirmAccountNo = confirmAccountNo;
	}

	public String getTokenId()
	{
		return tokenId;
	}

	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	public String getMaskedAccountNumber()
	{
		return maskedAccountNumber;
	}

	public void setMaskedAccountNumber(String maskedAccountNumber)
	{
		this.maskedAccountNumber = maskedAccountNumber;
	}

	public String getTokenStatus()
	{
		return tokenStatus;
	}

	public void setTokenStatus(String tokenStatus)
	{
		this.tokenStatus = tokenStatus;
	}

	public void setRecurringPaymentAssociated(boolean recurringPaymentAssociated) {
		this.recurringPaymentAssociated = recurringPaymentAssociated;
	}

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public boolean isRecurringPaymentAssociated() {
		return recurringPaymentAssociated;
	}

}
