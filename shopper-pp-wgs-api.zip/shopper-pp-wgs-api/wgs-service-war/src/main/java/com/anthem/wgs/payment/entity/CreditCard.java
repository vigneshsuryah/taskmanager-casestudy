package com.anthem.wgs.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class CreditCard {

	@Field("credit_card_number")
	private String creditCardNumber;

	@Field("credit_card_type")
	private String creditCardType;
	
	@Field("expiration_month")
	private String expirationMonth;
	
	@Field("expiration_year")
	private String expirationYear;

	@Field("integrity_check")
	private String integrityCheck;
	
	@Field("key_id")
	private String keyID;
	
	@Field("phase_id")
	private String phaseID;
	
	@Field("credit_card_token_number")
	private String creditCardTokenNumber;

	public String getCreditCardTokenNumber() {
		return creditCardTokenNumber;
	}

	public void setCreditCardTokenNumber(String creditCardTokenNumber) {
		this.creditCardTokenNumber = creditCardTokenNumber;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public String getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}

	public String getIntegrityCheck() {
		return integrityCheck;
	}

	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}

	public String getKeyID() {
		return keyID;
	}

	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	public String getPhaseID() {
		return phaseID;
	}

	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}
	
}
