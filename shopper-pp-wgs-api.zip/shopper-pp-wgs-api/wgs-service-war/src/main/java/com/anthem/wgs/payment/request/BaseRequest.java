package com.anthem.wgs.payment.request;

import java.io.Serializable;

public class BaseRequest implements Serializable {

	private static final long serialVersionUID = -8259955797943904092L;
	
	private String hcid;
	
	private String requestingSystem;

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public String getRequestingSystem() {
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}

	


	
	
}
