package com.anthem.wgs.payment.service;

import com.anthem.wgs.payment.exception.handler.MemberPayException;
import com.anthem.wgs.payment.request.GetPaymentMethodRequest;
import com.anthem.wgs.payment.request.UpdatePaymentMethodRequest;
import com.anthem.wgs.payment.response.GetPaymentMethodResponse;
import com.anthem.wgs.payment.response.UpdatePaymentMethodResponse;

public interface WGSPaymentService {

    /*UpdatePaymentMethodResponse addOrUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action) throws WGSException;
    
    DeletePaymentMethodResponse deletePaymentMethod(DeletePaymentMethodRequest deletePaymentMethodRequest) throws WGSException;
    
    GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws WGSException;*/
	
	UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws MemberPayException;
	
	GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws MemberPayException;
	
}
