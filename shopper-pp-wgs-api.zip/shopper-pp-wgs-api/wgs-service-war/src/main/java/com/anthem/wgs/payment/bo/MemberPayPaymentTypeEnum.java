package com.anthem.wgs.payment.bo;


public enum MemberPayPaymentTypeEnum
{

	NONE,

	BANKINGACCOUNT,

	CREDITDEBITCARD;

}