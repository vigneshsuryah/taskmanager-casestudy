package com.anthem.wgs.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class CancelDetails {

	@Field("payment_channel")
	private String paymentChannel;
	@Field("cancelled_by")
	private String cancelledBy;
	
	public String getCancelledBy() {
		return cancelledBy;
	}
	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}
	public String getPaymentChannel() {
		return paymentChannel;
	}
	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

}
