package com.anthem.wgs.payment.response;

import java.io.Serializable;

import com.anthem.wgs.payment.bo.Message;
import com.anthem.wgs.payment.exception.handler.MemberPayException;

public class BaseResponse implements Serializable{

	private static final long serialVersionUID = 8482083239638202067L;
	
	private MemberPayException memberPayException;
	private Message message; 
	
	public MemberPayException getMemberPayException()
	{
		return memberPayException;
	}

	public void setMemberPayException(MemberPayException memberPayException)
	{
		this.memberPayException = memberPayException;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public Message getMessage() {
		return message;
	}
	
}
