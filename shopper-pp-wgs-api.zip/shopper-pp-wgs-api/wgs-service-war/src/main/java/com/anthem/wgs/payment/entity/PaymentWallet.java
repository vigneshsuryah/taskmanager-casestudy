package com.anthem.wgs.payment.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "payment_wallet_wgs")
public class PaymentWallet {

	@Field("hcid")
	private String hcid;

	@Field("tokens")
	private Token[] tokens;

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public Token[] getTokens() {
		return tokens;
	}

	public void setTokens(Token[] tokens) {
		this.tokens = tokens;
	}

}
