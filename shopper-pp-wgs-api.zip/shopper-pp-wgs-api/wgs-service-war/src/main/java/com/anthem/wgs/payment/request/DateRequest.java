package com.anthem.wgs.payment.request;

import java.io.Serializable;

public class DateRequest implements Serializable {

	private static final long serialVersionUID = -8259955797943904092L;
	
	private String dateString;

	public String getDateString() {
		return dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}

}
