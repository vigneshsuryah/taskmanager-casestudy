package com.anthem.wgs.payment.config;

import java.util.Properties;

import org.apache.commons.configuration.AbstractConfiguration;
import org.springframework.stereotype.Component;

import com.netflix.config.ConcurrentCompositeConfiguration;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicPropertyUpdater;
import com.netflix.config.DynamicStringProperty;
import com.netflix.config.FixedDelayPollingScheduler;
import com.netflix.config.PollResult;
import com.netflix.config.sources.URLConfigurationSource;

@Component
public class ApplicationProperties {

	public static final String DEFAULT_RESOURCE_LOCATION = "I:/wgs/wgs-service.properties";
	private ConcurrentCompositeConfiguration finalConfig = new ConcurrentCompositeConfiguration();
	private DynamicPropertyUpdater dynamicPropertyUpdater = new DynamicPropertyUpdater();

	private void initializeProperties() {
		try {
			URLConfigurationSource src = new URLConfigurationSource("file:"+DEFAULT_RESOURCE_LOCATION);
			DynamicConfiguration configuration = new DynamicConfiguration(src, new FixedDelayPollingScheduler(0, 5000, true));
			configuration.stopLoading();
			finalConfig.addConfiguration(configuration);
			ConfigurationManager.install(finalConfig);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ApplicationProperties() throws Exception {
		initializeProperties();
	}

	public String getStringProperty(String key, String defaultValue) {
		final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, defaultValue);
		return property.get();
	}

	public void updateProperty(String key, String value) {
		finalConfig.setOverrideProperty(key, value);
	}

	public Properties listAll() {
		return finalConfig.getProperties();
	}
	
	public void updatePropertiesFile() {
		try {
			for (AbstractConfiguration config : finalConfig.getConfigurations()) {
				if (config instanceof DynamicConfiguration) {
					PollResult result = ((DynamicConfiguration) config).getSource().poll(false, null);
					dynamicPropertyUpdater.updateProperties(result, config, false);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
