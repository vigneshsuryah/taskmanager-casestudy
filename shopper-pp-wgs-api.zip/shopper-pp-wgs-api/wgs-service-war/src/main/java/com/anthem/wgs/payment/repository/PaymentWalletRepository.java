package com.anthem.wgs.payment.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.wgs.payment.entity.PaymentWallet;

@Repository
public interface PaymentWalletRepository extends MongoRepository<PaymentWallet, String>{

	/*@Query(value = "{ 'acid' : ?0}")
	List<PaymentWallet> getPaymentWalletByAcid(String acid);
	
	@Query(value = "{ 'acid' : ?0, 'tokens.status' : ?1, 'tokens.tokenId' : ?2}")
	List<PaymentWallet> getPaymentWalletForTokenID(String acid, String status, String tokenId);
	
	@Query(value = "{ 'acid' : ?0,  'tokens.tokenId' : ?1}")
	PaymentWallet getPaymentWalletWithTokenID(String acid, String tokenId);*/
	@Query(value = "{ 'hcid' : ?0}")
	List<PaymentWallet> getPaymentWalletByHcid(String hcid);
	
	@Query(value = "{ 'hcid' : ?0, 'tokens.status' : ?1}")
	List<PaymentWallet> getPaymentWalletWithStatus(String hcid, String status);
	
	@Query(value = "{ 'hcid' : ?0,  'tokens.tokenId' : ?1}")
	PaymentWallet getPaymentWalletWithTokenID(String hcid, String tokenId);
	
}
