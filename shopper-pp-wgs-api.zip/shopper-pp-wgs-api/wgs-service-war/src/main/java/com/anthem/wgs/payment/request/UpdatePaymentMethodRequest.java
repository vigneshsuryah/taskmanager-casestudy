package com.anthem.wgs.payment.request;

import com.anthem.wgs.payment.bo.MemberPayPaymentMethod;

public class UpdatePaymentMethodRequest extends BaseRequest {

	private static final long serialVersionUID = -439968373091805120L;
	
	private String summaryNumber;

	private String action;

	private MemberPayPaymentMethod paymentMethod;

	public String getSummaryNumber()
	{
		return summaryNumber;
	}

	public void setSummaryNumber(String summaryNumber)
	{
		if(summaryNumber != null)
		{
			this.summaryNumber = summaryNumber.toUpperCase();
		}else{
			this.summaryNumber = summaryNumber;
		}
	}

	public MemberPayPaymentMethod getPaymentMethod()
	{
		return paymentMethod;
	}

	public void setPaymentMethod(MemberPayPaymentMethod paymentMethod)
	{
		this.paymentMethod = paymentMethod;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public String getAction()
	{
		return action;
	}

}
