package com.anthem.wgs.payment.util;

public interface WGSPaymentConstants {

	String HEADER_ACCEPT = "Accept=*/*";
	String APPLICATION_TYPE_JSON = "application/json";
	String APP_PRODUCE_TYPE_1 = "application/json; charset=UTF-8";
	String APP_PRODUCE_TYPE_2 = "text/html;charset=UTF-8";
	String AMP_SUCCESS_STATUS = "OK";
	String AMP_BAD_REQUEST = "Bad Request";
	String AMP_CREATED = "Created";
	String AMP_UNAUTH = "Unauthorized";
	String AMP_FORBIDDEN = "Forbidden";
	String AMP_NOT_FOUND = "Not Found";
	String AMP_NO_DATA = "No Data Found";
	String AMP_SERVICE_NOT_AVAILABLE = "SERVICE NOT AVAILABLE";
	String AMP_TECH_ERROR_MSG = "System is unavailable. Please try again later. ";
	String AMP_TECH_ERROR_CODE = "9000";
	String AMP_MISSING_PARAMETERS = "One or more of the request parameters are missing/wrong. Please correct the request.";
	String AMP_ERR_004 = "1001";
	String AMP_ERR_CODE_1005 = "1005";
	String AMP_ERR_MSG_1005 = "Internal server error";
	String AMP_ERR_CODE_1006 = "1006";
	String AMP_ERR_MSG_1006 = "Add/Update payment method failure";
	String AMP_ERR_CODE_1007 = "1007";
	String AMP_ERR_MSG_1007 = "Delete payment method failure";
	String AMP_ERR_CODE_1008 = "1008";
	String AMP_ERR_MSG_1008 = "No Data found for the request parameters passed";
	String INACTIVE_STR = "INACTIVE";
	String ACTIVE_STR = "ACTIVE";
	String AMP_ERR_CODE_1009 = "1009";
	String AMP_ERR_MSG_1009 = "No Results Found";
	
	String TECHINICAL_ERROR_MSG = "We've encountered a technical error";
	String ERROR_EMPTY_HCID_LIST = "Hcid list must not have empty values";
}
