/*package com.anthem.wgs.payment.exception.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.anthem.wgs.payment.response.WGSExceptionResponse;
import com.anthem.wgs.payment.util.WGSPaymentConstants;
import com.anthem.wgs.payment.util.WGSUtils;
import com.anthem.wgs.payment.vo.Exception;

@ControllerAdvice
public class WGSExceptionHandler extends ResponseEntityExceptionHandler implements WGSPaymentConstants {

	@ExceptionHandler(MemberPayException.class)
	public @ResponseBody
	ResponseEntity<Object> handleCustomException(MemberPayException ex) {
		WGSExceptionResponse exResponse = new WGSExceptionResponse();
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		Exception apiError = new Exception();
		if (null != ex) {
			if(ex.getException() != null && ex.getException() instanceof IllegalAccessException) {
				status = HttpStatus.FORBIDDEN;
			} else {
				status = HttpStatus.BAD_REQUEST;
			}
			if(AMP_ERR_CODE_1009.equalsIgnoreCase(ex.getErrorCode())){
				status = HttpStatus.NO_CONTENT;
			}
			apiError.setCode(ex.getErrorCode());
			apiError.setMessage(ex.getErrorMessage());
		} else {
			apiError.setCode(AMP_TECH_ERROR_CODE);
			apiError.setMessage(AMP_TECH_ERROR_MSG);
		}
		exResponse.setExceptions(Arrays.asList(apiError));
		exResponse.setTransactionTimestamp(WGSUtils.dateToStr(new Date()));
//		exResponse.setUuid(UUID.randomUUID().toString());
		return new ResponseEntity<Object>(exResponse, new HttpHeaders(), status);
	}
	
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<Exception> exceptionList= new ArrayList<Exception>();
		Exception apiError = new Exception();
		apiError.setCode(AMP_ERR_004);
		apiError.setMessage(AMP_MISSING_PARAMETERS);
		exceptionList.add(apiError);
		
		WGSExceptionResponse exResponse = new WGSExceptionResponse();
		exResponse.setExceptions(exceptionList);
		exResponse.setTransactionTimestamp(WGSUtils.dateToStr(new Date()));
//		exResponse.setUuid(UUID.randomUUID().toString());
		return handleExceptionInternal(ex, exResponse, headers, HttpStatus.BAD_REQUEST, request);
	}

}
*/