package com.wgs.payment.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wgs.payment.exception.handler.MemberPayException;
import com.wgs.payment.request.GetPaymentMethodRequest;
import com.wgs.payment.request.UpdatePaymentMethodRequest;
import com.wgs.payment.response.BaseResponse;
import com.wgs.payment.response.GetPaymentMethodResponse;
import com.wgs.payment.response.UpdatePaymentMethodResponse;
import com.wgs.payment.service.WGSPaymentService;
import com.wgs.payment.util.WGSPaymentConstants;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class WGSPaymentController implements WGSPaymentConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(WGSPaymentController.class);
	
	@Autowired
	private WGSPaymentService wgsPaymentService;
	
	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Methods", notes = "The api call is used to retrieve the payment methods")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = GetPaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = WGSExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 204, message = AMP_NO_DATA),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = WGSExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getPaymentMethods(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws WGSException  {
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethods - start");
		
		GetPaymentMethodResponse getPaymentMethodResponse = wgsPaymentService.getPaymentMethods(getPaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethods - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/add", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Add Payment Method", notes = "The api call is used to add payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = WGSExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = WGSExceptionResponse.class) })
	public ResponseEntity<BaseResponse> addPaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws WGSException  {
		
		LOGGER.info("WGSPaymentController: Inside addPaymentMethod - start");
		
		UpdatePaymentMethodResponse updatePaymentMethodResponse = wgsPaymentService.addOrUpdatePaymentMethod(updatePaymentMethodRequest,"ADD");
		
		LOGGER.info("WGSPaymentController: Inside addPaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/delete", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Delete Payment Method", notes = "The api call is used to delete payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = DeletePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = WGSExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = WGSExceptionResponse.class) })
	public ResponseEntity<BaseResponse> deletePaymentMethod(@RequestBody @Valid DeletePaymentMethodRequest deletePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws WGSException  {
		
		LOGGER.info("WGSPaymentController: Inside deletePaymentMethod - start");
		
		DeletePaymentMethodResponse deletePaymentMethodResponse = wgsPaymentService.deletePaymentMethod(deletePaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside deletePaymentMethod - end");

		return new ResponseEntity(deletePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/update", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Update Payment Method", notes = "The api call is used to edit payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = WGSExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = WGSExceptionResponse.class) })
	public ResponseEntity<BaseResponse> updatePaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws WGSException  {
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - start");
		
		UpdatePaymentMethodResponse updatePaymentMethodResponse = wgsPaymentService.addOrUpdatePaymentMethod(updatePaymentMethodRequest,"UPD");
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}*/
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/updatePaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Update Payment Method", notes = "The api call is used to update payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = MemberPayException.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = MemberPayException.class) })
	public ResponseEntity<BaseResponse> updatePaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws MemberPayException  {
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - start");
		
		UpdatePaymentMethodResponse updatePaymentMethodResponse = wgsPaymentService.updatePaymentMethod(updatePaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside updatePaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/getPaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Method", notes = "The api call is used to update payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = MemberPayException.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = MemberPayException.class) })
	public ResponseEntity<BaseResponse> getPaymentMethod(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws MemberPayException  {
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethod - start");
		
		GetPaymentMethodResponse getPaymentMethodResponse = wgsPaymentService.getPaymentMethods(getPaymentMethodRequest);
		
		LOGGER.info("WGSPaymentController: Inside getPaymentMethod - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}

}
