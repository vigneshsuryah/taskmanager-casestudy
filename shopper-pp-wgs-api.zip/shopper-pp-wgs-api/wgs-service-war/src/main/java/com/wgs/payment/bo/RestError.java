package com.wgs.payment.bo;

public class RestError {
	private Exceptions[] exceptions;

	public Exceptions[] getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions[] exceptions) {
		this.exceptions = exceptions;
	}
}
