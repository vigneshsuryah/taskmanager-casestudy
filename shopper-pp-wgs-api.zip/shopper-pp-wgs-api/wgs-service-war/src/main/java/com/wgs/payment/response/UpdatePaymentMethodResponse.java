package com.wgs.payment.response;

import com.wgs.payment.bo.MemberPayPaymentMethod;

public class UpdatePaymentMethodResponse extends BaseResponse {

	private static final long serialVersionUID = -7121556993038508581L;
	
	private MemberPayPaymentMethod memberpayPaymentMethod;

	public MemberPayPaymentMethod getMemberpayPaymentMethod()
	{
		return memberpayPaymentMethod;
	}

	public void setMemberpayPaymentMethod(MemberPayPaymentMethod memberpayPaymentMethod)
	{
		this.memberpayPaymentMethod = memberpayPaymentMethod;
	}

}
