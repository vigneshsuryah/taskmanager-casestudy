package com.wgs.payment.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.wgs.payment.bo.MemberPayAcctTypeEnum;
import com.wgs.payment.bo.MemberPayAddress;
import com.wgs.payment.bo.MemberPayPaymentMethod;
import com.wgs.payment.entity.BankAccount;
import com.wgs.payment.entity.FundAccOwnerFullAddress;
import com.wgs.payment.entity.PaymentWallet;
import com.wgs.payment.entity.Token;
import com.wgs.payment.exception.handler.MemberPayException;
import com.wgs.payment.repository.PaymentWalletRepository;
import com.wgs.payment.request.GetPaymentMethodRequest;
import com.wgs.payment.request.UpdatePaymentMethodRequest;
import com.wgs.payment.response.GetPaymentMethodResponse;
import com.wgs.payment.response.UpdatePaymentMethodResponse;
import com.wgs.payment.service.WGSPaymentService;
import com.wgs.payment.util.WGSPaymentConstants;
import com.wgs.payment.util.WGSUtils;

@Service
public class WGSPaymentServiceImpl implements WGSPaymentService, WGSPaymentConstants {


	private final static Logger LOGGER = LoggerFactory.getLogger(WGSPaymentServiceImpl.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private PaymentWalletRepository paymentWalletRepository;

	@Autowired
	private MongoOperations mongoOperations;

	
	/*@Override
	public UpdatePaymentMethodResponse addOrUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action)
			throws WGSException {
		LOGGER.info("Inside WGSPaymentServiceImpl - addOrUpdatePaymentMethod - Start");
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		String tokenId = "";
		try {
			if("ADD".equalsIgnoreCase(action)) {
				updatePaymentMethodRequest.getPaymentMethod().setPaymentFutureUse(true);
				List<PaymentWallet> payWallets = paymentWalletRepository.getPaymentWalletByAcid(updatePaymentMethodRequest.getAcid());
				if(null != payWallets && payWallets.size() > 0) {
					for(PaymentWallet payWallet : payWallets) {
						if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
							int count = 0;
							for(Token token : payWallet.getTokens()) {
								if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != updatePaymentMethodRequest.getPaymentMethod() &&
										updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse()) {
									token.setUpdatedDt(new Date());
									token.setUpdatedId(updatePaymentMethodRequest.getAcid());
									token.setStatus(INACTIVE_STR);
									Query query = new Query();
									query.addCriteria(Criteria.where("acid").is(updatePaymentMethodRequest.getAcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
									Update update = new Update();
									update.set("tokens."+count, token);
									mongoOperations.findAndModify(query, update, PaymentWallet.class);
								}
								count++;
							}
							Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
							newToken.setCreatedDt(new Date());
							newToken.setCreatedId(updatePaymentMethodRequest.getAcid());
							newToken.setTokenId(WGSUtils.getRandomString(12));
							tokenId = newToken.getTokenId();
							Query query = new Query();
							query.addCriteria(Criteria.where("acid").is(updatePaymentMethodRequest.getAcid()));
							Update update = new Update();
							update.set("tokens."+payWallet.getTokens().length, newToken);
							mongoOperations.findAndModify(query, update, PaymentWallet.class);
						}
					}
				}else {
					PaymentWallet paymentWallet = dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod(),
							PaymentWallet.class);
					paymentWallet.setAcid(updatePaymentMethodRequest.getAcid());
					constructPaymentWalletForAdd(updatePaymentMethodRequest, paymentWallet);
					paymentWallet.getTokens()[0].setCreatedDt(new Date());
					paymentWallet.getTokens()[0].setCreatedId(updatePaymentMethodRequest.getAcid());
					paymentWallet.getTokens()[0].setTokenId(WGSUtils.getRandomString(12));
					tokenId = paymentWallet.getTokens()[0].getTokenId();
					mongoTemplate.save(paymentWallet);
				}
				
			}else if("UPD".equalsIgnoreCase(action) && null != updatePaymentMethodRequest.getPaymentMethod()) {
				PaymentWallet payWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						updatePaymentMethodRequest.getAcid(), updatePaymentMethodRequest.getPaymentMethod().getPaymentMethodId());
				if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
					int count = 0;
					for(Token token : payWallet.getTokens()) {
						if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() && 
								token.getTokenId().equalsIgnoreCase(updatePaymentMethodRequest.getPaymentMethod().getPaymentMethodId()) && updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse()) {
							token.setUpdatedDt(new Date());
							token.setUpdatedId(updatePaymentMethodRequest.getAcid());
							token.setStatus(INACTIVE_STR);
							Query query = new Query();
							query.addCriteria(Criteria.where("acid").is(updatePaymentMethodRequest.getAcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
							Update update = new Update();
							update.set("tokens."+count, token);
							mongoOperations.findAndModify(query, update, PaymentWallet.class);
						}
						count++;
					}
					Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
					newToken.setCreatedDt(new Date());
					newToken.setCreatedId(updatePaymentMethodRequest.getAcid());
					newToken.setTokenId(WGSUtils.getRandomString(12));
					tokenId = newToken.getTokenId();
					Query query = new Query();
					query.addCriteria(Criteria.where("acid").is(updatePaymentMethodRequest.getAcid()));
					Update update = new Update();
					update.set("tokens."+payWallet.getTokens().length, newToken);
					mongoOperations.findAndModify(query, update, PaymentWallet.class);
				}else {
					throw new WGSException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008);
				}
			}
			paymentMethodResponse.setPaymentMethodId(tokenId);
			paymentMethodResponse.setTransactionTimestamp(WGSUtils.dateToStr(new Date()));
		}
		catch(Exception e) {
			LOGGER.error("Exception in add/update payment method: " + e);
			if (e instanceof WGSException) {
				WGSException ex = (WGSException) e;
				if(AMP_ERR_CODE_1008.equalsIgnoreCase(ex.getErrorCode())) {
					throw e;
				}else {
					throw new WGSException(AMP_ERR_CODE_1006, AMP_ERR_MSG_1006);
				}
			} else {
				throw new WGSException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);

			}
		}

		LOGGER.info("Inside WGSPaymentServiceImpl - addOrUpdatePaymentMethod - End");
		return paymentMethodResponse;
	}


	private void constructPaymentWalletForAdd(UpdatePaymentMethodRequest updatePaymentMethodRequest,
			PaymentWallet paymentWallet) throws WGSException {
		Token[] tokens = new Token[1];
		tokens[0] = constructPaymentWalletForUpd(updatePaymentMethodRequest);
		paymentWallet.setTokens(tokens);
	}
	
	private Token constructPaymentWalletForUpd(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws WGSException {
		Token token = new Token();
		token.setAccNickName(updatePaymentMethodRequest.getPaymentMethod().getAccNickName());
		token.setNameOnFundingAcc(updatePaymentMethodRequest.getPaymentMethod().getAccountHolderName());
		token.setPaymentType(updatePaymentMethodRequest.getPaymentMethod().getPaymentType());
		if (null != updatePaymentMethodRequest.getPaymentMethod().getBillingAddress()) {
			FundAccOwnerFullAddress fundAccAddress = dozerMapper.map(
					updatePaymentMethodRequest.getPaymentMethod().getBillingAddress(), FundAccOwnerFullAddress.class);
			token.setFundAccOwnerFullAddress(fundAccAddress);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails()) {
			BankAccount bankAcc = dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails(),
					BankAccount.class);
			bankAcc.setBankAccountType(WGSUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails().getBankAccountType()));
			token.setBankAccount(bankAcc);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()) {
			CreditCard creditCard =  dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails(),
					CreditCard.class);
			creditCard.setCreditCardType(WGSUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardType()));
			String ccNo = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardNumber();
			GetTokenRequest getTokenRequest = new GetTokenRequest();
			getTokenRequest.setAccountNumber(ccNo);
			getTokenRequest.setCardHolderName(updatePaymentMethodRequest.getPaymentMethod().getAccountHolderName());
			String paySubType = creditCard.getCreditCardType();
			getTokenRequest.setMethodOfPayment(
					(null != paySubType && !paySubType.isEmpty() && "VISA".equalsIgnoreCase(paySubType)) ? "VI"
							: paySubType);
			if (null != updatePaymentMethodRequest.getPaymentMethod().getBillingAddress()) {
				getTokenRequest.setAddressLine1(
						updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getAddressLine1());
				getTokenRequest.setCity(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getCity());
				getTokenRequest.setPostalCode(
						updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getPostalCode());
				getTokenRequest.setState(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getState());
			}
			getTokenRequest.setAmount("0"); // have to check -- hardcoded
			if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth()
					&& null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
					.getExpirationYear()) {
				String expYear = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
						.getExpirationYear();
				getTokenRequest.setExpirationDate(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth() + expYear.substring(expYear.length() - 2));
			}
			getTokenRequest.setIntegrityCheck(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getIntegrityCheck());
			getTokenRequest.setKeyID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getKeyID());
			getTokenRequest
			.setPhaseID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getPhaseID());


			creditCard.setCreditCardTokenNumber("");
			token.setCreditCard(creditCard);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod()) {
			String status = updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse() ? ACTIVE_STR : INACTIVE_STR;
			token.setStatus(status);
		}
		return token;
	}

	@Override
	public DeletePaymentMethodResponse deletePaymentMethod(DeletePaymentMethodRequest deletePaymentMethodRequest)
			throws WGSException {
		LOGGER.info("Inside WGSPaymentServiceImpl - deletePaymentMethod - Start");
		DeletePaymentMethodResponse deletePaymentMethodResponse = new DeletePaymentMethodResponse();
		try {
			if (null != deletePaymentMethodRequest.getPaymentMethodID()) {
				PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						deletePaymentMethodRequest.getAcid(), deletePaymentMethodRequest.getPaymentMethodID());
				if (null != paymentWallet && null != paymentWallet.getTokens()
						&& paymentWallet.getTokens().length > 0) {
					int count = 0;
					for(Token token : paymentWallet.getTokens()) {
						if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() && 
								token.getTokenId().equalsIgnoreCase(deletePaymentMethodRequest.getPaymentMethodID())) {
							token.setUpdatedDt(new Date());
							token.setUpdatedId(deletePaymentMethodRequest.getAcid());
							token.setStatus(INACTIVE_STR);
							Query query = new Query();
							query.addCriteria(Criteria.where("acid").is(deletePaymentMethodRequest.getAcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
							Update update = new Update();
							update.set("tokens."+count, token);
							mongoOperations.findAndModify(query, update, PaymentWallet.class);
						}
						count++;
					}
					
				}else {
					throw new WGSException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008);
				}
				deletePaymentMethodResponse.setPaymentMethodId(deletePaymentMethodRequest.getPaymentMethodID());
				deletePaymentMethodResponse.setTransactionTimestamp(WGSUtils.dateToStr(new Date()));
			}
		} catch (Exception e) {
			LOGGER.error("Exception in delete payment method: " + e);
			if (e instanceof WGSException) {
				throw e;
			} else {
				throw new WGSException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);

			}
		}
		LOGGER.info("Inside WGSPaymentServiceImpl - deletePaymentMethod - End");
		return deletePaymentMethodResponse;
	}

	@Override
	public GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest)
			throws WGSException {
		LOGGER.info("Inside WGSPaymentServiceImpl - getPaymentMethods - start");
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		try {
			if (null != getPaymentMethodRequest.getAcid()) {
				List<PaymentWallet> paymentWallets = null;
				if (null != getPaymentMethodRequest.getPaymentMethodID()
						&& !getPaymentMethodRequest.getPaymentMethodID().isEmpty()) {
					if (null != getPaymentMethodRequest.getStatus() && !getPaymentMethodRequest.getStatus().isEmpty()) {
						paymentWallets = paymentWalletRepository.getPaymentWalletForTokenID(
								getPaymentMethodRequest.getAcid(), getPaymentMethodRequest.getStatus().toUpperCase(),
								getPaymentMethodRequest.getPaymentMethodID());
					}
				} else {
					if (null != getPaymentMethodRequest.getStatus() && !getPaymentMethodRequest.getStatus().isEmpty()) {
						paymentWallets = paymentWalletRepository.getPaymentWalletWithStatus(
								getPaymentMethodRequest.getAcid(), getPaymentMethodRequest.getStatus().toUpperCase());
					} else {
						paymentWallets = paymentWalletRepository.getPaymentWalletByAcid(getPaymentMethodRequest.getAcid());
					}
				}
				if (null != paymentWallets && paymentWallets.size() > 0) {
					List<PaymentMethod> paymentMethods = new ArrayList<PaymentMethod>();
					for (PaymentWallet payment : paymentWallets) {
						if (null != payment.getTokens() && payment.getTokens().length > 0) {
							for (Token token : payment.getTokens()) {
								if(null ==  getPaymentMethodRequest.getStatus() || getPaymentMethodRequest.getStatus().equalsIgnoreCase(token.getStatus())) {
									PaymentMethod payMethod = new PaymentMethod();
									boolean payFutureUse = ACTIVE_STR.equalsIgnoreCase(token.getStatus()) ? true : false;
									payMethod.setPaymentFutureUse(payFutureUse);
									payMethod.setAccNickName(token.getAccNickName());
									payMethod.setAccountHolderName(token.getNameOnFundingAcc());
									if (null != token.getBankAccount()) {
										BankAccountDetails bankAccountDetails = dozerMapper.map(token.getBankAccount(),
												BankAccountDetails.class);
										bankAccountDetails.setBankAccountType(
												WGSUtils.convertPaymentSubType(token.getBankAccount().getBankAccountType()));
										payMethod.setBankAccountDetails(bankAccountDetails);
									}
									if (null != token.getFundAccOwnerFullAddress()) {
										payMethod.setBillingAddress(
												dozerMapper.map(token.getFundAccOwnerFullAddress(), BillingAddress.class));
									}
									if (null != token.getCreditCard()) {
										CreditCardDetails creditCardDetails = dozerMapper.map(token.getCreditCard(),
												CreditCardDetails.class);
										creditCardDetails.setCreditCardType(
												WGSUtils.convertPaymentSubType(token.getCreditCard().getCreditCardType()));
										payMethod.setCreditCardDetails(creditCardDetails);
									}
									payMethod.setPaymentMethodId(token.getTokenId());
									payMethod.setPaymentType(token.getPaymentType());

									paymentMethods.add(payMethod);
								}

							}
						}
					}
					response.setPaymentMethods(paymentMethods);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getPaymentMethods " + e);
			throw new WGSException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);
		}
		if(null != response && (null == response.getPaymentMethods() || response.getPaymentMethods().isEmpty())){
			throw new WGSException(AMP_ERR_CODE_1009, AMP_ERR_MSG_1009);
		}
		LOGGER.info("Inside WGSPaymentServiceImpl - getPaymentMethods - End");
		return response;
	}*/

	@Override
	public UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest)
			throws MemberPayException {
		
		LOGGER.info("Inside WGSPaymentServiceImpl - updatePaymentMethod - Start");
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		String tokenId = "";
		MemberPayPaymentMethod memberPayPaymentMethod = new MemberPayPaymentMethod();
		if("ADD".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			LOGGER.info("Inside WGSPaymentServiceImpl - updatePaymentMethod - ADD");
			try {
				//updatePaymentMethodRequest.getPaymentMethod().setPaymentFutureUse(true); - need to confirm
				List<PaymentWallet> payWallets = paymentWalletRepository.getPaymentWalletByHcid(updatePaymentMethodRequest.getHcid());
				if(null != payWallets && payWallets.size() > 0) {
					for(PaymentWallet payWallet : payWallets) {
						if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
							int count = 0;
							for(Token token : payWallet.getTokens()) {
								if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != updatePaymentMethodRequest.getPaymentMethod()) {
									token.setUpdatedDt(new Date());
									token.setUpdatedId(updatePaymentMethodRequest.getHcid());
									token.setStatus(INACTIVE_STR);
									Query query = new Query();
									query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
									Update update = new Update();
									update.set("tokens."+count, token);
									mongoOperations.findAndModify(query, update, PaymentWallet.class);
								}
								count++;
							}
							Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
							newToken.setCreatedDt(new Date());
							newToken.setCreatedId(updatePaymentMethodRequest.getHcid());
							newToken.setTokenId(WGSUtils.getRandomString(12));
							tokenId = newToken.getTokenId();
							Query query = new Query();
							query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()));
							Update update = new Update();
							update.set("tokens."+payWallet.getTokens().length, newToken);
							mongoOperations.findAndModify(query, update, PaymentWallet.class);
						}
					}
				}else {
					PaymentWallet paymentWallet = new PaymentWallet();
					paymentWallet.setHcid(updatePaymentMethodRequest.getHcid());
					constructPaymentWalletForAdd(updatePaymentMethodRequest, paymentWallet);
					paymentWallet.getTokens()[0].setCreatedDt(new Date());
					paymentWallet.getTokens()[0].setCreatedId(updatePaymentMethodRequest.getHcid());
					paymentWallet.getTokens()[0].setTokenId(WGSUtils.getRandomString(12));
					tokenId = paymentWallet.getTokens()[0].getTokenId();
					mongoTemplate.save(paymentWallet);
				}
				memberPayPaymentMethod.setTokenId(tokenId);
				paymentMethodResponse.setMemberpayPaymentMethod(memberPayPaymentMethod);
			}catch(Exception e) {
				LOGGER.error("Exception in update payment method - ADD: " + e);
			}
			
		}else if("MODIFY".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			LOGGER.info("Inside WGSPaymentServiceImpl - updatePaymentMethod - MODIFY");
			try {
				PaymentWallet payWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						updatePaymentMethodRequest.getHcid(), updatePaymentMethodRequest.getPaymentMethod().getTokenId());
				if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
					int count = 0;
					for(Token token : payWallet.getTokens()) {
						if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() && 
								token.getTokenId().equalsIgnoreCase(updatePaymentMethodRequest.getPaymentMethod().getTokenId())) {
							token.setUpdatedDt(new Date());
							token.setUpdatedId(updatePaymentMethodRequest.getHcid());
							token.setStatus(INACTIVE_STR);
							Query query = new Query();
							query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
							Update update = new Update();
							update.set("tokens."+count, token);
							mongoOperations.findAndModify(query, update, PaymentWallet.class);
						}
						count++;
					}
					Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
					newToken.setCreatedDt(new Date());
					newToken.setCreatedId(updatePaymentMethodRequest.getHcid());
					newToken.setTokenId(WGSUtils.getRandomString(12));
					tokenId = newToken.getTokenId();
					Query query = new Query();
					query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()));
					Update update = new Update();
					update.set("tokens."+payWallet.getTokens().length, newToken);
					mongoOperations.findAndModify(query, update, PaymentWallet.class);
				}else {
					throw new MemberPayException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008, 0);//need to confirm
				}
				memberPayPaymentMethod.setTokenId(tokenId);
				paymentMethodResponse.setMemberpayPaymentMethod(memberPayPaymentMethod);
			}
			catch(Exception e) {
				LOGGER.error("Exception in update payment method - MODIFY: " + e);
			}
		}else if("DELETE".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			LOGGER.info("Inside WGSPaymentServiceImpl - updatePaymentMethod - DELETE");
			try {
				if (null != updatePaymentMethodRequest.getPaymentMethod()) {
					PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
							updatePaymentMethodRequest.getHcid(), updatePaymentMethodRequest.getPaymentMethod().getTokenId());
					if (null != paymentWallet && null != paymentWallet.getTokens()
							&& paymentWallet.getTokens().length > 0) {
						int count = 0;
						for(Token token : paymentWallet.getTokens()) {
							if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() && 
									token.getTokenId().equalsIgnoreCase(updatePaymentMethodRequest.getPaymentMethod().getTokenId())) {
								token.setUpdatedDt(new Date());
								token.setUpdatedId(updatePaymentMethodRequest.getHcid());
								token.setStatus(INACTIVE_STR);
								Query query = new Query();
								query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()).and("tokens."+count+".token_id").is(token.getTokenId()));
								Update update = new Update();
								update.set("tokens."+count, token);
								mongoOperations.findAndModify(query, update, PaymentWallet.class);
							}
							count++;
						}
						
					}else {
						throw new MemberPayException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008, 0);//need to confirm
					}
					memberPayPaymentMethod.setTokenId(updatePaymentMethodRequest.getPaymentMethod().getTokenId());
					paymentMethodResponse.setMemberpayPaymentMethod(memberPayPaymentMethod);
					//paymentMethodResponse.setTransactionTimestamp(WGSUtils.dateToStr(new Date()));
				}
			}catch(Exception e) {
				{
					LOGGER.error("Exception in update payment method - DELETE: " + e);
				}
			}
		}
		return paymentMethodResponse;
	}
	
	private void constructPaymentWalletForAdd(UpdatePaymentMethodRequest updatePaymentMethodRequest,
			PaymentWallet paymentWallet) throws MemberPayException {
		Token[] tokens = new Token[1];
		tokens[0] = constructPaymentWalletForUpd(updatePaymentMethodRequest);
		paymentWallet.setTokens(tokens);
	}
	
	private Token constructPaymentWalletForUpd(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws MemberPayException {
		Token token = new Token();
		token.setAccNickName(updatePaymentMethodRequest.getPaymentMethod().getAccNickName());
		token.setNameOnFundingAcc("");//need to check
		token.setPaymentType(updatePaymentMethodRequest.getPaymentMethod().getPaymentType().name());
		if (null != updatePaymentMethodRequest.getPaymentMethod().getBillingAddress()) {
			FundAccOwnerFullAddress fundAccAddress = new FundAccOwnerFullAddress();
			fundAccAddress.setAddress1(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getAddressLine1());
			fundAccAddress.setAddress2(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getAddressLine2());
			fundAccAddress.setCity(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getCity());
			fundAccAddress.setState(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getState());
			fundAccAddress.setZipcode(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getPostalCode());
			
			token.setFundAccOwnerFullAddress(fundAccAddress);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod()) {
			BankAccount bankAcc = new BankAccount();
			bankAcc.setBankAccountNumber(updatePaymentMethodRequest.getPaymentMethod().getConfirmAccountNo());
			bankAcc.setBankAccountType(updatePaymentMethodRequest.getPaymentMethod().getBankAccountType().name());
			bankAcc.setBankRoutingNumber(updatePaymentMethodRequest.getPaymentMethod().getRoutingNumber());
			bankAcc.setInstitutionName("");//need to check
			/*bankAcc.setBankAccountType(WGSUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails().getBankAccountType()));*/
			token.setBankAccount(bankAcc);
		}
		/*if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()) {
			CreditCard creditCard =  dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails(),
					CreditCard.class);
			creditCard.setCreditCardType(WGSUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardType()));
			String ccNo = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardNumber();
			GetTokenRequest getTokenRequest = new GetTokenRequest();
			getTokenRequest.setAccountNumber(ccNo);
			getTokenRequest.setCardHolderName(updatePaymentMethodRequest.getPaymentMethod().getAccountHolderName());
			String paySubType = creditCard.getCreditCardType();
			getTokenRequest.setMethodOfPayment(
					(null != paySubType && !paySubType.isEmpty() && "VISA".equalsIgnoreCase(paySubType)) ? "VI"
							: paySubType);
			if (null != updatePaymentMethodRequest.getPaymentMethod().getBillingAddress()) {
				getTokenRequest.setAddressLine1(
						updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getAddressLine1());
				getTokenRequest.setCity(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getCity());
				getTokenRequest.setPostalCode(
						updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getPostalCode());
				getTokenRequest.setState(updatePaymentMethodRequest.getPaymentMethod().getBillingAddress().getState());
			}
			getTokenRequest.setAmount("0"); // have to check -- hardcoded
			if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth()
					&& null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
					.getExpirationYear()) {
				String expYear = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
						.getExpirationYear();
				getTokenRequest.setExpirationDate(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth() + expYear.substring(expYear.length() - 2));
			}
			getTokenRequest.setIntegrityCheck(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getIntegrityCheck());
			getTokenRequest.setKeyID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getKeyID());
			getTokenRequest
			.setPhaseID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getPhaseID());


			creditCard.setCreditCardTokenNumber("");
			token.setCreditCard(creditCard);
		}*/
		if (null != updatePaymentMethodRequest.getPaymentMethod()) {
			//String status = updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse() ? ACTIVE_STR : INACTIVE_STR;
			token.setStatus(ACTIVE_STR);//need to confirm
		}
		return token;
	}

	@Override
	public GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest)
			throws MemberPayException {
		LOGGER.info("Inside WGSPaymentServiceImpl - getPaymentMethods - start");
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		List<GetPaymentMethodResponse> paymentMethods = new ArrayList<GetPaymentMethodResponse>();
		List<MemberPayPaymentMethod> memberpayPaymentMethods = new ArrayList<MemberPayPaymentMethod>();
		MemberPayPaymentMethod memberpayPaymentMethod = new MemberPayPaymentMethod();
		List<Token> tokens = new ArrayList<Token>();
		try {
			
			if(!WGSUtils.checkNullAndEmptyForAList(getPaymentMethodRequest.getHcids())){
				LOGGER.error(ERROR_EMPTY_HCID_LIST);
				throw new MemberPayException("I","9050",ERROR_EMPTY_HCID_LIST,400);
			} 
			//need to confirm if only valid hcid's are allowed.
			
			for(String hcid : getPaymentMethodRequest.getHcids()) {
				if(null != hcid && !hcid.isEmpty()) {
					List<PaymentWallet>paymentWallets = paymentWalletRepository.getPaymentWalletWithStatus(getPaymentMethodRequest.getHcid(), ACTIVE_STR);
					for (PaymentWallet payWallet :  paymentWallets) {
						for(Token token : tokens) {
							memberpayPaymentMethod.setAccNickName(token.getAccNickName());
							memberpayPaymentMethod.setAccountStatus(ACTIVE_STR);
							memberpayPaymentMethod.setAccountName(token.getNameOnFundingAcc());
							//memberpayPaymentMethod.setPaymentType(token.getPaymentType()); - need to check
							
							MemberPayAddress billingAddress = new MemberPayAddress();
							FundAccOwnerFullAddress fundAccFullAddress = new FundAccOwnerFullAddress();
							fundAccFullAddress = token.getFundAccOwnerFullAddress();
							billingAddress.setAddressLine1(fundAccFullAddress.getAddress1());
							billingAddress.setCity(fundAccFullAddress.getCity());
							billingAddress.setState(fundAccFullAddress.getState());
							billingAddress.setPostalCode(fundAccFullAddress.getZipcode());
							memberpayPaymentMethod.setBillingAddress(billingAddress);
							
							//memberpayPaymentMethod.setBankAccountType((MemberPayAcctTypeEnum)Enum.Parse(typeof(MemberPayAcctTypeEnum),token.getBankAccount().getBankAccountType());
							//memberpayPaymentMethod.setExpiration(expiration); commented since CC not in scope now
							memberpayPaymentMethod.setConfirmAccountNo(token.getBankAccount().getBankAccountNumber());
							memberpayPaymentMethod.setTokenId(token.getTokenId());
							memberpayPaymentMethod.setHcid(payWallet.getHcid());
							
							memberpayPaymentMethods.add(memberpayPaymentMethod);
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getPaymentMethods " + e);
			throw new MemberPayException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005, 0);
		}
		
		LOGGER.info("Inside WGSPaymentServiceImpl - getPaymentMethods - End");
		return response;
	}
	
	
}