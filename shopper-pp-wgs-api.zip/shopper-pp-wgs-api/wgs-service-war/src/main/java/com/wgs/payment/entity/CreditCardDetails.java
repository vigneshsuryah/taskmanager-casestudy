package com.wgs.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class CreditCardDetails {

	@Field("creditCardNumber")
	private String creditCardNumber;
	
	@Field("creditCardType")
	private String creditCardType;
	
	@Field("credit_card_first_six")
	private String creditCardFirstSix;

	@Field("credit_card_last_four")
	private String creditCardLastFour;

	@Field("cc_authorization_number")
	private String ccAuthorizationNumber;

	@Field("interchange_qualification_code")
	private String interchangeQualificationCode;

	@Field("action_code")
	private String actionCode;

	@Field("cc_exp_date")
	private String ccExpDate;

	@Field("response_reason_code")
	private String responseReasonCode;

	@Field("token_response_date")
	private String tokenDate;

	@Field("is_level3")
	private String isLevelThree;

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}

	public String getCcAuthorizationNumber() {
		return ccAuthorizationNumber;
	}

	public void setCcAuthorizationNumber(String ccAuthorizationNumber) {
		this.ccAuthorizationNumber = ccAuthorizationNumber;
	}

	public String getInterchangeQualificationCode() {
		return interchangeQualificationCode;
	}

	public void setInterchangeQualificationCode(String interchangeQualificationCode) {
		this.interchangeQualificationCode = interchangeQualificationCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getCcExpDate() {
		return ccExpDate;
	}

	public void setCcExpDate(String ccExpDate) {
		this.ccExpDate = ccExpDate;
	}

	public String getResponseReasonCode() {
		return responseReasonCode;
	}

	public void setResponseReasonCode(String responseReasonCode) {
		this.responseReasonCode = responseReasonCode;
	}

	public String getTokenDate() {
		return tokenDate;
	}

	public void setTokenDate(String tokenDate) {
		this.tokenDate = tokenDate;
	}

	public String getIsLevelThree() {
		return isLevelThree;
	}

	public void setIsLevelThree(String isLevelThree) {
		this.isLevelThree = isLevelThree;
	}
	
}
