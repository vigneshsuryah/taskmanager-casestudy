package com.wgs.payment.bo;


public enum MemberPayPaymentTypeEnum
{

	NONE,

	BANKINGACCOUNT,

	CREDITDEBITCARD;

}