package com.wgs.payment.service;

import com.wgs.payment.exception.handler.MemberPayException;
import com.wgs.payment.request.GetPaymentMethodRequest;
import com.wgs.payment.request.UpdatePaymentMethodRequest;
import com.wgs.payment.response.GetPaymentMethodResponse;
import com.wgs.payment.response.UpdatePaymentMethodResponse;

public interface WGSPaymentService {

    /*UpdatePaymentMethodResponse addOrUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action) throws WGSException;
    
    DeletePaymentMethodResponse deletePaymentMethod(DeletePaymentMethodRequest deletePaymentMethodRequest) throws WGSException;
    
    GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws WGSException;*/
	
	UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws MemberPayException;
	
	GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws MemberPayException;
	
}
