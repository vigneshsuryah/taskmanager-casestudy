package com.wgs.payment.response;

import java.util.List;

import com.wgs.payment.bo.MemberPayPaymentMethod;

public class GetPaymentMethodResponse extends BaseResponse {

	private static final long serialVersionUID = -2313166783067200949L;

	private List<MemberPayPaymentMethod> memberpayPaymentMethods;


	public List<MemberPayPaymentMethod> getMemberpayPaymentMethods()
	{
		return memberpayPaymentMethods;
	}

	public void setMemberpayPaymentMethods(List<MemberPayPaymentMethod> memberpayPaymentMethods)
	{
		this.memberpayPaymentMethods = memberpayPaymentMethods;
	}
	
}
