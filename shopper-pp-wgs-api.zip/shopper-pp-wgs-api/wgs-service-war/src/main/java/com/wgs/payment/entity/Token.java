package com.wgs.payment.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class Token {

	@Field("payment_type")
	private String paymentType;

	@Field("creditcard")
	private CreditCard creditCard;

	@Field("bankaccount")
	private BankAccount bankAccount;

	@Field("token_id")
	private String tokenId;

	@Field("name_on_funding_account")
	private String nameOnFundingAcc;

	@Field("account_nickname")
	private String accNickName;

	@Field("fund_account_owner_full_address")
	private FundAccOwnerFullAddress fundAccOwnerFullAddress;

	@Field("status")
	private String status;

	@Field("created_dt")
	private Date createdDt;

	@Field("created_id")
	private String createdId;

	@Field("updated_dt")
	private Date updatedDt;

	@Field("updated_id")
	private String updatedId;

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public BankAccount getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getNameOnFundingAcc() {
		return nameOnFundingAcc;
	}

	public void setNameOnFundingAcc(String nameOnFundingAcc) {
		this.nameOnFundingAcc = nameOnFundingAcc;
	}

	public String getAccNickName() {
		return accNickName;
	}

	public void setAccNickName(String accNickName) {
		this.accNickName = accNickName;
	}

	public FundAccOwnerFullAddress getFundAccOwnerFullAddress() {
		return fundAccOwnerFullAddress;
	}

	public void setFundAccOwnerFullAddress(FundAccOwnerFullAddress fundAccOwnerFullAddress) {
		this.fundAccOwnerFullAddress = fundAccOwnerFullAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedId() {
		return createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

}
