package com.wgs.payment.config;


import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.wgs.payment.entity.BankAccount;
import com.wgs.payment.entity.CreditCard;
import com.wgs.payment.entity.FundAccOwnerFullAddress;
import com.wgs.payment.vo.BankAccountDetails;
import com.wgs.payment.vo.BillingAddress;
import com.wgs.payment.vo.CreditCardDetails;


@Configuration
public class MappingConfig
{

	@Bean(name = "org.dozer.Mapper")
	public DozerBeanMapper dozerBean()
	{
		DozerBeanMapper dozerBean = new DozerBeanMapper();
		//dozerBean.addMapping(getPaymentWallet());
		dozerBean.addMapping(getFundAccFullAddress());
		dozerBean.addMapping(getBankAccDetails());
		dozerBean.addMapping(getCreditCardDetails());
		return dozerBean;
	}
	
	private BeanMappingBuilder getFundAccFullAddress() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(BillingAddress.class, type(FundAccOwnerFullAddress.class))
				.fields("addressLine1","address1")
				.fields("addressLine2","address2")
				.fields("city","city")
				.fields("state","state")
				.fields("postalCode","zipcode");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getBankAccDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(BankAccountDetails.class, type(BankAccount.class))
				.fields("bankAccountNumber","bankAccountNumber")
				.fields("routingNumber","bankRoutingNumber");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getCreditCardDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(CreditCardDetails.class, type(CreditCard.class))
				.fields("creditCardNumber","creditCardNumber")
				.fields("expirationMonth","expirationMonth")
				.fields("expirationYear","expirationYear")
				.fields("expirationMonth","expirationMonth")
				.fields("integrityCheck","integrityCheck")
				.fields("keyID","keyID")
				.fields("phaseID","phaseID");
			}
		};
		return builder;
	}
	
}
