package com.wgs.payment.util;

import java.math.RoundingMode;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wgs.payment.exception.handler.MemberPayException;

@Component
public class WGSUtils implements WGSPaymentConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(WGSUtils.class);
	
	private static final int DEAFULT_LIST_SIZE = 0;
	
	public static String returnPaymentSubType(String paymentType) {
		String paymentSubType = "";
		if (null != paymentType) {
			if (paymentType.equalsIgnoreCase("PERSONALCHECKING")) {
				paymentSubType = "PERSONAL CHECKING";
			} else if (paymentType.equalsIgnoreCase("PERSONALSAVINGS")) {
				paymentSubType = "PERSONAL SAVINGS";
			} else if (paymentType.equalsIgnoreCase("BUSCHECKING")) {
				paymentSubType = "BUSINESS CHECKING";
			} else if (paymentType.equalsIgnoreCase("BUSSAVINGS")) {
				paymentSubType = "BUSINESS SAVINGS";
			} else if (paymentType.equalsIgnoreCase("VISA")) {
				paymentSubType = "VISA";
			} else if (paymentType.equalsIgnoreCase("MASTERCARD") || paymentType.equalsIgnoreCase("MC")) {
				paymentSubType = "MC";
			}
		}
		return paymentSubType;
	}
	
	public static String getRandomString(int length) {	
		String randomString = "";
		try {
			SecureRandom secureRandom = new SecureRandom();
			String letters = "ABCDEFGHJKMNPQRSTUVWXYZ";
			String numbers = "0123456789";
			int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
			int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
			String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
			String shortId = RandomStringUtils.random(10, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			randomString = randomChar + shortId;
		}catch(Exception e) {
			LOGGER.error("Error occured in getRandomString : " + e);
		}
		return randomString;
	}
	
	public static String generateOrderId(String payChannel) {
		String orderId = "";
		try {
			Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
            SecureRandom secureRandom = new SecureRandom();
            String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
            String numbers = "0123456789";
            int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
            int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
            String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
            String shortId = RandomStringUtils.random(7, "0123456789");
            orderId = payChannel + dateFormat.format(date) + randomChar + shortId;
		} catch (Exception e) {
			LOGGER.error("Exception -- while generateOrderId " + e);
		}
		if(orderId != null && StringUtils.isNotBlank(orderId) && StringUtils.isNotEmpty(orderId)) {
			orderId = orderId.toLowerCase();
		}
		return orderId;
	}
	
	public static String convertPaymentSubType(String paymentType) {
		String paymentSubType = "";
		if (null != paymentType) {
			if (paymentType.equalsIgnoreCase("PERSONAL CHECKING")) {
				paymentSubType = "PERSONALCHECKING";
			} else if (paymentType.equalsIgnoreCase("PERSONAL SAVINGS")) {
				paymentSubType = "PERSONALSAVINGS";
			} else if (paymentType.equalsIgnoreCase("BUSINESS CHECKING")) {
				paymentSubType = "BUSCHECKING";
			} else if (paymentType.equalsIgnoreCase("BUSINESS SAVINGS")) {
				paymentSubType = "BUSSAVINGS";
			} else if (paymentType.equalsIgnoreCase("VISA")) {
				paymentSubType = "VISA";
			} else if (paymentType.equalsIgnoreCase("MASTERCARD") || paymentType.equalsIgnoreCase("MC")) {
				paymentSubType = "MC";
			}
		}
		return paymentSubType;
	}
	
	public static String dateToStr(Date date)
	{
		String dateStr = "";
		try
		{
			if(null != date)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.sss");
				dateStr = sdf.format(date);
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in dateToStr : " + e);
		}
		return dateStr;
	}
	
	public static String roundUp(String receivedValue, int digits) {
        Double receivedDoubleValue = Double.parseDouble(receivedValue);
        StringBuffer sb = new StringBuffer();
        sb.append("#");
        if(digits != 0){
        	sb.append(".");
            for(int i=0;i<digits;i++){
            	sb.append("0");
            }
        }
        DecimalFormat df = new DecimalFormat(sb.toString());
        df.setRoundingMode(RoundingMode.DOWN);
        String formattedValue = df.format(receivedDoubleValue);
        return formattedValue;
    }
	
	/**
	 * Checks for null and empty for a given list of String
	 * 
	 * @param listObject
	 * @return True or False
	 */
	public static Boolean checkNullAndEmptyForAList(List<String> listObject) throws MemberPayException
	{
		try
		{
			if (listObject != null && listObject.size() > DEAFULT_LIST_SIZE)
			{
				for (String value : listObject)
				{
					if (StringUtils.isBlank(value) || "null".equals(value))
					{
						return Boolean.FALSE;
					}
				}
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new MemberPayException("E", "9000", TECHINICAL_ERROR_MSG, 500);//need to confirm
		}
	}
}
