package com.wgs.payment.bo;

import java.io.Serializable;


public class Message implements Serializable
{

	private static final long serialVersionUID = -4575969139083458829L;

	private int messageCode;

	private String messageText;

	public void setMessageCode(int messageCode)
	{
		this.messageCode = messageCode;
	}

	public int getMessageCode()
	{
		return messageCode;
	}

	public void setMessageText(String messageText)
	{
		this.messageText = messageText;
	}

	public String getMessageText()
	{
		return messageText;
	}
}
