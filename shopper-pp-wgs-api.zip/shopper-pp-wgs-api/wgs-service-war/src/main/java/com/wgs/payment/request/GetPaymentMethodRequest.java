package com.wgs.payment.request;

import java.util.List;

public class GetPaymentMethodRequest extends BaseRequest {

	private static final long serialVersionUID = -8259955797943904092L;	
	
	private List<String> hcids;
	
	public List<String> getHcids()
	{
		return hcids;
	}
	public void setHcids(List<String> hcids)
	{
		this.hcids = hcids;
	}

}
