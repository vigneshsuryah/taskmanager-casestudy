package com.wgs.payment.bo;

public enum MemberPayAcctTypeEnum
{

	NONE,

	PERSONALCHECKING,

	PERSONALSAVINGS,

	BUSCHECKING,

	BUSSAVINGS,

	//VISA,

	//MASTERCARD;

}