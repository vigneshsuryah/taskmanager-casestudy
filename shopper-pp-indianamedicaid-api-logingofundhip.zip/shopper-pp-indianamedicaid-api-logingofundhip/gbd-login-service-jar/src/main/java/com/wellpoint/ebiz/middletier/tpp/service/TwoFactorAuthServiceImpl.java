/**
 * TwoFactorAuthServiceImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.constants.GbdUtil;
import com.wellpoint.ebiz.middletier.tpp.dao.LoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.dao.TPCLoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.dao.TransLogDAO;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.ebiz.middletier.tpp.utils.SOAServicesConsumer;
import com.wellpoint.ebiz.middletier.tpp.utils.SiteMinderLoginResponse;
import com.wellpoint.ebiz.middletier.tpp.utils.SiteMinderUtils;
import com.wellpoint.middletier.gbd.soa.gateway.bo.Exceptions;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetAttemptsRemainingResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.RepositoryEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.RequestContext;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SaveDFPRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SaveDFPResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserFilter;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SendOtpRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SendOtpResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SoaHeaders;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThreadApiRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThreadApiResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UpdateUserProfileRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UpdateUserProfileResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.User;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UserRoleEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateOtpRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateOtpResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.LoginRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SaveDFPRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SendOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ThreadApiRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateUserDetailsRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetAttemptsRemainingRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.LoginResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SaveDFPRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SendOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ThreadApiRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateAuthFlagRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateUserProfileRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateUserDetailsResponse;

@Component("twoFactorAuthServiceImpl")
public class TwoFactorAuthServiceImpl implements TwoFactorAuthService, GbdSOAConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(TwoFactorAuthServiceImpl.class);

	@Autowired
	private SOAServicesConsumer sOAServicesConsumer;
	
	@Autowired
	private SiteMinderUtils siteMinderUtils;
	
	@Autowired
	private LoginServiceDao loginServiceDaoImpl;
	
	@Autowired
	private TPCLoginServiceDao tpcLoginServiceDaoImpl;
	
	@Autowired
	private TransLogDAO transLogDAO;

	/***
	 * This method is used to send OTP using SOA service
	 * @param SendOtpRequestVO
	 * @return SendOtpResponseVO
	 */
	@Override
	public SendOtpRestResponse sendOtp(SendOtpRestRequest request, SoaHeaders soaHeaders) throws GbdException {
		SendOtpRestResponse sendOtpRestResponse = new SendOtpRestResponse();
		try {
			SendOtpRequestVO sendOtpRequestVO = new SendOtpRequestVO();
			/*sendOtpRequestVO.setTransientUserNm(request.getTransientUserNm());*/
			sendOtpRequestVO.setChannel(request.getChannel());
			sendOtpRequestVO.setRecoveryContact(request.getRecoveryContact());
			SendOtpResponseVO sendOtpResponseVO = sOAServicesConsumer.sendOtp(sendOtpRequestVO, soaHeaders);
			if(null != sendOtpResponseVO) {
				sendOtpRestResponse.setSecureAuthResponse(sendOtpResponseVO.getSecureAuthResponse());
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in SOAServiceEndpointServiceImpl sendOtp : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return sendOtpRestResponse;
	}
	
	/***
	 * This method is used to send OTP using SOA service
	 * @param SendOtpRequestVO
	 * @return SendOtpResponseVO
	 */
	@Override
	public ValidateOtpRestResponse validateOtp(ValidateOtpRestRequest request, SoaHeaders soaHeaders) throws GbdException {
		ValidateOtpRestResponse validateOtpRestResponse = new ValidateOtpRestResponse();
		try {
			ValidateOtpRequestVO validateOtpRequestVO = new ValidateOtpRequestVO();
			validateOtpRequestVO.setTransientUserNm(request.getTransientUserNm());
			validateOtpRequestVO.setOtp(request.getOtp());
			validateOtpRequestVO.setDuration(GbdUtil.getStringProperty("gbd.2fa.validate.opt.duration",""));
			ValidateOtpResponseVO validateOtpResponseVO = sOAServicesConsumer.validateOtp(validateOtpRequestVO, soaHeaders);
			if(null != validateOtpResponseVO) {
				validateOtpRestResponse.setValid(validateOtpResponseVO.getValid());
				validateOtpRestResponse.setFailureReason(validateOtpResponseVO.getFailureReason());
				validateOtpRestResponse.setCount(validateOtpResponseVO.getCount());
				validateOtpRestResponse.setSecureAuthResponse(validateOtpResponseVO.getSecureAuthResponse());
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in SOAServiceEndpointServiceImpl validateOtp : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return validateOtpRestResponse;
	}

	/***
	 * This method is used to invoke thread api SOA service
	 * @param ThreadApiRestRequest
	 * @return ThreadApiRestResponse
	 */
	@Override
	public ThreadApiRestResponse threatapi(ThreadApiRestRequest request, SoaHeaders soaHeaders) throws GbdException {
		ThreadApiRestResponse threadApiRestResponse = new ThreadApiRestResponse();
		try {
			ThreadApiRequestVO threadApiRequestVO = new ThreadApiRequestVO();
			threadApiRequestVO.setTransientUserNm(request.getTransientUserNm());
			threadApiRequestVO.setFingerprint(request.getFingerprint());
			ThreadApiResponseVO threadApiResponseVO = sOAServicesConsumer.threatapi(threadApiRequestVO, soaHeaders);
			if(null != threadApiResponseVO && null != threadApiResponseVO.getApiException() && null != threadApiResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = threadApiResponseVO.getApiException().getExceptions();
				threadApiRestResponse.setErrorMessage(exceptions[0].getCode());
			} else if (null != threadApiResponseVO.getStatus() && !threadApiResponseVO.getStatus().isEmpty()) {
				threadApiRestResponse.setStatus(threadApiResponseVO.getStatus());
				threadApiRestResponse.setSuggestedAction(threadApiResponseVO.getSuggestedAction());
				threadApiRestResponse.setSuggestedActionDesc(threadApiResponseVO.getSuggestedActionDesc());
				threadApiRestResponse.setPromptForDeviceUpdate(threadApiResponseVO.getPromptForDeviceUpdate());
				threadApiRestResponse.setFingerprintId(threadApiResponseVO.getFingerprintId());
				threadApiRestResponse.setAudit(threadApiResponseVO.getAudit());
				threadApiRestResponse.setTransientUserNm(threadApiResponseVO.getTransientUserNm());
				threadApiRestResponse.setAccessHistoryStatus(threadApiResponseVO.getAccessHistoryStatus());
			} else {
				threadApiRestResponse.setErrorMessage(UNK_ERROR);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in SOAServiceEndpointServiceImpl threatapi : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return threadApiRestResponse;
	}

	/***
	 * This method is used to save DFP SOA service
	 * @param ThreadApiRestRequest
	 * @return ThreadApiRestResponse
	 */
	@Override
	public SaveDFPRestResponse saveDfp(SaveDFPRestRequest request, SoaHeaders soaHeaders) throws GbdException {
		SaveDFPRestResponse saveDFPRestResponse = new SaveDFPRestResponse();
		try {
			SaveDFPRequestVO saveDFPRequestVO = new SaveDFPRequestVO();
			saveDFPRequestVO.setFingerprint(request.getFingerprint());
			SaveDFPResponseVO saveDFPResponseVO = sOAServicesConsumer.saveDfp(saveDFPRequestVO, soaHeaders);
			if (null != saveDFPResponseVO && null != saveDFPResponseVO.getApiException() && null != saveDFPResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = saveDFPResponseVO.getApiException().getExceptions();
				saveDFPRestResponse.setErrorMessage(exceptions[0].getCode());
			} else if (null != saveDFPResponseVO.getStatus() && !saveDFPResponseVO.getStatus().isEmpty()) {
				saveDFPRestResponse.setStatus(saveDFPResponseVO.getStatus());
			} else {
				saveDFPRestResponse.setErrorMessage(UNK_ERROR);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in SOAServiceEndpointServiceImpl saveDfp : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return saveDFPRestResponse;
	}
	
	/***
	 * This method is used to get the attempts remaining for the OTP using SOA service
	 * @param userName, soaHeaders
	 * @return GetAttemptsRemainingRestResponse
	*/
	@Override
	public GetAttemptsRemainingRestResponse getAttemptsRemaining(SoaHeaders soaHeaders) throws GbdException {
		
		LOGGER.debug("Inside getAttemptsRemaining of TwoFactorAuthServiceImpl - start");
		GetAttemptsRemainingRestResponse response = new GetAttemptsRemainingRestResponse();
		
		try {
			GetAttemptsRemainingResponseVO getAttemptsRemainingResponseVO = sOAServicesConsumer.getAttemptsRemaining(soaHeaders);
			
			if (null != getAttemptsRemainingResponseVO && null != getAttemptsRemainingResponseVO.getApiException() && null != getAttemptsRemainingResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = getAttemptsRemainingResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != getAttemptsRemainingResponseVO.getCount() && !getAttemptsRemainingResponseVO.getCount().isEmpty()) {
				response.setCount(getAttemptsRemainingResponseVO.getCount());
			}else{
				response.setErrorMessage(UNK_ERROR);
			}
			
		}catch (Exception e) {
			LOGGER.error("Exception in getAttemptsRemaining : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.debug("Inside getAttemptsRemaining of TwoFactorAuthServiceImpl - end");
		return response;
		
	}

	/***
	 * This method is used to update the username using SOA service
	 * @param transientUserNm, soaHeaders
	 * @return UpdateUserProfileRestResponse
	*/
	@Override
	public UpdateUserProfileRestResponse updateUserProfile(String transientUserNm, SoaHeaders soaHeaders) throws GbdException {

		LOGGER.debug("Inside updateUserProfile of TwoFactorAuthServiceImpl - start");
		UpdateUserProfileRestResponse response = new UpdateUserProfileRestResponse();
		
		try {
			UpdateUserProfileRequestVO updateUserProfileRequestVO = new UpdateUserProfileRequestVO();
			updateUserProfileRequestVO.setTransientUserNm(transientUserNm);
			UpdateUserProfileResponseVO updateUserProfileResponseVO = sOAServicesConsumer.updateUserProfile(updateUserProfileRequestVO, soaHeaders);
			
			if (null != updateUserProfileResponseVO && null != updateUserProfileResponseVO.getApiException() && null != updateUserProfileResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = updateUserProfileResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != updateUserProfileResponseVO.getStatus() && !updateUserProfileResponseVO.getStatus().isEmpty()) {
				response.setUpdateStatus(updateUserProfileResponseVO.getStatus());
			}else{
				response.setErrorMessage(UNK_ERROR);
			}
			
		}catch (Exception e) {
			LOGGER.error("Exception in updateUserProfile : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.debug("Inside updateUserProfile of TwoFactorAuthServiceImpl - end");
		return response;
	}

	/***
	 * This method is used to update the auth flag in registration table in db
	 * @param LoginRequest
	 * @return UpdateAuthFlagRestResponse
	*/
	@Override
	public UpdateAuthFlagRestResponse updateAuthFlag(LoginRequest request) throws GbdException {

		LOGGER.debug("Inside updateAuthFlag of TwoFactorAuthServiceImpl - start");
		UpdateAuthFlagRestResponse response = new UpdateAuthFlagRestResponse();
		int count = 0;
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				count = tpcLoginServiceDaoImpl.updateAuthFlag(request.getUserName());
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				count = loginServiceDaoImpl.updateAuthFlag(request.getUserName(), GBD_KY);
			}else {
				count = loginServiceDaoImpl.updateAuthFlag(request.getUserName(), GBD_IN);
			}
			if(count > 0){
				response.setUpdateStatus(true);
			}
		}catch (Exception e) {
			LOGGER.error("Exception in updateAuthFlag : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside updateAuthFlag of TwoFactorAuthServiceImpl - end");
		return response;
	}
	
	/**
	 * This method is used validate username and password in site minder and return auth flag from DB
	 * @param LoginRequest
	 * @param LoginResponse
	 */
	@Override
	public LoginResponse loginUser(LoginRequest request) throws GbdException
	{
		LOGGER.debug("Start - loginUser() of TwoFactorAuthServiceImpl");
		LoginResponse loginResponse = new LoginResponse();
		SiteMinderLoginResponse response = siteMinderUtils.authenticateUser(request.getUserName(), request.getPassword(), request.getFccUrl(), request.getTargetUrl());
		try{
			if(null != response){
				loginResponse.setSmErrorCode(response.getSmErrorCode());
				if(null != response && response.isLoginStatus()){
					loginResponse.setLoginSuccess(response.isLoginStatus());
					List<TPPRegistrationDetail> userDetails = null;
					if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
						userDetails = tpcLoginServiceDaoImpl.getTpcUserDetailsFromUserId(request.getUserName());
					}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
						userDetails = loginServiceDaoImpl.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
					}else {
						userDetails = loginServiceDaoImpl.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
					}
					if(null != userDetails && userDetails.size() > 0){
						if("ON".equalsIgnoreCase(userDetails.get(0).getAuthFlag())){
							loginResponse.setAuthFlag(true);
						}				
					}
				}
			}
		}catch(Exception e){
			LOGGER.error("Exception in loginUser() of TwoFactorAuthServiceImpl : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End - loginUser() of TwoFactorAuthServiceImpl");
		return loginResponse;
	}

	/**
	 * This method is used validate whether email id / phone no / user id already exists in DB
	 * @param ValidateUserDetailsRequest
	 * @param ValidateUserDetailsResponse
	 */
	@Override
	public ValidateUserDetailsResponse validateRegisterUserDetails(ValidateUserDetailsRequest request) throws GbdException
	{
		LOGGER.debug("Start - validateRegisterUserDetails() of TwoFactorAuthServiceImpl");
		ValidateUserDetailsResponse response = new ValidateUserDetailsResponse();
		int userIdCount = 0;
		int emailIdCount = 0;
		int phoneNoCount = 0;
		try{
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				userIdCount = tpcLoginServiceDaoImpl.getTpcUserIdUsedCount(request.getUserName());
				emailIdCount = tpcLoginServiceDaoImpl.getTpcEmailIdUsedCount(request.getEmailId());
				phoneNoCount = tpcLoginServiceDaoImpl.getTpcPhoneNoUsedCount(request.getPhoneNo());
			}else if (null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				userIdCount = loginServiceDaoImpl.getUserIdUsedCount(request.getUserName(), GBD_KY);
				emailIdCount = loginServiceDaoImpl.getEmailIdUsedCount(request.getEmailId(), GBD_KY);
				phoneNoCount = loginServiceDaoImpl.getPhoneNoUsedCount(request.getPhoneNo(), GBD_KY);
			} else {
				userIdCount = loginServiceDaoImpl.getUserIdUsedCount(request.getUserName(), GBD_IN);
				emailIdCount = loginServiceDaoImpl.getEmailIdUsedCount(request.getEmailId(), GBD_IN);
				phoneNoCount = loginServiceDaoImpl.getPhoneNoUsedCount(request.getPhoneNo(), GBD_IN);
			}
		}catch(Exception e){
			LOGGER.error("Exception in validateRegisterUserDetails() of TwoFactorAuthServiceImpl : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		if(userIdCount != 0){
			response.setUserNameFound(true);
		}else{
			response.setUserNameFound(callSearchUserSOA(request.getUserName(), request.getRequestingSystem()));
		}
		if(emailIdCount != 0){
			response.setEmailIdFound(true);
		}
		if(phoneNoCount != 0){
			response.setPhoneNoFound(true);
		}
		LOGGER.debug("End - validateRegisterUserDetails() of TwoFactorAuthServiceImpl");
		return response;
	}

	/***
	 * This method is used to get user details from registration table in db
	 * @param SearchUserDetailsRestRequest
	 * @return SearchUserDetailsRestResponse
	*/
	@Override
	public SearchUserDetailsRestResponse getRegisterUserDetails(SearchUserDetailsRestRequest request) throws GbdException {
		LOGGER.debug("Inside getRegisterUserDetails in TwoFactorAuthServiceImpl - start");
		SearchUserDetailsRestResponse response = new SearchUserDetailsRestResponse();
		List<TPPRegistrationDetail> details = null;
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = tpcLoginServiceDaoImpl.getTpcUserDetailsFromUserId(request.getUserName());
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = loginServiceDaoImpl.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
			}else {
				details = loginServiceDaoImpl.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
			}
			if(null != details && details.size() > 0){
				User user = new User();
				user.setUsername(details.get(0).getUserId().trim());
				user.setFirstName(details.get(0).getFirstName().trim());
				user.setLastName(details.get(0).getLastName().trim());
				user.setPhoneNumber(details.get(0).getPhoneNumber().trim());
				user.setEmailAddress(details.get(0).getEmailId().trim());
				user.setOrgName(details.get(0).getOrganizationName().trim());
				user.setOrgType(details.get(0).getOrganizationType().trim());
				if(null!=details.get(0).getAuthFlag() && NEEDS_AUTH.equalsIgnoreCase(details.get(0).getAuthFlag())){
					user.setAuthFlag(Boolean.TRUE);
				}
				response.setUser(user);
			}

		} catch (Exception e) {
			LOGGER.error("Exception getUserDetailsFromUserId db getRegisterUserDetails : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		LOGGER.debug("Inside getRegisterUserDetails in TwoFactorAuthServiceImpl - end");
		return response;
	}
	
	/***
	 * This method is used to log all the REST endpoint request and response in GBD Database.
	 * @param MbrPayTransLog
	 */
	@Async("loggingTaskExecutor")
	public void logRestLogInDB(MbrPayTransLog request) throws GbdException {
		LOGGER.debug("Save Rest Service Calls - start");
		try {
			transLogDAO.saveMemberRSLog(request);			 
		} catch (Exception ex) {
			LOGGER.error("REST Logging : ", ex);
		}
		LOGGER.debug("Save Rest Service Calls - end");		
	}
	
	/**
	 * Call SOA searchUSer service to check whether user exists
	 * @param userName
	 * @param reqSystem
	 * @return
	 */
	private boolean callSearchUserSOA(String userName, String reqSystem){
		LOGGER.debug("Inside callSearchUserSOA in TwoFactorAuthServiceImpl - start");
		boolean userFound = false;
		SearchUserDetailsRequestVO searchUserDetailsRequestVO = new SearchUserDetailsRequestVO();

		SearchUserFilter searchUserFilter = new SearchUserFilter();
		searchUserFilter.setUsername(userName);

		RepositoryEnum[] repositoryEnums = new RepositoryEnum[1];
		repositoryEnums[0] = RepositoryEnum.IAM;
		searchUserFilter.setRepositoryEnum(repositoryEnums);

		UserRoleEnum[] userRoleEnums = new UserRoleEnum[1];
		if(null != reqSystem && TPC_SENDER_APP.equalsIgnoreCase(reqSystem)) {
			userRoleEnums[0] = UserRoleEnum.GOFUNDCOMMERCIAL;
		}else if(null != reqSystem && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSystem)) {
			userRoleEnums[0] = UserRoleEnum.GOFUNDKYHEALTH;
		}else{
			userRoleEnums[0] = UserRoleEnum.GOFUNDHIP;
		}
		searchUserFilter.setUserRoleEnum(userRoleEnums);
		searchUserDetailsRequestVO.setSearchUserFilter(searchUserFilter);

		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid003");
		requestContext.setUsername(userName);

		searchUserDetailsRequestVO.setRequestContext(requestContext);

		try{
			SearchUserDetailsResponseVO searchUserResponse = sOAServicesConsumer.searchUserDetailsSOA(searchUserDetailsRequestVO, reqSystem);
			if (null != searchUserResponse && null != searchUserResponse.getResponseContext()
					&& null != searchUserResponse.getResponseContext().getConfirmationNumber()
					&& !searchUserResponse.getResponseContext().getConfirmationNumber().isEmpty()) {
				userFound = true;
			}
		}catch(Exception e){
			userFound = false;
		}
		LOGGER.debug("Inside callSearchUserSOA in TwoFactorAuthServiceImpl - start");
		return userFound;
	}

}
