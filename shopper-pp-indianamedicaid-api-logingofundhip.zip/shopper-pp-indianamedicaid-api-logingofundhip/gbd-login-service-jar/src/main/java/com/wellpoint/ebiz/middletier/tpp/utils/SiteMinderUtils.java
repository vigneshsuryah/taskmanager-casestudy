/**
* SiteMinderUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/24/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.tpp.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;


@Component
public class SiteMinderUtils implements GbdSOAConstants{

	private static final Logger LOGGER = LoggerFactory.getLogger(SiteMinderUtils.class);

	public SiteMinderLoginResponse authenticateUser(String userName, String password, String fccUrl, String targetUrl) throws GbdException {

		SiteMinderLoginResponse siteMinderResponse = new SiteMinderLoginResponse();
		siteMinderResponse.setLoginStatus(false);
		HttpClient httpClient = null;
		String SM_SESSION = "SMSESSION";

		int defaultMaxConn = 100;
		int maxTotalConn = 100;


		HttpConnectionManagerParams httpCManagerParams = new HttpConnectionManagerParams();
		httpCManagerParams.setDefaultMaxConnectionsPerHost(defaultMaxConn);
		httpCManagerParams.setMaxTotalConnections(maxTotalConn);
		MultiThreadedHttpConnectionManager httpConnectionManager = new MultiThreadedHttpConnectionManager();
		httpConnectionManager.setParams(httpCManagerParams);

		httpClient = new HttpClient(httpConnectionManager);
		httpClient.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		httpClient.getParams().setParameter("http.protocol.single-cookie-header", Boolean.TRUE);

		try
		{
			HttpState state = new HttpState();
			HashMap authenticationInfo = new HashMap();
			authenticationInfo.put("USER",userName);
			authenticationInfo.put("PASSWORD",password);

			NameValuePair[] data = new NameValuePair[authenticationInfo.size() + 1];
			int counter = 0;
			Set set = authenticationInfo.entrySet(); 
			Iterator i = set.iterator(); 
			String Value = null;
			String Key = null;
			while(i.hasNext()) 
			{ 
				Map.Entry me = (Map.Entry)i.next(); 
				Key = (String)me.getKey();
				Value = (String)me.getValue();
				data[counter++] = new NameValuePair(Key,Value);
			}

			data[counter] = new NameValuePair("TARGET", targetUrl);
			PostMethod postMethod = null;
			Cookie[] cookies = null;
			Header[] headers = null;
			try
			{
				postMethod = new PostMethod(fccUrl);
				postMethod.addParameter("http.protocol.single-cookie-header", "TRUE");
				postMethod.setRequestBody(data);
				int responseCode = httpClient.executeMethod(null, postMethod, state);
				LOGGER.debug("Response code : " + responseCode);
				cookies = state.getCookies();
				headers = postMethod.getResponseHeaders();

				/*for(int k=0;k<cookies.length;k++) {
					LOGGER.debug("Cookie " + k + " :" +cookies[k]);
				}
				for(int g=0;g<headers.length;g++) {
					LOGGER.debug("Header " + g + " :" +headers[g]);
				}*/
			} 

			finally
			{
				if(postMethod != null)
				{
					postMethod.releaseConnection();
				}
			}
			
			
			String location = getHeaderValue(headers, "Location");

			String cookieString = getCookieValue(cookies, SM_SESSION);
			int loginStatus = getSiteminderLoginStatus(location);
			siteMinderResponse.setSmErrorCode(Integer.toString(loginStatus));
			
			if (loginStatus == 0 && null != cookieString){
				siteMinderResponse.setLoginStatus(true);
			}

		}catch (Exception e)
		{
			LOGGER.error("Exception in authenticateUser "+e);
			throw new GbdException(ERROR_TYPE,LOGIN_SITEMINDER_ACCESS_ERR,LOGIN_SITEMINDER_ACCESS_ERR_MSG,REST_ERROR_200);
		}

		return siteMinderResponse;
	}


	private String getHeaderValue(Header[] headers, String headerName)
	{
		String headerValue = null;

		Header header = null;
		for (int countheader = 0; countheader < headers.length;countheader++)
		{
			header = headers[countheader];
			if (header.getName().equalsIgnoreCase(headerName))
			{
				headerValue = header.getValue();
				break;
			}
		}
		return headerValue;
	}

	private String getCookieValue(Cookie[] cookies, String cookieName)
	{
		String cookieString = null;
		Cookie cookie = null;
		for (int cookieCounts=0; cookieCounts<cookies.length;cookieCounts++)
		{
			cookie = cookies[cookieCounts];
			String name = cookie.getName();

			if (name.equalsIgnoreCase(cookieName))
			{
				cookieString = cookie.getValue();
				break;
			}
		}
		return cookieString;
	}
	
	private static int getSiteminderLoginStatus(String location)
	{
		if (location == null){
			return 0;
		}
		int index = location.indexOf("sm_error_msg");
		if (index < 0){
			return 0;
		}
		String smAuthReason = "0";
		index = index + 12 + 1;
		location = location.substring(index);
		index = location.indexOf("&");
		if (index > -1) {
			smAuthReason = location.substring(0, index);
		} else {
			smAuthReason = location.substring(0);
		}
		int authreason = Integer.parseInt(smAuthReason);

		return authreason;
	}
}