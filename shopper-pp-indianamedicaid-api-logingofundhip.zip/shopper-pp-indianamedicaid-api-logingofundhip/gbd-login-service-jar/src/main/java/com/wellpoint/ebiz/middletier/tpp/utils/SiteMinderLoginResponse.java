/**
* SiteMinderLoginResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/24/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.tpp.utils;


public class SiteMinderLoginResponse {

	private boolean loginStatus;
	
	private String smErrorCode;

	public boolean isLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(boolean loginStatus) {
		this.loginStatus = loginStatus;
	}

	/**
	 * @return the smErrorCode
	 */
	public String getSmErrorCode()
	{
		return smErrorCode;
	}

	/**
	 * @param smErrorCode the smErrorCode to set
	 */
	public void setSmErrorCode(String smErrorCode)
	{
		this.smErrorCode = smErrorCode;
	}
	
}