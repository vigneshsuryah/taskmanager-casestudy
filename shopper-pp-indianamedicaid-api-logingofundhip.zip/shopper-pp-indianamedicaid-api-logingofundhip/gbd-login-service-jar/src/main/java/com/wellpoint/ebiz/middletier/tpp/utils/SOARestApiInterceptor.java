package com.wellpoint.ebiz.middletier.tpp.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.service.SOAServiceEndpointService;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.TPTServicesLog;

@Component("sOARestApiInterceptor")
public class SOARestApiInterceptor implements ClientHttpRequestInterceptor, GbdSOAConstants{

	private final static Logger logger = LoggerFactory.getLogger(SOARestApiInterceptor.class);
	
	@Autowired
	private SOAServiceEndpointService sOAServiceEndpointServiceImpl;
	
	
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
		logger.debug("Inside ClientHttpResponse intercept");
		TPTServicesLog logData = new TPTServicesLog();
		traceRequest(request, body, logData);
		
		ClientHttpResponse response = execution.execute(request, body);
		traceResponse(response, logData);

		try {
			sOAServiceEndpointServiceImpl.logTPTRSInDB(logData);
		} catch (GbdException e) {
			logger.debug("Exception in ClientHttpResponse intercept");
		}

		return response;
	}
	
	private void traceRequest(HttpRequest request, byte[] body, TPTServicesLog logData) throws IOException {
		/*logger.info("===========================request begin================================================");
		logger.info("URI : " + request.getURI());
		logger.info("Method : " + request.getMethod());
		logger.info("Header : " + mapper.writeValueAsString(request.getHeaders()));
		logger.info("Request Body : " + new String(body, "UTF-8"));
*/
		List<String> userId = request.getHeaders().get(USER_ID);
		request.getHeaders().remove(USER_ID);
		List<String> requestingSystem = request.getHeaders().get(REQUESTING_SYSTEM);
		request.getHeaders().remove(REQUESTING_SYSTEM);
		List<String> outOperation = request.getHeaders().get(OPERATION_NAME);
		request.getHeaders().remove(OPERATION_NAME);

		logData.setOperationName(outOperation.get(0));
		logData.setHcid(userId.get(0));
		logData.setSbrUid(userId.get(0));
		logData.setRequestXml("Headers: " + request.getHeaders().toString() + " Request body: " + new String(body, "UTF-8"));
		logData.setRequestTs(Calendar.getInstance().getTime());
		logData.setRequestingSystem(requestingSystem.get(0));
		/*logger.info("==========================request end================================================");*/
	}
	
	private void traceResponse(ClientHttpResponse response, TPTServicesLog logData) throws IOException {
		/*logger.info("============================response begin==========================================");*/
		logData.setResponseTs(Calendar.getInstance().getTime());

		StringBuilder inputStringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;
		try {

			bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), "UTF-8"));
			String line = bufferedReader.readLine();
			while (line != null) {
				inputStringBuilder.append(line);
				inputStringBuilder.append('\n');
				line = bufferedReader.readLine();
			}
			if (response.getStatusCode() == HttpStatus.OK) {
				logData.setResponseXml(inputStringBuilder.toString());
			} else {
				logData.setResponseXml("Code:" + response.getStatusCode() + ":" + inputStringBuilder.toString());

			}
		} catch (Exception e) {
			logger.error("Exception while logging response:" + e);
			logData.setResponseXml("Code:" + response.getStatusCode() + ":" + response.getStatusText());
		}

		
		/*logger.info("status code: " + response.getStatusCode());
		logger.info("status text: " + response.getStatusText());
		logger.info("Response Body : " + inputStringBuilder.toString());
		logger.info("=======================response end=================================================");*/
	}
	
}
