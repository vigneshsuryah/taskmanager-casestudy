/**
 * SOAServicesConsumer.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.xstream.XStream;
import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.constants.GbdUtil;
import com.wellpoint.middletier.gbd.soa.gateway.bo.APIExceptions;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AccessHistoryRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AccessHistoryResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AuthenticateUserRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AuthenticateUserResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ChangePasswordRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ChangePasswordResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.CreateRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.CreateResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.DeleteUserAccountRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.DeleteUserAccountResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GeneratePasswordRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GeneratePasswordResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetAttemptsRemainingResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetSecretQuestionsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetSecretQuestionsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyUserDetailsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyUserDetailsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SaveDFPRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SaveDFPResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SendOtpRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SendOtpResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SoaHeaders;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThreadApiRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThreadApiResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UpdateUserProfileRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UpdateUserProfileResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateOtpRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateOtpResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateSecretAnswerRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateSecretAnswerResponseVO;

/**
 * This class consumes list of SOA services needed for GBD TPP Register Module
 * @author CTS
 */
@Component("sOAServicesConsumer")
public class SOAServicesConsumer implements GbdSOAConstants{

	/*@Autowired
	private RestTemplate restTemplate;*/

	@Autowired
	private SOARestApiInterceptor sOARestApiInterceptor;
	
	XStream xstream = new XStream();

	private static final Logger LOGGER = LoggerFactory.getLogger(SOAServicesConsumer.class);

	public String getSecureRestPath() {
		return GbdUtil.getStringProperty("gbd.setting.soa.rest.service.endpoint","");
	}

	private static ClientHttpRequestFactory clientHttpRequestFactory() {
		LOGGER.info("Inside SOARestApiInterceptor-->clientHttpRequestFactory");
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setReadTimeout(180000);
		factory.setConnectTimeout(6000000);
		ClientHttpRequestFactory requestFactory = new BufferingClientHttpRequestFactory(factory);
		LOGGER.info("End SOARestApiInterceptor-->clientHttpRequestFactory");
		return requestFactory;
	}

	@SuppressWarnings("deprecation")
	public RestTemplate getRestTemplate() {
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		
		MappingJacksonHttpMessageConverter jsonConverter = new MappingJacksonHttpMessageConverter();
		jsonConverter.setSupportedMediaTypes(MediaType.parseMediaTypes("application/json"));
		ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	    jsonConverter.setObjectMapper(objectMapper);
	    
	    List<HttpMessageConverter<?>> list = restTemplate.getMessageConverters();
	    list.add(jsonConverter);
	    restTemplate.setMessageConverters(list);
	    
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>(1);
		clientHttpRequestInterceptors.add(sOARestApiInterceptor);
		restTemplate.setInterceptors(clientHttpRequestInterceptors);
		return restTemplate;
	}
	
	/**
	 * This method is used to create a new user account using SOA service
	 * @param createRequestVO
	 * @return
	 * @throws GbdException
	 */
	public CreateResponseVO createUserRegisterSOA(CreateRequestVO createRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of createUserRegisterSOA of SOAServicesConsumer");
		CreateResponseVO createResponseVO = new CreateResponseVO();

		try{
			HttpEntity<CreateRequestVO> requestEntity = new HttpEntity<CreateRequestVO>(createRequestVO,setSOAServiceHeaders(createRequestVO.getRequestContext().getUsername(),"createUser", reqSys));
			createResponseVO = getRestTemplate().postForObject(getSecureRestPath()+"v1/webusers",requestEntity, CreateResponseVO.class);
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			createResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			createResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of createUserRegisterSOA of SOAServicesConsumer");
		return createResponseVO;
	}

	/**
	 * This method is used to set HTTP headers needed for consuming SOA services
	 * @return
	 */
	private HttpHeaders setSOAServiceHeaders(String userId, String operationName, String requestingSystem){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add(API_KEY, GbdUtil.getStringProperty("gbd.setting.soa.rest.service.apikey",""));
		if(null != userId){
		   headers.add(USER_ID,userId);
		}else{
		   headers.add(USER_ID,"NO_USERID");
		}
		headers.add(OPERATION_NAME,operationName);
		headers.add(REQUESTING_SYSTEM,requestingSystem);
		return headers;
	}

	/**
	 * This method is used to convert exception received from SOA service to API Exception
	 * @param bodyString
	 * @return
	 * @throws GbdException
	 */
	private APIExceptions convertSOAExceptionsToGbd(String bodyString) throws GbdException{
		ObjectMapper mapper = new ObjectMapper();
		APIExceptions exceptionObject = new APIExceptions();
		try {
			exceptionObject = mapper.readValue(bodyString, APIExceptions.class);
		} catch (JsonParseException e) {
			LOGGER.debug("JsonParseException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (JsonMappingException e) {
			LOGGER.debug("JsonMappingException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (IOException e) {
			LOGGER.debug("IOException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return exceptionObject;
	}

	/**
	 * This method is used to delete an user account using SOA service
	 * @param deleteUserAccountRequestVO
	 * @return
	 * @throws GbdException
	 */
	public DeleteUserAccountResponseVO deleteUserAccountSOA(DeleteUserAccountRequestVO deleteUserAccountRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of deleteUserAccountSOA of SOAServicesConsumer");
		DeleteUserAccountResponseVO deleteUserAccountResponseVO = new DeleteUserAccountResponseVO();

		try{
			HttpEntity<DeleteUserAccountRequestVO> requestEntity = new HttpEntity<DeleteUserAccountRequestVO>(deleteUserAccountRequestVO,setSOAServiceHeaders(deleteUserAccountRequestVO.getRequestContext().getUsername(),"deleteUser", reqSys));	
			deleteUserAccountResponseVO = getRestTemplate().postForObject(getSecureRestPath()+"v1/webusers/delete",requestEntity, DeleteUserAccountResponseVO.class);
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			deleteUserAccountResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			deleteUserAccountResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of deleteUserAccountSOA of SOAServicesConsumer");
		return deleteUserAccountResponseVO;
	}
	
	/**
	 * This method is used to search user details using SOA service
	 * @param searchUserDetailsRequestVO
	 * @return
	 * @throws GbdException
	 */
	public SearchUserDetailsResponseVO searchUserDetailsSOA(SearchUserDetailsRequestVO searchUserDetailsRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of searchUserDetailsSOA of SOAServicesConsumer");
		SearchUserDetailsResponseVO searchUserDetailsResponseVO = new SearchUserDetailsResponseVO();

		try{
			HttpEntity<SearchUserDetailsRequestVO> requestEntity = new HttpEntity<SearchUserDetailsRequestVO>(searchUserDetailsRequestVO,setSOAServiceHeaders(searchUserDetailsRequestVO.getRequestContext().getUsername(),"searchUser", reqSys));
			HttpEntity<SearchUserDetailsResponseVO> responseEntity = new HttpEntity<SearchUserDetailsResponseVO>(searchUserDetailsResponseVO);
			responseEntity = getRestTemplate().exchange(getSecureRestPath()+"v1/webusers/search", HttpMethod.POST, requestEntity, SearchUserDetailsResponseVO.class);
			if (responseEntity != null) {
				searchUserDetailsResponseVO = responseEntity.getBody();
			}
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			searchUserDetailsResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			searchUserDetailsResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of searchUserDetailsSOA of SOAServicesConsumer");
		return searchUserDetailsResponseVO;
	}
	
	/**
	 * This method is used to authenticate user using SOA service
	 * @param authenticateUserRequestVO
	 * @return
	 * @throws GbdException
	 */
	public AuthenticateUserResponseVO authenticateUserSOA(AuthenticateUserRequestVO authenticateUserRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of authenticateUserSOA of SOAServicesConsumer");
		AuthenticateUserResponseVO authenticateUserResponseVO = new AuthenticateUserResponseVO();

		try{
			HttpEntity<AuthenticateUserRequestVO> requestEntity = new HttpEntity<AuthenticateUserRequestVO>(authenticateUserRequestVO,setSOAServiceHeaders(authenticateUserRequestVO.getRequestContext().getUsername(),"authenticateUser", reqSys));	
			authenticateUserResponseVO = getRestTemplate().postForObject(getSecureRestPath()+"v1/webusers/authenticate",requestEntity, AuthenticateUserResponseVO.class);
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			authenticateUserResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			authenticateUserResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of authenticateUserSOA of SOAServicesConsumer");
		return authenticateUserResponseVO;
	}
	
	/**
	 * This method is used to modify user details using SOA service
	 * @param modifyUserDetailsRequestVO
	 * @return
	 * @throws GbdException
	 */
	public ModifyUserDetailsResponseVO modifyUserDetailsSOA(ModifyUserDetailsRequestVO modifyUserDetailsRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of modifyUserDetailsSOA of SOAServicesConsumer");
		ModifyUserDetailsResponseVO modifyUserDetailsResponseVO = new ModifyUserDetailsResponseVO();
         
		try{
			HttpEntity<ModifyUserDetailsRequestVO> requestEntity = new HttpEntity<ModifyUserDetailsRequestVO>(modifyUserDetailsRequestVO,setSOAServiceHeaders(modifyUserDetailsRequestVO.getRequestContext().getUsername(),"modifyUser", reqSys));	
			ResponseEntity<ModifyUserDetailsResponseVO> response = getRestTemplate().exchange(getSecureRestPath()+"v1/webusers", HttpMethod.PUT, requestEntity, ModifyUserDetailsResponseVO.class);
			modifyUserDetailsResponseVO = response.getBody();
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			modifyUserDetailsResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			modifyUserDetailsResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of modifyUserDetailsSOA of SOAServicesConsumer");
		return modifyUserDetailsResponseVO;
	}
	
	/**
	 * This method is used to get secret questions for the user using SOA service
	 * @param getSecretQuestionsRequestVO
	 * @return
	 * @throws GbdException
	 */
	public GetSecretQuestionsResponseVO getSecretQuestionsSOA(GetSecretQuestionsRequestVO getSecretQuestionsRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of getSecretQuestionsSOA of SOAServicesConsumer");
		GetSecretQuestionsResponseVO getSecretQuestionsResponseVO = new GetSecretQuestionsResponseVO();

		try{
			HttpEntity<GetSecretQuestionsRequestVO> requestEntity = new HttpEntity<GetSecretQuestionsRequestVO>(getSecretQuestionsRequestVO,setSOAServiceHeaders(getSecretQuestionsRequestVO.getRequestContext().getUsername(),"getSecurityQuestions", reqSys));	
			ResponseEntity<GetSecretQuestionsResponseVO> response = getRestTemplate().exchange(getSecureRestPath()+"v1/webusers/secretquestions", HttpMethod.GET, requestEntity, GetSecretQuestionsResponseVO.class);
			getSecretQuestionsResponseVO = response.getBody();
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			getSecretQuestionsResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			getSecretQuestionsResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of getSecretQuestionsSOA of SOAServicesConsumer");
		return getSecretQuestionsResponseVO;
	}
	
	/**
	 * This method is used to validate secret answers for the user using SOA service
	 * @param validateSecretAnswerRequestVO
	 * @return
	 * @throws GbdException
	 */
	public ValidateSecretAnswerResponseVO validateSecretAnswersSOA(ValidateSecretAnswerRequestVO validateSecretAnswerRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of validateSecretAnswersSOA of SOAServicesConsumer");
		ValidateSecretAnswerResponseVO validateSecretAnswerResponseVO = new ValidateSecretAnswerResponseVO();

		try{
			HttpEntity<ValidateSecretAnswerRequestVO> requestEntity = new HttpEntity<ValidateSecretAnswerRequestVO>(validateSecretAnswerRequestVO,setSOAServiceHeaders(validateSecretAnswerRequestVO.getRequestContext().getUsername(),"validateSecurityQuestions", reqSys));	
			validateSecretAnswerResponseVO = getRestTemplate().postForObject(getSecureRestPath()+"v1/webusers/secretanswers/validate",requestEntity, ValidateSecretAnswerResponseVO.class);
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			validateSecretAnswerResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			validateSecretAnswerResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of validateSecretAnswersSOA of SOAServicesConsumer");
		return validateSecretAnswerResponseVO;
	}
	
	/**
	 * This method is used to change password for the user using SOA service
	 * @param changePasswordRequestVO
	 * @return
	 * @throws GbdException
	 */
	public ChangePasswordResponseVO changePasswordSOA(ChangePasswordRequestVO changePasswordRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of changePasswordSOA of SOAServicesConsumer");
		ChangePasswordResponseVO changePasswordResponseVO = new ChangePasswordResponseVO();

		try{
			HttpEntity<ChangePasswordRequestVO> requestEntity = new HttpEntity<ChangePasswordRequestVO>(changePasswordRequestVO,setSOAServiceHeaders(changePasswordRequestVO.getRequestContext().getUsername(),"changePassword", reqSys));	
			ResponseEntity<ChangePasswordResponseVO> response = getRestTemplate().exchange(getSecureRestPath()+"v1/webusers/password", HttpMethod.PUT, requestEntity, ChangePasswordResponseVO.class);
			changePasswordResponseVO = response.getBody();
			/*LOGGER.debug("changePasswordSOA : " + xstream.toXML(response.getBody()));*/
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			changePasswordResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			changePasswordResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of changePasswordSOA of SOAServicesConsumer");
		return changePasswordResponseVO;
	}
	
	/**
	 * This method is used to generate password for the user using SOA service
	 * @param generatePasswordRequestVO
	 * @return
	 * @throws GbdException
	 */
	public GeneratePasswordResponseVO generatePasswordSOA(GeneratePasswordRequestVO generatePasswordRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("Start of generatePasswordSOA of SOAServicesConsumer");
		GeneratePasswordResponseVO generatePasswordResponseVO = new GeneratePasswordResponseVO();

		try{
			HttpEntity<GeneratePasswordRequestVO> requestEntity = new HttpEntity<GeneratePasswordRequestVO>(generatePasswordRequestVO,setSOAServiceHeaders(generatePasswordRequestVO.getRequestContext().getUsername(),"generatePassword", reqSys));	
			generatePasswordResponseVO = getRestTemplate().postForObject(getSecureRestPath()+"v1/webusers/password/generate",requestEntity, GeneratePasswordResponseVO.class);
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			generatePasswordResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			generatePasswordResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.debug("exception : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End of generatePasswordSOA of SOAServicesConsumer");
		return generatePasswordResponseVO;
	}

	//Added By Cognizant for 2FA Nov 2018 release - Start
	/**
	 * This method is used to invoke threadapi SOA service based on module
	 * @param threadApiRequestVO
	 * @return
	 * @throws GbdException
	 */
	public ThreadApiResponseVO threatapi(ThreadApiRequestVO threadApiRequestVO, SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer threatapi - Start");
		ThreadApiResponseVO threadApiResponseVO = new ThreadApiResponseVO();
		String soaEndpoint = "";
		try {
			if(null != soaHeaders && null != soaHeaders.getModule() && !soaHeaders.getModule().isEmpty()) {
				if(soaHeaders.getModule().equalsIgnoreCase("register")) {
					soaEndpoint = SOA_REGISTER_THREATAPI_URL;
				} else if(soaHeaders.getModule().equalsIgnoreCase("login")) {
					soaEndpoint = SOA_LOGIN_THREATAPI_URL;
				} else if(soaHeaders.getModule().equalsIgnoreCase("recovery")) {
					soaEndpoint = SOA_RECOVERY_THREATAPI_URL;
				}
			}
			HttpEntity<ThreadApiRequestVO> requestEntity = new HttpEntity<ThreadApiRequestVO>(threadApiRequestVO, 
					setSOA2FAServiceHeaders(soaHeaders.getModule()+"threatapi", soaHeaders));
			threadApiResponseVO = getRestTemplate().postForObject(getSecureRestPath() + soaEndpoint, requestEntity, ThreadApiResponseVO.class);
			
			//invoke access history
			try {
				if(checkModuleForAccessHistory(soaHeaders.getModule())) {
					AccessHistoryRequestVO accessHistoryRequestVO = new AccessHistoryRequestVO();
					AccessHistoryResponseVO accessHistoryResponseVO = new AccessHistoryResponseVO();
					
					accessHistoryRequestVO.setIp_address(soaHeaders.getIpaddress());
					accessHistoryRequestVO.setType("risk");
					HttpEntity<AccessHistoryRequestVO> accHisRequestEntity = new HttpEntity<AccessHistoryRequestVO>(accessHistoryRequestVO, 
							setSOAAccHisServiceHeaders(soaHeaders.getModule()+"accessHistory", soaHeaders));
					accessHistoryResponseVO = getRestTemplate().postForObject(getSecureRestPath() + ACCESS_HISTORY_SOA, accHisRequestEntity, AccessHistoryResponseVO.class);
					if(null != accessHistoryResponseVO) {
						threadApiResponseVO.setAccessHistoryStatus(accessHistoryResponseVO.getStatus());
					}
				}
			} catch(HttpClientErrorException httpClientErrorException){
				LOGGER.debug("HttpClientErrorException in SOAServicesConsumer threatapi accessHistory : " + httpClientErrorException.getResponseBodyAsString());
			} catch(HttpServerErrorException httpServerErrorException){
				LOGGER.debug("HttpServerErrorException in SOAServicesConsumer threatapi accessHistory : " + httpServerErrorException.getResponseBodyAsString());
			} catch(Exception exception){
				LOGGER.debug("Exception in SOAServicesConsumer threatapi accessHistory : " + exception.getCause());
			}
		} catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("HttpClientErrorException in SOAServicesConsumer threatapi : " + httpClientErrorException.getResponseBodyAsString());
			threadApiResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		} catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("HttpServerErrorException in SOAServicesConsumer threatapi : " + httpServerErrorException.getResponseBodyAsString());
			threadApiResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		} catch(Exception exception){
			LOGGER.debug("Exception in SOAServicesConsumer threatapi : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer threatapi - End");
		return threadApiResponseVO;
	}
	
	/**
	 * This method is used to invoke saveDfp of SOA service
	 * @param saveDFPRequestVO
	 * @return
	 * @throws GbdException
	 */
	public SaveDFPResponseVO saveDfp(SaveDFPRequestVO saveDFPRequestVO, SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer saveDfp - Start");
		SaveDFPResponseVO saveDFPResponseVO = new SaveDFPResponseVO();
		try {
			HttpEntity<SaveDFPRequestVO> requestEntity = new HttpEntity<SaveDFPRequestVO>(saveDFPRequestVO, 
					setSOA2FAServiceHeaders("saveDfp", soaHeaders));
			saveDFPResponseVO = getRestTemplate().postForObject(getSecureRestPath() + SOA_SAVE_DFP_URL, requestEntity, SaveDFPResponseVO.class);
		} catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("HttpClientErrorException in SOAServicesConsumer saveDfp : " + httpClientErrorException.getResponseBodyAsString());
			saveDFPResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		} catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("HttpServerErrorException in SOAServicesConsumer saveDfp : " + httpServerErrorException.getResponseBodyAsString());
			saveDFPResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		} catch(Exception exception){
			LOGGER.debug("Exception in SOAServicesConsumer saveDfp : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer saveDfp - End");
		return saveDFPResponseVO;
	}

	/**
	 * This method is used to invoke sendotp SOA service based on module
	 * @param sendOtpRequestVO
	 * @return
	 * @throws GbdException
	 */
	public SendOtpResponseVO sendOtp(SendOtpRequestVO sendOtpRequestVO, SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer sendOtp - Start");
		SendOtpResponseVO sendOtpResponseVO = new SendOtpResponseVO();
		try {
			HttpEntity<SendOtpRequestVO> requestEntity = new HttpEntity<SendOtpRequestVO>(sendOtpRequestVO, 
					setSOA2FAServiceHeaders("sendOtp", soaHeaders));
			sendOtpResponseVO = getRestTemplate().postForObject(getSecureRestPath() + SEND_OTP_SOA, requestEntity, SendOtpResponseVO.class);
		} catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("HttpClientErrorException in SOAServicesConsumer threatapi : " + httpClientErrorException.getResponseBodyAsString());
			sendOtpResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		} catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("HttpServerErrorException in SOAServicesConsumer threatapi : " + httpServerErrorException.getResponseBodyAsString());
			sendOtpResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		} catch(Exception exception){
			LOGGER.debug("Exception in SOAServicesConsumer sendOtp : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer sendOtp - End");
		return sendOtpResponseVO;
	}
	
	/**
	 * This method is used to invoke validateotp SOA service based on module
	 * @param validateOtpRequestVO
	 * @return
	 * @throws GbdException
	 */
	public ValidateOtpResponseVO validateOtp(ValidateOtpRequestVO validateOtpRequestVO, SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer validateOtp - Start");
		ValidateOtpResponseVO validateOtpResponseVO = new ValidateOtpResponseVO();
		try {
			HttpEntity<ValidateOtpRequestVO> requestEntity = new HttpEntity<ValidateOtpRequestVO>(validateOtpRequestVO, 
					setSOA2FAServiceHeaders("validateOtp", soaHeaders));
			validateOtpResponseVO = getRestTemplate().postForObject(getSecureRestPath() + VALIDATE_OTP_SOA, requestEntity, ValidateOtpResponseVO.class);
		} catch(HttpClientErrorException httpClientErrorException){
			LOGGER.debug("HttpClientErrorException in SOAServicesConsumer validateOtp : " + httpClientErrorException.getResponseBodyAsString());
			validateOtpResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		} catch(HttpServerErrorException httpServerErrorException){
			LOGGER.debug("HttpServerErrorException in SOAServicesConsumer validateOtp : " + httpServerErrorException.getResponseBodyAsString());
			validateOtpResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		} catch(Exception exception){
			LOGGER.debug("Exception in SOAServicesConsumer sendOtp : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer sendOtp - End");
		return validateOtpResponseVO;
	}

	/**
	 * This method is used to get the number of attempts remaining for the user using SOA service
	 * @param getAttemptsRemainingRequestVO
	 * @return GetAttemptsRemainingResponseVO
	 * @throws GbdException
	 */
	public GetAttemptsRemainingResponseVO getAttemptsRemaining(SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer getAttemptsRemainingSOA - Start");
		GetAttemptsRemainingResponseVO getAttemptsRemainingResponseVO = new GetAttemptsRemainingResponseVO();
		String contextPath = "v1/pp/multifactorauthentication/";
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(setSOA2FAServiceHeaders("attemptsRemaining", soaHeaders));	
			ResponseEntity<GetAttemptsRemainingResponseVO> response = getRestTemplate().exchange(getSecureRestPath()+contextPath+"otp/attemptsremaining", HttpMethod.GET, requestEntity, GetAttemptsRemainingResponseVO.class);
			getAttemptsRemainingResponseVO = response.getBody();
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.error("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			getAttemptsRemainingResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.error("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			getAttemptsRemainingResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.error("Exception in SOAServicesConsumer getAttemptsRemainingSOA : " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer getAttemptsRemainingSOA - End");
		return getAttemptsRemainingResponseVO;
	}
	
	/**
	 * This method is used to update the username using SOA service
	 * @param updateUserProfileRequestVO
	 * @return UpdateUserProfileResponseVO
	 * @throws GbdException
	 */
	public UpdateUserProfileResponseVO updateUserProfile(UpdateUserProfileRequestVO updateUserProfileRequestVO, SoaHeaders soaHeaders) throws GbdException{
		LOGGER.debug("Inside SOAServicesConsumer updateUserProfile - Start");
		UpdateUserProfileResponseVO updateUserProfileResponseVO = new UpdateUserProfileResponseVO();
		String contextPath = "v1/pp/multifactorauthentication/";
		try{
			HttpEntity<UpdateUserProfileRequestVO> requestEntity = new HttpEntity<UpdateUserProfileRequestVO>(updateUserProfileRequestVO, setSOA2FAServiceHeaders("updateUserProfile", soaHeaders));	
			ResponseEntity<UpdateUserProfileResponseVO> response = getRestTemplate().exchange(getSecureRestPath()+contextPath+"users/profile", HttpMethod.PUT, requestEntity, UpdateUserProfileResponseVO.class);
			updateUserProfileResponseVO = response.getBody();
		}catch(HttpClientErrorException httpClientErrorException){
			LOGGER.error("httpClientErrorException : " + httpClientErrorException.getResponseBodyAsString());
			updateUserProfileResponseVO.setApiException(convertSOAExceptionsToGbd(httpClientErrorException.getResponseBodyAsString()));
		}catch(HttpServerErrorException httpServerErrorException){
			LOGGER.error("httpServerErrorException : " + httpServerErrorException.getResponseBodyAsString());
			updateUserProfileResponseVO.setApiException(convertSOAExceptionsToGbd(httpServerErrorException.getResponseBodyAsString()));
		}catch(Exception exception){
			LOGGER.error("Exception in SOAServicesConsumer updateUserProfile: " + exception.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside SOAServicesConsumer updateUserProfile - End");
		return updateUserProfileResponseVO;
	}

	/**
	 * This method is used to set HTTP headers needed for consuming SOA services
	 * @return
	 */
	private HttpHeaders setSOA2FAServiceHeaders(String operationName, SoaHeaders soaHeaders){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add(API_KEY, GbdUtil.getStringProperty("gbd.setting.soa.rest.service.apikey",""));
		if(null != soaHeaders.getUsernm()) {
		   headers.add(USER_ID,soaHeaders.getUsernm());
		} else {
		   headers.add(USER_ID,"NO_USERID");
		}
		headers.add(OPERATION_NAME,operationName);
		headers.add(REQUESTING_SYSTEM, soaHeaders.getReqSys());
		
		headers.add(META_TRANSID, GbdUtil.getTransactionId());
		headers.add(META_SENDERAPP, soaHeaders.getSenderapp());
		
		if(operationName != "attemptsRemaining" && operationName != "updateUserProfile" && operationName != "sendOtp" && operationName != "validateOtp"){
			headers.add(META_IPADDRESS, soaHeaders.getIpaddress());
		}
		
		headers.add(USERNM, soaHeaders.getUsernm());
		headers.add(WEBGUID, soaHeaders.getWebguid());
		return headers;
	}
	
	/**
	 * This method is used to set HTTP headers needed for consuming SOA services
	 * @return
	 */
	private HttpHeaders setSOAAccHisServiceHeaders(String operationName, SoaHeaders soaHeaders){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add(API_KEY, GbdUtil.getStringProperty("gbd.setting.soa.rest.service.apikey",""));
		if(null != soaHeaders.getUsernm()) {
		   headers.add(USER_ID,soaHeaders.getUsernm());
		} else {
		   headers.add(USER_ID,"NO_USERID");
		}
		headers.add(OPERATION_NAME,operationName);
		headers.add(REQUESTING_SYSTEM, soaHeaders.getReqSys());
		
		headers.add(META_SENDERAPP, soaHeaders.getSenderapp());
		
		headers.add(USERNM, soaHeaders.getUsernm());
		return headers;
	}
	
	public static boolean checkModuleForAccessHistory(String module)
	{
		boolean flag = false;
		try {
			String allowedModuleString = GbdUtil.getStringProperty("gbd.2fa.access.history", "");
			String[] allowedModulesList = allowedModuleString.split(",");
			if(Arrays.asList(allowedModulesList).contains(module)) {
				flag = true;
			}
		} catch(Exception e){
			LOGGER.error("Exception in SOAServicesConsumer checkModuleForAccessHistory : " + e);
		}
		return flag;
	}
	//Added By Cognizant for 2FA Nov 2018 release - End
}
