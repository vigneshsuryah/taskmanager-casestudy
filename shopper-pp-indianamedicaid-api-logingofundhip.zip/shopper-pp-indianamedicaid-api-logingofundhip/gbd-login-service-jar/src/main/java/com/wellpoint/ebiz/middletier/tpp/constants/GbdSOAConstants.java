/**
 * GbdSOAConstants.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 06/11/2018  3.0		Cognizant	    KYTPP July 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.constants;

public interface GbdSOAConstants {

	public String API_TEXT = "API";
	public String UNK_ERROR = "Unknown Error";
	public String USERNAMEALREADYEXISTS = "USERNAMEALREADYEXISTS";
	public String USERNOTFOUND = "USERNOTFOUND";
	public String EMAILIDALREADYEXISTS = "EMAILIDALREADYEXISTS";
	public String EMAIL_ID = "EMAIL_ID";
	public String NAME = "NAME";
	public String PHONE_NUMBER = "PHONE_NUMBER";
	public String AUTH_FLAG = "AUTH_FLAG";
	
	String ERROR_TYPE = "E";
	int REST_ERROR_200 = 200;
	int REST_ERROR_400 = 400;	
	String TECHNICAL_ERR_CD = "GBD1000";
	String TECHNICAL_ERR_MSG = "Technical Error";
	int REST_ERROR_500 = 500;
	String REQ_PARAM_MSG_ERR_CD = "GBD1002";
	String REQ_PARAM_MSG_ERR_MSG = "One or more of the request parameters are missing/wrong. Please correct the request.";	
	
	String TPP_SENDER_APP = "TPP";
	String EMPTY = "";
	String API_KEY = "apiKey";
	String USER_ID = "userId";
	String OPERATION_NAME = "operationName";
	String REQUESTING_SYSTEM = "requestingSystem";
	
	String ERROR_CODE_9022 = "PP9022";	
	String TECHINICAL_ERROR_MSG_9022 = "One or more of the request parameters are missing/wrong, please correct the request.";
	String EXCEPTION="E";
	String INFORMATION="I";
	
	//Email changes
	String SPACE = " ";
	String FROM_EMAIL_ADDRESS = "noreply@anthem.com";
	String EMAIL_TEMPLATE_ABCBS = "template_abcbs";
	String FOOTER_IMAGE_DARKBLUE = "top-logo-abcbs";
	String EMAIL_CONTENT_USER_FIRSTNAME = "ecUserFirstName";
	String EMAIL_ADDRESS = "emailAddress";
	String USERID = "userId";
	String EMAIL_CONTENT_PARA1 = "ecPara1";
	String EMAIL_CONTENT_PARA2 = "ecPara2";
	String EMAIL_CONTENT_PARA3 = "ecPara3";
	String EMAIL_CONTENT_PARA4 = "ecPara4";
	String EMAIL_TEMPLATE_LOC = "/emailtemplate/";
	String EMAIL_TEMPLATE_SUFFIX = ".vm";
	String UTF_8 = "UTF-8";
	String EMAIL_IMG_LOC = "/emailimages/";
	String EMAIL_IMG_SUFFIX = ".png";
	String EMAIL_MULTI_RELATED = "related";
	String EMAIL_CONTENT_USERNAME_TEXT = "Thanks for visiting the Anthem Third-Party Payment Center. We're happy to provide you with your username as you requested. Here's the username you used when you created your account:";
	String EMAIL_CONTENT_TEMP_PASSWORD_TEXT = "Thanks for visiting the Anthem Third-Party Payment Center. You indicated that you've forgotten your password. Here is a temporary password:";
	String EMAIL_LINK_PWD_TEXT = " and enter your username and this temporary password.";
	String EMAIL_LINK_UN_TEXT = " and enter your username and password.";
	String EMAIL_TYPE = "Application";
	String EMAIL_REQUESTING_SYSTEM="TPP";
	String EMAIL_USERNAME_SUBJECT="Your username";
	String EMAIL_PASSWORD_SUBJECT="Your password";
	String USERDISABLED = "USERDISABLED";
	String EMAIL_DELETE_ACCOUNT_SUBJECT="Account deletion confirmation";
	String DELETE_ACCOUNT_EMAIL_TEMPLATE_ABCBS = "delete_account_template_abcbs";
	

	//Added by Cognizant for TPC change March 2018 release - Start
	String TPC_SENDER_APP = "TPC";
	
	String TPC_EMAIL_TEMPLATE_ABCBS = "tpc_template";
	
	String EMAIL_CONTENT_PARA5 = "ecPara5";
	String EMAIL_CONTENT_PARA6 = "ecPara6";
	String EMAIL_CONTENT_PARA7 = "ecPara7";
	
	String TPC_FOOTER_IMAGE_ABC = "top-logo-abc";
	String TPC_FOOTER_IMAGE_ABCBS = "top-logo-abcbs_tpc";
	String TPC_FOOTER_IMAGE_BCBSGA = "top-logo-bcbsga";
	String TPC_FOOTER_IMAGE_EBC = "top-logo-ebc";
	String TPC_FOOTER_IMAGE_EBCBS = "top-logo-ebcbs";
	
	String TPC_EMAIL_CONTENT_USERNAME_TEXT = "We received a request for your username at the Third Party Payment Center.";
	String TPC_EMAIL_USERNAME_TEXT1 = "Username : ";
	String TPC_EMAIL_USERNAME_TEXT2 = "Do yourself a favor and keep this info somewhere safe. You'll need your username any time you want to";
	String TPC_EMAIL_USERNAME_LINK_TEXT = " log in";
	String TPC_EMAIL_USERNAME_TEXT3 = ".";
	
	String NEEDS_AUTH = "ON";
	String TPC_EMAIL_CONTENT_TEMP_PASSWORD_TEXT = "We received a request for a temporary password at the Third Party Payment Center.";
	String TPC_EMAIL_PASSWORD_TEXT = "Temporary password : ";
	String TPC_EMAIL_PASSWORD_TEXT1 = "Once you";
	String TPC_EMAIL_PASSWORD_LINK_TEXT = " reset your password";
	String TPC_EMAIL_PASSWORD_TEXT2 = ", be sure to update it to something that will be easy for you to remember but hard for others to guess.";
	//Added by Cognizant for TPC change March 2018 release - End
	
	//Added by Cognizant for KY TPP change July 2018 release - Start
	String KY_TPP_SENDER_APP = "KYTPP";
	String GBD_IN = "GBDIN";
	String GBD_KY = "GBDKY";
	
	String KY_TPP_EMAIL_TEMPLATE_ABCBS = "kytpp_email_template";
	
	String KYTPP_EMAIL_CONTENT_TEMP_PASSWORD_TEXT = "Thanks for visiting the Anthem Medicaid Third Party Payment Center. You indicated that you've forgotten your password. Here is a temporary password:";
	String KYTPP_EMAIL_LINK_PWD_TEXT = "and enter your username and this temporary password.";
	String KYTPP_EMAIL_CONTENT_USERNAME_TEXT = "Thanks for visiting the Anthem Medicaid Third Party Payment Center. You asked us to send you your account username. Here's the username you used when you created your account:";
	String KYTPP_EMAIL_LINK_UN_TEXT = "and enter your username and password.";
	String KYTPP_MEDICAID_LOGO = "top-logo-abcbsm";
	//Added by Cognizant for KY TPP change July 2018 release - End
	
	/* GA Re-branding changes - starts */
	String GA_STATE = "GA";
	String GA_RE_BRAND_LAST_DATE = "memberpay.setting.ga.rebrand.allowable.lastdate.mmddyyyy";
	String GA_RE_BRAND_TODAY_DATE_CHANGE = "memberpay.setting.ga.rebrand.today.date.change.mmddyyyy";
	String GA_RE_BRAND_TODAY_DATE_CHANGE_REQUIRED = "memberpay.setting.ga.rebrand.today.date.change.required";
	String TPC_FOOTER_IMAGE_BCBSGA_OLD = "top-logo-bcbsga-old";
	String EMAIL_GA_REBRAND_LOGONAME = "gaReBrandLogoName";
	/* GA Re-branding changes - ends */
	
	//Added By Cognizant for 2FA Nov 2018 release - Start
	String META_SENDERAPP = "meta-senderapp";
	String MODULE = "module";
	String META_IPADDRESS = "meta-ipaddress";
	String USERNM = "usernm";
	String WEBGUID = "webguid";
	String META_TRANSID = "meta-transid";
	String SOA_LOGIN_THREATAPI_URL = "v1/pp/multifactorauthentication/loginthreat";
	String SOA_REGISTER_THREATAPI_URL = "v1/pp/multifactorauthentication/registrationthreat";
	String SOA_RECOVERY_THREATAPI_URL = "v1/pp/multifactorauthentication/recoverythreat";
	String SOA_SAVE_DFP_URL = "v1/pp/multifactorauthentication/dfp/save";
	String SEND_OTP_SOA = "v1/pp/multifactorauthentication/otp/send";
	String VALIDATE_OTP_SOA = "v1/pp/multifactorauthentication/otp/validate";
	String LOGIN_SITEMINDER_ACCESS_ERR = "GBD1022";
	String LOGIN_SITEMINDER_ACCESS_ERR_MSG = "The user name or password you entered isn't correct. Try entering it again.";
	String ACCESS_HISTORY_SOA = "v1/pp/multifactorauthentication/accesshistory";
	//Added By Cognizant for 2FA Nov 2018 release - End
}
