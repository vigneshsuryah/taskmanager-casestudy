/**
* EmailUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 06/16/2017  1.0      Cognizant       Initial Version
* 12/10/2017  1.0      Cognizant       TPC change
*/
package com.wellpoint.ebiz.middletier.tpp.constants;


import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.wellpoint.ebiz.middletier.tpp.dao.TPTServicesLogDao;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThirdPartyEmailLogging;

/**
 * This class is used to send email
 * @author CTS
 *
 */
@Component
public class EmailUtil implements GbdSOAConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtil.class);
	
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private VelocityEngine velocityEngine;
	
	@Autowired
	private TPTServicesLogDao tptServicesLogDaoImpl;
	
	private String emailContent;

	/**
	 * This method is used to construct email parameters and send email
	 * @param details
	 * @throws GbdException
	 */
	public void composeMailParameters(Mail mail, TPPRegistrationDetail details, boolean isPassword, String password, String reqSys) throws GbdException{
		LOGGER.debug("Inside composeMailParameters");
		try{
			sendMail(mail, details, isPassword, password, reqSys);
			logEmail(mail, reqSys);
		}catch(Exception e){
			LOGGER.error("Exception in composeMailParameters: " + e);
		}
	}

	@Async("loggingTaskExecutor")
	private void logEmail(Mail mail, String reqSys)
	{
		LOGGER.info("Start logEmail() of EmailUtil");
		ThirdPartyEmailLogging tppEmailLogging = new ThirdPartyEmailLogging();
		tppEmailLogging.setHcid(mail.getUserId());
		tppEmailLogging.setSbrUID(mail.getUserId());
		tppEmailLogging.setFromId(mail.getMailFrom());
		tppEmailLogging.setToId(mail.getMailTo());
		tppEmailLogging.setSubject(mail.getMailSubject());
		tppEmailLogging.setTemplateId(mail.getTemplateName());
		tppEmailLogging.setSentDate(new Date());
		tppEmailLogging.setDynamicContent(emailContent);
		tppEmailLogging.setMailType(GbdSOAConstants.EMAIL_TYPE);
		tppEmailLogging.setCreatedBy(mail.getUserId());
		tppEmailLogging.setCreatedDate(new Date());
		tppEmailLogging.setRequestingSystem(reqSys);
		
		tptServicesLogDaoImpl.saveEmailLog(tppEmailLogging);
		LOGGER.info("End logEmail() of EmailUtil");
	}

	/**
	 * This method is used to send mail
	 * @param mail
	 * @param details
	 */
	public void sendMail(final Mail mail, final TPPRegistrationDetail details, final boolean isPassword, final String password, final String reqSys) {
		LOGGER.debug("Inside sendMail -- start");
		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator()
		{
			@Override
			public void prepare(MimeMessage mimeMessage) throws MessagingException, IOException, URISyntaxException ,GbdException
			{
				LOGGER.debug("Inside prepare sendMail");
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				constructMessageForMail(mail, message);
				/*start of dynamic data*/
				Map<String, Object> model = new HashMap<String, Object>();
				model.put(EMAIL_ADDRESS, mail.getMailTo());
				constructModelForMail(details, model, isPassword, password, reqSys);

				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, EMAIL_TEMPLATE_LOC + mail.getTemplateName() +EMAIL_TEMPLATE_SUFFIX, UTF_8, model);
				BodyPart messageBodyPart = new MimeBodyPart();
				if(null != text && !text.trim().isEmpty())
				{
					text = text.replace("<%@ page language='java' contentType='text/html; charset=ISO-8859-1' pageEncoding='ISO-8859-1'%>", "");
				}
				messageBodyPart.setContent(text, mail.getContentType()); 
				MimeMultipart multipart = new MimeMultipart(EMAIL_MULTI_RELATED);
				multipart.addBodyPart(messageBodyPart);

				if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
					attachImage(mimeMessage, multipart, TPC_FOOTER_IMAGE_ABC);
					attachImage(mimeMessage, multipart, TPC_FOOTER_IMAGE_ABCBS);
					if(!gaReBranding()) {
						attachImage(mimeMessage, multipart, TPC_FOOTER_IMAGE_BCBSGA_OLD);
					}
					attachImage(mimeMessage, multipart, TPC_FOOTER_IMAGE_EBC);
					attachImage(mimeMessage, multipart, TPC_FOOTER_IMAGE_EBCBS);
				} else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)){
					attachImage(mimeMessage, multipart, KYTPP_MEDICAID_LOGO);
				}else {
					attachImage(mimeMessage, multipart, FOOTER_IMAGE_DARKBLUE);
				}
				emailContent = text;
				/*end of dynamic data*/
				LOGGER.info("End sendMail() of EmailUtil");
			}

			private void constructMessageForMail(final Mail mail,
					MimeMessageHelper message) throws MessagingException {
				message.setFrom(mail.getMailFrom());
				message.setTo(mail.getMailTo());
				message.setSubject(mail.getMailSubject());
			}

			private void constructModelForMail(final TPPRegistrationDetail details,
					Map<String, Object> model, boolean isPassword, String password, String reqSys) {
				model.put(EMAIL_CONTENT_USER_FIRSTNAME, null != details.getFirstName() ? details.getFirstName().trim() : details.getFirstName());
				if(isPassword){
					if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
						model.put(EMAIL_CONTENT_PARA1, TPC_EMAIL_CONTENT_TEMP_PASSWORD_TEXT);
						model.put(EMAIL_CONTENT_PARA2, TPC_EMAIL_PASSWORD_TEXT);
						model.put(EMAIL_CONTENT_PARA3, password);
						model.put(EMAIL_CONTENT_PARA4, TPC_EMAIL_PASSWORD_TEXT1);
						model.put(EMAIL_CONTENT_PARA5, GbdUtil.getStringProperty("gbd.tpc.email.resetpassword.url",""));
						model.put(EMAIL_CONTENT_PARA6, TPC_EMAIL_PASSWORD_LINK_TEXT);
						model.put(EMAIL_CONTENT_PARA7, TPC_EMAIL_PASSWORD_TEXT2);
						if(!gaReBranding()) {
							model.put(EMAIL_GA_REBRAND_LOGONAME, "cid:top-logo-bcbsga-old");
						}
					}else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)) {
						model.put(EMAIL_CONTENT_PARA1, KYTPP_EMAIL_CONTENT_TEMP_PASSWORD_TEXT);
						model.put(EMAIL_CONTENT_PARA2, password);
						model.put(EMAIL_CONTENT_PARA3, GbdUtil.getStringProperty("gbd.kytpp.email.resetpassword.url",""));
						model.put(EMAIL_CONTENT_PARA4, KYTPP_EMAIL_LINK_PWD_TEXT);
					}else {
						model.put(EMAIL_CONTENT_PARA1, EMAIL_CONTENT_TEMP_PASSWORD_TEXT);
						model.put(EMAIL_CONTENT_PARA2, password);
						model.put(EMAIL_CONTENT_PARA3, GbdUtil.getStringProperty("gbd.tpp.email.resetpassword.url",""));
					    model.put(EMAIL_CONTENT_PARA4, EMAIL_LINK_PWD_TEXT);
					}
				} else{
					if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
						model.put(EMAIL_CONTENT_PARA1, TPC_EMAIL_CONTENT_USERNAME_TEXT);
						model.put(EMAIL_CONTENT_PARA2, TPC_EMAIL_USERNAME_TEXT1);
						model.put(EMAIL_CONTENT_PARA3, details.getUserId());
						model.put(EMAIL_CONTENT_PARA4, TPC_EMAIL_USERNAME_TEXT2);
						model.put(EMAIL_CONTENT_PARA5, GbdUtil.getStringProperty("gbd.tpc.email.login.url",""));
						model.put(EMAIL_CONTENT_PARA6, TPC_EMAIL_USERNAME_LINK_TEXT);
						model.put(EMAIL_CONTENT_PARA7, TPC_EMAIL_USERNAME_TEXT3);
						if(!gaReBranding()) {
							model.put(EMAIL_GA_REBRAND_LOGONAME, "cid:top-logo-bcbsga-old");
						}
					}else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)){
						model.put(EMAIL_CONTENT_PARA1, KYTPP_EMAIL_CONTENT_USERNAME_TEXT);
						model.put(EMAIL_CONTENT_PARA2, details.getUserId());
						model.put(EMAIL_CONTENT_PARA3, GbdUtil.getStringProperty("gbd.kytpp.email.login.url",""));
						model.put(EMAIL_CONTENT_PARA4, KYTPP_EMAIL_LINK_UN_TEXT);
					}else {
						model.put(EMAIL_CONTENT_PARA1, EMAIL_CONTENT_USERNAME_TEXT);
						model.put(EMAIL_CONTENT_PARA2, details.getUserId());
						model.put(EMAIL_CONTENT_PARA3, GbdUtil.getStringProperty("gbd.tpp.email.login.url",""));
						model.put(EMAIL_CONTENT_PARA4, EMAIL_LINK_UN_TEXT);
					}
				}
				
			}

			private void attachImage(MimeMessage mimeMessage, MimeMultipart multipart, String image) throws IOException, MessagingException
			{
				LOGGER.debug("Inside attachImage() of EmailUtil");
				MimeBodyPart imagePart = new MimeBodyPart();
				URL url;
				url = this.getClass().getResource(EMAIL_IMG_LOC + image + EMAIL_IMG_SUFFIX);
				String path = url.getPath();
				imagePart.attachFile(path);
				imagePart.setHeader("Content-ID", "<"+image+">");
				imagePart.setDisposition(MimeBodyPart.INLINE);
				multipart.addBodyPart(imagePart);
				mimeMessage.setContent(multipart);
				LOGGER.debug("End attachImage() of EmailUtil");
			}
		};
		this.mailSender.send(mimeMessagePreparator);
	}
	
	/* GA Re-branding changes - starts */
	public boolean gaReBranding() {
		LOGGER.debug("Inside gaReBranding");
		boolean changeBrand = false;
		try
		{
			String gaReBrandLastDateString = GbdUtil.getStringProperty(GA_RE_BRAND_LAST_DATE,"");
			String todayDateChangeString = GbdUtil.getStringProperty(GA_RE_BRAND_TODAY_DATE_CHANGE,"");
			String todayDateChangeRequired = GbdUtil.getStringProperty(GA_RE_BRAND_TODAY_DATE_CHANGE_REQUIRED,"");
			Date gaReBrandLastDate = convertStringToDate(gaReBrandLastDateString, "MM/dd/yyyy");
			Date currentDate = null;
			if(null != todayDateChangeRequired && todayDateChangeRequired.equalsIgnoreCase("Y")) {
				currentDate = convertStringToDate(todayDateChangeString, "MM/dd/yyyy");
			}else {
				currentDate = Calendar.getInstance(Locale.US).getTime();
			}
			if (currentDate.after(gaReBrandLastDate))
			{
				/*Today's date >= 01/01/2019*/
				changeBrand = true;
			}
			LOGGER.debug("Inside gaReBranding changeBrand : " + changeBrand);
		} catch (Exception e)
		{
			LOGGER.debug("Exception in gaReBranding method : " + e.getCause());
		}
		return changeBrand;
	}
	
	public static Date convertStringToDate(String strDate, String format)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
		formatter.setLenient(false);
		Date date = null;
		try
		{
			date = formatter.parse(strDate);
		} catch (ParseException e)
		{
			LOGGER.error("Parse Exception occured while converting string to date" + e);
		}
		return date;
	}
	/* GA Re-branding changes - ends */
	

}
