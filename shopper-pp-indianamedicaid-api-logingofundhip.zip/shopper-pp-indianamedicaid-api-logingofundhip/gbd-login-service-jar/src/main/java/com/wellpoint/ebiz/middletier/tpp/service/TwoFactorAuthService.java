/**
 * TwoFactorAuthService.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.service;

import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SoaHeaders;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.LoginRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SaveDFPRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SendOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ThreadApiRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateUserDetailsRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetAttemptsRemainingRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.LoginResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SaveDFPRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SendOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ThreadApiRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateAuthFlagRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateUserProfileRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateUserDetailsResponse;

public interface TwoFactorAuthService {
	
	SendOtpRestResponse sendOtp(SendOtpRestRequest request, SoaHeaders soaHeaders) throws GbdException;
	ValidateOtpRestResponse validateOtp(ValidateOtpRestRequest request, SoaHeaders soaHeaders) throws GbdException;
	ThreadApiRestResponse threatapi(ThreadApiRestRequest request, SoaHeaders soaHeaders) throws GbdException;
	SaveDFPRestResponse saveDfp(SaveDFPRestRequest request, SoaHeaders soaHeaders) throws GbdException;
	LoginResponse loginUser(LoginRequest request) throws GbdException;
	ValidateUserDetailsResponse validateRegisterUserDetails(ValidateUserDetailsRequest request) throws GbdException;
    GetAttemptsRemainingRestResponse getAttemptsRemaining(SoaHeaders soaHeaders) throws GbdException;
	UpdateUserProfileRestResponse updateUserProfile(String transientUserNm, SoaHeaders soaHeaders) throws GbdException;
	UpdateAuthFlagRestResponse updateAuthFlag(LoginRequest request) throws GbdException;
	SearchUserDetailsRestResponse getRegisterUserDetails(SearchUserDetailsRestRequest request) throws GbdException;
	void logRestLogInDB(MbrPayTransLog request) throws GbdException;
	
}
