/**
 * SOAServiceEndpointServiceImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 11/12/2017  2.0      Cognizant       TPC change March 2018
 * 06/11/2018  3.0		Cognizant	    KYTPP July 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.service;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.thoughtworks.xstream.XStream;
import com.wellpoint.ebiz.middletier.tpp.constants.EmailUtil;
import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.constants.GbdUtil;
import com.wellpoint.ebiz.middletier.tpp.constants.Mail;
import com.wellpoint.ebiz.middletier.tpp.dao.LoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.dao.TPCLoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.dao.TPTServicesLogDao;
import com.wellpoint.ebiz.middletier.tpp.dao.TransLogDAO;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.ebiz.middletier.tpp.utils.EncryptiontUtils;
import com.wellpoint.ebiz.middletier.tpp.utils.SOAServicesConsumer;
import com.wellpoint.middletier.gbd.soa.gateway.bo.Attributes;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AuthenticateUserRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.AuthenticateUserResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ChangePasswordRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ChangePasswordResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.CreateRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.CreateResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.DeleteUserAccountRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.DeleteUserAccountResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.Exceptions;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GeneratePasswordRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GeneratePasswordResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetSecretQuestionsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GetSecretQuestionsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.IdentityInfo;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyAttributeEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyAttributes;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyTypeEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyUserDetailsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ModifyUserDetailsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.NewUserInfo;
import com.wellpoint.middletier.gbd.soa.gateway.bo.RepositoryEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.RequestContext;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserDetailsResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SearchUserFilter;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SecretQuestionAnswers;
import com.wellpoint.middletier.gbd.soa.gateway.bo.TPTServicesLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.User;
import com.wellpoint.middletier.gbd.soa.gateway.bo.UserRoleEnum;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateSecretAnswerRequestVO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ValidateSecretAnswerResponseVO;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.AuthenticateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ChangePasswordRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.DeleteUserAccountRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetFaqQnARequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetSecretQuestionsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ModifyUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.RegisterCreateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateSecretAnswerRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.AuthenticateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ChangePasswordRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.DeleteUserAccountRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetFaqQnAResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetFaqResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetSecretQuestionsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ModifyUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.RegisterCreateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateSecretAnswerRestResponse;

@Component("sOAServiceEndpointServiceImpl")
public class SOAServiceEndpointServiceImpl implements SOAServiceEndpointService, GbdSOAConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(SOAServiceEndpointServiceImpl.class);

	@Autowired
	private SOAServicesConsumer sOAServicesConsumer;

	@Autowired
	private TPTServicesLogDao tPTServicesLogDao;
	
	@Autowired
	private LoginServiceDao loginServiceDao;
	
	@Autowired
	private TPCLoginServiceDao tpcLoginServiceDao;
	
	@Autowired
	private TransLogDAO transLogDAO;
	
	@Autowired 
	private EmailUtil emailUtil;
	
	XStream xstream = new XStream();

	/***
	 * This method is used to create new user account using SOA service
	 * @param RegisterCreateUserRestRequest
	 * @return RegisterCreateUserRestResponse
	 */
	@Override
	public RegisterCreateUserRestResponse createUser(
			RegisterCreateUserRestRequest request) throws GbdException {

		LOGGER.debug("start of createUser in SOAServiceEndpointServiceImpl");
		RegisterCreateUserRestResponse response = new RegisterCreateUserRestResponse();

		if(null != request.getEmailAddress() && !request.getEmailAddress().isEmpty()){
			request.setEmailAddress(request.getEmailAddress().toLowerCase());
		}
		int userIdUsedCount = 0;
		int emailIdUsedCount = 0;
		String usedId = "";
		String reqSys = "";
		try{
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				userIdUsedCount = tpcLoginServiceDao.getTpcUserIdUsedCount(request.getUserName());
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())){
				userIdUsedCount = loginServiceDao.getUserIdUsedCount(request.getUserName(), GBD_KY);
				reqSys = KY_TPP_SENDER_APP;
			} else {
				userIdUsedCount = loginServiceDao.getUserIdUsedCount(request.getUserName(), GBD_IN);
				reqSys = TPP_SENDER_APP;
			}
		
			if(userIdUsedCount > 0){
				response.setCreateUserStatus(false);
				response.setErrorMessage(USERNAMEALREADYEXISTS);
				return response;
			}
			if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
				emailIdUsedCount = tpcLoginServiceDao.getTpcEmailIdUsedCount(request.getEmailAddress());
			} else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)){
				emailIdUsedCount = loginServiceDao.getEmailIdUsedCount(request.getEmailAddress(), GBD_KY);
			} else {
				emailIdUsedCount = loginServiceDao.getEmailIdUsedCount(request.getEmailAddress(), GBD_IN);
			}
			
			if(emailIdUsedCount > 0){
				response.setCreateUserStatus(false);
				response.setErrorMessage(EMAILIDALREADYEXISTS);
				return response;
			}
		} catch (Exception e) {
			LOGGER.debug("inside exception createUser db calls : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		CreateRequestVO createUserRequest = new CreateRequestVO();
		NewUserInfo newUserInfo = new NewUserInfo();
		RequestContext requestContext = new RequestContext();

		newUserInfo.setUsername(request.getUserName());
		newUserInfo.setPassword(request.getPassword());
		newUserInfo.setFirstName(request.getFirstName());
		newUserInfo.setLastName(request.getLastName());
		newUserInfo.setEmailAddress(request.getEmailAddress());
		for(SecretQuestionAnswers item: request.getSecretQuestionAnswers()){
			if(null != item.getAnswer() && !item.getAnswer().isEmpty()){
				item.setAnswer(item.getAnswer().toLowerCase());
			}
		}
		newUserInfo.setSecretQuestionAnswers(request.getSecretQuestionAnswers());
		newUserInfo.setForceChangePassword(false);
		newUserInfo.setRepositoryEnum(RepositoryEnum.IAM);
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			newUserInfo.setUserRoleEnum(UserRoleEnum.GOFUNDCOMMERCIAL);
		}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			newUserInfo.setUserRoleEnum(UserRoleEnum.GOFUNDKYHEALTH);
		} else {
			newUserInfo.setUserRoleEnum(UserRoleEnum.GOFUNDHIP);
		}

		createUserRequest.setNewUserInfo(newUserInfo);

		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid002");
		requestContext.setUsername(request.getUserName());

		createUserRequest.setRequestContext(requestContext);

		try {
			CreateResponseVO createUserResponse = sOAServicesConsumer.createUserRegisterSOA(createUserRequest, reqSys);

			if (null != createUserResponse && null != createUserResponse.getApiException() && null != createUserResponse.getApiException().getExceptions()) {
				response.setCreateUserStatus(false);
				Exceptions[] exceptions = createUserResponse.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != createUserResponse.getResponseContext()
					&& null != createUserResponse.getResponseContext().getConfirmationNumber()
					&& !createUserResponse.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setCreateUserStatus(true);
			}else{
				response.setCreateUserStatus(false);
				response.setErrorMessage(UNK_ERROR);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.createUserRegisterSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		if(response.isCreateUserStatus()){
			/*store the user information into db*/
			try{
				TPPRegistrationDetail details = new TPPRegistrationDetail();
				details.setUserId(request.getUserName());
				details.setFirstName(request.getFirstName());
				details.setLastName(request.getLastName());
				details.setEmailId(request.getEmailAddress());
				details.setPhoneNumber(request.getPhoneNumber());
				details.setOrganizationName(request.getOrgName());
				details.setOrganizationType(request.getOrgType());
				//details.setUniqueId(EncryptiontUtils.generateUniqueId());
				if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
					details.setUniqueId(EncryptiontUtils.generateTpcUniqueId());
					usedId = tpcLoginServiceDao.insertTpcRegistration(details);
				}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
					details.setUniqueId(EncryptiontUtils.generateTpcUniqueId());
					details.setLob(GBD_KY);
					usedId = loginServiceDao.insertTppRegistration(details);
				}else {
					details.setUniqueId(EncryptiontUtils.generateUniqueId());
					details.setLob(GBD_IN);
					usedId = loginServiceDao.insertTppRegistration(details);
				}
				LOGGER.debug("Register DB Store : " + usedId);
			} catch (Exception e) {
				LOGGER.debug("inside exception createUser db calls : " + e.getMessage());
				throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
			}
		}
		
		LOGGER.debug("end of createUser in SOAServiceEndpointServiceImpl");

		return response;
	}

	/***
	 * This method is used to delete existing account using SOA service
	 * @param DeleteUserAccountRestRequest
	 * @return DeleteUserAccountRestResponse
	 */

	@Override
	public DeleteUserAccountRestResponse deleteUser(
			DeleteUserAccountRestRequest request, boolean sendEmailFlag) throws GbdException {
		LOGGER.debug("start of deleteUser in SOAServiceEndpointServiceImpl");
		DeleteUserAccountRestResponse response = new DeleteUserAccountRestResponse();
		
		DeleteUserAccountRequestVO deleteUserAccountRequestVO = new DeleteUserAccountRequestVO();
		deleteUserAccountRequestVO.setComments(request.getComments());
		
		IdentityInfo identityInfo = new IdentityInfo();
		identityInfo.setDn(request.getDn());
		identityInfo.setRepositoryEnum(RepositoryEnum.IAM);
		deleteUserAccountRequestVO.setIdentityInfo(identityInfo);
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid005");
		requestContext.setUsername(request.getUserName());
		deleteUserAccountRequestVO.setRequestContext(requestContext);
		
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			DeleteUserAccountResponseVO deleteUserResponse = sOAServicesConsumer.deleteUserAccountSOA(deleteUserAccountRequestVO, reqSys);

			if (null != deleteUserResponse && null != deleteUserResponse.getApiException() && null != deleteUserResponse.getApiException().getExceptions()) {
				response.setDeleteUserStatus(false);
				Exceptions[] exceptions = deleteUserResponse.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != deleteUserResponse.getResponseContext()
					&& null != deleteUserResponse.getResponseContext().getConfirmationNumber()
					&& !deleteUserResponse.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setDeleteUserStatus(true);
			
				try{
					if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys) && sendEmailFlag) {
						sendDeleteUserAccountEmail(request, reqSys);
					}
				}catch(Exception e){
					LOGGER.error("Inside exception sendDeleteUserAccountEmail : " + e);
				}			
			
			}else{
				response.setDeleteUserStatus(false);
				response.setErrorMessage(UNK_ERROR);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.deleteUserAccountSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		if(response.isDeleteUserStatus()){
			/*delete the user information from db*/
			try{
				if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
					tpcLoginServiceDao.deleteTpcUserAccount(request.getUserName());
				}else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)) {
					loginServiceDao.deleteUserAccount(request.getUserName(), GBD_KY);
				}else{
					loginServiceDao.deleteUserAccount(request.getUserName(), GBD_IN);
				}
			} catch (Exception e) {
				LOGGER.debug("inside exception deleteUser db calls : " + e.getMessage());
				throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
			}
		}
		
		LOGGER.debug("end of deleteUser in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/**
	 * compose and send email for delete user confirmation
	 * @param request
	 * @throws GbdException 
	 */
	private void sendDeleteUserAccountEmail(
			DeleteUserAccountRestRequest request, String reqSys) throws GbdException {
		LOGGER.debug("Inside sendDeleteUserAccountEmail -- start");
		List<TPPRegistrationDetail> userDetails = tpcLoginServiceDao.getTpcUserDetailsFromUserId(request.getUserName());

		if(null != userDetails && userDetails.size() > 0){
			Mail mail = new Mail();
			mail.setMailFrom(GbdSOAConstants.FROM_EMAIL_ADDRESS);
			mail.setMailTo(userDetails.get(0).getEmailId().trim());
			mail.setMailSubject(GbdSOAConstants.EMAIL_DELETE_ACCOUNT_SUBJECT);
			mail.setTemplateName(DELETE_ACCOUNT_EMAIL_TEMPLATE_ABCBS);
			mail.setUserId(userDetails.get(0).getUserId().trim());
			emailUtil.composeMailParameters(mail, userDetails.get(0), false, "", reqSys);
		}
		LOGGER.debug("Inside sendDeleteUserAccountEmail -- end");
	}
	
	/***
	 * This method is used to search for user details using SOA service
	 * @param SearchUserDetailsRestRequest
	 * @return SearchUserDetailsRestResponse
	 */

	@Override
	public SearchUserDetailsRestResponse searchUser(
			SearchUserDetailsRestRequest request) throws GbdException {
		LOGGER.debug("start of searchUser in SOAServiceEndpointServiceImpl");
		SearchUserDetailsRestResponse response = new SearchUserDetailsRestResponse();
		
		SearchUserDetailsRequestVO searchUserDetailsRequestVO = new SearchUserDetailsRequestVO();
		
		SearchUserFilter searchUserFilter = new SearchUserFilter();
		searchUserFilter.setUsername(request.getUserName());
		
		RepositoryEnum[] repositoryEnums = new RepositoryEnum[1];
		repositoryEnums[0] = RepositoryEnum.IAM;
		searchUserFilter.setRepositoryEnum(repositoryEnums);
		
		UserRoleEnum[] userRoleEnums = new UserRoleEnum[1];
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userRoleEnums[0] = UserRoleEnum.GOFUNDCOMMERCIAL;
		}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userRoleEnums[0] = UserRoleEnum.GOFUNDKYHEALTH;
		}else{
			userRoleEnums[0] = UserRoleEnum.GOFUNDHIP;
		}
		searchUserFilter.setUserRoleEnum(userRoleEnums);
		searchUserDetailsRequestVO.setSearchUserFilter(searchUserFilter);
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid003");
		requestContext.setUsername(request.getUserName());
		
		searchUserDetailsRequestVO.setRequestContext(requestContext);
		
		int userIdUsedCount = 0;
		String reqSys = "";
		List<TPPRegistrationDetail> details = null;
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				userIdUsedCount = tpcLoginServiceDao.getTpcUserIdUsedCount(request.getUserName());
				reqSys = TPC_SENDER_APP;
			}else if (null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				userIdUsedCount = loginServiceDao.getUserIdUsedCount(request.getUserName(), GBD_KY);
				reqSys = KY_TPP_SENDER_APP;
			} else {
				userIdUsedCount = loginServiceDao.getUserIdUsedCount(request.getUserName(), GBD_IN);
				reqSys = TPP_SENDER_APP;
			}
			
			if(userIdUsedCount == 0){
				response.setErrorMessage(USERNOTFOUND);
				return response;
			}
			
			SearchUserDetailsResponseVO searchUserResponse = sOAServicesConsumer.searchUserDetailsSOA(searchUserDetailsRequestVO, reqSys);

			if (null != searchUserResponse && null != searchUserResponse.getApiException() && null != searchUserResponse.getApiException().getExceptions()) {
				Exceptions[] exceptions = searchUserResponse.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != searchUserResponse.getResponseContext()
					&& null != searchUserResponse.getResponseContext().getConfirmationNumber()
					&& !searchUserResponse.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setUser(searchUserResponse.getUser()[0]);
				if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
					details = tpcLoginServiceDao.getTpcUserDetailsFromUserId(request.getUserName());
				}else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)) {
					details = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
				}else {
					details = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
				}
				if(null != response.getUser() && null != details && details.size() > 0){
					if(null != details.get(0).getUserId() && !details.get(0).getUserId().isEmpty()){
						response.getUser().setUsername(details.get(0).getUserId().trim());
					}
					if(null != details.get(0).getPhoneNumber() && !details.get(0).getPhoneNumber().isEmpty()){
						response.getUser().setPhoneNumber(details.get(0).getPhoneNumber().trim());
					}
					if(null != details.get(0).getOrganizationName() && !details.get(0).getOrganizationName().isEmpty()){
						response.getUser().setOrgName(details.get(0).getOrganizationName().trim());
					}
					if(null != details.get(0).getOrganizationType() && !details.get(0).getOrganizationType().isEmpty()){
						response.getUser().setOrgType(details.get(0).getOrganizationType().trim());
					}
					if(null != details.get(0).getAuthFlag() && !details.get(0).getAuthFlag().isEmpty() && NEEDS_AUTH.equalsIgnoreCase(details.get(0).getAuthFlag())){
						response.getUser().setAuthFlag(Boolean.TRUE);
					}
				}
			}else{
				response.setErrorMessage(UNK_ERROR);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.searchUserDetailsSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		LOGGER.debug("end of searchUser in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/***
	 * This method is used to get user id from registration table in db, based on email id
	 * @param SearchUserDetailsRestRequest
	 * @return SearchUserDetailsRestResponse
	 */

	@Override
	public SearchUserDetailsRestResponse getUserIdFromEmailId(
			RegisterCreateUserRestRequest request) throws GbdException {
		LOGGER.debug("start of getUserIdFromEmailId in SOAServiceEndpointServiceImpl");
		SearchUserDetailsRestResponse response = new SearchUserDetailsRestResponse();
		List<TPPRegistrationDetail> details = null;
		List<TPPRegistrationDetail> userDetails = null;
		try {
			if(null != request.getEmailAddress() && !request.getEmailAddress().isEmpty()){
				request.setEmailAddress(request.getEmailAddress().toLowerCase());
			}
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = tpcLoginServiceDao.getTpcUserIdFromEmailId(request.getEmailAddress());
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = loginServiceDao.getUserIdFromEmailId(request.getEmailAddress(), GBD_KY);
			}else {
				details = loginServiceDao.getUserIdFromEmailId(request.getEmailAddress(), GBD_IN);
			}
			if(null != details && details.size() > 0){
				User user = new User();
				user.setUsername(details.get(0).getUserId().trim());
				if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
					userDetails = tpcLoginServiceDao.getTpcUserDetailsFromUserId(user.getUsername());
				} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
					userDetails = loginServiceDao.getUserDetailsFromUserId(user.getUsername(), GBD_KY);
				}else {
					userDetails = loginServiceDao.getUserDetailsFromUserId(user.getUsername(), GBD_IN);
				}
				if(null != userDetails && userDetails.size() > 0){
					String firstName = null != userDetails.get(0).getFirstName() ? userDetails.get(0).getFirstName().trim() : "";
					String lastName = null != userDetails.get(0).getLastName() ? userDetails.get(0).getLastName().trim() : "";
					String phoneNumber = null != userDetails.get(0).getPhoneNumber() ? userDetails.get(0).getPhoneNumber().trim() : "";
					if(firstName.equalsIgnoreCase(request.getFirstName()) && 
							lastName.equalsIgnoreCase(request.getLastName()) && 
							phoneNumber.equalsIgnoreCase(request.getPhoneNumber())){
						user.setFirstName(firstName);
						user.setLastName(lastName);
						user.setPhoneNumber(phoneNumber);
						if(NEEDS_AUTH.equalsIgnoreCase(userDetails.get(0).getAuthFlag())){
							user.setAuthFlag(Boolean.TRUE);
						}
						response.setUser(user);
					}else{
						response.setUser(null);
						LOGGER.debug("User details doesn't match database record");
					}
				}
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception getUserDetailsFromUserId db : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		LOGGER.debug("end of getUserDetailsFromUserId in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/***
	 * This method is used to get user details from registration table in db
	 * @param SearchUserDetailsRestRequest
	 * @return SearchUserDetailsRestResponse
	 */

	@Override
	public SearchUserDetailsRestResponse getRegisterUserDetails(
			SearchUserDetailsRestRequest request) throws GbdException {
		LOGGER.debug("start of getRegisterUserDetails in SOAServiceEndpointServiceImpl");
		SearchUserDetailsRestResponse response = new SearchUserDetailsRestResponse();
		List<TPPRegistrationDetail> details = null;
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = tpcLoginServiceDao.getTpcUserDetailsFromUserId(request.getUserName());
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				details = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
			}else {
				details = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
			}
			if(null != details && details.size() > 0){
				User user = new User();
				user.setUsername(details.get(0).getUserId().trim());
				user.setFirstName(details.get(0).getFirstName().trim());
				user.setLastName(details.get(0).getLastName().trim());
				user.setPhoneNumber(details.get(0).getPhoneNumber().trim());
				user.setEmailAddress(details.get(0).getEmailId().trim());
				user.setOrgName(details.get(0).getOrganizationName().trim());
				user.setOrgType(details.get(0).getOrganizationType().trim());
				if(null!=details.get(0).getAuthFlag() && NEEDS_AUTH.equalsIgnoreCase(details.get(0).getAuthFlag())){
					user.setAuthFlag(Boolean.TRUE);
				}
				response.setUser(user);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception getUserDetailsFromUserId db getRegisterUserDetails : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		LOGGER.debug("end of getRegisterUserDetails in SOAServiceEndpointServiceImpl");
		return response;
	}

	/***
	 * This method is used to authenticate user using SOA service
	 * @param AuthenticateUserRestRequest
	 * @return AuthenticateUserRestResponse
	 */
	@Override
	public AuthenticateUserRestResponse authenticateUser(
			AuthenticateUserRestRequest request) throws GbdException {
		LOGGER.debug("start of authenticateUser in SOAServiceEndpointServiceImpl");
		AuthenticateUserRestResponse response = new AuthenticateUserRestResponse();
		
		AuthenticateUserRequestVO authenticateUserRequestVO = new AuthenticateUserRequestVO();
		authenticateUserRequestVO.setPassword(request.getPassword());
		authenticateUserRequestVO.setUsername(request.getUserName());
		authenticateUserRequestVO.setRepositoryEnum(RepositoryEnum.IAM);
		
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			authenticateUserRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDCOMMERCIAL);
		}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			authenticateUserRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDKYHEALTH);
		}else {
			authenticateUserRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDHIP);
		}
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid002");
		requestContext.setUsername(request.getUserName());
		authenticateUserRequestVO.setRequestContext(requestContext);
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())){
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			AuthenticateUserResponseVO authenticateUserResponseVO = sOAServicesConsumer.authenticateUserSOA(authenticateUserRequestVO, reqSys);

			if (null != authenticateUserResponseVO && null != authenticateUserResponseVO.getApiException() && null != authenticateUserResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = authenticateUserResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
				response.setAuthenticated(false);
			} else if (null != authenticateUserResponseVO.getResponseContext()
					&& null != authenticateUserResponseVO.getResponseContext().getConfirmationNumber()
					&& !authenticateUserResponseVO.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setAuthenticated(authenticateUserResponseVO.isAuthenticated());
			}else{
				response.setErrorMessage(UNK_ERROR);
				response.setAuthenticated(false);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.authenticateUserSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}

		LOGGER.debug("end of authenticateUser in SOAServiceEndpointServiceImpl");
		
		return response;
	}

	/***
	 * This method is used to modify user details using SOA service
	 * @param AuthenticateUserRestRequest
	 * @return ModifyUserDetailsRestResponse
	 */
	@Override
	public ModifyUserDetailsRestResponse modifyUser(
			ModifyUserDetailsRestRequest request) throws GbdException {
		LOGGER.debug("start of modifyUser in SOAServiceEndpointServiceImpl");
		ModifyUserDetailsRestResponse response = new ModifyUserDetailsRestResponse();
		try{
			ModifyUserDetailsRequestVO modifyUserDetailsRequestVO = new ModifyUserDetailsRequestVO();
			IdentityInfo identityInfo = new IdentityInfo();
			identityInfo.setDn(request.getDn());
			identityInfo.setIamGuid(request.getIamGuid());
			identityInfo.setRepositoryEnum(RepositoryEnum.IAM);
			modifyUserDetailsRequestVO.setIdentityInfo(identityInfo);
			
			RequestContext requestContext = new RequestContext();
			requestContext.setApplication(GbdSOAConstants.API_TEXT);
			requestContext.setRequestId("transid004");
			requestContext.setUsername(request.getUserName());
			modifyUserDetailsRequestVO.setRequestContext(requestContext);
			
			Attributes[] attributesToUpd = request.getAttributes();
			if(null != attributesToUpd && attributesToUpd.length == 1 ){
				for(int i = 0; i < attributesToUpd.length ;i++){
					if("EMAIL_ADDRESS".equalsIgnoreCase(attributesToUpd[i].getAttributeName())){
						ModifyAttributes[] modifyAttributes= new ModifyAttributes[1];
						ModifyAttributes attributes = new ModifyAttributes();
						attributes.setModifyAttributeEnum(ModifyAttributeEnum.EMAIL_ADDRESS);
						attributes.setModifyTypeEnum(ModifyTypeEnum.REPLACE);
						String[] value = new String[1];
						if(null != attributesToUpd[i].getAttributeValue() && !attributesToUpd[i].getAttributeValue().isEmpty()){
							value[0] = attributesToUpd[i].getAttributeValue().toLowerCase();
						}
						attributes.setValues(value);
						modifyAttributes[0] = attributes;
						modifyUserDetailsRequestVO.setModifyAttributes(modifyAttributes);
						int emailIdUsedCount =0;
						if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							emailIdUsedCount = tpcLoginServiceDao.getTpcEmailIdUsedCount(value[0]);
						}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							emailIdUsedCount = loginServiceDao.getEmailIdUsedCount(value[0], GBD_KY);
						}else{
							emailIdUsedCount = loginServiceDao.getEmailIdUsedCount(value[0], GBD_IN);
						}
						
						if(emailIdUsedCount > 0){
							response.setModified(false);
							response.setErrorMessage(EMAILIDALREADYEXISTS);
							return response;
						}
						
						response = callModifyUserSOA(modifyUserDetailsRequestVO, request.getRequestingSystem());
						if(response.isModified()){
							int count = 0;
							/*change email id in db*/
							TPPRegistrationDetail details = new TPPRegistrationDetail();
							details.setEmailId(value[0]);
							details.setUserId(request.getUserName());
							details.setFieldName(EMAIL_ID);
							
							if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							 count = tpcLoginServiceDao.updateTpcRegistration(details);
							} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
								details.setLob(GBD_KY);
								count = loginServiceDao.updateTPPRegistration(details);
							} else{
								details.setLob(GBD_IN);
								count = loginServiceDao.updateTPPRegistration(details);
							}
							if(count > 0){
								LOGGER.debug("Email id updated successfully for " + request.getUserName());
							}else{
								LOGGER.debug("Email id not updated successfully for " + request.getUserName());
							}
						}
					}else if("PHONE_NUMBER".equalsIgnoreCase(attributesToUpd[i].getAttributeName())){
						/*change phone number in db*/
						TPPRegistrationDetail details = new TPPRegistrationDetail();
						details.setPhoneNumber(attributesToUpd[i].getAttributeValue());
						details.setUserId(request.getUserName());
						details.setFieldName(PHONE_NUMBER);
						int count = 0;
						if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							count = tpcLoginServiceDao.updateTpcRegistration(details);
						} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							details.setLob(GBD_KY);
							count = loginServiceDao.updateTPPRegistration(details);
						}else{
							details.setLob(GBD_IN);
						 	count = loginServiceDao.updateTPPRegistration(details);
						}
						if(count > 0){
							response.setModified(true);
							LOGGER.debug("Phone number updated successfully for " + request.getUserName());
						}else{
							LOGGER.debug("Phone number not updated successfully for " + request.getUserName());
						}
					}else if("AUTH_FLAG".equalsIgnoreCase(attributesToUpd[i].getAttributeName())){
						/*change phone number in db*/
						TPPRegistrationDetail details = new TPPRegistrationDetail();
						details.setAuthFlag(attributesToUpd[i].getAttributeValue());
						details.setUserId(request.getUserName());
						details.setFieldName(AUTH_FLAG);
						int count = 0;
						if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							count = tpcLoginServiceDao.updateTpcRegistration(details);
						} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
							details.setLob(GBD_KY);
							count = loginServiceDao.updateTPPRegistration(details);
						}else{
							details.setLob(GBD_IN);
						 	count = loginServiceDao.updateTPPRegistration(details);
						}
						if(count > 0){
							response.setModified(true);
							LOGGER.debug("Auth Flag updated successfully for " + request.getUserName());
						}else{
							LOGGER.debug("Auth Flag not updated successfully for " + request.getUserName());
						}
					}
				}
			}
			
			if(null != attributesToUpd && attributesToUpd.length == 2 ){
				ModifyAttributes[] modifyAttributes= new ModifyAttributes[2];
				String firstName = "";
				String lastName = "";
				for(int i = 0; i < attributesToUpd.length ;i++){
					if("FIRST_NAME".equalsIgnoreCase(attributesToUpd[i].getAttributeName())){
						ModifyAttributes attributes = new ModifyAttributes();
						attributes.setModifyAttributeEnum(ModifyAttributeEnum.FIRST_NAME);
						attributes.setModifyTypeEnum(ModifyTypeEnum.REPLACE);
						String[] value = new String[1];
						value[0] = attributesToUpd[i].getAttributeValue();
						attributes.setValues(value);
						firstName = value[0]; 
						modifyAttributes[0] = attributes;
					}else if("LAST_NAME".equalsIgnoreCase(attributesToUpd[i].getAttributeName())){
						ModifyAttributes attributes = new ModifyAttributes();
						attributes.setModifyAttributeEnum(ModifyAttributeEnum.LAST_NAME);
						attributes.setModifyTypeEnum(ModifyTypeEnum.REPLACE);
						String[] value = new String[1];
						value[0] = attributesToUpd[i].getAttributeValue();
						attributes.setValues(value);
						lastName = value[0];
						modifyAttributes[1] = attributes;
					}
				}
				modifyUserDetailsRequestVO.setModifyAttributes(modifyAttributes);
				response = callModifyUserSOA(modifyUserDetailsRequestVO, request.getRequestingSystem());
				if(response.isModified()){
					/*change first name and last name in db*/
					TPPRegistrationDetail details = new TPPRegistrationDetail();
					details.setFirstName(firstName);
					details.setLastName(lastName);
					details.setUserId(request.getUserName());
					details.setFieldName(NAME);
					int count = 0;
					if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
						count = tpcLoginServiceDao.updateTpcRegistration(details);
					} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
						details.setLob(GBD_KY);
						count = loginServiceDao.updateTPPRegistration(details);
					}else {
						details.setLob(GBD_IN);
						count = loginServiceDao.updateTPPRegistration(details);
					}
					if(count > 0){
						LOGGER.debug("First Name and Last Name updated successfully for " + request.getUserName());
					}else{
						LOGGER.debug("First Name and Last Name not updated successfully for " + request.getUserName());
					}
				}
	
			  }
		}catch(Exception e){
			LOGGER.debug("inside exception modifyUser : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("end of modifyUser in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/**
	 * This method is used to call Modify user SOA service to update user details
	 * @param modifyUserDetailsRequestVO
	 * @return
	 * @throws GbdException
	 */
	private ModifyUserDetailsRestResponse callModifyUserSOA(ModifyUserDetailsRequestVO modifyUserDetailsRequestVO, String reqSys) throws GbdException{
		LOGGER.debug("start of callModifyUserSOA in SOAServiceEndpointServiceImpl");
		
		ModifyUserDetailsRestResponse response = new ModifyUserDetailsRestResponse();
		try {
			if(null != reqSys && TPC_SENDER_APP.equalsIgnoreCase(reqSys)) {
				reqSys = TPC_SENDER_APP;
			}else if(null != reqSys && KY_TPP_SENDER_APP.equalsIgnoreCase(reqSys)) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			ModifyUserDetailsResponseVO modifyUserDetailsResponseVO = sOAServicesConsumer.modifyUserDetailsSOA(modifyUserDetailsRequestVO, reqSys);

			if (null != modifyUserDetailsResponseVO && null != modifyUserDetailsResponseVO.getApiException() && null != modifyUserDetailsResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = modifyUserDetailsResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
				response.setModified(false);
			} else if (null != modifyUserDetailsResponseVO.getResponseContext()
					&& null != modifyUserDetailsResponseVO.getResponseContext().getConfirmationNumber()
					&& !modifyUserDetailsResponseVO.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setModified(true);
				response.setUser(modifyUserDetailsResponseVO.getUser());
			}else{
				response.setErrorMessage(UNK_ERROR);
				response.setModified(false);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.callModifyUserSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("end of callModifyUserSOA in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/***
	 * This method is used to change current password using SOA service
	 * @param ChangePasswordRestRequest
	 * @return ChangePasswordRestResponse
	 */
	@Override
	public ChangePasswordRestResponse changePassword(
			ChangePasswordRestRequest request) throws GbdException {
		LOGGER.debug("start of callModifyUserSOA in SOAServiceEndpointServiceImpl");
		ChangePasswordRestResponse response = new ChangePasswordRestResponse();
		
		/*set reset password missing details - starts*/
		if(null == request.getDn() || request.getDn().isEmpty() || null == request.getIamGuid() || request.getIamGuid().isEmpty()){
			getMissingDetailsForChangePassword(request);
		}
		/*set reset password missing details - ends*/
		
		ChangePasswordRequestVO changePasswordRequestVO = new ChangePasswordRequestVO();
	
		changePasswordRequestVO.setDn(request.getDn());
		changePasswordRequestVO.setIamGuid(request.getIamGuid());
		changePasswordRequestVO.setRepositoryEnum(RepositoryEnum.IAM);
		changePasswordRequestVO.setCurrentPassword(request.getCurrentPassword());
		
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			changePasswordRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDCOMMERCIAL);
		}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			changePasswordRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDKYHEALTH);
		} else {
			changePasswordRequestVO.setUserRoleEnum(UserRoleEnum.GOFUNDHIP);
		}
		
		changePasswordRequestVO.setNewPassword(request.getNewPassword());
		changePasswordRequestVO.setUsername(request.getUserName());
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid004");
		requestContext.setUsername(request.getUserName());
		changePasswordRequestVO.setRequestContext(requestContext);
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			ChangePasswordResponseVO changePasswordResponseVO = sOAServicesConsumer.changePasswordSOA(changePasswordRequestVO, reqSys);

			if (null != changePasswordResponseVO && null != changePasswordResponseVO.getApiException() && null != changePasswordResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = changePasswordResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
				response.setChangeStatus(false);
			} else if (null != changePasswordResponseVO.getResponseContext()
					&& null != changePasswordResponseVO.getResponseContext().getConfirmationNumber()
					&& !changePasswordResponseVO.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setChangeStatus(true);
			}else{
				response.setErrorMessage(UNK_ERROR);
				response.setChangeStatus(false);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.changePasswordSOA : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("end of changePasswordSOA in SOAServiceEndpointServiceImpl");
		return response;
	}

	/***
	 * This method is used to set the missing details of reset password in the change password SOA call.
	 * @param ChangePasswordRestRequest
	 */
	private void getMissingDetailsForChangePassword(ChangePasswordRestRequest request) throws GbdException{
		SearchUserDetailsRestRequest searchUserRequest = new SearchUserDetailsRestRequest();
		searchUserRequest.setUserName(request.getUserName());
		searchUserRequest.setEndPointName("searchUser");
		SearchUserDetailsRestResponse searchUserResponse = searchUser(searchUserRequest);
		if(null != searchUserResponse.getUser()){
			request.setDn(searchUserResponse.getUser().getDn());
			request.setIamGuid(searchUserResponse.getUser().getIamGuid());
		}
	}
	
	/***
	 * This method is used to validate secret answer and send user name email
	 * @param ValidateSecretAnswerRestRequest
	 * @return ValidateSecretAnswerRestResponse
	 */
	@Override
	public ValidateSecretAnswerRestResponse validateSecretAnswerForForgotUserName(
			ValidateSecretAnswerRestRequest request) throws GbdException {
		ValidateSecretAnswerRestResponse response = validateSecretAnswer(request);	
		if(null != response && response.isValidated()){
			try{
				validateSecretAnswerForForgotUserNameEmail(request);
			}catch(Exception e){
				LOGGER.error("Inside exception validateSecretAnswerForForgotUserName : " + e);
			}
		}
		
		return response;
	}
	
	public GeneratePasswordResponseVO generateTemporaryPassword(ValidateSecretAnswerRestRequest request)throws GbdException {
		
		LOGGER.debug("start of generateTemporaryPassword in SOAServiceEndpointServiceImpl");
		
		GeneratePasswordResponseVO generatePasswordResponseVO = new GeneratePasswordResponseVO();
		GeneratePasswordRequestVO generatePasswordRequestVO = new GeneratePasswordRequestVO();
		
		generatePasswordRequestVO.setDn(request.getDn());
		generatePasswordRequestVO.setIamGuid(request.getIamGuid());
		generatePasswordRequestVO.setRepositoryEnum(RepositoryEnum.IAM);
		generatePasswordRequestVO.setUsername(request.getUserName());
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid004");
		requestContext.setUsername(request.getUserName());
		generatePasswordRequestVO.setRequestContext(requestContext);
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			generatePasswordResponseVO = sOAServicesConsumer.generatePasswordSOA(generatePasswordRequestVO, reqSys);
			
		}catch (Exception e) {
			LOGGER.debug("inside exception generateTemporaryPassword : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.debug("end of generateTemporaryPassword in SOAServiceEndpointServiceImpl");
		
		return generatePasswordResponseVO;
	}
	
	/***
	 * This method is used to validate secret answer and send user name email
	 * @param ValidateSecretAnswerRestRequest
	 * @return ValidateSecretAnswerRestResponse
	 */
	@Override
	public ValidateSecretAnswerRestResponse validateSecretAnswerForForgotPassword(
			ValidateSecretAnswerRestRequest request) throws GbdException {
		
		ValidateSecretAnswerRestResponse response = validateSecretAnswer(request);
		
		if(null != response && response.isValidated()){
			
			GeneratePasswordResponseVO generatePasswordResponseVO = generateTemporaryPassword(request);
			
			if(null != generatePasswordResponseVO && null != generatePasswordResponseVO.getResponseContext()
					&& !generatePasswordResponseVO.getResponseContext().getConfirmationNumber().isEmpty()){
			
				try{
					validateSecretAnswerForForgotPasswordEmail(request, generatePasswordResponseVO.getPassword());
				}catch(Exception e){
					LOGGER.error("Inside exception validateSecretAnswerForForgotPassword : " + e);
					throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
				}
				
			}else{
				LOGGER.debug("error response in generatePasswordResponse");
				throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
			}
			
		}
		
		return response;
	}
	
	/***
	 * This method is used to validate secret answer using SOA service
	 * @param ValidateSecretAnswerRestRequest
	 * @return ValidateSecretAnswerRestResponse
	 */
	public ValidateSecretAnswerRestResponse validateSecretAnswer(
			ValidateSecretAnswerRestRequest request) throws GbdException {
		
		LOGGER.debug("start of validateSecretAnswer in SOAServiceEndpointServiceImpl");
		ValidateSecretAnswerRestResponse response = new ValidateSecretAnswerRestResponse();
		
		ValidateSecretAnswerRequestVO validateSecretAnswerRequestVO = new ValidateSecretAnswerRequestVO();
	
		validateSecretAnswerRequestVO.setDn(request.getDn());
		validateSecretAnswerRequestVO.setIamGuid(request.getIamGuid());
		validateSecretAnswerRequestVO.setRepositoryEnum(RepositoryEnum.IAM);
		if(null != request.getSecretAnswerText1() && !request.getSecretAnswerText1().isEmpty()){
			validateSecretAnswerRequestVO.setSecretAnswerText1(request.getSecretAnswerText1().toLowerCase());
		}
		if(null != request.getSecretAnswerText2() && !request.getSecretAnswerText2().isEmpty()){
			validateSecretAnswerRequestVO.setSecretAnswerText2(request.getSecretAnswerText2().toLowerCase());
		}
		if(null != request.getSecretAnswerText3() && !request.getSecretAnswerText3().isEmpty()){
			validateSecretAnswerRequestVO.setSecretAnswerText3(request.getSecretAnswerText3().toLowerCase());
		}		
		validateSecretAnswerRequestVO.setUsername(request.getUserName());
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid004");
		requestContext.setUsername(request.getUserName());
		validateSecretAnswerRequestVO.setRequestContext(requestContext);
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			ValidateSecretAnswerResponseVO validateSecretAnswerResponseVO = sOAServicesConsumer.validateSecretAnswersSOA(validateSecretAnswerRequestVO, reqSys);

			if (null != validateSecretAnswerResponseVO && null != validateSecretAnswerResponseVO.getApiException() && null != validateSecretAnswerResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = validateSecretAnswerResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
				response.setValidated(false);
			} else if (null != validateSecretAnswerResponseVO.getResponseContext()
					&& null != validateSecretAnswerResponseVO.getResponseContext().getConfirmationNumber()
					&& !validateSecretAnswerResponseVO.getResponseContext().getConfirmationNumber().isEmpty()) {
				response.setSecretAnswerAttemptsLeft(validateSecretAnswerResponseVO.getSecretAnswerAttemptsLeft());
				response.setValidated(validateSecretAnswerResponseVO.isSecretAnswerMatched());
			}else{
				response.setErrorMessage(UNK_ERROR);
				response.setValidated(false);
			}
			
			if(!response.isValidated() && ((null != response.getErrorMessage() && 
					!response.getErrorMessage().isEmpty() && USERDISABLED.equalsIgnoreCase(response.getErrorMessage())) || response.getSecretAnswerAttemptsLeft() == 0)){
				DeleteUserAccountRestRequest deleteUserAccountRestRequest = new DeleteUserAccountRestRequest();
				deleteUserAccountRestRequest.setUserName(request.getUserName());
				deleteUserAccountRestRequest.setDn(request.getDn());
				deleteUserAccountRestRequest.setRequestingSystem(request.getRequestingSystem());
				deleteUserAccountRestRequest.setComments("Account Deleted due to account disabled on user entering wrong security questions");
				if(null != reqSys && !reqSys.isEmpty()){
					if(reqSys.equalsIgnoreCase(TPC_SENDER_APP)){
						deleteUser(deleteUserAccountRestRequest, false);
					}else{
						deleteUser(deleteUserAccountRestRequest, true);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception validateSecretAnswer : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("end of validateSecretAnswer in SOAServiceEndpointServiceImpl");
		return response;
	}

	/***
	 * This method is used to get secret questions using SOA service
	 * @param GetSecretQuestionsRestRequest
	 * @return GetSecretQuestionsRestResponse
	 */
	@Override
	public GetSecretQuestionsRestResponse getSecretQuestions(
			GetSecretQuestionsRestRequest request) throws GbdException {
		LOGGER.debug("start of getSecretQuestions in SOAServiceEndpointServiceImpl");
		GetSecretQuestionsRestResponse response = new GetSecretQuestionsRestResponse();
		
		GetSecretQuestionsRequestVO getSecretQuestionsRequestVO = new GetSecretQuestionsRequestVO();
	
		getSecretQuestionsRequestVO.setDn(request.getDn());
		getSecretQuestionsRequestVO.setRepositoryEnum(RepositoryEnum.IAM);
		
		RequestContext requestContext = new RequestContext();
		requestContext.setApplication(GbdSOAConstants.API_TEXT);
		requestContext.setRequestId("transid004");
		requestContext.setUsername(request.getUserName());
		getSecretQuestionsRequestVO.setRequestContext(requestContext);
		String reqSys = "";
		try {
			if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = TPC_SENDER_APP;
			}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
				reqSys = KY_TPP_SENDER_APP;
			}else{
				reqSys = TPP_SENDER_APP;
			}
			GetSecretQuestionsResponseVO getSecretQuestionsResponseVO = sOAServicesConsumer.getSecretQuestionsSOA(getSecretQuestionsRequestVO, reqSys);

			if (null != getSecretQuestionsResponseVO && null != getSecretQuestionsResponseVO.getApiException() && null != getSecretQuestionsResponseVO.getApiException().getExceptions()) {
				Exceptions[] exceptions = getSecretQuestionsResponseVO.getApiException().getExceptions();
				response.setErrorMessage(exceptions[0].getCode());
			} else if (null != getSecretQuestionsResponseVO.getResponseContext()
					&& null != getSecretQuestionsResponseVO.getResponseContext().getConfirmationNumber()
					&& !getSecretQuestionsResponseVO.getResponseContext().getConfirmationNumber().isEmpty()) {
				String[] questions = new String[getSecretQuestionsResponseVO.getSecretQuestions().length];
				int count = 0;
				for(String item: getSecretQuestionsResponseVO.getSecretQuestions()){
					questions[count] = item.substring(0, 1).toUpperCase() + item.substring(1);
					count++;
				}
				response.setSecretQuestions(questions);
			}else{
				response.setErrorMessage(UNK_ERROR);
			}

		} catch (Exception e) {
			LOGGER.debug("inside exception sOAServicesConsumer.getSecretQuestions : " + e.getMessage());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("end of getSecretQuestions in SOAServiceEndpointServiceImpl");
		return response;
	}
	
	/***
	 * This method is used to log all the REST endpoint request and response in GBD Database.
	 * @param MbrPayTransLog
	 */
	@Async("loggingTaskExecutor")
	public void logRestLogInDB(
			MbrPayTransLog request) throws GbdException {
		LOGGER.debug("Save Rest Service Calls -- start");
		try {
			transLogDAO.saveMemberRSLog(request);			 
		} catch (Exception ex) {
			LOGGER.error("REST Logging : ", ex);
		}
		LOGGER.debug("Save Rest Service Calls -- end");		
	}
	
	/***
	 * This method is used to log all the REST endpoint request and response in GBD Database.
	 * @param MbrPayTransLog
	 */
	@Async("loggingTaskExecutor")
	public void logTPTRSInDB(
			TPTServicesLog request) throws GbdException {
		LOGGER.debug("Save TPT Service Calls -- start");
		try {
			tPTServicesLogDao.saveTptServicesLog(request);			 
		} catch (Exception ex) {
			LOGGER.error("TPT Logging : ", ex);
		}
		LOGGER.debug("Save TPT Service Calls -- end");		
	}
	
	
	/***
	 * This method is used to compose an email when the user forgets his username
	 * @param ValidateSecretAnswerRestRequest
	 * @return void
	 */
	private void validateSecretAnswerForForgotUserNameEmail(ValidateSecretAnswerRestRequest request) throws GbdException{
		LOGGER.debug("Inside validateSecretAnswerForForgotUserNameEmail -- start");
		List<TPPRegistrationDetail> userDetails = null;
		String reqSys = "";
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userDetails = tpcLoginServiceDao.getTpcUserDetailsFromUserId(request.getUserName());
			reqSys = TPC_SENDER_APP;
		} else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userDetails = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
			reqSys = KY_TPP_SENDER_APP;
		}else {
			userDetails = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
			reqSys = TPP_SENDER_APP;
		}
		if(null != userDetails && userDetails.size() > 0){
			Mail mail = new Mail();
			mail.setMailFrom(GbdSOAConstants.FROM_EMAIL_ADDRESS);
			mail.setMailTo(userDetails.get(0).getEmailId().trim());
			mail.setMailSubject(GbdSOAConstants.EMAIL_USERNAME_SUBJECT);
			if(null != reqSys && reqSys.equalsIgnoreCase(TPC_SENDER_APP)) {
				mail.setTemplateName(TPC_EMAIL_TEMPLATE_ABCBS);
			}else if(null != reqSys && reqSys.equalsIgnoreCase(KY_TPP_SENDER_APP)) {
				mail.setTemplateName(KY_TPP_EMAIL_TEMPLATE_ABCBS);
			}else {
				mail.setTemplateName(EMAIL_TEMPLATE_ABCBS);
			}
			mail.setUserId(userDetails.get(0).getUserId().trim());
			emailUtil.composeMailParameters(mail, userDetails.get(0), false, "", reqSys);
		}
		LOGGER.debug("Inside validateSecretAnswerForForgotUserNameEmail -- end");
	}
	
	
	/***
	 * This method is used to compose an email when the user forgets his password
	 * @param ValidateSecretAnswerRestRequest, String
	 * @return void
	 */
	private void validateSecretAnswerForForgotPasswordEmail(ValidateSecretAnswerRestRequest request, String password) throws GbdException{
		LOGGER.debug("Inside validateSecretAnswerForForgotPasswordEmail -- start");
		List<TPPRegistrationDetail> userDetails = null;
		String reqSys = "";
		if(null != request && null != request.getRequestingSystem() && TPC_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userDetails = tpcLoginServiceDao.getTpcUserDetailsFromUserId(request.getUserName());
			reqSys = TPC_SENDER_APP;
		}else if(null != request && null != request.getRequestingSystem() && KY_TPP_SENDER_APP.equalsIgnoreCase(request.getRequestingSystem())) {
			userDetails = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_KY);
			reqSys = KY_TPP_SENDER_APP;
		}else {
			userDetails = loginServiceDao.getUserDetailsFromUserId(request.getUserName(), GBD_IN);
			reqSys = TPP_SENDER_APP;
		}
		if(null != userDetails && userDetails.size() > 0){
			Mail mail = new Mail();
			mail.setMailFrom(GbdSOAConstants.FROM_EMAIL_ADDRESS);
			mail.setMailTo(userDetails.get(0).getEmailId().trim());
			mail.setMailSubject(GbdSOAConstants.EMAIL_PASSWORD_SUBJECT);
			if(null != reqSys && reqSys.equalsIgnoreCase(TPC_SENDER_APP)) {
				mail.setTemplateName(TPC_EMAIL_TEMPLATE_ABCBS);
			}else if(null != reqSys && reqSys.equalsIgnoreCase(KY_TPP_SENDER_APP)) {
				mail.setTemplateName(KY_TPP_EMAIL_TEMPLATE_ABCBS);
			} else {
				mail.setTemplateName(EMAIL_TEMPLATE_ABCBS);
			}
			mail.setUserId(userDetails.get(0).getUserId().trim());
			emailUtil.composeMailParameters(mail, userDetails.get(0), true, password, reqSys);
		}
		LOGGER.debug("Inside validateSecretAnswerForForgotPasswordEmail -- end");
	}
	
	@SuppressWarnings("unused")
	@Override
	public List<GetFaqResponse> getFaqQnA(GetFaqQnARequest request) throws GbdException {
		
		JSONParser parser = new JSONParser();
		List<GetFaqQnAResponse> faqQnAList = null;
		GetFaqResponse getFaqResponse = null;
		GetFaqQnAResponse getFaqQnAResponse = null;
		List<GetFaqResponse> getFaqResponseList = new ArrayList<GetFaqResponse>();
		
		try {
			String fileName = GbdUtil.getStringProperty("gbd.tpc.faq.file.location", "");
			if(!fileName.isEmpty() || null!=fileName){
				Object object = parser.parse(new FileReader(fileName));
				JSONObject jsonObj = (JSONObject)object;
				JSONArray jsonArray = (JSONArray) jsonObj.get("faqQnAList");
				
				for(int i = 0 ; i < jsonArray.size() ; i++){
					getFaqResponse = new GetFaqResponse();
					JSONObject jsonObjectRow = (JSONObject) jsonArray.get(i);
					
					String label = null!= jsonObjectRow.get("label") ? (String) jsonObjectRow.get("label") : "";
					JSONArray jsonArrayQnA = (JSONArray) jsonObjectRow.get("questionAndAnswers");
					faqQnAList = new ArrayList<GetFaqQnAResponse>();
					
					for(int j = 0 ; j < jsonArrayQnA.size() ; j++) {
						getFaqQnAResponse = new GetFaqQnAResponse();
						JSONObject jsonObjRow = (JSONObject) jsonArrayQnA.get(j);
						String question = null!= jsonObjRow.get("question") ? (String) jsonObjRow.get("question") : "";
						String answer = null!= jsonObjRow.get("answer") ? (String) jsonObjRow.get("answer") : "";
					
						if(!question.isEmpty() && !answer.isEmpty()){
							getFaqQnAResponse.setQuestion(question);
							getFaqQnAResponse.setAnswer(answer);
						}
					
					faqQnAList.add(getFaqQnAResponse);
					}
					getFaqResponse.setLabel(label);
					getFaqResponse.setQuestionAndAnswers(faqQnAList);
					getFaqResponseList.add(getFaqResponse);
				}
			}else{
				LOGGER.error("faq location not present");
			}
		} catch (IOException e) {
			LOGGER.error("TPCServiceImpl: IOException while getting FAQ response from json file " + e.getMessage());
		} catch (ParseException e) {
			LOGGER.error("TPCServiceImpl: ParseException while getting FAQ response from json file " + e.getMessage());
		}
		return getFaqResponseList;
	}

}
