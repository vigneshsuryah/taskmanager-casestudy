/**
 * SOAServiceEndpointService.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 22/10/2018  1.0      Cognizant       2FA changes Nov 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.service;

import java.util.List;

import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.TPTServicesLog;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.AuthenticateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ChangePasswordRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.DeleteUserAccountRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetFaqQnARequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetSecretQuestionsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ModifyUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.RegisterCreateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateSecretAnswerRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.AuthenticateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ChangePasswordRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.DeleteUserAccountRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetFaqResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetSecretQuestionsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ModifyUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.RegisterCreateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateSecretAnswerRestResponse;

public interface SOAServiceEndpointService {
	
	RegisterCreateUserRestResponse createUser(RegisterCreateUserRestRequest request) throws GbdException;
	DeleteUserAccountRestResponse deleteUser(DeleteUserAccountRestRequest request, boolean sendEmailFlag) throws GbdException;
	SearchUserDetailsRestResponse searchUser(SearchUserDetailsRestRequest request) throws GbdException;
	SearchUserDetailsRestResponse getRegisterUserDetails(SearchUserDetailsRestRequest request) throws GbdException;
	SearchUserDetailsRestResponse getUserIdFromEmailId(RegisterCreateUserRestRequest request) throws GbdException;
	AuthenticateUserRestResponse authenticateUser(AuthenticateUserRestRequest request) throws GbdException;
	ModifyUserDetailsRestResponse modifyUser(ModifyUserDetailsRestRequest request) throws GbdException;
	ChangePasswordRestResponse changePassword(ChangePasswordRestRequest request) throws GbdException;
	ValidateSecretAnswerRestResponse validateSecretAnswerForForgotUserName(ValidateSecretAnswerRestRequest request) throws GbdException;
	ValidateSecretAnswerRestResponse validateSecretAnswerForForgotPassword(ValidateSecretAnswerRestRequest request) throws GbdException;
	GetSecretQuestionsRestResponse getSecretQuestions(GetSecretQuestionsRestRequest request) throws GbdException;
	void logRestLogInDB(MbrPayTransLog request) throws GbdException;
	void logTPTRSInDB(TPTServicesLog request) throws GbdException;
	List<GetFaqResponse> getFaqQnA(GetFaqQnARequest request) throws GbdException;
}
