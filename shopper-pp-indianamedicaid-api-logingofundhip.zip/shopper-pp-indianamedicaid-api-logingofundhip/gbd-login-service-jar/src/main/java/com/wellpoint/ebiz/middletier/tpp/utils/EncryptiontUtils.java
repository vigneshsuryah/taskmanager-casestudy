package com.wellpoint.ebiz.middletier.tpp.utils;

import java.security.SecureRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptiontUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(EncryptiontUtils.class);
	private static final String UNIQUE_ID_POSSIBLE_CHARS="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	private static final int UNIQUE_ID_MAX_LENGTH=20;
	private static final int TPC_UNIQUE_ID_MAX_LENGTH=9;
	
	/**
	 * 
	 * @return Generate Unique Id for the given String
	 */
	public static String generateUniqueId()
	{
		String encryptedText = "";
		//Veracode Fix Start - 06/05/2017
		try
		{
			char[] possibleCharacters = (new String(UNIQUE_ID_POSSIBLE_CHARS)).toCharArray();
			encryptedText = random( UNIQUE_ID_MAX_LENGTH, 0, possibleCharacters.length-1, false, false, possibleCharacters);
		} catch (Exception e)
		{
			LOGGER.debug("Exception in generateUniqueId() "+e);
			char[] possibleCharacters = (new String(UNIQUE_ID_POSSIBLE_CHARS)).toCharArray();
			encryptedText = random( UNIQUE_ID_MAX_LENGTH, 0, possibleCharacters.length-1, false, false, possibleCharacters);
		} 
		//Veracode Fix End - 06/05/2017
		return encryptedText;
	}	
	
	/**
	 * Generates random alphanumeric string
	 * @param count
	 * @param start
	 * @param end
	 * @param letters
	 * @param numbers
	 * @param chars
	 * @return
	 */
	  private static String random(int count, int start, int end, boolean letters, boolean numbers,char[] chars) {
		SecureRandom random = new SecureRandom();
		if (count == 0) {
			return "";
		} else if (count < 0) {
			throw new IllegalArgumentException(
					"Requested random string length " + count
							+ " is less than 0.");
		}
		if ((start == 0) && (end == 0)) {
			end = 'z' + 1;
			start = ' ';
			if (!letters && !numbers) {
				start = 0;
				end = Integer.MAX_VALUE;
			}
		}

		char[] buffer = new char[count];
		int gap = end - start;

		while (count-- != 0) {
			char ch;
			if (chars == null) {
				ch = (char) (random.nextInt(gap) + start);
			} else {
				ch = chars[random.nextInt(gap) + start];
			}
			if ((letters && Character.isLetter(ch))
					|| (numbers && Character.isDigit(ch))
					|| (!letters && !numbers)) {
				if (ch >= 56320 && ch <= 57343) {
					if (count == 0) {
						count++;
					} else {
						buffer[count] = ch;
						count--;
						buffer[count] = (char) (55296 + random.nextInt(128));
					}
				} else if (ch >= 55296 && ch <= 56191) {
					if (count == 0) {
						count++;
					} else {
						buffer[count] = (char) (56320 + random.nextInt(128));
						count--;
						buffer[count] = ch;
					}
				} else if (ch >= 56192 && ch <= 56319) {
					count++;
				} else {
					buffer[count] = ch;
				}
			} else {
				count++;
			}
		}
		return new String(buffer);
	}
	  
	  /**
		 * 
		 * @return Generate TPC Unique Id for the given String
		 */
		public static String generateTpcUniqueId()
		{
			String encryptedText = "";
			try
			{
				char[] possibleCharacters = (new String(UNIQUE_ID_POSSIBLE_CHARS)).toCharArray();
				encryptedText = random( TPC_UNIQUE_ID_MAX_LENGTH, 0, possibleCharacters.length-1, false, false, possibleCharacters);
			} catch (Exception e)
			{
				LOGGER.debug("Exception in generateTpcUniqueId() "+e);
				char[] possibleCharacters = (new String(UNIQUE_ID_POSSIBLE_CHARS)).toCharArray();
				encryptedText = random( TPC_UNIQUE_ID_MAX_LENGTH, 0, possibleCharacters.length-1, false, false, possibleCharacters);
			} 
			if(null != encryptedText && !encryptedText.isEmpty()){
				encryptedText = encryptedText.toUpperCase();
			}
			return encryptedText;
		}	
	
}
