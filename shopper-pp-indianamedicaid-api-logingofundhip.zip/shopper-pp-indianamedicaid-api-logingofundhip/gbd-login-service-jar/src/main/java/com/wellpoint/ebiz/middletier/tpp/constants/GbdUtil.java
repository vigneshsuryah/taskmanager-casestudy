package com.wellpoint.ebiz.middletier.tpp.constants;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;

@Component
public class GbdUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(GbdUtil.class);
		
	public GbdUtil(){
		//Can't initialize this class
	}
	
	/**
	 * This method encodes a string using base64
	 * @param value
	 * @return
	 */
	public static String getEncodedText(String value)
	{
		String encoded = "";
		try {
			byte[] byteArray = Base64.encodeBase64(value.getBytes());
			encoded = new String(byteArray);
		} catch (Exception e) {
			LOGGER.debug("Exception in getEncodedText() "+e);
		}
		return encoded;
	}
    
	/**
	 * This method decodes a string using base64
	 * @param encoded
	 * @return
	 */
    public static String getDecodedText(String encoded)
    {
    	String decoded = "";
    	try {
    		byte[] byteArray = Base64.decodeBase64(encoded.getBytes());
    		decoded = new String(byteArray);
    		decoded = decoded.replaceAll("[\n\r]", "");
    	} catch (Exception e){ 
    		LOGGER.debug("Exception in getDecodedText() "+e);
    	}
    	return decoded;
    }
    
    
    /**
	 * 
	 * @param key
	 * @param defaultValue
	 * @return the value of the given key from the property file using Archaius
	 */
	public static String getStringProperty(String key, String defaultValue) {
        final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key,
            defaultValue);
        return property.get();
    }
	
	
	/**
	 * @return a random transaction id
	 */
	public static String getTransactionId(){
		try {
			SecureRandom random = new SecureRandom();
			return new BigInteger(130, random).toString(32);
		} catch (Exception e) {
			return "213987282a";
		}
	}
}
