/**
 * NewUserInfo.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class NewUserInfo {

	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private SecretQuestionAnswers[] secretQuestionAnswers;
	private UserRoleEnum userRoleEnum;
	private RepositoryEnum repositoryEnum;
	private boolean forceChangePassword;

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public SecretQuestionAnswers[] getSecretQuestionAnswers() {
		return secretQuestionAnswers;
	}
	public void setSecretQuestionAnswers(
			SecretQuestionAnswers[] secretQuestionAnswers) {
		this.secretQuestionAnswers = secretQuestionAnswers;
	}
	public UserRoleEnum getUserRoleEnum() {
		return userRoleEnum;
	}
	public void setUserRoleEnum(UserRoleEnum userRoleEnum) {
		this.userRoleEnum = userRoleEnum;
	}
	public RepositoryEnum getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	public boolean isForceChangePassword() {
		return forceChangePassword;
	}
	public void setForceChangePassword(boolean forceChangePassword) {
		this.forceChangePassword = forceChangePassword;
	}
	
}
