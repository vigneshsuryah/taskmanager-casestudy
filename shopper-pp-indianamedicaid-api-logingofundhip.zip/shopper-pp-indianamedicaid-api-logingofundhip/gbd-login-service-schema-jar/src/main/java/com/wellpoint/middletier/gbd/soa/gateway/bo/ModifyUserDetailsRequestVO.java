/**
 * ModifyUserDetailsRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ModifyUserDetailsRequestVO extends BaseRequest{

	private static final long serialVersionUID = 3343632027578456210L;
	
	private IdentityInfo identityInfo;
	private ModifyAttributes[] modifyAttributes;
	public IdentityInfo getIdentityInfo() {
		return identityInfo;
	}
	public void setIdentityInfo(IdentityInfo identityInfo) {
		this.identityInfo = identityInfo;
	}
	public ModifyAttributes[] getModifyAttributes() {
		return modifyAttributes;
	}
	public void setModifyAttributes(ModifyAttributes[] modifyAttributes) {
		this.modifyAttributes = modifyAttributes;
	}

}
