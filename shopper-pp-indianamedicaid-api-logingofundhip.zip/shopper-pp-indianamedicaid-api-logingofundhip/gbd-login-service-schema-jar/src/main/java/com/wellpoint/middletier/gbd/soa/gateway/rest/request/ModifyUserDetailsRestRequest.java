/**
 * ModifyUserDetailsRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

import com.wellpoint.middletier.gbd.soa.gateway.bo.Attributes;

public class ModifyUserDetailsRestRequest extends BaseRequest {

	private Attributes[] attributes;
	private String dn;
	private String iamGuid;
	public Attributes[] getAttributes() {
		return attributes;
	}
	public void setAttributes(Attributes[] attributes) {
		this.attributes = attributes;
	}
	
	public String getIamGuid() {
		return iamGuid;
	}
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	
}
