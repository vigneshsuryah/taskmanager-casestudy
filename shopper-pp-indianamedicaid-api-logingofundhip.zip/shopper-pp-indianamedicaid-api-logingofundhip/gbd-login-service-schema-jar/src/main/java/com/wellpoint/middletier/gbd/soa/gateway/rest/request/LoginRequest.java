/**
 * LoginRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 10/24/2018  2.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class LoginRequest extends BaseRequest
{
	private String password;
	private String fccUrl;
	private String targetUrl;
	
	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}
	/**
	 * @return the fccUrl
	 */
	public String getFccUrl()
	{
		return fccUrl;
	}
	/**
	 * @param fccUrl the fccUrl to set
	 */
	public void setFccUrl(String fccUrl)
	{
		this.fccUrl = fccUrl;
	}
	/**
	 * @return the targetUrl
	 */
	public String getTargetUrl()
	{
		return targetUrl;
	}
	/**
	 * @param targetUrl the targetUrl to set
	 */
	public void setTargetUrl(String targetUrl)
	{
		this.targetUrl = targetUrl;
	}


}
