/**
 * SendOtpResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SecureAuthResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SendOtpRestResponse extends BaseResponse{
	
	private SecureAuthResponse secureAuthResponse;

	public SecureAuthResponse getSecureAuthResponse()
	{
		return secureAuthResponse;
	}

	public void setSecureAuthResponse(SecureAuthResponse value)
	{
		this.secureAuthResponse = value;
	}
	
}
