/**
 * ChangePasswordRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class ChangePasswordRestRequest extends BaseRequest {
	
	private String dn;
	private String comments;
	private String currentPassword;
	private String newPassword;
	private String iamGuid;

	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCurrentPassword() {
		return currentPassword;
	}
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getIamGuid() {
		return iamGuid;
	}
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}
	
}
