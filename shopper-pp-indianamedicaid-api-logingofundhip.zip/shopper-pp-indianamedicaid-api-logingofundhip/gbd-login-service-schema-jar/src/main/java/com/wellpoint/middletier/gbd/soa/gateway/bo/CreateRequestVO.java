/**
 * CreateRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class CreateRequestVO extends BaseRequest {
	
	private static final long serialVersionUID = -6741245266754868534L;
	
	private NewUserInfo newUserInfo; 

	public NewUserInfo getNewUserInfo() {
		return newUserInfo;
	}
	public void setNewUserInfo(NewUserInfo newUserInfo) {
		this.newUserInfo = newUserInfo;
	}
	
}
