/**
 * ValidateOtpRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class ValidateOtpRestRequest extends BaseRequest{
	
	private String transientUserNm;
	private String otp;
	private String duration;
	
	public String getTransientUserNm() {
		return transientUserNm;
	}
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
}
