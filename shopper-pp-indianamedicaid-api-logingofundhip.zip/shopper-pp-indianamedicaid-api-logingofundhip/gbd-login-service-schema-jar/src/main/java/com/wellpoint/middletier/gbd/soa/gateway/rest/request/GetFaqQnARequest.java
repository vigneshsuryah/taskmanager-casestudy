package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class GetFaqQnARequest extends BaseRequest{

}
