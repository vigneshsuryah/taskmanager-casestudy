/**
 * BaseRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 11/12/2017  2.0      Cognizant       TPC change March 2018
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class BaseRequest {

	private String userName;
	private String endPointName;
	
	//Added by Cognizant for TPC change March 2018 release - Start
	private String requestingSystem;
	//Added by Cognizant for TPC change March 2018 release - End

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEndPointName() {
		return endPointName;
	}

	public void setEndPointName(String endPointName) {
		this.endPointName = endPointName;
	}

	//Added by Cognizant for TPC change March 2018 release - Start
	/**
	 * @return the requestingSystem
	 */
	public String getRequestingSystem() {
		return requestingSystem;
	}

	/**
	 * @param requestingSystem the requestingSystem to set
	 */
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
	//Added by Cognizant for TPC change March 2018 release - End
}
