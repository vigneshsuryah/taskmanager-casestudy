/**
* Exceptions.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 07/01/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class Exceptions {
	private String type;
	private String code;
	private String message;
	private String detail;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
}
