package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

import java.util.List;

public class GetFaqResponse {

	private String label;
	private List<GetFaqQnAResponse> questionAndAnswers;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<GetFaqQnAResponse> getQuestionAndAnswers() {
		return questionAndAnswers;
	}

	public void setQuestionAndAnswers(List<GetFaqQnAResponse> questionAndAnswers) {
		this.questionAndAnswers = questionAndAnswers;
	}

}
