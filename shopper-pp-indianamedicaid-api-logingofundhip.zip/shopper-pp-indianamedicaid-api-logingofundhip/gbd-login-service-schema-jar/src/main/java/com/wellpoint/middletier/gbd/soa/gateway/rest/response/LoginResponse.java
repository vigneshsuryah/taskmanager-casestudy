/**
 * LoginResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 10/24/2018  2.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class LoginResponse extends BaseResponse
{
    private boolean loginSuccess;
    private boolean authFlag;
    private String smErrorCode;
    
	/**
	 * @return the smErrorCode
	 */
	public String getSmErrorCode()
	{
		return smErrorCode;
	}
	/**
	 * @param smErrorCode the smErrorCode to set
	 */
	public void setSmErrorCode(String smErrorCode)
	{
		this.smErrorCode = smErrorCode;
	}
	/**
	 * @return the loginSuccess
	 */
	public boolean isLoginSuccess()
	{
		return loginSuccess;
	}
	/**
	 * @param loginSuccess the loginSuccess to set
	 */
	public void setLoginSuccess(boolean loginSuccess)
	{
		this.loginSuccess = loginSuccess;
	}
	/**
	 * @return the authFlag
	 */
	public boolean isAuthFlag()
	{
		return authFlag;
	}
	/**
	 * @param authFlag the authFlag to set
	 */
	public void setAuthFlag(boolean authFlag)
	{
		this.authFlag = authFlag;
	}
}
