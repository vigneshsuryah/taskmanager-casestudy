/**
 * Audit.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Audit {
	
	private AdaptAuthResponse adaptAuthResponse;

	private IpEvalResponse ipEvalResponse;
	
	private AccessHistoryResponse accessHistoryResponse;
	
	private DfpScoreResponse dfpScoreResponse;

	/**
	 * @return the adaptAuthResponse
	 */
	public AdaptAuthResponse getAdaptAuthResponse() {
		return adaptAuthResponse;
	}

	/**
	 * @param adaptAuthResponse the adaptAuthResponse to set
	 */
	public void setAdaptAuthResponse(AdaptAuthResponse adaptAuthResponse) {
		this.adaptAuthResponse = adaptAuthResponse;
	}

	/**
	 * @return the ipEvalResponse
	 */
	public IpEvalResponse getIpEvalResponse() {
		return ipEvalResponse;
	}

	/**
	 * @param ipEvalResponse the ipEvalResponse to set
	 */
	public void setIpEvalResponse(IpEvalResponse ipEvalResponse) {
		this.ipEvalResponse = ipEvalResponse;
	}

	/**
	 * @return the accessHistoryResponse
	 */
	public AccessHistoryResponse getAccessHistoryResponse() {
		return accessHistoryResponse;
	}

	/**
	 * @param accessHistoryResponse the accessHistoryResponse to set
	 */
	public void setAccessHistoryResponse(AccessHistoryResponse accessHistoryResponse) {
		this.accessHistoryResponse = accessHistoryResponse;
	}

	/**
	 * @return the dfpScoreResponse
	 */
	public DfpScoreResponse getDfpScoreResponse() {
		return dfpScoreResponse;
	}

	/**
	 * @param dfpScoreResponse the dfpScoreResponse to set
	 */
	public void setDfpScoreResponse(DfpScoreResponse dfpScoreResponse) {
		this.dfpScoreResponse = dfpScoreResponse;
	}

}
