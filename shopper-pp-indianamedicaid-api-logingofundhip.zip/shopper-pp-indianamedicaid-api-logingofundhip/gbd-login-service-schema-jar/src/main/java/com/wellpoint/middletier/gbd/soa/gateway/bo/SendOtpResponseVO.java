/**
 * SendOtpResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.wellpoint.middletier.gbd.soa.gateway.bo.SecureAuthResponse;

public class SendOtpResponseVO extends BaseResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1456889261915657058L;
	private SecureAuthResponse secureAuthResponse;

	public SecureAuthResponse getSecureAuthResponse()
	{
		return secureAuthResponse;
	}

	public void setSecureAuthResponse(SecureAuthResponse value)
	{
		this.secureAuthResponse = value;
	}
	
}
