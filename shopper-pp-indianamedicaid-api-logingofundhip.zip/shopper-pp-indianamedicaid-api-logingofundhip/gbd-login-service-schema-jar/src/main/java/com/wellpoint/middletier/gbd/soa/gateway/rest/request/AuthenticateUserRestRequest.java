/**
 * AuthenticateUserRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class AuthenticateUserRestRequest extends BaseRequest{

	
	private String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
