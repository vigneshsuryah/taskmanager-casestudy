/**
 * ThreadApiRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ThreadApiRequestVO extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7293404197675604491L;
	
	private FingerPrint fingerprint;
	
	private String transientUserNm;

	/**
	 * @return the fingerprint
	 */
	public FingerPrint getFingerprint() {
		return fingerprint;
	}

	/**
	 * @param fingerprint the fingerprint to set
	 */
	public void setFingerprint(FingerPrint fingerprint) {
		this.fingerprint = fingerprint;
	}

	/**
	 * @return the transientUserNm
	 */
	public String getTransientUserNm() {
		return transientUserNm;
	}

	/**
	 * @param transientUserNm the transientUserNm to set
	 */
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}
	
}
