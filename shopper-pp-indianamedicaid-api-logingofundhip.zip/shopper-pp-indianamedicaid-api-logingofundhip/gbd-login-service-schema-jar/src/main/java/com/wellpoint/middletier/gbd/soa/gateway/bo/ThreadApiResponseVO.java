/**
 * ThreadApiResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ThreadApiResponseVO extends BaseResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7833117321638042385L;

	private String status;
	
	private String suggestedAction;
	
	private String suggestedActionDesc;
	
	private String promptForDeviceUpdate;
	
	private String fingerprintId;
	
	private Audit audit;
	
	private String transientUserNm;
	
	private String accessHistoryStatus;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the suggestedAction
	 */
	public String getSuggestedAction() {
		return suggestedAction;
	}

	/**
	 * @param suggestedAction the suggestedAction to set
	 */
	public void setSuggestedAction(String suggestedAction) {
		this.suggestedAction = suggestedAction;
	}

	/**
	 * @return the suggestedActionDesc
	 */
	public String getSuggestedActionDesc() {
		return suggestedActionDesc;
	}

	/**
	 * @param suggestedActionDesc the suggestedActionDesc to set
	 */
	public void setSuggestedActionDesc(String suggestedActionDesc) {
		this.suggestedActionDesc = suggestedActionDesc;
	}

	/**
	 * @return the promptForDeviceUpdate
	 */
	public String getPromptForDeviceUpdate() {
		return promptForDeviceUpdate;
	}

	/**
	 * @param promptForDeviceUpdate the promptForDeviceUpdate to set
	 */
	public void setPromptForDeviceUpdate(String promptForDeviceUpdate) {
		this.promptForDeviceUpdate = promptForDeviceUpdate;
	}

	/**
	 * @return the fingerprintId
	 */
	public String getFingerprintId() {
		return fingerprintId;
	}

	/**
	 * @param fingerprintId the fingerprintId to set
	 */
	public void setFingerprintId(String fingerprintId) {
		this.fingerprintId = fingerprintId;
	}

	/**
	 * @return the audit
	 */
	public Audit getAudit() {
		return audit;
	}

	/**
	 * @param audit the audit to set
	 */
	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	/**
	 * @return the transientUserNm
	 */
	public String getTransientUserNm() {
		return transientUserNm;
	}

	/**
	 * @param transientUserNm the transientUserNm to set
	 */
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}

	/**
	 * @return the accessHistoryStatus
	 */
	public String getAccessHistoryStatus() {
		return accessHistoryStatus;
	}

	/**
	 * @param accessHistoryStatus the accessHistoryStatus to set
	 */
	public void setAccessHistoryStatus(String accessHistoryStatus) {
		this.accessHistoryStatus = accessHistoryStatus;
	}
	
}
