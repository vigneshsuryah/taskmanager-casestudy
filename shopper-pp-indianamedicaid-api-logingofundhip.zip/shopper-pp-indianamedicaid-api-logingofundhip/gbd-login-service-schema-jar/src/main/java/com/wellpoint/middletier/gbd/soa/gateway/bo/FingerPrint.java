/**
 * FingerPrintVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class FingerPrint extends BaseRequest{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5864963713994753693L;

	private UaBrowser uaBrowser;
	
	private String uaString;
	
	private UaDevice uaDevice;
	
	private UaEngine uaEngine;
	
	private UaOS uaOS;
	
	private UaCPU uaCPU;
	
	private String uaPlatform;
	
	private String language;
	
	private String colorDepth;
	
	private String pixelRatio;
	
	private String screenResolution;
	
	private String availableScreenResolution;
	
	private String timezone;
	
	private String timezoneOffset;
	
	private String localStorage;
	
	private String sessionStorage;
	
	private String indexedDb;
	
	private String addBehavior;
	
	private String openDatabase;
	
	private String cpuClass;
	
	private String platform;
	
	private String doNotTrack;
	
	private String plugins;
	
	private String canvas;
	
	private String webGl;
	
	private String adBlock;
	
	private String userTamperLanguage;
	
	private String userTamperScreenResolution;
	
	private String userTamperOS;
	
	private String userTamperBrowser;
	
	private TouchSupport touchSupport;
	
	private String cookieSupport;
	
	private String fonts;

	/**
	 * @return the uaBrowser
	 */
	public UaBrowser getUaBrowser() {
		return uaBrowser;
	}

	/**
	 * @param uaBrowser the uaBrowser to set
	 */
	public void setUaBrowser(UaBrowser uaBrowser) {
		this.uaBrowser = uaBrowser;
	}

	/**
	 * @return the uaString
	 */
	public String getUaString() {
		return uaString;
	}

	/**
	 * @param uaString the uaString to set
	 */
	public void setUaString(String uaString) {
		this.uaString = uaString;
	}

	/**
	 * @return the uaDevice
	 */
	public UaDevice getUaDevice() {
		return uaDevice;
	}

	/**
	 * @param uaDevice the uaDevice to set
	 */
	public void setUaDevice(UaDevice uaDevice) {
		this.uaDevice = uaDevice;
	}

	/**
	 * @return the uaEngine
	 */
	public UaEngine getUaEngine() {
		return uaEngine;
	}

	/**
	 * @param uaEngine the uaEngine to set
	 */
	public void setUaEngine(UaEngine uaEngine) {
		this.uaEngine = uaEngine;
	}

	/**
	 * @return the uaOS
	 */
	public UaOS getUaOS() {
		return uaOS;
	}

	/**
	 * @param uaOS the uaOS to set
	 */
	public void setUaOS(UaOS uaOS) {
		this.uaOS = uaOS;
	}

	/**
	 * @return the uaCPU
	 */
	public UaCPU getUaCPU() {
		return uaCPU;
	}

	/**
	 * @param uaCPU the uaCPU to set
	 */
	public void setUaCPU(UaCPU uaCPU) {
		this.uaCPU = uaCPU;
	}

	/**
	 * @return the uaPlatform
	 */
	public String getUaPlatform() {
		return uaPlatform;
	}

	/**
	 * @param uaPlatform the uaPlatform to set
	 */
	public void setUaPlatform(String uaPlatform) {
		this.uaPlatform = uaPlatform;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the colorDepth
	 */
	public String getColorDepth() {
		return colorDepth;
	}

	/**
	 * @param colorDepth the colorDepth to set
	 */
	public void setColorDepth(String colorDepth) {
		this.colorDepth = colorDepth;
	}

	/**
	 * @return the pixelRatio
	 */
	public String getPixelRatio() {
		return pixelRatio;
	}

	/**
	 * @param pixelRatio the pixelRatio to set
	 */
	public void setPixelRatio(String pixelRatio) {
		this.pixelRatio = pixelRatio;
	}

	/**
	 * @return the screenResolution
	 */
	public String getScreenResolution() {
		return screenResolution;
	}

	/**
	 * @param screenResolution the screenResolution to set
	 */
	public void setScreenResolution(String screenResolution) {
		this.screenResolution = screenResolution;
	}

	/**
	 * @return the availableScreenResolution
	 */
	public String getAvailableScreenResolution() {
		return availableScreenResolution;
	}

	/**
	 * @param availableScreenResolution the availableScreenResolution to set
	 */
	public void setAvailableScreenResolution(String availableScreenResolution) {
		this.availableScreenResolution = availableScreenResolution;
	}

	/**
	 * @return the timezone
	 */
	public String getTimezone() {
		return timezone;
	}

	/**
	 * @param timezone the timezone to set
	 */
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	/**
	 * @return the timezoneOffset
	 */
	public String getTimezoneOffset() {
		return timezoneOffset;
	}

	/**
	 * @param timezoneOffset the timezoneOffset to set
	 */
	public void setTimezoneOffset(String timezoneOffset) {
		this.timezoneOffset = timezoneOffset;
	}

	/**
	 * @return the localStorage
	 */
	public String getLocalStorage() {
		return localStorage;
	}

	/**
	 * @param localStorage the localStorage to set
	 */
	public void setLocalStorage(String localStorage) {
		this.localStorage = localStorage;
	}

	/**
	 * @return the sessionStorage
	 */
	public String getSessionStorage() {
		return sessionStorage;
	}

	/**
	 * @param sessionStorage the sessionStorage to set
	 */
	public void setSessionStorage(String sessionStorage) {
		this.sessionStorage = sessionStorage;
	}

	/**
	 * @return the indexedDb
	 */
	public String getIndexedDb() {
		return indexedDb;
	}

	/**
	 * @param indexedDb the indexedDb to set
	 */
	public void setIndexedDb(String indexedDb) {
		this.indexedDb = indexedDb;
	}

	/**
	 * @return the addBehavior
	 */
	public String getAddBehavior() {
		return addBehavior;
	}

	/**
	 * @param addBehavior the addBehavior to set
	 */
	public void setAddBehavior(String addBehavior) {
		this.addBehavior = addBehavior;
	}

	/**
	 * @return the openDatabase
	 */
	public String getOpenDatabase() {
		return openDatabase;
	}

	/**
	 * @param openDatabase the openDatabase to set
	 */
	public void setOpenDatabase(String openDatabase) {
		this.openDatabase = openDatabase;
	}

	/**
	 * @return the cpuClass
	 */
	public String getCpuClass() {
		return cpuClass;
	}

	/**
	 * @param cpuClass the cpuClass to set
	 */
	public void setCpuClass(String cpuClass) {
		this.cpuClass = cpuClass;
	}

	/**
	 * @return the platform
	 */
	public String getPlatform() {
		return platform;
	}

	/**
	 * @param platform the platform to set
	 */
	public void setPlatform(String platform) {
		this.platform = platform;
	}

	/**
	 * @return the doNotTrack
	 */
	public String getDoNotTrack() {
		return doNotTrack;
	}

	/**
	 * @param doNotTrack the doNotTrack to set
	 */
	public void setDoNotTrack(String doNotTrack) {
		this.doNotTrack = doNotTrack;
	}

	/**
	 * @return the plugins
	 */
	public String getPlugins() {
		return plugins;
	}

	/**
	 * @param plugins the plugins to set
	 */
	public void setPlugins(String plugins) {
		this.plugins = plugins;
	}

	/**
	 * @return the canvas
	 */
	public String getCanvas() {
		return canvas;
	}

	/**
	 * @param canvas the canvas to set
	 */
	public void setCanvas(String canvas) {
		this.canvas = canvas;
	}

	/**
	 * @return the webGl
	 */
	public String getWebGl() {
		return webGl;
	}

	/**
	 * @param webGl the webGl to set
	 */
	public void setWebGl(String webGl) {
		this.webGl = webGl;
	}

	/**
	 * @return the adBlock
	 */
	public String getAdBlock() {
		return adBlock;
	}

	/**
	 * @param adBlock the adBlock to set
	 */
	public void setAdBlock(String adBlock) {
		this.adBlock = adBlock;
	}

	/**
	 * @return the userTamperLanguage
	 */
	public String getUserTamperLanguage() {
		return userTamperLanguage;
	}

	/**
	 * @param userTamperLanguage the userTamperLanguage to set
	 */
	public void setUserTamperLanguage(String userTamperLanguage) {
		this.userTamperLanguage = userTamperLanguage;
	}

	/**
	 * @return the userTamperScreenResolution
	 */
	public String getUserTamperScreenResolution() {
		return userTamperScreenResolution;
	}

	/**
	 * @param userTamperScreenResolution the userTamperScreenResolution to set
	 */
	public void setUserTamperScreenResolution(String userTamperScreenResolution) {
		this.userTamperScreenResolution = userTamperScreenResolution;
	}

	/**
	 * @return the userTamperOS
	 */
	public String getUserTamperOS() {
		return userTamperOS;
	}

	/**
	 * @param userTamperOS the userTamperOS to set
	 */
	public void setUserTamperOS(String userTamperOS) {
		this.userTamperOS = userTamperOS;
	}

	/**
	 * @return the userTamperBrowser
	 */
	public String getUserTamperBrowser() {
		return userTamperBrowser;
	}

	/**
	 * @param userTamperBrowser the userTamperBrowser to set
	 */
	public void setUserTamperBrowser(String userTamperBrowser) {
		this.userTamperBrowser = userTamperBrowser;
	}

	/**
	 * @return the touchSupport
	 */
	public TouchSupport getTouchSupport() {
		return touchSupport;
	}

	/**
	 * @param touchSupport the touchSupport to set
	 */
	public void setTouchSupport(TouchSupport touchSupport) {
		this.touchSupport = touchSupport;
	}

	/**
	 * @return the cookieSupport
	 */
	public String getCookieSupport() {
		return cookieSupport;
	}

	/**
	 * @param cookieSupport the cookieSupport to set
	 */
	public void setCookieSupport(String cookieSupport) {
		this.cookieSupport = cookieSupport;
	}

	/**
	 * @return the fonts
	 */
	public String getFonts() {
		return fonts;
	}

	/**
	 * @param fonts the fonts to set
	 */
	public void setFonts(String fonts) {
		this.fonts = fonts;
	}
	
}
