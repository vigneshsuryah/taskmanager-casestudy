/**
 * IPAudit.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 24/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IPAudit {
	
	private int risk_factor;
	private String country;
	private String country_code;
	private String internet_service_provider;
	private String organization;

	/**
	 * @return the risk_factor
	 */
	public int getRisk_factor() {
		return risk_factor;
	}

	/**
	 * @param risk_factor the risk_factor to set
	 */
	public void setRisk_factor(int risk_factor) {
		this.risk_factor = risk_factor;
	}
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public String getInternet_service_provider() {
		return internet_service_provider;
	}

	public void setInternet_service_provider(String internet_service_provider) {
		this.internet_service_provider = internet_service_provider;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

}
