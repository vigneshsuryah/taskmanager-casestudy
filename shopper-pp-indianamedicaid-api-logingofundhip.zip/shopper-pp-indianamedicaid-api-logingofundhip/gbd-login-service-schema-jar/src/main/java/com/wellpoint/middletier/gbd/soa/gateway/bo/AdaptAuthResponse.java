/**
 * AdaptAuthResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 24/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdaptAuthResponse {
	
	private String realm_workflow;
	
	private String suggested_action;
	
	private String status;
	
	private String message;

	/**
	 * @return the realm_workflow
	 */
	public String getRealm_workflow() {
		return realm_workflow;
	}

	/**
	 * @param realm_workflow the realm_workflow to set
	 */
	public void setRealm_workflow(String realm_workflow) {
		this.realm_workflow = realm_workflow;
	}

	/**
	 * @return the suggested_action
	 */
	public String getSuggested_action() {
		return suggested_action;
	}

	/**
	 * @param suggested_action the suggested_action to set
	 */
	public void setSuggested_action(String suggested_action) {
		this.suggested_action = suggested_action;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
}
