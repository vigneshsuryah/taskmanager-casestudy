/**
* MemberPayTransLog.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.soa.gateway.bo;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


public class MbrPayTransLog implements Serializable
{
	private static final long serialVersionUID = -5154713930571769197L;
 
	private String hcid;
	private String sbrUid;	
	private String channel;
	private String operationName;
	private String requestXML;
	private String responseXML;
	private String errorMsg;
	private Date createdDate;
	private String requestingSystem;
	private Date requestTs;
	private Date responseTs;
	
	
	public String getSbrUid()
	{
		return sbrUid;
	}

	public void setSbrUid(String sbrUid)
	{
		this.sbrUid = sbrUid;
	}

	public Date getRequestTs()
	{
		return requestTs;
	}

	public void setRequestTs(Date requestTs)
	{
		this.requestTs = requestTs;
	}

	public Date getResponseTs()
	{
		return responseTs;
	}

	public void setResponseTs(Date responseTs)
	{
		this.responseTs = responseTs;
	}
	
	public String getRequestingSystem() {
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
 

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public String getChannel()
	{
		return channel;
	}

	public void setChannel(String channel)
	{
		this.channel = channel;
	}

	public String getOperationName()
	{
		return operationName;
	}

	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}

	public String getRequestXML()
	{
		return requestXML;
	}

	public void setRequestXML(String requestXML)
	{
		this.requestXML = requestXML;
	}

	public String getResponseXML()
	{
		return responseXML;
	}

	public void setResponseXML(String responseXML)
	{
		this.responseXML = responseXML;
	}

	public String getErrorMsg()
	{
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	public Date getCreatedDate()
	{
		return createdDate;
	}

	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

 
}
