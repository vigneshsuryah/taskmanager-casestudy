/**
 * ModifyAttributes.class
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ModifyAttributes {

	private ModifyAttributeEnum modifyAttributeEnum;
	private String[] values;
	private ModifyTypeEnum modifyTypeEnum;
	public ModifyAttributeEnum getModifyAttributeEnum() {
		return modifyAttributeEnum;
	}
	public void setModifyAttributeEnum(ModifyAttributeEnum modifyAttributeEnum) {
		this.modifyAttributeEnum = modifyAttributeEnum;
	}
	
	public String[] getValues() {
		return values;
	}
	public void setValues(String[] values) {
		this.values = values;
	}
	public ModifyTypeEnum getModifyTypeEnum() {
		return modifyTypeEnum;
	}
	public void setModifyTypeEnum(ModifyTypeEnum modifyTypeEnum) {
		this.modifyTypeEnum = modifyTypeEnum;
	}
	
	
	
}
