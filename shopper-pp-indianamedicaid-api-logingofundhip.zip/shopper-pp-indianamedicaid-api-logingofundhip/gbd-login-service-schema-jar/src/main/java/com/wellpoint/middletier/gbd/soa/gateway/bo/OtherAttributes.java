/**
 * OtherAttributes.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OtherAttributes {

	private String Name;
	private String Value;
	
	/**
	 * @return the Name
	 */
	public String getName() {
		return Name;
	}
	
	/**
	 * @param name the Name to set
	 */
	public void setName(String name) {
		Name = name;
	}
	
	/**
	 * @return the Value
	 */
	public String getValue() {
		return Value;
	}
	
	/**
	 * @param value the Value to set
	 */
	public void setValue(String value) {
		Value = value;
	}
	
}

