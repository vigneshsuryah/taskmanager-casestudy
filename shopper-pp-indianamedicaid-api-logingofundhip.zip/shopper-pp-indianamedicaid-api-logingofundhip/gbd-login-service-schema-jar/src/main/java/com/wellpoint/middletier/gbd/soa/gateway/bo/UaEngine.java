/**
 * UaEngine.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class UaEngine {
	
	private String name;
	
	private String version;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
}
