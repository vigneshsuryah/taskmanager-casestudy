/**
 * AuthenticateUserRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class AuthenticateUserRequestVO extends BaseRequest{
	
	private static final long serialVersionUID = 1632336806922664210L;
	private UserRoleEnum userRoleEnum;
	private RepositoryEnum repositoryEnum;
	private String username;
	private String password;
	public UserRoleEnum getUserRoleEnum() {
		return userRoleEnum;
	}
	public void setUserRoleEnum(UserRoleEnum userRoleEnum) {
		this.userRoleEnum = userRoleEnum;
	}
	public RepositoryEnum getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
