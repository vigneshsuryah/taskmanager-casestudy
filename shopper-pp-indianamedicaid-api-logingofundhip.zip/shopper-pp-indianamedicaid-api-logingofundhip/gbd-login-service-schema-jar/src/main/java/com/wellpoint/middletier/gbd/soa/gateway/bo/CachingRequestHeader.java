/**
 * CachingRequestHeader.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class CachingRequestHeader
 {

	private boolean forceLiveResponse;

	public boolean isForceLiveResponse() {
		return forceLiveResponse;
	}

	public void setForceLiveResponse(boolean forceLiveResponse) {
		this.forceLiveResponse = forceLiveResponse;
	}

	private int thresholdTime;

	public int getThresholdTime() {
		return thresholdTime;
	}

	public void setThresholdTime(int thresholdTime) {
		this.thresholdTime = thresholdTime;
	}
}
