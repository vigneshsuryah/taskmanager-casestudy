/**
 * ChangePasswordRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ChangePasswordRequestVO extends BaseRequest{

	private static final long serialVersionUID = 5245439675382386815L;
	
	private String username;
	private String iamGuid;
	private String dn;
	private String currentPassword;
	private String newPassword;
	private RepositoryEnum repositoryEnum;
	private UserRoleEnum userRoleEnum;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getIamGuid() {
		return iamGuid;
	}
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getCurrentPassword() {
		return currentPassword;
	}
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public RepositoryEnum getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	public UserRoleEnum getUserRoleEnum() {
		return userRoleEnum;
	}
	public void setUserRoleEnum(UserRoleEnum userRoleEnum) {
		this.userRoleEnum = userRoleEnum;
	}
	
}
