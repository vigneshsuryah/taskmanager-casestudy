package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class APIExceptions {
	private Exceptions[] exceptions;

	public Exceptions[] getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions[] exceptions) {
		this.exceptions = exceptions;
	}
}