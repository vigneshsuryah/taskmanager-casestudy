/**
 * GetSecretQuestionsRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class GetSecretQuestionsRestResponse extends BaseResponse {
	
	private String[] secretQuestions;

	public String[] getSecretQuestions() {
		return secretQuestions;
	}

	public void setSecretQuestions(String[] secretQuestions) {
		this.secretQuestions = secretQuestions;
	}
	
}
