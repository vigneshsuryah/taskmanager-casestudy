/**
 * SearchUserFilter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class SearchUserFilter {

	private UserRoleEnum[] userRoleEnum;
	private RepositoryEnum[] repositoryEnum;
	private String username;
	public UserRoleEnum[] getUserRoleEnum() {
		return userRoleEnum;
	}
	public void setUserRoleEnum(UserRoleEnum[] userRoleEnum) {
		this.userRoleEnum = userRoleEnum;
	}
	public RepositoryEnum[] getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum[] repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
