/**
 * UserAccountStatus.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserAccountStatus {

	private boolean disabled;
	private boolean locked;
	private boolean forceChangePassword;
	private int badSecretAnsCount;
	private int badPasswordCount;
	private Date lastLoginTime;
	private String comments;
	private boolean isUserNameValid;
	private boolean isSecretQuestionValid;

	/**
	 * @return the disabled
	 */
	public boolean isDisabled() {
		return disabled;
	}

	/**
	 * @param disabled
	 *            the disabled to set
	 */
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	

	/**
	 * @return the locked
	 */
	public boolean isLocked() {
		return locked;
	}

	/**
	 * @param locked the userNameValid to set
	 */
	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public boolean isForceChangePassword() {
		return forceChangePassword;
	}

	public void setForceChangePassword(boolean forceChangePassword) {
		this.forceChangePassword = forceChangePassword;
	}

	public int getBadSecretAnsCount() {
		return badSecretAnsCount;
	}

	public void setBadSecretAnsCount(int badSecretAnsCount) {
		this.badSecretAnsCount = badSecretAnsCount;
	}

	/**
	 * @return the badPasswordCount
	 */
	public int getBadPasswordCount() {
		return badPasswordCount;
	}

	/**
	 * @param badPasswordCount
	 *            the badPasswordCount to set
	 */
	public void setBadPasswordCount(int badPasswordCount) {
		this.badPasswordCount = badPasswordCount;
	}

	/**
	 * @return the lastLoginTime
	 */
	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	/**
	 * @param lastLoginTime
	 *            the lastLoginTime to set
	 */
	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public boolean isUserNameValid() {
		return isUserNameValid;
	}

	public void setUserNameValid(boolean isUserNameValid) {
		this.isUserNameValid = isUserNameValid;
	}

	public boolean isSecretQuestionValid() {
		return isSecretQuestionValid;
	}

	public void setSecretQuestionValid(boolean isSecretQuestionValid) {
		this.isSecretQuestionValid = isSecretQuestionValid;
	}

}
