package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SecureAuthResponse {

	private AdhocOTPAudit adhocOTPAudit;
	private String count;
	private ThrottleAudit throttleAudit;
	private ValidateOtpAudit validateOtpAudit;
	private UsersAudit usersAudit;
	
	public AdhocOTPAudit getAdhocOTPAudit() {
		return adhocOTPAudit;
	}
	public void setAdhocOTPAudit(AdhocOTPAudit value) {
		this.adhocOTPAudit = value;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public ThrottleAudit getThrottleAudit() {
		return throttleAudit;
	}
	public void setThrottleAudit(ThrottleAudit value) {
		this.throttleAudit = value;
	}
	public ValidateOtpAudit getValidateOtpAudit() {
		return validateOtpAudit;
	}
	public void setValidateOtpAudit(ValidateOtpAudit value) {
		this.validateOtpAudit = value;
	}
	public UsersAudit getUsersAudit() {
		return usersAudit;
	}
	public void setUsersAudit(UsersAudit value) {
		this.usersAudit = value;
	}

}
