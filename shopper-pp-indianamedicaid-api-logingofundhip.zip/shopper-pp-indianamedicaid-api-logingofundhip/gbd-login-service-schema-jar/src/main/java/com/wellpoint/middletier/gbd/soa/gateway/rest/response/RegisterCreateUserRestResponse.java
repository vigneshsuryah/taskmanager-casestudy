/**
 * RegisterCreateUserRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class RegisterCreateUserRestResponse extends BaseResponse {

	private boolean createUserStatus;
	
	public boolean isCreateUserStatus() {
		return createUserStatus;
	}
	public void setCreateUserStatus(boolean createUserStatus) {
		this.createUserStatus = createUserStatus;
	}
}
