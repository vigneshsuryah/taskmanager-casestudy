/**
* GbdException.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 07/07/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.soa.gateway.bo;


import java.io.Serializable;

public class GbdException extends Exception implements Serializable
{

	private static final long serialVersionUID = -2848300257012566378L;

	private final String errorCode;
	private final String errorType;
	private final String errorMessage;
	private final int returnStatus;
	
	public GbdException(String errorType,String errorCode, String errorMessage, int returnStatus)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorType = errorType;
		this.returnStatus = returnStatus;
	}

	public APIExceptions transformException() {
		APIExceptions restError = new APIExceptions();
		Exceptions newException = new Exceptions();
		newException.setType(this.errorType);
		newException.setCode(this.errorCode);
		newException.setMessage(this.errorMessage);
		newException.setDetail(this.errorMessage);
		Exceptions exceptions[] = new Exceptions[1];
		exceptions[0] = newException;
		restError.setExceptions(exceptions);
		return restError;
	}

	public int getReturnStatus() {
		return returnStatus;
	}
}
