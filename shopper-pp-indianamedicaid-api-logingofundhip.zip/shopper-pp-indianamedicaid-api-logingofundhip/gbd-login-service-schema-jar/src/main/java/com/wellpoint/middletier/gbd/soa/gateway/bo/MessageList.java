/**
 * MessageList.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

@SuppressWarnings({"rawtypes","unchecked"})
public class MessageList implements Serializable {

	private static final long serialVersionUID = 5029833791286596261L;
	private List messages = new LinkedList();

	public MessageList() {
		super();
	}

	public void addObjectMessage(String objectName, String code,
			String defaultMessage) {
		messages.add(new ObjectError(objectName, new String[] { code }, null,
				defaultMessage));
	}

	public void addObjectMessage(String objectName, String code,
			Object[] arguments, String defaultMessage) {
		messages.add(new ObjectError(objectName, new String[] { code },
				arguments, defaultMessage));
	}

	public void addObjectMessage(String objectName, String code,
			String argument, String defaultMessage) {
		messages.add(new ObjectError(objectName, new String[] { code },
				new String[] { argument }, defaultMessage));
	}

	public void addFieldMessage(String objectName, String fieldName,
			String code, String defaultMessage) {
		messages.add(new FieldError(objectName, fieldName, null, false,
				new String[] { code }, null, defaultMessage));
	}

	public List getMessages() {
		return messages;
	}
	
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
