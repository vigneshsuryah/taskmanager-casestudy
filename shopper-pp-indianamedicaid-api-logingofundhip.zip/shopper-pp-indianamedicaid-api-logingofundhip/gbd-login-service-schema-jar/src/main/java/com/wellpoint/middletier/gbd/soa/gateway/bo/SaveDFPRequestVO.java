/**
 * SaveDFPRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 23/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class SaveDFPRequestVO extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7293404197675604491L;
	
	private String transientUserNm;
	
	private FingerPrint fingerprint;

	/**
	 * @return the transientUserNm
	 */
	public String getTransientUserNm() {
		return transientUserNm;
	}

	/**
	 * @param transientUserNm the transientUserNm to set
	 */
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}

	/**
	 * @return the fingerprint
	 */
	public FingerPrint getFingerprint() {
		return fingerprint;
	}

	/**
	 * @param fingerprint the fingerprint to set
	 */
	public void setFingerprint(FingerPrint fingerprint) {
		this.fingerprint = fingerprint;
	}
	
}
