/**
 * UpdateAuthFlagRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 23/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class UpdateAuthFlagRestResponse extends BaseResponse {

	private boolean updateStatus;

	/**
	 * @return the updateStatus
	 */
	public boolean isUpdateStatus() {
		return updateStatus;
	}

	/**
	 * @param updateStatus the updateStatus to set
	 */
	public void setUpdateStatus(boolean updateStatus) {
		this.updateStatus = updateStatus;
	}

}
