/**
 * SendOtpRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class SendOtpRestRequest extends BaseRequest{
	
	private String transientUserNm;
	private String channel;
	private String recoveryContact;
	
	public String getTransientUserNm() {
		return transientUserNm;
	}
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRecoveryContact() {
		return recoveryContact;
	}
	public void setRecoveryContact(String recoveryContact) {
		this.recoveryContact = recoveryContact;
	}
	
}
