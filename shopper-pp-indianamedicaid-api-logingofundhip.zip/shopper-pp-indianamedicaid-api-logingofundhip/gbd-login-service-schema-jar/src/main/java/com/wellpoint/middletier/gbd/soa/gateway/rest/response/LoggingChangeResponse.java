/**
* LoggingChangeResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 05/02/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;


public class LoggingChangeResponse
{

	private static final long serialVersionUID = -7634428706697495544L;

	private String changeStatus;

	public String getChangeStatus() {
		return changeStatus;
	}

	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}
	

}
