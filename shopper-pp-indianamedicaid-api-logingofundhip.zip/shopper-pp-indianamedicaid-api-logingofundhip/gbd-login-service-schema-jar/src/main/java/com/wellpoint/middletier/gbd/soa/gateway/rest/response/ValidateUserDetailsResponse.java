/**
 * ValidateUserDetailsResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 10/24/2018  2.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class ValidateUserDetailsResponse extends BaseResponse
{
	private boolean userNameFound;
	private boolean emailIdFound;
	private boolean phoneNoFound;
	/**
	 * @return the userNameFound
	 */
	public boolean isUserNameFound()
	{
		return userNameFound;
	}
	/**
	 * @param userNameFound the userNameFound to set
	 */
	public void setUserNameFound(boolean userNameFound)
	{
		this.userNameFound = userNameFound;
	}
	/**
	 * @return the emailIdFound
	 */
	public boolean isEmailIdFound()
	{
		return emailIdFound;
	}
	/**
	 * @param emailIdFound the emailIdFound to set
	 */
	public void setEmailIdFound(boolean emailIdFound)
	{
		this.emailIdFound = emailIdFound;
	}
	/**
	 * @return the phoneNoFound
	 */
	public boolean isPhoneNoFound()
	{
		return phoneNoFound;
	}
	/**
	 * @param phoneNoFound the phoneNoFound to set
	 */
	public void setPhoneNoFound(boolean phoneNoFound)
	{
		this.phoneNoFound = phoneNoFound;
	}
}
