/**
 * UpdateUserProfileRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 23/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class UpdateUserProfileRequestVO extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String transientUserNm;

	/**
	 * @return the transientUserNm
	 */
	public String getTransientUserNm() {
		return transientUserNm;
	}

	/**
	 * @param transientUserNm the transientUserNm to set
	 */
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}
	
}
