/**
 * BaseResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import java.io.Serializable;

public abstract class BaseResponse implements Serializable
{
	private static final long serialVersionUID = -1047856867327962473L;
	
	private ResponseContext responseContext;
	private APIExceptions apiException;

	public ResponseContext getResponseContext() {
		return responseContext;
	}

	public void setResponseContext(ResponseContext responseContext) {
		this.responseContext = responseContext;
	}

	public APIExceptions getApiException() {
		return apiException;
	}

	public void setApiException(APIExceptions apiException) {
		this.apiException = apiException;
	}

}

