/**
 * GetSecretQuestionsRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class GetSecretQuestionsRequestVO extends BaseRequest{

	private static final long serialVersionUID = 7857436285299753416L;
	
	private String dn;
	private RepositoryEnum repositoryEnum;
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public RepositoryEnum getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	
}
