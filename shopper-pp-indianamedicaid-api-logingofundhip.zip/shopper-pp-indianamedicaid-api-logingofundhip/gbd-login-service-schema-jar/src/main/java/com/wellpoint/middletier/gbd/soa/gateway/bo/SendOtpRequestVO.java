/**
 * SendOtpRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class SendOtpRequestVO extends BaseRequest{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1743426720359130662L;
	/*private String transientUserNm;*/
	private String channel;
	private String recoveryContact;
	
	/*public String getTransientUserNm() {
		return transientUserNm;
	}
	public void setTransientUserNm(String transientUserNm) {
		this.transientUserNm = transientUserNm;
	}*/
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRecoveryContact() {
		return recoveryContact;
	}
	public void setRecoveryContact(String recoveryContact) {
		this.recoveryContact = recoveryContact;
	}
	
}
