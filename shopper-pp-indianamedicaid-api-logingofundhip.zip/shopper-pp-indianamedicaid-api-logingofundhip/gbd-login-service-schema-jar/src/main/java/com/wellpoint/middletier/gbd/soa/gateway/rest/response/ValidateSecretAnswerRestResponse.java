/**
 * ValidateSecretAnswerRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

public class ValidateSecretAnswerRestResponse extends BaseResponse {
	
	private boolean validated;
	private int secretAnswerAttemptsLeft;
	public boolean isValidated() {
		return validated;
	}
	public void setValidated(boolean validated) {
		this.validated = validated;
	}
	public int getSecretAnswerAttemptsLeft() {
		return secretAnswerAttemptsLeft;
	}
	public void setSecretAnswerAttemptsLeft(int secretAnswerAttemptsLeft) {
		this.secretAnswerAttemptsLeft = secretAnswerAttemptsLeft;
	}
	
}
