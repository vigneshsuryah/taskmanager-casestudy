/**
 * RegisterCreateUserRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

import com.wellpoint.middletier.gbd.soa.gateway.bo.SecretQuestionAnswers;

public class RegisterCreateUserRestRequest extends BaseRequest {

	private String password;
	private String emailAddress;
	private SecretQuestionAnswers[] secretQuestionAnswers;
	private String orgName;
	private String orgType;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public SecretQuestionAnswers[] getSecretQuestionAnswers() {
		return secretQuestionAnswers;
	}
	public void setSecretQuestionAnswers(
			SecretQuestionAnswers[] secretQuestionAnswers) {
		this.secretQuestionAnswers = secretQuestionAnswers;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
}
