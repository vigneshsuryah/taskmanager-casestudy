/**
 * ValidateSecretAnswerResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ValidateSecretAnswerResponseVO extends BaseResponse{

	private static final long serialVersionUID = 1205307388055190443L;
	
	private boolean secretAnswerMatched;
	private int secretAnswerAttemptsLeft;
	
	public boolean isSecretAnswerMatched() {
		return secretAnswerMatched;
	}
	public void setSecretAnswerMatched(boolean secretAnswerMatched) {
		this.secretAnswerMatched = secretAnswerMatched;
	}
	public int getSecretAnswerAttemptsLeft() {
		return secretAnswerAttemptsLeft;
	}
	public void setSecretAnswerAttemptsLeft(int secretAnswerAttemptsLeft) {
		this.secretAnswerAttemptsLeft = secretAnswerAttemptsLeft;
	}
}
