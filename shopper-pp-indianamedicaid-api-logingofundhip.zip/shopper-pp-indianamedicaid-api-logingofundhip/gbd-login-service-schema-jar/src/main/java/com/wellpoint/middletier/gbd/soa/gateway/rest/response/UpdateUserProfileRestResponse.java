/**
 * UpdateUserProfileRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 23/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateUserProfileRestResponse extends BaseResponse {
	
	private String updateStatus;

	/**
	 * @return the updateStatus
	 */
	public String getUpdateStatus() {
		return updateStatus;
	}

	/**
	 * @param updateStatus the updateStatus to set
	 */
	public void setUpdateStatus(String updateStatus) {
		this.updateStatus = updateStatus;
	}
	
}
