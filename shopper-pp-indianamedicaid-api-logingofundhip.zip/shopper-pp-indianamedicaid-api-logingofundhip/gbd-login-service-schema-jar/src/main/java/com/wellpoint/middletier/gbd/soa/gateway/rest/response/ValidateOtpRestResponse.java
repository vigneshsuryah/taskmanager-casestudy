/**
 * ValidateOtpResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SecureAuthResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ValidateOtpRestResponse extends BaseResponse{
	
	private String valid;
	private String failureReason;
	private String count;
	private SecureAuthResponse secureAuthResponse; 
	
	public String getValid() {
		return valid;
	}
	public void setValid(String valid) {
		this.valid = valid;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public SecureAuthResponse getSecureAuthResponse() {
		return secureAuthResponse;
	}
	public void setSecureAuthResponse(SecureAuthResponse secureAuthResponse) {
		this.secureAuthResponse = secureAuthResponse;
	}

}
