/**
 * DfpScoreResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 24/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DfpScoreResponse {
	
	private String fingerprint_id;
	
	private String fingerprint_name;
	
	private String score;
	
	private String match_score;
	
	private String update_score;
	
	private String status;
	
	private String message;

	/**
	 * @return the fingerprint_id
	 */
	public String getFingerprint_id() {
		return fingerprint_id;
	}

	/**
	 * @param fingerprint_id the fingerprint_id to set
	 */
	public void setFingerprint_id(String fingerprint_id) {
		this.fingerprint_id = fingerprint_id;
	}

	/**
	 * @return the fingerprint_name
	 */
	public String getFingerprint_name() {
		return fingerprint_name;
	}

	/**
	 * @param fingerprint_name the fingerprint_name to set
	 */
	public void setFingerprint_name(String fingerprint_name) {
		this.fingerprint_name = fingerprint_name;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String score) {
		this.score = score;
	}

	/**
	 * @return the match_score
	 */
	public String getMatch_score() {
		return match_score;
	}

	/**
	 * @param match_score the match_score to set
	 */
	public void setMatch_score(String match_score) {
		this.match_score = match_score;
	}

	/**
	 * @return the update_score
	 */
	public String getUpdate_score() {
		return update_score;
	}

	/**
	 * @param update_score the update_score to set
	 */
	public void setUpdate_score(String update_score) {
		this.update_score = update_score;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
}
