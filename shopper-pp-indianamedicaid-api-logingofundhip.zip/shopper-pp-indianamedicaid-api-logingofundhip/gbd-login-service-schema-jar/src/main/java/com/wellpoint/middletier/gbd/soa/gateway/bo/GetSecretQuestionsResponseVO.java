/**
 * GetSecretQuestionsResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class GetSecretQuestionsResponseVO extends BaseResponse{

	private static final long serialVersionUID = -9033569073671437993L;
	
	private String[] secretQuestions;

	public String[] getSecretQuestions() {
		return secretQuestions;
	}

	public void setSecretQuestions(String[] secretQuestions) {
		this.secretQuestions = secretQuestions;
	}

}
