/**
 * TouchSupport.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class TouchSupport {
	
	private String maxTouchPoints;
	
	private String touchEvent;
	
	private String touchStart;

	/**
	 * @return the maxTouchPoints
	 */
	public String getMaxTouchPoints() {
		return maxTouchPoints;
	}

	/**
	 * @param maxTouchPoints the maxTouchPoints to set
	 */
	public void setMaxTouchPoints(String maxTouchPoints) {
		this.maxTouchPoints = maxTouchPoints;
	}

	/**
	 * @return the touchEvent
	 */
	public String getTouchEvent() {
		return touchEvent;
	}

	/**
	 * @param touchEvent the touchEvent to set
	 */
	public void setTouchEvent(String touchEvent) {
		this.touchEvent = touchEvent;
	}

	/**
	 * @return the touchStart
	 */
	public String getTouchStart() {
		return touchStart;
	}

	/**
	 * @param touchStart the touchStart to set
	 */
	public void setTouchStart(String touchStart) {
		this.touchStart = touchStart;
	}
	
}
