/**
 * ValidateSecretAnswerRestRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.rest.request;

public class ValidateSecretAnswerRestRequest extends BaseRequest{
	
	private String secretAnswerText1;
	private String secretAnswerText2;
	private String secretAnswerText3;
	private String iamGuid;
	private String dn;
	
	public String getSecretAnswerText1() {
		return secretAnswerText1;
	}
	public void setSecretAnswerText1(String secretAnswerText1) {
		this.secretAnswerText1 = secretAnswerText1;
	}
	public String getSecretAnswerText2() {
		return secretAnswerText2;
	}
	public void setSecretAnswerText2(String secretAnswerText2) {
		this.secretAnswerText2 = secretAnswerText2;
	}
	public String getSecretAnswerText3() {
		return secretAnswerText3;
	}
	public void setSecretAnswerText3(String secretAnswerText3) {
		this.secretAnswerText3 = secretAnswerText3;
	}
	public String getIamGuid() {
		return iamGuid;
	}
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	
}
