/**
 * SoaHeaders.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class SoaHeaders {
	
	private String senderapp;
	
	private String module;
	
	private String ipaddress;
	
	private String usernm;
	
	private String webguid;
	
	private String reqSys;

	/**
	 * @return the senderapp
	 */
	public String getSenderapp() {
		return senderapp;
	}

	/**
	 * @param senderapp the senderapp to set
	 */
	public void setSenderapp(String senderapp) {
		this.senderapp = senderapp;
	}

	/**
	 * @return the module
	 */
	public String getModule() {
		return module;
	}

	/**
	 * @param module the module to set
	 */
	public void setModule(String module) {
		this.module = module;
	}

	/**
	 * @return the ipaddress
	 */
	public String getIpaddress() {
		return ipaddress;
	}

	/**
	 * @param ipaddress the ipaddress to set
	 */
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	/**
	 * @return the usernm
	 */
	public String getUsernm() {
		return usernm;
	}

	/**
	 * @param usernm the usernm to set
	 */
	public void setUsernm(String usernm) {
		this.usernm = usernm;
	}

	/**
	 * @return the webguid
	 */
	public String getWebguid() {
		return webguid;
	}

	/**
	 * @param webguid the webguid to set
	 */
	public void setWebguid(String webguid) {
		this.webguid = webguid;
	}

	/**
	 * @return the reqSys
	 */
	public String getReqSys() {
		return reqSys;
	}

	/**
	 * @param reqSys the reqSys to set
	 */
	public void setReqSys(String reqSys) {
		this.reqSys = reqSys;
	}

}