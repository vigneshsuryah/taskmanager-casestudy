/**
 * GeneratePasswordRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 25/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class GeneratePasswordRequestVO extends BaseRequest{

	private static final long serialVersionUID = 1404221974033519498L;
	
	private String username;
	private String iamGuid;
	private String dn;
	private RepositoryEnum repositoryEnum;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getIamGuid() {
		return iamGuid;
	}
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public RepositoryEnum getRepositoryEnum() {
		return repositoryEnum;
	}
	public void setRepositoryEnum(RepositoryEnum repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}
	
}
