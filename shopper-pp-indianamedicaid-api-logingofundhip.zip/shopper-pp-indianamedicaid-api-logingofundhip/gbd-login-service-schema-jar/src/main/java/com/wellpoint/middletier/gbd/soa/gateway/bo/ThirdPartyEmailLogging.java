/**
* ThirdPartyEmailLogging
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 15/06/2017  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.soa.gateway.bo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ThirdPartyEmailLogging implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private BigDecimal emailLoggingId;
	private String hcid;
	private String sbrUID;
	private String fromId;
	private String toId;
	private String subject;
	private String templateId;
	private Date sentDate;
	private String dynamicContent;
	private String mailType;
	private String createdBy;
	private Date createdDate;
	private String requestingSystem;
	
	
	public BigDecimal getEmailLoggingId() {
		return emailLoggingId;
	}
	public void setEmailLoggingId(BigDecimal emailLoggingId) {
		this.emailLoggingId = emailLoggingId;
	}
	public String getHcid() {
		return hcid;
	}
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}
	public String getSbrUID() {
		return sbrUID;
	}
	public void setSbrUID(String sbrUID) {
		this.sbrUID = sbrUID;
	}
	public String getFromId() {
		return fromId;
	}
	public void setFromId(String fromId) {
		this.fromId = fromId;
	}
	public String getToId() {
		return toId;
	}
	public void setToId(String toId) {
		this.toId = toId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public Date getSentDate() {
		return sentDate;
	}
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
	public String getDynamicContent() {
		return dynamicContent;
	}
	public void setDynamicContent(String dynamicContent) {
		this.dynamicContent = dynamicContent;
	}
	public String getMailType() {
		return mailType;
	}
	public void setMailType(String mailType) {
		this.mailType = mailType;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getRequestingSystem() {
		return requestingSystem;
	}
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
	
}
