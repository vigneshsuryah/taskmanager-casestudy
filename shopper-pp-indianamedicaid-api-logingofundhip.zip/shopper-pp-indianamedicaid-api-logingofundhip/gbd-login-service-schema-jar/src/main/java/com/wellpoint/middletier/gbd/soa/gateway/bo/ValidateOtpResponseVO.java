/**
 * ValidateOtpResponseVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 22/10/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class ValidateOtpResponseVO extends BaseResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6340393451884643652L;
	private SecureAuthResponse secureAuthResponse;
	private String valid;
	private String failureReason;
	private String count;
	
	public String getValid() {
		return valid;
	}
	public void setValid(String valid) {
		this.valid = valid;
	}
	public String getFailureReason() {
		return failureReason;
	}
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public SecureAuthResponse getSecureAuthResponse() {
		return secureAuthResponse;
	}
	public void setSecureAuthResponse(SecureAuthResponse secureAuthResponse) {
		this.secureAuthResponse = secureAuthResponse;
	}
}
