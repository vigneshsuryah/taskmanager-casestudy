/**
 * SearchUserDetailsRequestVO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.soa.gateway.bo;

public class SearchUserDetailsRequestVO extends BaseRequest{
	
	private static final long serialVersionUID = -2936057228918293644L;
	
	private SearchUserFilter searchUserFilter;

	public SearchUserFilter getSearchUserFilter() {
		return searchUserFilter;
	}

	public void setSearchUserFilter(SearchUserFilter searchUserFilter) {
		this.searchUserFilter = searchUserFilter;
	}
	
}
