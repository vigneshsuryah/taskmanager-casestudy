/**
 * TwoFactorAuthController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 22/10/2018  1.0       Cognizant      Initial Version
 */
package com.wellpoint.ebiz.middletier.gbd.payment.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.service.TwoFactorAuthService;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.bo.SoaHeaders;
import com.wellpoint.middletier.gbd.soa.gateway.bo.User;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.LoginRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SaveDFPRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SendOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ThreadApiRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateOtpRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateUserDetailsRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetAttemptsRemainingRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.LoginResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SaveDFPRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SendOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ThreadApiRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateAuthFlagRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.UpdateUserProfileRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateOtpRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateUserDetailsResponse;

/**
 * This class contains list of rest services exposed for Two factor authentication
 * @author CTS
 */
@Controller
@RequestMapping("/soaservices/v1/tpp/2fa")
public class TwoFactorAuthController implements GbdSOAConstants  {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TwoFactorAuthController.class);

	@Autowired
	private TwoFactorAuthService twoFactorAuthServiceImpl;
	
	@RequestMapping(value = "/threatapi", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ThreadApiRestResponse threatapi(@RequestBody ThreadApiRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("Inside TwoFactorAuthController threatapi - Start");
		ThreadApiRestResponse response = null;
		try{
			request.setEndPointName(getModule(httpRequest) + "threatapi");
			
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setModule(getModule(httpRequest));
			soaHeaders.setIpaddress(getIpAddress(httpRequest));
			soaHeaders.setUsernm(getUsernm(httpRequest));
			soaHeaders.setReqSys(getReqSys(httpRequest));
			soaHeaders.setWebguid(getWebguid(httpRequest));
			
			response = twoFactorAuthServiceImpl.threatapi(request, soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in TwoFactorAuthController threatapi : "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.info("Inside TwoFactorAuthController threatapi - End");
		return response;
	}
	
	@RequestMapping(value = "/dfp/save", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SaveDFPRestResponse saveDfp(@RequestBody SaveDFPRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("Inside TwoFactorAuthController saveDfp - Start");
		SaveDFPRestResponse response = null;
		try{
			request.setEndPointName("saveDfp");
			
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setModule(getModule(httpRequest));
			soaHeaders.setIpaddress(getIpAddress(httpRequest));
			soaHeaders.setUsernm(getUsernm(httpRequest));
			
			response = twoFactorAuthServiceImpl.saveDfp(request, soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in TwoFactorAuthController saveDfp : "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.info("Inside TwoFactorAuthController saveDfp - End");
		return response;
	}

	@RequestMapping(value = "/otp/send", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SendOtpRestResponse sendOtp(@RequestBody SendOtpRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In sendOtp() of TwoFactorAuthController");
		
		SendOtpRestResponse response = null;
		request.setEndPointName("sendOtp");
		
		try{
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setModule(getModule(httpRequest));
			//soaHeaders.setWebguid(getWebguid(httpRequest));
			soaHeaders.setUsernm(getUsernm(httpRequest));
			soaHeaders.setReqSys(getReqSys(httpRequest));
			
			response = 	twoFactorAuthServiceImpl.sendOtp(request, soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in sendOtp() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of sendOtp() of TwoFactorAuthController");
		return response;
	}
	
	@RequestMapping(value = "/otp/validate", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateOtpRestResponse sendOtp(@RequestBody ValidateOtpRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In validateOtp() of TwoFactorAuthController");
		
		ValidateOtpRestResponse response = null;
		request.setEndPointName("validateOtp");
		
		try{
			
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setModule(getModule(httpRequest));
			//soaHeaders.setWebguid(getWebguid(httpRequest));
			soaHeaders.setUsernm(getUsernm(httpRequest));
			soaHeaders.setReqSys(getReqSys(httpRequest));
			
			response = 	twoFactorAuthServiceImpl.validateOtp(request, soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in validateOtp() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of validateOtp() of TwoFactorAuthController");
		return response;
	}

 	@RequestMapping(value = "/validateLoginInformation", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody LoginResponse validateLoginInformation(@RequestBody LoginRequest request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.debug("Start - validateLoginInformation() of TwoFactorAuthController");
		LoginResponse response = null;
		request.setEndPointName("validateLoginInformation");
		request.setRequestingSystem(getReqSys(httpRequest));
		try{
			response = 	twoFactorAuthServiceImpl.loginUser(request);
		}catch(Exception e){
			LOGGER.error("Exception in validateLoginInformation() of TwoFactorAuthController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End - validateLoginInformation() of TwoFactorAuthController");
		return response;
	}
 	
 	@RequestMapping(value = "/validateRegisterUserDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateUserDetailsResponse validateRegisterUserDetails(@RequestBody ValidateUserDetailsRequest request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.debug("Start - validateRegisterUserDetails() of TwoFactorAuthController");
		ValidateUserDetailsResponse response = null;
		request.setEndPointName("validateRegisterUserDetails");
		request.setRequestingSystem(getReqSys(httpRequest));
		try{
			response = 	twoFactorAuthServiceImpl.validateRegisterUserDetails(request);
		}catch(Exception e){
			LOGGER.error("Exception in validateRegisterUserDetails() of TwoFactorAuthController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("End - validateRegisterUserDetails() of TwoFactorAuthController");
		return response;
	}

	@RequestMapping(value = "/otp/attemptsRemaining", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetAttemptsRemainingRestResponse getAttemptsRemaining(@RequestBody LoginRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("Inside getAttemptsRemaining() of TwoFactorAuthController - Start");
		GetAttemptsRemainingRestResponse response = null;
		try{
			request.setEndPointName("attemptsRemaining");
			
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setUsernm(request.getUserName());
			soaHeaders.setWebguid(getWebguid(httpRequest));
			soaHeaders.setReqSys(getReqSys(httpRequest));
			
			response = 	twoFactorAuthServiceImpl.getAttemptsRemaining(soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in getAttemptsRemaining() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.info("Inside getAttemptsRemaining() of TwoFactorAuthController - End");
		return response;
	}
	
	@RequestMapping(value = "/users/profile", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody UpdateUserProfileRestResponse updateUserProfile(@RequestBody LoginRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("Inside updateUserProfile() of TwoFactorAuthController - Start");
		UpdateUserProfileRestResponse response = null;
		try{
			request.setEndPointName("updateUserProfile");
			
			SoaHeaders soaHeaders = new SoaHeaders();
			soaHeaders.setSenderapp(getSenderApp(httpRequest));
			soaHeaders.setUsernm(getUsernm(httpRequest));
			soaHeaders.setWebguid(getWebguid(httpRequest));
			soaHeaders.setReqSys(getReqSys(httpRequest));
			
			response = 	twoFactorAuthServiceImpl.updateUserProfile(request.getUserName(), soaHeaders);
		}catch(Exception e){
			LOGGER.error("Exception in updateUserProfile() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.info("Inside updateUserProfile() of TwoFactorAuthController - End");
		return response;
	}
	
	@RequestMapping(value = "/updateAuthFlag", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody UpdateAuthFlagRestResponse updateAuthFlag(@RequestBody LoginRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("Inside updateAuthFlag() of TwoFactorAuthController - Start");
		UpdateAuthFlagRestResponse response = null;
		try{
			request.setEndPointName("updateAuthFlag");
			request.setRequestingSystem(getReqSys(httpRequest));
			response = 	twoFactorAuthServiceImpl.updateAuthFlag(request);
		}catch(Exception e){
			LOGGER.error("Exception in updateAuthFlag() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("Inside updateAuthFlag() of TwoFactorAuthController - End");
		return response;
	}
	
	@RequestMapping(value = "/getChannelDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SearchUserDetailsRestResponse getChannelDetails(@RequestBody SearchUserDetailsRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In getChannelDetails() of TwoFactorAuthController");
		
		SearchUserDetailsRestResponse response = null;
		SearchUserDetailsRestResponse searchUserDetailsRestResponse = null;
		request.setEndPointName("getChannelDetails");

		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}

		try{
			response = 	twoFactorAuthServiceImpl.getRegisterUserDetails(request);
			if(null != response && response.getUser() != null){
				searchUserDetailsRestResponse = new SearchUserDetailsRestResponse();
				User user = new User();
				user.setEmailAddress(response.getUser().getEmailAddress());
				user.setUsername(response.getUser().getUsername());
				user.setPhoneNumber(response.getUser().getPhoneNumber());
				searchUserDetailsRestResponse.setUser(user);
			}
		}catch(Exception e){
			LOGGER.error("Exception in getChannelDetails() of TwoFactorAuthController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of getChannelDetails() of TwoFactorAuthController");
		return searchUserDetailsRestResponse;
	}
	
	private String getSenderApp(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("senderapp")) {
			return httpRequest.getHeader("senderapp");
		} else {
			return "";
		}
	}
	
	private String getModule(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("module")) {
			return httpRequest.getHeader("module");
		} else {
			return "";
		}
	}
	
	private String getIpAddress(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("ipaddress")) {
			return httpRequest.getHeader("ipaddress");
		} else {
			return "";
		}
	}
	
	private String getUsernm(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("usernm")) {
			return httpRequest.getHeader("usernm");
		} else {
			return "";
		}
	}
	
	private String getReqSys(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			return httpRequest.getHeader("meta-senderapp");
		} else {
			return "";
		}
	}

	private String getWebguid(HttpServletRequest httpRequest) {
		if(null != httpRequest && null != httpRequest.getHeader("webguid")) {
			return httpRequest.getHeader("webguid");
		} else {
			return "";
		}
	}
}
