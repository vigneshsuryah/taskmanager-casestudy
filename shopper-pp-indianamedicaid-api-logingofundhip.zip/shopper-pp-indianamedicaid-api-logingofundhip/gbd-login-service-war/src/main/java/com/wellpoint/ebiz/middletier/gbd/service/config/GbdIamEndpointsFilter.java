package com.wellpoint.ebiz.middletier.gbd.service.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.GenericFilterBean;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdUtil;

public class GbdIamEndpointsFilter extends GenericFilterBean {
	private static final Logger MBLOGGER = LoggerFactory.getLogger(GbdIamEndpointsFilter.class);

	
	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res,
			final FilterChain chain) throws IOException, ServletException {

		final HttpServletRequest request = (HttpServletRequest) req;

		try {
			String metaSenderApp = request.getHeader("meta-senderapp");
			String metaSenderAppKey = request.getHeader("meta-senderapp-key");
			String appKey = ApplicationPropertiesUI.getStringProperty("gbd.meta.senderapp.secretkey." + metaSenderApp);
			if(null != appKey){
				appKey = GbdUtil.getDecodedText(appKey);
			}
			if(metaSenderAppKey == null || appKey == null || !metaSenderAppKey.equalsIgnoreCase(appKey)){
				throw new ServletException("Invalid Requesting API Key");
			}
		} catch (Exception e) {
			throw new ServletException("Invalid Requesting API Key");
		}

		chain.doFilter(req, res);
		
	}
}
