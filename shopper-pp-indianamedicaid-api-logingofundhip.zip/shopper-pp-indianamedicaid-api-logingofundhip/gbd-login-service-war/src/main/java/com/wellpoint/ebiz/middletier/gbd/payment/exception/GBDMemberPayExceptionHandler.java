/**
* MemberPayExceptionHandler.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.gbd.payment.exception;


import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.middletier.gbd.soa.gateway.bo.APIExceptions;
import com.wellpoint.middletier.gbd.soa.gateway.bo.Exceptions;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;

@ControllerAdvice
public class GBDMemberPayExceptionHandler implements GbdSOAConstants
{
	
	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	public @ResponseBody APIExceptions handleCustomException (Exception ex, HttpServletResponse response) {
		response.setHeader("Content-Type", "application/json");
		if(ex instanceof GbdException){
			if(ex == null)
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				APIExceptions restError = returnRestErrorPP9043();
				return restError;
			}else
			{
				response.setStatus(((GbdException) ex).getReturnStatus());
				return ((GbdException) ex).transformException();
			}
		}else
		{
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			APIExceptions restError = returnRestErrorPP9043();
			return restError;
		}
		
	}
	
	public APIExceptions returnRestErrorPP9043()
	{
		APIExceptions restError = new APIExceptions();
		Exceptions exception = new Exceptions();
		exception.setType(EXCEPTION);
		exception.setCode(ERROR_CODE_9022);
		exception.setMessage(TECHINICAL_ERROR_MSG_9022);
		exception.setDetail(TECHINICAL_ERROR_MSG_9022);
		Exceptions exceptions[] = new Exceptions[1];
		exceptions[0] = exception;
		restError.setExceptions(exceptions);
		return restError;
	}
}
