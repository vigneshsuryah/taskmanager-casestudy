package com.wellpoint.ebiz.middletier.gbd.payment.aspect;

import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wellpoint.ebiz.middletier.tpp.service.TwoFactorAuthService;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.BaseRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.BaseResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;

@Aspect
public class TwoFactorAuthAspect {

	final static Logger LOGGER = Logger.getLogger(TwoFactorAuthAspect.class);
	
	@Autowired
	private TwoFactorAuthService twoFactorAuthServiceImpl;

	@AfterThrowing(pointcut = "execution(* com.wellpoint.ebiz.middletier.tpp.service.TwoFactorAuthService.*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error)
	{
		LOGGER.error("Suspected error in the request::" + error.getCause());
	}
	
	@Around("execution(* com.wellpoint.ebiz.middletier.gbd.payment.controller.TwoFactorAuthController.*(..))")
	public Object logMemberRS(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		MbrPayTransLog logObj = new MbrPayTransLog();
		ObjectMapper mapper = new ObjectMapper();
		Object[] objs = proceedingJoinPoint.getArgs();
		BaseRequest request = null;
		String requestingApplication = "";
		HttpServletRequest httpRequest = null;
		String reqHeaders = "";
		String reqBody = "";
		for (Object param : objs) {
			//Added by Cognizant for TPC change March 2018 release - Start
			if (param instanceof HttpServletRequest) {
				httpRequest = (HttpServletRequest) param;
				reqHeaders = null != httpRequest ? getHeaders(httpRequest) : "";
				if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
					requestingApplication = httpRequest.getHeader("meta-senderapp");
				}
			}
			//Added by Cognizant for TPC change March 2018 release - End
			if (param instanceof BaseRequest) {
				request = (BaseRequest) param;
				/*String requestingApplication = "TPP";
				logObj.setRequestingSystem(requestingApplication);
				logObj.setChannel(requestingApplication);*/
				if(null != request.getUserName() && !request.getUserName().isEmpty()){
					String userName = request.getUserName();
					if(userName.length() >= 25){
						logObj.setHcid(userName.substring(0, 24));
					}else{
						logObj.setHcid(userName);
					}
				}else{
					logObj.setHcid("NO_USERID");
				}
				logObj.setRequestTs(Calendar.getInstance().getTime());
				reqBody = " Request body: " + mapper.writeValueAsString(param);
				//break;
			}
			logObj.setRequestingSystem(requestingApplication);
			logObj.setChannel(requestingApplication);
		}
		logObj.setRequestXML(reqHeaders + reqBody);
		Object response = null;
		String endPoint = " ";
		try {
			response = proceedingJoinPoint.proceed();
			endPoint = request.getEndPointName();
			logObj.setOperationName(endPoint);
		} catch (Exception e) {
			endPoint = request.getEndPointName();
			logObj.setOperationName(endPoint);
			logObj.setResponseTs(Calendar.getInstance().getTime());
			logObj.setResponseXML(e.getMessage());

			try {
				twoFactorAuthServiceImpl.logRestLogInDB(logObj);
			} catch (Exception ex) {
				LOGGER.error("logMemberRS - ", ex);
			}
			throw e;
		}

		if (response instanceof BaseResponse) {
			logObj.setResponseTs(Calendar.getInstance().getTime());
			logObj.setResponseXML(mapper.writeValueAsString(response));
			
			if(null != endPoint && endPoint.equalsIgnoreCase("getUserIdFromEmailId")){
				SearchUserDetailsRestResponse searchUserDetailsRestResponse = (SearchUserDetailsRestResponse) response;
				if(null != searchUserDetailsRestResponse.getUser()){
					logObj.setHcid(searchUserDetailsRestResponse.getUser().getUsername());
				}
			}
			
			try {
				twoFactorAuthServiceImpl.logRestLogInDB(logObj);
			} catch (Exception ex) {
				LOGGER.error("logMemberRS - ", ex);
			}
		}
		return response;
	}
	
	private String getHeaders(HttpServletRequest httpRequest) {
		String headers = "Headers: ";

        Enumeration headerNames = httpRequest.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = httpRequest.getHeader(key);
            headers = headers + key + ":" + value + ",";
        }
		return headers;		
	}
}
