/**
 * SOAServicesGatewayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 11/12/2017  2.0      Cognizant       TPC change March 2018
 */
package com.wellpoint.ebiz.middletier.gbd.payment.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.ebiz.middletier.tpp.constants.GbdSOAConstants;
import com.wellpoint.ebiz.middletier.tpp.service.SOAServiceEndpointService;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.AuthenticateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ChangePasswordRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.DeleteUserAccountRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetFaqQnARequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.GetSecretQuestionsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ModifyUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.RegisterCreateUserRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.request.ValidateSecretAnswerRestRequest;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.AuthenticateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ChangePasswordRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.DeleteUserAccountRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetFaqResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.GetSecretQuestionsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ModifyUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.RegisterCreateUserRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.SearchUserDetailsRestResponse;
import com.wellpoint.middletier.gbd.soa.gateway.rest.response.ValidateSecretAnswerRestResponse;

/**
 * This class contains list of rest services exposed for Register Module of GBD TPP
 * @author CTS
 */
@Controller  
public class SOAServicesGatewayRestController implements GbdSOAConstants{
	private static final Logger LOGGER = LoggerFactory.getLogger(SOAServicesGatewayRestController.class);
	
	@Autowired
	private SOAServiceEndpointService sOAServiceEndpointServiceImpl;
	
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/createuser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody RegisterCreateUserRestResponse createUser(@RequestBody RegisterCreateUserRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In createUser() of SOAServicesGatewayRestController");
		
		RegisterCreateUserRestResponse response = null;
		request.setEndPointName("createUser");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.createUser(request);
		}catch(Exception e){
			LOGGER.error("Exception in createUser() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of createUser() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/account/deleteUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody DeleteUserAccountRestResponse deleteUser(@RequestBody DeleteUserAccountRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In deleteUser() of SOAServicesGatewayRestController");
		
		DeleteUserAccountRestResponse response = null;
		request.setEndPointName("deleteUser");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.deleteUser(request, true);
		}catch(Exception e){
			LOGGER.error("Exception in deleteUser() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of deleteUser() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SearchUserDetailsRestResponse searchUser(@RequestBody SearchUserDetailsRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In searchUser() of SOAServicesGatewayRestController");
		
		SearchUserDetailsRestResponse response = null;
		request.setEndPointName("searchUser");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.searchUser(request);
		}catch(Exception e){
			LOGGER.error("Exception in searchUser() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of searchUser() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/account/getRegisterUserDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SearchUserDetailsRestResponse getRegisterUserDetails(@RequestBody SearchUserDetailsRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In getRegisterUserDetails() of SOAServicesGatewayRestController");
		
		SearchUserDetailsRestResponse response = null;
		request.setEndPointName("getRegisterUserDetails");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.getRegisterUserDetails(request);
		}catch(Exception e){
			LOGGER.error("Exception in getRegisterUserDetails() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of getRegisterUserDetails() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/getUserIdFromEmailId", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SearchUserDetailsRestResponse getUserIdFromEmailId(@RequestBody RegisterCreateUserRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In getUserIdFromEmailId() of SOAServicesGatewayRestController");
		
		SearchUserDetailsRestResponse response = null;
		request.setEndPointName("getUserIdFromEmailId");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.getUserIdFromEmailId(request);
		}catch(Exception e){
			LOGGER.error("Exception in getUserIdFromEmailId() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of getUserIdFromEmailId() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/account/authenticateUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody AuthenticateUserRestResponse authenticateUser(@RequestBody AuthenticateUserRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In authenticateUser() of SOAServicesGatewayRestController");
		
		AuthenticateUserRestResponse response = null;
		request.setEndPointName("authenticateUser");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.authenticateUser(request);
		}catch(Exception e){
			LOGGER.error("Exception in authenticateUser() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of authenticateUser() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/account/modifyUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ModifyUserDetailsRestResponse modifyUser(@RequestBody ModifyUserDetailsRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In modifyUser() of SOAServicesGatewayRestController");
		
		ModifyUserDetailsRestResponse response = null;
		request.setEndPointName("modifyUser");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.modifyUser(request);
		}catch(Exception e){
			LOGGER.error("Exception in modifyUser() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of modifyUser() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ChangePasswordRestResponse changePassword(@RequestBody ChangePasswordRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In changePassword() of SOAServicesGatewayRestController");
		
		ChangePasswordRestResponse response = null;
		request.setEndPointName("changePassword");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.changePassword(request);
		}catch(Exception e){
			LOGGER.error("Exception in changePassword() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of changePassword() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/getSecretQuestions", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetSecretQuestionsRestResponse getSecretQuestions(@RequestBody GetSecretQuestionsRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In getSecretQuestions() of SOAServicesGatewayRestController");
		
		GetSecretQuestionsRestResponse response = null;
		request.setEndPointName("getSecretQuestions");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.getSecretQuestions(request);
		}catch(Exception e){
			LOGGER.error("Exception in getSecretQuestions() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of getSecretQuestions() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/validateSecretAnswerForForgotUserName", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateSecretAnswerRestResponse validateSecretAnswerForForgotUserName(@RequestBody ValidateSecretAnswerRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In validateSecretAnswerForForgotUserName() of SOAServicesGatewayRestController");
		
		ValidateSecretAnswerRestResponse response = null;
		request.setEndPointName("validateSecAnsForUN");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.validateSecretAnswerForForgotUserName(request);
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotUserName() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of validateSecretAnswerForForgotUserName() of SOAServicesGatewayRestController");
		return response;
	}
	
	@RequestMapping(value = "/soaservices/v1/gbd/register/validateSecretAnswerForForgotPassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateSecretAnswerRestResponse validateSecretAnswerForForgotPassword(@RequestBody ValidateSecretAnswerRestRequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In validateSecretAnswerForForgotPassword() of SOAServicesGatewayRestController");
		
		ValidateSecretAnswerRestResponse response = null;
		request.setEndPointName("validateSecAnsForPass");
		//Added by Cognizant for TPC change March 2018 release - Start
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}
		//Added by Cognizant for TPC change March 2018 release - End
		try{
			response = 	sOAServiceEndpointServiceImpl.validateSecretAnswerForForgotPassword(request);
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotPassword() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of validateSecretAnswerForForgotPassword() of SOAServicesGatewayRestController");
		return response;
	}

	@RequestMapping(value = "/soaservices/v1/gbd/account/getFaqQnA", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody List<GetFaqResponse> getFaqQnA(@RequestBody GetFaqQnARequest request, HttpServletRequest httpRequest) throws GbdException{
		
		LOGGER.info("In getFaqQnA() of SOAServicesGatewayRestController");
		
		List<GetFaqResponse> response = null;
		request.setEndPointName("getFaqQnA");
		
		if(null != httpRequest && null != httpRequest.getHeader("meta-senderapp")) {
			request.setRequestingSystem(httpRequest.getHeader("meta-senderapp"));
		}

		try{
			response = 	sOAServiceEndpointServiceImpl.getFaqQnA(request);
		}catch(Exception e){
			LOGGER.error("Exception in getFaqQnA() of SOAServicesGatewayRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		
		LOGGER.info("End of getFaqQnA() of SOAServicesGatewayRestController");
		return response;
	}
	
	
}
