/**
 * TPCLoginServiceDaoImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 11/12/2017  2.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.wellpoint.ebiz.middletier.tpp.dao.TPCLoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.dao.impl.GenericDAOImpl;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPMemberDetail;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;


public class TPCLoginServiceDaoImpl extends GenericDAOImpl implements TPCLoginServiceDao
{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TPCLoginServiceDaoImpl.class);
	
	static final String GET_USER_ID_USED_COUNT = "TPC.GET_USER_ID_USED_COUNT";
	static final String GET_EMAIL_ID_USED_COUNT = "TPC.GET_EMAIL_ID_USED_COUNT";
	static final String GET_USER_ID_FOR_EMAIL_ID = "TPC.GET_USER_ID_FOR_EMAIL_ID";
	static final String GET_USER_DETAILS_FROM_REGISTRATION = "TPC.GET_USER_DETAILS_FROM_REGISTRATION";
	static final String UPDATE_TPC_REGISTRATION = "TPC.UPDATE_TPC_REGISTRATION";
	static final String DELETE_ACCOUNT_TPC_REGISTRATION = "TPC.DELETE_ACCOUNT_TPC_REGISTRATION";
	static final String INSERT_TPC_REGISTRATION = "TPC.INSERT_TPC_REGISTRATION";
	static final String UPDATE_AUTH_FLAG = "TPC.UPDATE_AUTH_FLAG";
	static final String GET_PHONE_NO_USED_COUNT = "TPC.GET_PHONE_NUMBER_USED_COUNT";
	
	private String ERROR_TYPE = "E";
	private String TECHNICAL_ERR_CD = "TPC1000";
	private String TECHNICAL_ERR_MSG = "Technical Error";
	private int REST_ERROR_500 = 500;

	@SuppressWarnings("rawtypes")
	public class TPCMemberInfoRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPMemberDetail tpcMemberDetail = new TPPMemberDetail();
			tpcMemberDetail.setMemberFName(rs.getString("memberFName"));
			tpcMemberDetail.setMemberLName(rs.getString("memberLName"));
			tpcMemberDetail.setMemberId(rs.getString("memberId"));
			tpcMemberDetail.setMemberDob(rs.getDate("memberDOB"));
			tpcMemberDetail.setUserId(rs.getString("userId"));			
			return tpcMemberDetail;
		}
	}
	
	
	@Override
	public Integer getTpcUserIdUsedCount(String userId) throws GbdException
	{
		LOGGER.debug("Inside getUserIdUsedCount -- start");
		Integer count = 0;
		try{
			GetUserIdUsedCountQuery getUserIdUsedCountQuery = new GetUserIdUsedCountQuery(dataSource);
			count = getUserIdUsedCountQuery.executeGetUserIdUsedCountSp(userId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserIdUsedCount -- end");
		return count;
	}
	
	public class GetUserIdUsedCountQuery extends DAOStoredProc
	{
		protected GetUserIdUsedCountQuery(DataSource ds)
		{

			super(ds, GET_USER_ID_USED_COUNT);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetUserIdUsedCountSp(String userId)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	
	@Override
	public Integer getTpcEmailIdUsedCount(String emailId) throws GbdException
	{
		LOGGER.debug("Inside getEmailIdUsedCount -- start");
		Integer count = 0;
		try{
			GetEmailIdUsedCountQuery getEmailIdUsedCountQuery = new GetEmailIdUsedCountQuery(dataSource);
			count = getEmailIdUsedCountQuery.executeGetEmailIdUsedCountSp(emailId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getEmailIdUsedCount -- end");
		return count;
	}
	
	public class GetEmailIdUsedCountQuery extends DAOStoredProc
	{
		protected GetEmailIdUsedCountQuery(DataSource ds)
		{

			super(ds, GET_EMAIL_ID_USED_COUNT);
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetEmailIdUsedCountSp(String userId)
		{

			Map inParams = new HashMap();
			inParams.put("@EMAIL_ID",userId);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public List<TPPRegistrationDetail> getTpcUserIdFromEmailId(String emailId) throws GbdException
	{
		LOGGER.debug("Inside getUserIdFromEmailId -- start");
		List<TPPRegistrationDetail> tpcRegistrationDetailList = new ArrayList<TPPRegistrationDetail>();
		try{
			GetUserIdFromEmailId memberDetailInfoSproc = new GetUserIdFromEmailId(dataSource);
			tpcRegistrationDetailList = memberDetailInfoSproc.executeGetUserIdFromEmailId(emailId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserIdFromEmailId -- end");
		return tpcRegistrationDetailList;
	}

	
	private class GetUserIdFromEmailId extends StoredProcedure
	{

		public GetUserIdFromEmailId(DataSource ds)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(GET_USER_ID_FOR_EMAIL_ID);
			declareParameter(new SqlReturnResultSet("rs", new TPCRegistrationDetailUserIdMapper()));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));			
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<TPPRegistrationDetail> executeGetUserIdFromEmailId(String emailId)
		{
			Map inParams = new HashMap();			
				inParams.put("@EMAIL_ID", emailId);			
			Map resultMap = execute(inParams);
			List reportLineItems = (List) resultMap.get("rs");

			return reportLineItems;
		}
	}
	
	@Override
	public Integer updateTpcRegistration(TPPRegistrationDetail details) throws GbdException
	{
		LOGGER.debug("Inside updateTpcRegistration -- start");
		Integer count = 0;
		try{
			UpdateTpcRegistrationQuery getEmailIdUsedCountQuery = new UpdateTpcRegistrationQuery(dataSource);
			count = getEmailIdUsedCountQuery.executeupdateTPCRegistrationSp(details);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside updateTpcRegistration -- end");
		return count;
	}
	
	public class UpdateTpcRegistrationQuery extends DAOStoredProc
	{
		protected UpdateTpcRegistrationQuery(DataSource ds)
		{

			super(ds, UPDATE_TPC_REGISTRATION);
			declareParameter(new SqlParameter("@FIELD_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@FIRST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@LAST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@AUTH_FLAG", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeupdateTPCRegistrationSp(TPPRegistrationDetail details)
		{

			Map inParams = new HashMap();
			inParams.put("@FIELD_NAME",details.getFieldName());
			inParams.put("@FIRST_NAME",details.getFirstName());
			inParams.put("@LAST_NAME",details.getLastName());
			inParams.put("@PHONE_NUMBER",details.getPhoneNumber());
			inParams.put("@USER_ID",details.getUserId());
			inParams.put("@EMAIL_ID",details.getEmailId());
			inParams.put("@AUTH_FLAG", details.getAuthFlag());
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public void deleteTpcUserAccount(String userId) throws GbdException
	{
		try{
			DeleteUserAccountQuery deleteUserAccountQuery = new DeleteUserAccountQuery(dataSource);
			deleteUserAccountQuery.executeDeleteUserAccountQuerySp(userId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
	}
	
	public class DeleteUserAccountQuery extends DAOStoredProc
	{
		protected DeleteUserAccountQuery(DataSource ds)
		{
			super(ds, DELETE_ACCOUNT_TPC_REGISTRATION);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public void executeDeleteUserAccountQuerySp(String userId)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			execute(inParams);
		}
	}
	
	
	@Override
	public String insertTpcRegistration(TPPRegistrationDetail details) throws GbdException
	{
		LOGGER.debug("Inside insertTpcRegistration -- start");
		String userId = details.getUserId();
		try{
			InsertTpcRegistrationQuery insertTpcRegistrationQuery = new InsertTpcRegistrationQuery(dataSource);
			userId = insertTpcRegistrationQuery.executeInsertTpcRegistrationSp(details);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside insertTpcRegistration -- end");
		return userId;
	}
	
	public class InsertTpcRegistrationQuery extends DAOStoredProc
	{
		protected InsertTpcRegistrationQuery(DataSource ds)
		{
			super(ds, INSERT_TPC_REGISTRATION);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@FIRST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@LAST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATED_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@RELATIONSHIP_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@RELATIONSHIP_TYPE", Types.VARCHAR));
			declareParameter(new SqlParameter("@UNIQUE_ID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@OUT_USER_ID", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeInsertTpcRegistrationSp(TPPRegistrationDetail details)
		{
			Map inParams = new HashMap();
			inParams.put("@USER_ID",details.getUserId());
			inParams.put("@FIRST_NAME",details.getFirstName());
			inParams.put("@LAST_NAME",details.getLastName());
			inParams.put("@PHONE_NUMBER",details.getPhoneNumber());
			inParams.put("@CREATED_ID",details.getUserId());
			inParams.put("@EMAIL_ID",details.getEmailId());
			inParams.put("@RELATIONSHIP_NAME",details.getOrganizationName());
			inParams.put("@RELATIONSHIP_TYPE",details.getOrganizationType());
			inParams.put("@UNIQUE_ID",details.getUniqueId());
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			String userId = (String) outParams.get("@OUT_USER_ID");
			return userId;
		}
	}
	
	
	@Override
	public List<TPPRegistrationDetail> getTpcUserDetailsFromUserId(String userId) throws GbdException
	{
		LOGGER.debug("Inside getUserDetailsFromUserId -- start");
		List<TPPRegistrationDetail> tpcRegistrationDetailList = new ArrayList<TPPRegistrationDetail>();
		try{
			GetUserDetailsFromUserId userDetails = new GetUserDetailsFromUserId(dataSource);
			tpcRegistrationDetailList = userDetails.executeGetUserDetailsFromUserId(userId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserDetailsFromUserId -- end");
		return tpcRegistrationDetailList;
	}

	
	private class GetUserDetailsFromUserId extends StoredProcedure
	{

		public GetUserDetailsFromUserId(DataSource ds)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(GET_USER_DETAILS_FROM_REGISTRATION);
			declareParameter(new SqlReturnResultSet("rs", new TPCRegistrationDetailMapper()));
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));			
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<TPPRegistrationDetail> executeGetUserDetailsFromUserId(String userId)
		{
			Map inParams = new HashMap();			
			inParams.put("@USER_ID", userId);			
			Map resultMap = execute(inParams);
			List reportLineItems = (List) resultMap.get("rs");

			return reportLineItems;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public class TPCRegistrationDetailMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPRegistrationDetail tpcRegistrationDetail = new TPPRegistrationDetail();
			tpcRegistrationDetail.setUserId(rs.getString("USER_ID"));
			tpcRegistrationDetail.setFirstName(rs.getString("FIRST_NAME"));
			tpcRegistrationDetail.setLastName(rs.getString("LAST_NAME"));
			tpcRegistrationDetail.setPhoneNumber(rs.getString("PHONE_NUMBER"));
			tpcRegistrationDetail.setEmailId(rs.getString("EMAIL_ID"));
			tpcRegistrationDetail.setOrganizationName(rs.getString("RELATIONSHIP_NAME"));
			tpcRegistrationDetail.setOrganizationType(rs.getString("RELATIONSHIP_TYPE"));
			tpcRegistrationDetail.setAuthFlag(rs.getString("AUTH_FLAG"));
			return tpcRegistrationDetail;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public class TPCRegistrationDetailUserIdMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPRegistrationDetail tpcRegistrationDetail = new TPPRegistrationDetail();
			tpcRegistrationDetail.setUserId(rs.getString("USER_ID"));
			return tpcRegistrationDetail;
		}
	}

	@Override
	public Integer updateAuthFlag(String userId) throws GbdException
	{
		LOGGER.debug("Inside updateAuthFlag - start");
		Integer count = 0;
		try{
			UpdateAuthFlagQuery updateAuthFlagQuery = new UpdateAuthFlagQuery(dataSource);
			count = updateAuthFlagQuery.executeUpdateAuthFlagSp(userId);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside updateAuthFlag - end");
		return count;
	}
	
	public class UpdateAuthFlagQuery extends DAOStoredProc
	{
		protected UpdateAuthFlagQuery(DataSource ds)
		{

			super(ds, UPDATE_AUTH_FLAG);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeUpdateAuthFlagSp(String userId)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public Integer getTpcPhoneNoUsedCount(String phoneNo) throws GbdException
	{
		LOGGER.debug("Inside getTpcPhoneNoUsedCount -- start");
		Integer count = 0;
		try{
			GetPhoneNoUsedCountQuery getPhoneNoUsedCountQuery = new GetPhoneNoUsedCountQuery(dataSource);
			count = getPhoneNoUsedCountQuery.executeGetPhoneNoUsedCountSp(phoneNo);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getTpcPhoneNoUsedCount -- end");
		return count;
	}
	
	public class GetPhoneNoUsedCountQuery extends DAOStoredProc
	{
		protected GetPhoneNoUsedCountQuery(DataSource ds)
		{

			super(ds, GET_PHONE_NO_USED_COUNT);
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetPhoneNoUsedCountSp(String phoneNo)
		{

			Map inParams = new HashMap();
			inParams.put("@PHONE_NUMBER",phoneNo);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	
}
