/**
 * LoginServiceDaoImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 06/11/2018  3.0		Cognizant	    KYTPP July 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;

import com.wellpoint.ebiz.middletier.tpp.dao.LoginServiceDao;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPMemberDetail;
import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;


public class LoginServiceDaoImpl extends GenericDAOImpl implements LoginServiceDao
{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginServiceDaoImpl.class);
	
	static final String GET_USER_ID_USED_COUNT = "TPP.GET_USER_ID_USED_COUNT";
	static final String GET_EMAIL_ID_USED_COUNT = "TPP.GET_EMAIL_ID_USED_COUNT";
	static final String GET_USER_ID_FOR_EMAIL_ID = "TPP.GET_USER_ID_FOR_EMAIL_ID";
	static final String GET_USER_DETAILS_FROM_REGISTRATION = "TPP.GET_USER_DETAILS_FROM_REGISTRATION";
	static final String UPDATE_TPP_REGISTRATION = "TPP.UPDATE_TPP_REGISTRATION";
	static final String DELETE_ACCOUNT_TPP_REGISTRATION = "TPP.DELETE_ACCOUNT_TPP_REGISTRATION";
	static final String INSERT_TPP_REGISTRATION = "TPP.INSERT_TPP_REGISTRATION";
	static final String UPDATE_AUTH_FLAG = "TPP.UPDATE_AUTH_FLAG";
	static final String GET_PHONE_NO_USED_COUNT = "TPP.GET_PHONE_NUMBER_USED_COUNT";
	
	private String ERROR_TYPE = "E";
	private String TECHNICAL_ERR_CD = "GBD1000";
	private String TECHNICAL_ERR_MSG = "Technical Error";
	private int REST_ERROR_500 = 500;

	@SuppressWarnings("rawtypes")
	public class TPPMemberInfoRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPMemberDetail tppMemberDetail = new TPPMemberDetail();
			tppMemberDetail.setMemberFName(rs.getString("memberFName"));
			tppMemberDetail.setMemberLName(rs.getString("memberLName"));
			tppMemberDetail.setMemberId(rs.getString("memberId"));
			tppMemberDetail.setMemberDob(rs.getDate("memberDOB"));
			tppMemberDetail.setUserId(rs.getString("userId"));			
			return tppMemberDetail;
		}
	}
	
	
	@Override
	public Integer getUserIdUsedCount(String userId, String lob) throws GbdException
	{
		LOGGER.debug("Inside getUserIdUsedCount -- start");
		Integer count = 0;
		try{
			GetUserIdUsedCountQuery getUserIdUsedCountQuery = new GetUserIdUsedCountQuery(dataSource);
			count = getUserIdUsedCountQuery.executeGetUserIdUsedCountSp(userId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserIdUsedCount -- end");
		return count;
	}
	
	public class GetUserIdUsedCountQuery extends DAOStoredProc
	{
		protected GetUserIdUsedCountQuery(DataSource ds)
		{

			super(ds, GET_USER_ID_USED_COUNT);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetUserIdUsedCountSp(String userId, String lob)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			inParams.put("@LOB",lob);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	
	@Override
	public Integer getEmailIdUsedCount(String emailId, String lob) throws GbdException
	{
		LOGGER.debug("Inside getEmailIdUsedCount -- start");
		Integer count = 0;
		try{
			GetEmailIdUsedCountQuery getEmailIdUsedCountQuery = new GetEmailIdUsedCountQuery(dataSource);
			count = getEmailIdUsedCountQuery.executeGetEmailIdUsedCountSp(emailId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getEmailIdUsedCount -- end");
		return count;
	}
	
	public class GetEmailIdUsedCountQuery extends DAOStoredProc
	{
		protected GetEmailIdUsedCountQuery(DataSource ds)
		{

			super(ds, GET_EMAIL_ID_USED_COUNT);
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetEmailIdUsedCountSp(String userId, String lob)
		{

			Map inParams = new HashMap();
			inParams.put("@EMAIL_ID",userId);
			inParams.put("@LOB",lob);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public List<TPPRegistrationDetail> getUserIdFromEmailId(String emailId, String lob) throws GbdException
	{
		LOGGER.debug("Inside getUserIdFromEmailId -- start");
		List<TPPRegistrationDetail> tPPRegistrationDetailList = new ArrayList<TPPRegistrationDetail>();
		try{
			GetUserIdFromEmailId memberDetailInfoSproc = new GetUserIdFromEmailId(dataSource);
			tPPRegistrationDetailList = memberDetailInfoSproc.executeGetUserIdFromEmailId(emailId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserIdFromEmailId -- end");
		return tPPRegistrationDetailList;
	}

	
	private class GetUserIdFromEmailId extends StoredProcedure
	{

		public GetUserIdFromEmailId(DataSource ds)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(GET_USER_ID_FOR_EMAIL_ID);
			declareParameter(new SqlReturnResultSet("rs", new TPPRegistrationDetailUserIdMapper()));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));			
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<TPPRegistrationDetail> executeGetUserIdFromEmailId(String emailId, String lob)
		{
			Map inParams = new HashMap();			
			inParams.put("@EMAIL_ID", emailId);			
			inParams.put("@LOB", lob);
			Map resultMap = execute(inParams);
			List reportLineItems = (List) resultMap.get("rs");

			return reportLineItems;
		}
	}
	
	@Override
	public Integer updateTPPRegistration(TPPRegistrationDetail details) throws GbdException
	{
		LOGGER.debug("Inside updateTPPRegistration -- start");
		Integer count = 0;
		try{
			UpdateTPPRegistrationQuery getEmailIdUsedCountQuery = new UpdateTPPRegistrationQuery(dataSource);
			count = getEmailIdUsedCountQuery.executeupdateTPPRegistrationSp(details);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside updateTPPRegistration -- end");
		return count;
	}
	
	public class UpdateTPPRegistrationQuery extends DAOStoredProc
	{
		protected UpdateTPPRegistrationQuery(DataSource ds)
		{

			super(ds, UPDATE_TPP_REGISTRATION);
			declareParameter(new SqlParameter("@FIELD_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@FIRST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@LAST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlParameter("@AUTH_FLAG",Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeupdateTPPRegistrationSp(TPPRegistrationDetail details)
		{

			Map inParams = new HashMap();
			inParams.put("@FIELD_NAME",details.getFieldName());
			inParams.put("@FIRST_NAME",details.getFirstName());
			inParams.put("@LAST_NAME",details.getLastName());
			inParams.put("@PHONE_NUMBER",details.getPhoneNumber());
			inParams.put("@USER_ID",details.getUserId());
			inParams.put("@EMAIL_ID",details.getEmailId());
			inParams.put("@LOB",details.getLob());
			inParams.put("@AUTH_FLAG", details.getAuthFlag());
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public void deleteUserAccount(String userId, String lob) throws GbdException
	{
		try{
			DeleteUserAccountQuery deleteUserAccountQuery = new DeleteUserAccountQuery(dataSource);
			deleteUserAccountQuery.executeDeleteUserAccountQuerySp(userId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
	}
	
	public class DeleteUserAccountQuery extends DAOStoredProc
	{
		protected DeleteUserAccountQuery(DataSource ds)
		{
			super(ds, DELETE_ACCOUNT_TPP_REGISTRATION);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public void executeDeleteUserAccountQuerySp(String userId, String lob)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			inParams.put("@LOB",lob);
			execute(inParams);
		}
	}
	
	
	@Override
	public String insertTppRegistration(TPPRegistrationDetail details) throws GbdException
	{
		LOGGER.debug("Inside insertTppRegistration -- start");
		String userId = details.getUserId();
		try{
			InsertTppRegistrationQuery insertTppRegistrationQuery = new InsertTppRegistrationQuery(dataSource);
			userId = insertTppRegistrationQuery.executeInsertTppRegistrationSp(details);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside insertTppRegistration -- end");
		return userId;
	}
	
	public class InsertTppRegistrationQuery extends DAOStoredProc
	{
		protected InsertTppRegistrationQuery(DataSource ds)
		{
			super(ds, INSERT_TPP_REGISTRATION);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@FIRST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@LAST_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATED_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@EMAIL_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@ORGANIZATION_NAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@ORGANIZATION_TYPE", Types.VARCHAR));
			declareParameter(new SqlParameter("@UNIQUE_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@OUT_USER_ID", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeInsertTppRegistrationSp(TPPRegistrationDetail details)
		{
			Map inParams = new HashMap();
			inParams.put("@USER_ID",details.getUserId());
			inParams.put("@FIRST_NAME",details.getFirstName());
			inParams.put("@LAST_NAME",details.getLastName());
			inParams.put("@PHONE_NUMBER",details.getPhoneNumber());
			inParams.put("@CREATED_ID",details.getUserId());
			inParams.put("@EMAIL_ID",details.getEmailId());
			inParams.put("@ORGANIZATION_NAME",details.getOrganizationName());
			inParams.put("@ORGANIZATION_TYPE",details.getOrganizationType());
			inParams.put("@UNIQUE_ID",details.getUniqueId());
			inParams.put("@LOB",details.getLob());
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			String userId = (String) outParams.get("@OUT_USER_ID");
			return userId;
		}
	}
	
	
	@Override
	public List<TPPRegistrationDetail> getUserDetailsFromUserId(String userId, String lob) throws GbdException
	{
		LOGGER.debug("Inside getUserDetailsFromUserId -- start");
		List<TPPRegistrationDetail> tPPRegistrationDetailList = new ArrayList<TPPRegistrationDetail>();
		try{
			GetUserDetailsFromUserId userDetails = new GetUserDetailsFromUserId(dataSource);
			tPPRegistrationDetailList = userDetails.executeGetUserDetailsFromUserId(userId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getUserDetailsFromUserId -- end");
		return tPPRegistrationDetailList;
	}

	
	private class GetUserDetailsFromUserId extends StoredProcedure
	{

		public GetUserDetailsFromUserId(DataSource ds)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(GET_USER_DETAILS_FROM_REGISTRATION);
			declareParameter(new SqlReturnResultSet("rs", new TPPRegistrationDetailMapper()));
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));			
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<TPPRegistrationDetail> executeGetUserDetailsFromUserId(String userId, String lob)
		{
			Map inParams = new HashMap();			
			inParams.put("@USER_ID", userId);			
			inParams.put("@LOB", lob);
			Map resultMap = execute(inParams);
			List reportLineItems = (List) resultMap.get("rs");

			return reportLineItems;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public class TPPRegistrationDetailMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPRegistrationDetail tPPRegistrationDetail = new TPPRegistrationDetail();
			tPPRegistrationDetail.setUserId(rs.getString("USER_ID"));
			tPPRegistrationDetail.setFirstName(rs.getString("FIRST_NAME"));
			tPPRegistrationDetail.setLastName(rs.getString("LAST_NAME"));
			tPPRegistrationDetail.setPhoneNumber(rs.getString("PHONE_NUMBER"));
			tPPRegistrationDetail.setEmailId(rs.getString("EMAIL_ID"));
			tPPRegistrationDetail.setOrganizationName(rs.getString("ORGANIZATION_NAME"));
			tPPRegistrationDetail.setOrganizationType(rs.getString("ORGANIZATION_TYPE"));
			tPPRegistrationDetail.setAuthFlag(rs.getString("AUTH_FLAG"));
			return tPPRegistrationDetail;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public class TPPRegistrationDetailUserIdMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			TPPRegistrationDetail tPPRegistrationDetail = new TPPRegistrationDetail();
			tPPRegistrationDetail.setUserId(rs.getString("USER_ID"));
			return tPPRegistrationDetail;
		}
	}

	@Override
	public Integer updateAuthFlag(String userId, String lob) throws GbdException
	{
		LOGGER.debug("Inside updateAuthFlag - start");
		Integer count = 0;
		try{
			UpdateAuthFlagQuery updateAuthFlagQuery = new UpdateAuthFlagQuery(dataSource);
			count = updateAuthFlagQuery.executeUpdateAuthFlagSp(userId, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside updateAuthFlag - end");
		return count;
	}
	
	public class UpdateAuthFlagQuery extends DAOStoredProc
	{
		protected UpdateAuthFlagQuery(DataSource ds)
		{

			super(ds, UPDATE_AUTH_FLAG);
			declareParameter(new SqlParameter("@USER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeUpdateAuthFlagSp(String userId, String lob)
		{

			Map inParams = new HashMap();
			inParams.put("@USER_ID",userId);
			inParams.put("@LOB", lob);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
	@Override
	public Integer getPhoneNoUsedCount(String phoneNo, String lob) throws GbdException
	{
		LOGGER.debug("Inside getPhoneNoUsedCount -- start");
		Integer count = 0;
		try{
			GetPhoneNoUsedCountQuery getEmailIdUsedCountQuery = new GetPhoneNoUsedCountQuery(dataSource);
			count = getEmailIdUsedCountQuery.executeGetPhoneNoUsedUsedCountSp(phoneNo, lob);
		}catch(Exception e){
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD,TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		LOGGER.debug("Inside getPhoneNoUsedCount -- end");
		return count;
	}
	
	public class GetPhoneNoUsedCountQuery extends DAOStoredProc
	{
		protected GetPhoneNoUsedCountQuery(DataSource ds)
		{

			super(ds, GET_PHONE_NO_USED_COUNT);
			declareParameter(new SqlParameter("@PHONE_NUMBER", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@COUNT_VAL", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public Integer executeGetPhoneNoUsedUsedCountSp(String phoneNo, String lob)
		{

			Map inParams = new HashMap();
			inParams.put("@PHONE_NUMBER",phoneNo);
			inParams.put("@LOB",lob);
			Map<String, Object> outParams = new HashMap<String, Object>();
			outParams = execute(inParams);
			Integer count = (Integer) outParams.get("@COUNT_VAL");
			return count;
		}
	}
	
}
