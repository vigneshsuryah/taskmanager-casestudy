/**
 * TPCLoginServiceDao.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 11/12/2017  2.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.dao;


import java.util.List;

import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;

public interface TPCLoginServiceDao
{

	Integer getTpcUserIdUsedCount(String userId) throws GbdException;

	Integer getTpcEmailIdUsedCount(String emailId) throws GbdException;

	List<TPPRegistrationDetail> getTpcUserIdFromEmailId(String emailId) throws GbdException;

	Integer updateTpcRegistration(TPPRegistrationDetail details) throws GbdException;

	void deleteTpcUserAccount(String userId) throws GbdException;

	String insertTpcRegistration(TPPRegistrationDetail details) throws GbdException;

	List<TPPRegistrationDetail> getTpcUserDetailsFromUserId(String userId) throws GbdException;
	
	Integer updateAuthFlag (String userId) throws GbdException;

	Integer getTpcPhoneNoUsedCount(String phoneNo) throws GbdException;
	
}
