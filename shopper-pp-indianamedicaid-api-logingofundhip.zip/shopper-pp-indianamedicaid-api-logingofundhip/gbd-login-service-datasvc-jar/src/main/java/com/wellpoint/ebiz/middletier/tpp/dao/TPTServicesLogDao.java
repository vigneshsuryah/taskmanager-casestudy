/**
 * TPTServicesLogDao.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.tpp.dao;

import com.wellpoint.middletier.gbd.soa.gateway.bo.TPTServicesLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThirdPartyEmailLogging;


public interface TPTServicesLogDao
{
	void saveTptServicesLog(TPTServicesLog logData);
	void saveEmailLog(ThirdPartyEmailLogging tppEmailLogging);

}
