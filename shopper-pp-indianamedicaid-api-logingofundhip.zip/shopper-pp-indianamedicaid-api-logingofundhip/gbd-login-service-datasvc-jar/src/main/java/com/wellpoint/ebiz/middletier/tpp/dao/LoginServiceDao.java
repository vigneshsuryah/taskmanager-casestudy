/**
 * LoginServiceDao.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 06/11/2018  3.0		Cognizant	    KYTPP July 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.dao;


import java.util.List;

import com.wellpoint.ebiz.middletier.tpp.entity.TPPRegistrationDetail;
import com.wellpoint.middletier.gbd.soa.gateway.bo.GbdException;

public interface LoginServiceDao
{

	Integer getUserIdUsedCount(String userId, String lob) throws GbdException;

	Integer getEmailIdUsedCount(String emailId, String lob) throws GbdException;

	List<TPPRegistrationDetail> getUserIdFromEmailId(String emailId, String lob) throws GbdException;

	Integer updateTPPRegistration(TPPRegistrationDetail details) throws GbdException;

	void deleteUserAccount(String userId, String lob) throws GbdException;

	String insertTppRegistration(TPPRegistrationDetail details) throws GbdException;

	List<TPPRegistrationDetail> getUserDetailsFromUserId(String userId, String lob) throws GbdException;
	
	Integer updateAuthFlag (String userId, String lob) throws GbdException;

	Integer getPhoneNoUsedCount(String phoneNo, String lob) throws GbdException;
	
}
