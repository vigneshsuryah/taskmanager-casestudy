package com.wellpoint.ebiz.middletier.tpp.entity;

import java.util.Date;

public class TPPMemberDetail
{
	private String memberFName;
	private String memberLName;
	private String memberId;
	private Date memberDob;
	private String userId;
	
	public String getMemberFName()
	{
		return memberFName;
	}
	public void setMemberFName(String memberFName)
	{
		this.memberFName = memberFName;
	}
	public String getMemberLName()
	{
		return memberLName;
	}
	public void setMemberLName(String memberLName)
	{
		this.memberLName = memberLName;
	}
	public String getMemberId()
	{
		return memberId;
	}
	public void setMemberId(String memberId)
	{
		this.memberId = memberId;
	}
	public Date getMemberDob()
	{
		return memberDob;
	}
	public void setMemberDob(Date memberDob)
	{
		this.memberDob = memberDob;
	}
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	

}
