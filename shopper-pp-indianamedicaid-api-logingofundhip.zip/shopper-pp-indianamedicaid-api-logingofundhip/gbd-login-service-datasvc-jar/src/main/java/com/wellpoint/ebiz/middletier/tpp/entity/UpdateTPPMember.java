package com.wellpoint.ebiz.middletier.tpp.entity;

import java.util.Date;

public class UpdateTPPMember
{
	private String memberId;
	private String memberLName;
	private String memberFName;
	private String memberStatus;
	private Date dob;
	private Date createdDate;
	private String createdId;
	private String userId;
	private Date updateDate;
	private String updateId;
	public String getMemberId()
	{
		return memberId;
	}
	public void setMemberId(String memberId)
	{
		this.memberId = memberId;
	}
	public String getMemberLName()
	{
		return memberLName;
	}
	public void setMemberLName(String memberLName)
	{
		this.memberLName = memberLName;
	}
	public String getMemberFName()
	{
		return memberFName;
	}
	public void setMemberFName(String memberFName)
	{
		this.memberFName = memberFName;
	}
	public String getMemberStatus()
	{
		return memberStatus;
	}
	public void setMemberStatus(String memberStatus)
	{
		this.memberStatus = memberStatus;
	}
	public Date getDob()
	{
		return dob;
	}
	public void setDob(Date dob)
	{
		this.dob = dob;
	}
	public Date getCreatedDate()
	{
		return createdDate;
	}
	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}
	public String getCreatedId()
	{
		return createdId;
	}
	public void setCreatedId(String createdId)
	{
		this.createdId = createdId;
	}
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	public Date getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public String getUpdateId()
	{
		return updateId;
	}
	public void setUpdateId(String updateId)
	{
		this.updateId = updateId;
	}
	
	
	
	
}
