package com.wellpoint.ebiz.middletier.tpp.dao;

import org.springframework.dao.DataAccessException;

import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
 

public interface TransLogDAO{
	void saveMemberRSLog(MbrPayTransLog transLogDataBean) throws DataAccessException;
}
