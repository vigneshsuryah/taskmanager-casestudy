/**
 * TPPRegistrationDetail.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 06/11/2018  3.0		Cognizant	    KYTPP July 2018 release
 */
package com.wellpoint.ebiz.middletier.tpp.entity;

public class TPPRegistrationDetail
{
	private String userId;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String emailId;
	private String organizationName;
	private String organizationType;
	private String fieldName;
	private String uniqueId;
	private String lob;
	private String authFlag;
	
	public String getUniqueId()
	{
		return uniqueId;
	}
	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	public String getFirstName()
	{
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	public String getOrganizationName()
	{
		return organizationName;
	}
	public void setOrganizationName(String organizationName)
	{
		this.organizationName = organizationName;
	}
	public String getOrganizationType()
	{
		return organizationType;
	}
	public void setOrganizationType(String organizationType)
	{
		this.organizationType = organizationType;
	}
	public String getFieldName()
	{
		return fieldName;
	}
	public void setFieldName(String fieldName)
	{
		this.fieldName = fieldName;
	}
	/**
	 * @return the lob
	 */
	public String getLob()
	{
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob)
	{
		this.lob = lob;
	}
	public String getAuthFlag()
	{
		return authFlag;
	}
	public void setAuthFlag(String authFlag)
	{
		this.authFlag = authFlag;
	}
}
