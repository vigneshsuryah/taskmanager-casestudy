/**
 * TPTServicesLogDaoImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 11/12/2017  2.0      Cognizant       TPC change March 2018
 */
package com.wellpoint.ebiz.middletier.tpp.dao.impl;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.tpp.dao.TPTServicesLogDao;
import com.wellpoint.middletier.gbd.soa.gateway.bo.TPTServicesLog;
import com.wellpoint.middletier.gbd.soa.gateway.bo.ThirdPartyEmailLogging;

public class TPTServicesLogDaoImpl extends GenericDAOImpl implements TPTServicesLogDao
{
	private static final Logger LOGGER = LoggerFactory.getLogger(TPTServicesLogDaoImpl.class);
	private static final String SAVE_TPT_LOGGING_SP = "GBD.GBD_MEMBER_TPT_SERVICES_LOG";
	private static final String INSERT_EMAIL_LOGGING_SP = "GBD.GBD_EMAIL_LOGGING";
	
	//Added by Cognizant for TPC change March 2018 release - Start
	private static final String TPC_SAVE_TPT_LOGGING_SP = "OLX.OLX_MEMBER_TPT_SERVICES_LOG";
	private static final String TPC_INSERT_EMAIL_LOGGING_SP = "OLX.OLX_EMAIL_LOGGING";
	//Added by Cognizant for TPC change March 2018 release - End
	
	@Override
	public void saveTptServicesLog(TPTServicesLog logData)
	{
		LOGGER.debug("Inside saveTptServicesLog - Start");
		TPTServicesLogging logging = null;
		if(null != logData && null != logData.getRequestingSystem() && "TPC".equalsIgnoreCase(logData.getRequestingSystem())) {
			logging = new TPTServicesLogging(olxDataSource, TPC_SAVE_TPT_LOGGING_SP);
		} else {
			logging = new TPTServicesLogging(dataSource, SAVE_TPT_LOGGING_SP);
		}
		logging.executeTPTServicesLoggingSp(logData);
		LOGGER.debug("Inside saveTptServicesLog - End");
	}

	protected class TPTServicesLogging extends DAOStoredProc
	{
		protected TPTServicesLogging(DataSource ds, String spName){
			super(ds, spName);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@ISBUSINESSFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@ISSYSTEMFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEID", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEID", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEDDATE", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@TPTTRANSIDOUT", Types.BIGINT));

			compile();
		}

		protected void executeTPTServicesLoggingSp(TPTServicesLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", logDataBean.getSbrUid());
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXml());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXml());
			if (logDataBean.getRequestTs() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTs().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getResponseTs() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getResponseTs().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}
			inParams.put("@ISBUSINESSFAULT", logDataBean.getIsBusinessFault());
			inParams.put("@ISSYSTEMFAULT", logDataBean.getIsSystemFault());
			//Modified by Cognizant for TPC change March 2018 release - Start
			inParams.put("@CREATEID", logDataBean.getRequestingSystem());
			//Modified by Cognizant for TPC change March 2018 release - End
			inParams.put("@CREATEDDATE",  new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			//Modified by Cognizant for TPC change March 2018 release - Start
			inParams.put("@UPDATEID", logDataBean.getRequestingSystem());
			//Modified by Cognizant for TPC change March 2018 release - End
			inParams.put("@UPDATEDDATE",  new Timestamp(new Date().getTime()));

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@TPTTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@TPTTRANSIDOUT");
			}
		}
	}

	
	@Override
	public void saveEmailLog(ThirdPartyEmailLogging tppEmailLogging)
	{
		LOGGER.debug("Inside saveEmailLog - Start");
		ThirdPartyEmailLoggingQuery thirdPartyEmailLogging = null;
		if(null != tppEmailLogging && null != tppEmailLogging.getRequestingSystem() && "TPC".equalsIgnoreCase(tppEmailLogging.getRequestingSystem())) {
			thirdPartyEmailLogging = new ThirdPartyEmailLoggingQuery(olxDataSource, TPC_INSERT_EMAIL_LOGGING_SP);
		} else {
			thirdPartyEmailLogging = new ThirdPartyEmailLoggingQuery(dataSource, INSERT_EMAIL_LOGGING_SP);
		}
		thirdPartyEmailLogging.executeThirdPartyEmailLoggingSp(tppEmailLogging);
		LOGGER.debug("Inside saveEmailLog - End");
	}

	public class ThirdPartyEmailLoggingQuery extends DAOStoredProc
	{
		protected ThirdPartyEmailLoggingQuery(DataSource ds, String spName){
			super(ds, spName);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@FromID", Types.VARCHAR));
			declareParameter(new SqlParameter("@ToID", Types.VARCHAR));
			declareParameter(new SqlParameter("@Subject", Types.VARCHAR));
			declareParameter(new SqlParameter("@TemplateID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SentDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@DynamicContent", Types.CLOB));
			declareParameter(new SqlParameter("@MailType", Types.VARCHAR));
			declareParameter(new SqlParameter("@CreatedBy", Types.CHAR));
			declareParameter(new SqlParameter("@CreatedDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RequestingSystem", Types.CHAR));

			declareParameter(new SqlOutParameter("@IdOUT", Types.BIGINT));

			compile();
		}

		protected void executeThirdPartyEmailLoggingSp(ThirdPartyEmailLogging tppEmailLogging)
		{

			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", tppEmailLogging.getHcid());
			inParams.put("@SBRUID", tppEmailLogging.getSbrUID());
			inParams.put("@FromID", tppEmailLogging.getFromId());
			inParams.put("@ToID", tppEmailLogging.getToId());
			inParams.put("@Subject", tppEmailLogging.getSubject());
			inParams.put("@TemplateID", tppEmailLogging.getTemplateId());
			inParams.put("@SentDate", new Timestamp(new Date().getTime()));
			inParams.put("@DynamicContent", tppEmailLogging.getDynamicContent());
			inParams.put("@MailType", tppEmailLogging.getMailType());
			inParams.put("@CreatedBy", tppEmailLogging.getCreatedBy());
			inParams.put("@CreatedDate", new Timestamp(new Date().getTime()));
			inParams.put("@RequestingSystem", tppEmailLogging.getRequestingSystem());

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@IdOUT") != null)
			{
				long insertedId = (Long) outParams.get("@IdOUT");
				LOGGER.debug("Inserted successfully: "+insertedId);
			}
		}
	}


}
