/**
 * SOAServicesGatewayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 * 11/12/2017  2.0      Cognizant       TPC change March 2018
 */
package com.wellpoint.ebiz.middletier.tpp.dao.impl;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.tpp.dao.TransLogDAO;
import com.wellpoint.middletier.gbd.soa.gateway.bo.MbrPayTransLog;
 
public class TransLogDAOImpl extends GenericDAOImpl implements TransLogDAO{
 

	static final String SAVE_RS_LOGGING_SP = "GBD.GBD_MEMBER_RS_LOGS";
	
	//Modified by Cognizant for TPC change March 2018 release - Start
	private static final Logger LOGGER = LoggerFactory.getLogger(TransLogDAOImpl.class);
	
	static final String TPC_SAVE_RS_LOGGING_SP = "OLX.OLX_MEMBER_RS_LOGS";
	
	@Override
	public void saveMemberRSLog(MbrPayTransLog transLogDataBean) throws DataAccessException
	{
		RSServicesLogging logging = null;
		try{
			if(null != transLogDataBean && null != transLogDataBean.getRequestingSystem() && "TPC".equalsIgnoreCase(transLogDataBean.getRequestingSystem())) {
				logging = new RSServicesLogging(olxDataSource, TPC_SAVE_RS_LOGGING_SP);
			} else {
				logging = new RSServicesLogging(dataSource, SAVE_RS_LOGGING_SP);
			}
			logging.executeRSServicesLoggingSp(transLogDataBean);
		}catch(Exception e){
			LOGGER.error("Exception in TransLogDAOImpl saveMemberRSLog : "+e);
			/*e.printStackTrace();*/
		}
		
	}
	//Modified by Cognizant for TPC change March 2018 release - End
	
	protected class RSServicesLogging extends DAOStoredProc{
		
		protected RSServicesLogging(DataSource ds, String spName){
			super(ds, spName);
			
			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@CHANNEL", Types.VARCHAR));			
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@ERRORMSG", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));			
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
		 
			declareParameter(new SqlOutParameter("@RSTRANSID", Types.BIGINT));
			compile();
		}
		
		
		protected void executeRSServicesLoggingSp(MbrPayTransLog transLogDataBean)
		{			 
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", transLogDataBean.getHcid());
			inParams.put("@SBRUID", transLogDataBean.getSbrUid());
			inParams.put("@CHANNEL", transLogDataBean.getChannel());
			inParams.put("@OPERATIONNAME", transLogDataBean.getOperationName());
			inParams.put("@REQUESTXML", transLogDataBean.getRequestXML());
			inParams.put("@RESPONSEXML", transLogDataBean.getResponseXML());
			inParams.put("@ERRORMSG", transLogDataBean.getErrorMsg());
			inParams.put("@CREATEDDATE",  new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", transLogDataBean.getRequestingSystem());
		
			if(transLogDataBean.getRequestTs() != null) {
				inParams.put("@REQUESTTS",  new Timestamp(transLogDataBean.getRequestTs().getTime()));
			} else {
				inParams.put("@REQUESTTS",  null);
			}
			if(transLogDataBean.getResponseTs() != null) {
				inParams.put("@RESPONSETS",  new Timestamp(transLogDataBean.getResponseTs().getTime()));
			} else {
				inParams.put("@RESPONSETS",  null);
			}
			 

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@RSTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@RSTRANSIDOUT");
			}
		}
				
	}	
	
}
