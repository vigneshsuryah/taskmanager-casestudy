package com.wellpoint.ebiz.middletier.tpp.dao;

import javax.sql.DataSource;

public interface GenericDAO {

	public DataSource getDataSource();

	public void setDataSource(DataSource dataSource);
}
