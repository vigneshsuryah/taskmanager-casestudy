package com.wellpoint.ebiz.middletier.gbd.payment.dao.impl;


import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.jdbc.object.StoredProcedure;

import com.wellpoint.ebiz.middletier.gbd.payment.dao.GenericDAO;


public class GenericDAOImpl implements GenericDAO
{

	public static String UPDATE = "UPDATE";
	public static String DELETE = "DELETE";
	public static String NONE = "NONE";

	protected DataSource dataSource;

	public DataSource getDataSource()
	{
		return dataSource;
	}

	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}

	public void afterPropertiesSet() throws Exception
	{
		if (dataSource == null)
		{
			throw new BeanCreationException("Data Source Cannot Be Empty");
		}
	}

	protected abstract class DAOStoredProc extends StoredProcedure
	{

		protected DAOStoredProc(DataSource ds, String sp)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(sp);
		}
	}
}
