package com.wellpoint.ebiz.middletier.gbd.payment.dao;


import com.wellpoint.ebiz.middletier.gbd.payment.entity.PaymentDetailsLog;


public interface PaymentDetailsLogDao
{
	void savePaymentDetailsLog(PaymentDetailsLog dataBean) throws Exception;
}
