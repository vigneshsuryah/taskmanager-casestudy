package com.wellpoint.ebiz.middletier.gbd.payment.dao;


import com.wellpoint.ebiz.middletier.gbd.payment.entity.RecurringLog;


public interface RecurringLogDao
{
	void saveRecurringLog(RecurringLog dataBean) throws Exception;
}
