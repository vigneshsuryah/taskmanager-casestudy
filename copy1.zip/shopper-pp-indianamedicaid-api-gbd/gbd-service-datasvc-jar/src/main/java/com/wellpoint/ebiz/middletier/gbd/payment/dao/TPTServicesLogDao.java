package com.wellpoint.ebiz.middletier.gbd.payment.dao;

import com.wellpoint.ebiz.middletier.gbd.payment.entity.TPTServicesLog;

public interface TPTServicesLogDao
{
	void saveTptServicesLog(TPTServicesLog logData);
}
