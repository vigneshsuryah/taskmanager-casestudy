/**
* KYCashPayDAO.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 11/05/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.cashpay.payment.dao;

import com.wellpoint.cashpay.exception.KYCashPayException;
import com.wellpoint.cashpay.model.MemberDetaillsVO;
import com.wellpoint.cashpay.request.CashPayMessage;
import com.wellpoint.ebiz.middletier.cashpay.payment.model.CashPayBarCodeBean;

public interface KYCashPayDAO {
	
	CashPayBarCodeBean getBarCodeDetails(MemberDetaillsVO detaillsVO) throws KYCashPayException;
	
	CashPayBarCodeBean getBarCodeDetails(String barcodeNo) throws KYCashPayException;
	
	boolean hasPaymentIdAvailable(String paymentId) throws KYCashPayException;
	
	int savePaymentAndStoreInfo(CashPayMessage message,CashPayBarCodeBean barCodeBean) throws KYCashPayException;
	
	String updatePaymentStatus(String barCode,String paymentId) throws KYCashPayException;
	
	double getTotalAmtForBarCode(String barcodeNo) throws KYCashPayException;
	
	boolean hasInPrgPayment(String barcodeNo) throws KYCashPayException;
	
	CashPayBarCodeBean getInprogressPaymentDetails(String hcid) throws KYCashPayException;

}
