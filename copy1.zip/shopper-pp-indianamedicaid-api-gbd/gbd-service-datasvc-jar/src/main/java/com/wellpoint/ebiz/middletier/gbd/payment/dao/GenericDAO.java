package com.wellpoint.ebiz.middletier.gbd.payment.dao;

import javax.sql.DataSource;

public interface GenericDAO {

	public DataSource getDataSource();

	public void setDataSource(DataSource dataSource);
}
