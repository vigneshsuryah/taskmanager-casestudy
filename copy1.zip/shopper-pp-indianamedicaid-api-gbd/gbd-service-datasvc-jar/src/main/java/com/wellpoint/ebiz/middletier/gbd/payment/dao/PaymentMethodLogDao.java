package com.wellpoint.ebiz.middletier.gbd.payment.dao;


import com.wellpoint.ebiz.middletier.gbd.payment.entity.PaymentMethodLog;


public interface PaymentMethodLogDao
{
	void savePaymentMethodLog(PaymentMethodLog dataBean) throws Exception;
}
