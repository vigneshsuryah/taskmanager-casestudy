package com.wellpoint.ebiz.middletier.gbd.payment.dao.impl;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.gbd.payment.dao.RecurringLogDao;
import com.wellpoint.ebiz.middletier.gbd.payment.entity.RecurringLog;


public class RecurringLogDaoImpl extends GenericDAOImpl implements RecurringLogDao
{
	static final String UPDATE_TPT_LOGGING_SP = "GBD.GBD_RECURRING_LOG";

	@Override
	public void saveRecurringLog(RecurringLog logDataBean) throws Exception
	{
		RecurringDataLogging logging = new RecurringDataLogging(dataSource);
		logging.executeRecurringDataLoggingSp(logDataBean);
	}

	protected class RecurringDataLogging extends DAOStoredProc
	{

		protected RecurringDataLogging(DataSource ds)
		{

			super(ds, UPDATE_TPT_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@PRODUCTID", Types.CHAR));
			declareParameter(new SqlParameter("@TOKENID", Types.VARCHAR));
			declareParameter(new SqlParameter("@CSRUSERID", Types.CHAR));
			declareParameter(new SqlParameter("@PULLDAY", Types.CHAR));
			declareParameter(new SqlParameter("@STATUS", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@CREATEDBY", Types.CHAR));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@CONFIRMSTATUS", Types.CHAR));
			declareParameter(new SqlParameter("@ACTION", Types.CHAR));

			declareParameter(new SqlOutParameter("@RECURRIDOUT", Types.BIGINT));

			compile();
		}

		protected void executeRecurringDataLoggingSp(RecurringLog logDataBean)
		{

			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", logDataBean.getSbrUid());
			inParams.put("@PRODUCTID", logDataBean.getProductId());
			inParams.put("@TOKENID", logDataBean.getTokenId());
			inParams.put("@PULLDAY", logDataBean.getPullDay());
			inParams.put("@STATUS", logDataBean.getStatus());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			if(null != logDataBean.getRequestingSystem() && "KYTPP".equalsIgnoreCase(logDataBean.getRequestingSystem())){
				inParams.put("@CREATEDBY", logDataBean.getCsrUserId());
				inParams.put("@CSRUSERID", "");
			}else{
				inParams.put("@CREATEDBY", "GBD");
				inParams.put("@CSRUSERID", logDataBean.getCsrUserId());
			}
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParams.put("@CONFIRMSTATUS", logDataBean.getConfirmStatus());
			inParams.put("@ACTION", logDataBean.getAction());

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@RECURRIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@RECURRIDOUT");
			}
		}
	}
}
