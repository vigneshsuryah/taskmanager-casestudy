package com.wellpoint.ebiz.middletier.gbd.payment.dao.impl;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.gbd.payment.dao.PaymentDetailsLogDao;
import com.wellpoint.ebiz.middletier.gbd.payment.entity.PaymentDetailsLog;


public class PaymentDetailsLogDaoImpl extends GenericDAOImpl implements PaymentDetailsLogDao
{
	static final String UPDATE_PYMT_DETAILS_LOGGING_SP = "GBD.GBD_PAYMENT_DETAILS";

	@Override
	public void savePaymentDetailsLog(PaymentDetailsLog dataBean) throws Exception
	{
		PaymentDetailsLogging logging = new PaymentDetailsLogging(dataSource);
		logging.executePaymentDetailsLoggingSp(dataBean);
	}

	protected class PaymentDetailsLogging extends DAOStoredProc
	{

		protected PaymentDetailsLogging(DataSource ds)
		{

			super(ds, UPDATE_PYMT_DETAILS_LOGGING_SP);

			declareParameter(new SqlParameter("@PAYMENTHCID", Types.CHAR));
			declareParameter(new SqlParameter("@PAYMENTSBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@SUBMITTEDHCID", Types.CHAR));
			declareParameter(new SqlParameter("@PAYMENTCONFIRMNO", Types.VARCHAR));		
			declareParameter(new SqlParameter("@PAYMENTSTATUS", Types.VARCHAR));
			declareParameter(new SqlParameter("@PRODUCTID", Types.CHAR));
			declareParameter(new SqlParameter("@TOKENID", Types.CHAR));	
			declareParameter(new SqlParameter("@PAYMENTTYPE", Types.VARCHAR));
			declareParameter(new SqlParameter("@PAYMENTDATE", Types.VARCHAR));
			declareParameter(new SqlParameter("@PAIDAMOUNT", Types.DOUBLE));			
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@CREATEDBY", Types.CHAR));
			declareParameter(new SqlParameter("@ERRORREASON", Types.VARCHAR));			
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));			
			declareParameter(new SqlParameter("@STATEVAL", Types.CHAR));
 
			declareParameter(new SqlOutParameter("@PAYMENTDETAILSIDOUT", Types.BIGINT));

			compile();
		}

		protected void executePaymentDetailsLoggingSp(PaymentDetailsLog logDataBean)
		{ 
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@PAYMENTHCID", logDataBean.getPaymentHcid());
			inParams.put("@PAYMENTSBRUID", logDataBean.getPaymentSbrUid());
			inParams.put("@SUBMITTEDHCID", logDataBean.getSubmittedHcid());
			inParams.put("@PAYMENTCONFIRMNO", logDataBean.getPaymentConfirmNo());
			inParams.put("@PAYMENTSTATUS", logDataBean.getPaymentStatus());
			inParams.put("@PRODUCTID", logDataBean.getProductId());
			inParams.put("@TOKENID", logDataBean.getTokenId());
			inParams.put("@PAYMENTTYPE", logDataBean.getPaymentType());
			inParams.put("@PAYMENTDATE", logDataBean.getPaymentDate());
			inParams.put("@PAIDAMOUNT", logDataBean.getPaidAmount());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParams.put("@CREATEDBY", "GBD");
			inParams.put("@ERRORREASON", logDataBean.getErrorReason());
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParams.put("@STATEVAL", logDataBean.getStateVal());
					 

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@PAYMENTDETAILSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@PAYMENTDETAILSIDOUT");
			}
		}
	}

 
}
