package com.wellpoint.ebiz.middletier.gbd.payment.dao.impl;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.gbd.payment.dao.PaymentMethodLogDao;
import com.wellpoint.ebiz.middletier.gbd.payment.entity.PaymentMethodLog;


public class PaymentMethodLogDaoImpl extends GenericDAOImpl implements PaymentMethodLogDao
{
	static final String UPDATE_PYMT_MTHD_LOGGING_SP = "GBD.GBD_PYMTMTHD_LOG";

	@Override
	public void savePaymentMethodLog(PaymentMethodLog dataBean) throws Exception
	{
		PaymentDataLogging logging = new PaymentDataLogging(dataSource);
		logging.executePaymentDataLoggingSp(dataBean);
	}

	protected class PaymentDataLogging extends DAOStoredProc
	{

		protected PaymentDataLogging(DataSource ds)
		{

			super(ds, UPDATE_PYMT_MTHD_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));			
			declareParameter(new SqlParameter("@TOKENID", Types.VARCHAR));		
			declareParameter(new SqlParameter("@STATUS", Types.CHAR));
			declareParameter(new SqlParameter("@CSRUSERID", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@CREATEDBY", Types.CHAR));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@CONFIRMSTATUS", Types.CHAR));
			declareParameter(new SqlParameter("@ACTION", Types.CHAR));

			declareParameter(new SqlOutParameter("@PYMTMTHDOUT", Types.BIGINT));

			compile();
		}

		protected void executePaymentDataLoggingSp(PaymentMethodLog logDataBean)
		{ 
			Map<String, Object> inParam = new HashMap<String, Object>();
			inParam.put("@HCID", logDataBean.getHcid());
			inParam.put("@SBRUID", logDataBean.getSbrUid());			
			inParam.put("@TOKENID", logDataBean.getTokenId());			
			inParam.put("@STATUS", logDataBean.getStatus());
			inParam.put("@CSRUSERID", logDataBean.getCsrUserId());
			inParam.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParam.put("@CREATEDBY", "GBD");
			inParam.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParam.put("@CONFIRMSTATUS", logDataBean.getConfirmStatus());
			inParam.put("@ACTION", logDataBean.getAction());

			Map<String, Object> outParam = execute(inParam);
			if (outParam.get("@PYMTMTHDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParam.get("@PYMTMTHDOUT");
			}
		}
	}

 
}
