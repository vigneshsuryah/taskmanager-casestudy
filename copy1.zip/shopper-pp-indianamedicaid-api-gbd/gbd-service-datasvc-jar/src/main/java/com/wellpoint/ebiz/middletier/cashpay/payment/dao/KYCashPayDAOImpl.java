/**
* KYCashPayDAOImpl.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 11/05/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.cashpay.payment.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.stereotype.Repository;

import com.wellpoint.cashpay.exception.KYCashPayException;
import com.wellpoint.cashpay.model.MemberDetaillsVO;
import com.wellpoint.cashpay.request.CashPayMessage;
import com.wellpoint.ebiz.middletier.cashpay.payment.model.CashPayBarCodeBean;
import com.wellpoint.ebiz.middletier.gbd.payment.dao.impl.GenericDAOImpl;

@Repository("kyCashPayDAOImpl")
public class KYCashPayDAOImpl extends GenericDAOImpl implements KYCashPayDAO {
	
	static final String RETRIEVE_BARCODE_DETAILS = "OLX.KY_CASH_PAY_RETURN_BARCODE_NUMBER";
	static final String GET_PAY_INPRG_COUNT = "OLX.CASH_PAY_RETURN_INPROGRESS_PAYMENT_COUNT";
	static final String GET_BC_INFO = "OLX.CASH_PAY_RETURN_BC_INFO";
	static final String GET_PAY_ID_COUNT = "OLX.CASH_PAY_RETURN_PAYMENTID_COUNT";
	static final String UPD_PAY_STATUS = "OLX.CASH_PAY_UPDATE_PAYMENT_STATUS";
	static final String GET_TOT_AMT_FOR_BC = "OLX.CASH_PAY_RETURN_PAYMENT_AMOUNT";
	
	static final String GET_INPRG_PAYMENT_DETAILS_MEDICAID = "OLX.CASH_PAY_RETURN_PAYMENT_DETAILS_MEDICAID";
	static final String INPROGRESS_PAYMENT_STATUS = "Payment Processing";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(KYCashPayDAOImpl.class);
	
	/**
	 * Gets barcode information from database for a member
	 */
	@Override
	public CashPayBarCodeBean getBarCodeDetails(MemberDetaillsVO detaillsVO) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside getBarCodeDetails - start");
		RetrieveBarCodeInformation query = new RetrieveBarCodeInformation(dataSource);
		CashPayBarCodeBean cashPayBarCodeBean = null;
		try {
			List<CashPayBarCodeBean> cashPayBarCodeBeans = query.executeRetrieveBarCodeDetailsSp(detaillsVO.getHcid(),detaillsVO.getContractCode());
		    if(null != cashPayBarCodeBeans && cashPayBarCodeBeans.size() != 0){
		    	cashPayBarCodeBean = cashPayBarCodeBeans.get(0);
		    }
		} catch (Exception e) {
			LOGGER.error("Exception in getBarCodeDetails of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("KYCashPayDAOImpl: Inside getBarCodeDetails - end");
		return cashPayBarCodeBean;
	}
	
	public class RetrieveBarCodeInformation extends DAOStoredProc {

		protected RetrieveBarCodeInformation(DataSource ds) {

			super(ds, RETRIEVE_BARCODE_DETAILS);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@GROUP_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@LOB", Types.VARCHAR));
			declareParameter(new SqlReturnResultSet("rs", new CashPayBarCodeBeanRowMapper()));

			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<CashPayBarCodeBean> executeRetrieveBarCodeDetailsSp(
				String hcid, String contractCode) {

			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@GROUP_ID", contractCode);
			inParams.put("@LOB", "KYGBD");

			Map outParams = execute(inParams);
			return (List) outParams.get("rs");
		}
	}

	@SuppressWarnings("rawtypes")
	private class CashPayBarCodeBeanRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CashPayBarCodeBean barCodeBean = new CashPayBarCodeBean();
			barCodeBean.setBarCodeNo(rs.getString("BARCODE"));
			return barCodeBean;
		}
	}
	
	/**
	 * Gets inprogress payment for barcode number
	 */
	@Override
	public boolean hasInPrgPayment(String barcodeNo) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside hasInPrgPayment - start");
		GetPayInPrgCountQuery query = new GetPayInPrgCountQuery(dataSource);
		int count = 0;
		boolean inPrgPayment = false;
		try {
			count = query.executeGetPayInPrgCountSp(barcodeNo);
		} catch (Exception e) {
			LOGGER.error("Exception in hasInPrgPayment of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		if(count > 0){
			inPrgPayment = true;
		}
		LOGGER.info("KYCashPayDAOImpl: Inside hasInPrgPayment - end");
		return inPrgPayment;
	}
	
	public class GetPayInPrgCountQuery extends DAOStoredProc {

		protected GetPayInPrgCountQuery(DataSource ds ){

			super(ds, GET_PAY_INPRG_COUNT);
			declareParameter(new SqlParameter("@BARCODE", Types.VARCHAR));
			declareParameter(new SqlParameter("@PAYMENT_STATUS", Types.VARCHAR));
			declareParameter (new SqlOutParameter("@PAYMENT_STATUS_COUNT", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public int executeGetPayInPrgCountSp(String barcode) {

			Map inParams = new HashMap();
			inParams.put ("@BARCODE", barcode);
			inParams.put ("@PAYMENT_STATUS", "Payment Processing");
			Map outParams = execute(inParams);
			int payCount  = 0;

			try {
				payCount = (Integer) outParams.get("@PAYMENT_STATUS_COUNT");
			} catch (NullPointerException e) {
				LOGGER.error("Exception in GetPayInPrgCountQuery: KYCashPay");
			}
			return payCount;

		}
	}

	/**
	 * Gets member information based on barcode
	 */
	@Override
	public CashPayBarCodeBean getBarCodeDetails(String barcodeNo) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside getBarCodeDetails - start");
		GetBCInfo query = new GetBCInfo(dataSource);
		CashPayBarCodeBean cashPayBarCodeBean = null;
		try {
			List<CashPayBarCodeBean> cashPayBarCodeBeans = query.executeGetBCInfoSp(barcodeNo);
		    if(null != cashPayBarCodeBeans && cashPayBarCodeBeans.size() != 0){
		    	cashPayBarCodeBean = cashPayBarCodeBeans.get(0);
		    }
		} catch (Exception e) {
			LOGGER.error("Exception in getBarCodeDetails GetBCInfo of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("KYCashPayDAOImpl: Inside getBarCodeDetails - end");
		return cashPayBarCodeBean;
	}
	
	public class GetBCInfo extends DAOStoredProc {

		protected GetBCInfo(DataSource ds) {

			super(ds, GET_BC_INFO);
			declareParameter(new SqlParameter("@BARCODE", Types.VARCHAR));
			declareParameter(new SqlReturnResultSet("rs", new GetBCBeanRowMapper()));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<CashPayBarCodeBean> executeGetBCInfoSp(
				String barCodeNo) {

			Map inParams = new HashMap();
			inParams.put("@BARCODE", barCodeNo);
			Map outParams = execute(inParams);
			return (List) outParams.get("rs");
		}
	}
	
	@SuppressWarnings("rawtypes")
	private class GetBCBeanRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CashPayBarCodeBean barCodeBean = new CashPayBarCodeBean();
			barCodeBean.setBarCodeNo(rs.getString("BARCODE"));
			barCodeBean.setHcid(rs.getString("HCID"));
			barCodeBean.setContractCode(rs.getString("PRODUCT_ID"));
			barCodeBean.setSubGroupId(rs.getString("SUBGROUP_ID"));
			barCodeBean.setSummaryBillNo(rs.getString("SUMMARY_BILL_NO"));
			return barCodeBean;
		}
	}

	/**
	 * Check payment exists with payment id in DB
	 */
	@Override
	public boolean hasPaymentIdAvailable(String paymentId) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside hasPaymentIdAvailable - start");
		GetPayIdCountQuery query = new GetPayIdCountQuery(dataSource);
		int count = 0;
		boolean paymentIdAvailable = false;
		try {
			count = query.executeGetPayIdCountSp(paymentId);
		} catch (Exception e) {
			LOGGER.error("Exception in hasPaymentIdAvailable of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		if(count > 0){
			paymentIdAvailable = true;
		}
		LOGGER.info("KYCashPayDAOImpl: Inside hasPaymentIdAvailable - end");
		return paymentIdAvailable;
	}
	
	public class GetPayIdCountQuery extends DAOStoredProc {

		protected GetPayIdCountQuery(DataSource ds ){

			super(ds, GET_PAY_ID_COUNT);
			declareParameter(new SqlParameter("@PAYMENTID", Types.VARCHAR));
			declareParameter (new SqlOutParameter("@PAYMENTID_COUNT", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public int executeGetPayIdCountSp(String paymentId) {

			Map inParams = new HashMap();
			inParams.put ("@PAYMENTID", paymentId);
			Map outParams = execute(inParams);
			int payCount  = 0;

			try {
				payCount = (Integer) outParams.get("@PAYMENTID_COUNT");
			} catch (NullPointerException e) {
				LOGGER.error("Exception in GetPayIdCountQuery: KYCashPay");
			}
			return payCount;

		}
	}

	/**
	 * Save Payment and Store information in DB
	 */
	@Override
	public int savePaymentAndStoreInfo(CashPayMessage message,CashPayBarCodeBean barCodeBean) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside savePaymentAndStoreInfo - start");
		int insertedCount = 0;
		try {
			Connection connection = dataSource.getConnection();
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			Object[] paymentAttributes = new Object[] {
					message.getPayment().getBarcode_number(),
					message.getPayment().getUpc(),
					barCodeBean.getLegalEntity(),
					barCodeBean.getMarketSegment(),
					message.getPayment().getValue().getAmount(),
					barCodeBean.getDueDate(), 
					barCodeBean.getBillDate(), 
					barCodeBean.getResponseId(),
					barCodeBean.getDivisionCode(),
					"Payment Processing",
					message.getPayment().getId(),
					null,
					message.getRetailer().getRetailer_reference_number(),
					message.getRetailer().getName(),
					message.getCashtie_reference_number(),
					null,
					null,
					barCodeBean.getHcid(),
					timestamp
					};
			Object[] storeAttributes = new Object[] {
					null != message.getStore() ? message.getStore().getId(): null,
					null,
					null != message.getStore() ? message.getStore().getAddress1(): null,
					null != message.getStore() ? message.getStore().getAddress2(): null,
					null != message.getStore() ? message.getStore().getCity(): null,
					null != message.getStore() ? message.getStore().getCounty(): null,
					null != message.getStore() ? message.getStore().getState(): null,
					null != message.getStore() ? message.getStore().getZip_code(): null,
					null != message.getStore() ? message.getStore().getCountry(): null,
					null != message.getStore() ? message.getStore().getPhone_numbers().toString(): null,
					null != message.getStore() ? message.getStore().getTerminal_id(): null,
					null,
					null,
					barCodeBean.getHcid(),
					timestamp
					};
			Struct rowTypePayment = connection.createStruct("OLX.ROWTYPE_CASH_PAY_CASHPAYMENTS", paymentAttributes);
			Struct rowTypeStore = connection.createStruct("OLX.ROWTYPE_CASH_PAY_STOREDETAILS", storeAttributes);
					
			
			CallableStatement cstmt = connection.prepareCall("CALL OLX.CASH_PAY_PERSIST_PAYMENT_AND_STORE_DETAILS(?,?,?)");
			cstmt.setObject(1, rowTypePayment);
			cstmt.setObject(2, rowTypeStore);
			cstmt.registerOutParameter (3, Types.BIGINT);
			cstmt.execute();
			if(null != cstmt.getBigDecimal(3)){
				insertedCount = cstmt.getBigDecimal(3).intValue();
			}
		} catch (Exception e) {
			LOGGER.error("Exception in savePaymentAndStoreInfo of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("KYCashPayDAOImpl: Inside savePaymentAndStoreInfo - end");
		return insertedCount;
	}

	/**
	 * Update payment status for the barcode no and payment id 
	 */
	@Override
	public String updatePaymentStatus(String barCode,String paymentId) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside updatePaymentStatus - start");
		UpdatePaymentStatusQuery query = new UpdatePaymentStatusQuery(dataSource);
		String message = "";
		try {
			message = query.executeUpdatePaymentStatusQuery(barCode,paymentId);
		} catch (Exception e) {
			LOGGER.error("Exception in updatePaymentStatus of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("KYCashPayDAOImpl: Inside updatePaymentStatus - end");
		return message;
	}
	
	private class UpdatePaymentStatusQuery extends DAOStoredProc {
		
		protected UpdatePaymentStatusQuery(DataSource ds) {

			super(ds, UPD_PAY_STATUS);
			declareParameter(new SqlParameter("@BARCODE", Types.VARCHAR));
			declareParameter(new SqlParameter("@PAYMENTID", Types.VARCHAR));
			declareParameter (new SqlOutParameter("@RESPONSE_MSG", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeUpdatePaymentStatusQuery(String barCode,String paymentId) {

			Map inParams = new HashMap();
			inParams.put("@BARCODE", barCode);
			inParams.put("@PAYMENTID", paymentId);
			
			String msg = "";
			Map outParams = execute(inParams);
			try {
				msg = (String) outParams.get("@RESPONSE_MSG");
			} catch (NullPointerException e) {
				LOGGER.error("Exception in UpdatePaymentStatusQuery");
			}
			return msg;
		}
	}

	/**
	 * Gets total inprogress amount for the barcode number
	 */
	@Override
	public double getTotalAmtForBarCode(String barcodeNo) throws KYCashPayException {
		LOGGER.info("KYCashPayDAOImpl: Inside getTotalAmtForBarCode - start");
		GetTotalAmtForBCQuery query = new GetTotalAmtForBCQuery(dataSource);
		double totalAmt = 0.0;
		try {
			totalAmt = query.executeGetTotalAmtForBCSp(barcodeNo);
		} catch (Exception e) {
			LOGGER.error("Exception in getTotalAmtForBarCode of KYCashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("KYCashPayDAOImpl: Inside getTotalAmtForBarCode - end");
		return totalAmt;
	}
	
	public class GetTotalAmtForBCQuery extends DAOStoredProc {

		protected GetTotalAmtForBCQuery(DataSource ds ){

			super(ds, GET_TOT_AMT_FOR_BC);
			declareParameter(new SqlParameter("@BARCODE", Types.VARCHAR));
			declareParameter (new SqlOutParameter("@PAYMENT_AMOUNT", Types.DOUBLE));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public double executeGetTotalAmtForBCSp(String barcode) {

			Map inParams = new HashMap();
			inParams.put ("@BARCODE", barcode);
			Map outParams = execute(inParams);
			double amount = 0.0;

			try {
				amount = (Double) outParams.get("@PAYMENT_AMOUNT");
			} catch (NullPointerException e) {
				LOGGER.error("Exception in GetTotalAmtForBCQuery");
			}
			return amount;
		}
	}	
	
	/**
	 * Gets in progress payment for hcid
	 */
	@Override
	public CashPayBarCodeBean getInprogressPaymentDetails(String hcid) throws KYCashPayException {
		LOGGER.info("CashPayDAOImpl: Inside getInprogressPaymentDetails - start");
		GetInprgPaymentDetailsQuery query = new GetInprgPaymentDetailsQuery(dataSource);
		CashPayBarCodeBean cashPayBarCodeBean = new CashPayBarCodeBean();
		List<CashPayBarCodeBean> cashPayBarCodeBeans = null;
		try {
				cashPayBarCodeBeans = query.getInprogressPaymentDetailsSp(hcid, INPROGRESS_PAYMENT_STATUS);
			    if(null != cashPayBarCodeBeans && cashPayBarCodeBeans.size() != 0){
			    	cashPayBarCodeBean = cashPayBarCodeBeans.get(0);
			    }
			
		} catch (Exception e) {
			LOGGER.error("Exception in getInprogressPaymentDetails of CashPayDAOImpl "+e);
			throw new KYCashPayException("E", "CP1000", "We've encountered a technical error", 500);
		}
		LOGGER.info("CashPayDAOImpl: Inside getInprogressPaymentDetails - end");
		return cashPayBarCodeBean;
	}

	public class GetInprgPaymentDetailsQuery extends DAOStoredProc {

		protected GetInprgPaymentDetailsQuery(DataSource ds) {

			super(ds, GET_INPRG_PAYMENT_DETAILS_MEDICAID);

			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@PAYMENT_STATUS", Types.VARCHAR));
			
			declareParameter(new SqlReturnResultSet("rs",new InprgPaymentDetailsRowMapper()));

			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<CashPayBarCodeBean> getInprogressPaymentDetailsSp(String hcid, String paymentStatus) {

			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@PAYMENT_STATUS", paymentStatus);

			Map outParams = execute(inParams);
			return (List) outParams.get("rs");
		}
	}

	@SuppressWarnings("rawtypes")
	private class InprgPaymentDetailsRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CashPayBarCodeBean barCodeBean = new CashPayBarCodeBean();
			barCodeBean.setHcid(rs.getString("HCID"));
			barCodeBean.setPaymentAmount(rs.getBigDecimal("PAYMENT_AMOUNT"));
			barCodeBean.setBillDate(rs.getTimestamp("PAYMENT_DATE"));
			return barCodeBean;
		}
	}

}
