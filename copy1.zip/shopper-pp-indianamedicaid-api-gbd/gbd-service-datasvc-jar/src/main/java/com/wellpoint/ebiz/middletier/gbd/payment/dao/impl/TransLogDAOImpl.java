package com.wellpoint.ebiz.middletier.gbd.payment.dao.impl;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import com.wellpoint.ebiz.middletier.gbd.payment.dao.TransLogDAO;
import com.wellpoint.ebiz.middletier.gbd.payment.entity.MbrPayTransLog;
import com.wellpoint.memberpay.model.MemberPayEmailLogging;
 

public class TransLogDAOImpl extends GenericDAOImpl implements TransLogDAO{
 

	static final String SAVE_RS_LOGGING_SP = "GBD.GBD_MEMBER_RS_LOGS";
	
	static final String GBD_EMAIL_LOGGING_SP = "GBD.GBD_EMAIL_LOGGING";
	
	@Override
	public void saveMemberRSLog(MbrPayTransLog transLogDataBean) throws DataAccessException
	{
		RSServicesLogging logging = new RSServicesLogging(dataSource);
		logging.executeRSServicesLoggingSp(transLogDataBean); 
		
	}
	
	protected class RSServicesLogging extends DAOStoredProc{
		
		protected RSServicesLogging(DataSource ds){
			
			super(ds,SAVE_RS_LOGGING_SP);
			
			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@CHANNEL", Types.VARCHAR));			
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@ERRORMSG", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));			
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
		 
			declareParameter(new SqlOutParameter("@RsTransIdOUT", Types.BIGINT));
			compile();
		}
		
		
		protected void executeRSServicesLoggingSp(MbrPayTransLog transLogDataBean)
		{			 
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", transLogDataBean.getHcid());
			inParams.put("@SBRUID", transLogDataBean.getSbrUid());
			inParams.put("@CHANNEL", transLogDataBean.getChannel());
			inParams.put("@OPERATIONNAME", transLogDataBean.getOperationName());
			inParams.put("@REQUESTXML", transLogDataBean.getRequestXML());
			inParams.put("@RESPONSEXML", transLogDataBean.getResponseXML());
			inParams.put("@ERRORMSG", transLogDataBean.getErrorMsg());
			inParams.put("@CREATEDDATE",  new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", transLogDataBean.getRequestingSystem());
		
			if(transLogDataBean.getRequestTs() != null) {
				inParams.put("@REQUESTTS",  new Timestamp(transLogDataBean.getRequestTs().getTime()));
			} else {
				inParams.put("@REQUESTTS",  null);
			}
			if(transLogDataBean.getResponseTs() != null) {
				inParams.put("@RESPONSETS",  new Timestamp(transLogDataBean.getResponseTs().getTime()));
			} else {
				inParams.put("@RESPONSETS",  null);
			}
			 

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@RSTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@RSTRANSIDOUT");
			}
		}
				
	}	
	
	@Override
	public void logEmail(MemberPayEmailLogging memberpayEmailLogging, String senderApp, String subscriberId) throws DataAccessException
	{
		EmailLogging logging = new EmailLogging(dataSource);
		logging.executeEmailLoggingSp(memberpayEmailLogging, senderApp, subscriberId); 
		
	}
	
	protected class EmailLogging extends DAOStoredProc{
		
		protected EmailLogging(DataSource ds){
			
			super(ds, GBD_EMAIL_LOGGING_SP);
			
			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@FromID", Types.VARCHAR));			
			declareParameter(new SqlParameter("@ToID", Types.VARCHAR));
			declareParameter(new SqlParameter("@Subject", Types.VARCHAR));
			declareParameter(new SqlParameter("@TemplateID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SentDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@DynamicContent", Types.CLOB));
			declareParameter(new SqlParameter("@MailType", Types.VARCHAR));			
			declareParameter(new SqlParameter("@CreatedBy", Types.CHAR));
			declareParameter(new SqlParameter("@CreatedDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RequestingSystem", Types.CHAR));
		 
			declareParameter(new SqlOutParameter("@IdOUT", Types.BIGINT));
			compile();
		}
		
		
		protected void executeEmailLoggingSp(MemberPayEmailLogging memberpayEmailLogging, String senderApp, String subscriberId)
		{			 
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", memberpayEmailLogging.getHcid());
			inParams.put("@SBRUID", subscriberId);
			inParams.put("@FromID", memberpayEmailLogging.getFrom());
			inParams.put("@ToID", memberpayEmailLogging.getTo());
			inParams.put("@Subject", memberpayEmailLogging.getSubject());
			inParams.put("@TemplateID", memberpayEmailLogging.getTemplateId());
			inParams.put("@SentDate", new Timestamp(new Date().getTime()));
			inParams.put("@DynamicContent", memberpayEmailLogging.getDynamicContent());
			inParams.put("@MailType", memberpayEmailLogging.getMailType());
			inParams.put("@CreatedBy", memberpayEmailLogging.getCreatedBy());
			inParams.put("@CreatedDate", new Timestamp(new Date().getTime()));
			inParams.put("@RequestingSystem", senderApp);
		
			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@IdOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@IdOUT");
			}
		}
				
	}
}
