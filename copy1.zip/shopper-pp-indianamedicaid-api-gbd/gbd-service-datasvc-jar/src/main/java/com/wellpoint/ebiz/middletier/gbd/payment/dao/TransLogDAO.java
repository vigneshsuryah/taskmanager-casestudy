package com.wellpoint.ebiz.middletier.gbd.payment.dao;

import org.springframework.dao.DataAccessException;

import com.wellpoint.ebiz.middletier.gbd.payment.entity.MbrPayTransLog;
import com.wellpoint.memberpay.model.MemberPayEmailLogging;
 

public interface TransLogDAO{
	void saveMemberRSLog(MbrPayTransLog transLogDataBean) throws DataAccessException;
	
	void logEmail(MemberPayEmailLogging memberpayEmailLogging, String senderApp, String subscriberId);
}
