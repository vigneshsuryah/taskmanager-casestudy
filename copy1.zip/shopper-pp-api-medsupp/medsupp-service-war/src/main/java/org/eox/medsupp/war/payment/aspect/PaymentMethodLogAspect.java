/**
 * PaymentMethodLogAspect.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.war.payment.aspect;


import java.util.Date;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.eox.medsupp.datasvc.payment.entity.PaymentDetailsLog;
import org.eox.medsupp.datasvc.payment.entity.PaymentMethodLog;
import org.eox.medsupp.datasvc.payment.entity.PaymentTypeEnum;
import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;
import org.eox.medsupp.schema.request.SubmitPaymentRequest;
import org.eox.medsupp.schema.request.UpdatePaymentMethodRequest;
import org.eox.medsupp.schema.response.SubmitPaymentResponse;
import org.eox.medsupp.schema.response.UpdatePaymentMethodResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class PaymentMethodLogAspect implements MedicarePayConstants
{
	private final static Logger LOGGER = LoggerFactory.getLogger(PaymentMethodLogAspect.class);

	@Autowired
	private MedicarePayGateway medicarePayGateway;

	@Around("execution(* org.eox.medsupp.jar.payment.service.MedicarePayService.updatePaymentMethod(..))")
	public Object paymentMethodLogAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable
	{
		LOGGER.debug("Inside PaymentMethodLogAspect paymentMethodLogAroundAdvice start");
		PaymentMethodLog logObj = new PaymentMethodLog();
		Object[] objs = proceedingJoinPoint.getArgs();
		UpdatePaymentMethodRequest request = (UpdatePaymentMethodRequest) objs[0];
		if (null != request)
		{
			logObj.setRequestingSystem(request.getServiceEnv());
			logObj.setAction(request.getAction());
			logObj.setHcid(request.getHealthCardId());
			logObj.setCreatedBy(request.getHealthCardId());

			if (null != request.getPaymentMethod() && null != request.getPaymentMethod().getTokenId())
			{
				logObj.setTokenId(request.getPaymentMethod().getTokenId());
			}
			if (null != request.getPaymentMethod() && null != request.getPaymentMethod().getBankAccountType())
			{
				logObj.setAccountType(request.getPaymentMethod().getBankAccountType().name());
			}
		}
		UpdatePaymentMethodResponse value = null;
		try
		{
			value = (UpdatePaymentMethodResponse) proceedingJoinPoint.proceed();
		} catch (Throwable e)
		{
			logObj.setStatus("Failure");
			LOGGER.error("Exception in paymentMethodLogAroundAdvice catch block : ", e);
			try
			{
				medicarePayGateway.savePaymentMethodLog(logObj);
			} catch (Exception ex)
			{
				LOGGER.error("Exception in paymentMethodLogAroundAdvice savePaymentMethodLog catch block : ", ex);
			}
			throw e;
		}
		if (null != value && null != value.getMessage() && null != value.getMessage().getMessageCode()
				&& ("0".equalsIgnoreCase(value.getMessage().getMessageCode()) || "1075".equalsIgnoreCase(value.getMessage().getMessageCode())))
		{
			logObj.setStatus("Success");
			if (null == logObj.getTokenId())
			{
				logObj.setTokenId(value.getMedicarePayPaymentMethod().getTokenId());
			}
		}
		else
		{
			logObj.setStatus("Failure");
		}
		try
		{
			medicarePayGateway.savePaymentMethodLog(logObj);
		} catch (Exception e)
		{
			LOGGER.debug("PaymentMethodLogAspect paymentMethodLogAroundAdvice savePaymentMethodLog " + e);
		}
		LOGGER.debug("Inside PaymentMethodLogAspect paymentMethodLogAroundAdvice End");
		return value;
	}

	@Around("execution(* org.eox.medsupp.jar.payment.service.MedicarePayService.submitPayment(..))")
	public Object paymentDetailsLogAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable
	{
		LOGGER.debug("Inside PaymentMethodLogAspect paymentDetailsLogAroundAdvice start");
		PaymentDetailsLog detailsObj = new PaymentDetailsLog();
		Object[] objs = proceedingJoinPoint.getArgs();
		String tempPaymentType = "";
		SubmitPaymentRequest request = (SubmitPaymentRequest) objs[0];
		if (request != null)
		{
			detailsObj.setRequestingSystem(request.getServiceEnv());
			detailsObj.setPaymentDate(request.getPaymentDate());
			detailsObj.setSubmittedHcid(request.getHealthCardId());
			detailsObj.setPaymentHcid(request.getHealthCardId());
			detailsObj.setStateVal("");
			detailsObj.setCreatedBy(request.getHealthCardId());
			detailsObj.setPaymentDate(MedicarePayUtils.dateToStr(new Date()));
			tempPaymentType = request.getPaymentType().toString();

			if (tempPaymentType.equals("CREDITDEBITCARD"))
			{
				detailsObj.setPaymentType(PaymentTypeEnum.CREDITDEBITCARD);
			}
			else if (tempPaymentType.equals("BANKINGACCOUNT"))
			{
				detailsObj.setPaymentType(PaymentTypeEnum.BANKINGACCOUNT);
			}
			else
			{
				detailsObj.setPaymentType(PaymentTypeEnum.NONE);
			}

			detailsObj.setTokenId(request.getTokenId());

			List<MemberPaySubmitPayment> items = request.getMemberpaySubmitPayments();

			if (items != null && !items.isEmpty() && items.get(0) != null)
			{
				MemberPaySubmitPayment detail = items.get(0);

				detailsObj.setPaidAmount(detail.getPaymentAmount());
				detailsObj.setSubGroupId(detail.getPlanID());
			}
		}
		SubmitPaymentResponse value = null;
		try
		{
			value = (SubmitPaymentResponse) proceedingJoinPoint.proceed();
		} catch (Exception e)
		{
			detailsObj.setPaymentStatus("Failure");
			detailsObj.setErrorReason(e.getMessage());
			try
			{
				medicarePayGateway.savePaymentDetailsLog(detailsObj);
			} catch (Exception ex)
			{
				LOGGER.error("paymentDetailsLogAroundAdvice catch - ", ex);
			}
			throw e;
		}

		if (value != null && value.getMemberpaySubmitPayments() != null)
		{
			List<MemberPaySubmitPayment> itemsResult = value.getMemberpaySubmitPayments();
			if (itemsResult != null && !itemsResult.isEmpty() && itemsResult.get(0) != null)
			{
				detailsObj.setPaymentConfirmNo(itemsResult.get(0).getConfirmationNumber());
				detailsObj.setPaymentStatus(itemsResult.get(0).getStatus());
				if (itemsResult.get(0).getStatus().equals("Failure"))
				{
					detailsObj.setErrorReason(itemsResult.get(0).getMessage().getMessageText());
				}
			}
		}
		try
		{
			medicarePayGateway.savePaymentDetailsLog(detailsObj);
		} catch (Exception e)
		{
			LOGGER.debug("PaymentMethodLogAspect paymentDetailsLogAroundAdvice : " + e);
		}
		LOGGER.debug("Inside PaymentMethodLogAspect paymentDetailsLogAroundAdvice end");
		return value;
	}

}
