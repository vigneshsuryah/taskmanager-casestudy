/**
 * MedicarePayAspect.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.war.payment.aspect;


import java.lang.reflect.UndeclaredThrowableException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.eox.medsupp.datasvc.payment.entity.RSTransLog;
import org.eox.medsupp.jar.payment.service.MedicarePayService;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.request.BaseRequest;
import org.eox.medsupp.schema.response.BaseResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.eox.medsupp.schema.utility.MedicarePayAccessProviderUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;

import com.fasterxml.jackson.databind.ObjectMapper;


@Aspect
@RefreshScope
public class MedicarePayAspect implements MedicarePayConstants
{
	@Autowired
	private MedicarePayService medicarePayServiceImpl;

	@Value("${medicarepay.setting.payment.ui.restconsumer.service.allowed.applications}")
	private String allowedApplication;

	@Value("${medicarepay.setting.check.metasenderapp.value}")
	private String metaSenderAppCheckFlag;

	final static Logger LOGGER = Logger.getLogger(MedicarePayAspect.class);

	@Before("execution(* org.eox.medsupp.jar.payment.service.*.*(..)) && "
			+ "!execution(* org.eox.medsupp.jar.payment.service.MedicarePayService.saveRSLog(..))")
	public void logBefore(JoinPoint joinPoint) throws MedicarePayException
	{
		Object[] objs = joinPoint.getArgs();
		LOGGER.info("About to intercept request");
		boolean hasBaseRequest = false;
		for (Object obj : objs)
		{
			if (obj instanceof BaseRequest)
			{
				hasBaseRequest = true;
				BaseRequest request = (BaseRequest) obj;
				String requestingApplication = request.getServiceEnv();
				MDC.put("requestingApplication", requestingApplication);
				String secureUserName = MedicarePayUtils.getStringProperty("medicarepay.setting.payment.ui.restconsumer.service.username."
						+ requestingApplication, "");
				String securePassword = MedicarePayUtils.getStringProperty("medicarepay.setting.payment.ui.restconsumer.service.password."
						+ requestingApplication, "");
				String secureAlgorithm = MedicarePayUtils.getStringProperty(
						"medicarepay.setting.payment.ui.restconsumer.service.algorithm." + requestingApplication, "");
				String secureKey = MedicarePayUtils.getStringProperty("medicarepay.setting.payment.ui.restconsumer.service.key."
						+ requestingApplication, "");
				if (metaSenderAppCheckFlag != null && metaSenderAppCheckFlag.equalsIgnoreCase("Y"))
				{
					if (allowedApplication == null || allowedApplication.isEmpty() || requestingApplication == null
							|| requestingApplication.isEmpty()
							|| !MedicarePayUtils.checkReqAppEndPoint(requestingApplication, request.getEndPointName()))
					{
						LOGGER.error("Access Denied....Request header missing");
						throw new MedicarePayException(INFORMATION, ERROR_CODE_9011, "Access Denied....In-Valid Requesting Application", 401);
					}
				}
				if (request.getRequestHeader() == null)
				{
					LOGGER.error("Access Denied....Request header missing");
					throw new MedicarePayException(INFORMATION, ERROR_CODE_9012, "Access Denied. Request header missing", 403);
				}
				if (request.getRequestHeader() != null
						&& !MedicarePayAccessProviderUtils.authenticateUserName(request.getRequestHeader().getUserName(), secureUserName))
				{
					LOGGER.error("Access denied In-Valid User Name");
					throw new MedicarePayException(INFORMATION, ERROR_CODE_9013, "Access Denied. In-Valid User Name", 401);
				}

				if (request.getRequestHeader() != null
						&& !MedicarePayAccessProviderUtils.authenticatePassword(request.getRequestHeader().getPassword(), secureKey,
								secureAlgorithm, securePassword))
				{
					LOGGER.error("Access denied In-Valid Password");
					throw new MedicarePayException(INFORMATION, ERROR_CODE_9014, "Access Denied. In-Valid Password", 401);
				}
			}
		}
		if (!hasBaseRequest)
		{
			LOGGER.error("Access denied illegal request");
			throw new MedicarePayException(INFORMATION, ERROR_CODE_9015, "Access Denied. Illegal Request", 403);
		}
	}

	@AfterThrowing(pointcut = "execution(* org.eox.medsupp.jar.payment.service.*.*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error)
	{

		LOGGER.error("Suspected error in the request::" + error);

	}

	@Around("allMethodsPointcut()")
	public Object trackReqRes(ProceedingJoinPoint joinPoint) throws Throwable
	{
		Object response = null;
		HttpServletRequest httpRequest = null;
		ObjectMapper mapper = new ObjectMapper();
		RSTransLog rSTransLog = new RSTransLog();
		rSTransLog.setChannel("Application");
		String operationName = joinPoint.getSignature().getName() == null ? " " : joinPoint.getSignature().getName();
		rSTransLog.setOperationName(operationName);
		rSTransLog.setCreatedDate(new Date());
		try
		{
			Object[] objs = joinPoint.getArgs();
			String requestingSystem = "";
			for (Object obj : objs)
			{
				if (obj instanceof HttpServletRequest)
				{
					httpRequest = (HttpServletRequest) obj;
					if (null != httpRequest && null != httpRequest.getHeader("meta-senderapp"))
					{
						requestingSystem = httpRequest.getHeader("meta-senderapp");
					}
				}

				if (obj instanceof BaseRequest)
				{
					String hcid = ((BaseRequest) obj).getHealthCardId() != null ? ((BaseRequest) obj).getHealthCardId() : "";
					rSTransLog.setRequestTS(new Date());
					rSTransLog.setHcid(hcid);
					rSTransLog.setRequestXML(mapper.writeValueAsString(obj));
				}
			}
			rSTransLog.setRequestingSystem(requestingSystem);
			response = joinPoint.proceed();
			rSTransLog.setResponseTS(new Date());
			if (response instanceof BaseResponse)
			{
				if (null != ((BaseResponse) response).getMedicarePayException())
				{
					rSTransLog.setErrorMsg(mapper.writeValueAsString(response));
				}
				else
				{
					rSTransLog.setResponseXML(mapper.writeValueAsString(response));
				}
			}
			if (rSTransLog.getRequestXML() == null || rSTransLog.getRequestXML().isEmpty())
			{
				rSTransLog.setRequestXML(" ");
			}
			medicarePayServiceImpl.saveRSLog(rSTransLog);
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in trackReqRes :" + e);
			rSTransLog.setResponseTS(new Date());
			if (e instanceof UndeclaredThrowableException)
			{
				UndeclaredThrowableException unEx = (UndeclaredThrowableException) e;
				if (unEx.getUndeclaredThrowable() instanceof MedicarePayException)
				{
					MedicarePayException mpex = (MedicarePayException) unEx.getUndeclaredThrowable();
					rSTransLog.setErrorMsg(mpex.getErrorMessage());
					rSTransLog.setResponseXML(null != response ? mapper.writeValueAsString(response) : mpex.getErrorMessage());
				}
			}
			else
			{
				rSTransLog.setErrorMsg(TECHNICAL_ERROR_MSG);
				rSTransLog.setResponseXML(TECHNICAL_ERROR_MSG);
			}
			try
			{
				medicarePayServiceImpl.saveRSLog(rSTransLog);
			} catch (Exception ex)
			{
				LOGGER.error("Exception occured in trackReqRes - saving RS log :" + e);
			}
			throw e;
		}
		MDC.clear();
		return response;
	}

	@Pointcut("execution(* org.eox.medsupp.war.payment.controller.MedicarePayRestController.*(..))")
	public void allMethodsPointcut()
	{
	}

}
