/**
 * PPAppSpringBootApplication.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;


@SpringBootApplication
@EnableAspectJAutoProxy
@EnableCircuitBreaker
@ImportResource({ "classpath:medicarePay_mapping.xml", "classpath:chub-integration-context.xml", "classpath:root-integration-context.xml" })
public class PPAppSpringBootApplication extends SpringBootServletInitializer
{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
	{
		return application.sources(PPAppSpringBootApplication.class);
	}

	public static void main(String[] args)
	{
		SpringApplication.run(PPAppSpringBootApplication.class, args);
	}
}