/**
 * MedicarePayExceptionHandler.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.war.payment.exception;


import java.lang.reflect.UndeclaredThrowableException;
import java.util.Arrays;

import javax.servlet.http.HttpServletResponse;

import org.eox.medsupp.schema.exception.ExceptionResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;


@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class MedicarePayExceptionHandler implements MedicarePayConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MedicarePayExceptionHandler.class);

	@ExceptionHandler(Exception.class)
	public @ResponseBody
	ExceptionResponse handleCustomException(Exception ex, HttpServletResponse response)
	{
		response.setHeader("Content-Type", "application/json");
		if (ex instanceof MedicarePayException)
		{
			response.setStatus(((MedicarePayException) ex).getReturnStatus());
			return ((MedicarePayException) ex).transformException();
		}
		else if (ex instanceof UndeclaredThrowableException)
		{
			UndeclaredThrowableException unEx = (UndeclaredThrowableException) ex;
			if (unEx.getUndeclaredThrowable() instanceof MedicarePayException)
			{
				MedicarePayException mpex = (MedicarePayException) unEx.getUndeclaredThrowable();
				response.setStatus(mpex.getReturnStatus());
				return mpex.transformException();
			}
			else
			{
				response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				return returnRestError();
			}
		}
		else
		{
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			return returnRestError();
		}
	}

	private ExceptionResponse returnRestError()
	{
		ExceptionResponse restError = new ExceptionResponse();
		org.eox.medsupp.schema.exception.Exception exception = new org.eox.medsupp.schema.exception.Exception();
		exception.setType(EXCEPTION);
		exception.setCode(ERROR_CODE_9000);
		exception.setMessage(TECHNICAL_ERROR_MSG);
		exception.setDetail(TECHNICAL_ERROR_MSG);
		org.eox.medsupp.schema.exception.Exception exceptions[] = new org.eox.medsupp.schema.exception.Exception[1];
		exceptions[0] = exception;
		restError.setExceptions(Arrays.asList(exceptions));
		return restError;
	}
}
