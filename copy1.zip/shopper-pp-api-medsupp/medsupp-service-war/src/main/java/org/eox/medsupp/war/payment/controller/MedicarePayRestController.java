/**
 * MedicarePayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/06/2018  1.0      Cognizant       CSR - Chase Integration
 */
package org.eox.medsupp.war.payment.controller;


import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.eox.medsupp.jar.payment.service.MedicarePayService;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.request.CancelPaymentRequest;
import org.eox.medsupp.schema.request.GetAccountSummaryRequest;
import org.eox.medsupp.schema.request.GetAutoPaymentRequest;
import org.eox.medsupp.schema.request.GetLinkedAccountRequest;
import org.eox.medsupp.schema.request.GetMedicareFaqRequest;
import org.eox.medsupp.schema.request.GetPaymentMethodRequest;
import org.eox.medsupp.schema.request.GetViewBillRequest;
import org.eox.medsupp.schema.request.SubmitPaymentRequest;
import org.eox.medsupp.schema.request.UpdateLinkedAccountRequest;
import org.eox.medsupp.schema.request.UpdatePaymentMethodRequest;
import org.eox.medsupp.schema.request.ViewPaymentHistoryRequest;
import org.eox.medsupp.schema.response.CancelPaymentResponse;
import org.eox.medsupp.schema.response.GetAccountSummaryResponse;
import org.eox.medsupp.schema.response.GetAutoPaymentResponse;
import org.eox.medsupp.schema.response.GetLinkedAccountResponse;
import org.eox.medsupp.schema.response.GetMedicareFaqResponse;
import org.eox.medsupp.schema.response.GetPaymentMethodResponse;
import org.eox.medsupp.schema.response.GetViewBillResponse;
import org.eox.medsupp.schema.response.SubmitPaymentResponse;
import org.eox.medsupp.schema.response.UpdateLinkedAccountResponse;
import org.eox.medsupp.schema.response.UpdatePaymentMethodResponse;
import org.eox.medsupp.schema.response.ViewPaymentHistoryResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MedicarePayRestController implements MedicarePayConstants
{

	@Autowired
	private MedicarePayService medicarePayService;

	/**
	 * Add/Edit/Deletes payment method of the medicare member
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/updatePaymentMethod", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	UpdatePaymentMethodResponse updatePaymentMethod(@RequestBody UpdatePaymentMethodRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("updatePaymentMethod");
		}
		UpdatePaymentMethodResponse response = medicarePayService.updatePaymentMethod(request);
		return response;
	}

	/**
	 * Returns the saved payment methods of the medicare member
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getPaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetPaymentMethodResponse getPaymentMethods(@RequestBody GetPaymentMethodRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getPaymentMethods");
		}
		GetPaymentMethodResponse response = medicarePayService.getPaymentMethods(request);
		return response;
	}

	/**
	 * Get the bill detals of the medicare member
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getAccountSummary", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetAccountSummaryResponse getAccountSummary(@RequestBody GetAccountSummaryRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getAccountSummary");
			//PP-14143 - Start
			String csrId = MedicarePayUtils.getCsrIdValueFromRequest(httpRequest);
			request.setCsrId(csrId);
			request.setCsrRoles(MedicarePayUtils.getCsrRoleValueFromRequest(httpRequest));
			request.setLob(MedicarePayUtils.getLOBValueFromRequest(httpRequest));
			//PP-14143 - End
		}
		GetAccountSummaryResponse response = medicarePayService.getAccountSummary(request);
		return response;
	}

	/**
	 * Cancels the in-progress payment
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/cancelPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	CancelPaymentResponse cancelPayment(@RequestBody CancelPaymentRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		CancelPaymentResponse response = new CancelPaymentResponse();
		String getPaymentConfirmationNo = null;
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("cancelPayment");
			getPaymentConfirmationNo = request.getPaymentConfirmationNo();
			/*PP-14144 - start */
			String csrId = MedicarePayUtils.getCsrIdValueFromRequest(httpRequest);
			String lob = MedicarePayUtils.getLOBValueFromRequest(httpRequest);
			request.setCsrId(csrId);
			request.setLob(lob);
			/*PP-14144 - end */
		}
		if(getPaymentConfirmationNo == null || getPaymentConfirmationNo.isEmpty()) {
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		if(getPaymentConfirmationNo != null && StringUtils.isNumeric(getPaymentConfirmationNo)) {
			// getPaymentConfirmationNo is confirmation number - ACI payment
			response = medicarePayService.cancelPayment(request);
		}else {
			// getPaymentConfirmationNo is anthem_orderid - chase payment
			/*PP-14144 - start */
			response = medicarePayService.payModCancelPayment(request);
			/*PP-14144 - end */
		}
		return response;
	}

	/**
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/submitPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	SubmitPaymentResponse submitPayment(@RequestBody SubmitPaymentRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		SubmitPaymentResponse response = new SubmitPaymentResponse();
		String csrId = null;
		String lob = null;
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("submitPayment");
			/*PP-14146 - start */
			csrId = MedicarePayUtils.getCsrIdValueFromRequest(httpRequest);
			lob = MedicarePayUtils.getLOBValueFromRequest(httpRequest);
			request.setCsrId(csrId);
			request.setLob(lob);
			/*PP-14146 - end */
		}
		if(csrId != null && !csrId.isEmpty()) {
			/*PP-14146 - start */
			response = medicarePayService.payModSubmitPayment(request);
			/*PP-14146 - end */
		} else {
			response = medicarePayService.submitPayment(request);
		}
		
		return response;
	}

	/**
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getLinkedAccount", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetLinkedAccountResponse getLinkedAccount(@RequestBody GetLinkedAccountRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getLinkedAccount");
		}
		return medicarePayService.getLinkedAccount(request);
	}

	/**
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/updateLinkedAccount", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	UpdateLinkedAccountResponse updateLinkedAccount(@RequestBody UpdateLinkedAccountRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("updateLinkedAccount");
		}
		UpdateLinkedAccountResponse response = medicarePayService.updateLinkedAccount(request);
		return response;
	}

	/**
	 * Get FAQ details for the logged in member
	 * 
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getFaq", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetMedicareFaqResponse getFaq(@RequestBody GetMedicareFaqRequest request, HttpServletRequest httpRequest) throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getFaq");
		}
		GetMedicareFaqResponse response = medicarePayService.getMedicareFaq(request);
		return response;
	}

	/**
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getViewBill", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetViewBillResponse getViewBill(@RequestBody GetViewBillRequest request, HttpServletRequest httpRequest) throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getViewBill");
		}
		return medicarePayService.getViewBill(request);
	}

	/**
	 * Get auto payment details for the logged in member
	 * 
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@RequestMapping(value = "/v1/getAutoPayPdfDetails", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	GetAutoPaymentResponse getAutoPayPdfDetails(@RequestBody GetAutoPaymentRequest request, HttpServletRequest httpRequest)
			throws MedicarePayException
	{
		if (null != request)
		{
			request.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			request.setEndPointName("getAutoPayPdfDetails");
		}
		GetAutoPaymentResponse response = medicarePayService.getAutoPayPdfDetails(request);
		return response;
	}
	@RequestMapping(value = "/v1/getPaymentHistory", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	ViewPaymentHistoryResponse getHistory(@RequestBody ViewPaymentHistoryRequest viewPaymentHistoryRequest, HttpServletRequest httpRequest) throws MedicarePayException
	{
		if(null != viewPaymentHistoryRequest) {
			viewPaymentHistoryRequest.setServiceEnv(MedicarePayUtils.getMetaSenderAppValue(httpRequest));
			viewPaymentHistoryRequest.setEndPointName("getPaymentHistory");
		}
		return  medicarePayService.getPaymentHistory(viewPaymentHistoryRequest);
	}
	
}
