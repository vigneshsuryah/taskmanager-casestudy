package org.eox.medsupp.war.payment.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Properties;

import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.request.LoggingChangeRequest;
import org.eox.medsupp.schema.response.LoggingChangeResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;


@Controller
public class UtilityController implements MedicarePayConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UtilityController.class);
		
	@Autowired
	private MedicarePayUtils medicarePayUtils;
	
	@Value("${medicarepay.setting.refresh.endpoint}")
	String refreshEndpoint;
	
	@RequestMapping(value = "changeMessageBundlePropsValue", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = {
			APPLICATION_TYPE_JSON}, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	LoggingChangeResponse changeMessageBundlePropsValue(@RequestBody LoggingChangeRequest request) throws MedicarePayException
	{
		LoggingChangeResponse response= new LoggingChangeResponse();
		response.setChangeStatus("Value Not Changed. Error Occured.");
		try
		{
			String key = request.getPropsKey();
			String value = request.getPropsValue();
			String fileName = request.getPropFileName();
			LOGGER.info("Inside changeMessageBundlePropsValue() of MEDSUPP");
			if(null != fileName && !fileName.isEmpty()){
				String path = "";
				switch(fileName) {
					case "medsupp-application" : {
						path = "/wsapps/eox/deployment/config/memberpay/service/medsupp/medsupp-application.properties";
						break;
					}
					case "brand_email_matrix" : {
						path = "/wsapps/eox/deployment/config/memberpay/service/medsupp/brand_email_matrix.properties";
						break;
					}
					case "brand_values" : {
						path = "/wsapps/eox/deployment/config/memberpay/service/medsupp/brand_values.properties";
						break;
					}
					case "division_code" : {
						path = "/wsapps/eox/deployment/config/memberpay/service/medsupp/division_code.properties";
						break;
					}
					default:
						break;
				}
				Properties props = new Properties();

				FileInputStream configStream = new FileInputStream(path);
				props.load(configStream);
				configStream.close();

				String existingValue = props.getProperty(key, "NOTFOUND");
				if( existingValue != null && !existingValue.isEmpty() && !existingValue.equals("NOTFOUND"))
				{
					props.setProperty(key, value);
					FileOutputStream output = new FileOutputStream(path);
					props.store(output, "Archaius - Dynamic Loading Property file.");
					output.close();
					response.setChangeStatus("Value Changed");
					medicarePayUtils.updateProperties();
					
					HttpEntity<Object> requestEntity = new HttpEntity<Object>(request, getHttpHeaders());
					getRestTemplate().postForObject(refreshEndpoint, requestEntity, Object.class);
				}else
				{
					response.setChangeStatus("New Key - Not Added");
				}
			}else{
				    response.setChangeStatus("Invalid File to update");
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in changeMessageBundlePropsValue() of MEDSUPP : " + e);
		}
		return response;
	}
	
	private RestTemplate getRestTemplate()
	{
		LOGGER.info("Above to get RestTemplate");
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate;
	}

	/**
	 * Returns the Http header params
	 * @param requestContext
	 * @return
	 */
	private MultiValueMap<String, String> getHttpHeaders()
	{
		LOGGER.info("Above to get HttpHeaders");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));

		LOGGER.debug(headers.toString());
		LOGGER.info("Got HttpHeaders");
		return headers;
	}
}
