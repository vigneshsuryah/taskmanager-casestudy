package org.eox.medsupp.war;

import static com.jayway.restassured.RestAssured.get;
import static org.hamcrest.Matchers.equalTo;

import org.junit.Test;

/**
 * 
 * @author AD44346
 * 
 */
public class PPAppIT {
	@Test
	public void firstEchoTest() {
		get("/medSupp/echo/hello").then().assertThat()
				.body("message", equalTo("hello"));
	}
}
