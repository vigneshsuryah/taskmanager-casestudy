/**
 * ExpMMConverter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.config;


import org.dozer.DozerConverter;
import org.springframework.util.StringUtils;


public class ExpMMConverter extends DozerConverter<String, String>
{

	public ExpMMConverter()
	{
		super(String.class, String.class);
	}

	@Override
	public String convertFrom(String source, String destination)
	{
		if (source != null)
		{
			if (source.length() == 7)
			{
				return convertMMYYYYtoMM(source);
			}
			else
			{
				return convertMMtoExp(source, destination);
			}
		}
		return source;
	}

	private String convertMMYYYYtoMM(String source)
	{
		if (source != null && !StringUtils.isEmpty(source))
		{
			return source.split("/")[0];
		}
		return source;
	}

	private String convertMMtoExp(String source, String destination)
	{
		if (destination == null)
		{
			return source;
		}
		return new StringBuilder().append(source).append(destination).toString();
	}

	@Override
	public String convertTo(String source, String destination)
	{
		return convertFrom(source, destination);
	}

}
