/**
 * EmailUtil.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.io.IOException;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.eox.medsupp.datasvc.payment.dao.MedicarePayDao;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.BrandEmailMatrix;
import org.eox.medsupp.schema.model.MedicareEmailLogging;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;


@Component
public class EmailUtil implements MedicarePayConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtil.class);

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private VelocityEngine velocityEngine;

	@Autowired
	private MedicarePayDao medicarePayDaoImpl;

	private String emailContent;

	public void sendMail(Mail mail, Map<String, Object> model) throws MedicarePayException
	{
		LOGGER.info("Start sendMail() of EmailUtil");
		try
		{
			sendConfirmationEmail(mail, model);
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in sendMail() of EmailUtil " + e);
			throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
					+ "That member needs to update their email address before you can link accounts.");
		}
		try
		{
			logEmail(mail);
			LOGGER.info("End sendMail() of EmailUtil");
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in logging the mail " + e.getMessage());
		}
	}

	private void logEmail(Mail mail) throws MedicarePayException
	{
		LOGGER.info("Start logEmail() of EmailUtil");
		MedicareEmailLogging memberpayEmailLogging = new MedicareEmailLogging();
		memberpayEmailLogging.setFrom(mail.getMailFrom());
		memberpayEmailLogging.setTo(mail.getMailTo());
		memberpayEmailLogging.setHcid(mail.getToHcid());
		memberpayEmailLogging.setSubject(mail.getMailSubject());
		memberpayEmailLogging.setTemplateId(mail.getTemplateId());
		memberpayEmailLogging.setSentDate(new Date());
		memberpayEmailLogging.setDynamicContent(emailContent);
		memberpayEmailLogging.setMailType(mail.getMailType());
		memberpayEmailLogging.setCreatedBy(mail.getCreatedBy());
		memberpayEmailLogging.setCreatedDate(new Date());
		medicarePayDaoImpl.saveEmailLog(memberpayEmailLogging);
		LOGGER.info("End logEmail() of EmailUtil");
	}

	private void sendConfirmationEmail(final Mail mail, final Map<String, Object> model)
	{
		LOGGER.info("Start sendConfirmationEmail() of EmailUtil");
		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator()
		{
			@Override
			public void prepare(MimeMessage mimeMessage) throws MessagingException, IOException, URISyntaxException, VelocityException
			{
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
				message.setTo(mail.getMailTo());
				message.setFrom(new InternetAddress(mail.getMailFrom()));
				message.setSubject(mail.getMailSubject());
				message.setSentDate(new Date());
				String text = "";

				try
				{
					VelocityContext context = new VelocityContext(model);
					StringWriter writer = new StringWriter();
					velocityEngine.mergeTemplate(mail.getTemplateLocation(), "UTF-8", context, writer);
					text = writer.toString();
				} catch (VelocityException ve)
				{
					throw ve;
				} catch (Exception e)
				{
					throw new VelocityException(e.toString());
				}

				if (text != null && !text.isEmpty())
				{
					text = text.replace("<%@ page language='java' contentType='text/html; charset=ISO-8859-1' pageEncoding='ISO-8859-1'%>",
							"");
				}
				BrandEmailMatrix brandEmailMatrix = (BrandEmailMatrix) model.get("brandEmailMatrix");
				message.setText(text, true);
				if (ADD_LINK_ACC_TEMP_ID.equalsIgnoreCase(mail.getTemplateId()))
				{
					message.addInline(ALLOW_BUTTON_LOGO, new ClassPathResource(EMAIL_IMAGES + ALLOW_BUTTON_LOGO + PNG));
					message.addInline(DENY_BUTTON_LOGO, new ClassPathResource(EMAIL_IMAGES + DENY_BUTTON_LOGO + PNG));
				}
				message.addInline("headerLogo", new ClassPathResource(EMAIL_IMAGES + brandEmailMatrix.getImageName() + PNG));
				emailContent = text;
				LOGGER.info("End sendConfirmationEmail() of EmailUtil");
			}

		};
		try
		{
			this.mailSender.send(mimeMessagePreparator);
		} catch (Exception ex)
		{
			LOGGER.error("Exception in sending the mail " + ex);
			throw ex;
		}
	}
}
