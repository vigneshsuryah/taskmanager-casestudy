/**
 * 
 */
package org.eox.medsupp.jar.payment.util;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.List;

import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;


@Component("restApiInterceptor")
public class RestApiInterceptor implements ClientHttpRequestInterceptor, MedicarePayConstants
{

	private final static Logger logger = LoggerFactory.getLogger(RestApiInterceptor.class);

	private ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private MedicarePayGateway medicarePayGateway;

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException
	{
		TPTServicesLog logData = new TPTServicesLog();

		traceRequest(request, body, logData);
		ClientHttpResponse response = execution.execute(request, body);
		traceResponse(response, logData);
		try
		{
			medicarePayGateway.saveTPTServiceLog(logData);
		} catch (Exception e)
		{
			logger.error("Exception in RestApiInterceptor intercept TPT Logging : " + e);
		}
		return response;
	}

	private void traceRequest(HttpRequest request, byte[] body, TPTServicesLog logData) throws IOException
	{
		logger.info("===========================request begin================================================");
		logger.info("URI : " + request.getURI());
		logger.info("Method : " + request.getMethod());
		logger.info("Header : " + mapper.writeValueAsString(request.getHeaders()));
		logger.info("Request Body : " + new String(body, "UTF-8"));
		logger.info("==========================request end================================================");
		List<String> outgoingRequestId = request.getHeaders().get(OUT_GOING_ID);
		request.getHeaders().remove(OUT_GOING_ID);
		List<String> outOperation = request.getHeaders().get(OUT_OPERATION);
		request.getHeaders().remove(OUT_OPERATION);
		List<String> senderApp = request.getHeaders().get(META_SENDERAPP);
		
		if(null != outOperation && outOperation.size() > 0 && !outOperation.contains(SOA_PAY_SUCCESS_MAIL_SERVICE)) {
			request.getHeaders().remove(META_SENDERAPP);
		}

		logData.setOperationName(null != outOperation ? outOperation.get(0) : "");
		logData.setHcid(null != outgoingRequestId ? outgoingRequestId.get(0) : "");
		logData.setSbrUid("");
		logData.setRequestXml("Headers: " + request.getHeaders().toString() + " Request: " + new String(body, "UTF-8"));
		logData.setRequestTs(Calendar.getInstance().getTime());
		logData.setRequestingSystem(null != senderApp ? senderApp.get(0) : "");
	}

	private void traceResponse(ClientHttpResponse response, TPTServicesLog logData) throws IOException
	{
		logData.setResponseTs(Calendar.getInstance().getTime());

		StringBuilder inputStringBuilder = new StringBuilder();
		try
		{

			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), "UTF-8"));
			String line = bufferedReader.readLine();
			while (line != null)
			{
				inputStringBuilder.append(line);
				inputStringBuilder.append('\n');
				line = bufferedReader.readLine();
			}
			if (response.getStatusCode() == HttpStatus.OK)
			{
				logData.setResponseXml(inputStringBuilder.toString());
			}
			else
			{
				logData.setResponseXml("Code:" + response.getStatusCode() + ":" + inputStringBuilder.toString());

			}
		} catch (Exception e)
		{
			logger.error("Exception in RestApiInterceptor traceResponse : " + e);
			logData.setResponseXml("Code:" + response.getStatusCode() + ":" + response.getStatusText());
		}

		logger.info("============================response begin==========================================");
		logger.info("status code: " + response.getStatusCode());
		logger.info("status text: " + response.getStatusText());
		logger.info("Response Body : " + inputStringBuilder.toString());
		logger.info("=======================response end=================================================");
	}

}
