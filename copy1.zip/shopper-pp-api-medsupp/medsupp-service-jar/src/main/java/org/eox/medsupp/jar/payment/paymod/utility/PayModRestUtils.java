/**
 * PayModRestUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.paymod.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.paymod.request.GetTokenRequest;
import org.eox.medsupp.paymod.request.PayModCancelPaymentRequest;
import org.eox.medsupp.paymod.request.PayModSubmitPaymentRequest;
import org.eox.medsupp.paymod.request.SearchPayModPaymentRequest;
import org.eox.medsupp.paymod.response.Exceptions;
import org.eox.medsupp.paymod.response.GetTokenResponse;
import org.eox.medsupp.paymod.response.PayModCancelPaymentResponse;
import org.eox.medsupp.paymod.response.PayModSubmitPaymentResponse;
import org.eox.medsupp.paymod.response.SearchPayModPaymentResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.eox.medsupp.paymod.request.MamDetailsBO;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.eox.medsupp.paymod.response.PaymentModExceptionResponse;
import java.io.IOException;

@Component("payModRestUtils")
@RefreshScope
public class PayModRestUtils implements MedicarePayConstants {
	private final static Logger logger = LoggerFactory.getLogger(PayModRestUtils.class);
	
	@Value("${medicarepay.setting.paymod.readtimeout}")
	private int readTimeout;

	@Value("${medicarepay.setting.paymod.connectiontimeout}")
	private int connectionTimeout;
	
	@Value("${medicarepay.setting.paymod.endpoint}")
	String payModRestEndpoint;
	
	@Value("${medicarepay.setting.paymod.request.application}")
	String payModReqSys;
	
	@Value("${medicarepay.setting.paymod.user.name}")
	String payModUserName;
	
	@Value("${medicarepay.setting.paymod.pass.word}")
	String payModPwd;
	
	@Autowired
	private PayModInterceptor payModInterceptor;
	
	private ClientHttpRequestFactory clientHttpRequestFactory() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setReadTimeout(readTimeout);
		factory.setConnectTimeout(connectionTimeout);  
		ClientHttpRequestFactory requestFactory = new BufferingClientHttpRequestFactory(factory);
		return requestFactory;
	}
	
	public RestTemplate getRestTemplate() {
		logger.info("Above to get RestTemplate");
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors= new ArrayList<ClientHttpRequestInterceptor>(1);
		clientHttpRequestInterceptors.add(payModInterceptor);
		restTemplate.setInterceptors(clientHttpRequestInterceptors);
		logger.info("Got the RestTemplate");
		return restTemplate;
	}

	public GetTokenResponse getTokenForCCAuthorization(GetTokenRequest request) throws MedicarePayException{
		HttpEntity<GetTokenRequest> requestEntity = new HttpEntity<GetTokenRequest>(request,getHttpHeaders(request.getAccountNumber(),"getTokenPayMod"));
		GetTokenResponse response = null;
		try {	
			logger.info("Above to POST getTokenForCCAuthorization Request");
			response = getRestTemplate().postForObject(payModRestEndpoint + "v1/getToken",requestEntity, GetTokenResponse.class);
		} catch(HttpClientErrorException e){	
			logger.info("PAY MOD HttpClientErrorException for getTokenForCCAuthorization::"+e.getCause()); 
			response = new GetTokenResponse();
			Exceptions exceptions= convertPayModException(e.getResponseBodyAsString());
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpClientErrorException for getTokenForCCAuthorization Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch (HttpServerErrorException e){
			response = new GetTokenResponse();
			Exceptions exceptions= convertPayModException(e.getResponseBodyAsString());
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpServerErrorException for getTokenForCCAuthorization Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch(Exception e){
			logger.error("Error in calling getTokenForCCAuthorization:"+e);
			throw new MedicarePayException("Error in calling getTokenForCCAuthorization:"+e);
		}
		return response;
	}	

	public SearchPayModPaymentResponse searchPayModPayment(SearchPayModPaymentRequest request) throws MedicarePayException{
		HttpEntity<SearchPayModPaymentRequest> requestEntity = new HttpEntity<SearchPayModPaymentRequest>(request,getHttpHeaders(request.getHcid(),"searchPayModPayment"));
		SearchPayModPaymentResponse response = null;
		try {	
			logger.info("Above to POST searchPayModPayment Request");
			response = getRestTemplate().postForObject(payModRestEndpoint + "v1/searchPayment",requestEntity, SearchPayModPaymentResponse.class);
		} catch(HttpClientErrorException e){	
			logger.info("PAY MOD HttpClientErrorException for searchPayModPayment::"+e.getCause()); 
			HttpClientErrorException httpError = ((HttpClientErrorException) e);
			response = new SearchPayModPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(httpError.getStatusCode()!=null?String.valueOf(httpError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpClientErrorException for searchPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch (HttpServerErrorException e){
			HttpServerErrorException serverError = (HttpServerErrorException)e;
			response = new SearchPayModPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(serverError.getStatusCode()!=null?String.valueOf(serverError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpServerErrorException for searchPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch(Exception e){
			logger.error("Error in calling searchPayModPayment:"+e);
			throw new MedicarePayException("Error in calling searchPayModPayment:"+e);
		}
		return response;
	}
	/*PP-13883 ends */
	
	/*PP-14146 - start */
	public PayModSubmitPaymentResponse submitPayModPayment(PayModSubmitPaymentRequest request) throws MedicarePayException{
		HttpEntity<PayModSubmitPaymentRequest> requestEntity = new HttpEntity<PayModSubmitPaymentRequest>(request,getHttpHeaders(request.getMemberBillingId(),"submitPayModPayment"));
		PayModSubmitPaymentResponse response = null;
		try {	
			logger.info("Above to POST submitPayModPayment Request");
			response = getRestTemplate().postForObject(payModRestEndpoint + "v1/submitPayment",requestEntity, PayModSubmitPaymentResponse.class);
		} catch(HttpClientErrorException e){	
			logger.info("PAY MOD HttpClientErrorException for submitPayModPayment::"+e.getCause()); 
			HttpClientErrorException httpError = ((HttpClientErrorException) e);
			response = new PayModSubmitPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(httpError.getStatusCode()!=null?String.valueOf(httpError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpClientErrorException for submitPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch (HttpServerErrorException e){
			HttpServerErrorException serverError = (HttpServerErrorException)e;
			response = new PayModSubmitPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(serverError.getStatusCode()!=null?String.valueOf(serverError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpServerErrorException for submitPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch(Exception e){
			logger.error("Error in calling submitPayModPayment:"+e);
			throw new MedicarePayException("Error in calling submitPayModPayment:"+e);
		}
		return response;
	}
	
	public MamDetailsBO getTransactionDivision(MamDetailsBO request) throws MedicarePayException{
		HttpEntity<MamDetailsBO> requestEntity = new HttpEntity<MamDetailsBO>(request,getHttpHeaders(request.getMarketSegment(),"getTransactionDivisionPayMod"));
		MamDetailsBO response = null;
		try {	
			logger.info("Above to POST getTransactionDivision Request");
			response = getRestTemplate().postForObject(payModRestEndpoint + "v1/getTransactionDivision",requestEntity, MamDetailsBO.class);
		} catch(HttpClientErrorException e){	
			logger.info("PAY MOD HttpClientErrorException for getTransactionDivision::"+e.getCause()); 
			HttpClientErrorException httpError = ((HttpClientErrorException) e);
			response = new MamDetailsBO();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(httpError.getStatusCode()!=null?String.valueOf(httpError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpClientErrorException for getTransactionDivision Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch (HttpServerErrorException e){
			HttpServerErrorException serverError = (HttpServerErrorException)e;
			response = new MamDetailsBO();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(serverError.getStatusCode()!=null?String.valueOf(serverError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpServerErrorException for getTransactionDivision Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch(Exception e){
			logger.error("Error in calling getTransactionDivision:"+e);
			throw new MedicarePayException("Error in calling getTransactionDivision:"+e);
		}
		return response;
	}
	/*PP-14146 - end */
	
	/*PP-14144 - start */
	public PayModCancelPaymentResponse cancelPayModPayment(PayModCancelPaymentRequest request) throws MedicarePayException{
		HttpEntity<PayModCancelPaymentRequest> requestEntity = new HttpEntity<PayModCancelPaymentRequest>(request,getHttpHeaders(request.getOrderId(),"cancelPayModPayment"));
		PayModCancelPaymentResponse response = null;
		try {	
			logger.info("Above to POST cancelPayModPayment Request");
			response = getRestTemplate().postForObject(payModRestEndpoint + "v1/cancelPayment",requestEntity, PayModCancelPaymentResponse.class);
		} catch(HttpClientErrorException e){	
			logger.info("PAY MOD HttpClientErrorException for cancelPayModPayment::"+e.getCause()); 
			HttpClientErrorException httpError = ((HttpClientErrorException) e);
			response = new PayModCancelPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(httpError.getStatusCode()!=null?String.valueOf(httpError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpClientErrorException for cancelPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch (HttpServerErrorException e){
			HttpServerErrorException serverError = (HttpServerErrorException)e;
			response = new PayModCancelPaymentResponse();
			Exceptions exceptions= new Exceptions();
			exceptions.setCode(serverError.getStatusCode()!=null?String.valueOf(serverError.getStatusCode().value()):"Undefined");
			response.setExceptions(exceptions);
			logger.error("PAY MOD HttpServerErrorException for cancelPayModPayment Status Code :: " + response.getExceptions().getCode());
			return response;
		}catch(Exception e){
			logger.error("Error in calling cancelPayModPayment:"+e);
			throw new MedicarePayException("Error in calling cancelPayModPayment:"+e);
		}
		return response;
	}
	/*PP-14144 - end */

	private HttpHeaders getHttpHeaders(String outGoingId, String operationName){
		logger.info("Above to get HttpHeaders");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add(PAY_MOD_REQUEST_APP, payModReqSys);
		headers.add(PAY_MOD_USER_NAME, payModUserName);
		headers.add(PAY_MOD_AUTH_KEY, payModPwd);
		headers.add(CASHAPI_OUT_GOING_ID, outGoingId);
		headers.add(WS_CONTEXT_OPERATION_NAME, operationName);
		logger.info("Got HttpHeaders");
		return headers;
	}	
	
	private Exceptions convertPayModException(String bodyString) {
		org.codehaus.jackson.map.ObjectMapper mapper = new org.codehaus.jackson.map.ObjectMapper();
		PaymentModExceptionResponse exceptionObject = new PaymentModExceptionResponse();
		Exceptions exception = new Exceptions();
		try {
			exceptionObject = mapper.readValue(bodyString, PaymentModExceptionResponse.class);
			exception = exceptionObject.getExceptions().get(0);
		} catch (JsonParseException e) {
			logger.debug("JsonParseException in convertSOAExceptionsToGbd");
		} catch (JsonMappingException e) {
			logger.debug("JsonMappingException in convertSOAExceptionsToGbd");
		} catch (IOException e) {
			logger.debug("IOException in convertSOAExceptionsToGbd");
		}
		return exception;
	}
	
}
