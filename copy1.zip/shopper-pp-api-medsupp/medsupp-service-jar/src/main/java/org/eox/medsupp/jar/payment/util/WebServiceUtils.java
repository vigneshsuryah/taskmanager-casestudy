/**
 * WebServiceUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Calendar;

import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class WebServiceUtils implements MedicarePayConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(WebServiceUtils.class);

	@Autowired
	private MedicarePayGateway medicarePayGateway;

	public void addTptTransactionToLog(TPTServicesLog request) throws MedicarePayException
	{
		try
		{
			medicarePayGateway.saveTPTServiceLog(request);
		} catch (Exception e)
		{
			LOGGER.error("Exception in WebServiceUtils addTptTransactionToLog : " + e);
		}
	}

	public TPTServicesLog prepareTptLogRequest(String operationName, String hcid, String requestXML) throws MedicarePayException
	{
		TPTServicesLog tPTServicesLog = new TPTServicesLog();
		try
		{
			Calendar cal = Calendar.getInstance();
			tPTServicesLog.setHcid(hcid);
			tPTServicesLog.setSbrUid("");
			tPTServicesLog.setOperationName(operationName);
			tPTServicesLog.setRequestTs(cal.getTime());
			tPTServicesLog.setRequestXml(requestXML);
			tPTServicesLog.setCreateId(hcid);
			//tPTServicesLog.setRequestingSystem(MedicarePayUtils.getRequestingSystem());
			tPTServicesLog.setRequestingSystem("MEDSUPP");
			tPTServicesLog.setUpdateId(hcid);
		} catch (Exception e)
		{
			LOGGER.error("Exception in WebServiceUtils prepareTptLogRequest : " + e);
		}
		return tPTServicesLog;
	}

	public String getTransactionId()
	{
		try
		{
			/*
			 * SecureRandom number = SecureRandom.getInstance("SHA1PRNG"); StringBuffer randomValue= new StringBuffer(); for (int i = 0; i <
			 * SECURE_RANDOM_LENGTH; i++) { randomValue.append(number.nextInt(10)); } return randomValue.toString();
			 */
			SecureRandom random = new SecureRandom();
			return new BigInteger(130, random).toString(32);
		} catch (Exception e)
		{
			return "213987282a";
		}
	}
}
