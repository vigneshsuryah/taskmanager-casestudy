/**
 * MedicarePayService.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/06/2018  1.0      Cognizant       CSR - Chase Integration
 */
package org.eox.medsupp.jar.payment.service;


import org.eox.medsupp.datasvc.payment.entity.RSTransLog;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.request.CancelPaymentRequest;
import org.eox.medsupp.schema.request.GetAccountSummaryRequest;
import org.eox.medsupp.schema.request.GetAutoPaymentRequest;
import org.eox.medsupp.schema.request.GetLinkedAccountRequest;
import org.eox.medsupp.schema.request.GetMedicareFaqRequest;
import org.eox.medsupp.schema.request.GetPaymentMethodRequest;
import org.eox.medsupp.schema.request.GetViewBillRequest;
import org.eox.medsupp.schema.request.SubmitPaymentRequest;
import org.eox.medsupp.schema.request.UpdateLinkedAccountRequest;
import org.eox.medsupp.schema.request.UpdatePaymentMethodRequest;
import org.eox.medsupp.schema.request.ViewPaymentHistoryRequest;
import org.eox.medsupp.schema.response.CancelPaymentResponse;
import org.eox.medsupp.schema.response.GetAccountSummaryResponse;
import org.eox.medsupp.schema.response.GetAutoPaymentResponse;
import org.eox.medsupp.schema.response.GetEligibilityResponse;
import org.eox.medsupp.schema.response.GetLinkedAccountResponse;
import org.eox.medsupp.schema.response.GetMedicareFaqResponse;
import org.eox.medsupp.schema.response.GetPaymentMethodResponse;
import org.eox.medsupp.schema.response.GetViewBillResponse;
import org.eox.medsupp.schema.response.SubmitPaymentResponse;
import org.eox.medsupp.schema.response.UpdateLinkedAccountResponse;
import org.eox.medsupp.schema.response.UpdatePaymentMethodResponse;
import org.eox.medsupp.schema.response.ViewPaymentHistoryResponse;
import org.springframework.scheduling.annotation.Async;


public interface MedicarePayService
{

	GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest request) throws MedicarePayException;

	UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest request) throws MedicarePayException;

	GetAccountSummaryResponse getAccountSummary(GetAccountSummaryRequest request) throws MedicarePayException;

	CancelPaymentResponse cancelPayment(CancelPaymentRequest request) throws MedicarePayException;

	SubmitPaymentResponse submitPayment(SubmitPaymentRequest request) throws MedicarePayException;

	@Async
	public void saveRSLog(RSTransLog request) throws MedicarePayException;

	GetLinkedAccountResponse getLinkedAccount(GetLinkedAccountRequest request) throws MedicarePayException;

	UpdateLinkedAccountResponse updateLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException;

	GetMedicareFaqResponse getMedicareFaq(GetMedicareFaqRequest request) throws MedicarePayException;

	public GetViewBillResponse getViewBill(GetViewBillRequest request) throws MedicarePayException;

	public GetAutoPaymentResponse getAutoPayPdfDetails(GetAutoPaymentRequest request) throws MedicarePayException;
	
	ViewPaymentHistoryResponse getPaymentHistory(ViewPaymentHistoryRequest viewPaymentHistoryRequest)  throws MedicarePayException ;
	
	/*PP-14144 - start*/
	SubmitPaymentResponse payModSubmitPayment(SubmitPaymentRequest request) throws MedicarePayException;
	/*PP-14144 - end*/
	
	/*PP-14144 - start*/
	CancelPaymentResponse payModCancelPayment(CancelPaymentRequest request) throws MedicarePayException;
	/*PP-14144 - end*/

}
