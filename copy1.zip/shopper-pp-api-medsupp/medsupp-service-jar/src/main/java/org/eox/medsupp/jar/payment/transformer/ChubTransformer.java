/**
 * ChubTransformer.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.transformer;


import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.dozer.Mapper;
import org.eox.medsupp.chub.service.CommComponentReq;
import org.eox.medsupp.chub.service.MemberType;
import org.eox.medsupp.chub.service.MembershipServiceGetMbrContactMethodRequestType;
import org.eox.medsupp.chub.service.MembershipServiceGetMbrContactMethodResponseType;
import org.eox.medsupp.chub.service.MembershipServiceUpdateMbrContactMethodRequestType;
import org.eox.medsupp.chub.service.MembershipServiceUpdateMbrContactMethodResponseType;
import org.eox.medsupp.schema.request.GetMbrContactMethodServiceRequest;
import org.eox.medsupp.schema.request.UpdatePaperBillServiceRequest;
import org.eox.medsupp.schema.response.GetMbrContactMethodServiceResponse;
import org.eox.medsupp.schema.response.UpdatePaperBillServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;


@Component
public class ChubTransformer
{
	@Autowired
	private Mapper dozerMapper;

	@Transformer
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public JAXBElement<?> createUpdateMbrContactMethodRequest(UpdatePaperBillServiceRequest serviceRequest)
	{
		MembershipServiceUpdateMbrContactMethodRequestType request = new MembershipServiceUpdateMbrContactMethodRequestType();
		MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest updateMbrContactMethodRequest = new MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest();
		MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest.MbrInfo mbrInfo = new MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest.MbrInfo();
		mbrInfo.setGrpId(serviceRequest.getGroupId());
		MemberType member = new MemberType();
		member.setSubscriberId(serviceRequest.getSubscriberId());
		member.setMbrSeqNum(serviceRequest.getMemberSequenceNumber());
		mbrInfo.setMember(member);
		mbrInfo.setSrcSysId(serviceRequest.getSourceSystemId());
		mbrInfo.setSuppressEmailInd(serviceRequest.getSuppressEmailInd());
		MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest.MbrInfo.ChgRqst chgRqst = new MembershipServiceUpdateMbrContactMethodRequestType.UpdateMbrContactMethodRequest.MbrInfo.ChgRqst();
		CommComponentReq commComponent = new CommComponentReq();
		CommComponentReq.Preference preference = new CommComponentReq.Preference();
		preference.setPrfrncTyp(serviceRequest.getPreferenceType());
		preference.setPrfrncOpt(serviceRequest.getPreferenceOpt());
		preference.setEfctvDt(serviceRequest.getPreferenceEffectiveDate());
		commComponent.getPreference().add(preference);
		CommComponentReq.Email email = new CommComponentReq.Email();
		email.setEmTypCd(serviceRequest.getEmailTypeCode());
		email.setEmailAddr(serviceRequest.getEmailAddress());
		email.setEfctvDt(serviceRequest.getEmailEffectiveDate());
		commComponent.setEmail(email);
		chgRqst.setCommComponent(commComponent);
		mbrInfo.setSrcChnl(serviceRequest.getSourceChannel());
		mbrInfo.getChgRqst().add(chgRqst);
		updateMbrContactMethodRequest.setMbrInfo(mbrInfo);
		request.setUpdateMbrContactMethodRequest(updateMbrContactMethodRequest);
		return new JAXBElement(new QName("http://wellpoint.com/service/membership", "MembershipService_Update_MbrContactMethod_Request"),
				request.getClass(), null, request);
	}

	@Transformer
	public UpdatePaperBillServiceResponse processUpdateMbrContactMethodResponse(JAXBElement<?> jaxbElement)
	{
		MembershipServiceUpdateMbrContactMethodResponseType response = (MembershipServiceUpdateMbrContactMethodResponseType) jaxbElement
				.getValue();
		UpdatePaperBillServiceResponse serviceResponse = new UpdatePaperBillServiceResponse();
		serviceResponse.setResultStatus(response.getUpdateMbrContactMethodResponse().getResultStts());
		return serviceResponse;
	}

	@Transformer
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public JAXBElement<?> createGetMbrContactMethodRequest(GetMbrContactMethodServiceRequest serviceRequest)
	{
		MembershipServiceGetMbrContactMethodRequestType request = new MembershipServiceGetMbrContactMethodRequestType();
		MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest getMbrContactMethodRequest = new MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest();
		MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest.MbrInfo mbrInfo = new MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest.MbrInfo();
		mbrInfo.setGrpId(serviceRequest.getGroupId());
		mbrInfo.setSrcSysId(serviceRequest.getSourceSystemId());
		MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest.MbrInfo.Member member = new MembershipServiceGetMbrContactMethodRequestType.GetMbrContactMethodRequest.MbrInfo.Member();
		member.setSubscriberId(serviceRequest.getSubscriberId());
		member.setMbrSeqNum(serviceRequest.getMemberSequenceNumber());
		mbrInfo.setMember(member);
		getMbrContactMethodRequest.setMbrInfo(mbrInfo);
		request.setGetMbrContactMethodRequest(getMbrContactMethodRequest);
		JAXBElement<?> jaxbelement = new JAXBElement(new QName("http://wellpoint.com/service/membership",
				"MembershipService_Get_MbrContactMethod_Request"), request.getClass(), null, request);
		return jaxbelement;
	}

	@Transformer
	public GetMbrContactMethodServiceResponse processGetMbrContactMethodResponse(JAXBElement<?> jaxbElement)
	{
		MembershipServiceGetMbrContactMethodResponseType response = (MembershipServiceGetMbrContactMethodResponseType) jaxbElement
				.getValue();
		return dozerMapper.map(response.getGetMbrContactMethodResponse(), GetMbrContactMethodServiceResponse.class);
	}
}
