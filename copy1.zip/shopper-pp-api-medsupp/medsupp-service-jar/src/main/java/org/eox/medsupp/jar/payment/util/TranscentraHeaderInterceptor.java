/**
 * TranscentraHeaderInterceptor.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPPart;

import org.apache.log4j.Logger;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.eox.medsupp.transcentra.service.GetDocumentsRequest;
import org.eox.medsupp.transcentra.service.SearchDocumentsRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;


@Component("transcentraHeaderInterceptor")
public class TranscentraHeaderInterceptor implements ClientInterceptor, MedicarePayConstants
{

	private static final Logger LOGGER = Logger.getLogger(TranscentraHeaderInterceptor.class);

	private static final String V2_STR = "v2";

	private static final int DEAFULT_LIST_SIZE = 0;

	@Autowired
	private Jaxb2Marshaller transcentraMarshaller;

	@Autowired
	private WebServiceUtils webServiceUtils;

	@Override
	public boolean handleRequest(MessageContext messageContext)
	{

		LOGGER.info("TranscentraHeaderInterceptor handleRequest=====================================>>>>>>>>>>>>>>>>>>>");
		WebServiceMessage message = messageContext.getRequest();

		try
		{

			SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;

			javax.xml.soap.SOAPMessage soapMessage1 = saajSoapMessage.getSaajMessage();

			SOAPPart soapPart = soapMessage1.getSOAPPart();

			SOAPEnvelope soapEnvelope = soapPart.getEnvelope();

			SOAPHeader soapHeader = soapEnvelope.getHeader();

			SoapBody requestBody = ((SoapMessage) message).getSoapBody();
			Object requestBodyObj = transcentraMarshaller.unmarshal(requestBody.getPayloadSource());

			Name esbheaderName = soapEnvelope.createName("ESBHeader", V2_STR, "http://wellpoint.com/esb/header/v2");
			SOAPHeaderElement soapESBHeaderElmt = soapHeader.addHeaderElement(esbheaderName);

			// Add ESBHeader to Soap Header
			SOAPElement srvcNameSOAPElement = soapESBHeaderElmt.addChildElement("srvcName", V2_STR);
			srvcNameSOAPElement.addTextNode("Document");

			SOAPElement srvcVerSOAPElement = soapESBHeaderElmt.addChildElement("srvcVersion", V2_STR);
			srvcVerSOAPElement.addTextNode("1.0");

			SOAPElement operNameSOAPElement = soapESBHeaderElmt.addChildElement("operName", V2_STR);
			if (requestBodyObj instanceof SearchDocumentsRequest)
			{
				SearchDocumentsRequest req = (SearchDocumentsRequest) requestBodyObj;
				messageContext.setProperty(WS_CONTEXT_LOG_ID, getOutGoingId(req.getDocumentTypeCode().getSearchFields().getField()));
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, OPERATION_NAME_TRANSCENTRA_SEARCHDOC);
				operNameSOAPElement.addTextNode(OPERATION_NAME_TRANSCENTRA_SEARCHDOC);
			}
			else if (requestBodyObj instanceof GetDocumentsRequest)
			{
				GetDocumentsRequest req = (GetDocumentsRequest) requestBodyObj;
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getDocumentTypeCode().getDocumentList().getDocument().get(0).getId());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, OPERATION_NAME_TRANSCENTRA_GETDOC);
				operNameSOAPElement.addTextNode(OPERATION_NAME_TRANSCENTRA_GETDOC);
			}

			SOAPElement senderAppSOAPElement = soapESBHeaderElmt.addChildElement("senderApp", V2_STR);
			senderAppSOAPElement.addTextNode("PPORT");

			SOAPElement transIdSOAPElement = soapESBHeaderElmt.addChildElement("transId", V2_STR);
			String transId = webServiceUtils.getTransactionId();
			transIdSOAPElement.addTextNode(transId);
			messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);

		} catch (javax.xml.soap.SOAPException e)
		{
			LOGGER.error("SOAP Exception in TranscentraHeaderInterceptor  handleRequest method  -->" + e.getMessage());
		} catch (Exception e)
		{
			LOGGER.error("Exception in TranscentraHeaderInterceptor", e);
		}
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext)
	{
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext)
	{

		SoapMessage msg = (SoapMessage) messageContext.getResponse();
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try
		{
			msg.writeTo(os);
			String aString = new String(os.toByteArray(), "UTF-8");
			LOGGER.info("ERROR from Service in TranscentraHeaderInterceptor====>>>>>" + aString);
		} catch (Exception e1)
		{
			LOGGER.error("IO Exception  in TranscentraHeaderInterceptor handleFault method-->" + e1.getMessage());
		}
		return true;
	}

	private String getOutGoingId(List<SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field> searchFields) throws MedicarePayException
	{
		String outGoingId = "";
		if (searchFields != null && searchFields.size() > DEAFULT_LIST_SIZE)
		{
			for (SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field field : searchFields)
			{
				if ("Member ID".equalsIgnoreCase(field.getName()) || "Summary Bill No".equalsIgnoreCase(field.getName()) || "Group Bill Entity".equalsIgnoreCase(field.getName()))
				{
					outGoingId = field.getValue();
					break;
				}
			}
		}
		return outGoingId;
	}

	@Override
	public void afterCompletion(MessageContext arg0, Exception arg1) throws WebServiceClientException
	{
		// TODO Auto-generated method stub

	}

}
