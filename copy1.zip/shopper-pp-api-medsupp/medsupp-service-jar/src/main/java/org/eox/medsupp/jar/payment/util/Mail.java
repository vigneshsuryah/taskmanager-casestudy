/**
 * Mail.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


public class Mail
{
	private String mailFrom;
	private String mailTo;
	private String mailCc;
	private String mailSubject;
	private String contentType;
	private String templateLocation;
	private String toHcid;
	private String templateId;
	private String createdBy;
	private String mailType;

	public Mail()
	{
		contentType = "text/html";
	}

	public String getMailFrom()
	{
		return mailFrom;
	}

	public void setMailFrom(String mailFrom)
	{
		this.mailFrom = mailFrom;
	}

	public String getMailTo()
	{
		return mailTo;
	}

	public void setMailTo(String mailTo)
	{
		this.mailTo = mailTo;
	}

	public String getMailSubject()
	{
		return mailSubject;
	}

	public void setMailSubject(String mailSubject)
	{
		this.mailSubject = mailSubject;
	}

	public String getContentType()
	{
		return contentType;
	}

	public void setContentType(String contentType)
	{
		this.contentType = contentType;
	}

	public String getTemplateLocation()
	{
		return templateLocation;
	}

	public void setTemplateLocation(String templateLocation)
	{
		this.templateLocation = templateLocation;
	}

	public String getToHcid()
	{
		return toHcid;
	}

	public void setToHcid(String toHcid)
	{
		this.toHcid = toHcid;
	}

	public String getTemplateId()
	{
		return templateId;
	}

	public void setTemplateId(String templateId)
	{
		this.templateId = templateId;
	}

	public String getCreatedBy()
	{
		return createdBy;
	}

	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}

	public String getMailType()
	{
		return mailType;
	}

	public void setMailType(String mailType)
	{
		this.mailType = mailType;
	}

	public String getMailCc()
	{
		return mailCc;
	}

	public void setMailCc(String mailCc)
	{
		this.mailCc = mailCc;
	}

}
