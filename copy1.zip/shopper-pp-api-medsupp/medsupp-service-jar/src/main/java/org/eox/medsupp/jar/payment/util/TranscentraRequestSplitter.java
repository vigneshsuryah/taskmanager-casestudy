/**
 * TranscentraRequestSplitter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.util.ArrayList;
import java.util.List;

import org.eox.medsupp.schema.domain.transcentra.GetDocumentsServiceRequest;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceResponse;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;


@Component
public class TranscentraRequestSplitter
{
	public List<Object> split(SearchDocumentsServiceResponse searchDocumentsResponse, @Header("docValue") String docValue)
	{
		List<Object> requests = new ArrayList<Object>();
		GetDocumentsServiceRequest getDocumentsRequest = new GetDocumentsServiceRequest();
		getDocumentsRequest.setDocumentId(searchDocumentsResponse.getDocumentId());
		getDocumentsRequest.setDocumentType("DPS");
		getDocumentsRequest.setDocumentValue(docValue);
		requests.add(getDocumentsRequest);
		return requests;
	}
}
