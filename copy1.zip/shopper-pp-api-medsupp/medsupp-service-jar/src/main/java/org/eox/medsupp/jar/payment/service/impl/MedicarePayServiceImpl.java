/**
 * MedicarePayServiceImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/06/2018  1.0      Cognizant       CSR - Chase Integration
 * 03/25/2019  1.0      Cognizant       SMC mail changes
 */
package org.eox.medsupp.jar.payment.service.impl;


import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.eox.medsupp.datasvc.payment.dao.MedicareLoggingDao;
import org.eox.medsupp.datasvc.payment.dao.MedicarePayDao;
import org.eox.medsupp.datasvc.payment.entity.RSTransLog;
import org.eox.medsupp.jar.payment.aci.restapi.util.AciRestUtils;
import org.eox.medsupp.jar.payment.domain.MedicarePayRequestContext;
import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.jar.payment.paymod.utility.PayModRestUtils;
import org.eox.medsupp.jar.payment.service.MedicarePayService;
import org.eox.medsupp.jar.payment.util.EmailUtilHelper;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.paymod.request.AnthemBankDetails;
import org.eox.medsupp.paymod.request.CommunicationDetails;
import org.eox.medsupp.paymod.request.FundAccountOwnerFullAddress;
import org.eox.medsupp.paymod.request.GetTokenRequest;
import org.eox.medsupp.paymod.request.MailingAddress;
import org.eox.medsupp.paymod.request.PayModCancelPaymentRequest;
import org.eox.medsupp.paymod.request.PayModSubmitPaymentRequest;
import org.eox.medsupp.paymod.request.PayerId;
import org.eox.medsupp.paymod.request.PaymentMethod;
import org.eox.medsupp.paymod.request.Transaction;
import org.eox.medsupp.paymod.response.GetTokenResponse;
import org.eox.medsupp.paymod.response.PayModCancelPaymentResponse;
import org.eox.medsupp.paymod.response.PayModSubmitPaymentResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.Address;
import org.eox.medsupp.schema.model.BrandEmailMatrix;
import org.eox.medsupp.schema.model.MedicareBillDetails;
import org.eox.medsupp.schema.model.MedicareFAQ;
import org.eox.medsupp.schema.model.MedicareFaqDetails;
import org.eox.medsupp.schema.model.MedicareLinkedAccount;
import org.eox.medsupp.schema.model.MedicareMember;
import org.eox.medsupp.schema.model.MedicarePayAutoPay;
import org.eox.medsupp.schema.model.MedicarePayLinkedBill;
import org.eox.medsupp.schema.model.MedicarePayMember;
import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;
import org.eox.medsupp.schema.model.MedicarePayPaymentTypeEnum;
import org.eox.medsupp.schema.model.MedicarePersonDetails;
import org.eox.medsupp.schema.model.MemberEligibility;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;
import org.eox.medsupp.schema.model.SOAMemberProfile;
import org.eox.medsupp.schema.request.CancelPaymentRequest;
import org.eox.medsupp.schema.request.GetAccountSummaryRequest;
import org.eox.medsupp.schema.request.GetAutoPaymentRequest;
import org.eox.medsupp.schema.request.GetEligibilityRequest;
import org.eox.medsupp.schema.request.GetLinkedAccountRequest;
import org.eox.medsupp.schema.request.GetMedicareFaqRequest;
import org.eox.medsupp.schema.request.GetPaymentMethodRequest;
import org.eox.medsupp.schema.request.GetViewBillRequest;
import org.eox.medsupp.schema.request.SubmitPaymentRequest;
import org.eox.medsupp.schema.request.UpdateLinkedAccountRequest;
import org.eox.medsupp.schema.request.UpdatePaperBillServiceRequest;
import org.eox.medsupp.schema.request.UpdatePaymentMethodRequest;
import org.eox.medsupp.schema.request.ViewPaymentHistoryRequest;
import org.eox.medsupp.schema.response.CancelPaymentResponse;
import org.eox.medsupp.schema.response.GetAccountSummaryResponse;
import org.eox.medsupp.schema.response.GetAutoPaymentResponse;
import org.eox.medsupp.schema.response.GetEligibilityResponse;
import org.eox.medsupp.schema.response.GetLinkedAccountResponse;
import org.eox.medsupp.schema.response.GetMedicareFaqResponse;
import org.eox.medsupp.schema.response.GetPaymentMethodResponse;
import org.eox.medsupp.schema.response.GetViewBillResponse;
import org.eox.medsupp.schema.response.Message;
import org.eox.medsupp.schema.response.SubmitPaymentResponse;
import org.eox.medsupp.schema.response.UpdateLinkedAccountResponse;
import org.eox.medsupp.schema.response.UpdatePaperBillServiceResponse;
import org.eox.medsupp.schema.response.UpdatePaymentMethodResponse;
import org.eox.medsupp.schema.response.ViewPaymentHistoryResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;

import com.wellpoint.aci.enums.AciFundingActionType;
import com.wellpoint.aci.enums.BankAccountType;
import com.wellpoint.aci.enums.CreditCardType;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPayment;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;


import org.eox.medsupp.paymod.request.MamDetailsBO;

import org.eox.medsupp.paymod.request.Note;

/**
 * @author 463657
 * 
 */
@Service
@RefreshScope
public class MedicarePayServiceImpl implements MedicarePayService, MedicarePayConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MedicarePayServiceImpl.class);

	@Autowired
	private Mapper dozerMapper;

	@Autowired
	private AciRestUtils aciRestUtils;

	@Autowired
	private MedicarePayUtils medicarePayUtils;

	@Autowired
	private MedicareLoggingDao medicareLoggingDaoImpl;

	@Autowired
	private MedicarePayDao medicarePayDaoImpl;

	@Autowired
	private MedicarePayGateway medicarePayGateway;
	
	@Autowired
	private PayModRestUtils payModRestUtils;

	@Autowired
	private EmailUtilHelper emailUtilHelper;

	@Value("${medicare.faq.file.location}")
	private String faqFileLocation;
	
	@Value("${medicare.setting.approvedeny.success.urlpath}")
	private String actionUrl;
	
	@Value("${medicarepay.setting.ga.rebrand.today.date.change.required}")
	private String todayDateInd;
	
	@Value("${medicarepay.setting.ga.rebrand.today.date}")
	private String todayDate;

	/**
	 * Returns the saved payment methods of the medicare member
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest request) throws MedicarePayException
	{
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		try
		{
			validateMember(request.getHealthCardId(), request.getServiceEnv());
			if (null != request)
			{
				final MedicarePayRequestContext.Builder contextBuilder = new MedicarePayRequestContext.Builder(request.getHealthCardId())
						.metaSrcEnv(request.getServiceEnv());
				AciFundingRequest aciRequest = (AciFundingRequest) medicarePayUtils.getRequestInstance(AciFundingRequest.class);
				aciRequest.setHcid(request.getHealthCardId());
				aciRequest.setFundingRequestActionType(AciFundingActionType.GETSUM);

				final AciFundingResponse aciResponse = aciRestUtils.invokeManagePaymentMethodACI(contextBuilder.requestObj(aciRequest)
						.build());
				if (null != aciResponse && MedicarePayUtils.checkNullForAString(aciResponse.getAckStatus()) && "Success".equalsIgnoreCase(aciResponse.getAckStatus()))
				{
					List<MedicarePayPaymentMethod> medicarePayPaymentMethods = new ArrayList<>();

					List<CreditCardDetails> creditCardDetails = aciResponse.getCreditCardDetails();
					if (MedicarePayUtils.checkNullForAList(creditCardDetails))
					{
						for (Iterator<CreditCardDetails> iterator = creditCardDetails.iterator(); iterator.hasNext();)
						{
							CreditCardDetails paymentMethod = iterator.next();
							MedicarePayPaymentMethod medicarePayMethod = dozerMapper.map(paymentMethod, MedicarePayPaymentMethod.class);
							medicarePayPaymentMethods.add(medicarePayMethod);
						}
					}

					List<BankAccountDetails> bankAcctList = aciResponse.getBankAccountDetails();
					if (MedicarePayUtils.checkNullForAList(bankAcctList))
					{
						for (BankAccountDetails entry : bankAcctList)
						{
							MedicarePayPaymentMethod bankPayMethod = dozerMapper.map(entry, MedicarePayPaymentMethod.class);
							medicarePayPaymentMethods.add(bankPayMethod);
						}
					}
					response.setMedicarePayPaymentMethods(medicarePayPaymentMethods);
				}
				else
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedicarePayServiceImpl getPaymentMethods : " + e);
			throwException(e);
		}
		return response;
	}

	/**
	 * Add/Edit/Deletes payment method of the medicare member
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest request) throws MedicarePayException
	{
		UpdatePaymentMethodResponse updatePaymentMethodResponse = new UpdatePaymentMethodResponse();
		try
		{
			if (null != request)
			{

				MedicarePayPaymentMethod paymentMethod = request.getPaymentMethod();
				if (null != paymentMethod)
				{
					updatePaymentMethodResponse = updateCCinACI(request, updatePaymentMethodResponse);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedicarePayServiceImpl updatePaymentMethod : " + e);
			throwException(e);
		}
		return updatePaymentMethodResponse;
	}

	/**
	 * Add/Edit/Deletes payment method of the medicare member
	 * @param request
	 * @param response
	 * @return
	 * @throws MedicarePayException
	 */
	private UpdatePaymentMethodResponse updateCCinACI(UpdatePaymentMethodRequest request,
			UpdatePaymentMethodResponse updatePaymentMethodResponse) throws MedicarePayException
	{
		final MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(request.getHealthCardId())
				.metaSrcEnv(request.getServiceEnv());

		AciFundingRequest aciRequest = (AciFundingRequest) medicarePayUtils.getRequestInstance(AciFundingRequest.class);
		aciRequest.setHcid(request.getHealthCardId());
		if ("CREATE".equalsIgnoreCase(request.getAction()))
		{
			aciRequest.setFundingRequestActionType(AciFundingActionType.CREATE);
		}
		else if ("MODIFY".equalsIgnoreCase(request.getAction()))
		{
			aciRequest.setFundingRequestActionType(AciFundingActionType.MODIFY);
		}
		else if ("DELETE".equalsIgnoreCase(request.getAction()))
		{
			aciRequest.setFundingRequestActionType(AciFundingActionType.DELETE);
		}
		MedicarePayPaymentMethod paymentMethod = request.getPaymentMethod();
		aciRequest.setTokenId(paymentMethod.getTokenId());
		if (paymentMethod.getPaymentType() == MedicarePayPaymentTypeEnum.CREDITDEBITCARD)
		{
			// CreditCardDetails creditCardDetails = dozerMapper.map(paymentMethod, CreditCardDetails.class);
			aciRequest.setCreditCardDetails(setCreditCardDetailsForEdit(paymentMethod));
		}
		else
		{
			// BankAccountDetails bankAccountDetails = dozerMapper.map(paymentMethod, BankAccountDetails.class);
			aciRequest.setBankAccountDetails(setBankAccountDetailsForEdit(paymentMethod));
		}

		final AciFundingResponse response = aciRestUtils.invokeManagePaymentMethodACI(context.requestObj(aciRequest).build());

		if (null != response && null != response.getAciException())
		{
			if ("AC9000".equalsIgnoreCase(response.getAciException().getErrorCode()))
			{
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
			throw new MedicarePayException(EXCEPTION, response.getAciException().getErrorCode(), response.getAciException().getErrorMessage(),
					500);
		}
		else
		{
			if (null != response && null != response.getResponseMessage())
			{
				Message message = new Message();
				message.setMessageCode(response.getResponseMessage().getMessageCode());
				message.setMessageText(MedicarePayUtils.removeErrCode(response.getResponseMessage().getMessageDesc()));
				updatePaymentMethodResponse.setMessage(message);

				if (checkUpdatePayMethodMessage(response.getResponseMessage().getMessageCode(), response.getResponseMessage().getMessageDesc()))
				{
					MedicarePayPaymentMethod medicarePayPaymentMethod = new MedicarePayPaymentMethod();
					if (null != response.getCreditCardDetails() && response.getCreditCardDetails().size() > 0)
					{
						medicarePayPaymentMethod.setTokenId(response.getCreditCardDetails().get(0).getTokenId());
					}
					if (null != response.getBankAccountDetails() && !response.getBankAccountDetails().isEmpty())
					{
						medicarePayPaymentMethod.setTokenId(response.getBankAccountDetails().get(0).getTokenId());
					}
					updatePaymentMethodResponse.setMedicarePayPaymentMethod(medicarePayPaymentMethod);
				}
			} else if(null != response && null != response.getAckStatus() && "Failed".equalsIgnoreCase(response.getAckStatus())) {
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
		}
		return updatePaymentMethodResponse;
	}

	/**
	 * Returns the auto payment pdf
	 * @param request
	 * @param response
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public GetAccountSummaryResponse getAccountSummary(GetAccountSummaryRequest request) throws MedicarePayException
	{
		GetAccountSummaryResponse response = new GetAccountSummaryResponse();
		//PP-14143 - Start
		boolean isCSREligibile = false;
		List<MemberEligibility> memberEligibilityList = null;
		try
		{
			if(null == request.getCsrId() || (null != request.getCsrId() && request.getCsrId().isEmpty())) {
				validateMember(request.getHealthCardId(), request.getServiceEnv());
			}
			if(null != request.getCsrId() && !request.getCsrId().isEmpty()) {
				memberEligibilityList = invokeMemberProfile(request.getHealthCardId());
				if(!MedicarePayUtils.checkNullForAList(memberEligibilityList)) {
					throw new MedicarePayException(EXCEPTION, "9001", INVALID_HCID_ERROR_MSG, 500);
				}
				isCSREligibile = checkCSREligibility(memberEligibilityList,  request.getCsrRoles());
				if(!isCSREligibile) {
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9011, UNAUTHORIZED_CSR_ERROR, 401);
				}
			}
			//PP-14143 - End
			GetAccountSummaryResponse accountSummaryResponse = null;
			Set<String> hcidSet = new HashSet<String>();
			List<Future<GetAccountSummaryResponse>> getMemberProfileFutureList = new ArrayList<>();
			List<String> allowedPayMethodList = null;
			String state = "";
			String lob = "";
			//PP-14143 - Start
			//do not include linked hcid's for CSR
			if(null == request.getCsrId() || (null != request.getCsrId() && request.getCsrId().isEmpty())) {
				hcidSet = medicarePayDaoImpl.getChildHcids(request.getHealthCardId(), request.getServiceEnv());
			}
			//PP-14143 - End
			hcidSet.add(request.getHealthCardId());
			for (String hcid : hcidSet)
			{
				GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
				newReq.setHealthCardId(hcid);
				newReq.setServiceEnv(request.getServiceEnv());
				//PP-14143 - Start
				newReq.setCsrId(request.getCsrId());
				newReq.setLob(request.getLob());
				//PP-14143 - End
				getMemberProfileFutureList.add(medicarePayGateway.getMemberProfile(newReq));
			}
			List<MedicareMember> finalMedicareMemberList = new ArrayList<>();
			boolean serviceFailure = true;
			for (Future<GetAccountSummaryResponse> futureObj : getMemberProfileFutureList)
			{
				accountSummaryResponse = futureObj.get();
				if (MedicarePayUtils.checkNullForAList(accountSummaryResponse.getMedicareMemberList()))
				{
					finalMedicareMemberList.addAll(accountSummaryResponse.getMedicareMemberList());
				}
				if(null == accountSummaryResponse.getMedicarePayException()){
					serviceFailure = false;
				}
			}
			if(serviceFailure){
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
			//PP-14143 - Start
			if(null != request.getCsrId() && !request.getCsrId().isEmpty()) {
				constructCSRSummaryResponse(response, finalMedicareMemberList, request);
			} else {
				constructSummaryResponse(response, finalMedicareMemberList);
			}
			//PP-14143 - End
			if (MedicarePayUtils.checkNullForAList(response.getMedicareMemberList()))
			{
				List<MedicareMember> childLinkeBills= new ArrayList<>();
				MedicareMember parentLinkedBill = null;
				for (MedicareMember member : response.getMedicareMemberList())
				{
					if (null != member && request.getHealthCardId().equalsIgnoreCase(member.getHealthCardId()))
					{
						member.setRelationShip("self");
						state = member.getState();
						if(MedicarePayUtils.checkNullForAList(member.getMedicareBillDetails())) {
							lob = null != member.getMedicareBillDetails().get(0).getLineOfBusiness() ? 
									member.getMedicareBillDetails().get(0).getLineOfBusiness().toUpperCase() : "";
						}
						resetBillDetails(member);
						parentLinkedBill = member;
					}
					else
					{
						member.setRelationShip("child");
						resetBillDetails(member);
						childLinkeBills.add(member);
					}
				}
				allowedPayMethodList = medicarePayDaoImpl.getAllowedPaymentMethod(state, lob, "ONETIME");
				if (MedicarePayUtils.checkNullForAList(allowedPayMethodList))
				{
					if (allowedPayMethodList.contains("BANKINGACCOUNT"))
					{
						response.setBankingAllowed(true);
					}
					if (allowedPayMethodList.contains("CREDITDEBITCARD"))
					{
						response.setCreditDebitAllowed(true);
					}
				}
				sortMedicareMember(response, childLinkeBills, parentLinkedBill);
				if(null!=todayDateInd && !todayDateInd.isEmpty() && "Y".equalsIgnoreCase(todayDateInd)){
					if(null!=todayDate && !todayDate.isEmpty())
						response.setTodayDate(todayDate);
				} else{
					Date dt = new Date();
					SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
					response.setTodayDate(formatDate.format(dt));
				}
					
			}
			else
			{
				throw new MedicarePayException(EXCEPTION, "9001", INVALID_HCID_ERROR_MSG, 500);
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedSupServiceImpl getAccountSummay : " + e);
			throwException(e);
		}

		return response;

	}

	/**
	 * Resets sorted Bill Details
	 * @param member
	 * @throws MedicarePayException
	 */
	private void resetBillDetails(MedicareMember member) throws MedicarePayException
	{
		if(MedicarePayUtils.checkNullForAList(member.getMedicareBillDetails())){
			List<MedicareBillDetails> billAccounts = new ArrayList<MedicareBillDetails>();
			billAccounts.addAll(member.getMedicareBillDetails());
			member.getMedicareBillDetails().clear();
			member.getMedicareBillDetails().addAll(prepareFinalBillAccountsWithoutNull(billAccounts));
		}
	}

	/**
	 * This method is used to sort Members based on the hcid
	 * @param response
	 * @param childLinkeBills
	 * @param parentLinkedBill
	 * @throws MedicarePayException
	 */
	private void sortMedicareMember(GetAccountSummaryResponse response, List<MedicareMember> childLinkeBills,
			MedicareMember parentLinkedBill) throws MedicarePayException
	{
		response.getMedicareMemberList().clear();
		response.getMedicareMemberList().add(parentLinkedBill);
		if(MedicarePayUtils.checkNullForAList(childLinkeBills)){
			Collections.sort(childLinkeBills, new Comparator<MedicareMember>() {
			    public int compare(MedicareMember linkedBillOne, MedicareMember linkedBillTwo) {
			    	if (linkedBillOne.getHealthCardId() == null || linkedBillTwo.getHealthCardId() == null){
			            return 0;
			    	}
			        return linkedBillTwo.getHealthCardId().compareTo(linkedBillOne.getHealthCardId());
			    }
			});
			response.getMedicareMemberList().addAll(childLinkeBills);
		}
	}
	
	/**
	 * Sort Bill Details based on Group Id
	 * @param billAccounts
	 * @return
	 * @throws MedicarePayException
	 */
	public List<MedicareBillDetails> prepareFinalBillAccountsWithoutNull(List<MedicareBillDetails> billAccounts) throws MedicarePayException{
		List<MedicareBillDetails> finalBillAccounts= new ArrayList<>();
           Collections.sort(billAccounts, new Comparator<MedicareBillDetails>(){
         	    @Override
         	    public int compare(MedicareBillDetails billAccount1, MedicareBillDetails billAccount2){
         	    	if(null != billAccount1 && null != billAccount2 && null != billAccount1.getGroupId() && null != billAccount2.getGroupId()){
         	    		return billAccount1.getGroupId().compareTo(billAccount2.getGroupId());
         	    	}else{
         	    		return 0;
         	    	}
         	    }
         	});		
		// To remove null in the object array as sometimes null objects are pushed inside
		for(MedicareBillDetails finalBillAccount:billAccounts){
			if(null != finalBillAccount){
				finalBillAccounts.add(finalBillAccount);
			}
		}
		return finalBillAccounts;
	}

	/**
	 * Constructs Account Summary Response with Min due, total due, pay now count, bill records count
	 * @param response
	 * @param finalMedicareMemberList
	 * @throws MedicarePayException
	 */
	private void constructSummaryResponse(GetAccountSummaryResponse response, List<MedicareMember> finalMedicareMemberList)
			throws MedicarePayException
	{
		int payNowCount = 0;
		int billRecordsCount = 0;
		float totalDue = 0.0f;
		float minDue = 0.0f;
		if (MedicarePayUtils.checkNullForAList(finalMedicareMemberList))
		{
			for (MedicareMember medicareMember : finalMedicareMemberList)
			{
				if (MedicarePayUtils.checkNullForAList(medicareMember.getMedicareBillDetails()))
				{
					for (MedicareBillDetails medicareBillDetail : medicareMember.getMedicareBillDetails())
					{
						billRecordsCount++;
						if ("Pay Now".equalsIgnoreCase(medicareBillDetail.getPaymentStatus()))
						{
							payNowCount++;
							totalDue += medicareBillDetail.getBillNetDue();
							minDue += medicareBillDetail.getBillMinDue();
						}

					}
				}
			}
			response.setMedicareMemberList(finalMedicareMemberList);
		}
		response.setPayNowCount(payNowCount);
		response.setTotalAmountDue(totalDue);
		response.setMinDueAmount(minDue);
		response.setTotalBillsAvailableCount(billRecordsCount);
	}

	/**
	 * Cancels the in-progress payment
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public CancelPaymentResponse cancelPayment(CancelPaymentRequest request) throws MedicarePayException
	{
		final MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(request.getPaymentConfirmationNo())
				.metaSrcEnv(request.getServiceEnv());
		CancelPaymentResponse response = new CancelPaymentResponse();

		if (null != request)
		{
			AciCancelRequest aciRequest = (AciCancelRequest) medicarePayUtils.getRequestInstance(AciCancelRequest.class);
			try
			{
				if (MedicarePayUtils.checkNullForAString(request.getPaymentConfirmationNo()) && request.getPaymentConfirmationNo().trim().length() > 0)
				{
					aciRequest.setPaymentConfirmationNo(request.getPaymentConfirmationNo());
					AciCancelResponse cancelPaymentServiceResponse = aciRestUtils.invokeCancelPaymentACI(context.requestObj(aciRequest)
							.build());
					if (null != cancelPaymentServiceResponse.getResponseMessage() && null != cancelPaymentServiceResponse.getResponseMessage().getMessageDesc()
							&& !StringUtils.equalsIgnoreCase(cancelPaymentServiceResponse.getAckStatus(), ACI_PAYMENT_CANCEL_FAIL_STATUS))
					{
						response.setPaymentCancelStatus(cancelPaymentServiceResponse.getResponseMessage().getMessageDesc());
						response.setPaymentConfirmationNo(cancelPaymentServiceResponse.getPaymentConfirmationNo());
					}
					else
					{
						Message message = new Message();
						if (null != cancelPaymentServiceResponse.getResponseMessage())
						{
							message.setMessageText(cancelPaymentServiceResponse.getResponseMessage().getMessageDesc());
							message.setMessageCode(cancelPaymentServiceResponse.getResponseMessage().getMessageCode());
						}
						response.setMessage(message);
						response.setPaymentCancelStatus(CANCELPAYMENT_SERVICE_FAILED);
					}
				}
				else
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			} catch (Exception e)
			{
				LOGGER.error("Exception in MedicarePayServiceImpl cancelPayment : " + e);
				throwException(e);
			}
		}
		return response;
	}

	@Override
	public SubmitPaymentResponse submitPayment(SubmitPaymentRequest request) throws MedicarePayException
	{
		final MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(request.getHealthCardId())
				.metaSrcEnv(request.getServiceEnv());
		SubmitPaymentResponse response = new SubmitPaymentResponse();

		if (request != null)
		{
			try
			{
				AciPaymentRequest aciPaymentRequest = (AciPaymentRequest) medicarePayUtils.getRequestInstance(AciPaymentRequest.class);
				aciPaymentRequest.setHcid(request.getHealthCardId());
				aciPaymentRequest.setPaymentType(request.getPaymentType().toString());
				
				//building list of model map for all group ids
				Map<String, Object> modelMapList = new HashMap<String, Object>();
				for (MemberPaySubmitPayment oneRequest : request.getMemberpaySubmitPayments())
				{
					Map<String, Object> modelMap = getMemberProfileDataSubmit(request.getHealthCardId(), request.getHealthCardId(), oneRequest.getPlanID());
					modelMapList.put(oneRequest.getPlanID(), modelMap);
				}
				
				/*Map<String, Object> modelMap = getMemberProfileDataForMail(request.getHealthCardId(), request.getHealthCardId());
				if (null != modelMap.get("divisionCode"))
				{
					aciPaymentRequest.setDivisionCode(MedicarePayUtils.getStringProperty(
							"division.code." + (String) modelMap.get("divisionCode"), ""));
				}*/
				aciPaymentRequest.setIsNewPaymentMethod(request.isNewPaymentMethod());
				if (request.isNewPaymentMethod())
				{
					if (null != request.getBankAccountDetails())
					{
						aciPaymentRequest.setBankAccountDetails(request.getBankAccountDetails());
					}
					else if (null != request.getCreditCardDetails())
					{
						aciPaymentRequest.setCreditCardDetails(request.getCreditCardDetails());
					}
					else
					{
						throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
					}
					aciPaymentRequest.setIsForFutureUse(request.isPayMetFutureUse());
				}
				else
				{
					aciPaymentRequest.setTokenId(request.getTokenId());
					aciPaymentRequest.setIsForFutureUse(false);
				}
				aciPaymentRequest.setPaymentDate(medicarePayUtils.splitDateToMMddyyyyFormat(request.getPaymentDate()));
				createAciFundingRequest(request, aciPaymentRequest);
				response = aciRestUtils.invokeSubmitPaymentACI(context.requestObj(aciPaymentRequest).build());
				if (null != response && null != response.getMemberpaySubmitPayments() && response.getMemberpaySubmitPayments().size() > 0)
				{
					for (MemberPaySubmitPayment memPaySubmitPayment : response.getMemberpaySubmitPayments())
					{
						Map<String, Object> modelMap = new HashMap<String, Object>();
						if(null != modelMapList.get(memPaySubmitPayment.getPlanID())) {
							modelMap = (Map<String, Object>) modelMapList.get(memPaySubmitPayment.getPlanID());
						}
						if (null != memPaySubmitPayment && null != memPaySubmitPayment.getMessage()
								&& MedicarePayUtils.checkNullForAString(memPaySubmitPayment.getMessage().getMessageText())
								&& "Success".equalsIgnoreCase(memPaySubmitPayment.getMessage().getMessageText()))
						{
							// SOA mail service call
							medicarePayGateway.sendPaySuccessMail(modelMap, memPaySubmitPayment, request.getHealthCardId());
						}
						else
						{	
							try{
							// send mail from this application
							//	aciRestUtils.constructMailParams(modelMap, MAIL_TYPE_PAY_FAILED);
								medicarePayGateway.sendFailedPayMail(modelMap);
							}catch(Exception e){
								LOGGER.error("Error while sending mail: Inside submitPayment method");
							}
						}
					}

				}
			} catch (Exception e)
			{
				LOGGER.error("Exception in MedicarePayServiceImpl submitPayment : " + e);
				throwException(e);
			}

		}
		return response;
	}

	public void createAciFundingRequest(SubmitPaymentRequest request, AciPaymentRequest aciPaymentRequest) throws MedicarePayException
	{
		List<AciPayment> aciPaymentLst = new ArrayList<AciPayment>();
		for (MemberPaySubmitPayment memberPaySubmitPayment : request.getMemberpaySubmitPayments())
		{

			if (null != memberPaySubmitPayment.getChildHealthCardId())
			{
				AciPayment aciPayment = new AciPayment();
				aciPayment.setPaymentSubmissionId(memberPaySubmitPayment.getChildHealthCardId());
				aciPayment.setProductCode(memberPaySubmitPayment.getPlanID());
				aciPayment.setRemitAmount(memberPaySubmitPayment.getPaymentAmount());
				aciPayment.setRemitFee("0.00");
				
				String divisionDetails = MedicarePayUtils.getStringProperty("division.code." + memberPaySubmitPayment.getDivisionCode(), "");
				String [] divDetailsArr = null;
				if(null != divisionDetails && !divisionDetails.isEmpty()){
					divDetailsArr = divisionDetails.split("\\|");
				}
				if(null != divDetailsArr && divDetailsArr.length > 0){
					aciPayment.setDivisionCode(divDetailsArr[0]);
				} else{
					aciPayment.setDivisionCode("");
				}
				
				aciPaymentLst.add(aciPayment);
			}
		}
		aciPaymentRequest.setAciPayments(aciPaymentLst);
	}

	@Override
	public void saveRSLog(RSTransLog request) throws MedicarePayException
	{
		LOGGER.info("Inside MedicarePayServiceImpl - saveRSLog start");
		try
		{
			if(null != request.getOperationName()){
				String opName = request.getOperationName();
				if(null != opName && !opName.isEmpty() && (opName.equalsIgnoreCase("submitPayment") || opName.equalsIgnoreCase("updatePaymentMethod"))){
					request.setRequestXML(MedicarePayUtils.getEncodedText(request.getRequestXML()));
					request.setResponseXML(MedicarePayUtils.getEncodedText(request.getResponseXML()));
				}
			}
			medicareLoggingDaoImpl.saveRSServiceLog(request);
		} catch (Exception e)
		{
			LOGGER.error("Exception MedicarePayServiceImpl - saveRSLog : " + e);
		}
	}

	@Override
	public GetLinkedAccountResponse getLinkedAccount(GetLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - getLinkedAccount() of MedicarePayServiceImpl");
		GetLinkedAccountResponse response = new GetLinkedAccountResponse();
		try
		{
			List<MedicareLinkedAccount> linkedAccounts = medicarePayDaoImpl.getLinkedAccount(request.getHealthCardId());
			linkedAccounts = populateSubscriberName(linkedAccounts, request.getHealthCardId());
			response.setLinkedAccounts(linkedAccounts);
			response.setErrorFlag(false);
		} catch (MedicarePayException e)
		{
			response.setErrorFlag(true);
			response.setErrorMessage("Exception occured in get LinkedBill " + e.getErrorMessage());
			LOGGER.error("Exception occured in getLinkedAccount() of MedicarePayServiceImpl " + e.getErrorMessage());
		} catch (Exception e)
		{
			response.setErrorFlag(true);
			response.setErrorMessage("Exception occured in get LinkedBill : Cause :" + e.getMessage());
			LOGGER.error("Exception occured in getLinkedAccount() of MedicarePayServiceImpl " + e.getMessage());
		}
		LOGGER.info("End - getLinkedAccount() of MedicarePayServiceImpl");
		return response;
	}

	private List<MedicareLinkedAccount> populateSubscriberName(List<MedicareLinkedAccount> linkedAccounts, String selfHcid)
			throws InterruptedException, ExecutionException, MedicarePayException
	{
		/* set first name and last name from getContractService - use asynchronous call */
		LOGGER.info("Start - populateSubscriberName() of MedicarePayServiceImpl");
		List<MedicareLinkedAccount> populatedLinkedAccounts = new ArrayList<MedicareLinkedAccount>();
		ArrayList<Future<GetAccountSummaryResponse>> getAccountSummaryResponseList = new ArrayList<Future<GetAccountSummaryResponse>>();
		Set<String> hcids = new HashSet<String>();
		for (MedicareLinkedAccount linkedAccount : linkedAccounts)
		{
			hcids.add(linkedAccount.getPersonDetails().getChildMemberId());
		}
		hcids.add(selfHcid);

		for (String hcid : hcids)
		{
			GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
			newReq.setHealthCardId(hcid);
			getAccountSummaryResponseList.add(medicarePayGateway.getMemberProfileAsync(newReq));
		}
		for (Future<GetAccountSummaryResponse> asyncGetAccountSummaryResponse : getAccountSummaryResponseList)
		{
			GetAccountSummaryResponse getAccountSummaryResponse = asyncGetAccountSummaryResponse.get();
			if (null != getAccountSummaryResponse
					&& MedicarePayUtils.checkNullForAList(getAccountSummaryResponse.getMemberEligibilityList()))
			{
				MemberEligibility memberEligibility = aciRestUtils.getProductLevelBillDetails(getAccountSummaryResponse.getMemberEligibilityList());
				if (null != memberEligibility)
				{
					for (MedicareLinkedAccount linkedAccount : linkedAccounts)
					{
						if (null != memberEligibility.getHealthCardId()
								&& memberEligibility.getHealthCardId().getSubscriberId()
										.equalsIgnoreCase(linkedAccount.getPersonDetails().getChildMemberId()))
						{
							MedicarePersonDetails personDetails = new MedicarePersonDetails();
							if (null != memberEligibility.getMemberDemographicDetails())
							{
								personDetails.setFirstName(correctCasing(memberEligibility.getMemberDemographicDetails().getFirstName()));
								personDetails.setLastName(correctCasing(memberEligibility.getMemberDemographicDetails().getLastName()));
							}
							else
							{
								personDetails.setFirstName("");
								personDetails.setLastName("");
							}
							personDetails.setChildMemberId(linkedAccount.getPersonDetails().getChildMemberId());
							linkedAccount.setPersonDetails(personDetails);
							populatedLinkedAccounts.add(linkedAccount);
						}
					}
				}
			}

		}
		LOGGER.info("End - populateSubscriberName() of MedicarePayServiceImpl");
		return populatedLinkedAccounts;
	}

	/**
	 * Changes the case of input value
	 * @param name
	 * @return
	 */
	private String correctCasing(String name)
	{
		LOGGER.info("Start - correctCasing() of MedicarePayServiceImpl");
		String correctCasedString = "";
		if (null != name && !name.isEmpty())
		{
			correctCasedString = StringUtils.capitalize(name.toLowerCase());
		}
		return correctCasedString;
	}

	/**
	 * Updates a linked bill
	 * 
	 * @param UpdateLinkedBillRequest
	 * @return UpdateLinkedBillResponse
	 * @exception MedicarePayException
	 */
	@Override
	public UpdateLinkedAccountResponse updateLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("start - updateLinkedAccount() of MedicarePayServiceImpl");
		UpdateLinkedAccountResponse response = new UpdateLinkedAccountResponse();
		try
		{
			String action = request != null ? request.getAction() : "";
			if (request.isFromMail())
			{
				String subscriberName = approveDenyAccountFromMail(request);
				response.setSubScriberName(subscriberName);
			}
			else
			{
				if (LINK_ACTION_ADD.equalsIgnoreCase(action))
				{
					addLinkedAccount(request);
				}
				else if (LINK_ACTION_REMOVE.equalsIgnoreCase(action))
				{
					removeLinkedAccount(request);
				}
				else if (LINK_ACTION_APPROVE.equalsIgnoreCase(action) || LINK_ACTION_DENY.equalsIgnoreCase(action))
				{
					approveOrDenyLinkedAccount(request);
				}
			}
			response.setErrorFlag(false);
		} catch (MedicarePayException e)
		{
			response.setErrorFlag(true);
			response.setErrorMessage(e.getErrorMessage());
			LOGGER.error("Exception Occured in updateLinkedAccount() of MedicarePayServiceImpl " + e.getErrorMessage());
		} catch (Exception e)
		{
			response.setErrorFlag(true);
			response.setErrorMessage("Your request to update the linked account cannot be performed at this time. Please try again later or contact us at the number on your ID Card.");
			LOGGER.error("Exception Occured in updateLinkedAccount() of MedicarePayServiceImpl " + e.getMessage());
		}
		LOGGER.info("End - updateLinkedAccount() of MedicarePayServiceImpl");
		return response;
	}

	/**
	 * Approves or Denies an account from mail
	 * 
	 * @param UpdateLinkedAccountRequest
	 * @return String
	 * @exception MedicarePayException
	 */
	private String approveDenyAccountFromMail(UpdateLinkedAccountRequest request) throws MedicarePayException
	{

		LOGGER.info("Start - approveDenyAccountFromMail() of MedicarePayServiceImpl");
		String subscriberName = "";

		try
		{
			String relStatus = medicarePayDaoImpl.getLinkedAccountStatusFromKey(request.getKey());
			if (MedicarePayUtils.checkNullForAString(relStatus))
			{
				relStatus = relStatus.trim();
				if (LINK_STATUS_DENY.equalsIgnoreCase(relStatus))
				{
					throw new MedicarePayException("The request to link to this account expired or was already rejected.");
				}
				else if (LINK_STATUS_APPROVE.equalsIgnoreCase(relStatus))
				{
					throw new MedicarePayException("This account is already linked.");
				}
				else if (LINK_STATUS_REMOVE.equalsIgnoreCase(relStatus))
				{
					throw new MedicarePayException("This association is already removed by parent");
				}
				String hcid = medicarePayDaoImpl.updateLinkedAccountStatusFromKey(request.getAction(), request.getKey());
				if (MedicarePayUtils.checkNullForAString(hcid))
				{
					if (LINK_ACTION_APPROVE.equalsIgnoreCase(request.getAction()))
					{
						GetAccountSummaryRequest getAccountSummaryRequest = new GetAccountSummaryRequest();
						getAccountSummaryRequest.setHealthCardId(hcid);
						Future<GetAccountSummaryResponse> getAccountSummaryfutureObj = medicarePayGateway
								.getMemberProfileAsync(getAccountSummaryRequest);
						GetAccountSummaryResponse getAccountSummaryResponse = getAccountSummaryfutureObj.get();
						List<MemberEligibility> eligibilities = getAccountSummaryResponse.getMemberEligibilityList();
						if (MedicarePayUtils.checkNullForAList(eligibilities))
						{
							MemberEligibility memberEligibility = aciRestUtils.getProductLevelBillDetails(eligibilities);
							if (null != memberEligibility.getMemberDemographicDetails())
							{
								subscriberName = correctCasing(memberEligibility.getMemberDemographicDetails().getFirstName()) + " "
										+ correctCasing(memberEligibility.getMemberDemographicDetails().getLastName());
							}
						}
					}
				}
			}
			else
			{
				throw new MedicarePayException("The request to link to this account expired or was already rejected.");
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in approveDenyAccountFromMail() of MedicarePayServiceImpl " + e.getMessage());
			throwException(e);
		}
		LOGGER.info("End - approveDenyAccountFromMail() of MedicarePayServiceImpl");
		return subscriberName;

	}

	/**
	 * Approves or Denies a linked Account
	 * 
	 * @return
	 * @throws MedicarePayException
	 */
	private boolean approveOrDenyLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		boolean status = false;
		String relStatus = medicarePayDaoImpl.getLinkedAccountStatus(request);
		if (MedicarePayUtils.checkNullForAString(relStatus))
		{
			relStatus = relStatus.trim();
			if (LINK_STATUS_APPROVE.equalsIgnoreCase(relStatus))
			{
				throw new MedicarePayException("This account is already linked.");
			}
			else if (LINK_STATUS_DENY.equalsIgnoreCase(relStatus))
			{
				throw new MedicarePayException("The request to link to this account expired or was already rejected.");
			}
			else if (LINK_STATUS_REMOVE.equalsIgnoreCase(relStatus))
			{
				throw new MedicarePayException("This association is already removed by parent");
			}
			status = medicarePayDaoImpl.updateLinkedAccountStatus(request);
		}
		else
		{
			throw new MedicarePayException("Invalid Request");
		}

		return status;
	}

	/**
	 * Adds a linked bill
	 * 
	 * @param String
	 *            ,MemberPayLinkedBill,String
	 * @return boolean
	 * @exception MedicarePayException
	 */
	private boolean addLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - addLinkedAccount() of MedicarePayServiceImpl");
		GetAccountSummaryResponse getAccSummaryResponse = null;
		GetAccountSummaryRequest req = new GetAccountSummaryRequest();
		String fname = "";
		String lname = "";
		String dob = "";
		String subscriberId = "";
		String billType = "";
		String groupId = "";
		String lineOfBusiness = "";
		String parentFName = "";
		String parentLName = "";
		String requestDob = "";

		req.setHealthCardId(request.getChildHealthCardId());
		BrandEmailMatrix brandEmailMatrix = null;
		List<Future<GetAccountSummaryResponse>> getAccountSummaryResponseList = new ArrayList<>();
		
		try
		{	
			Set<String> hcids = new HashSet<String>();
			hcids.add(request.getHealthCardId());
			hcids.add(request.getChildHealthCardId());

			for(String hcId : hcids){
				GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
				newReq.setHealthCardId(hcId);
				getAccountSummaryResponseList.add(medicarePayGateway.getMemberProfileAsync(newReq));
			}

			for(Future<GetAccountSummaryResponse> futureObj : getAccountSummaryResponseList) {
				getAccSummaryResponse = futureObj.get();
				if (null != getAccSummaryResponse && null != getAccSummaryResponse.getMemberEligibilityList()
						&& getAccSummaryResponse.getMemberEligibilityList().size() > 0)
				{
					MemberEligibility memberEligibility  = aciRestUtils.getProductLevelBillDetails(getAccSummaryResponse.getMemberEligibilityList());
					if (null != memberEligibility && null != memberEligibility.getMemberDemographicDetails())
					{
						if(null != memberEligibility.getHealthCardId() && MedicarePayUtils.checkNullForAString(memberEligibility.getHealthCardId().getSubscriberId())
								&& memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(request.getHealthCardId())){

							if (null != memberEligibility.getMemberDemographicDetails()
									&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
							{
								parentFName = memberEligibility.getMemberDemographicDetails().getFirstName();
							}

							if (null != memberEligibility.getMemberDemographicDetails()
									&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
							{
								parentLName = memberEligibility.getMemberDemographicDetails().getLastName();
							}
						}

						else if(null != memberEligibility.getHealthCardId() && MedicarePayUtils.checkNullForAString(memberEligibility.getHealthCardId().getSubscriberId())
								&& memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(request.getChildHealthCardId())){

							if (null != memberEligibility.getBillDetails() && MedicarePayUtils.checkNullForAString(memberEligibility.getBillDetails().getBillType()))
							{
								billType = memberEligibility.getBillDetails().getBillType();
							}

							if (EMPLOYER_BILL.equalsIgnoreCase(billType))
							{
								throw new MedicarePayException(
										"The account you are attempting to link to is not eligible for account linking. If you have questions, please call the Customer Service number on your ID card.");
							}

							if(null != memberEligibility.getGroupID())
							{
								groupId = memberEligibility.getGroupID();
							}
							if(null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness())
							{
								lineOfBusiness = memberEligibility.getBillDetails().getLineOfBusiness();
							}

							if (null != memberEligibility.getHealthCardId() && MedicarePayUtils.checkNullForAString(memberEligibility.getHealthCardId().getSubscriberId()))
							{
								subscriberId = memberEligibility.getHealthCardId().getSubscriberId();
							}
							if (null != memberEligibility.getMemberDemographicDetails()
									&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
							{
								fname = memberEligibility.getMemberDemographicDetails().getFirstName();
							}

							if (null != memberEligibility.getMemberDemographicDetails()
									&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
							{
								lname = memberEligibility.getMemberDemographicDetails().getLastName();
							}

							if (null != memberEligibility.getMemberDemographicDetails()
									&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getDateOfBirth()))
							{
								dob = memberEligibility.getMemberDemographicDetails().getDateOfBirth().substring(0, 10);
							}
							if(null != request.getDob() && request.getDob().length() == 10){
								requestDob = request.getDob().substring(6, 10)+"-"+request.getDob().substring(0, 2)+"-"+request.getDob().substring(3,5);
							} 

							if (MedicarePayUtils.checkNullForAString(request.getFirstName()) && MedicarePayUtils.checkNullForAString(request.getLastName()) 
									&& MedicarePayUtils.checkNullForAString(requestDob)
									&& (!request.getFirstName().equalsIgnoreCase(fname) || !request.getLastName().equalsIgnoreCase(lname)
											|| !requestDob.equalsIgnoreCase(dob)))
							{
								throw new MedicarePayException(
										"One or more of the values you entered does not match our records.  "
												+ "Please be sure to use the exact name, date of birth and Member ID number as they appear on the member's billing statement.");
							}

							if (groupId.contains(UNICARE) || groupId.contains(AMERIVANTAGE))
							{
								throw new MedicarePayException(
										"The account you are attempting to link to is not eligible for account linking. If you have questions, please call the Customer Service number on your ID card.");
							}

							if(null != lineOfBusiness && !lineOfBusiness.isEmpty()){

								brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(lineOfBusiness, groupId,
										memberEligibility.getClassID(), memberEligibility.getPlanState(), memberEligibility.getPlanID());
							}

						}
					}
				}else{
					throw new MedicarePayException("Sorry, we can't find that member ID number. Can you double check you entered it right? Please note account linking may be limited to certain types of accounts.");
				}
			}
		} catch (Exception e)
		{
			if(e instanceof MedicarePayException){
				MedicarePayException ex = (MedicarePayException)e;
				throw ex;
			}
			getAccSummaryResponse = null;
		}
		if (getAccSummaryResponse == null)
		{
			throw new MedicarePayException("Sorry, we can't find that member ID number. Can you double check you entered it right? Please note account linking may be limited to certain types of accounts.");
		}

		String memberSequenceNumber = "000";
		String mailId = emailUtilHelper.getMailId(subscriberId, memberSequenceNumber, groupId);
		
		String contentId = medicarePayDaoImpl.addLinkedAccount(request);

		UpdatePaperBillServiceResponse updatePaperBillResponse = updatePaperBill(mailId, subscriberId, OPT_IN_PREFERENCE,
				memberSequenceNumber, groupId);
		if (!(STATUS_UPDATE_SUCCESS.equalsIgnoreCase(updatePaperBillResponse.getResultStatus())))
		{
			medicarePayDaoImpl.deleteLinkedAccount(request);
			throw new MedicarePayException("Update paper bill failed");
		}

		try
		{
			if (null != brandEmailMatrix)
			{
				Map<String, Object> model = new HashMap<String, Object>();
				model.put(LINK_CONTENT_KEY, contentId); 
				model.put(LINK_ACTION_URL, actionUrl); 
				model.put("memberName", parentFName + " " + parentLName);
				model.put(LINK_TO_EMAIL, mailId);
				model.put(LINK_LOGGEDIN_HCID, request.getHealthCardId());
				model.put(LINK_TO_HCID, request.getChildHealthCardId());
				model.put("brandEmailMatrix", brandEmailMatrix);
				aciRestUtils.sendMail(model, "ADD_LINK_ACC");
			} /*else {
				medicarePayDaoImpl.deleteLinkedAccount(request);
				LOGGER.error("Unable to determine brandEmailMatrix in addLinkedAccount() of MedicarePayServiceImpl");
				throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
						+ "That member needs to update their email address before you can link accounts.");
			}*/
		} catch (MedicarePayException e)
		{
			medicarePayDaoImpl.deleteLinkedAccount(request);
			throw e;
		}
		LOGGER.info("End - addLinkedAccount() of MedicarePayServiceImpl");
		return true;
	}

	/**
	 * Removes a linked account
	 * 
	 * @param String
	 *            ,MemberPayLinkedBill,String
	 * @return boolean
	 * @exception MedicarePayException
	 */

	private boolean removeLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - removeLinkedAccount() of MedicarePayServiceImpl");
		medicarePayDaoImpl.removeLinkedAccount(request);
		try
		{
			aciRestUtils.removeOneTimePayment(request.getChildHealthCardId(), request.getHealthCardId(), request.getServiceEnv());
			try
			{
				aciRestUtils.constructMailParams(getMemberProfileDataForMail(request.getHealthCardId(), request.getChildHealthCardId()),
						MAIL_TYPE_REMOVE_LINK_ACC);
			} catch (Exception e)
			{
				if (e instanceof MedicarePayException)
				{
					LOGGER.error("Exception occured in removeLinkedAccount() of MedicarePayServiceImpl "
							+ ((MedicarePayException) e).getErrorMessage());
				}
				else
				{
					LOGGER.error("Exception occured in removeLinkedAccount() of MedicarePayServiceImpl " + e.getMessage());
				}
				throw new MedicarePayException(
						"You're trying to remove an account that doesn't have a working email address.Or The member has chosen to not be contacted by email.");
			}
		} catch (MedicarePayException e)
		{
			request.setAction(LINK_ACTION_APPROVE);
			medicarePayDaoImpl.updateLinkedAccountStatus(request);
			LOGGER.error("Exception occured in removeLinkedBill() of MedicarePayServiceImpl " + e.getErrorMessage());
			throw new MedicarePayException(
					"Your request to remove the linked account cannot be performed at this time. Please try again later or contact us at the number on your ID Card.");
		} catch (Exception e)
		{
			throw new MedicarePayException(
					"Your request to remove the linked account cannot be performed at this time. Please try again later or contact us at the number on your ID Card.");
		}
		LOGGER.info("End - removeLinkedAccount() of MedicarePayServiceImpl");
		return true;
	}

	/**
	 * Prepares the i/p parameters necessary to invoke sendMail()
	 * 
	 * @param String
	 *            ,String,String,String
	 * @return void
	 * @exception MedicarePayException
	 */

	private Map<String, Object> getMemberProfileDataForMail(String hcid, String childHcid) throws MedicarePayException
	{
		LOGGER.info("Start - getMemberProfileDataForMail() of MedicarePayServiceImpl");
		Map<String, Object> model = new HashMap<String, Object>();

		GetAccountSummaryResponse getAccSummaryResponse = null;
		String groupId = "";
		String childGroupId = "";
		List<Future<GetAccountSummaryResponse>> getAccountSummaryResponseList = new ArrayList<>();
		
		try
		{
			Set<String> hcids = new HashSet<String>();
			hcids.add(hcid);
			hcids.add(childHcid);
			
			for(String hcId : hcids){
				GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
				newReq.setHealthCardId(hcId);
				getAccountSummaryResponseList.add(medicarePayGateway.getMemberProfileAsync(newReq));
			}
			
			for(Future<GetAccountSummaryResponse> futureObj : getAccountSummaryResponseList) {
				getAccSummaryResponse = futureObj.get();
				if (getAccSummaryResponse == null)
				{
					throw new MedicarePayException("Invalid Hcid");
				}

				if (null != getAccSummaryResponse && null != getAccSummaryResponse.getMemberEligibilityList()
						&& getAccSummaryResponse.getMemberEligibilityList().size() > 0)
				{
					MemberEligibility memberEligibility = aciRestUtils.getProductLevelBillDetails(getAccSummaryResponse.getMemberEligibilityList());
					
						if (null != memberEligibility &&  null != memberEligibility.getHealthCardId() && null != memberEligibility.getHealthCardId().getSubscriberId())
						{
							if(hcids.size() > 1 && memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(childHcid)){
								
								childGroupId = memberEligibility.getGroupID();
								model.put("childGroupId", childGroupId);
								model.put("classId", memberEligibility.getClassID());
								model.put("state", memberEligibility.getPlanState());
								model.put("divisionCode", memberEligibility.getDivisionCode());
								model.put("hcid", hcid);
								model.put("childHcid", childHcid);
								model.put("planId",memberEligibility.getPlanID());
								model.put("lineOfBusiness", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness()) ? memberEligibility.getBillDetails().getLineOfBusiness().toUpperCase() : "");
								
							}else if(memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(hcid)){
								if (null != memberEligibility && null != memberEligibility.getMemberDemographicDetails())
								{
									if (null != memberEligibility.getMemberDemographicDetails()
											&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
									{
										model.put("fname", memberEligibility.getMemberDemographicDetails().getFirstName());
									}

									if (null != memberEligibility.getMemberDemographicDetails()
											&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
									{
										model.put("lname", memberEligibility.getMemberDemographicDetails().getLastName());
									}
								}
								groupId = memberEligibility.getGroupID();
								model.put("groupId", groupId);
								if(hcids.size() == 1){
									model.put("classId", memberEligibility.getClassID());
									model.put("state", memberEligibility.getPlanState());
									model.put("divisionCode", memberEligibility.getDivisionCode());
									model.put("hcid", hcid);
									model.put("childHcid", childHcid);
									model.put("lineOfBusiness", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness()) ? memberEligibility.getBillDetails().getLineOfBusiness().toUpperCase() : "");
									model.put("planId",memberEligibility.getPlanID());
								}
							}
							
							/*PP-14146 start*/
							model.put("productDesc", memberEligibility.getProductDescription());
							model.put("planIdDesc", memberEligibility.getPlanIdDescription());
							model.put("productName", memberEligibility.getProductName());
							model.put("productId", memberEligibility.getProductID());
							model.put("subscriberId", memberEligibility.getHealthCardId().getSubscriberId());
							model.put("groupNumber", memberEligibility.getGroupID());
							model.put("legalEntityCode", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLegalEntityCode()) ? memberEligibility.getBillDetails().getLegalEntityCode() : "");
							model.put("marketSegment", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getMarketSegment()) ? memberEligibility.getBillDetails().getMarketSegment() : "");
							
							if (null != memberEligibility && null != memberEligibility.getMemberDemographicDetails())
							{
								if (null != memberEligibility.getMemberDemographicDetails()
										&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
								{
									model.put("firstName", memberEligibility.getMemberDemographicDetails().getFirstName());
								}

								if (null != memberEligibility.getMemberDemographicDetails()
										&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
								{
									model.put("lastName", memberEligibility.getMemberDemographicDetails().getLastName());
								}
								/* pay mod letter address - starts */
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress());
								}
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress());
								}
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress());
								}
								/* pay mod letter address - ends */
							}
							/*PP-14146 end*/
						}
				}else{
					throw new MedicarePayException("Invalid Hcid");
				}
			}

		} catch (Exception e)
		{
			LOGGER.info("Exception in getMemberProfileDataForMail() of MedicarePayServiceImpl:" + e);
			throw new MedicarePayException("Exception occurred in getMemberProfileDataForMail()");
		}
		LOGGER.info("End - getMemberProfileDataForMail() of MedicarePayServiceImpl");
		return model;
	}
	
	
	
	private Map<String, Object> getMemberProfileDataSubmit(String hcid, String childHcid, String groupIdFilter) throws MedicarePayException
	{
		LOGGER.info("Start - getMemberProfileDataSubmitCancel() of MedicarePayServiceImpl");
		Map<String, Object> model = new HashMap<String, Object>();

		GetAccountSummaryResponse getAccSummaryResponse = null;
		String groupId = "";
		String childGroupId = "";
		List<Future<GetAccountSummaryResponse>> getAccountSummaryResponseList = new ArrayList<>();
		
		try
		{
			Set<String> hcids = new HashSet<String>();
			hcids.add(hcid);
			hcids.add(childHcid);
			
			for(String hcId : hcids){
				GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
				newReq.setHealthCardId(hcId);
				getAccountSummaryResponseList.add(medicarePayGateway.getMemberProfileAsync(newReq));
			}
			
			for(Future<GetAccountSummaryResponse> futureObj : getAccountSummaryResponseList) {
				getAccSummaryResponse = futureObj.get();
				if (getAccSummaryResponse == null)
				{
					throw new MedicarePayException("Invalid Hcid");
				}

				if (null != getAccSummaryResponse && null != getAccSummaryResponse.getMemberEligibilityList()
						&& getAccSummaryResponse.getMemberEligibilityList().size() > 0)
				{
					MemberEligibility memberEligibility = aciRestUtils.getProductLevelBillDetailsForAGroupId(getAccSummaryResponse.getMemberEligibilityList(), groupIdFilter);
					
						if (null != memberEligibility &&  null != memberEligibility.getHealthCardId() && null != memberEligibility.getHealthCardId().getSubscriberId())
						{
							if(hcids.size() > 1 && memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(childHcid)){
								
								childGroupId = memberEligibility.getGroupID();
								model.put("childGroupId", childGroupId);
								model.put("classId", memberEligibility.getClassID());
								model.put("state", memberEligibility.getPlanState());
								model.put("divisionCode", memberEligibility.getDivisionCode());
								model.put("hcid", hcid);
								model.put("childHcid", childHcid);
								model.put("planId",memberEligibility.getPlanID());
								model.put("lineOfBusiness", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness()) ? memberEligibility.getBillDetails().getLineOfBusiness().toUpperCase() : "");
								
							}else if(memberEligibility.getHealthCardId().getSubscriberId().equalsIgnoreCase(hcid)){
								if (null != memberEligibility && null != memberEligibility.getMemberDemographicDetails())
								{
									if (null != memberEligibility.getMemberDemographicDetails()
											&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
									{
										model.put("fname", memberEligibility.getMemberDemographicDetails().getFirstName());
									}

									if (null != memberEligibility.getMemberDemographicDetails()
											&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
									{
										model.put("lname", memberEligibility.getMemberDemographicDetails().getLastName());
									}
								}
								groupId = memberEligibility.getGroupID();
								model.put("groupId", groupId);
								if(hcids.size() == 1){
									model.put("classId", memberEligibility.getClassID());
									model.put("state", memberEligibility.getPlanState());
									model.put("divisionCode", memberEligibility.getDivisionCode());
									model.put("hcid", hcid);
									model.put("childHcid", childHcid);
									model.put("lineOfBusiness", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness()) ? memberEligibility.getBillDetails().getLineOfBusiness().toUpperCase() : "");
									model.put("planId",memberEligibility.getPlanID());
								}
							}
							
							/*PP-14146 start*/
							model.put("productDesc", memberEligibility.getProductDescription());
							model.put("planIdDesc", memberEligibility.getPlanIdDescription());
							model.put("productName", memberEligibility.getProductName());
							model.put("productId", memberEligibility.getProductID());
							model.put("subscriberId", memberEligibility.getHealthCardId().getSubscriberId());
							model.put("groupNumber", memberEligibility.getGroupID());
							model.put("legalEntityCode", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLegalEntityCode()) ? memberEligibility.getBillDetails().getLegalEntityCode() : "");
							model.put("marketSegment", (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getMarketSegment()) ? memberEligibility.getBillDetails().getMarketSegment() : "");
							
							if (null != memberEligibility && null != memberEligibility.getMemberDemographicDetails())
							{
								if (null != memberEligibility.getMemberDemographicDetails()
										&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getFirstName()))
								{
									model.put("firstName", memberEligibility.getMemberDemographicDetails().getFirstName());
								}

								if (null != memberEligibility.getMemberDemographicDetails()
										&& MedicarePayUtils.checkNullForAString(memberEligibility.getMemberDemographicDetails().getLastName()))
								{
									model.put("lastName", memberEligibility.getMemberDemographicDetails().getLastName());
								}
								/* pay mod letter address - starts */
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getHomeAddress());
								}
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getMailingAddress());
								}
								if (null != memberEligibility.getMemberDemographicDetails()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress()
										&& null != memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress().getAddressLineOne()
										&& !memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress().getAddressLineOne().isEmpty())
								{
									model.put("mailingAddress", memberEligibility.getMemberDemographicDetails().getContactInformation().getBillingAddress());
								}
								/* pay mod letter address - ends */
							}
							/*PP-14146 end*/
						}
				}else{
					throw new MedicarePayException("Invalid Hcid");
				}
			}

		} catch (Exception e)
		{
			LOGGER.info("Exception in getMemberProfileDataSubmit() of MedicarePayServiceImpl:" + e);
			throw new MedicarePayException("Exception occurred in getMemberProfileDataSubmit()");
		}
		LOGGER.info("End - getMemberProfileDataSubmit() of MedicarePayServiceImpl");
		return model;
	}

	/**
	 * calls updatePaperBill() of MemberPayGateway
	 * 
	 * @param String
	 *            ,MemberSummary,String,Contract
	 * @return UpdatePaperBillServiceResponse
	 */
	private UpdatePaperBillServiceResponse updatePaperBill(String tomailId, String subscriberId, String preferenceOpt,
			String memberSequenceNumber, String groupId)
	{
		LOGGER.info("Start - updatePaperBill() of MedicarePayServiceImpl");
		UpdatePaperBillServiceRequest updatePaperBillServiceRequest = new UpdatePaperBillServiceRequest();
		updatePaperBillServiceRequest.setSubscriberId(subscriberId);
		updatePaperBillServiceRequest.setMemberSequenceNumber(memberSequenceNumber);
		// SourceSystemId = for STAR,815
		updatePaperBillServiceRequest.setSourceSystemId(SOURCE_SYSTEM_ID);
		// for preference type is 100031 = Premium Notification Consent
		updatePaperBillServiceRequest.setPreferenceType(PREMIUM_NOTIFICATION_CONSENT);
		updatePaperBillServiceRequest.setPreferenceOpt(preferenceOpt);
		// emailtypeCode = 100014 = Email1
		updatePaperBillServiceRequest.setEmailTypeCode(EMAIL_TYPE_CODE);
		updatePaperBillServiceRequest.setEmailAddress(tomailId);
		// check this value 100012 = Consumer/Member Portal (R10)
		updatePaperBillServiceRequest.setSourceChannel(SOURCE_CHANNEL);
		updatePaperBillServiceRequest.setGroupId(groupId);
		return medicarePayGateway.updatePaperBill(updatePaperBillServiceRequest);
	}

	/**
	 * Gets FAQ details for medicare members
	 */
	@Override
	public GetMedicareFaqResponse getMedicareFaq(GetMedicareFaqRequest request) throws MedicarePayException
	{
		GetMedicareFaqResponse response = new GetMedicareFaqResponse();
		List<MedicareFaqDetails> getFaqResponseList = new ArrayList<MedicareFaqDetails>();
		MedicareFaqDetails faqDetails = null;
		try
		{
			if (null != faqFileLocation && !faqFileLocation.isEmpty())
			{
				JSONParser parser = new JSONParser();
				Object object = parser.parse(new FileReader(faqFileLocation));
				if (null != object)
				{
					JSONObject jsonObj = (JSONObject) object;
					JSONArray jsonArray = (JSONArray) jsonObj.get("faqQnAList");

					for (int i = 0; i < jsonArray.size(); i++)
					{
						JSONObject jsonObjectRow = (JSONObject) jsonArray.get(i);
						faqDetails = new MedicareFaqDetails();
						Long faqId = (Long) jsonObjectRow.get("id");
						faqDetails.setFaqId(faqId.intValue());
						JSONObject quesAnsObj = (JSONObject) jsonObjectRow.get("questionAndAnswer");
						MedicareFAQ medicareFAQ = new MedicareFAQ();
						String question = null != quesAnsObj.get("question") ? (String) quesAnsObj.get("question") : "";
						String answer = null != quesAnsObj.get("answer") ? (String) quesAnsObj.get("answer") : "";

						if (!question.isEmpty() && !answer.isEmpty())
						{
							medicareFAQ.setQuestion(question);
							medicareFAQ.setAnswer(answer);
						}
						faqDetails.setMedicareFAQ(medicareFAQ);
						getFaqResponseList.add(faqDetails);
					}
				}
			}
			else
			{
				LOGGER.error("faq location not present");
			}
			response.setMedicareFaqDetails(getFaqResponseList);
		} catch (Exception e)
		{
			LOGGER.error("MedicarePayServiceImpl: Exception while getting FAQ response from json file " + e.getMessage());
		}
		return response;
	}

	private CreditCardDetails setCreditCardDetailsForEdit(MedicarePayPaymentMethod payMethod)
	{
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		if (null != payMethod)
		{
			if (null != payMethod.getBankAccountType())
			{
				if ("VISA".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					creditCardDetails.setCreditCardType(CreditCardType.VISA);
				}
				else if ("MASTERCARD".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					creditCardDetails.setCreditCardType(CreditCardType.MC);
				}
				else if ("MC".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					creditCardDetails.setCreditCardType(CreditCardType.MC);
				}
			}
			creditCardDetails.setAccountNickname(payMethod.getAccNickName());
			creditCardDetails.setTokenId(payMethod.getTokenId());
			creditCardDetails.setCreditCardNumber(payMethod.getMaskedAccountNumber());
			creditCardDetails.setAccountHolderName(MedicarePayUtils.trimCharByLength(payMethod.getAccountName(), 40));
			
			String expString = payMethod.getExpiration();
			String[] expArr = {};
			if (expString != null && !expString.isEmpty())
			{
				expArr = expString.split("/");
			}
			
			creditCardDetails.setExpirationMonth(expArr[0]);
			creditCardDetails.setExpirationYear(expArr[1]);
			if (null != payMethod.getBillingAddress())
			{
				creditCardDetails
						.setAccountAddress1(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getAddressLine1(), 40));
				creditCardDetails
						.setAccountAddress2(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getAddressLine2(), 20));
				creditCardDetails.setAccountCity(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getCity(), 20));
				creditCardDetails.setAccountState(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getState(), 2));
				creditCardDetails
						.setAccountPostalCode(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getPostalCode(), 5));
			}
		}
		return creditCardDetails;
	}

	private BankAccountDetails setBankAccountDetailsForEdit(MedicarePayPaymentMethod payMethod)
	{
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		if (null != payMethod)
		{
			if (null != payMethod.getBankAccountType())
			{
				if ("PERSONALCHECKING".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					bankAccountDetails.setBankAccountType(BankAccountType.PERSONAL_CHECKING);
				}
				else if ("PERSONALSAVINGS".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					bankAccountDetails.setBankAccountType(BankAccountType.PERSONAL_SAVINGS);
				}
				else if ("BUSCHECKING".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					bankAccountDetails.setBankAccountType(BankAccountType.BUSINESS_CHECKING);
				}
				else if ("BUSSAVINGS".equalsIgnoreCase(payMethod.getBankAccountType().name()))
				{
					bankAccountDetails.setBankAccountType(BankAccountType.BUSINESS_SAVINGS);
				}
			}
			bankAccountDetails.setRoutingNumber(payMethod.getRoutingNumber());
			bankAccountDetails.setBankAccountNumber(payMethod.getConfirmAccountNo());
			bankAccountDetails.setAccountNickname(payMethod.getAccNickName());
			bankAccountDetails.setTokenId(payMethod.getTokenId());
			bankAccountDetails.setAccountHolderName(MedicarePayUtils.trimCharByLength(payMethod.getAccountName(), 40));
			if (null != payMethod.getBillingAddress())
			{
				bankAccountDetails.setAccountAddress1(MedicarePayUtils
						.trimCharByLength(payMethod.getBillingAddress().getAddressLine1(), 40));
				bankAccountDetails.setAccountAddress2(MedicarePayUtils
						.trimCharByLength(payMethod.getBillingAddress().getAddressLine2(), 20));
				bankAccountDetails.setAccountCity(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getCity(), 20));
				bankAccountDetails.setAccountState(MedicarePayUtils.trimCharByLength(payMethod.getBillingAddress().getState(), 2));
				bankAccountDetails.setAccountPostalCode(MedicarePayUtils
						.trimCharByLength(payMethod.getBillingAddress().getPostalCode(), 5));
			}
		}
		return bankAccountDetails;
	}

	/**
	 * Validate the member and insert the member details in DB when the member is valid
	 * 
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	private GetAccountSummaryResponse validateMember(String hcid, String sourceSystem) throws MedicarePayException
	{
		GetAccountSummaryResponse getAccSummaryResponse = null;
		boolean memberExists = medicarePayDaoImpl.checkIfMemberExists(hcid, sourceSystem);

		if (!memberExists)
		{
			GetAccountSummaryRequest newReq = new GetAccountSummaryRequest();
			newReq.setHealthCardId(hcid);
			Future<GetAccountSummaryResponse> futureObj = medicarePayGateway.getMemberProfileAsync(newReq);
			try
			{
				getAccSummaryResponse = futureObj.get();
			} catch (Exception e)
			{
				getAccSummaryResponse = null;
			}

			if (null != getAccSummaryResponse && MedicarePayUtils.checkNullForAList(getAccSummaryResponse.getMemberEligibilityList()))
			{
				medicarePayDaoImpl.insertMemberDetails(hcid, sourceSystem);
			}
			else
			{
				throw new MedicarePayException(EXCEPTION, "9001", INVALID_HCID_ERROR_MSG, 500);
			}
		}
		return getAccSummaryResponse;
	}

	@Override
	public GetViewBillResponse getViewBill(GetViewBillRequest getViewBillRequest) throws MedicarePayException
	{
		GetViewBillResponse getViewBillResponse = new GetViewBillResponse();
		try
		{
			getViewBillResponse = medicarePayGateway.getViewBill(getViewBillRequest);
		} catch (Exception e)
		{
			getViewBillResponse.setErrorFlag(true);
			getViewBillResponse.setErrorMessage("PDF not available");
			LOGGER.error("Exception in MedicarePayServiceImpl getViewBill :" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return getViewBillResponse;
	}

	/**
	 * Get auto payment details for the logged in member
	 * 
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public GetAutoPaymentResponse getAutoPayPdfDetails(GetAutoPaymentRequest request) throws MedicarePayException
	{
		GetAutoPaymentResponse response = new GetAutoPaymentResponse();
		List<MedicarePayAutoPay> medicarePayAutoPayList = null;
		try
		{
			GetAccountSummaryResponse getAccSummaryResponse = validateMember(request.getHealthCardId(), request.getServiceEnv());
			if(null == getAccSummaryResponse)
			{
				GetAccountSummaryRequest accSummaryReq = new GetAccountSummaryRequest();
				accSummaryReq.setHealthCardId(request.getHealthCardId());
				Future<GetAccountSummaryResponse> futureObj = medicarePayGateway.getMemberProfileAsync(accSummaryReq);
				GetAccountSummaryResponse accSummaryResponse = null;
				try
				{
					accSummaryResponse = futureObj.get();
				} catch (Exception e)
				{
					LOGGER.error("Exception in MedicarePayServiceImpl getAutoPayPdfDetails getting future object :" + e);
					accSummaryResponse = null;
				}
				getAccSummaryResponse = accSummaryResponse;
			}

			if (null != getAccSummaryResponse && MedicarePayUtils.checkNullForAList(getAccSummaryResponse.getMemberEligibilityList()))
			{
				medicarePayAutoPayList = new ArrayList<>();
				String lineOfBusiness = null;
				List<MemberEligibility> memberEligibilityList = aciRestUtils.getBillDetailsForDiffGrpAutoPay(getAccSummaryResponse.getMemberEligibilityList());

				if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
					for (MemberEligibility memberEligibility : memberEligibilityList)
					{
						MedicarePayAutoPay medicarePayAutoPay = new MedicarePayAutoPay();
						if(null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness()){
							medicarePayAutoPay.setLineOfBusiness(memberEligibility.getBillDetails().getLineOfBusiness());
							lineOfBusiness = memberEligibility.getBillDetails().getLineOfBusiness();
							/*PP-6433 & PP-9107 GA rebranding starts*/
							boolean isFutureDate = MedicarePayUtils.checkForGARebrand(memberEligibility.getPlanState(), memberEligibility.getDateEffective());
							if(isFutureDate){
								if(GA_MS_LOB.equalsIgnoreCase(lineOfBusiness)){
									medicarePayAutoPay.setPdfName(GA_REBRAND_MS_AUTO_PDF);
								}else if(GA_MA_LOB.equalsIgnoreCase(lineOfBusiness)){
									if(MedicarePayUtils.checkNullForAString(memberEligibility.getClassID()) && memberEligibility.getClassID().startsWith(GA_CLASS_ID_LPPO)){
										medicarePayAutoPay.setPdfName(GA_REBRAND_MA_LPPO_AUTO_PDF);
									}else if(MedicarePayUtils.checkNullForAString(memberEligibility.getClassID()) && memberEligibility.getClassID().startsWith(GA_CLASS_ID_HMO)){
										medicarePayAutoPay.setPdfName(GA_REBRAND_MA_HMO_AUTO_PDF);
									}
								}
								if(MedicarePayUtils.checkNullForAString(medicarePayAutoPay.getPdfName())){
									medicarePayAutoPayList.add(medicarePayAutoPay);
								}
							}else{
								BrandEmailMatrix brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(
										lineOfBusiness, memberEligibility.getGroupID(),
										memberEligibility.getClassID(), memberEligibility.getPlanState(),memberEligibility.getPlanID());
								if (null != brandEmailMatrix)
								{
									medicarePayAutoPay.setPdfName(brandEmailMatrix.getAutoPayPdfName());
									medicarePayAutoPayList.add(medicarePayAutoPay);
								}
							}
							/*PP-6433 & PP-9107 GA rebranding ends*/
						}
					}
				}
			}
			else
			{
				throw new MedicarePayException(EXCEPTION, "9001", INVALID_HCID_ERROR_MSG, 500);
			}
			
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedicarePayServiceImpl getAutoPayPdfDetails :" + e);
			throwException(e);
		}
		response.setMedicarePayAutoPayList(medicarePayAutoPayList);
		return response;
	}

	@Override
	public ViewPaymentHistoryResponse getPaymentHistory(ViewPaymentHistoryRequest request) throws MedicarePayException {
		
		
		Set<String> hcidSet = new HashSet<String>();
		ViewPaymentHistoryResponse viewPaymentHistoryResponse = new ViewPaymentHistoryResponse();
		List<Future<ViewPaymentHistoryResponse>> getMemberBillingFutureList = new ArrayList<>();
		MedicarePayMember member = new MedicarePayMember();
		List<MedicarePayLinkedBill> linkedBills = new LinkedList<MedicarePayLinkedBill>();
		member.setHcid(request.getHealthCardId());
		try {
			LOGGER.info("came to viewPaymentHistory--> serviceImp");
			hcidSet = medicarePayDaoImpl.getChildHcids(request.getHealthCardId(), request.getServiceEnv());
			hcidSet.add(request.getHealthCardId());
			for(String hcid : hcidSet){
				ViewPaymentHistoryRequest newReq = new ViewPaymentHistoryRequest();
				newReq.setHealthCardId(hcid);
				getMemberBillingFutureList.add(medicarePayGateway.getEligibilityProfile(newReq));
			}
			for(Future<ViewPaymentHistoryResponse> futResponse :getMemberBillingFutureList) {
				ViewPaymentHistoryResponse viewPaymentHistResponse = futResponse.get();
				if (viewPaymentHistoryResponse != null && viewPaymentHistResponse.getMedicarePayMember() != null && CollectionUtils.isNotEmpty(viewPaymentHistResponse.getMedicarePayMember().getLinkedBills())) {
					List<MedicarePayLinkedBill> receivedLinkedBills = viewPaymentHistResponse.getMedicarePayMember().getLinkedBills();
					
					LOGGER.info(receivedLinkedBills.toString());
					if (MedicarePayUtils.checkNullForAList(receivedLinkedBills)) {
						if (viewPaymentHistResponse.getMedicarePayMember().getHcid().equalsIgnoreCase(request.getHealthCardId())) {
							
							receivedLinkedBills.get(0).setLinkRelationship("self");
						} else {
							
							receivedLinkedBills.get(0).setLinkRelationship("child");
						}
						
						linkedBills.addAll(receivedLinkedBills);
					} else {
						
						LOGGER.error("error received in getting the bills");
						throw new MedicarePayException();
					}
				}
				
			}
			
			member.setLinkedBills(linkedBills);
			viewPaymentHistoryResponse.setMedicarePayMember(member);
		}catch (Exception e) {
			viewPaymentHistoryResponse.setErrorFlag(true);
			viewPaymentHistoryResponse.setErrorMessage("Error In receiving the bills data");
		}
		
		return viewPaymentHistoryResponse;
	
	}
	
	private void throwException(Exception e) throws MedicarePayException {
		if (e instanceof MedicarePayException)
		{
			MedicarePayException ex = (MedicarePayException) e;
			throw ex;
		}
		if (null != e.getCause() && e.getCause() instanceof MessagingException)
		{
			MessagingException mesagingEx = (MessagingException) e.getCause();
			if (null != mesagingEx.getCause() && mesagingEx.getCause() instanceof MedicarePayException)
			{
				MedicarePayException ex = (MedicarePayException) mesagingEx.getCause();
				throw ex;
			}
			else
			{
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
		}
		else
		{
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
	}

	/**
	 * Returns true when update payment method ACI call response is success
	 * @param messageCode
	 * @param messageText
	 * @return
	 * @throws MedicarePayException
	 */
	private boolean checkUpdatePayMethodMessage(String messageCode, String messageText) throws MedicarePayException {
		boolean isUpdatePayMethodSuccess = false;
		if((MedicarePayUtils.checkNullForAString(messageText) && "Success".equalsIgnoreCase(messageText)) ||
				(MedicarePayUtils.checkNullForAString(messageCode) && "1075".equalsIgnoreCase(messageCode))) {
			isUpdatePayMethodSuccess = true;
		}
		return isUpdatePayMethodSuccess;
	}
	
	//PP-14143 start
	/**
	 * Invokes Member profile service
	 * @param hcid
	 * @return
	 * @throws MedicarePayException
	 */
	private List<MemberEligibility> invokeMemberProfile(String hcid) throws MedicarePayException
	{
		GetEligibilityResponse response = null;
		List<MemberEligibility> memberEligibilityList = null;
		try
		{
			GetEligibilityRequest eligiblityRequest = medicarePayUtils.getEligibilityRequestForAccSummary(hcid);
			response = aciRestUtils.invokeMemberProfile(eligiblityRequest);
			if(null != response) {
				memberEligibilityList = response.getMemberEligibilityList();
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedSupServiceImpl invokeMemberProfile : " + e);
			throwException(e);
		}
		return memberEligibilityList;
	}
	
	/**
	 * Checks whether CSR is authorized to the HCID
	 * @param memberEligibilityList
	 * @param csrRoles
	 * @return
	 * @throws MedicarePayException
	 */
	private boolean checkCSREligibility(List<MemberEligibility> memberEligibilityList, List<String> csrRoles) throws MedicarePayException
	{
		boolean isCSREligibile = false;
		try
		{
			if(MedicarePayUtils.checkNullForAList(memberEligibilityList)) {
				for(MemberEligibility memEligibility : memberEligibilityList) {
					if(null != memEligibility && null != memEligibility.getBillDetails() && null != memEligibility.getBillDetails().getLineOfBusiness() && null != csrRoles) {
						if("MA".equalsIgnoreCase(memEligibility.getBillDetails().getLineOfBusiness()) && csrRoles.contains("MACSRSUBMIT")) {
							isCSREligibile = true;
						} else if("MEDSUPP".equalsIgnoreCase(memEligibility.getBillDetails().getLineOfBusiness()) && csrRoles.contains("MSCSRSUBMIT")) {
							isCSREligibile = true;
						}
					}
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MedSupServiceImpl checkCSREligibility : " + e);
			throwException(e);
		}
		return isCSREligibile;
	}
	//PP-14143 end

	/*PP-14146 - start */
	@Override
	public SubmitPaymentResponse payModSubmitPayment(SubmitPaymentRequest request) throws MedicarePayException {

		SubmitPaymentResponse submitPaymentResponse = new SubmitPaymentResponse();
		
		List<PayModSubmitPaymentRequest> payModRequests = new ArrayList<PayModSubmitPaymentRequest>();
		List<PayModSubmitPaymentResponse> resultList = new ArrayList<PayModSubmitPaymentResponse>();
		Map<String, Object> modelMapList = new HashMap<String, Object>();
		
		try{
			
			request.setPaymentDate(MedicarePayUtils.getCorrectedDate(request.getPaymentDate()));
			
			for (MemberPaySubmitPayment oneRequest : request.getMemberpaySubmitPayments())
			{
				oneRequest.setMatchId(MedicarePayUtils.getPayModMatch());
				oneRequest.setConfirmationNumber(null);
				Message returnMessage = new Message();
				returnMessage.setMessageCode("");
				returnMessage.setMessageText("");
				oneRequest.setMessage(returnMessage);
				
				Map<String, Object> modelMap = getMemberProfileDataSubmit(request.getHealthCardId(), request.getHealthCardId(), oneRequest.getPlanID());
				modelMapList.put(oneRequest.getPlanID(), modelMap);
			}
			
			payModRequests = constructPayModSubmitPaymentResponse(request, modelMapList);
			
			resultList = triggerPayModSubmitPayments(payModRequests);
			
			for (MemberPaySubmitPayment oneRequest : request.getMemberpaySubmitPayments())
			{
				for (PayModSubmitPaymentResponse oneResponse : resultList)
				{
					if(oneRequest.getMatchId().equalsIgnoreCase(oneResponse.getMatchId()) && oneResponse.getOrderId() != null && !oneResponse.getOrderId().isEmpty()) {
						Message messageResponse = new Message();
						messageResponse.setMessageText("Success");
						messageResponse.setMessageCode("0");
						oneRequest.setMessage(messageResponse);
						oneRequest.setStatus("Success");
						oneRequest.setConfirmationNumber(oneResponse.getOrderId());
						
						Map<String, Object> modelMap = new HashMap<String, Object>();
						if(null != modelMapList.get(oneRequest.getPlanID())) {
							modelMap = (Map<String, Object>) modelMapList.get(oneRequest.getPlanID());
						}
						
						//PP-15970 - Start
						if(null != request.getCsrEnteredEmailId() && !request.getCsrEnteredEmailId().isEmpty()) {
							SOAMemberProfile sOAMemberProfile = new SOAMemberProfile();
							sOAMemberProfile.setClassId(null != modelMap.get("classId") ? (String) modelMap.get("classId") : "");
							sOAMemberProfile.setLob(null != modelMap.get("lineOfBusiness") ? (String) modelMap.get("lineOfBusiness") : "");
							sOAMemberProfile.setGroupId(null != modelMap.get("groupId") ? (String) modelMap.get("groupId") : "");
							sOAMemberProfile.setState(null != modelMap.get("state") ? (String) modelMap.get("state") : "");
							sOAMemberProfile.setPlanId(null != modelMap.get("planId") ? (String) modelMap.get("planId") : "");
							sOAMemberProfile.setPayAmt(oneRequest.getPaymentAmount());
							sOAMemberProfile.setConfirmationNbr(oneResponse.getOrderId());
							sOAMemberProfile.setPaymentHcid(oneRequest.getChildHealthCardId());
							sOAMemberProfile.setHcid(oneRequest.getChildHealthCardId());
							sOAMemberProfile.setEmailAddr(request.getCsrEnteredEmailId());
							if(request.getCsrId() != null && !request.getCsrId().isEmpty()) {
								sOAMemberProfile.setPayIndicator("CSR");
							} else {
								sOAMemberProfile.setPayIndicator("WEB");
							}
							medicarePayGateway.sendPaymentSMCMail(sOAMemberProfile, SMC_PAYMENT_CONFIRMATION);
						}
						//PP-15970 - End
					}
				}
				if(oneRequest.getMessage() != null && oneRequest.getMessage().getMessageCode().isEmpty()) {
					Message messageResponse = new Message();
					messageResponse.setMessageText("There is a problem processing your payment from this account, please contact your financial institution or use another payment method.");
					messageResponse.setMessageCode("9129");
					oneRequest.setMessage(messageResponse);
					oneRequest.setStatus("Failed");
				}
			}
			
			submitPaymentResponse.setMemberpaySubmitPayments(request.getMemberpaySubmitPayments());
			submitPaymentResponse.setHealthCardId(request.getHealthCardId());
			submitPaymentResponse.setPaymentDate(request.getPaymentDate());
			
			/*if (null != submitPaymentResponse && null != submitPaymentResponse.getMemberpaySubmitPayments() && submitPaymentResponse.getMemberpaySubmitPayments().size() > 0)
			{
				for (MemberPaySubmitPayment memPaySubmitPayment : submitPaymentResponse.getMemberpaySubmitPayments())
				{
					if (null != memPaySubmitPayment && null != memPaySubmitPayment.getMessage()
							&& MedicarePayUtils.checkNullForAString(memPaySubmitPayment.getMessage().getMessageText())
							&& "Success".equalsIgnoreCase(memPaySubmitPayment.getMessage().getMessageText()))
					{
						medicarePayGateway.sendPaySuccessMail(modelMap, memPaySubmitPayment, request.getHealthCardId());
					}
					else
					{	
						try{
							medicarePayGateway.sendFailedPayMail(modelMap);
						}catch(Exception e){
							LOGGER.error("Error while sending mail: Inside submitPayment method");
						}
					}
				}
			}*/
		}
		catch(Exception e){
			LOGGER.error("Exception in MedicarePayServiceImpl submitPayment : " + e);
			throwException(e);
		}
		return submitPaymentResponse;
	}
	
	public List<PayModSubmitPaymentResponse> triggerPayModSubmitPayments(List<PayModSubmitPaymentRequest> request) throws MedicarePayException, InterruptedException, ExecutionException
	{
		LOGGER.debug("Inside MedicarePayServiceImpl-->payModSubmitPayment-->triggerPayModSubmitPayments");
		
		List<Future<PayModSubmitPaymentResponse>> restobjs = new ArrayList<Future<PayModSubmitPaymentResponse>>();
		List<PayModSubmitPaymentResponse> resultList = new ArrayList<PayModSubmitPaymentResponse>();
		
		for (PayModSubmitPaymentRequest oneRequest : request)
		{
			if(oneRequest.getMemberBillingId() != null && !oneRequest.getMemberBillingId().isEmpty()) {
				Future<PayModSubmitPaymentResponse> result = medicarePayGateway.triggerPayModSubmitPayments(oneRequest);
				restobjs.add(result);
			}
		}

		for (Future<PayModSubmitPaymentResponse> eachResponse : restobjs)
		{
			resultList.add(eachResponse.get());
		}
		
		return resultList;
	}

	public List<PayModSubmitPaymentRequest> constructPayModSubmitPaymentResponse(SubmitPaymentRequest request, Map<String, Object> modelMapList) throws MedicarePayException, InterruptedException, ExecutionException
	{
		LOGGER.debug("Inside MedicarePayServiceImpl-->payModSubmitPayment-->constructPayModSubmitPaymentResponse");
		
		List<PayModSubmitPaymentRequest> resultList = new ArrayList<PayModSubmitPaymentRequest>();
		
		for (MemberPaySubmitPayment oneRequest : request.getMemberpaySubmitPayments())
		{
			PayModSubmitPaymentRequest result = constructPayModSubmitPerRequest(oneRequest, request, modelMapList);
			resultList.add(result);
		}
		
		return resultList;
	}
	
	public PayModSubmitPaymentRequest constructPayModSubmitPerRequest(MemberPaySubmitPayment request, SubmitPaymentRequest submitPaymentRequest, Map<String, Object> modelMapList) throws MedicarePayException{

		PayModSubmitPaymentRequest payModRequest = new PayModSubmitPaymentRequest();
		PaymentMethod paymentMethod = new PaymentMethod();
		
		try
		{
			Map<String, Object> modelMap = new HashMap<String, Object>();
			if(null != modelMapList.get(request.getPlanID())) {
				modelMap = (Map<String, Object>) modelMapList.get(request.getPlanID());
			}
			LOGGER.debug("Inside constructPayModSubmitPerRequest");
			String hcid = (String) modelMap.get("subscriberId");
			
			payModRequest.setMatchId(request.getMatchId());
			payModRequest.setAnthemOrderId(MedicarePayUtils.generateOrderId("CSR"));
			
			payModRequest.setAcn(""); 
			payModRequest.setMemberBillingId(hcid);
			payModRequest.setHcid(hcid);
			
			request.setPaymentAmount(MedicarePayUtils.roundUp(request.getPaymentAmount(), 2));
			Double paymentAmountValue = Double.parseDouble(request.getPaymentAmount());
			if(paymentAmountValue <= 0) {
				MedicarePayUtils.setReturnErrorMessage("9176", "The Payment Amount is invalid. Please try again", request);
				return new PayModSubmitPaymentRequest();
			}
			String firstName = "";
			String lastName = "";
			if(modelMap.get("lastName") != null && !modelMap.get("lastName").toString().isEmpty()) {
				lastName = (String) modelMap.get("lastName");
			}
			if(modelMap.get("firstName") != null && !modelMap.get("firstName").toString().isEmpty()) {
				firstName = (String) modelMap.get("firstName");
			}
			
			payModRequest.setSubscrName(lastName + ", " + firstName);
			payModRequest.setMemberBillingName(lastName + ", " + firstName); 
			payModRequest.setProductIdentifier(request.getPlanID()); 
			payModRequest.setSummaryBill(""); 
			if(null != modelMap.get("lineOfBusiness")) {
				if(modelMap.get("lineOfBusiness").toString().equalsIgnoreCase("MEDSUPP")) {
					payModRequest.setGroupName(null != modelMap.get("productDesc") ? modelMap.get("productDesc").toString() : ""); 
				}else {
					payModRequest.setGroupName(null != modelMap.get("planIdDesc") ? modelMap.get("planIdDesc").toString() : "");
				}
			}
			payModRequest.setGroupNumber(null != modelMap.get("groupNumber") ? modelMap.get("groupNumber").toString() : "");
			payModRequest.setSubgroupName(null != modelMap.get("productName") ? modelMap.get("productName").toString() : ""); 
			payModRequest.setSubgroupNumber(null != modelMap.get("productId") ? modelMap.get("productId").toString() : ""); 
			
			MamDetailsBO transactionDvisionBO = new MamDetailsBO();
			AnthemBankDetails anthemBankDetails = new AnthemBankDetails();
			
			String marketSegment = (String) modelMap.get("marketSegment");
			String legalEntityCode = (String) modelMap.get("legalEntityCode");
			String transactionDivisionCode = "";
			try {
				MamDetailsBO mamDetailsBO = new MamDetailsBO();
				mamDetailsBO.setSystem("15");
				mamDetailsBO.setMarketSegment(marketSegment);
				mamDetailsBO.setLegalEntity(legalEntityCode);
				transactionDvisionBO = payModRestUtils.getTransactionDivision(mamDetailsBO);
				if(transactionDvisionBO.getDivisionCode() != null && !transactionDvisionBO.getDivisionCode().isEmpty()) {
					transactionDivisionCode = transactionDvisionBO.getDivisionCode();
				}else if(transactionDvisionBO.getExceptions() != null){
					LOGGER.error("Exception in payModRestUtils.getTransactionDivision inside constructPerPayModSubmitRequest: " + transactionDvisionBO.getExceptions().toString());
				}
			}catch(Exception e) {
				LOGGER.error("Error in payModRestUtils.getTransactionDivision inside constructPerPayModSubmitRequest: " + e);
			}
			if(transactionDivisionCode == null || transactionDivisionCode.isEmpty()) {
				MedicarePayUtils.setReturnErrorMessage("5634", "Transaction Division Code Information not available.", request);
                return new PayModSubmitPaymentRequest();
			}else {
				payModRequest.setDivisionCode("");
				payModRequest.setSystem("15");
				payModRequest.setLegalEntity(legalEntityCode);
				payModRequest.setMarketSegment(marketSegment);
				payModRequest.setTransactionDivisionCode(transactionDivisionCode);
				payModRequest.setMarket(transactionDvisionBO.getMarket());
				anthemBankDetails.setAnthemDepostingBank("chase");
				anthemBankDetails.setBusinessUnit(transactionDvisionBO.getBuId());
				anthemBankDetails.setAnthemBankAccount(transactionDvisionBO.getBankAccountLastDigits());
				anthemBankDetails.setTransactionDivision(transactionDivisionCode);
			}
			
			payModRequest.setSettleAmount(request.getPaymentAmount());
			
			payModRequest.setLob(null != modelMap.get("lineOfBusiness") && modelMap.get("lineOfBusiness").toString().equalsIgnoreCase("MEDSUPP") ? PAY_MOD_MS_LOB : PAY_MOD_MA_LOB);
			
			payModRequest.setThirdPartyId("");
			payModRequest.setThirdPartyName("");
			
			// construct payerId variables
			PayerId payerId = new PayerId();
			if(submitPaymentRequest.getCsrId() != null && !submitPaymentRequest.getCsrId().isEmpty()) {
				payerId.setId(submitPaymentRequest.getCsrId());
				payerId.setType("CSR");
			}else {
				payerId = null;
			}
			payModRequest.setPayerId(payerId);
			
			// construct payment method variables
			if(null != submitPaymentRequest.getBankAccountDetails())
			{
				paymentMethod.setPaymentType("ACH");
				BankAccountDetails bankAccountDetails = submitPaymentRequest.getBankAccountDetails();
				if (bankAccountDetails.getBankAccountType() != null)
				{
					if (bankAccountDetails.getBankAccountType().name().equals("PERSONALCHECKING") || bankAccountDetails.getBankAccountType().name().equals("PERSONAL_CHECKING"))
					{
						paymentMethod.setPaymentSubType("PERSONAL CHECKING");
					}
					else if (bankAccountDetails.getBankAccountType().name().equals("PERSONALSAVINGS") || bankAccountDetails.getBankAccountType().name().equals("PERSONAL_SAVINGS"))
					{
						paymentMethod.setPaymentSubType("PERSONAL SAVINGS");
					}
					else if (bankAccountDetails.getBankAccountType().name().equals("BUSCHECKING") || bankAccountDetails.getBankAccountType().name().equals("BUSINESS_CHECKING"))
					{
						paymentMethod.setPaymentSubType("BUSINESS CHECKING");
					}
					else if (bankAccountDetails.getBankAccountType().name().equals("BUSSAVINGS") || bankAccountDetails.getBankAccountType().name().equals("BUSINESS_SAVINGS"))
					{
						paymentMethod.setPaymentSubType("BUSINESS SAVINGS");
					}
				}
				if(bankAccountDetails == null && bankAccountDetails.getAccountAddress1() == null || bankAccountDetails.getAccountAddress1().isEmpty() || 
						!Pattern.matches("^[a-zA-Z0-9\\s]{0,40}$", bankAccountDetails.getAccountAddress1())) {
					MedicarePayUtils.setReturnErrorMessage("9181", "Invalid Address Information.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getAccountCity() == null || bankAccountDetails.getAccountCity().isEmpty() || 
						!Pattern.matches("^[a-zA-Z\\s]{0,20}$", bankAccountDetails.getAccountCity())) {
					MedicarePayUtils.setReturnErrorMessage("9182", "The city is not valid. Please check the city and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getAccountState() == null || bankAccountDetails.getAccountState().isEmpty() || 
						!Pattern.matches("^[a-zA-Z]{2}$", bankAccountDetails.getAccountState())) {
					MedicarePayUtils.setReturnErrorMessage("9183", "The state is not a valid. Please check the state and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getAccountPostalCode() == null || bankAccountDetails.getAccountPostalCode().isEmpty() || 
						!Pattern.matches("^[0-9]{5}$", bankAccountDetails.getAccountPostalCode())) {
					MedicarePayUtils.setReturnErrorMessage("9184", "The zip code is not valid. Please check the field and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getAccountHolderName() == null || bankAccountDetails.getAccountHolderName().isEmpty() || !Pattern.matches("^[a-zA-Z\\s]{0,40}$", bankAccountDetails.getAccountHolderName())) {
					MedicarePayUtils.setReturnErrorMessage("9179", "The name is not valid.Please check the Account Holder name field and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getRoutingNumber() == null || bankAccountDetails.getRoutingNumber().isEmpty() || 
						!MedicarePayUtils.isRoutingNoValid(bankAccountDetails.getRoutingNumber())) {
					MedicarePayUtils.setReturnErrorMessage("9180", "The Routing Number is not valid.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(bankAccountDetails.getBankAccountNumber() == null || bankAccountDetails.getBankAccountNumber().isEmpty() || 
                        !Pattern.matches("^[0-9]{4,17}$", bankAccountDetails.getBankAccountNumber())) {
					MedicarePayUtils.setReturnErrorMessage("8180", "The Bank Account Number is not valid.", request);
                 return new PayModSubmitPaymentRequest();
				}
				
				paymentMethod.setBankRoutingnumber(bankAccountDetails.getRoutingNumber());
				paymentMethod.setBankAccountNumber(bankAccountDetails.getBankAccountNumber());
				paymentMethod.setNameOnFundingAccount(bankAccountDetails.getAccountHolderName()); 
				FundAccountOwnerFullAddress fundAccountOwnerFullAddress = new FundAccountOwnerFullAddress();
				fundAccountOwnerFullAddress.setAddress1(bankAccountDetails.getAccountAddress1());
				fundAccountOwnerFullAddress.setAddress2(bankAccountDetails.getAccountAddress2());
				fundAccountOwnerFullAddress.setCity(bankAccountDetails.getAccountCity());
				fundAccountOwnerFullAddress.setState(bankAccountDetails.getAccountState());
				fundAccountOwnerFullAddress.setZipcode(bankAccountDetails.getAccountPostalCode());
				paymentMethod.setFundAccountOwnerFullAddress(fundAccountOwnerFullAddress);
				payModRequest.setPaymentMethod(paymentMethod);
				payModRequest.setState(submitPaymentRequest.getBankAccountDetails().getAccountState());
			}else if(null != submitPaymentRequest.getCreditCardDetails())
			{
				paymentMethod.setPaymentType("CC");
				CreditCardDetails creditCardDetails = submitPaymentRequest.getCreditCardDetails();
				if (creditCardDetails.getCreditCardType() != null)
				{
					if (creditCardDetails.getCreditCardType().name().equals("VISA"))
					{
						paymentMethod.setPaymentSubType("VISA");
					}
					else if (creditCardDetails.getCreditCardType().name().equals("MASTERCARD") || creditCardDetails.getCreditCardType().name().equals("MC"))
					{
						paymentMethod.setPaymentSubType("MC");
					}
				}
				if(!MedicarePayUtils.validateCCExpirationString(creditCardDetails.getExpirationMonth() + "/" + creditCardDetails.getExpirationYear())) {
					MedicarePayUtils.setReturnErrorMessage("9177", "You've entered an invalid card expiration date.", request);
					return new PayModSubmitPaymentRequest();
				}
				
				/*to perform the cc token authorization - starts*/
				String encryptedToken = "";
				GetTokenResponse getTokenResponse = new GetTokenResponse();
				String errorCode = "";
				String errorMessage = "";
				
				try {
					GetTokenRequest getTokenRequest = new GetTokenRequest();
					
					String paymentAmount = "0";
					
					if(request.getPaymentAmount() != null) {
						paymentAmount = MedicarePayUtils.roundUp(request.getPaymentAmount(), 2);
						paymentAmount = paymentAmount.replaceAll("\\.", "");
					}
					
					if (creditCardDetails.getCreditCardType().name().equals("VISA"))
					{
						getTokenRequest.setMethodOfPayment("VI");
					}
					else if (creditCardDetails.getCreditCardType().name().equals("MASTERCARD"))
					{
						getTokenRequest.setMethodOfPayment("MC");
					}
					
					getTokenRequest.setAccountNumber(creditCardDetails.getCreditCardNumber());
					getTokenRequest.setExpirationDate(creditCardDetails.getExpirationMonth() + creditCardDetails.getExpirationYear().substring(creditCardDetails.getExpirationYear().length() - 2));
					getTokenRequest.setAmount(paymentAmount);
					getTokenRequest.setIntegrityCheck(creditCardDetails.getIntegrityCheck()); 
					getTokenRequest.setKeyID(creditCardDetails.getKeyID());
					getTokenRequest.setPhaseID(creditCardDetails.getPhaseID());
					getTokenRequest.setCardHolderName(creditCardDetails.getAccountHolderName());
					getTokenRequest.setAddressLine1(creditCardDetails.getAccountAddress1());
					getTokenRequest.setCity(creditCardDetails.getAccountCity());
					getTokenRequest.setState(creditCardDetails.getAccountState());
					getTokenRequest.setPostalCode(creditCardDetails.getAccountPostalCode());
					getTokenRequest.setAnthemOrderId(payModRequest.getAnthemOrderId());
					getTokenRequest.setDivisionCode(payModRequest.getTransactionDivisionCode());
					getTokenRequest.setMessageType("CSTO"); // hard coded for one time functionality
					getTokenRequest.setStoredCredentialFlag("N"); // passing N since not stored pm.
					
					getTokenResponse = payModRestUtils.getTokenForCCAuthorization(getTokenRequest);
					if(getTokenResponse.getEncryptedToken() != null && !getTokenResponse.getEncryptedToken().isEmpty()) {
						encryptedToken = getTokenResponse.getEncryptedToken();
					}else if(getTokenResponse.getExceptions() != null){
						errorCode = getTokenResponse.getExceptions().getCode();
						errorMessage = getTokenResponse.getExceptions().getMessage();
						LOGGER.error("Exception in payModRestUtils.getTokenForCCAuthorization inside constructPerPayModSubmitRequest: " + getTokenResponse.getExceptions().toString());
					}
				}catch(Exception e) {
					LOGGER.error("Error in payModRestUtils.getTokenForCCAuthorization inside constructPerPayModSubmitRequest: " + e);
					errorCode = "0003";
					errorMessage = "There is a problem processing your payment from this account, please contact your financial institution or use another payment method.";
				}
				if(encryptedToken == null || encryptedToken.isEmpty()) {
					MedicarePayUtils.setReturnErrorMessage(errorCode, errorMessage, request);
					return new PayModSubmitPaymentRequest();
				}
				/*to perform the cc token authorization - ends*/
				
				paymentMethod.setCreditCardNumber(encryptedToken);
				paymentMethod.setCreditCardNumberUI(creditCardDetails.getCreditCardNumber());
				paymentMethod.setCreditCardFirstSix(encryptedToken.substring(0,6));
				paymentMethod.setCreditCardLastFour(encryptedToken.substring(encryptedToken.length() - 4));
				paymentMethod.setCcAuthorizationNumber(getTokenResponse.getAuthorizationCode());
				paymentMethod.setIsLevelThree(getTokenResponse.getLevelTInd());
				paymentMethod.setCcExpDate(creditCardDetails.getExpirationMonth() + "/" + creditCardDetails.getExpirationYear());
				paymentMethod.setResponseReasonCode(getTokenResponse.getReasonCode());
				paymentMethod.setTokenDate(getTokenResponse.getTokenPaidDate());
				paymentMethod.setInterchangeQualificationCode("");
				paymentMethod.setActionCode(getTokenResponse.getActionCode());
				paymentMethod.setaVSAAV(getTokenResponse.getAvsaav());
				paymentMethod.setMessageType(getTokenResponse.getMessageType());
				paymentMethod.setStoredCredentialFlag(getTokenResponse.getStoredCredentialFlag());
				paymentMethod.setSubmittedTransactionID(getTokenResponse.getSubmittedTransactionID());
				paymentMethod.setResponseTransactionID(getTokenResponse.getResponseTransactionID());
				
				if(creditCardDetails == null && creditCardDetails.getAccountAddress1() == null || creditCardDetails.getAccountAddress1().isEmpty() || 
						!Pattern.matches("^[a-zA-Z0-9\\s]{0,40}$", creditCardDetails.getAccountAddress1())) {
					MedicarePayUtils.setReturnErrorMessage("9181", "Invalid Address Information.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(creditCardDetails.getAccountCity() == null || creditCardDetails.getAccountCity().isEmpty() || 
						!Pattern.matches("^[a-zA-Z\\s]{0,20}$", creditCardDetails.getAccountCity())) {
					MedicarePayUtils.setReturnErrorMessage("9182", "The city is not valid. Please check the city and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(creditCardDetails.getAccountState() == null || creditCardDetails.getAccountState().isEmpty() || 
						!Pattern.matches("^[a-zA-Z]{2}$", creditCardDetails.getAccountState())) {
					MedicarePayUtils.setReturnErrorMessage("9183", "The state is not a valid. Please check the state and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(creditCardDetails.getAccountPostalCode() == null || creditCardDetails.getAccountPostalCode().isEmpty() || 
						!Pattern.matches("^[0-9]{5}$", creditCardDetails.getAccountPostalCode())) {
					MedicarePayUtils.setReturnErrorMessage("9184", "The zip code is not valid. Please check the field and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				if(creditCardDetails.getAccountHolderName() == null || creditCardDetails.getAccountHolderName().isEmpty() || !Pattern.matches("^[a-zA-Z\\s]{0,40}$", creditCardDetails.getAccountHolderName())) {
					MedicarePayUtils.setReturnErrorMessage("9179", "The name is not valid.Please check the Account Holder name field and try again.", request);
					return new PayModSubmitPaymentRequest();
				}
				paymentMethod.setNameOnFundingAccount(creditCardDetails.getAccountHolderName()); 
				FundAccountOwnerFullAddress fundAccountOwnerFullAddress = new FundAccountOwnerFullAddress();
				fundAccountOwnerFullAddress.setAddress1(creditCardDetails.getAccountAddress1());
				fundAccountOwnerFullAddress.setAddress2(creditCardDetails.getAccountAddress2());
				fundAccountOwnerFullAddress.setCity(creditCardDetails.getAccountCity());
				fundAccountOwnerFullAddress.setState(creditCardDetails.getAccountState());
				fundAccountOwnerFullAddress.setZipcode(creditCardDetails.getAccountPostalCode());
				paymentMethod.setFundAccountOwnerFullAddress(fundAccountOwnerFullAddress);
				payModRequest.setPaymentMethod(paymentMethod);
				payModRequest.setState(submitPaymentRequest.getCreditCardDetails().getAccountState());
			}

			Transaction[] transactions = new Transaction[1];
			Transaction transaction = new Transaction();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.sss");
			DateFormat mmddyyyyFormat = new SimpleDateFormat("MM/dd/yyyy");
			String strDate = dateFormat.format(Calendar.getInstance().getTime());
			transaction.setCreatedDt(strDate);
			transaction.setUpdatedDt(strDate);
			Date paymentDate = MedicarePayUtils.convertStringToDate(submitPaymentRequest.getPaymentDate(), "yyyy-MM-dd");
			Date currentDate = MedicarePayUtils.convertStringToDate(mmddyyyyFormat.format(Calendar.getInstance(Locale.US).getTime()), "MM/dd/yyyy"); 
			if(paymentDate.compareTo(currentDate) < 0)
			{
				MedicarePayUtils.setReturnErrorMessage("9178", "The entered payment date is not valid.", request);
				return new PayModSubmitPaymentRequest();
			}
			transaction.setPaidDate(new SimpleDateFormat("yyyy-MM-dd").format(paymentDate) + " 00:00:00.000");
			if(submitPaymentRequest.getCsrId() != null && !submitPaymentRequest.getCsrId().isEmpty()) {
				transaction.setCsr(true);
				transaction.setCreatedId(submitPaymentRequest.getCsrId());
				transaction.setUpdatedId(submitPaymentRequest.getCsrId());
				transaction.setCheckId("PBP_"+MedicarePayUtils.getDateForString(new Date(), "yyMMdd"));
			}else {
				transaction.setCreatedId(hcid);
				transaction.setUpdatedId(hcid);
			}
			transaction.setPaymentChannel("CSR"); 
			transaction.setPremiumAmount(request.getPaymentAmount());
			transaction.setTransactionStatus("PENDING"); 
			transaction.setTransactionType("PAYMENT"); 
			transaction.setFrequency(""); 
			transaction.setInvoiceNumber(""); 
			transaction.setPaymentConfirmationEmailAddress(""); 
			transaction.setAnthemBankDetails(anthemBankDetails);
			if(null != modelMap.get("planId")) {
				transaction.setPlanId((String) modelMap.get("planId"));
			}
			if(null != modelMap.get("classId")) {
				transaction.setClassId((String) modelMap.get("classId"));
			}
			
			CommunicationDetails communicationDetails = new CommunicationDetails();
			if(submitPaymentRequest.getCsrEnteredEmailId() != null && !submitPaymentRequest.getCsrEnteredEmailId().isEmpty()) {
				communicationDetails.setEmailId(submitPaymentRequest.getCsrEnteredEmailId());
				transaction.setNotificationIndicator("EMAIL");
			}else {
				Address address = (Address) modelMap.get("mailingAddress");
				MailingAddress mailingAddress = dozerMapper.map(address, MailingAddress.class);
				communicationDetails.setMailingAddress(mailingAddress);
				transaction.setNotificationIndicator("LETTER");
			}
			transaction.setCommunicationDetails(communicationDetails);
			transaction.setUpdatedToPsd("N");
			
			List<Note> notes = new ArrayList<Note>();
			Note note = new Note();
			if(submitPaymentRequest.getNotes() != null && !submitPaymentRequest.getNotes().isEmpty()) {
				note.setCsrId(submitPaymentRequest.getCsrId());
				note.setNoteDesc(submitPaymentRequest.getNotes());
				note.setAction("submit");
				notes.add(note);
			}
			transaction.setNotes(notes);
			transaction.setNocReceived("false");
			transactions[0] = transaction;
			payModRequest.setTransactions(transactions);
			
			LOGGER.debug("Ends constructPerPayModSubmitRequest");
		} catch (Exception e)
		{
			LOGGER.error("Error in constructPerPayModSubmitRequest:" + e);
			MedicarePayUtils.setReturnErrorMessage("5638", "Sorry, Unexpected error occured while making payment.", request);
			return new PayModSubmitPaymentRequest();
		}
		
		return payModRequest;
	}
	/*PP-14146 - end */
	
	/*PP-14144 - start */
	@Override
	public CancelPaymentResponse payModCancelPayment(CancelPaymentRequest request) throws MedicarePayException {

		CancelPaymentResponse response = new CancelPaymentResponse();

		if (null != request)
		{
			try
			{
				if (MedicarePayUtils.checkNullForAString(request.getPaymentConfirmationNo()) && request.getPaymentConfirmationNo().trim().length() > 0)
				{
					//Map<String, Object> modelMap = getMemberProfileDataForMail(request.getHealthCardId(), request.getHealthCardId());
					Map<String, Object> modelMap = getMemberDetailsForCancellationEmail(request.getHealthCardId(), request.getLob(), request.getPaymentConfirmationNo());
					PayModCancelPaymentResponse paymodresponse = new PayModCancelPaymentResponse();
					
					PayModCancelPaymentRequest paymodrequest = new PayModCancelPaymentRequest();
					paymodrequest.setOrderId(request.getPaymentConfirmationNo());
					Note notes = new Note();
					if(request.getCsrId() != null && !request.getCsrId().isEmpty()) {
						paymodrequest.setCsrFlag(true);
						paymodrequest.setCancelledBy(request.getCsrId());
						paymodrequest.setPaymentChannel("CSR");
						notes.setCsrId(request.getCsrId());
						notes.setNoteDesc(request.getNotes());
					}else {
						paymodrequest.setCsrFlag(false);
						paymodrequest.setCancelledBy(null);
						paymodrequest.setPaymentChannel("WEB");
						notes.setCsrId(null);
						notes.setNoteDesc(null);
					}
					notes.setAction("cancel");
					paymodrequest.setNotes(notes);
					
					paymodresponse = payModRestUtils.cancelPayModPayment(paymodrequest);
					
					if(null != paymodresponse && paymodresponse.isCancelled()) {
						response.setPaymentCancelStatus(SUCCESS);
						response.setPaymentConfirmationNo(request.getPaymentConfirmationNo());
						
						//PP-15970 - Start
						if(null != paymodresponse.getEmailId() && !paymodresponse.getEmailId().isEmpty()) {
							SOAMemberProfile sOAMemberProfile = new SOAMemberProfile();
							sOAMemberProfile.setClassId(null != modelMap.get("classId") ? (String) modelMap.get("classId") : "");
							sOAMemberProfile.setLob(null != modelMap.get("lineOfBusiness") ? (String) modelMap.get("lineOfBusiness") : "");
							sOAMemberProfile.setGroupId(null != modelMap.get("groupId") ? (String) modelMap.get("groupId") : "");
							sOAMemberProfile.setState(null != modelMap.get("state") ? (String) modelMap.get("state") : "");
							sOAMemberProfile.setPlanId(null != modelMap.get("planId") ? (String) modelMap.get("planId") : "");
							String paymentAmount = "";
							if(null != request.getPaymentAmt()) {
								paymentAmount = MedicarePayUtils.roundUp(request.getPaymentAmt(), 2);
							}
							sOAMemberProfile.setPayAmt(paymentAmount);
							sOAMemberProfile.setConfirmationNbr(request.getPaymentConfirmationNo());
							sOAMemberProfile.setPaymentHcid(request.getHealthCardId());
							sOAMemberProfile.setPaymentHcid(request.getHealthCardId());
							sOAMemberProfile.setHcid(request.getHealthCardId());
							sOAMemberProfile.setEmailAddr(paymodresponse.getEmailId());
							if(request.getCsrId() != null && !request.getCsrId().isEmpty()) {
								sOAMemberProfile.setPayIndicator("CSR");
							} else {
								sOAMemberProfile.setPayIndicator("WEB");
							}
							medicarePayGateway.sendPaymentSMCMail(sOAMemberProfile, SMC_PAYMENT_CANCELLATION);
						}
						//PP-15970 - End
					}else {
						response.setPaymentCancelStatus(CANCELPAYMENT_SERVICE_FAILED);
						Message message = new Message();
						message.setMessageText(paymodresponse.getErrorMessage());
						message.setMessageCode(paymodresponse.getErrorCode());
						response.setMessage(message);
					}
					
					if(paymodresponse.getExceptions() != null){
						LOGGER.error("Exception in payModRestUtils.payModCancelPayment inside payModCancelPayment: " + paymodresponse.getExceptions());
					}
				}
				else
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			} catch (Exception e)
			{
				LOGGER.error("Exception in MedicarePayServiceImpl cancelPayment : " + e);
				throwException(e);
			}
		}
		return response;
	}
	
	
	private Map<String, Object> getMemberDetailsForCancellationEmail(String hcid, String lob, String orderId) throws MedicarePayException{
		
		Map<String, Object> modelMap = new HashMap<String, Object>();
		
		List<PayModSubmitPaymentRequest> payModDocuments = aciRestUtils.searchPayModPayments(hcid, lob);
		
		if(null != payModDocuments) {
			for(PayModSubmitPaymentRequest document: payModDocuments) {
				if(null != document && null != document.getAnthemOrderId() && null != orderId && document.getAnthemOrderId().equalsIgnoreCase(orderId)) {
					modelMap.put("state", document.getState());
					modelMap.put("groupId", document.getProductIdentifier());
					modelMap.put("lineOfBusiness", lob);
					if(null != document.getTransactions()) {
						for(Transaction transaction: document.getTransactions()) {
							modelMap.put("classId", transaction.getClassId());
							modelMap.put("planId", transaction.getPlanId());
							break;
						}
					}
				}
			}
		}
		
		return modelMap;
	}
	/*PP-14144 - end */
	
	//PP-14143 - Start
	/**
	 * Constructs Account Summary Response with Min due, total due, pay now count, bill records count for CSR flow
	 * @param response
	 * @param finalMedicareMemberList
	 * @throws MedicarePayException
	 */
	private void constructCSRSummaryResponse(GetAccountSummaryResponse response, List<MedicareMember> finalMedicareMemberList, GetAccountSummaryRequest request)
			throws MedicarePayException
	{
		int payNowCount = 0;
		int billRecordsCount = 0;
		float totalDue = 0.0f;
		float minDue = 0.0f;
		List<MedicareBillDetails> csrMedicareBillDetails = null;
		if (MedicarePayUtils.checkNullForAList(finalMedicareMemberList))
		{
			for (MedicareMember medicareMember : finalMedicareMemberList)
			{
				if (MedicarePayUtils.checkNullForAList(medicareMember.getMedicareBillDetails()))
				{
					csrMedicareBillDetails = new ArrayList<>();
					for (MedicareBillDetails medicareBillDetail : medicareMember.getMedicareBillDetails())
					{
						if(null != request.getCsrRoles() && ("MA".equalsIgnoreCase(medicareBillDetail.getLineOfBusiness()) && request.getCsrRoles().contains("MACSRSUBMIT")) ||
								("MEDSUPP".equalsIgnoreCase(medicareBillDetail.getLineOfBusiness()) && request.getCsrRoles().contains("MSCSRSUBMIT"))) {
							csrMedicareBillDetails.add(medicareBillDetail);
							billRecordsCount++;
							if ("Pay Now".equalsIgnoreCase(medicareBillDetail.getPaymentStatus()))
							{
								payNowCount++;
								totalDue += medicareBillDetail.getBillNetDue();
								minDue += medicareBillDetail.getBillMinDue();
							}
						}
					}
				}
			}
			if(finalMedicareMemberList.size() > 0) {
				finalMedicareMemberList.get(0).setMedicareBillDetails(csrMedicareBillDetails);
			}
			response.setMedicareMemberList(finalMedicareMemberList);
		}
		response.setPayNowCount(payNowCount);
		response.setTotalAmountDue(totalDue);
		response.setMinDueAmount(minDue);
		response.setTotalBillsAvailableCount(billRecordsCount);
	}
	//PP-14143 - End
	
}