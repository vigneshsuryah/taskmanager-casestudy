/**
 * TranscentraTransformer.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.math.BigInteger;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.eox.medsupp.schema.domain.transcentra.GetDocumentsServiceRequest;
import org.eox.medsupp.schema.domain.transcentra.GetDocumentsServiceResponse;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceRequest;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.eox.medsupp.transcentra.service.GetDocumentsRequest;
import org.eox.medsupp.transcentra.service.GetDocumentsResponse;
import org.eox.medsupp.transcentra.service.SearchDocumentsRequest;
import org.eox.medsupp.transcentra.service.SearchDocumentsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;


@Component
public class TranscentraTransformer implements MedicarePayConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(TranscentraTransformer.class);
	//private static String ACCOUNT_NUMBER = "Account Number";
	private static String GROUP_NUMBER = "Current Group ID";
	private static String TYPE_DATE = "Date";
	private static String TYPE_STRING = "String";
	private static String BILL_DATE = "Billing Date";
	private static String MEMBER_ID = "Member ID";
	private static String GROUP_BILL_ENTITY_ID = "Group Bill Entity";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transformer
	public JAXBElement<?> createSearchDocumentRequest(SearchDocumentsServiceRequest searchDocumentsServiceRequest)
			throws MedicarePayException
	{
		LOGGER.debug("Inside createSearchDocumentRequest");
		SearchDocumentsRequest searchDocumentsRequest = new SearchDocumentsRequest();
		SearchDocumentsRequest.DocumentTypeCode documentTypeCode = new SearchDocumentsRequest.DocumentTypeCode();
		documentTypeCode.setType(searchDocumentsServiceRequest.getDocumentType());
		documentTypeCode.setValue(searchDocumentsServiceRequest.getDocumentValue());
		SearchDocumentsRequest.DocumentTypeCode.SearchFields searchFields = new SearchDocumentsRequest.DocumentTypeCode.SearchFields();
		
		if (MedicarePayUtils.checkNullForAString(searchDocumentsServiceRequest.getAccountNumber())) {
			SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field accountNumberField = new SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field();
			accountNumberField.setName(MEMBER_ID);
			accountNumberField.setType(TYPE_STRING);
			accountNumberField.setValue(searchDocumentsServiceRequest.getAccountNumber());
			searchFields.getField().add(accountNumberField);
		}
		if (MEDSUPP_DOC_VAL.equalsIgnoreCase(searchDocumentsServiceRequest.getDocumentValue()) && MedicarePayUtils.checkNullForAString(searchDocumentsServiceRequest.getProductId()))
		{
			SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field groupNumberField = new SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field();
			groupNumberField.setName(GROUP_NUMBER);
			groupNumberField.setType(TYPE_STRING);
			groupNumberField.setValue(searchDocumentsServiceRequest.getProductId());
			searchFields.getField().add(groupNumberField);
		}
		if (MedicarePayUtils.checkNullForAString(searchDocumentsServiceRequest.getBillGroupId()))
		{
			SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field groupBillEntityId = new SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field();
			groupBillEntityId.setName(GROUP_BILL_ENTITY_ID);
			groupBillEntityId.setType(TYPE_STRING);
			groupBillEntityId.setValue(searchDocumentsServiceRequest.getBillGroupId());
			searchFields.getField().add(groupBillEntityId);
		}
		if (MedicarePayUtils.checkNullForAString(searchDocumentsServiceRequest.getBillDate()))
		{
			SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field billDateField = new SearchDocumentsRequest.DocumentTypeCode.SearchFields.Field();
			billDateField.setName(BILL_DATE);
			billDateField.setType(TYPE_DATE);
			//billDateField.setValue(MedicarePayUtils.addDay(searchDocumentsServiceRequest.getBillDate(), "MM/dd/yyyy", 2));
			billDateField.setValue(searchDocumentsServiceRequest.getBillDate());
			searchFields.getField().add(billDateField);
		}
		documentTypeCode.setSearchFields(searchFields);
		searchDocumentsRequest.setDocumentTypeCode(documentTypeCode);
		LOGGER.debug("Completed createSearchDocumentRequest");
		return new JAXBElement(new QName("http://regulusgroup.com/schema/DIS/T2/2008/01", "searchDocumentsRequest"),
				searchDocumentsRequest.getClass(), null, searchDocumentsRequest);
	}

	@Transformer
	public SearchDocumentsServiceResponse processSearchDocumentsResponse(SearchDocumentsResponse searchDocumentsResponse)
	{
		LOGGER.debug("Inside processSearchDocumentsResponse");
		SearchDocumentsServiceResponse response = new SearchDocumentsServiceResponse();
		BigInteger documentId = null;
		if (searchDocumentsResponse.getDocumentTypeCode().getDocumentList().getItemsFound().signum() != 0)
		{
			documentId = searchDocumentsResponse.getDocumentTypeCode().getDocumentList().getDocument().get(0).getId();
		}
		response.setDocumentId(documentId);
		LOGGER.debug("Completed processSearchDocumentsResponse");
		return response;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transformer
	public JAXBElement<?> createGetDocumentsRequest(GetDocumentsServiceRequest getDocumentsServiceRequest)
	{
		LOGGER.debug("Inside createGetDocumentsRequest");
		GetDocumentsRequest getDocumentsRequest = new GetDocumentsRequest();
		GetDocumentsRequest.DocumentTypeCode docCode = new GetDocumentsRequest.DocumentTypeCode();
		GetDocumentsRequest.DocumentTypeCode.DocumentList documentList = new GetDocumentsRequest.DocumentTypeCode.DocumentList();
		GetDocumentsRequest.DocumentTypeCode.DocumentList.Document document = new GetDocumentsRequest.DocumentTypeCode.DocumentList.Document();
		document.setId(getDocumentsServiceRequest.getDocumentId());
		documentList.getDocument().add(document);
		docCode.setDocumentList(documentList);
		docCode.setType(getDocumentsServiceRequest.getDocumentType());
		docCode.setValue(getDocumentsServiceRequest.getDocumentValue());
		getDocumentsRequest.setDocumentTypeCode(docCode);
		LOGGER.debug("Completed createGetDocumentsRequest");
		return new JAXBElement(new QName("http://regulusgroup.com/schema/DIS/T2/2008/01", "getDocumentsRequest"),
				getDocumentsRequest.getClass(), null, getDocumentsRequest);
	}

	@Transformer
	public GetDocumentsServiceResponse processGetDocumentsResponse(GetDocumentsResponse getDocumentsResponse)
	{
		LOGGER.debug("Inside processGetDocumentsResponse");
		GetDocumentsServiceResponse response = new GetDocumentsServiceResponse();
		response.setDocumentUrl(getDocumentsResponse.getDocumentTypeCode().getLocation().getValue());
		LOGGER.debug("Completed processGetDocumentsResponse");
		return response;
	}
}
