package org.eox.medsupp.jar.payment.paymod.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.jar.payment.util.WebServiceUtils;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

@Component
public class PayModInterceptor implements ClientHttpRequestInterceptor, MedicarePayConstants {

    private final static Logger logger = LoggerFactory.getLogger(PayModInterceptor.class);

    @Autowired
	private WebServiceUtils webServiceUtils;
    
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {

    	TPTServicesLog logRequest= traceRequest(request, body);       
        ClientHttpResponse response = execution.execute(request, body);
        traceResponse(response,logRequest);
        return response;
    } 

    private TPTServicesLog traceRequest(HttpRequest request, byte[] body) throws IOException {
        logger.info("===========================request begin================================================");
        logger.info("URI : " + request.getURI());
        logger.info("Method : " + request.getMethod());
        logger.info("Request Body : " + new String(body, "UTF-8"));
        logger.info("==========================request end================================================");          
        List<String> outgoingRequestId=request.getHeaders().get(CASHAPI_OUT_GOING_ID);
        List<String> operationName = request.getHeaders().get(WS_CONTEXT_OPERATION_NAME);
        request.getHeaders().remove(CASHAPI_OUT_GOING_ID);
        TPTServicesLog tPTServicesLog=null;        
		try {
			tPTServicesLog = webServiceUtils.prepareTptLogRequest(operationName.get(0),outgoingRequestId.get(0),new String(body, "UTF-8"));
		} catch (MedicarePayException e) {
			logger.error("Exception while logging Pay Mod API request:"+e);
		}
       return tPTServicesLog;
    }

    private void traceResponse(ClientHttpResponse response,TPTServicesLog request) {
       
		try {
			 	StringBuilder inputStringBuilder = new StringBuilder();		       
		        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), "UTF-8"));
		        String line = bufferedReader.readLine();
		        while (line != null) {
		            inputStringBuilder.append(line);
		            inputStringBuilder.append('\n');
		            line = bufferedReader.readLine();
		        }
		        if(response.getStatusCode()==HttpStatus.OK){
		        	request.setResponseXml(inputStringBuilder.toString());	
		        }else{
		        	request.setResponseXml("Error Code:"+response.getStatusCode()+":"+inputStringBuilder.toString());	
		        }
			
		} catch (Exception e) {
			request.setResponseXml("Exception while fetching responseXML");
		}
		
		try{
			webServiceUtils.addTptTransactionToLog(request);
		} catch (Exception e) {
			logger.error("Exception while logging Pay Mod API response:"+e);
		}
		
        logger.info("=======================response end=================================================");      
    }

}