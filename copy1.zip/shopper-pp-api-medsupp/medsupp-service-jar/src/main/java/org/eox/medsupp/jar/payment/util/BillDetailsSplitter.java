package org.eox.medsupp.jar.payment.util;


import java.util.List;

import org.eox.medsupp.schema.model.MedicareBillDetails;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;


@Component
public class BillDetailsSplitter
{

	public List<MedicareBillDetails> splitBillDetailsForPdf(List<MedicareBillDetails> memberpayBillAccounts,
			@Header("memberState") String memberState, @Header("hcid") String hcid)
	{
		return memberpayBillAccounts;
	}
}
