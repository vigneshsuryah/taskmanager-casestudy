/**
 * EmailUtilHelper.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/20/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.util.List;

import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.schema.domain.chub.CommComponent;
import org.eox.medsupp.schema.domain.chub.Preference;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.request.GetMbrContactMethodServiceRequest;
import org.eox.medsupp.schema.response.GetMbrContactMethodServiceResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("emailUtilHelper")
public class EmailUtilHelper implements MedicarePayConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtilHelper.class);
	private static final int DEAFULT_LIST_SIZE = 0;

	@Autowired
	private MedicarePayGateway medicarePayGateway;

	public String getMailId(String subscriberId, String memberSequenceNumber, String groupId) throws MedicarePayException
	{
		LOGGER.info("Start - getMailId() of MemberPaymentServiceImpl");
		String mailId = "";
		GetMbrContactMethodServiceResponse getMbrContactMethodServiceResponse = getMbrContact(subscriberId, memberSequenceNumber, groupId);
		CommComponent mailContent = getEmailComponent(getMbrContactMethodServiceResponse);
		if (mailContent == null)
		{
			throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
					+ "That member needs to update their email address before you can link accounts.");
		}
		mailId = mailContent.getEmail().getEmailAddr();
		if (mailId == null || mailId.isEmpty())
		{
			throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
					+ "That member needs to update their email address before you can link accounts.");
		}
		boolean isOpted = false;
		List<org.eox.medsupp.schema.domain.chub.Preference> preferences = mailContent.getPreference();
		if (checkNullForAList(preferences))
		{
			for (org.eox.medsupp.schema.domain.chub.Preference preference : preferences)
			{
				if (MAIL_PREFERENCE_TYPE.equalsIgnoreCase(preference.getPrfrncTyp())
						&& OPT_IN.equalsIgnoreCase(preference.getPrfrncOptDesc()))
				{
					isOpted = true;
					break;
				}
			}
		}
		if (!isOpted)
		{
			throw new MedicarePayException("You can not link to this account. The member has chosen to not be contacted by email.");
		}
		return mailId;
	}

	public GetMbrContactMethodServiceResponse getMbrContact(String subscriberId, String memberSequenceNumber, String groupId)
			throws MedicarePayException
	{
		GetMbrContactMethodServiceRequest getMbrContactMethodServiceRequest = new GetMbrContactMethodServiceRequest();
		getMbrContactMethodServiceRequest.setGroupId(groupId);
		getMbrContactMethodServiceRequest.setSubscriberId(subscriberId);
		getMbrContactMethodServiceRequest.setMemberSequenceNumber(memberSequenceNumber);
		getMbrContactMethodServiceRequest.setSourceSystemId(SOURCE_SYSTEM_ID);
		GetMbrContactMethodServiceResponse getMbrContactMethodServiceResponse = null;
		try
		{
			getMbrContactMethodServiceResponse = medicarePayGateway.getEBillIndicator(getMbrContactMethodServiceRequest);
		} catch (Exception e)
		{
			throw new MedicarePayException("Technical Error.One of the backend service failed");
		}
		return getMbrContactMethodServiceResponse;
	}

	public CommComponent getEmailComponent(GetMbrContactMethodServiceResponse getMbrContactMethodServiceResponse)
			throws MedicarePayException
	{
		if (getMbrContactMethodServiceResponse != null && checkNullForAList(getMbrContactMethodServiceResponse.getCommComponent()))
		{
			for (CommComponent emailComponent : getMbrContactMethodServiceResponse.getCommComponent())
			{
				if (emailComponent.getEmail() != null && EMAIL_TYPE_CODE.equalsIgnoreCase(emailComponent.getEmail().getEmTypCd()))
				{
					return emailComponent;
				}
			}
		}
		return null;
	}

	/**
	 * Checks for null and empty list
	 * 
	 * @param listObject
	 * @return True or False
	 */
	public static Boolean checkNullForAList(List<?> listObject) throws MedicarePayException
	{
		try
		{
			if (listObject != null && listObject.size() > DEAFULT_LIST_SIZE)
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new MedicarePayException(e, "Error in handling the list");
		}
	}

	public boolean checkForEBillFlag(String hcid, String groupId) throws MedicarePayException
	{
		boolean isEbillSigned = Boolean.FALSE;
		try
		{
			GetMbrContactMethodServiceResponse response = getMbrContact(hcid, "000", groupId);
			LOGGER.info("Inside MedicarePayServiceImpl-->checkForEBillFlag");
			Preference preferencesWithEbillDesc = null;

			if (response != null && MedicarePayUtils.checkNullForAList(response.getCommComponent()))
			{
				for (CommComponent commComponent : response.getCommComponent())
				{
					boolean prfrncTypFound = Boolean.FALSE;
					for (Preference preference : commComponent.getPreference())
					{
						if (preference.getPrfrncTyp() != null && preference.getPrfrncTyp().equals(PREMIUM_NOTIFICATION_CONSENT))
						{
							LOGGER.info("FOUND PREMIUM_NOTIFICATION_CONSENT-->");
							preferencesWithEbillDesc = preference;
							prfrncTypFound = Boolean.TRUE;
							break;
						}
					}
					if (prfrncTypFound)
					{
						break;
					}
				}
				if (preferencesWithEbillDesc != null)
				{
					if (preferencesWithEbillDesc.getPrfrncOpt().equals(OPT_IN_PREFERENCE)
							&& preferencesWithEbillDesc.getPrfrncOptDesc().equals(OPT_IN))
					{
						isEbillSigned = Boolean.TRUE;
					}
					else
					{
						isEbillSigned = Boolean.FALSE;
					}
				}
				LOGGER.info("Is Ebill Subscribed-->" + isEbillSigned);
			}
			LOGGER.info("Completed MedicarePayServiceImpl-->checkForEBillFlag");

		} catch (Exception e)
		{
			LOGGER.error("Error in checkForEBillFlag:" + e);
			isEbillSigned = Boolean.FALSE;
		}
		return isEbillSigned;
	}

}
