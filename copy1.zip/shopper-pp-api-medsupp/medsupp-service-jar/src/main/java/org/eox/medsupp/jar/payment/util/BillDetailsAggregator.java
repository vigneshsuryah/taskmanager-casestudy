/**
 * AccountSummaryAggregator.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.util;


import java.util.List;

import org.eox.medsupp.schema.model.MedicareBillDetails;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;


@Component
public class BillDetailsAggregator
{

	public List<MedicareBillDetails> aggregateBillDetailsForPdf(List<MedicareBillDetails> billAccounts,
			@Header("memberState") String memberState, @Header("hcid") String hcid)
	{
		return billAccounts;
	}
}
