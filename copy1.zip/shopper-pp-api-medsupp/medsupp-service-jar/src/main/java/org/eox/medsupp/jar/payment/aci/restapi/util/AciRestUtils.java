/**
 * AciRestUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/05/2019  2.0      Cognizant       CSR - Chase Integration
 * 03/25/2019  1.0      Cognizant       SMC mail changes
 */
package org.eox.medsupp.jar.payment.aci.restapi.util;


import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.eox.medsupp.jar.payment.domain.MedicarePayRequestContext;
import org.eox.medsupp.jar.payment.gateway.MedicarePayGateway;
import org.eox.medsupp.jar.payment.paymod.utility.PayModRestUtils;
import org.eox.medsupp.jar.payment.util.EmailUtil;
import org.eox.medsupp.jar.payment.util.EmailUtilHelper;
import org.eox.medsupp.jar.payment.util.Mail;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.jar.payment.util.RestApiInterceptor;
import org.eox.medsupp.paymod.request.Note;
import org.eox.medsupp.paymod.request.PayModSubmitPaymentRequest;
import org.eox.medsupp.paymod.request.SearchPayModPaymentRequest;
import org.eox.medsupp.paymod.request.Transaction;
import org.eox.medsupp.paymod.response.PayModSubmitPaymentResponse;
import org.eox.medsupp.paymod.response.SearchPayModPaymentResponse;
import org.eox.medsupp.schema.domain.transcentra.GetDocumentsServiceResponse;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceRequest;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.AdditionalPropGrpBO;
import org.eox.medsupp.schema.model.AdditionalPropertiesBO;
import org.eox.medsupp.schema.model.Bill;
import org.eox.medsupp.schema.model.BrandEmailMatrix;
import org.eox.medsupp.schema.model.EventHeader;
import org.eox.medsupp.schema.model.MedicareBillDetails;
import org.eox.medsupp.schema.model.MedicareMember;
import org.eox.medsupp.schema.model.MedicarePayAcctTypeEnum;
import org.eox.medsupp.schema.model.MedicarePayBillAccount;
import org.eox.medsupp.schema.model.MedicarePayLinkedBill;
import org.eox.medsupp.schema.model.MedicarePayMember;
import org.eox.medsupp.schema.model.MedicarePayPayment;
import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;
import org.eox.medsupp.schema.model.MedicarePayPerson;
import org.eox.medsupp.schema.model.Member;
import org.eox.medsupp.schema.model.MemberBillSummary;
import org.eox.medsupp.schema.model.MemberEligibility;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;
import org.eox.medsupp.schema.model.NotificationPreference;
import org.eox.medsupp.schema.model.Payment;
import org.eox.medsupp.schema.model.PropertyBO;
import org.eox.medsupp.schema.model.SOAMemberProfile;
import org.eox.medsupp.schema.request.GetAccountSummaryRequest;
import org.eox.medsupp.schema.request.GetEligibilityRequest;
import org.eox.medsupp.schema.request.GetViewBillRequest;
import org.eox.medsupp.schema.request.MemberBillingSummaryRequest;
import org.eox.medsupp.schema.request.SOASMCEmailRequest;
import org.eox.medsupp.schema.request.ViewPaymentHistoryRequest;
import org.eox.medsupp.schema.response.GetAccountSummaryResponse;
import org.eox.medsupp.schema.response.GetEligibilityResponse;
import org.eox.medsupp.schema.response.GetViewBillResponse;
import org.eox.medsupp.schema.response.MemberBillingSummaryResponse;
import org.eox.medsupp.schema.response.Message;
import org.eox.medsupp.schema.response.SOASMCEmailResponse;
import org.eox.medsupp.schema.response.SubmitPaymentResponse;
import org.eox.medsupp.schema.response.ViewPaymentHistoryResponse;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.hystrix.exception.HystrixTimeoutException;
import com.wellpoint.aci.enums.AciFundingActionType;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentDetail;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.FundingAccount;
import com.wellpoint.aci.response.PaymentAckDetail;


@Component("aciRestUtils")
@RefreshScope
public class AciRestUtils implements MedicarePayConstants
{
	private final static Logger LOGGER = LoggerFactory.getLogger(AciRestUtils.class);
	
	@SuppressWarnings("serial")
	public final static Map<String, String> mailDetailsMap = Collections.unmodifiableMap(new HashMap<String, String>()
	{
		{
			put("ADD_LINK_ACC_MAIL_SUBJECT", "New Linked Account Confirmation - Important Plan Information");
			put("ADD_LINK_ACC_TEMP_LOC", "/emailTemplate/addNewLinkedBillTemplate.vm");
			put("ADD_LINK_ACC_TEMP_ID", ADD_LINK_ACC_TEMP_ID);
			put("REMOVE_LINK_ACC_MAIL_SUBJECT", "Your Online Bill Pay Account has been Unlinked - Important Plan Information");
			put("REMOVE_LINK_ACC_TEMP_LOC", "/emailTemplate/removeLinkedBillTemplate.vm");
			put("REMOVE_LINK_ACC_TEMP_ID", "Your Online Bill Pay Account has been Unlinked - Important Plan Information");
			put("PAYMENT_FAILURE_MAIL_SUBJECT", "There is an Issue with your Payment - Important Plan Information");
			put("PAYMENT_FAILURE_TEMP_LOC", "/emailTemplate/paymentReturned.vm");
			put("PAYMENT_FAILURE_TEMP_ID", "Payment Failure - Important Plan Information");
		}
	});

	@Value("${medicarepay.setting.aci.fundingaccountretrival.endpoint}")
	String aciFundingAccountRetrivalEndpoint;

	@Value("${medicarepay.setting.aci.cancelpayment.endpoint}")
	String aciCancelPaymentEndpoint;

	@Value("${medicarepay.setting.aci.submitpayment.endpoint}")
	String aciSubmitPaymentEndpoint;

	@Value("${medicarepay.setting.aci.searchpayment.endpoint}")
	String aciSearchPaymentEndpoint;
	
	@Value("${medicarepay.setting.billing.endpoint}")
	String billingEndpoint;
	
	@Value("${medicarepay.setting.aci.readtimeout}")
	private int readTimeout;

	@Value("${medicarepay.setting.eligibilityapi.connectiontimeout}")
	private int connectionTimeout;

	@Value("${medicarepay.setting.eligibility.endpoint}")
	String memberProfileEndPoint;

	@Value("${medicarepay.setting.eligibilityapi.apiKey}")
	private String key;
	
	@Value("${medicarepay.setting.eligibilityapi.targetSrc}")
	private String targetSrc;

	@Value("${medicarepay.setting.eligibilityapi.svcEnv}")
	private String svcEnv;
	
	@Value("${medicarepay.setting.soapaysuccessmail.endpoint}")
	private String soaPaySuccessMailEndPoint;
	
	@Value("${medicarepay.setting.soapaysuccessmail.apiKey}")
	private String soaPaySuccessMailApikey;
	
	@Value("${medicarepay.setting.ga.rebranding.effective.overrideInd}")
	private String overrideInd;
	
	@Value("${medicarepay.setting.ga.rebranding.effective.overrideDate}")
	private String overrideDate;
	
	@Autowired
	private MedicarePayUtils medicarePayUtils;

	@Autowired
	private MedicarePayGateway medicarePayGateway;

	@Autowired
	private Mapper dozerMapper;

	@Autowired
	private EmailUtilHelper emailUtilHelper;

	@Autowired
	private RestApiInterceptor restApiInterceptor;
	
	@Autowired
	private EmailUtil emailUtil;
  
	@Autowired
	private PayModRestUtils payModRestUtils;
	
	/**
	 * Invokes ACI service to GET/ADD/EDIT/DELETE payment methods
	 * @param mdsRequestContext
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokePayACIApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public AciFundingResponse invokeManagePaymentMethodACI(MedicarePayRequestContext mdsRequestContext) throws MedicarePayException
	{
		AciFundingResponse response = new AciFundingResponse();
		try
		{
			final AciFundingRequest request = (AciFundingRequest) mdsRequestContext.getRequest();
			HttpEntity<AciFundingRequest> requestEntity = new HttpEntity<AciFundingRequest>(request, getHttpHeaders(mdsRequestContext));
			LOGGER.info("About to send request for getPaymentMethod rest API");

			response = getRestTemplate().postForObject(aciFundingAccountRetrivalEndpoint, requestEntity, AciFundingResponse.class);
			if (null != response.getAciException())
			{
				LOGGER.info("Received error response from getSummary service layer::" + response.getAciException().getErrorMessage());
				String errorMessage = response.getAciException().getErrorMessage();
				if (TECHNICAL_ERROR_MSG.equals(errorMessage))
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in invokeManagePaymentMethodACI::" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return response;
	}

	/**
	 * Returns the Http header params
	 * @param requestContext
	 * @return
	 */
	private MultiValueMap<String, String> getHttpHeaders(MedicarePayRequestContext requestContext)
	{
		LOGGER.info("Above to get HttpHeaders");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		String outGoingId = requestContext.getInputHcid();
		headers.add(OUT_GOING_ID, outGoingId);
		headers.add(META_SENDERAPP, requestContext.getMetaSrcEnv());

		LOGGER.debug(headers.toString());
		LOGGER.info("Got HttpHeaders");
		return headers;
	}

	public MemberBillingSummaryResponse invokeMemberBillsSummaryApiHystrix(MemberBillingSummaryRequest request,Throwable e) {
		MemberBillingSummaryResponse response = new MemberBillingSummaryResponse();
		MedicarePayException exception = new MedicarePayException();
		if (e instanceof HystrixTimeoutException) {
			exception.setErrorMessage("Hystrix timeout for Submit Payment api");
		} else {
			exception.setErrorMessage("Member Billling - " + e.getMessage());
		}
		response.setMedicarePayException(exception);
		return response;
	}
	
  /**
	 * Returns the rest template object for ACI service call
	 * @return
	 */
	public RestTemplate getRestTemplate()
	{
		LOGGER.info("Above to get RestTemplate");
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		converter.setObjectMapper(objMapper);

		List<HttpMessageConverter<?>> convertorList = new ArrayList<HttpMessageConverter<?>>();
		convertorList.add(converter);

		restTemplate.setMessageConverters(convertorList);
		LOGGER.info("Got the RestTemplate");
		return restTemplate;
	}

	/**
	 * Returns clientHttpRequestFactory object
	 * @return
	 */
	private ClientHttpRequestFactory clientHttpRequestFactory()
	{
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setReadTimeout(readTimeout);
		factory.setConnectTimeout(connectionTimeout);
		ClientHttpRequestFactory requestFactory = new BufferingClientHttpRequestFactory(factory);
		return requestFactory;
	}

	public AciFundingResponse getAciFundingResponse(Future<AciFundingResponse> getAciFundingResponse) throws MedicarePayException
	{
		try
		{
			long timeout = 120;
			String summaryCallTimeout = readTimeout + "";
			if (StringUtils.isNotBlank(summaryCallTimeout) && StringUtils.isNumeric(summaryCallTimeout))
			{
				timeout = new Long(summaryCallTimeout);
			}
			AciFundingResponse response = getAciFundingResponse.get(timeout, TimeUnit.SECONDS);
			if (null != response.getAciException())
			{
				LOGGER.info("Received error response from getSummary service layer::" + response.getAciException().getErrorMessage());
				String errorMessage = response.getAciException().getErrorMessage();
				if (TECHNICAL_ERROR_MSG.equals(errorMessage))
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}
			return response;
		} catch (Exception e)
		{
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
	}

	/**
	 * Invokes ACI service to cancel the In-Progress medicare payments
	 * @param mdsRequestContext
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokeCancelPayApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public AciCancelResponse invokeCancelPaymentACI(MedicarePayRequestContext mdsRequestContext) throws MedicarePayException
	{
		AciCancelResponse response = new AciCancelResponse();
		try
		{
			final AciCancelRequest request = (AciCancelRequest) mdsRequestContext.getRequest();
			HttpEntity<AciCancelRequest> requestEntity = new HttpEntity<AciCancelRequest>(request, getHttpHeaders(mdsRequestContext));
			LOGGER.info("About to send request for cancelPayment rest API");

			response = getRestTemplate().postForObject(aciCancelPaymentEndpoint, requestEntity, AciCancelResponse.class);
			if (null != response.getAciException())
			{
				LOGGER.info("Received error response from cancelPayment service layer::" + response.getAciException().getErrorMessage());
				String errorMessage = response.getAciException().getErrorMessage();
				if (TECHNICAL_ERROR_MSG.equals(errorMessage))
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in invokeCancelPaymentACI::" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return response;
	}

	/**
	 * Hystrix fallback method for cancel payment service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public AciCancelResponse invokeCancelPayApiHystrix(MedicarePayRequestContext requestContext, Throwable e)
	{
		AciCancelResponse response = new AciCancelResponse();
		AciException exception = new AciException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Cancel Payment api");
		}
		else
		{
			exception.setErrorMessage("Cancel Payment - " + e.getMessage());
		}
		response.setAciException(exception);
		return response;
	}

	/**
	 * Invokes ACI service to make payment
	 * @param mdsRequestContext
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokeSubmitPaymentApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public SubmitPaymentResponse invokeSubmitPaymentACI(MedicarePayRequestContext mdsRequestContext) throws MedicarePayException
	{
		SubmitPaymentResponse submitPaymentResponse = new SubmitPaymentResponse();
		try
		{
			final AciPaymentRequest request = (AciPaymentRequest) mdsRequestContext.getRequest();
			HttpEntity<AciPaymentRequest> requestEntity = new HttpEntity<AciPaymentRequest>(request, getHttpHeaders(mdsRequestContext));
			LOGGER.info("About to send request for submitPayment rest API");

			AciPaymentResponse response = getRestTemplate()
					.postForObject(aciSubmitPaymentEndpoint, requestEntity, AciPaymentResponse.class);
			if (null != response.getAciException())
			{
				LOGGER.info("Received error response from getSummary service layer::" + response.getAciException().getErrorMessage());
				String errorMessage = response.getAciException().getErrorMessage();
				if (TECHNICAL_ERROR_MSG.equals(errorMessage))
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
				Message message = new Message();

				message.setMessageText(response.getAciException().getErrorMessage());
				message.setMessageCode(response.getAciException().getErrorCode());
				submitPaymentResponse.setMessage(message);
			}
			else
			{
				getSubmitPaymentResponse(response, submitPaymentResponse, mdsRequestContext);
				if (request.getIsForFutureUse() && null != submitPaymentResponse.getTokenID()
						&& submitPaymentResponse.getTokenID().length() > 0)
				{
					submitPaymentResponse.setPaymentMethodSaved(true);
				}
				else
				{
					submitPaymentResponse.setPaymentMethodSaved(false);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in invokeSubmitPaymentACI::" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return submitPaymentResponse;
	}

	/**
	 * Returns submit payment response
	 * @param aciPaymentResponse
	 * @param submitPaymentResponse
	 * @param medRequestContext
	 */
	public void getSubmitPaymentResponse(AciPaymentResponse aciPaymentResponse, SubmitPaymentResponse submitPaymentResponse,
			MedicarePayRequestContext medRequestContext)
	{
		String payDate = null;
		List<MemberPaySubmitPayment> memberpaySubmitPayments = new ArrayList<MemberPaySubmitPayment>();
		List<PaymentAckDetail> paymentAckDetailLst = aciPaymentResponse.getPaymentAckDetails();
		if (null != aciPaymentResponse.getUserId() && aciPaymentResponse.getUserId().equalsIgnoreCase(""))
		{
			submitPaymentResponse.setHealthCardId("");
		}
		else
		{
			submitPaymentResponse.setHealthCardId(aciPaymentResponse.getUserId());
		}
		submitPaymentResponse.setTokenID(aciPaymentResponse.getTokenId());
		if (null == aciPaymentResponse.getResponseMessage())
		{

			int count = 0;
			for (PaymentAckDetail paymentAckDetail : paymentAckDetailLst)
			{
				MemberPaySubmitPayment memberPaySubmitPayment = new MemberPaySubmitPayment();
				if (count == 0 && null != paymentAckDetail.getPaymentDate())
				{
					try
					{
						payDate = medicarePayUtils.splitDateToMMddyyyyFormat(paymentAckDetail.getPaymentDate().trim());
					} catch (Exception e)
					{
						LOGGER.error("Error in processing the payDate::" + e);
					}
					count++;
				}
				if (null != paymentAckDetail.getPaymentSubmissionId() && paymentAckDetail.getPaymentSubmissionId().equalsIgnoreCase(""))
				{
					memberPaySubmitPayment.setChildHealthCardId("");
				}
				else
				{
					memberPaySubmitPayment.setChildHealthCardId(paymentAckDetail.getPaymentSubmissionId());
				}
				memberPaySubmitPayment.setConfirmationNumber(paymentAckDetail.getConfirmationNumber());
				memberPaySubmitPayment.setPaymentAmount(paymentAckDetail.getPaymentAmount());
				if (null != paymentAckDetail.getProductCode())
				{
					memberPaySubmitPayment.setPlanID(paymentAckDetail.getProductCode().trim());
				}
				memberPaySubmitPayment.setStatus(paymentAckDetail.getPaymentStatus());
				if (null != paymentAckDetail.getResponseMessage())
				{
					Message paymentMessage = new Message();
					paymentMessage.setMessageCode(paymentAckDetail.getResponseMessage().getMessageCode());
					paymentMessage.setMessageText(paymentAckDetail.getResponseMessage().getMessageDesc());
					memberPaySubmitPayment.setMessage(paymentMessage);
				}
				memberpaySubmitPayments.add(memberPaySubmitPayment);
			}
			submitPaymentResponse.setPaymentDate(payDate);
			submitPaymentResponse.setMemberpaySubmitPayments(memberpaySubmitPayments);
		}
		else
		{
			Message message = new Message();
			message.setMessageCode(aciPaymentResponse.getResponseMessage().getMessageCode());
			message.setMessageText(aciPaymentResponse.getResponseMessage().getMessageDesc());
			submitPaymentResponse.setMessage(message);
		}
	}

	/**
	 * Hystrix fallback method for Submit payment ACI service call
	 * @param medRequestContext
	 * @param e
	 * @return
	 */
	public SubmitPaymentResponse invokeSubmitPaymentApiHystrix(MedicarePayRequestContext medRequestContext, Throwable e)
	{
		SubmitPaymentResponse response = new SubmitPaymentResponse();
		MedicarePayException exception = new MedicarePayException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Submit Payment api");
		}
		else
		{
			exception.setErrorMessage("Submit Payment - " + e.getMessage());
		}
		response.setMedicarePayException(exception);
		return response;
	}

	/**
	 * Invokes Member Profile service to get member and corresponding bill details
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokeMemberProfileApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public GetEligibilityResponse invokeMemberProfile(GetEligibilityRequest request) throws MedicarePayException
	{
		GetEligibilityResponse eligibilityResponse = new GetEligibilityResponse();
		String memberId = "";
		try
		{
			if (null != request)
			{
				memberId = request.getMemberId();
			}
			HttpEntity<GetEligibilityRequest> requestEntity = new HttpEntity<GetEligibilityRequest>(request, getMemberProfileHttpHeaders(memberId, MEMBER_PROFILE_SERVICE));
			LOGGER.info("About to send request for member profile rest API");
			eligibilityResponse = getMemberProfileRestTemplate().postForObject(memberProfileEndPoint, requestEntity,GetEligibilityResponse.class);
		} catch (Exception e){
			LOGGER.error("Error in invokeMemberProfile::" + e);
			throw new MedicarePayException(EXCEPTION, "9001", INVALID_HCID_ERROR_MSG, 500);
		}
		
		/* Unicare / Amerivantage lineOfBusiness changes - starts */
		if(eligibilityResponse != null && eligibilityResponse.getMemberEligibilityList() != null && eligibilityResponse.getMemberEligibilityList().size() > 0) {
			for(MemberEligibility memberEligibility : eligibilityResponse.getMemberEligibilityList()) {
				if(memberEligibility.getBillDetails() != null) {
					if("Unicare".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness()) || "AmerigroupMS".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness())) {
						memberEligibility.getBillDetails().setLineOfBusiness("MedSupp");
					}
					if("Amerivantage".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness())) {
						memberEligibility.getBillDetails().setLineOfBusiness("MA");
					}
				}
			}
		}
		/* Unicare / Amerivantage lineOfBusiness changes - ends */
		
		return eligibilityResponse;
	}

	/**
	 * Hystrix fallback method for member profile service call
	 * @param medRequestContext
	 * @param e
	 * @return
	 */
	public GetEligibilityResponse invokeMemberProfileApiHystrix(GetEligibilityRequest request, Throwable e)
	{
		GetEligibilityResponse response = new GetEligibilityResponse();
		MedicarePayException exception = new MedicarePayException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Submit Payment api");
		}
		else
		{
			exception.setErrorMessage("Member Profile - " + e.getMessage());
		}
		response.setMedicarePayException(exception);
		return response;
	}

	public ViewPaymentHistoryResponse getMemberEligibilityProfile(ViewPaymentHistoryRequest viewPaymentHistoryRequest) throws MedicarePayException{
		
		LOGGER.info("MemberEligibilityProfile=>Started");
		int count = 0;
		ViewPaymentHistoryResponse viewPaymentHistoryResponse = new ViewPaymentHistoryResponse();
		String hcid = viewPaymentHistoryRequest.getHealthCardId();
		Set<String> groupIds = new HashSet<>();
		GetEligibilityRequest request  = medicarePayUtils.getEligibilityRequest(viewPaymentHistoryRequest.getHealthCardId());
		GetEligibilityResponse response = invokeMemberProfile(request);
		List<MedicarePayLinkedBill> linkedBills = new LinkedList<>();
		MemberBillingSummaryRequest memberSummaryRequest= new MemberBillingSummaryRequest();
		MemberBillingSummaryResponse memberBillingSummaryResponse = new MemberBillingSummaryResponse();
		List<Future<MemberBillingSummaryResponse>> memberBillingSummaryResponses = new LinkedList<>();
		MedicarePayLinkedBill medicarePayLinkedBill = new MedicarePayLinkedBill();
		MedicarePayPerson personDetails = new MedicarePayPerson(); 
		MedicarePayMember medicarePayMember = new MedicarePayMember();
		List<MemberEligibility> memberEligList = new LinkedList<>();
		
		if(null != response && MedicarePayUtils.checkNullForAList(response.getMemberEligibilityList())){
			memberEligList = response.getMemberEligibilityList();
			if(MedicarePayUtils.checkNullForAList(memberEligList)) {
				for(MemberEligibility memberEligibility:memberEligList) {
					personDetails = dozerMapper.map(memberEligibility, MedicarePayPerson.class);
					groupIds.add(memberEligibility.getGroupID());
					medicarePayLinkedBill.setPersonDetails(personDetails);
				}
				
				if (CollectionUtils.isNotEmpty(groupIds)) {
					
					for (String groupId : groupIds) {
						memberSummaryRequest = medicarePayUtils.helpWithHistoryRequest(hcid, groupId);
						memberBillingSummaryResponses.add(medicarePayGateway.callBillSummaryService(memberSummaryRequest));
					}
				}
					List<MedicarePayBillAccount> accounts = new LinkedList<>();
					for (Future<MemberBillingSummaryResponse> future : memberBillingSummaryResponses) {
						MedicarePayLinkedBill linkedBill = new MedicarePayLinkedBill();
						linkedBill.setPersonDetails(medicarePayLinkedBill.getPersonDetails());
						try {
							memberBillingSummaryResponse = future.get();
							if (null!=memberBillingSummaryResponse  && CollectionUtils.isNotEmpty(memberBillingSummaryResponse.getMemberBillSummaryList())) {
								for (MemberBillSummary memSummary : memberBillingSummaryResponse.getMemberBillSummaryList()) {
									if (memSummary != null && CollectionUtils.isNotEmpty(memSummary.getBills())) {
										accounts.addAll(helpWithMapping(memSummary, linkedBill.getPersonDetails().getState())); 
									}
								}
							}
						} catch (Exception e) {
							LOGGER.info("Bills Not Found->exception block");
							viewPaymentHistoryResponse.setErrorMessage("Bills Not Found");
							viewPaymentHistoryResponse.setErrorFlag(true);
						}
					}
					//set accounts
					medicarePayLinkedBill.setBillAccounts(accounts);
					if (MedicarePayUtils.checkNullForAList(accounts)){
							for(MedicarePayBillAccount billAcc : accounts){
								if(billAcc.isPdfBillAvailable()){
									medicarePayLinkedBill.setCanViewPdf(true);
									break;
								}
							}
					}
					if(null!=medicarePayLinkedBill.getBillAccounts() && CollectionUtils.isNotEmpty(medicarePayLinkedBill.getBillAccounts()))
						linkedBills.add(medicarePayLinkedBill);
					else{
						MedicarePayLinkedBill bill = new MedicarePayLinkedBill();
						bill.setPersonDetails(medicarePayLinkedBill.getPersonDetails());
						linkedBills.add(bill);
					}
						
					medicarePayMember.setHcid(request.getMemberId());
					medicarePayMember.setLinkedBills(linkedBills);
					viewPaymentHistoryResponse.setMedicarePayMember(medicarePayMember);
					LOGGER.info("Membereligibilityprofile()-> end");
				
			}
		}
		return viewPaymentHistoryResponse;
	}
	
	
	private List<MedicarePayBillAccount> helpWithMapping(MemberBillSummary memberBillSummary,String state) throws MedicarePayException {
		List<Bill> bills = memberBillSummary.getBills();
		List<MedicarePayBillAccount> billAccounts = new LinkedList<>();
		List<MedicarePayBillAccount> newBillDetails = null;
		
		List<Payment> payments = new LinkedList<>();
		
		try{
			boolean emailOpted = false;
			if (null != memberBillSummary && null != memberBillSummary.getHealthCardId() && emailUtilHelper.checkForEBillFlag(memberBillSummary.getHealthCardId().getSubscriberId(), memberBillSummary.getProductGroupNumber()))
			{
				emailOpted = true;
			}
			for(Bill bill:bills) {
				if (CollectionUtils.isNotEmpty(bill.getPayments()) && null != bill.getPayments()) {
					payments = bill.getPayments();
paymentLoop:			for (Payment payment : payments) {
						MedicarePayPayment medicarePayment = new MedicarePayPayment();
						if(payment!=null && payment.getPaidAmount()!=0){
							medicarePayment.setPaymentAmount(payment.getPaidAmount());
							medicarePayment.setPaymentDate(medicarePayUtils.getDate(payment.getPaidDate()));
							medicarePayment.setPaymentMode(payment.getPaymentMethod());
						}else{
							continue paymentLoop;
						}
						if (MA.equalsIgnoreCase(payment.getLineOfBusiness())) {
							medicarePayment.setLineOfBussiness(ADVANTAGE);
						} else if (MS.equalsIgnoreCase(payment.getLineOfBusiness())) {
							medicarePayment.setLineOfBussiness(SUPPLEMENT);
						}

						if (PAYMENT.equalsIgnoreCase(payment.getPaymentType())) {
							medicarePayment.setPaymentSource(PAYMENT_RESP);
						} else if (REFUND.equalsIgnoreCase(payment.getPaymentType())) {
							medicarePayment.setPaymentSource(REFUND_RESP);
						}
						MedicarePayBillAccount medicarePayBillAccount = new MedicarePayBillAccount();
						medicarePayBillAccount.setMedicarePayment(medicarePayment);
						medicarePayBillAccount.setSubGroupId(bill.getBillGroupId());
						medicarePayBillAccount.setBillType(bill.getBillType());
						medicarePayBillAccount.setGroupId(memberBillSummary.getProductGroupNumber());
						medicarePayBillAccount.setPaymentMethod(memberBillSummary.getStatementId());
						medicarePayBillAccount.setLineOfBusiness(null != payment.getLineOfBusiness() ? payment.getLineOfBusiness().toUpperCase() : "");
						medicarePayBillAccount.setBillProcessedDate(bill.getBillProcessedDate());
						medicarePayBillAccount.setBillGroupId(bill.getBillGroupId());
						medicarePayBillAccount.setProductId(memberBillSummary.getProductGroupNumber());
						medicarePayBillAccount.setBillDate(medicarePayUtils.getDate(bill.getBillProcessedDate()));
						medicarePayBillAccount.setBillFrequency(bill.getBillFrequency() + "");
						medicarePayBillAccount.setBillSource(memberBillSummary.getSourceSystemId());
						medicarePayBillAccount.setDueDate(medicarePayUtils.getDate(bill.getDueDate()));
						medicarePayBillAccount.setMinDue(bill.getMinimumAmountDue());
						medicarePayBillAccount.setTotalDue(bill.getBillNetDue());
						medicarePayBillAccount.setPaidToDate(medicarePayUtils.getDate(bill.getBillToDateOriginal()));
					
						billAccounts.add(medicarePayBillAccount);
					}
				}
			}
			if(emailOpted && billAccounts.size() > 0){
				newBillDetails = medicarePayGateway.findPdfForBillAccounts(billAccounts, state, memberBillSummary.getHealthCardId().getSubscriberId());
			}else{
				newBillDetails = billAccounts;
			}
		} catch (Exception e) {
			LOGGER.error("error in calling getMemberEligibilityService->helpwithmapping");
		
		}
		return newBillDetails;
	}

	@HystrixCommand(fallbackMethod = "invokeMemberBillsSummaryApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public MemberBillingSummaryResponse getBillsSummary(MemberBillingSummaryRequest request) throws MedicarePayException {

		MemberBillingSummaryResponse billingSummaryResponse = new MemberBillingSummaryResponse();
		String memberId = ""; 
		try {
			if(null != request) {
				memberId = request.getMemberId();
			}
			HttpEntity<MemberBillingSummaryRequest> requestEntity = new HttpEntity<MemberBillingSummaryRequest>(request, getMemberProfileHttpHeaders(memberId, MEMBER_BILLING_SERVICE));
			LOGGER.info("About to send request for member billing summary rest API");
			billingSummaryResponse = getMemberProfileRestTemplate().postForObject(billingEndpoint, requestEntity, MemberBillingSummaryResponse.class);
			ObjectMapper mapper = new ObjectMapper();
			LOGGER.info("OBJECT MAPPER RESPONSE FOR BILLING SERVICE ::: "+mapper.writeValueAsString(billingSummaryResponse));
		} catch(Exception e) {
			LOGGER.error("Error in invokeBillingSummary::"+ e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return billingSummaryResponse;
	}
	
  /**
	 * Consolidates the response of Member Profile service response and ACI Search payment service response 
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	public GetAccountSummaryResponse getMemberProfile(GetAccountSummaryRequest request) throws MedicarePayException
	{
		GetAccountSummaryResponse response = new GetAccountSummaryResponse();
		//PP-14143 - Start
		AciPaymentSearchResponse searchResponse = null;
		List<PayModSubmitPaymentRequest> payModRes = null;
		String lob = request.getLob();
		try
		{
			GetEligibilityRequest eligiblityRequest = medicarePayUtils.getEligibilityRequestForAccSummary(request.getHealthCardId());
			GetEligibilityResponse eligibilityResponse = invokeMemberProfile(eligiblityRequest);
			List<MedicareBillDetails> medicareBillList = null;
			if (null != eligibilityResponse && MedicarePayUtils.checkNullForAList(eligibilityResponse.getMemberEligibilityList()))
			{
				Map<String, Object> productStatusMap = new HashMap<>();
				try
				{
					final MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(request.getHealthCardId())
							.metaSrcEnv(request.getServiceEnv());
					AciPaymentSearchRequest aciRequest = (AciPaymentSearchRequest) medicarePayUtils
							.getRequestInstance(AciPaymentSearchRequest.class);
					aciRequest.setHcid(request.getHealthCardId());
					searchResponse = invokeSearchAciPayment(context.requestObj(aciRequest).build());
				} catch (Exception ex)
				{
					LOGGER.error("Error in Payment Search Service - getMemberProfile::" + ex);
				}
				List<MedicareMember> medicareMemberList = new ArrayList<>();
				List<MemberEligibility>  eligibilityList = getBillDetailsForDiffGrp(eligibilityResponse.getMemberEligibilityList());
				for (MemberEligibility memberEligibility : eligibilityList)
				{
					MedicareMember medicareMember = dozerMapper.map(memberEligibility, MedicareMember.class);
					if(null != memberEligibility.getDateEffective() && null != memberEligibility.getCoverageStatusCode()){
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
						Date effectiveDate = MedicarePayUtils.getDateByString(memberEligibility.getDateEffective(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
						Date currentDate = MedicarePayUtils.getDateByString(simpleDateFormat.format(new Date()), "yyyy-MM-dd'T'HH:mm:ss'Z'");

						if (((effectiveDate.after(currentDate) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())) || 
								"EXPIRED".equalsIgnoreCase(memberEligibility.getCoverageStatusCode()) || "PENDING".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())) &&
								null != memberEligibility.getBillDetails() && memberEligibility.getBillDetails().getBillNetDue() <= 0){
							medicareMember.getMedicareBillDetails().clear();
						} 
					}
					if (null != memberEligibility.getBillDetails() && 
							!("MA".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness()) || "MEDSUPP".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness())))
					{
						medicareMember.getMedicareBillDetails().clear();
					} else if (null != memberEligibility.getBillDetails() && 
							("MA".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness()) || "MEDSUPP".equalsIgnoreCase(memberEligibility.getBillDetails().getLineOfBusiness())))
					{
						if(!MedicarePayUtils.checkNullForAString(lob)) {
							lob = memberEligibility.getBillDetails().getLineOfBusiness();
						}
					}
					
					if (MedicarePayUtils.checkNullForAList(medicareMemberList))
					{
						medicareBillList = medicareMemberList.get(0).getMedicareBillDetails();
						if (null != medicareBillList)
						{
							medicareBillList.addAll(medicareMember.getMedicareBillDetails());
							medicareMemberList.get(0).setState(medicareMember.getState());
							
							medicareMember.setMedicareBillDetails(medicareBillList);
							medicareMemberList.clear();
							medicareMemberList.add(medicareMember);
						}
					}
					else
					{
						medicareMemberList.add(medicareMember);
						/*PP-6430 GA rebranding starts*/
						if(null!=overrideInd && !overrideInd.isEmpty() && "Y".equalsIgnoreCase(overrideInd)){
							if(null!=overrideDate && !overrideDate.isEmpty())
								medicareMemberList.get(0).setEffectiveDate(overrideDate);
							else
								medicareMemberList.get(0).setEffectiveDate(medicareMember.getEffectiveDate());
						}else{
							medicareMemberList.get(0).setEffectiveDate(medicareMember.getEffectiveDate());
						}
						/*PP-6430 GA rebranding ends*/
					}
				}
				try
				{
					if(null != lob && ("MEDSUPP".equalsIgnoreCase(lob) || "MA".equalsIgnoreCase(lob) || "MEDADV".equalsIgnoreCase(lob)|| "MADV".equalsIgnoreCase(lob)||"MSUP".equalsIgnoreCase(lob))) {
						//get Chase payments
						payModRes = searchPayModPayments(request.getHealthCardId(), lob);
					}
					
					getPendingAndScheduledProducts(searchResponse.getAciPaymentDetails(), new Date(), productStatusMap, payModRes, request.getCsrId());
				} catch (Exception ex)
				{
					LOGGER.error("Error in PayMod Payment Search Service - getMemberProfile::" + ex);
				}
				constructMedicareBillDetails(productStatusMap, medicareMemberList, request.getCsrId());
				//PP-14143 - End
				response.setMedicareMemberList(medicareMemberList);
			}
			if (null != eligibilityResponse.getMessage())
			{
				response.setMessage(eligibilityResponse.getMessage());
			}

		} catch (Exception e)
		{
			LOGGER.error("Exception in AciRestUtils getMemberProfile : " + e);
			if( e instanceof MedicarePayException){
				MedicarePayException ex = (MedicarePayException) e;
				if("9001".equalsIgnoreCase(ex.getErrorCode())){
					response = new GetAccountSummaryResponse();
				}else{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}else{
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
			
		}
		return response;
	}

	//PP-14143 - Start
	/**
	 * Constructs Mediacre member Bill details
	 * @param productStatusMap
	 * @param medicareMemberList
	 * @throws MedicarePayException
	 */
	@SuppressWarnings("unchecked")
	private void constructMedicareBillDetails(Map<String, Object> productStatusMap, List<MedicareMember> medicareMemberList, String csrId)
			throws MedicarePayException
	{
		LOGGER.info("Inside AciRestUtils-->constructMedicareBillDetails - Start");
		if (MedicarePayUtils.checkNullForAList(medicareMemberList))
		{
			for (MedicareMember medicareMember : medicareMemberList)
			{
				if (MedicarePayUtils.checkNullForAList(medicareMember.getMedicareBillDetails()))
				{
					if (emailUtilHelper.checkForEBillFlag(medicareMember.getHealthCardId(), medicareMember.getMedicareBillDetails().get(0)
							.getGroupId()))
					{
						List<MedicareBillDetails> newBillDetails = medicarePayGateway.findPdfAvailabilityForBillAccounts(
								medicareMember.getMedicareBillDetails(), medicareMember.getState(), medicareMember.getHealthCardId());
						if (MedicarePayUtils.checkNullForAList(newBillDetails))
						{
							medicareMember.setMedicareBillDetails(newBillDetails);
						}
					}
					List<String> pendingProducts = (List<String>) productStatusMap.get(ACI_PAYMENT_PENDING_STATUS);
					List<String> scheduledProducts = (List<String>) productStatusMap.get(ACI_PAYMENT_SCHEDULED_STATUS);
					for (MedicareBillDetails medicareBillDetail : medicareMember.getMedicareBillDetails())
					{
						if(null != medicareBillDetail.getLineOfBusiness() && "MA".equalsIgnoreCase(medicareBillDetail.getLineOfBusiness())){
							medicareBillDetail.setProductDescription(medicareBillDetail.getPlanIdDescription());
						}
						if(null != medicareBillDetail.getBillDueDate()){
							medicareBillDetail.setBillDueDate(MedicarePayUtils.formatInputDate(medicareBillDetail.getBillDueDate()));
						}
						
						if(null != medicareBillDetail.getBillProcessedDate()){
							medicareBillDetail.setBillProcessedDate(MedicarePayUtils.formatInputDate(medicareBillDetail.getBillProcessedDate()));
						}
						
						BrandEmailMatrix brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(medicareBillDetail.getLineOfBusiness(),
								medicareBillDetail.getGroupId(), medicareBillDetail.getClassId(), medicareMember.getState(),medicareBillDetail.getPlanId());
						if (null != brandEmailMatrix && null != brandEmailMatrix.getBrandAbbr())
						{
							medicareMember.setBrand(brandEmailMatrix.getBrandAbbr());
						}
						medicareBillDetail.setBrandEmailMatrix(brandEmailMatrix);
						if (medicareBillDetail.getBillMinDue() == 0)
						{
							medicareBillDetail.setBillMinDue(medicareBillDetail.getBillNetDue());
						}
						String paymentProgress = pendingProducts != null ? pendingProducts.contains(medicareBillDetail.getGroupId()) ? YES_STR
								: NO_STR
								: NO_STR;
						String schedulePaymentProgress = scheduledProducts != null ? scheduledProducts.contains(medicareBillDetail
								.getGroupId()) ? YES_STR : NO_STR : NO_STR;
						if (YES_STR.equalsIgnoreCase(paymentProgress))
						{
							medicareBillDetail.setPaymentStatus("Payment in process");
							List<MedicarePayPayment> medicarePayList = (List<MedicarePayPayment>) productStatusMap.get(medicareBillDetail.getGroupId());
							if(null != medicarePayList && medicarePayList.size() > 0) {
								sortMemberPayments(medicarePayList);
							}
							if(null != csrId && !csrId.isEmpty()) {
								//send all payments
								medicareBillDetail.setMedicarePayPayments(medicarePayList);
								medicareBillDetail.setMedicarePayPayment(null);
							} else {
								//send only one payment
								if(null != medicarePayList && medicarePayList.size() > 0) {
									medicareBillDetail.setMedicarePayPayment(medicarePayList.get(0));
									medicareBillDetail.setPaymentStatus(getPayStatus(medicarePayList.get(0)));
									medicareBillDetail.setMedicarePayPayments(null);
								}
							}
						}
						else if (YES_STR.equalsIgnoreCase(schedulePaymentProgress))
						{
							medicareBillDetail.setPaymentStatus("Future payment Scheduled");
							List<MedicarePayPayment> medicarePayList = (List<MedicarePayPayment>) productStatusMap.get(medicareBillDetail.getGroupId());
							if(null != medicarePayList) {
								sortMemberPayments(medicarePayList);
							}
							if(null != csrId && !csrId.isEmpty()) {
								//send all payments
								medicareBillDetail.setMedicarePayPayments(medicarePayList);
								medicareBillDetail.setMedicarePayPayment(null);
							} else {
								//send only one payment
								if(null != medicarePayList && medicarePayList.size() > 0) {
									medicareBillDetail.setMedicarePayPayment(medicarePayList.get(0));
									medicareBillDetail.setPaymentStatus(getPayStatus(medicarePayList.get(0)));
									medicareBillDetail.setMedicarePayPayments(null);
								}
							}
						}
						else if ("EFT".equalsIgnoreCase(medicareBillDetail.getPaymentMethod()))
						{
							medicareBillDetail.setPaymentStatus("Automatic monthly withdrawals are on");
							medicareBillDetail.setShowToolTip(true);
							medicareBillDetail
									.setToolTipDescription("Our records show you are currently on an automatic recurring payment option where your premiums are automatically debited from your chosen account. If you want to make changes to your Payment Method, contact Customer Service at the number on the back of your ID card.");
						}
						else if (medicareBillDetail.getBillNetDue() != 0
								&& !"EFT".equalsIgnoreCase(medicareBillDetail.getPaymentMethod())
								&& (medicareBillDetail.getPrimaryMemberHcid() == null || medicareBillDetail.getPrimaryMemberHcid().isEmpty()|| medicareBillDetail.getPrimaryMemberHcid()
										.equalsIgnoreCase(medicareMember.getHealthCardId())))
						{
							medicareBillDetail.setPaymentStatus("Pay Now");
						}
						else if (medicareBillDetail.getBillNetDue() == 0 && "SSA".equalsIgnoreCase(medicareBillDetail.getPaymentMethod()))
						{
							medicareBillDetail.setPaymentStatus("Enrolled in SSA");
							medicareBillDetail.setShowToolTip(true);
							medicareBillDetail
									.setToolTipDescription("If you want to make changes to your Payment Method, contact Customer Service at the number on the back of your ID card.");
						}
						else if (medicareBillDetail.getBillNetDue() == 0 && "RRB".equalsIgnoreCase(medicareBillDetail.getPaymentMethod()))
						{
							medicareBillDetail.setPaymentStatus("Enrolled in RRB");
							medicareBillDetail.setShowToolTip(true);
							medicareBillDetail
									.setToolTipDescription("If you want to make changes to your Payment Method, contact Customer Service at the number on the back of your ID card.");
						}
						else if (medicareBillDetail.getBillNetDue() == 0 && !"EFT".equalsIgnoreCase(medicareBillDetail.getPaymentMethod())
								&& "Paid In Full".equalsIgnoreCase(medicareBillDetail.getPaidStatus()))
						{
							medicareBillDetail.setPaymentStatus("Paid In Full");
						}
						if (MedicarePayUtils.checkNullForAString(medicareBillDetail.getPrimaryMemberHcid())
								&& !medicareBillDetail.getPrimaryMemberHcid().equalsIgnoreCase(medicareMember.getHealthCardId()))
						{
							medicareBillDetail.setPaymentStatus("Two Party Bill");
							medicareBillDetail.setShowToolTip(true);
							medicareBillDetail.setToolTipDescription("Submit payment under primary subscriber ID");
						}

					}
				}
			}
		}
		LOGGER.info("Inside AciRestUtils-->constructMedicareBillDetails - End");
	}
	//PP-14143 - End

	/**
	 * Invokes Member Profile service in async
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	public GetAccountSummaryResponse getMemberProfileAsync(GetAccountSummaryRequest request) throws MedicarePayException
	{
		GetAccountSummaryResponse response = new GetAccountSummaryResponse();
		try
		{
			GetEligibilityRequest eligiblityRequest = medicarePayUtils.getEligibilityRequestForAccSummary(request.getHealthCardId());
			GetEligibilityResponse eligibilityResponse = invokeMemberProfile(eligiblityRequest);
			if (null != eligibilityResponse && MedicarePayUtils.checkNullForAList(eligibilityResponse.getMemberEligibilityList()))
			{
				response.setMemberEligibilityList(eligibilityResponse.getMemberEligibilityList());
			}
			if (null != eligibilityResponse.getMessage())
			{
				response.setMessage(eligibilityResponse.getMessage());
			}

		} catch (Exception e)
		{
			LOGGER.error("Exception in AciRestUtils getMemberProfileAsync : " + e);
			response = new GetAccountSummaryResponse();
		}
		return response;
	}

	/**
	 * Invokes ACI Service to get payment details 
	 * @param mdsRequestContext
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokeSearchAciPaymentHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public AciPaymentSearchResponse invokeSearchAciPayment(MedicarePayRequestContext mdsRequestContext) throws MedicarePayException
	{
		AciPaymentSearchResponse response = new AciPaymentSearchResponse();
		try
		{
			final AciPaymentSearchRequest request = (AciPaymentSearchRequest) mdsRequestContext.getRequest();
			HttpEntity<AciPaymentSearchRequest> requestEntity = new HttpEntity<AciPaymentSearchRequest>(request,
					getHttpHeaders(mdsRequestContext));
			LOGGER.info("About to send request for searchPayment rest API");

			response = getRestTemplate().postForObject(aciSearchPaymentEndpoint, requestEntity, AciPaymentSearchResponse.class);
			if (null != response.getAciException())
			{
				LOGGER.info("Received error response from searchPayment service layer::" + response.getAciException().getErrorMessage());
				String errorMessage = response.getAciException().getErrorMessage();
				if (TECHNICAL_ERROR_MSG.equals(errorMessage))
				{
					throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in invokeSearchAciPayment::" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return response;
	}

	/**
	 * Hystrix fallback method for search payment ACI service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public AciPaymentSearchResponse invokeSearchAciPaymentHystrix(MedicarePayRequestContext requestContext, Throwable e)
	{
		AciPaymentSearchResponse response = new AciPaymentSearchResponse();
		AciException exception = new AciException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Cancel Payment api");
		}
		else
		{
			exception.setErrorMessage("Search Payment - " + e.getMessage());
		}
		response.setAciException(exception);
		return response;
	}

	//PP-14143 - Start
	/**
	 * Returns pending and Scheduled products details
	 * @param paymentInfos
	 * @param date
	 * @param productStatusMap
	 * @return
	 * @throws MedicarePayException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getPendingAndScheduledProducts(List<AciPaymentDetail> paymentInfos, Date date,
			Map<String, Object> productStatusMap, List<PayModSubmitPaymentRequest> payModRes, String csrId) throws MedicarePayException
	{
		try
		{
			LOGGER.info("Inside AciRestUtils-->getPendingAndScheduledProducts");
			List<String> pendingProducts = new ArrayList<String>();
			List<String> scheduledProducts = new ArrayList<String>();
			List<MedicarePayPayment> aciPayList = null;
			List<MedicarePayPayment> chasePayList = null;
			if (MedicarePayUtils.checkNullForAList(paymentInfos))
			{
				for (AciPaymentDetail paymentInfo : paymentInfos)
				{
					if (ACI_PAYMENT_PENDING_STATUS.equals(paymentInfo.getPaymentStatus()))
					{
						String productId = null != paymentInfo.getRemittanceDetail() ? paymentInfo.getRemittanceDetail().getProductId() : "";
						if (!MedicarePayUtils.getDateByString(paymentInfo.getPaymentDate(), DATE_FORMAT_yyyyMMdd).after(date))
						{
							pendingProducts.add(productId);
						}
						else if (MedicarePayUtils.getDateByString(paymentInfo.getPaymentDate(), DATE_FORMAT_yyyyMMdd).after(date))
						{
							scheduledProducts.add(productId);
						}
						if(null != productStatusMap && null != productStatusMap.get(productId)) {
							aciPayList = (List<MedicarePayPayment>) productStatusMap.get(productId);
						} else {
							aciPayList = new ArrayList<MedicarePayPayment>();
						}
						aciPayList.add(preparePaymentDetails(paymentInfo));
						productStatusMap.put(productId, aciPayList);
					}
				}
			}

			if (MedicarePayUtils.checkNullForAList(payModRes))
			{
				for(PayModSubmitPaymentRequest paymentInfo : payModRes)
				{
					if(null != paymentInfo && null != paymentInfo.getTransactions() && paymentInfo.getTransactions().length > 0) {
						for(Transaction transaction : paymentInfo.getTransactions()) {
							if(TRAN_TYPE_PAYMENT.equalsIgnoreCase(transaction.getTransactionType()) && (Arrays.asList(PAY_MOD_TRAN_STATUS).contains(transaction.getTransactionStatus()))) {
								String productId = paymentInfo.getProductIdentifier();
								if (!MedicarePayUtils.getDateByString(transaction.getPaidDate(), DATE_FORMAT_yyyyMMdd).after(date))
								{
									pendingProducts.add(productId);
								}
								else if (MedicarePayUtils.getDateByString(transaction.getPaidDate(), DATE_FORMAT_yyyyMMdd).after(date))
								{
									scheduledProducts.add(productId);
								}
								if(null != productStatusMap && null != productStatusMap.get(productId)) {
									chasePayList = (List<MedicarePayPayment>) productStatusMap.get(productId);
								} else {
									chasePayList = new ArrayList<MedicarePayPayment>();
								}
								chasePayList.add(prepareChasePaymentDetails(paymentInfo, transaction, csrId));
								productStatusMap.put(productId, chasePayList);
							}
						}
					}
				}
			}
			
			productStatusMap.put(ACI_PAYMENT_PENDING_STATUS, pendingProducts);
			productStatusMap.put(ACI_PAYMENT_SCHEDULED_STATUS, scheduledProducts);
			LOGGER.info("Completed AciRestUtils-->getPendingAndScheduledProducts");
			return productStatusMap;
		} catch (Exception e)
		{
			LOGGER.error("Error in getPendingAndScheduledProducts:" + e);
			throw new MedicarePayException(e, "Exception in getPendingAndScheduledProducts");
		}
	}
	//PP-14143 - End

	/**
	 * Returns payment details
	 * @param paymentInfo
	 * @return
	 */
	private MedicarePayPayment preparePaymentDetails(AciPaymentDetail paymentInfo)
	{
		LOGGER.info("Inside AciRestUtils-->preparePaymentDetails");
		MedicarePayPayment memberPayPayment = new MedicarePayPayment();
		MedicarePayPaymentMethod paymentMethod = new MedicarePayPaymentMethod();
		if (null != paymentInfo)
		{
			memberPayPayment.setPaymentAmount(Float.valueOf(paymentInfo.getPaymentAmount()));
			memberPayPayment.setPaymentDate(MedicarePayUtils.getDateByString(paymentInfo.getPaymentDate(), DATE_FORMAT_yyyyMMdd));
			memberPayPayment.setPaymentTrackingNo(paymentInfo.getPaymentConfirmationNo());
			if(null != paymentInfo.getFundingAccount()) {
				paymentMethod.setMaskedAccountNumber(paymentInfo.getFundingAccount().getMaskedAccountNo());
				if (paymentInfo.getFundingAccount().getFundingAccountType() != null)
				{
					paymentMethod.setBankAccountType(setAccountType(paymentInfo.getFundingAccount().getFundingAccountType()));
				}
				if (paymentInfo.getFundingAccount().getAccountNickname() != null)
				{
					paymentMethod.setAccNickName(paymentInfo.getFundingAccount().getAccountNickname());
				}
				paymentMethod.setTokenId(paymentInfo.getFundingAccount().getTokenId());
			}
			memberPayPayment.setPaymentMethod(paymentMethod);
		}
		LOGGER.info("Completed AciRestUtils-->preparePaymentDetails");
		return memberPayPayment;

	}

	//PP-14143 - Start
	/**
	 * Sets Account type value
	 * @param accountType
	 * @return
	 */
	private MedicarePayAcctTypeEnum setAccountType(String accountType)
	{
		if (null != accountType && (accountType.equals("PERSONAL_CHECKING") || accountType.equals("PERSONAL CHECKING")))
		{
			return MedicarePayAcctTypeEnum.PERSONALCHECKING;
		}
		else if (null != accountType && (accountType.equals("PERSONAL_SAVINGS") || accountType.equals("PERSONAL SAVINGS")))
		{
			return MedicarePayAcctTypeEnum.PERSONALSAVINGS;
		}
		else if (null != accountType && (accountType.equals("BUSINESS_CHECKING") || accountType.equals("BUSINESS CHECKING")))
		{
			return MedicarePayAcctTypeEnum.BUSCHECKING;
		}
		else if (null != accountType && (accountType.equals("BUSINESS_SAVINGS") || accountType.equals("BUSINESS SAVINGS")))
		{
			return MedicarePayAcctTypeEnum.BUSSAVINGS;
		}
		else if (null != accountType && accountType.equals("VISA"))
		{
			return MedicarePayAcctTypeEnum.VISA;
		}
		else if (null != accountType && accountType.equals("MC"))
		{
			return MedicarePayAcctTypeEnum.MASTERCARD;
		}
		else if (null != accountType && accountType.equals("MASTERCARD"))
		{
			return MedicarePayAcctTypeEnum.MASTERCARD;
		}
		else
		{
			return MedicarePayAcctTypeEnum.NONE;
		}
	}
	//PP-14143 - End

	/**
	 * Retrieves token id associated with hcid
	 * 
	 * @param String
	 * @return Set<String>
	 * @exception MedicarePayException
	 */

	private Set<String> getTokenId(String hcid, String sourceSystem) throws MedicarePayException
	{
		LOGGER.info("Start - getTokenId() of AciRestUtils");
		try
		{
			final MedicarePayRequestContext.Builder contextBuilder = new MedicarePayRequestContext.Builder(hcid).metaSrcEnv(sourceSystem);
			AciFundingRequest aciRequest = (AciFundingRequest) medicarePayUtils.getRequestInstance(AciFundingRequest.class);
			aciRequest.setHcid(hcid);
			aciRequest.setFundingRequestActionType(AciFundingActionType.GETSUM);

			final AciFundingResponse aciResponse = invokeManagePaymentMethodACI(contextBuilder.requestObj(aciRequest).build());
			Set<String> tokenIds = new HashSet<String>();
			if (null != aciResponse)
			{
				List<CreditCardDetails> creditCardDetails = aciResponse.getCreditCardDetails();
				if (MedicarePayUtils.checkNullForAList(creditCardDetails))
				{
					for (CreditCardDetails paymentMethod : creditCardDetails)
					{
						tokenIds.add(paymentMethod.getTokenId());
					}
				}
				List<BankAccountDetails> bankAcctList = aciResponse.getBankAccountDetails();
				if (MedicarePayUtils.checkNullForAList(bankAcctList))
				{
					for (BankAccountDetails paymentMethod : bankAcctList)
					{
						tokenIds.add(paymentMethod.getTokenId());
					}
				}
			}
			LOGGER.info("End - getTokenId() of AciRestUtils");
			return tokenIds;
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in getTokenId() of AciRestUtils " + e.getMessage());
			throw new MedicarePayException("Exception occured while retriveing funding id" + e.getMessage());
		}

	}

	/**
	 * Retrieves pending confirmation id associated with hcid
	 * 
	 * @param String
	 * @return Set<String>
	 * @exception MedicarePayException
	 */
	private Set<String> getPendingConfirmationNumber(String hcid, String sourceSystem, Set<String> tokenIds) throws MedicarePayException
	{
		LOGGER.info("Start - getPendingConfirmationNumber() of AciRestUtils");
		try
		{
			final MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(hcid).metaSrcEnv(sourceSystem);
			AciPaymentSearchRequest aciRequest = (AciPaymentSearchRequest) medicarePayUtils
					.getRequestInstance(AciPaymentSearchRequest.class);
			aciRequest.setHcid(hcid);
			AciPaymentSearchResponse searchResponse = invokeSearchAciPayment(context.requestObj(aciRequest).build());
			Set<String> pendingConfirmationIds = new HashSet<String>();
			if (null != searchResponse && MedicarePayUtils.checkNullForAList(searchResponse.getAciPaymentDetails()))
			{
				for (AciPaymentDetail paymentInfo : searchResponse.getAciPaymentDetails())
				{
					if (ACI_PAYMENT_PENDING_STATUS.equalsIgnoreCase(paymentInfo.getPaymentStatus()))
					{
						FundingAccount fundingAccount = paymentInfo.getFundingAccount();
						String fundingTokenId = fundingAccount.getTokenId();
						if (null != fundingTokenId && tokenIds.contains(fundingTokenId))
						{
							pendingConfirmationIds.add(paymentInfo.getPaymentConfirmationNo());
						}
					}
				}
			}
			LOGGER.info("End - getPendingConfirmationNumber() of AciRestUtils");
			return pendingConfirmationIds;
		} catch (MedicarePayException e)
		{
			LOGGER.error("Exception occured in getPendingConfirmationNumber() of AciRestUtils " + e.getErrorMessage());
			throw e;
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in getPendingConfirmationNumber() of AciRestUtils " + e.getMessage());
			throw new MedicarePayException("Exception occured while retrieving pending confirmation id" + e.getMessage());
		}
	}

	/**
	 * Removes one time payment
	 * 
	 * @param String
	 *            ,String
	 * @return boolean
	 * @exception MemberPayException
	 */

	public boolean removeOneTimePayment(String hcid, String parentHcid, String sourceSystem) throws MedicarePayException
	{
		LOGGER.info("Start - removeOneTimePayment() of AciRestUtils");
		try
		{
			Set<String> tokenIds = getTokenId(parentHcid, sourceSystem);
			if (null != tokenIds && !tokenIds.isEmpty())
			{
				Set<String> pendingConfirmationIds = getPendingConfirmationNumber(hcid, sourceSystem, tokenIds);
				if (null != pendingConfirmationIds && !pendingConfirmationIds.isEmpty())
				{
					if (cancelPayment(pendingConfirmationIds, sourceSystem))
					{
						return true;
					}
				}
			}
			LOGGER.info("End - removeOneTimePayment() of AciRestUtils");
			return true;
		} catch (Exception e)
		{
			if (e instanceof MedicarePayException)
			{
				LOGGER.error("Exception occured while removing one time payment " + ((MedicarePayException) e).getErrorMessage());
			}
			else
			{
				LOGGER.error("Exception occured while removing one time payment " + e.getMessage());
			}
			throw new MedicarePayException("unable to remove one time payment for the linked account");
		}
	}

	/**
	 * cancels one time payment
	 * 
	 * @param Set
	 *            <String>
	 * @return boolean
	 * @exception MedicarePayException
	 */

	private boolean cancelPayment(Set<String> pendingConfirmationIds, String sourceSystem) throws MedicarePayException
	{
		LOGGER.info("Start - cancelPayment() of AciRestUtils");
		try
		{
			for (String pendingConfirmationId : pendingConfirmationIds)
			{
				MedicarePayRequestContext.Builder context = new MedicarePayRequestContext.Builder(pendingConfirmationId)
						.metaSrcEnv(sourceSystem);
				AciCancelRequest aciRequest = (AciCancelRequest) medicarePayUtils.getRequestInstance(AciCancelRequest.class);
				aciRequest.setPaymentConfirmationNo(pendingConfirmationId);
				invokeCancelPaymentACI(context.requestObj(aciRequest).build());
			}
			LOGGER.info("End - cancelPayment() of MemberPaymentServiceImpl");
			return true;
		} catch (Exception e)
		{
			LOGGER.error("Exception occured in cancelPayment() of AciRestUtils " + e.getMessage());
			throw new MedicarePayException("Exception occured while cancelling payments" + e.getMessage());
		}
	}

	/**
	 * Constructs and returns request params for Transcentra search document service
	 * @param billAccount
	 * @param memberState
	 * @param hcid
	 * @return
	 * @throws MedicarePayException
	 */
	public SearchDocumentsServiceResponse findPdfSource(MedicareBillDetails billAccount, @Header("memberState") String memberState, @Header("hcid") String hcid)
	    throws MedicarePayException
	{
	  LOGGER.info("Inside AciRestUtils-->findPdfSource");
	  SearchDocumentsServiceRequest searchDocumentsServiceRequest = new SearchDocumentsServiceRequest();
	  searchDocumentsServiceRequest.setBillDate(MedicarePayUtils.formatBillDate(billAccount.getBillProcessedDate(), "MM/dd/yyyy", "yyyy-MM-dd"));
	  searchDocumentsServiceRequest.setDocumentType(TRAN_DOC_TYPE);
	  
	  if (LOB_MA.equalsIgnoreCase(billAccount.getLineOfBusiness()))
	  {
	    searchDocumentsServiceRequest.setDocumentValue(MA_DOC_VAL);
	  }
	  else if (LOB_MEDSUPP.equalsIgnoreCase(billAccount.getLineOfBusiness()))
	  {
	    searchDocumentsServiceRequest.setDocumentValue(MEDSUPP_DOC_VAL);
	  }
	  if (MedicarePayUtils.checkNullForAString(billAccount.getBillType())
	      && "FAMILY".equalsIgnoreCase(billAccount.getBillType()))
	  {
	    searchDocumentsServiceRequest.setBillGroupId(billAccount.getBillGroupId());
	  }else{
	    searchDocumentsServiceRequest.setBillGroupId(null);
	    searchDocumentsServiceRequest.setProductId(billAccount.getGroupId());
	    searchDocumentsServiceRequest.setAccountNumber(hcid);
	  }
	  SearchDocumentsServiceResponse searchDocumentsServiceResponse = medicarePayGateway.searchTranscentraBill(searchDocumentsServiceRequest);
	  LOGGER.info("Completed AciRestUtils-->findPdfSource");
	  return searchDocumentsServiceResponse;
	}

	/**
	 * Checks for VA Coupon member and Invokes Transcentra search document service to find whether bill exists
	 * @param billAccount
	 * @param memberState
	 * @param hcid
	 * @return
	 * @throws MedicarePayException
	 */
	@Transformer
	public List<MedicareBillDetails> findPdfAvailabiltyForBillAccount(MedicareBillDetails billAccount,
			@Header("memberState") String memberState, @Header("hcid") String hcid) throws MedicarePayException
	{
		LOGGER.info("Inside AciRestUtils-->findPdfAvailabiltyForBillAccount");
		List<MedicareBillDetails> memberPayBillAccounts = new ArrayList<MedicareBillDetails>();
		try
		{
			if (checkForVACouponMember(billAccount, memberState))
			{
				Object response = medicarePayGateway.findPdfAvailabilityForSingleBill(billAccount, memberState, hcid);
				if (null != response && response instanceof SearchDocumentsServiceResponse)
				{
					SearchDocumentsServiceResponse searchDocumentsServiceResponse = (SearchDocumentsServiceResponse) response;
					if (null != searchDocumentsServiceResponse && null != searchDocumentsServiceResponse.getDocumentId())
					{
						billAccount.setPdfAvailable(true);
					}
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in findPdfAvailabiltyForBillAccount:" + e);
		}
		memberPayBillAccounts.add(billAccount);
		LOGGER.info("Completed AciRestUtils-->findPdfAvailabiltyForBillAccount");
		return memberPayBillAccounts;
	}

	/**
	 * Returns Rest Template object for invoking member profile service
	 * @return
	 */
	public RestTemplate getMemberProfileRestTemplate()
	{
		LOGGER.info("About to get getMemberProfileRestTemplate");
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>(1);
		clientHttpRequestInterceptors.add(restApiInterceptor);
		restTemplate.setInterceptors(clientHttpRequestInterceptors);
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		converter.setObjectMapper(objMapper);

		List<HttpMessageConverter<?>> convertorList = new ArrayList<HttpMessageConverter<?>>();
		convertorList.add(converter);

		restTemplate.setMessageConverters(convertorList);
		LOGGER.info("Got the getMemberProfileRestTemplate");
		return restTemplate;
	}

	/**
	 * Returns Http Headers for invoking member profile service
	 * @param memberId
	 * @param api
	 * @return
	 */
	private HttpHeaders getMemberProfileHttpHeaders(String memberId, String api)
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(APIKEY, key);
		headers.add(META_TARGET_SRC,targetSrc);
		headers.add(META_SRC_ENV, svcEnv);
		headers.add(OUT_GOING_ID, memberId);
		headers.add(OUT_OPERATION, api);
		headers.add(META_SENDERAPP, "MEDSUPP");

		return headers;
	}
	
	
  /**
	 * Invokes Transcentra search and get documents services to get pdf url 
	 * @param request
	 * @return
	 * @throws MedicarePayException
	 */
	@HystrixCommand(fallbackMethod = "invokeTranscentraApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public GetViewBillResponse getTranscentraBill(GetViewBillRequest request) throws MedicarePayException
	{
		GetViewBillResponse getViewBillResponse = new GetViewBillResponse();
		try
		{
			SearchDocumentsServiceRequest searchDocumentsServiceRequest = dozerMapper.map(request, SearchDocumentsServiceRequest.class);
			searchDocumentsServiceRequest.setDocumentType(TRAN_DOC_TYPE);
			//searchDocumentsServiceRequest.setBillDate(MedicarePayUtils.formatBillDate(request.getBillDate(), "MM/dd/yyyy", "yyyy-MM-dd"));
			searchDocumentsServiceRequest.setBillDate(request.getBillDate());
			if (MedicarePayUtils.checkNullForAString(request.getLob()) && LOB_MA.equalsIgnoreCase(request.getLob()))
			{
				searchDocumentsServiceRequest.setDocumentValue(MA_DOC_VAL);
			}
			else if (MedicarePayUtils.checkNullForAString(request.getLob()) && LOB_MEDSUPP.equalsIgnoreCase(request.getLob()))
			{
				searchDocumentsServiceRequest.setDocumentValue(MEDSUPP_DOC_VAL);
			}

			if(null != request.getBillType() && "FAMILY".equalsIgnoreCase(request.getBillType()))
			{
				searchDocumentsServiceRequest.setBillGroupId(request.getBillGroupId());
				searchDocumentsServiceRequest.setAccountNumber(null);
				searchDocumentsServiceRequest.setProductId(null);
			}else{
				searchDocumentsServiceRequest.setBillGroupId(null);
			}

			GetDocumentsServiceResponse serviceResponse = medicarePayGateway.getTranscentraBill(searchDocumentsServiceRequest);
			if(null != serviceResponse && null != serviceResponse.getDocumentUrl())
			{
				getViewBillResponse.setErrorFlag(false);
				getViewBillResponse.setPdfString(serviceResponse.getDocumentUrl());
			} else
			{
				getViewBillResponse.setErrorFlag(true);
				getViewBillResponse.setPdfString("PDF not available");
			}
		} catch (Exception e)
		{
			getViewBillResponse.setErrorFlag(true);
			getViewBillResponse.setErrorMessage("PDF not available");
			LOGGER.error("Exception in AciRestUtils getTranscentraBill :" + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		return getViewBillResponse;
	}

	/**
	 * Checks whether the member belongs to VA state, MEDSUPP LOB and have coupon payment type
	 * @param medicareBillDetail
	 * @param state
	 * @return
	 * @throws MedicarePayException 
	 */
	private boolean checkForVACouponMember(MedicareBillDetails medicareBillDetail, String state) throws MedicarePayException
	{
		boolean invokeTranscentra = true;
		String payMethod = "";
		String lob = "";
		if (null != medicareBillDetail)
		{
			payMethod = medicareBillDetail.getPaymentMethod();
			lob = medicareBillDetail.getLineOfBusiness();
		}
		if (MedicarePayUtils.checkNullForAString(state) && STATE_VA.equalsIgnoreCase(state) 
				&& MedicarePayUtils.checkNullForAString(lob) && LOB_MEDSUPP.equalsIgnoreCase(lob) 
				&& MedicarePayUtils.checkNullForAString(payMethod) && PAY_METHOD_COUPON.equalsIgnoreCase(payMethod))
		{
			invokeTranscentra = false;
		}
		return invokeTranscentra;
	}
	
	/**
	 * Hystrix fallback method for Payment Method service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public AciFundingResponse invokePayACIApiHystrix(MedicarePayRequestContext requestContext, Throwable e)
	{
		AciFundingResponse response = new AciFundingResponse();
		AciException exception = new AciException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Payment Method api");
		}
		else
		{
			exception.setErrorMessage("Payment Method - " + e.getMessage());
		}
		response.setAciException(exception);
		return response;
	}
	/**
	 * Hystrix fallback method for searchdocuments service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public SearchDocumentsServiceResponse invokeTranscentraApiBillHystrix(MedicareBillDetails billAccount, String memberState, String hcid, Throwable e)
	{
		SearchDocumentsServiceResponse response = new SearchDocumentsServiceResponse();
		LOGGER.error("Hystrix timeout for searchdocuments response");
		return response;
	}
	/**
	 * Hystrix fallback method for Transcentra service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public GetViewBillResponse invokeTranscentraApiHystrix(GetViewBillRequest request, Throwable e)
	{
		GetViewBillResponse response = new GetViewBillResponse();
		MedicarePayException exception = new MedicarePayException();
		if (e instanceof HystrixTimeoutException)
		{
			exception.setErrorMessage("Hystrix timeout for Transcentra api");
		}
		else
		{
			exception.setErrorMessage("Transcentra - " + e.getMessage());
		}
		response.setMedicarePayException(exception);
		return response;
	}
	
	/**
	 * Returns null when search document trancentra service doesn't reterive document id for group number and bill date.
	 * @return
	 */
	public GetDocumentsServiceResponse sendNoDocResponse() {
		GetDocumentsServiceResponse response = new GetDocumentsServiceResponse();
		response.setDocumentUrl(null);
		return response;
	}
	
	/**
	 * Constructs mail params and sends mail
	 * @param model
	 * @param mailType
	 * @throws MedicarePayException
	 */
	public void constructMailParams(Map<String, Object> model, String mailType) throws MedicarePayException
	{	
		String groupId = "";
		if(null != (model.get("childGroupId")) && model.get("childGroupId") != ""){
			groupId = (String)model.get("childGroupId");
		}else{
			groupId = (String)model.get("groupId");
		}
		BrandEmailMatrix brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(
					null != model.get("lineOfBusiness") ? (String) model.get("lineOfBusiness") : "",
							groupId,
					null != model.get("classId") ? (String) model.get("classId") : "",
					null != model.get("state") ? (String) model.get("state") : "",
					null != model.get("planId") ?(String) model.get("planId") : "");
		if (null != brandEmailMatrix)
		{
			model.put(
					LINK_TO_EMAIL,
					emailUtilHelper.getMailId(null != model.get("childHcid") ? (String) model.get("childHcid") : "", "000", groupId));
			model.put(LINK_LOGGEDIN_HCID, null != model.get("hcid") ? (String) model.get("hcid") : "");
			model.put(LINK_TO_HCID, null != model.get("childHcid") ? (String) model.get("childHcid") : "");
			model.put("brandEmailMatrix", brandEmailMatrix);
			sendMail(model, mailType);
		} /*else {
			LOGGER.error("Unable to determine BrandEmailMatrix in constructMailParams() of AciRestUtils");
			throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
					+ "That member needs to update their email address before you can link accounts.");
		}*/
	}
	
	
	/**
	 * Constructs mail params and send mail in async
	 * @param model
	 * @param mailType
	 * @throws MedicarePayException
	 */
	public void constructFailedPayMailParams(Map<String, Object> modelMap) throws MedicarePayException
	{	
		LOGGER.info("Start - Inside constructFailedPayMailParams of AciRestUtils");
		String groupId = "";
		if(null != (modelMap.get("childGroupId")) && modelMap.get("childGroupId") != ""){
			groupId = (String)modelMap.get("childGroupId");
		}else{
			groupId = (String)modelMap.get("groupId");
		}
		BrandEmailMatrix  brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(
					null != modelMap.get("lineOfBusiness") ? (String) modelMap.get("lineOfBusiness") : "",
							groupId,
					null != modelMap.get("classId") ? (String) modelMap.get("classId") : "",
					null != modelMap.get("state") ? (String) modelMap.get("state") : "",
					null != modelMap.get("planId")? (String) modelMap.get("planId"):"");
		if (null != brandEmailMatrix)
		{
			modelMap.put(
					LINK_TO_EMAIL,
					emailUtilHelper.getMailId(null != modelMap.get("hcid") ? (String) modelMap.get("hcid") : "", "000", groupId));
			modelMap.put(LINK_LOGGEDIN_HCID, null != modelMap.get("hcid") ? (String) modelMap.get("hcid") : "");
			modelMap.put(LINK_TO_HCID, null != modelMap.get("childHcid") ? (String) modelMap.get("childHcid") : "");
			modelMap.put("brandEmailMatrix", brandEmailMatrix);
			sendMail(modelMap, MAIL_TYPE_PAY_FAILED);
		} else {
			LOGGER.error("Unable to determine brandEmailMatrix in constructFailedPayMailParams() of AciRestUtils");
			throw new MedicarePayException("You're trying to link to an account that doesn't have a working email address. "
					+ "That member needs to update their email address before you can link accounts.");
		}
		LOGGER.info("End - Inside constructFailedPayMailParams of AciRestUtils");
	}
	
	

	/**
	 * Sets the necessary parameters to invoke sendMail()
	 * 
	 * @param Map
	 *            <String, Object>,String
	 * @return
	 */
	public void sendMail(Map<String, Object> model, String mailType) throws MedicarePayException
	{
		LOGGER.info("Start - sendMail() of MedicarePayServiceImpl");
		Mail mail = new Mail();
		mail.setMailFrom(MAIL_FROM);
		mail.setMailSubject(mailDetailsMap.get(mailType + "_MAIL_SUBJECT"));
		mail.setTemplateLocation(mailDetailsMap.get(mailType + "_TEMP_LOC"));
		mail.setTemplateId(mailDetailsMap.get(mailType + "_TEMP_ID"));
		mail.setMailType(MAIL_TYPE);
		mail.setToHcid((String) model.get(LINK_TO_HCID));
		mail.setCreatedBy((String) model.get(LINK_LOGGEDIN_HCID));
		mail.setMailTo((String) model.get(LINK_TO_EMAIL));
		emailUtil.sendMail(mail, model);
		LOGGER.info("End - sendMail() of MedicarePayServiceImpl");
	}

	/**
	 * constructs params for Payment Success Mail
	 * @param modelMap
	 * @param memPaySubmitPayment
	 * @param hcidInRequest
	 * @throws MedicarePayException
	 */
	public void constructPaySuccessMailParams(@Header("modelMap") Map<String, Object> modelMap, MemberPaySubmitPayment memPaySubmitPayment, 
			@Header("hcidInRequest") String hcidInRequest) throws MedicarePayException {
		GetAccountSummaryResponse getAccSummaryResponse = null;
		SOAMemberProfile sOAMemberProfile = null;
		boolean sendMail = false;
		try {
			if(MedicarePayUtils.checkNullForAString(memPaySubmitPayment.getChildHealthCardId()) && hcidInRequest.equalsIgnoreCase(memPaySubmitPayment.getChildHealthCardId())) {
				if(null != modelMap.get("groupId") && modelMap.get("groupId").equals(memPaySubmitPayment.getPlanID())) {
					sOAMemberProfile = new SOAMemberProfile();
					sOAMemberProfile.setClassId(null != modelMap.get("classId") ? (String) modelMap.get("classId") : "");
					sOAMemberProfile.setLob(null != modelMap.get("lineOfBusiness") ? (String) modelMap.get("lineOfBusiness") : "");
					sOAMemberProfile.setGroupId(null != modelMap.get("groupId") ? (String) modelMap.get("groupId") : "");
					sOAMemberProfile.setState(null != modelMap.get("state") ? (String) modelMap.get("state") : "");
					sOAMemberProfile.setPlanId(null != modelMap.get("planId") ? (String) modelMap.get("planId") : "");
					sOAMemberProfile.setPayAmt(memPaySubmitPayment.getPaymentAmount());
					sOAMemberProfile.setConfirmationNbr(memPaySubmitPayment.getConfirmationNumber());
					sOAMemberProfile.setPaymentHcid(hcidInRequest); //passed to SMC
					sOAMemberProfile.setHcid(hcidInRequest); //to get email address from chub
					sOAMemberProfile.setPayIndicator("WEB");
					constructPaySuccessMailReq(sOAMemberProfile, SMC_PAYMENT_CONFIRMATION);
				} else {
					LOGGER.error("Parent Mail - Plan id in aci response and Group id in member profile doesn't match");
				}
			} else {
				sOAMemberProfile = new SOAMemberProfile();
				sOAMemberProfile.setClassId(null != modelMap.get("classId") ? (String) modelMap.get("classId") : "");
				sOAMemberProfile.setLob(null != modelMap.get("lineOfBusiness") ? (String) modelMap.get("lineOfBusiness") : "");
				sOAMemberProfile.setGroupId(null != modelMap.get("groupId") ? (String) modelMap.get("groupId") : "");
				sOAMemberProfile.setState(null != modelMap.get("state") ? (String) modelMap.get("state") : "");
				sOAMemberProfile.setPlanId(null != modelMap.get("planId") ? (String) modelMap.get("planId") : "");
				sOAMemberProfile.setPayAmt(memPaySubmitPayment.getPaymentAmount());
				sOAMemberProfile.setConfirmationNbr(memPaySubmitPayment.getConfirmationNumber());
				sOAMemberProfile.setPaymentHcid(memPaySubmitPayment.getChildHealthCardId()); //passed to SMC
				sOAMemberProfile.setHcid(hcidInRequest); //to get email address from chub
				sOAMemberProfile.setPayIndicator("WEB");
				constructPaySuccessMailReq(sOAMemberProfile, SMC_PAYMENT_CONFIRMATION);
				
				sOAMemberProfile = new SOAMemberProfile();
				sOAMemberProfile.setPayAmt(memPaySubmitPayment.getPaymentAmount());
				sOAMemberProfile.setConfirmationNbr(memPaySubmitPayment.getConfirmationNumber());
				sOAMemberProfile.setPaymentHcid(memPaySubmitPayment.getChildHealthCardId()); //passed to SMC
				
				GetAccountSummaryRequest accSummaryReq = new GetAccountSummaryRequest();
				accSummaryReq.setHealthCardId(memPaySubmitPayment.getChildHealthCardId());
				Future<GetAccountSummaryResponse> futureObj = medicarePayGateway.getMemberProfileAsync(accSummaryReq);
				getAccSummaryResponse = futureObj.get();
				
				if (null != getAccSummaryResponse && null != getAccSummaryResponse.getMemberEligibilityList()
						&& getAccSummaryResponse.getMemberEligibilityList().size() > 0)
				{
					for (MemberEligibility memberEligibility : getAccSummaryResponse.getMemberEligibilityList())
					{
						if (null != memberEligibility &&  null != memberEligibility.getHealthCardId()&& null != memberEligibility.getHealthCardId().getSubscriberId()
								&& (null != memberEligibility.getBillDetails() && null != memberEligibility.getBillDetails().getLineOfBusiness())
								&& null != memPaySubmitPayment.getPlanID() && memPaySubmitPayment.getPlanID().equalsIgnoreCase(memberEligibility.getGroupID()))
						{
							sendMail = true;
							sOAMemberProfile.setGroupId(memberEligibility.getGroupID());
							sOAMemberProfile.setClassId(memberEligibility.getClassID());
							sOAMemberProfile.setState(memberEligibility.getPlanState());
							sOAMemberProfile.setLob(memberEligibility.getBillDetails().getLineOfBusiness().toUpperCase());
							sOAMemberProfile.setPlanId(memberEligibility.getPlanID());
							break;
						}
					}
					if(sendMail) {
						sOAMemberProfile.setHcid(memPaySubmitPayment.getChildHealthCardId()); //to get email addrress from chub
						sOAMemberProfile.setPayIndicator("WEB");
						constructPaySuccessMailReq(sOAMemberProfile, SMC_PAYMENT_CONFIRMATION);
					} else {
						LOGGER.error("Child Mail - Plan id in aci response and Group id in member profile doesn't match");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in MedicarePayServiceImpl MedicarePayServiceImpl : " + e);
		}
	}
	
	//PP-15970 - Start
	/**
	 * @param model
	 * @param hcid
	 * @throws MedicarePayException
	 */
	public void constructPaySuccessMailReq(SOAMemberProfile sOAMemberProfile, String mailType) throws MedicarePayException {
		SOASMCEmailRequest sOASubmitPaymentMail = null;
		try {
			BrandEmailMatrix brandEmailMatrix = MedicarePayUtils.getBrandMatrixDetails(sOAMemberProfile.getLob(), sOAMemberProfile.getGroupId(), 
					sOAMemberProfile.getClassId(), sOAMemberProfile.getState(),sOAMemberProfile.getPlanId());
			if (null != brandEmailMatrix) {
				sOASubmitPaymentMail = new SOASMCEmailRequest();
				
				AdditionalPropertiesBO additionalPropertiesBO = new AdditionalPropertiesBO();
				AdditionalPropGrpBO additionalPropGrpBO = new AdditionalPropGrpBO();
				List<AdditionalPropGrpBO> additionalPropGrp = new ArrayList<AdditionalPropGrpBO>();

				additionalPropGrpBO.setAdditionalPropGrpNm(mailType);
				List<PropertyBO> property = new ArrayList<PropertyBO>();
				
				PropertyBO paymentDateField = new PropertyBO();
				paymentDateField.setPropertyNm("PaymentDate");
				//paymentDateField.setPropertyVal(MedicarePayUtils.formatDate(new Date(), "MM/dd/yy hh:mm:ss.SSS zzz"));
				paymentDateField.setPropertyVal(MedicarePayUtils.formatDate(new Date(), "MM/dd/yy HH:mm"));
				
				PropertyBO paymentAmtField = new PropertyBO();
				paymentAmtField.setPropertyNm("PaymentAmount");
				paymentAmtField.setPropertyVal(sOAMemberProfile.getPayAmt());
				
				PropertyBO brandField = new PropertyBO();
				brandField.setPropertyNm("EmailBrand");
				brandField.setPropertyVal(brandEmailMatrix.getBrandAbbr());
				
				PropertyBO brandIdField = new PropertyBO();
				brandIdField.setPropertyNm("BrandID");
				brandIdField.setPropertyVal(brandEmailMatrix.getBrandId());
				
				PropertyBO stateField = new PropertyBO();
				stateField.setPropertyNm("PlanState");
				stateField.setPropertyVal(sOAMemberProfile.getState());
				
				PropertyBO payIndicatorField = new PropertyBO();
				payIndicatorField.setPropertyNm("PaymentIndicator");
				payIndicatorField.setPropertyVal(sOAMemberProfile.getPayIndicator());
				
				if(null != mailType && mailType.equalsIgnoreCase(SMC_PAYMENT_CONFIRMATION)) {
					PropertyBO confirmationField = new PropertyBO();
					confirmationField.setPropertyNm("ConfirmationNumber");
					confirmationField.setPropertyVal(sOAMemberProfile.getConfirmationNbr());
					property.add(confirmationField);
				} else if(null != mailType && mailType.equalsIgnoreCase(SMC_PAYMENT_CANCELLATION)) {
					PropertyBO cancellationField = new PropertyBO();
					cancellationField.setPropertyNm("CancellationNumber");
					cancellationField.setPropertyVal(sOAMemberProfile.getConfirmationNbr());
					property.add(cancellationField);
				}
				
				property.add(paymentDateField);
				property.add(paymentAmtField);
				property.add(brandField);
				property.add(brandIdField);
				property.add(stateField);
				property.add(payIndicatorField);
				additionalPropGrpBO.setProperty(property);
				additionalPropGrp.add(additionalPropGrpBO);
				
				additionalPropertiesBO.setAdditionalPropGrp(additionalPropGrp);
				sOASubmitPaymentMail.setAdditionalProperties(additionalPropertiesBO);
				
				EventHeader eventHeader = new EventHeader();
				eventHeader.setEventDomain("Payment"); 
				eventHeader.setEventGenerationTimestamp(MedicarePayUtils.getCurrentDateTimezoneString());
				eventHeader.setEventGenerator(SMC_EVENT_GENERATOR);
				eventHeader.setSourceSystemId("MEDIS");
				eventHeader.setTransId(sOAMemberProfile.getConfirmationNbr());
				sOASubmitPaymentMail.setEventHeader(eventHeader);
				
				Member member = new Member();
				member.setHcid(sOAMemberProfile.getPaymentHcid());
				member.setMbrSequenceNbr("000");
				sOASubmitPaymentMail.setMember(member);
				
				NotificationPreference notificationPreference = new NotificationPreference();
				notificationPreference.setPreferenceType("Email");
				if(null != sOAMemberProfile.getPayIndicator() && "CSR".equalsIgnoreCase(sOAMemberProfile.getPayIndicator())) {
					notificationPreference.setEmailAddress(sOAMemberProfile.getEmailAddr());					
				} else if(null != sOAMemberProfile.getPayIndicator() && "WEB".equalsIgnoreCase(sOAMemberProfile.getPayIndicator())) {
					notificationPreference.setEmailAddress(emailUtilHelper.getMailId(sOAMemberProfile.getHcid(), "000", sOAMemberProfile.getGroupId()));
				}
				notificationPreference.setPreVerificationInd("false");
				sOASubmitPaymentMail.setNotificationPreference(notificationPreference);
				
				sendPaySuccessMail(sOASubmitPaymentMail, sOAMemberProfile.getHcid());
			} else {
				LOGGER.error("MedicarePayServiceImpl constructSuccessMailParams BrandEmailMartrix is null");
			}
		} catch (Exception e){
			LOGGER.error("Exception in AciRestUtils sendPaySuccessMail" + e);
		}
	}
	//PP-15970 End
	
	/**
	 * Invokes SOA service to send payment confirmation mail
	 * @param sOASubmitPaymentMail
	 */
	@HystrixCommand(fallbackMethod = "invokeSOASuccessMailApiHystrix", ignoreExceptions = { MedicarePayException.class }, commandProperties = { @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "15000") })
	public void sendPaySuccessMail(SOASMCEmailRequest request, String hcid) throws MedicarePayException {
		SOASMCEmailResponse response = null;
		try {
			HttpEntity<SOASMCEmailRequest> requestEntity = new HttpEntity<SOASMCEmailRequest>(request, getSOASuccessMailHttpHeaders(hcid, SOA_PAY_SUCCESS_MAIL_SERVICE));
			response = getMemberProfileRestTemplate().postForObject(soaPaySuccessMailEndPoint, requestEntity, SOASMCEmailResponse.class);
			response.setStatus("200");
			response.setMessage("Mail Sent Successfully");
		} catch(HttpClientErrorException e) {
			HttpClientErrorException httpError = ((HttpClientErrorException) e);
			response = new SOASMCEmailResponse();
			response.setStatus(null != httpError.getStatusCode() ? String.valueOf(httpError.getStatusCode().value()) : "Undefined");
			response.setMessage(e.getMessage());
			LOGGER.error("HttpClientErrorException in AciRestUtils sendPaySuccessMail Status Code :: " + response.getStatus() + "Error : " + e);
		} catch (HttpServerErrorException e) {
			HttpServerErrorException serverError = (HttpServerErrorException)e;
			response = new SOASMCEmailResponse();
			response.setStatus(null != serverError.getStatusCode() ? String.valueOf(serverError.getStatusCode().value()) : "Undefined");
			response.setMessage(e.getMessage());
			LOGGER.error("HttpServerErrorException in AciRestUtils sendPaySuccessMail Status Code :: " + response.getStatus() + "Error : " + e);
		} catch (Exception e){
			response = new SOASMCEmailResponse();
			response.setStatus("Undefined");
			response.setMessage(e.getMessage());
			LOGGER.error("Exception in AciRestUtils sendPaySuccessMail" + e);
		}
	}
	
	/**
	 * Hystrix fallback method for SOA pay success mail service call
	 * @param requestContext
	 * @param e
	 * @return
	 */
	public void invokeSOASuccessMailApiHystrix(SOASMCEmailRequest sOASubmitPaymentMail, String hcid, Throwable e) {
		LOGGER.error("Exception in AciRestUtils invokeSOASuccessMailApiHystrix " + e);
	}
	
	/**
	 * Returns Http Headers for invoking member profile service
	 * @param memberId
	 * @param api
	 * @return
	 */
	private HttpHeaders getSOASuccessMailHttpHeaders(String memberId, String api) {
		SecureRandom mySecureRand = new SecureRandom();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(APIKEY, soaPaySuccessMailApikey);
		headers.add(META_TRANS_ID, String.valueOf(mySecureRand.nextInt(9999999)));
		headers.add(META_SENDERAPP, "PPORT");
		headers.add(OUT_GOING_ID, memberId);
		headers.add(OUT_OPERATION, api);
		return headers;
	}
	
	/**
	 * To get the product level bill details
	 * @param memberEligibilityList
	 * @return
	 * @throws MedicarePayException
	 */
	public List<MemberEligibility> getBillDetailsForDiffGrp(List<MemberEligibility> memberEligibilityList) throws MedicarePayException{
		LOGGER.info("Start - Inside getBillDetailsForDiffGrp of AciRestUtils");
		List<MemberEligibility> newMemberEligibilityList = null;
		Map<String,List<MemberEligibility>> billDetailsMap = new HashMap<>();
		if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
			for (MemberEligibility memberEligibility : memberEligibilityList) {
				if(null != memberEligibility){
					if(null != billDetailsMap.get(memberEligibility.getGroupID())){
						billDetailsMap.get(memberEligibility.getGroupID()).add(memberEligibility);
					}else{
						newMemberEligibilityList = new ArrayList<>();
						newMemberEligibilityList.add(memberEligibility);
						billDetailsMap.put(memberEligibility.getGroupID(),newMemberEligibilityList );
					}
				}
			}
		}
		
		newMemberEligibilityList = new ArrayList<>();
		for (Map.Entry<String,List<MemberEligibility>> billDetailEntry : billDetailsMap.entrySet()) {
			MemberEligibility newEligibility = getProductLevelBillDetails(billDetailEntry.getValue());
			if(null != newEligibility){
				newMemberEligibilityList.add(newEligibility);
			}
		}
		
		LOGGER.info("End - Inside getBillDetailsForDiffGrp of AciRestUtils");
		return newMemberEligibilityList;
	}
	
	/**
	 * To get the product level bill details
	 * @param memberEligibilityList
	 * @return
	 * @throws MedicarePayException
	 */
	public MemberEligibility getProductLevelBillDetails(List<MemberEligibility> memberEligibilityList) throws MedicarePayException{
		
		LOGGER.info("Start - Inside getProductLevelBillDetails of AciRestUtils");
		Map<String, MemberEligibility> productLevelMap = new HashMap<>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		boolean isFutureActive = false;
		boolean isCurrentActive = false;
		boolean isTerminated = false;
		boolean isPending = false;
		MemberEligibility newMemberEligibility = null;
		if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
			for (MemberEligibility memberEligibility : memberEligibilityList) {
				if(null != memberEligibility.getDateEffective() && null != memberEligibility.getCoverageStatusCode()){
					Date effectiveDate = MedicarePayUtils.getDateByString(memberEligibility.getDateEffective(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					Date currentDate = MedicarePayUtils.getDateByString(simpleDateFormat.format(new Date()), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					
					LOGGER.info("effectiveDate::::::"+effectiveDate);
					LOGGER.info("currentDate:::::::"+currentDate);
					
					if ((effectiveDate.before(currentDate) || effectiveDate.equals(currentDate)) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("currentActive", memberEligibility);
						isCurrentActive = true;
					}else if (effectiveDate.after(currentDate) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("futureActive", memberEligibility);
						isFutureActive = true;
					}else if ("PENDING".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("pending", memberEligibility);
						isPending = true;
					}else if ("EXPIRED".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("terminated", memberEligibility);
						isTerminated = true;
					}
				}
			}
		}
		
		if(isCurrentActive){
			newMemberEligibility = productLevelMap.get("currentActive");
		} else if (isFutureActive){
			newMemberEligibility = productLevelMap.get("futureActive");
		}else if(isPending){
			newMemberEligibility = productLevelMap.get("pending");
		}else if (isTerminated){
			newMemberEligibility = productLevelMap.get("terminated");
		}
		
		LOGGER.info("End - Inside getProductLevelBillDetails of AciRestUtils");
		return newMemberEligibility;
	}
	
	
	/**
	 * To get the product level bill details for a groupid
	 * @param memberEligibilityList
	 * @return
	 * @throws MedicarePayException
	 */
	public MemberEligibility getProductLevelBillDetailsForAGroupId(List<MemberEligibility> memberEligibilityList, String groupId) throws MedicarePayException{
		
		LOGGER.info("Start - Inside getProductLevelBillDetails of AciRestUtils");
		Map<String, MemberEligibility> productLevelMap = new HashMap<>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		boolean isFutureActive = false;
		boolean isCurrentActive = false;
		boolean isTerminated = false;
		boolean isPending = false;
		MemberEligibility newMemberEligibility = null;
		if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
			for (MemberEligibility memberEligibility : memberEligibilityList) {
				if(null != memberEligibility.getDateEffective() && null != memberEligibility.getCoverageStatusCode() && null != memberEligibility.getGroupID() && memberEligibility.getGroupID().equalsIgnoreCase(groupId)){
					Date effectiveDate = MedicarePayUtils.getDateByString(memberEligibility.getDateEffective(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					Date currentDate = MedicarePayUtils.getDateByString(simpleDateFormat.format(new Date()), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					
					LOGGER.info("effectiveDate::::::"+effectiveDate);
					LOGGER.info("currentDate:::::::"+currentDate);
					
					if ((effectiveDate.before(currentDate) || effectiveDate.equals(currentDate)) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("currentActive", memberEligibility);
						isCurrentActive = true;
					}else if (effectiveDate.after(currentDate) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("futureActive", memberEligibility);
						isFutureActive = true;
					}else if ("PENDING".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("pending", memberEligibility);
						isPending = true;
					}else if ("EXPIRED".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("terminated", memberEligibility);
						isTerminated = true;
					}
				}
			}
		}
		
		if(isCurrentActive){
			newMemberEligibility = productLevelMap.get("currentActive");
		} else if (isFutureActive){
			newMemberEligibility = productLevelMap.get("futureActive");
		}else if(isPending){
			newMemberEligibility = productLevelMap.get("pending");
		}else if (isTerminated){
			newMemberEligibility = productLevelMap.get("terminated");
		}
		
		LOGGER.info("End - Inside getProductLevelBillDetails of AciRestUtils");
		return newMemberEligibility;
	}
	
	/***
	 * Call Transcentra in async for multiple bills
	 * @param medicareBillAccount
	 * @param memberState
	 * @param hcid
	 * @return
	 */
	public List<MedicarePayBillAccount> findPdfForBillAccount(MedicarePayBillAccount medicareBillAccount,@Header("memberState") String memberState, @Header("hcid") String hcid){
		LOGGER.info("Inside AciRestUtils-->findPdfForBillAccount");
		List<MedicarePayBillAccount> medicarePayBillAccounts = new ArrayList<MedicarePayBillAccount>();
		try{
			MedicareBillDetails billAccount = new MedicareBillDetails();
			billAccount.setGroupId(medicareBillAccount.getGroupId());
			billAccount.setPaymentMethod(medicareBillAccount.getPaymentMethod());
			billAccount.setLineOfBusiness(medicareBillAccount.getLineOfBusiness());
			billAccount.setBillProcessedDate(medicareBillAccount.getBillProcessedDate());
			billAccount.setPrimaryMemberHcid(medicareBillAccount.getPrimaryMemberHcid());
			billAccount.setBillGroupId(medicareBillAccount.getBillGroupId());
			billAccount.setBillType(medicareBillAccount.getBillType());
			if (checkForVACouponMember(billAccount, memberState))
			{
				Object response = medicarePayGateway.findPdfAvailabilityForSingleBill(
						billAccount, memberState, hcid);
				if (null != response && response instanceof SearchDocumentsServiceResponse)
				{
					SearchDocumentsServiceResponse searchDocumentsServiceResponse = (SearchDocumentsServiceResponse) response;
					if (null != searchDocumentsServiceResponse && null != searchDocumentsServiceResponse.getDocumentId())
					{
						medicareBillAccount.setPdfBillAvailable(true);
					}
				}
			}

		}catch(Exception e){
			LOGGER.error("Excpetion in findPdfForBillAccount of AciRestUtils"+e);
		}
		medicarePayBillAccounts.add(medicareBillAccount);
		LOGGER.info("End AciRestUtils-->findPdfForBillAccount");
		return medicarePayBillAccounts;
	}
	
	/**
	 * To get the product level bill details to get auto pay pdf
	 * @param memberEligibilityList
	 * @return
	 * @throws MedicarePayException
	 */
	public List<MemberEligibility> getBillDetailsForDiffGrpAutoPay(List<MemberEligibility> memberEligibilityList) throws MedicarePayException{
		LOGGER.info("Start - Inside getBillDetailsForDiffGrpAutoPay of AciRestUtils");
		List<MemberEligibility> newMemberEligibilityList = null;
		Map<String,List<MemberEligibility>> billDetailsMap = new HashMap<>();
		if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
			for (MemberEligibility memberEligibility : memberEligibilityList) {
				if(null != memberEligibility){
					if(null != billDetailsMap.get(memberEligibility.getGroupID())){
						billDetailsMap.get(memberEligibility.getGroupID()).add(memberEligibility);
					}else{
						newMemberEligibilityList = new ArrayList<>();
						newMemberEligibilityList.add(memberEligibility);
						billDetailsMap.put(memberEligibility.getGroupID(),newMemberEligibilityList );
					}
				}
			}
		}
		
		newMemberEligibilityList = new ArrayList<>();
		for (Map.Entry<String,List<MemberEligibility>> billDetailEntry : billDetailsMap.entrySet()) {
			MemberEligibility newEligibility = getProdLevelBillDetailsAutoPay(billDetailEntry.getValue());
			if(null != newEligibility){
				newMemberEligibilityList.add(newEligibility);
			}
		}
		
		LOGGER.info("End - Inside getBillDetailsForDiffGrpAutoPay of AciRestUtils");
		return newMemberEligibilityList;
	}
	
	/**
	 * To get the product level bill details to get auto pay pdf
	 * @param memberEligibilityList
	 * @return
	 * @throws MedicarePayException
	 */
	public MemberEligibility getProdLevelBillDetailsAutoPay(List<MemberEligibility> memberEligibilityList) throws MedicarePayException{
		
		LOGGER.info("Start - Inside getProdLevelBillDetailsAutoPay of AciRestUtils");
		Map<String, MemberEligibility> productLevelMap = new HashMap<>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		boolean isFutureActive = false;
		boolean isCurrentActive = false;
		boolean isPending = false;
		MemberEligibility newMemberEligibility = null;
		if(MedicarePayUtils.checkNullForAList(memberEligibilityList)){
			for (MemberEligibility memberEligibility : memberEligibilityList) {
				if(null != memberEligibility.getDateEffective() && null != memberEligibility.getCoverageStatusCode()){
					Date effectiveDate = MedicarePayUtils.getDateByString(memberEligibility.getDateEffective(), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					Date currentDate = MedicarePayUtils.getDateByString(simpleDateFormat.format(new Date()), "yyyy-MM-dd'T'HH:mm:ss'Z'");
					
					LOGGER.info("effectiveDate::::::"+effectiveDate);
					LOGGER.info("currentDate:::::::"+currentDate);
					
					if ((effectiveDate.before(currentDate) || effectiveDate.equals(currentDate)) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("currentActive", memberEligibility);
						isCurrentActive = true;
					}else if (effectiveDate.after(currentDate) && ACTIVE.equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("futureActive", memberEligibility);
						isFutureActive = true;
					}else if ("PENDING".equalsIgnoreCase(memberEligibility.getCoverageStatusCode())){
						productLevelMap.put("pending", memberEligibility);
						isPending = true;
					}
				}
			}
		}
		
		if(isCurrentActive){
			newMemberEligibility = productLevelMap.get("currentActive");
		} else if (isFutureActive){
			newMemberEligibility = productLevelMap.get("futureActive");
		}else if(isPending){
			newMemberEligibility = productLevelMap.get("pending");
		}
		
		LOGGER.info("End - Inside getProdLevelBillDetailsAutoPay of AciRestUtils");
		return newMemberEligibility;
	}

	//PP-14143 - Start
	public List<PayModSubmitPaymentRequest> searchPayModPayments(String hcid, String lob) throws MedicarePayException{
		LOGGER.info("AciRestUtils: Inside searchPayModPayments - start");
		List<PayModSubmitPaymentRequest> payDetails = null;
		try {
			SearchPayModPaymentRequest request = new SearchPayModPaymentRequest();
			request.setHcid(hcid);
			
			if("MEDSUPP".equalsIgnoreCase(lob)) {
				request.setLob(PAY_MOD_MS_LOB);
			} else {
				request.setLob(PAY_MOD_MA_LOB);
			}
			
			request.setTransactionType(Arrays.asList(PAY_MOD_TRAN_TYPE));
			request.setTransactionStatus(Arrays.asList(PAY_MOD_TRAN_STATUS));
			SearchPayModPaymentResponse response = payModRestUtils.searchPayModPayment(request);
			if(null != response && null == response.getExceptions()) {
				payDetails = response.getPaymentDetailsVOs();
			}else {
				LOGGER.error("Exception in AciRestUtils.searchPayModPayments" + response.getExceptions().toString());
				throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
			}
		}catch(Exception e) {
			LOGGER.error("Error in AciRestUtils.searchPayModPayment inside searchPayModPayment: " + e);
			throw new MedicarePayException(EXCEPTION, ERROR_CODE_9000, TECHNICAL_ERROR_MSG, 500);
		}
		LOGGER.info("AciRestUtils: Inside searchPayModPayments - end");
		return payDetails;
	}
	
	/**
	 * Returns chase payment details
	 * @param paymentInfo
	 * @return
	 * @throws MedicarePayException 
	 */
	private MedicarePayPayment prepareChasePaymentDetails(PayModSubmitPaymentRequest paymentInfo, Transaction transaction, String csrId) throws MedicarePayException
	{
		LOGGER.info("Inside AciRestUtils-->preparePaymentDetails");
		MedicarePayPayment memberPayPayment = new MedicarePayPayment();
		MedicarePayPaymentMethod paymentMethod = new MedicarePayPaymentMethod();
		if (null != paymentInfo)
		{
			memberPayPayment.setPaymentAmount(Float.valueOf(transaction.getPremiumAmount()));
			memberPayPayment.setPaymentDate(MedicarePayUtils.getDateByString(transaction.getPaidDate(), DATE_FORMAT_yyyyMMdd));
			if(!TRAN_STS_PENDING.equalsIgnoreCase(transaction.getTransactionStatus())) {
				memberPayPayment.setPaymentTrackingNo("");
			} else {
				memberPayPayment.setPaymentTrackingNo(paymentInfo.getAnthemOrderId());
			}
			if(null != csrId && !csrId.isEmpty()) {
				List<String> notes = new ArrayList<String>();
				if(transaction.getNotes() != null) {
					for(Note note: transaction.getNotes()) {
						if(note.getNoteDesc() != null && !note.getNoteDesc().isEmpty()) {
							String notesString = "";
							if(note.getAction() != null && note.getAction().equalsIgnoreCase("submit")) {
								notesString = "Payment Submission Notes : " + note.getNoteDesc();
							}
							if(note.getAction() != null && note.getAction().equalsIgnoreCase("cancel")) {
								notesString = "Payment Cancellation Notes : " + note.getNoteDesc();
							}
							notes.add(notesString);
						}
					}
				}
				memberPayPayment.setNotes(notes);
			}
			if(null != paymentInfo.getPaymentMethod()) {
				String paymentType = paymentInfo.getPaymentMethod().getPaymentType();
				String accNo = "";
				if(PAY_MOD_PAY_TYP_ACH.equalsIgnoreCase(paymentType)) {
					accNo = paymentInfo.getPaymentMethod().getBankAccountNumber();
					accNo = "*"+ accNo.subSequence(accNo.length()-4, accNo.length());
					paymentMethod.setMaskedAccountNumber(accNo);
				}else {
					accNo = MedicarePayUtils.maskString(paymentInfo.getPaymentMethod().getCreditCardNumber(), 0,paymentInfo.getPaymentMethod().getCreditCardNumber().length() - 4, '*');
					paymentMethod.setMaskedAccountNumber(accNo);
				}
				paymentMethod.setAccNickName(paymentInfo.getPaymentMethod().getNameOnFundingAccount());
				paymentMethod.setBankAccountType(setAccountType(paymentInfo.getPaymentMethod().getPaymentSubType()));
				paymentMethod.setTokenId((null != paymentInfo.getPaymentMethod().getTokenId() ? paymentInfo.getPaymentMethod().getTokenId() : ""));
			}
			memberPayPayment.setPaymentMethod(paymentMethod);
		}
		LOGGER.info("Completed AciRestUtils-->preparePaymentDetails");
		return memberPayPayment;

	}
	
	private void sortMemberPayments(List<MedicarePayPayment> memberPayments) {
		Collections.sort(memberPayments, new Comparator<MedicarePayPayment>(){
		    public int compare(MedicarePayPayment memberPayment1, MedicarePayPayment memberPayment2) {
		    	try
				{
		    	if (null == memberPayment1.getPaymentDate() || null == memberPayment2.getPaymentDate()){
		            return 0;
		    	}
				return memberPayment2.getPaymentDate().compareTo(memberPayment1.getPaymentDate());
				} catch (Exception e)
				{
					return 0;
				}
		    }
		});
	}
	
	private String getPayStatus(MedicarePayPayment payDetails) {
		String status = null;
		if(null != payDetails && null != payDetails.getPaymentDate()) {
			Date date = new Date();
			if (!payDetails.getPaymentDate().after(date))
			{
				status = "Payment in process";
			}
			else if (payDetails.getPaymentDate().after(date))
			{
				status = "Future payment Scheduled";
			}
		}
		return status;
	}
	//PP-14143 - End

	/*PP-14146 - start */
	public PayModSubmitPaymentResponse triggerPayModSubmitPayments(PayModSubmitPaymentRequest request) throws MedicarePayException{
		PayModSubmitPaymentResponse response = new PayModSubmitPaymentResponse();
		try {
			response = payModRestUtils.submitPayModPayment(request);
			if(response.getExceptions() != null){
				LOGGER.error("Exception in payModRestUtils.triggerPayModSubmitPayments inside triggerPayModSubmitPayments: " + response.getExceptions().toString());
			}
		}catch(Exception e) {
			LOGGER.error("Error in payModRestUtils.triggerPayModSubmitPayments inside triggerPayModSubmitPayments: " + e);
		}
		return response;
	}
	/*PP-14146 - end */
	
	//PP-15970 - Start
	/**
	 * @param sOAMemberProfile
	 * @param mailType
	 * @throws MedicarePayException
	 */
	public void sendPaymentSMCMail(SOAMemberProfile sOAMemberProfile, @Header("mailType") String mailType) throws MedicarePayException {
		try {
			constructPaySuccessMailReq(sOAMemberProfile, mailType);
		} catch (Exception e) {
			LOGGER.error("Exception in AciRestUtils sendPaySuccessSMCMail : " + e);
		}
	}
	//PP-15970 - End
}
