/**
 * MappingConfig.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.config;


import static org.dozer.loader.api.FieldsMappingOptions.customConverter;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.eox.medsupp.schema.model.GeneralIDs;
import org.eox.medsupp.schema.model.MedicareMember;
import org.eox.medsupp.schema.model.MemberEligibility;
import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;
import org.eox.medsupp.schema.model.MedicarePayPerson;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;


@Configuration
public class MappingConfig
{

	@Bean(name = "org.dozer.Mapper")
	public DozerBeanMapper dozerBean()
	{
		DozerBeanMapper dozerBean = new DozerBeanMapper();
		dozerBean.addMapping(getMethodPaymentAciRequestCC());
		dozerBean.addMapping(getMethodPaymentAciRequestBank());
		dozerBean.addMapping(getMedicareMember());
		dozerBean.addMapping(getMedicarePersonDetails());
		dozerBean.addMapping(getGeneralIdsDetails());
		return dozerBean;
	}

	private BeanMappingBuilder getGeneralIdsDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(MemberEligibility.class, type(GeneralIDs.class))
				.fields("planID","planId")
				.fields("productID","productId")
				.fields("planIdDescription","planDescription")
				.fields("productDescription","productDescription")
				.fields("groupID","groupId")
				.fields("healthCardId.subscriberId","hcid");
			}
		};
		return builder;
	}
	private BeanMappingBuilder getMedicarePersonDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(MemberEligibility.class, type(MedicarePayPerson.class))
				.fields("memberDemographicDetails.firstName","firstName")
				.fields("memberDemographicDetails.lastName","lastName") 
				.fields("healthCardId.subscriberId","hcid")
				.fields("planState", "state")
				.fields("memberDemographicDetails.contactInformation.homeAddress.addressLineOne","address.addressLine1")
				.fields("memberDemographicDetails.contactInformation.homeAddress.addressLineTwo","address.addressLine2")
				.fields("memberDemographicDetails.contactInformation.homeAddress.city","address.city")
				.fields("memberDemographicDetails.contactInformation.homeAddress.state", "address.state")
				.fields("memberDemographicDetails.contactInformation.homeAddress.zipCode", "address.postalCode");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getMethodPaymentAciRequestBank()
	{
		BeanMappingBuilder builder = new BeanMappingBuilder()
		{

			@Override
			protected void configure()
			{
				mapping(BankAccountDetails.class, type(MedicarePayPaymentMethod.class).createMethod("dozerCreateMethodActiveBank"))
						.fields("accountNickname", "accNickName").fields("tokenId", "tokenId")
						.fields("bankAccountType", "bankAccountType", customConverter("org.eox.medsupp.jar.config.BankTypeConverter"))
						.fields("routingNumber", "routingNumber").fields("bankAccountNumber", "maskedAccountNumber")
						.fields("bankAccountNumber", "confirmAccountNo").fields("accountHolderName", "accountName")
						.fields("accountAddress1", "billingAddress.addressLine1").fields("accountAddress2", "billingAddress.addressLine2")
						.fields("accountCity", "billingAddress.city").fields("accountState", "billingAddress.state")
						.fields("accountCountryCode", "billingAddress.country").fields("accountPostalCode", "billingAddress.postalCode");
			}

		};
		return builder;
	}

	private BeanMappingBuilder getMethodPaymentAciRequestCC()
	{
		BeanMappingBuilder builder = new BeanMappingBuilder()
		{

			@Override
			protected void configure()
			{
				mapping(CreditCardDetails.class, type(MedicarePayPaymentMethod.class).createMethod("dozerCreateMethodActiveCC"))
						.fields("accountNickname", "accNickName").fields("tokenId", "tokenId")
						.fields("creditCardType", "bankAccountType", customConverter("org.eox.medsupp.jar.config.CredtiCardTypeConverter"))
						.fields("creditCardNumber", "confirmAccountNo").fields("creditCardNumber", "maskedAccountNumber")
						.fields("accountHolderName", "accountName").fields("accountHolderName", "accountName")
						.fields("expirationMonth", "expiration", customConverter(ExpMMConverter.class))
						.fields("expirationYear", "expiration", customConverter(ExpYYConverter.class))
						.fields("accountAddress1", "billingAddress.addressLine1").fields("accountAddress2", "billingAddress.addressLine2")
						.fields("accountCity", "billingAddress.city").fields("accountState", "billingAddress.state")
						.fields("accountPostalCode", "billingAddress.postalCode");
			}

		};
		return builder;
	}

	/*PP-6430 GA rebranding starts*/
	private BeanMappingBuilder getMedicareMember()
	{
		BeanMappingBuilder builder = new BeanMappingBuilder()
		{

			@Override
			protected void configure()
			{
				mapping(MemberEligibility.class, type(MedicareMember.class))
						.fields("memberDemographicDetails.firstName", "firstName")
						.fields("memberDemographicDetails.lastName", "lastName")
						.fields("memberDemographicDetails.dateOfBirth", "dateOfBirth")
						.fields("healthCardId.subscriberId", "healthCardId")
						.fields("planState", "state")
						.fields("billDetails.billGroupId", "medicareBillDetails[0].billGroupId")
						.fields("billDetails.billType", "medicareBillDetails[0].billType")
						.fields("billDetails.primaryMemberHcid.subscriberId", "medicareBillDetails[0].primaryMemberHcid")
						.fields("billDetails.billDueDate", "medicareBillDetails[0].billDueDate")
						.fields("billDetails.paidStatus", "medicareBillDetails[0].paidStatus")
						.fields("divisionCode", "medicareBillDetails[0].divisionCode")
						.fields("billDetails.lineOfBusiness", "medicareBillDetails[0].lineOfBusiness")
						.fields("billDetails.billProcessedDate", "medicareBillDetails[0].billProcessedDate")
						.fields("billDetails.billNetDue", "medicareBillDetails[0].billNetDue")
						.fields("billDetails.minimumAmountDue", "medicareBillDetails[0].billMinDue")
						.fields("billDetails.statementId", "medicareBillDetails[0].paymentMethod")
						.fields("productDescription", "medicareBillDetails[0].productDescription")
						.fields("planIdDescription", "medicareBillDetails[0].planIdDescription")
						.fields("subgroupID", "medicareBillDetails[0].subgroupId")
						.fields("planID", "medicareBillDetails[0].planId")
						.fields("classID", "medicareBillDetails[0].classId")
						.fields("groupID", "medicareBillDetails[0].groupId")
						.fields("memberDemographicDetails.contactInformation.homeAddress.addressLineOne", "billingAddress.addressLineOne")
						.fields("memberDemographicDetails.contactInformation.homeAddress.addressLineThree",
								"billingAddress.addressLineThree")
						.fields("memberDemographicDetails.contactInformation.homeAddress.addressLineTwo", "billingAddress.addressLineTwo")
						.fields("memberDemographicDetails.contactInformation.homeAddress.city", "billingAddress.city")
						.fields("memberDemographicDetails.contactInformation.homeAddress.county", "billingAddress.county")
						.fields("memberDemographicDetails.contactInformation.homeAddress.phone", "billingAddress.phone")
						.fields("memberDemographicDetails.contactInformation.homeAddress.phoneExtension", "billingAddress.phoneExtension")
						.fields("memberDemographicDetails.contactInformation.homeAddress.state", "billingAddress.state")
						.fields("memberDemographicDetails.contactInformation.homeAddress.zipCode", "billingAddress.zipCode")
						.fields("dateEffective","effectiveDate");
			}

		};
		return builder;
	}
	/*PP-6430 GA rebranding ends*/
}
