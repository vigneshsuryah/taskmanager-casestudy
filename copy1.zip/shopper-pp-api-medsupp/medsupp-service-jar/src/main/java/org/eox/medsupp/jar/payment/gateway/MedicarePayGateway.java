/**
 * MedicarePayGateway.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 03/25/2019  1.0      Cognizant       SMC mail changes
 */
package org.eox.medsupp.jar.payment.gateway;


import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.eox.medsupp.datasvc.payment.entity.PaymentDetailsLog;
import org.eox.medsupp.datasvc.payment.entity.PaymentMethodLog;
import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.paymod.request.PayModSubmitPaymentRequest;
import org.eox.medsupp.paymod.response.PayModSubmitPaymentResponse;
import org.eox.medsupp.schema.domain.transcentra.GetDocumentsServiceResponse;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceRequest;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceResponse;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.MedicareBillDetails;
import org.eox.medsupp.schema.model.MedicarePayBillAccount;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;
import org.eox.medsupp.schema.model.SOAMemberProfile;
import org.eox.medsupp.schema.request.GetAccountSummaryRequest;
import org.eox.medsupp.schema.request.GetMbrContactMethodServiceRequest;
import org.eox.medsupp.schema.request.GetViewBillRequest;
import org.eox.medsupp.schema.request.MemberBillingSummaryRequest;
import org.eox.medsupp.schema.request.UpdatePaperBillServiceRequest;
import org.eox.medsupp.schema.request.ViewPaymentHistoryRequest;
import org.eox.medsupp.schema.response.GetAccountSummaryResponse;
import org.eox.medsupp.schema.response.GetMbrContactMethodServiceResponse;
import org.eox.medsupp.schema.response.GetViewBillResponse;
import org.eox.medsupp.schema.response.MemberBillingSummaryResponse;
import org.eox.medsupp.schema.response.UpdatePaperBillServiceResponse;
import org.eox.medsupp.schema.response.ViewPaymentHistoryResponse;
import org.springframework.integration.annotation.Gateway;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Component
public interface MedicarePayGateway
{

	@Async
	@Gateway(requestChannel = "saveTptInChannel")
	public void saveTPTServiceLog(TPTServicesLog tPTServicesLog) throws MedicarePayException;

	@Async
	@Gateway(requestChannel = "savePaymentMethodInChannel")
	public void savePaymentMethodLog(PaymentMethodLog paymentMethodLog) throws MedicarePayException;

	@Async
	@Gateway(requestChannel = "savePaymentDetailsInChannel")
	public void savePaymentDetailsLog(PaymentDetailsLog paymentDetailsLog) throws MedicarePayException;

	@Gateway(requestChannel = "getMbrContactMethodRequestChannel", replyChannel = "getMbrContactMethodResponseChannel")
	public GetMbrContactMethodServiceResponse getEBillIndicator(GetMbrContactMethodServiceRequest getSummaryBillDuesDetailsServiceRequest)
			throws MedicarePayException;

	@Gateway(requestChannel = "updatePaperBillRequestChannel", replyChannel = "updatePaperBillResponseChannel")
	public UpdatePaperBillServiceResponse updatePaperBill(UpdatePaperBillServiceRequest updatePaperBillServiceRequest);

	@Async
	@Gateway(requestChannel = "getMemberProfileInChannel", replyChannel = "getMemberProfileOutChannel")
	public Future<GetAccountSummaryResponse> getMemberProfile(GetAccountSummaryRequest request) throws MedicarePayException;

	@Gateway(requestChannel = "pdfAvailabilitySplitterChannel", replyChannel = "pdfAvailabilityAggregateChannel")
	public List<MedicareBillDetails> findPdfAvailabilityForBillAccounts(List<MedicareBillDetails> medicareBillDetails,
			@Header("memberState") String memberState, @Header("hcid") String hcid) throws MedicarePayException;

	@Gateway(requestChannel = "pdfAvailabilityForSingleBillRequestChannel", replyChannel = "pdfAvailabilityForSingleBillResponseChannel")
	public Object findPdfAvailabilityForSingleBill(MedicareBillDetails memberPayBillAccount, @Header("memberState") String memberState,
			@Header("hcid") String hcid) throws MedicarePayException;

	@Async
	@Gateway(requestChannel = "getMemberProfileAsyncInChannel", replyChannel = "getMemberProfileAsyncOutChannel")
	public Future<GetAccountSummaryResponse> getMemberProfileAsync(GetAccountSummaryRequest request) throws MedicarePayException;

	@Gateway(requestChannel = "getViewBillRequestChannel", replyChannel = "getViewBillResponseChannel")
	public GetViewBillResponse getViewBill(GetViewBillRequest request);

	@Gateway(requestChannel = "getTranscentraBillRequestChannel", replyChannel = "getTranscentraBillResponseChannel")
	public GetDocumentsServiceResponse getTranscentraBill(SearchDocumentsServiceRequest searchDocumentsServiceRequest);
	
	@Gateway(requestChannel = "searchTranscentraBillRequestChannel", replyChannel = "searchTranscentraBillResponseChannel")
	public SearchDocumentsServiceResponse searchTranscentraBill(SearchDocumentsServiceRequest searchDocumentsServiceRequest);
	
	@Async
	@Gateway(requestChannel = "getPaymentHistoryMemberProfileInChannel", replyChannel = "getPaymentHistoryMemberProfileOutChannel")
	public Future<ViewPaymentHistoryResponse> getEligibilityProfile(ViewPaymentHistoryRequest newReq);

	@Async
	@Gateway(requestChannel = "getBillsSummaryInChannel", replyChannel = "getBillsSummaryOutChannel")
	public Future<MemberBillingSummaryResponse> callBillSummaryService(	MemberBillingSummaryRequest memberSummaryRequest);

	@Async
	@Gateway(requestChannel = "sendPaySuccessSOAMailInChannel")
	public void sendPaySuccessMail(@Header("modelMap") Map<String, Object> modelMap, MemberPaySubmitPayment memPaySubmitPayment, @Header("hcidInRequest") String hcidInRequest) throws MedicarePayException;
	
	@Async
	@Gateway(requestChannel = "sendFailedPayMailInChannel")
	public void sendFailedPayMail(Map<String, Object> modelMap) throws MedicarePayException;
	
	@Gateway(requestChannel = "pdfSplitterChannel", replyChannel = "pdfAggregateChannel")
	public List<MedicarePayBillAccount> findPdfForBillAccounts(List<MedicarePayBillAccount> billAccounts,
			@Header("memberState") String memberState, @Header("hcid") String hcid) throws MedicarePayException;
	
	@Async
	@Gateway(requestChannel = "triggerPayModSubmitPaymentsReqChannel", replyChannel = "triggerPayModSubmitPaymentsResChannel")
	public Future<PayModSubmitPaymentResponse> triggerPayModSubmitPayments(PayModSubmitPaymentRequest request);
	
	//PP-15970 - Start
	@Async
	@Gateway(requestChannel = "sendPaymentSMCMailInChannel")
	public void sendPaymentSMCMail(SOAMemberProfile sOAMemberProfile, @Header("mailType") String mailType) throws MedicarePayException;
	//PP-15970 - End
}
