package org.eox.medsupp.jar.payment.util;

import java.util.List;

import org.eox.medsupp.schema.model.MedicarePayBillAccount;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Component
public class MedicareBillAccountSplitter
{
	public List<MedicarePayBillAccount> splitBillAccountForPdf(List<MedicarePayBillAccount> billAccounts,
			@Header("memberState") String memberState, @Header("hcid") String hcid)
	{
		return billAccounts;
	}
}
