/**
 * WsTracingInterceptor.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.transformer;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.jar.payment.util.MedicarePayUtils;
import org.eox.medsupp.jar.payment.util.WebServiceUtils;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapMessage;


@Component
public class WsTracingInterceptor implements ClientInterceptor, MedicarePayConstants
{
	final static Logger LOGGER = Logger.getLogger(WsTracingInterceptor.class);

	@Autowired
	private WebServiceUtils webServiceUtils;

	private static final String WS_CONTEXT_LOG_ID = "WS_CONTEXT_LOG_ID";
	private static final String WS_CONTEXT_OPERATION_NAME = "WS_CONTEXT_OPERATION";
	private static final String WS_CONTEXT_TRANS_ID = "WS_CONTEXT_TRANS_ID";
	private static final String WS_TPT_TRANS_LOG_ID = "WS_TPT_TRANS_LOG_ID";
	private static final String[] FORBIDDEN_OPERATIONS_TO_LOG = { OPERATION_NAME_CHUB_GET, OPERATION_NAME_CHUB_UPDATE,
			OPERATION_NAME_TRANSCENTRA_SEARCHDOC, OPERATION_NAME_TRANSCENTRA_GETDOC };

	@Override
	public boolean handleRequest(MessageContext messageContext)
	{
		LOGGER.debug("OUTGOING REQUEST FOR OPERATION-->::" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME));
		WebServiceMessage message = messageContext.getRequest();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(byos);

		try
		{
			message.writeTo(out);
			TPTServicesLog request = webServiceUtils.prepareTptLogRequest(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString(),
					null != messageContext.getProperty(WS_CONTEXT_LOG_ID) ? messageContext.getProperty(WS_CONTEXT_LOG_ID).toString() : "",
					byos.toString());

			messageContext.setProperty(WS_TPT_TRANS_LOG_ID, request);

			/* LOGGER.debug(byos.toString()); */
		} catch (Exception e)
		{
			if (isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString()))
			{
				LOGGER.error("Exception in handleRequest of WsTracingInterceptor:" + e.getMessage());
			}
		}
		messageContext.removeProperty(WS_CONTEXT_LOG_ID);
		messageContext.removeProperty(WS_CONTEXT_TRANS_ID);
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext)
	{
		LOGGER.debug("INCOMING RESPONSE FOR OPERATION-->::" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME));
		WebServiceMessage messageResponse = messageContext.getResponse();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(byos);
		try
		{
			messageResponse.writeTo(out);
			TPTServicesLog tPTServicesLog = (TPTServicesLog) messageContext.getProperty(WS_TPT_TRANS_LOG_ID);
			tPTServicesLog.setResponseXml(byos.toString());
			tPTServicesLog.setResponseTs(Calendar.getInstance().getTime());
			SoapFault soapFault = (((SoapMessage) messageResponse).getSoapBody()).getFault();
			if (null != soapFault)
			{
				WebServiceMessage messageRequest = messageContext.getRequest();
				ByteArrayOutputStream byosRequest = new ByteArrayOutputStream();
				PrintStream in = new PrintStream(byosRequest);
				messageRequest.writeTo(in);
				if (isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString()))
				{
					LOGGER.error("OUTGOING REQUEST  :" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME) + ":"
							+ MedicarePayUtils.getEncodedText(byosRequest.toString()));
					LOGGER.error("INCOMING RESPONSE :" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME) + ":"
							+ MedicarePayUtils.getEncodedText(byos.toString()));
				}
			}
			webServiceUtils.addTptTransactionToLog(tPTServicesLog);
			messageContext.removeProperty(WS_CONTEXT_OPERATION_NAME);
			messageContext.removeProperty(WS_TPT_TRANS_LOG_ID);

		} catch (Exception e)
		{
			if (isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString()))
			{
				LOGGER.error("Exception in handleResponse of WsTracingInterceptor:" + MedicarePayUtils.getEncodedText(e.getMessage()));
			}
		}
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext)
	{
		LOGGER.error("Error Message is ");
		WebServiceMessage message = messageContext.getResponse();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(byos);
		try
		{
			message.writeTo(out);
			TPTServicesLog tPTServicesLog = (TPTServicesLog) messageContext.getProperty(WS_TPT_TRANS_LOG_ID);
			tPTServicesLog.setResponseXml(byos.toString());
			tPTServicesLog.setIsBusinessFault("true");
			tPTServicesLog.setResponseTs(Calendar.getInstance().getTime());
			webServiceUtils.addTptTransactionToLog(tPTServicesLog);
			WebServiceMessage messageRequest = messageContext.getRequest();
			ByteArrayOutputStream byosRequest = new ByteArrayOutputStream();
			PrintStream in = new PrintStream(byosRequest);
			messageRequest.writeTo(in);
			if (isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString()))
			{
				LOGGER.error("OUTGOING REQUEST  :" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME) + ":"
						+ MedicarePayUtils.getEncodedText(byosRequest.toString()));
				LOGGER.error("INCOMING RESPONSE :" + messageContext.getProperty(WS_CONTEXT_OPERATION_NAME) + ":"
						+ MedicarePayUtils.getEncodedText(byos.toString()));
			}

		} catch (Exception ioException)
		{
			if (isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString()))
			{
				LOGGER.error("Exception in handleFault of WsTracingInterceptor:"
						+ MedicarePayUtils.getEncodedText(ioException.getMessage()));
			}
		}
		messageContext.removeProperty(WS_CONTEXT_OPERATION_NAME);
		messageContext.removeProperty(WS_TPT_TRANS_LOG_ID);
		return true;
	}

	private boolean isAllowedToLog(String operationName)
	{
		if (!Arrays.asList(FORBIDDEN_OPERATIONS_TO_LOG).contains(operationName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException
	{
		// TODO Auto-generated method stub

	}

}