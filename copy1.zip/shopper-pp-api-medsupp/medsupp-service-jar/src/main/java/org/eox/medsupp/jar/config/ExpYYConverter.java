/**
 * ExpYYConverter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.config;


import org.dozer.DozerConverter;
import org.springframework.util.StringUtils;


public class ExpYYConverter extends DozerConverter<String, String>
{

	public ExpYYConverter()
	{
		super(String.class, String.class);
	}

	@Override
	public String convertFrom(String source, String destination)
	{
		if (source != null)
		{
			if (source.length() == 7)
			{
				return convertMMYYYYtoYY(source);
			}
			else
			{
				return convertYYYYtoExp(source, destination);
			}
		}
		return source;
	}

	private String convertMMYYYYtoYY(String source)
	{
		if (source != null && !StringUtils.isEmpty(source.length()))
		{
			return source.split("/")[1];
		}
		return source;
	}

	private String convertYYYYtoExp(String sourceYY, String destination)
	{
		if (destination == null)
		{
			return new StringBuilder().append("/").append(sourceYY).toString();
		}
		return new StringBuilder().append(destination).append("/").append(sourceYY).toString();
	}

	@Override
	public String convertTo(String source, String destination)
	{
		return convertFrom(source, destination);
	}

}
