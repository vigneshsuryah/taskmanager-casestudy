/**
 * CredtiCardTypeConverter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.config;


import org.dozer.DozerConverter;
import org.eox.medsupp.schema.model.MedicarePayAcctTypeEnum;

import com.wellpoint.aci.enums.CreditCardType;


public class CredtiCardTypeConverter extends DozerConverter<CreditCardType, MedicarePayAcctTypeEnum>
{

	public CredtiCardTypeConverter()
	{
		super(CreditCardType.class, MedicarePayAcctTypeEnum.class);
	}

	@Override
	public MedicarePayAcctTypeEnum convertTo(CreditCardType source, MedicarePayAcctTypeEnum destination)
	{
		MedicarePayAcctTypeEnum result = MedicarePayAcctTypeEnum.PERSONALCHECKING;
		switch (source)
		{
		case AMEX:
			break;
		case DISC:
			break;
		case MASTERCARD:
			result = MedicarePayAcctTypeEnum.MASTERCARD;
			break;
		case MC:
			result = MedicarePayAcctTypeEnum.MASTERCARD;
			break;
		case VISA:
			result = MedicarePayAcctTypeEnum.VISA;
			break;
		default:
			break;
		}
		return result;
	}

	@Override
	public CreditCardType convertFrom(MedicarePayAcctTypeEnum source, CreditCardType destination)
	{
		CreditCardType result = CreditCardType.VISA;
		switch (source)
		{
		case BUSCHECKING:
			break;
		case BUSSAVINGS:
			break;
		case MASTERCARD:
			result = CreditCardType.MC;
			break;
		case MC:
			result = CreditCardType.MC;
			break;
		case NONE:
			break;
		case PERSONALCHECKING:
			break;
		case PERSONALSAVINGS:
			break;
		case VISA:
			result = CreditCardType.VISA;
			break;
		default:
			break;

		}
		return result;
	}

}
