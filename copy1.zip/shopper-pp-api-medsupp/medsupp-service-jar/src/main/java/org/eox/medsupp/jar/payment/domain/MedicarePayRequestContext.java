/**
 * MedicarePayRequestContext.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.domain;


import java.io.Serializable;


public class MedicarePayRequestContext implements Serializable
{

	private static final long serialVersionUID = 1L;

	private Object request;
	private String metaSrcEnv;
	private String inputHcid;
	private String sbrUid;

	private MedicarePayRequestContext(Builder b)
	{
		this.request = b.request;
		this.metaSrcEnv = b.metaSrcEnv;
		this.inputHcid = b.inputHcid;
	}

	public Object getRequest()
	{
		return request;
	}

	public String getMetaSrcEnv()
	{
		return metaSrcEnv;
	}

	public String getInputHcid()
	{
		return inputHcid;
	}

	public String getSbrUid()
	{
		return sbrUid;
	}

	public static class Builder
	{
		private String inputHcid;
		private Object request;
		private String metaSrcEnv;

		public Builder(String inputHcid)
		{
			super();
			this.inputHcid = inputHcid;
		}

		public Builder metaSrcEnv(String meta)
		{
			this.metaSrcEnv = meta;
			return this;
		}

		public Builder requestObj(Object obj)
		{
			this.request = obj;
			return this;
		}

		public MedicarePayRequestContext build()
		{
			return new MedicarePayRequestContext(this);
		}
	}

}
