/**
 * BankTypeConverter.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.config;


import org.dozer.DozerConverter;
import org.eox.medsupp.schema.model.MedicarePayAcctTypeEnum;

import com.wellpoint.aci.enums.BankAccountType;


public class BankTypeConverter extends DozerConverter<MedicarePayAcctTypeEnum, BankAccountType>
{

	public BankTypeConverter()
	{
		super(MedicarePayAcctTypeEnum.class, BankAccountType.class);
	}

	@Override
	public BankAccountType convertTo(MedicarePayAcctTypeEnum source, BankAccountType destination)
	{
		BankAccountType result = BankAccountType.PERSONAL_CHECKING;
		switch (source)
		{
		case BUSCHECKING:
			result = BankAccountType.BUSINESS_CHECKING;
			break;
		case BUSSAVINGS:
			result = BankAccountType.BUSINESS_SAVINGS;
			break;
		case MASTERCARD:
			break;
		case MC:
			break;
		case NONE:
			break;
		case PERSONALCHECKING:
			result = BankAccountType.PERSONAL_CHECKING;
			break;
		case PERSONALSAVINGS:
			result = BankAccountType.PERSONAL_SAVINGS;
			break;
		case VISA:
			break;
		default:
			break;
		}
		return result;
	}

	@Override
	public MedicarePayAcctTypeEnum convertFrom(BankAccountType source, MedicarePayAcctTypeEnum destination)
	{
		MedicarePayAcctTypeEnum result = MedicarePayAcctTypeEnum.PERSONALCHECKING;
		switch (source)
		{
		case BUSINESS_CHECKING:
			result = MedicarePayAcctTypeEnum.BUSCHECKING;
			break;
		case BUSINESS_SAVINGS:
			result = MedicarePayAcctTypeEnum.BUSSAVINGS;
			break;
		case MONEY_MARKET:
			break;
		case PERSONAL_CHECKING:
			result = MedicarePayAcctTypeEnum.PERSONALCHECKING;
			break;
		case PERSONAL_SAVINGS:
			result = MedicarePayAcctTypeEnum.PERSONALSAVINGS;
			break;
		default:
			break;

		}
		return result;
	}

}
