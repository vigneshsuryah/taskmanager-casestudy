/**
 * MedicarePayUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/05/2019  2.0      Cognizant       CSR - Chase Integration
 */
package org.eox.medsupp.jar.payment.util;


import java.math.RoundingMode;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.configuration.AbstractConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.eox.medsupp.schema.domain.transcentra.SearchDocumentsServiceRequest;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.BrandEmailMatrix;
import org.eox.medsupp.schema.request.GetEligibilityRequest;
import org.eox.medsupp.schema.request.MemberBillingSummaryRequest;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.eox.medsupp.schema.utility.MedicarePayEncryptionUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicPropertyUpdater;
import com.netflix.config.DynamicStringProperty;
import com.netflix.config.PollResult;
import com.wellpoint.aci.request.BaseRequest;
import com.wellpoint.aci.request.RequestHeader;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;

@Component
@RefreshScope
public class MedicarePayUtils implements MedicarePayConstants
{
	private static final Logger LOGGER = Logger.getLogger(MedicarePayUtils.class);

	@Value("${medicarepay.setting.payment.service.username.ACI}")
	private String aciUserName;

	@Value("${medicarepay.setting.payment.service.password.ACI}")
	private String aciPwd;

	@Value("${medicarepay.setting.payment.service.key.ACI}")
	private String aciKey;

	@Value("${medicarepay.setting.payment.service.algorithm.ACI}")
	private String aciAlgorithm;
	
	private DynamicPropertyUpdater dynamicPropertyUpdater = new DynamicPropertyUpdater();

	/**
	 * Returns BaseRequest object with requestHeader
	 * @param targetClass
	 * @return
	 * @throws MedicarePayException
	 */
	@SuppressWarnings("unchecked")
	public <T extends BaseRequest> T getRequestInstance(Class<? extends BaseRequest> targetClass) throws MedicarePayException
	{
		BaseRequest request = null;
		try
		{
			LOGGER.info("Inside MemberPayHelperUtils.getRequestInstance ");
			RequestHeader requestHeader = new RequestHeader();

			requestHeader.setUserName(aciUserName);
			try
			{
				requestHeader.setPassword(MedicarePayEncryptionUtils.getEncryptedText(aciKey, aciAlgorithm, aciPwd));
			} catch (MedicarePayException e)
			{
				LOGGER.error("Exception in AciRestUtils setRequestHeader : " + e);
			}
			request = (BaseRequest) targetClass.newInstance();
			request.setRequestHeader(requestHeader);
			LOGGER.info("Request header has been set for the class::" + targetClass.getCanonicalName());
		} catch (Exception e)
		{
			LOGGER.error("Possibly illegal class passed as argument::" + e.getCause());
			throw new MedicarePayException("Error in getting Payment Method");
		}
		return (T) request;
	}

	/**
	 * Validates the end point	
	 * @param requestingApplication
	 * @param endPointName
	 * @return
	 */
	public static boolean checkReqAppEndPoint(String requestingApplication, String endPointName)
	{
		boolean flag = false;
		try
		{
			String allowedEndpointsString = getStringProperty("medicarepay.setting.requestingapplication.allow.endpoint."
					+ requestingApplication, "");
			String[] allowedEndpointsList = checkNullForAString(allowedEndpointsString) ? allowedEndpointsString.split(",") : null;
			if (null != allowedEndpointsList && Arrays.asList(allowedEndpointsList).contains(endPointName))
			{
				flag = true;
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in checkReqAppEndPoint : " + e);
		}
		return flag;
	}

	/**
	 * Checks for null and empty list
	 * 
	 * @param listObject
	 * @return True or False
	 */
	public static Boolean checkNullForAList(List<?> listObject) throws MedicarePayException
	{
		try
		{
			if (listObject != null && listObject.size() > 0)
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new MedicarePayException("");
		}
	}

	/**
	 * Split Date To MMddyyyy Format
	 * @param dateString
	 * @return
	 * @throws MedicarePayException
	 */
	public String splitDateToMMddyyyyFormat(String dateString) throws MedicarePayException
	{
		StringBuffer value = new StringBuffer();
		if (checkNullForAString(dateString) && dateString.length() == 10 && isDateValid(dateString, "yyyy-MM-dd"))
		{
			value.append(dateString.substring(5, 7));
			value.append("/");
			value.append(dateString.substring(8, 10));
			value.append("/");
			value.append(dateString.substring(0, 4));
			return value.toString();
		}
		else
		{
			return null;
		}
	}

	/**
	 * Check for null and empty string
	 * 
	 * @param value
	 * @return Boolean
	 * @throws MemberPayException
	 */
	public static Boolean checkNullForAString(String value) throws MedicarePayException
	{
		try
		{
			if (null != value && !value.trim().isEmpty())
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new MedicarePayException("");
		}
	}

	/**
	 * Checks whether date is valid
	 * @param date
	 * @param format
	 * @return
	 */
	public static boolean isDateValid(String date, String format)
	{
		boolean isValidDate = false;
		try
		{
			if(checkNullForAString(date)) {
				DateFormat df = new SimpleDateFormat(format);
				df.setLenient(false);
				df.parse(date);
				isValidDate = true;
			}
		} catch (ParseException e)
		{
			isValidDate = false;
		} catch (Exception e)
		{
			isValidDate = false;
		}
		return isValidDate;
	}

	/**
	 * Encodes the input text
	 * @param value
	 * @return
	 */
	public static String getEncodedText(String value)
	{
		String encoded = "";
		
		try
		{
			if(checkNullForAString(value))
			{
				StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
				encryptor.setPassword(getStringProperty("medicarepay.setting.ui.restconsumer.service.username",""));
				encoded = encryptor.encrypt(value);
			}
		} catch (Exception e)
		{
			try
			{
				byte[] message = value.getBytes("UTF-8");
				encoded = DatatypeConverter.printBase64Binary(message);
			} catch (Exception e1)
			{
				encoded = value;
			}
		}
		return encoded;
	}

	/**
	 * Returns meta-senderapp from http header
	 * @param httpRequest
	 * @return
	 */
	public static String getMetaSenderAppValue(HttpServletRequest httpRequest)
	{
		String value = "";
		try
		{
			value = httpRequest.getHeader("meta-senderapp");
		} catch (Exception e)
		{
			LOGGER.error("Error occured in fetching meta-senderapp header : " + e);
		}
		return value;
	}

	/**
	 * Changes date based on input value
	 * @param i
	 * @return
	 */
	public Date changeDate(int i)
	{
		Date currentDate = new Date(System.currentTimeMillis());
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		cal.add(Calendar.MONTH, i);

		return cal.getTime();
	}

	/**
	 * Returns eligibility request object for payment history
	 * @param hcid
	 * @return
	 * @throws MedicarePayException
	 */
	public GetEligibilityRequest getEligibilityRequest(String hcid) throws MedicarePayException
	{
		GetEligibilityRequest eligibilityRequest = new GetEligibilityRequest();
		eligibilityRequest.setMemberId(hcid);
		eligibilityRequest.setMemberIdType("HCID");
		eligibilityRequest.setStartDate(getDateForString(changeDate(-18), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
		eligibilityRequest.setEndDate(getDateForString(changeDate(6), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
		return eligibilityRequest;
	}
	
	/**
	 * Returns eligibility request object for account summary
	 * @param hcid
	 * @return
	 * @throws MedicarePayException
	 */
	public GetEligibilityRequest getEligibilityRequestForAccSummary(String hcid) throws MedicarePayException
	{
		GetEligibilityRequest eligibilityRequest = new GetEligibilityRequest();
		eligibilityRequest.setMemberId(hcid);
		eligibilityRequest.setMemberIdType("HCID");
		eligibilityRequest.setStartDate(getDateForString(changeDate(-12), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
		eligibilityRequest.setEndDate(getDateForString(changeDate(6), "yyyy-MM-dd'T'HH:mm:ss'Z'"));
		return eligibilityRequest;
	}

	/**
	 * Converts string to date
	 * @param date
	 * @param format
	 * @return
	 */
	public static Date getDateByString(String date, String format)
	{
		Date formattedDate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		try
		{
			if (checkNullForAString(date))
			{
				formattedDate = simpleDateFormat.parse(date);
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in getDateByString : " + e);
		}
		return formattedDate;
	}

	/**
	 * Converts date to string
	 * @param date
	 * @return
	 */
	public static String dateToStr(Date date)
	{
		String dateStr = "";
		try
		{
			if(null != date)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				dateStr = sdf.format(date);
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in dateToStr : " + e);
		}
		return dateStr;
	}

	/**
	 * Trims Char By Length
	 * @param str
	 * @param length
	 * @return
	 */
	public static String trimCharByLength(String str, int length)
	{
		String value = "";
		if (null != str && str.length() > length)
		{
			value = str.substring(0, length);
		}
		else
		{
			value = str;
		}
		return value;
	}

	/**
	 * Reads property value based on key
	 * @param key
	 * @param defaultValue
	 * @return
	 */
	public static String getStringProperty(String key, String defaultValue)
	{
		final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, defaultValue);
		return property.get();
	}

	/**
	 * Adds daycount to today's date
	 * @param fromDate
	 * @param targetFormat
	 * @param daycount
	 * @return
	 * @throws MedicarePayException
	 */
	public static String addDay(String fromDate, String targetFormat, int daycount) throws MedicarePayException
	{
		LOGGER.info("Inside addOneDay");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(getDateByString(fromDate, targetFormat));
		calendar.add(Calendar.DATE, daycount);
		LOGGER.info("Completed addOneDay");
		return getDateForString(calendar.getTime(), targetFormat);
	}

	/**
	 * Converts date to string
	 * @param date
	 * @param format
	 * @return
	 * @throws MedicarePayException
	 */
	public static String getDateForString(Date date, String format) throws MedicarePayException
	{
		String dateInStr = null;
		try
		{
			if (null != date)
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
				dateInStr = simpleDateFormat.format(date);
			}
		} catch (Exception e)
		{
			throw new MedicarePayException(e, "Error in formatting the date value");
		}
		return dateInStr;
	}

	/**
	 * Returns Brand Matrix Details based on lob, groupId, classId and state
	 * @param lineOfBusiness
	 * @param groupId
	 * @param classId
	 * @param state
	 * @return
	 */
	public static BrandEmailMatrix getBrandMatrixDetails(String lineOfBusiness, String groupId, String classId, String state, String planId)
	{
		BrandEmailMatrix brandEmailMatrix = null;
		try
		{
			String noClassIdStr = getStringProperty("medicare.all.classid", "");
			String classIds= getStringProperty("medicare.in.put.planid."+groupId, "");
			boolean includePlanId = Boolean.FALSE;
			List<String> noClassIdList = new ArrayList<>();
			if (null != noClassIdStr)
			{
				noClassIdList = Arrays.asList(noClassIdStr.split(","));
				if(null!=classIds && !classIds.isEmpty()){
					if(classIds.contains(classId)){
						includePlanId  = Boolean.TRUE;
					}
				}
			}
			
			StringBuffer sb = new StringBuffer();
			lineOfBusiness = null != lineOfBusiness ? lineOfBusiness.toUpperCase() : "";
			sb.append(lineOfBusiness);
			sb.append(".");
			sb.append(groupId);
			sb.append(".");
			sb.append(state);
			if (!noClassIdList.contains(groupId))
			{
				sb.append(".");
				sb.append(classId);
			}
			if(includePlanId){
				
				sb.append(".");
				sb.append(planId);
				
			}
			String brandMatrix = getStringProperty(sb.toString(), "");
			String brandLineItem = getStringProperty(brandMatrix, "");
			if (null != brandLineItem && !brandLineItem.isEmpty())
			{
				String[] brandMatrixArr = brandLineItem.split("\\|\\|");
				brandEmailMatrix = new BrandEmailMatrix();
				brandEmailMatrix.setImageName(brandMatrixArr[0]);
				brandEmailMatrix.setPlanWebsiteUrl(brandMatrixArr[1]);
				brandEmailMatrix.setMsgCenterLink(brandMatrixArr[2]);
				brandEmailMatrix.setCustomerServiceText(brandMatrixArr[3]);
				brandEmailMatrix.setTtyUserText(brandMatrixArr[4]);
				brandEmailMatrix.setCompanyName(brandMatrixArr[5]);
				brandEmailMatrix.setBrandName(brandMatrixArr[6]);
				brandEmailMatrix.setAlternateLangLink(brandMatrixArr[7]);
				brandEmailMatrix.setFederalContractStmt(brandMatrixArr[8]);
				brandEmailMatrix.setPrivacyPolicyLink(brandMatrixArr[9]);
				brandEmailMatrix.setTaglineText(brandMatrixArr[10]);
				brandEmailMatrix.setReturnAddress(brandMatrixArr[11]);
				brandEmailMatrix.setShowPartBPremium(brandMatrixArr[12]);
				brandEmailMatrix.setAutoPayPdfName(brandMatrixArr[13]);
				brandEmailMatrix.setInvoiceMaterialId(brandMatrixArr[14]);
				brandEmailMatrix.setPayReturnMaterialId(brandMatrixArr[15]);
				brandEmailMatrix.setLinkAccMaterialId(brandMatrixArr[16]);
				brandEmailMatrix.setUnLinkAccMaterialId(brandMatrixArr[17]);
				brandEmailMatrix.setInvoiceComplianceCode(brandMatrixArr[18]);
				brandEmailMatrix.setPayReturnComplianceCode(brandMatrixArr[19]);
				brandEmailMatrix.setLinkAccComplianceCode(brandMatrixArr[20]);
				brandEmailMatrix.setUnLinkAccComplianceCode(brandMatrixArr[21]);
				brandEmailMatrix.setBrandId(brandMatrixArr[22]);
				brandEmailMatrix.setBrandAbbr(brandMatrixArr[23]);
			} else {
				LOGGER.error("Unable to determine brand matrix for : " + brandMatrix);
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in getBrandMatrixDetails : " + e);
		}

		return brandEmailMatrix;
	}

	/**
	 * Returns abbreviation for the brand
	 * @param brandName
	 * @return
	 */
	public static String getBrandNameAbbr(String brandName)
	{
		String brandAbbr = "";
		switch (brandName.trim())
		{
		case "Anthem Blue Cross":
		{
			brandAbbr = "ABC";
			break;
		}
		case "Anthem Blue Cross and Blue Shield":
		{
			brandAbbr = "ABCBS";
			break;
		}
		case "Blue Cross and Blue Shield of Georgia, Inc.":
		{
			brandAbbr = "BCBSGA";
			break;
		}
		case "Empire BlueCross BlueShield":
		{
			brandAbbr = "EBCBS";
			break;
		}
		case "Empire BlueCross":
		{
			brandAbbr = "EBC";
			break;
		}
		case "Anthem Blue Cross Life and Health Insurance Company":
		{
			brandAbbr = "ABC";
			break;
		}
		case "Blue Cross Blue Shield Healthcare Plan of Georgia, Inc.":
		{
			brandAbbr = "BCBSGA";
			break;
		}
		case "Anthem HealthKeepers":
		{
			brandAbbr = "ABC";
			break;
		}
		default:
		{
			brandAbbr = "";
			break;
		}
		}
		return brandAbbr;

	}

	/**
	 * Returns requesting system value
	 * @return
	 */
	public static String getRequestingSystem()
	{
		String requestingSystem = "";
		try
		{
			String value = (String) MDC.get("requestingApplication");
			if (checkNullForAString(value))
			{
				requestingSystem = value;
			}
		} catch (Exception e)
		{
			LOGGER.error("Error in MedicarePayUtils requestingSystem : " + e);
		}
		return requestingSystem;
	}

	/**
	 * Returns doc type value to the get Document Splitter class
	 * @param m
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public String getDocValue(Message m)
	{
		String docValue = "";
		SearchDocumentsServiceRequest req = (SearchDocumentsServiceRequest) m.getPayload();
		if (null != req)
		{
			docValue = req.getDocumentValue();
		}
		return docValue;
	}

	/**
	 * Formats bill date for Transcentra search document request
	 * @param date
	 * @param format
	 * @param currentFormat
	 * @return
	 */
	public static String formatBillDate(String date, String format, String currentFormat)
	{
		String formattedDate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		SimpleDateFormat sdf = new SimpleDateFormat(currentFormat);
		try
		{
			if (checkNullForAString(date))
			{
				formattedDate = simpleDateFormat.format(sdf.parse(date));
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in formatBillDate : " + e);
		}
		return formattedDate;
	}
	

	public MemberBillingSummaryRequest helpWithHistoryRequest(String hcid, String groupId) throws MedicarePayException {
		MemberBillingSummaryRequest memberBillingSummaryRequest = new MemberBillingSummaryRequest();
		memberBillingSummaryRequest.setMemberId(hcid);
		memberBillingSummaryRequest.setGroupId(groupId);
		memberBillingSummaryRequest.setMemberIdType("HCID");
		memberBillingSummaryRequest.setStartDate(getDateForString(changeDate(-18),"yyyy-MM-dd'T'HH:mm:ss'Z'"));
		memberBillingSummaryRequest.setEndDate(getDateForString(changeDate(0),"yyyy-MM-dd'T'HH:mm:ss'Z'"));
		return memberBillingSummaryRequest;
	}

	public Date getDate(String dte)  throws MedicarePayException{

		Date d=null;
		try {
			d = new SimpleDateFormat("yyyy-MM-dd").parse(dte);
		} catch (ParseException e) {
			LOGGER.error("cannot set the format to y-m-d format");
			throw new MedicarePayException();
		}
		return d;

}
	/**
	 * Removes error code from ACI service message
	 * @param completeMessageText
	 * @return
	 */
	public static String removeErrCode(String completeMessageText)
	{
		String returnString = null;
		if(null != completeMessageText && !completeMessageText.isEmpty())
		{
			String[] array = completeMessageText.split("\\(");
			returnString = array[0];
		}
		return returnString;
	}

	
	public static String formatInputDate(String strDate) throws MedicarePayException{
		StringBuffer value = new StringBuffer();
		if (checkNullForAString(strDate) && strDate.length() == 10 && isDateValid(strDate, "yyyy-MM-dd"))
		{
			value.append(strDate.substring(5, 7));
			value.append("/");
			value.append(strDate.substring(8, 10));
			value.append("/");
			value.append(strDate.substring(0, 4));
			return value.toString();
		}
		else
		{
			return null;
		}
	}
	
	public void updateProperties() {
		try {
			AbstractConfiguration config= ConfigurationManager.getConfigInstance();
			if (config instanceof DynamicConfiguration) {
				PollResult result = ((DynamicConfiguration) config).getSource().poll(false, null);
				dynamicPropertyUpdater.updateProperties(result, config, false);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in updateProperties() of MedicarePayUtils MEDSUPP : " + e);
		}
	}
	
	/**
	 * Formats date with specified format
	 * @param date
	 * @param format
	 * @return
	 */
	public static String formatDate(Date date, String format)
	{
		String formattedDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try
		{
			if (null != date)
			{
				formattedDate = sdf.format(date);
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in formatDate : " + e);
		}
		return formattedDate;
	}
	
	public static String getCurrentDateTimezoneString(){
		GregorianCalendar gCal = new GregorianCalendar();
		gCal.setTime(new Date());
		StringBuilder dateStr = new StringBuilder();
		try {
			XMLGregorianCalendar gDateUnformated = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCal);
			dateStr.append(gDateUnformated.toString());
			dateStr.append("[");
			dateStr.append(gCal.getTimeZone().getID());
			dateStr.append("]");
		} catch (DatatypeConfigurationException e) {
			dateStr = new StringBuilder();
			LOGGER.error("Exception in getCurrentDateTimezoneString formatting timezone date format "+e);
		}
		return dateStr.toString();
	}
	
	/*PP-6431,PP-6432,PP-6433,PP-9107 GA rebranding starts*/

	/**
	 * Checks whether current date is greater than or equal to Jan 1, 2019
	 * @param currentDate
	 * @param nextDate
	 * @return
	 */
	public static boolean checkFutureDate(Date currentDate, Date nextDate){
		boolean isFutureDate = false;
		if (null != currentDate && currentDate.compareTo(nextDate) >= 0) {
			isFutureDate = true;
		}
		return isFutureDate; 
	}
	
	public static boolean checkForGARebrand(String state, String effDate)
	{
		boolean isFutureDate = false;
		if(GA_STATE_STR.equalsIgnoreCase(state)){
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FMT);
			String todayDateChangeRequired = MedicarePayUtils.getStringProperty(GA_RE_BRAND_TODAY_DATE_CHANGE_REQUIRED,GA_TODAY_DATE_CHANGE_REQUIRED);
			Date currentDate = null;
			if(null != todayDateChangeRequired && todayDateChangeRequired.equalsIgnoreCase("Y")) {
				String todayDateChangeString = MedicarePayUtils.getStringProperty(GA_RE_BRAND_TODAY_DATE_CHANGE,GA_REBRAND_DEF_DATE);
				currentDate = MedicarePayUtils.getDateByString(todayDateChangeString,DATE_FMT);
			}else {
				currentDate = MedicarePayUtils.getDateByString(simpleDateFormat.format(new Date()), DATE_FMT);
			}
			Date gaRebrandDate = MedicarePayUtils.getDateByString(MedicarePayUtils.getStringProperty(MEDICAREPAY_SETTING_GA_REBRANDING_DATE,GA_REBRAND_DEF_DATE),DATE_FMT);
			String effDateChangeRequired = MedicarePayUtils.getStringProperty(GA_RE_BRAND_EFF_DATE_CHANGE_REQUIRED,GA_TODAY_DATE_CHANGE_REQUIRED);
			Date effectiveDate = null;
			if(null != effDateChangeRequired && effDateChangeRequired.equalsIgnoreCase("Y")) {
				String effDateChangeString = MedicarePayUtils.getStringProperty(GA_RE_BRAND_EFF_DATE_CHANGE,GA_REBRAND_DEF_DATE);
				effectiveDate = MedicarePayUtils.getDateByString(effDateChangeString,DATE_FMT);
			}else {
				effectiveDate = MedicarePayUtils.getDateByString(effDate, DATE_FMT);
			}
			if(MedicarePayUtils.checkFutureDate(currentDate,gaRebrandDate) || MedicarePayUtils.checkFutureDate(effectiveDate, gaRebrandDate)){
				isFutureDate = true;
			}
		}
		return isFutureDate;
	}
	
	/*PP-6431,PP-6432,PP-6433,PP-9107 GA rebranding ends*/
	
	/**
	 * Returns csrId from http header
	 * @param httpRequest
	 * @return
	 */
	public static String getCsrIdValueFromRequest(HttpServletRequest httpRequest)
	{
		String value = "";
		try
		{
			value = httpRequest.getHeader("csrId");
		} catch (Exception e)
		{
			LOGGER.error("Error occured in fetching csrId header : " + e);
		}
		return value;
	}
	
	/**
	 * Returns lob from http header
	 * @param httpRequest
	 * @return
	 */
	public static String getLOBValueFromRequest(HttpServletRequest httpRequest)
	{
		String value = "";
		try
		{
			value = httpRequest.getHeader("lob");
		} catch (Exception e)
		{
			LOGGER.error("Error occured in fetching lob header : " + e);
		}
		return value;
	}
	
	public static String maskString(String strText, int start, int end, char maskChar) throws MedicarePayException{
		String maskedStr = "";
		try{
			if(strText == null || strText.equals(""))
				return "";

			if(start < 0)
				start = 0;

			if( end > strText.length() )
				end = strText.length();

			if(start > end){
				LOGGER.error("End index cannot be greater than start index");
				throw new MedicarePayException("E", "PP9000", TECHNICAL_ERROR_MSG, 500);
			}

			int maskLength = end - start;

			if(maskLength == 0)
				return strText;

			String strMaskString = org.apache.commons.lang3.StringUtils.repeat(maskChar, maskLength);
			maskedStr = org.apache.commons.lang3.StringUtils.overlay(strText, strMaskString, start, end);
		}catch(Exception e){
			LOGGER.error("Exception in maskString"+e);
		}
		return maskedStr;
	}
	
	//PP-14143 starts
	public static List<String> getCsrRoleValueFromRequest(HttpServletRequest httpRequest)
	{
		String value = "";
		List<String> csrRoleList = null;
		try
		{
			value = httpRequest.getHeader("csrRole");
			if(null != value && !value.isEmpty()) {
				csrRoleList = new ArrayList<>();
				String[] childHcidArr = value.split(",");
				for (String str : childHcidArr)
				{
					csrRoleList.add(str);
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Error occured in fetching csrRole header : " + e);
		}
		return csrRoleList;
	}
	//PP-14143 ends

	public static String getPayModMatch() {
		String matchId = "";
		try {
			SecureRandom secureRandom = new SecureRandom();
			String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
			String numbers = "0123456789";
			int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
			int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
			matchId = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
			matchId = matchId.toUpperCase() + Long.toString(System.currentTimeMillis());
		} catch (Exception e) {
			System.out.println("Exception -- while getPayModMatch " + e.toString());
		}
		if(matchId != null && StringUtils.isNotBlank(matchId) && StringUtils.isNotEmpty(matchId)) {
			matchId = matchId.toLowerCase();
		}
		return matchId;
	}
	
	public static void setReturnErrorMessage(String errorCode, String errorMessage, MemberPaySubmitPayment request) {
		org.eox.medsupp.schema.response.Message returnMessage = new org.eox.medsupp.schema.response.Message();
		returnMessage.setMessageCode(errorCode);
		returnMessage.setMessageText(errorMessage);
		request.setMessage(returnMessage);
	}
	
	public static boolean validateCCExpirationString(String expString) {
		boolean flag = true;
		DateFormat dateFormatYear = new SimpleDateFormat("yyyy");
		DateFormat dateFormatMonth = new SimpleDateFormat("MM");
		String currentYearString = dateFormatYear.format(Calendar.getInstance().getTime());
		int currentYear = Integer.parseInt(currentYearString);
		String currentMonthString = dateFormatMonth.format(Calendar.getInstance().getTime());
		int currentMonth = Integer.parseInt(currentMonthString);
		if (expString != null && !expString.isEmpty())
		{
			String[] expArr = {};
			expArr = expString.split("/");
			if(expArr.length == 2 && expArr[0].length() == 2 && expArr[1].length() == 4) {
				int month = 0;
				int year = 0;
				try {
					month = Integer.parseInt(expArr[0]);
					year = Integer.parseInt(expArr[1]);
				}catch(Exception e) {
					LOGGER.error("Error in validateCCExpirationString");
				}
				if(year > currentYear) {
                    if(month < 1 || month > 12) {
                           flag = false;
                    }else {
                           flag = true;
                    }
		         }else if(year == currentYear) {
	                if(month < currentMonth || month > 12) {
	                       flag = false;
	                }else {
	                       flag = true;
	                }
		         }else {
		            flag = false;
		         }
			}else {
				flag = false;
			}
		}else {
			flag = false;
		}
		return flag;
	}
	
	public static boolean isRoutingNoValid(String routingNo)
	{
		final int FIRST_MULTIPLER = 3;
		final int SECOND_MULTIPLER = 7;
		final int THIRD_MULTIPLER = 1;
		if (!StringUtils.isNumeric(routingNo) || routingNo.length() != 9)
		{
			return false;
		}
		char[] routingArray = routingNo.toCharArray();
		int firstNumber = Integer.parseInt(String.valueOf(routingArray[0]));
		int secondNumber = Integer.parseInt(String.valueOf(routingArray[1]));
		int thridNumber = Integer.parseInt(String.valueOf(routingArray[2]));
		int fourthNumber = Integer.parseInt(String.valueOf(routingArray[3]));
		int fifthNumber = Integer.parseInt(String.valueOf(routingArray[4]));
		int sixthNumber = Integer.parseInt(String.valueOf(routingArray[5]));
		int seventhNumber = Integer.parseInt(String.valueOf(routingArray[6]));
		int eighthNumber = Integer.parseInt(String.valueOf(routingArray[7]));
		int checkDigit = Integer.parseInt(String.valueOf(routingArray[8]));
		int productsSumOrg = (firstNumber * FIRST_MULTIPLER) + (fourthNumber * FIRST_MULTIPLER) + (seventhNumber * FIRST_MULTIPLER)
				+ (secondNumber * SECOND_MULTIPLER) + (fifthNumber * SECOND_MULTIPLER) + (eighthNumber * SECOND_MULTIPLER)
				+ (thridNumber * THIRD_MULTIPLER) + (sixthNumber * THIRD_MULTIPLER);
		int productsSumArr = productsSumOrg;
		if (productsSumOrg % 10 > 0)
		{
			productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
		}
		if (productsSumArr - productsSumOrg == checkDigit)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static String roundUp(String receivedValue, int digits) {
        Double receivedDoubleValue = Double.parseDouble(receivedValue);
        StringBuffer sb = new StringBuffer();
        sb.append("#");
        if(digits != 0){
        	sb.append(".");
            for(int i=0;i<digits;i++){
            	sb.append("0");
            }
        }
        DecimalFormat df = new DecimalFormat(sb.toString());
        df.setRoundingMode(RoundingMode.DOWN);
        String formattedValue = df.format(receivedDoubleValue);
        if(null != formattedValue && formattedValue.startsWith(".")) {
        	formattedValue = "0" + formattedValue;
        }
        return formattedValue;
    }
	
	public static String generateOrderId(String payChannel) {
		String orderId = "";
		try {
			Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
            SecureRandom secureRandom = new SecureRandom();
            String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
            String numbers = "0123456789";
            int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
            int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
            String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
            String shortId = RandomStringUtils.random(7, "0123456789");
            orderId = payChannel + dateFormat.format(date) + randomChar + shortId;
		} catch (Exception e) {
			System.out.println("Exception -- while generateOrderId " + e.toString());
		}
		if(orderId != null && StringUtils.isNotBlank(orderId) && StringUtils.isNotEmpty(orderId)) {
			orderId = orderId.toLowerCase();
		}
		return orderId;
	}
	
	public static String getCorrectedDate(String requestDate) {
		String correctedDate = requestDate;

		String HOUR_FORMAT = "HH:mm";
		SimpleDateFormat sdfHour = new SimpleDateFormat(HOUR_FORMAT);
		String now = sdfHour.format(Calendar.getInstance(Locale.US).getTime());

		String start = "00:00";
		String end = "03:00";
		boolean isPresentHourInTheInterval = ((now.compareTo(start) >= 0) && (now.compareTo(end) <= 0));

		String YYYYMMDD = "yyyy-MM-dd";
		SimpleDateFormat yyyymmddFormat = new SimpleDateFormat(YYYYMMDD);
		Date paymentDate = convertStringToDate(requestDate, YYYYMMDD);
		Date currentDate = convertStringToDate(yyyymmddFormat.format(Calendar.getInstance(Locale.US).getTime()), YYYYMMDD);

		long diff = currentDate.getTime() - paymentDate.getTime();
		int diffDays = (int) (diff / (24 * 60 * 60 * 1000));

		if (paymentDate.compareTo(currentDate) < 0 && isPresentHourInTheInterval && diffDays == 1) {
			correctedDate = yyyymmddFormat.format(Calendar.getInstance(Locale.US).getTime());
		}

		return correctedDate;
	}
	
	public static Date convertStringToDate(String strDate, String format)
	{
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
		formatter.setLenient(false);
		Date date = null;
		try
		{
			date = formatter.parse(strDate);
		} catch (ParseException e)
		{
			LOGGER.error("Parse Exception occured while converting string to date" + e);
		}
		return date;
	}
	
	/* PayMod changes - end */
}
