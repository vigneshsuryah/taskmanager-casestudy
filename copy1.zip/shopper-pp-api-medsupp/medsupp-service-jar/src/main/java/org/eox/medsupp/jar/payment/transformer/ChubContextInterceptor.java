/**
 * ChubContextInterceptor.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.jar.payment.transformer;


import javax.xml.bind.JAXBElement;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPPart;

import org.apache.log4j.Logger;
import org.eox.medsupp.chub.service.MembershipServiceGetMbrContactMethodRequestType;
import org.eox.medsupp.chub.service.MembershipServiceUpdateMbrContactMethodRequestType;
import org.eox.medsupp.jar.payment.util.WebServiceUtils;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;


@Component
public class ChubContextInterceptor implements ClientInterceptor, MedicarePayConstants
{
	private static final Logger LOGGER = Logger.getLogger(ChubContextInterceptor.class);
	private static final String CONTEXT_STR = "con";

	@Autowired
	private Jaxb2Marshaller chubMarshaller;

	@Autowired
	private WebServiceUtils webServiceUtils;

	@Override
	public boolean handleRequest(MessageContext messageContext)
	{
		LOGGER.info("ChubContextInterceptor handleRequest=====================================>>>>>>>>>>>>>>>>>>>");
		WebServiceMessage message = messageContext.getRequest();
		try
		{
			SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();

			SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
			javax.xml.soap.SOAPMessage soapMessage1 = saajSoapMessage.getSaajMessage();

			SOAPPart soapPart = soapMessage1.getSOAPPart();
			SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
			SOAPHeader soapHeader = soapEnvelope.getHeader();

			SoapBody requestBody = soapMessage.getSoapBody();
			Object requestBodyObj = chubMarshaller.unmarshal(requestBody.getPayloadSource());
			JAXBElement<?> jaxbElement = (JAXBElement<?>) requestBodyObj;

			Name contextheaderName = soapEnvelope.createName("Context", CONTEXT_STR, "http://wellpoint.com/esb/context");
			SOAPHeaderElement soapESBHeaderElmt = soapHeader.addHeaderElement(contextheaderName);

			SOAPElement domainNameSOAPElement = soapESBHeaderElmt.addChildElement("domainName", CONTEXT_STR);
			domainNameSOAPElement.addTextNode("Membership");

			SOAPElement srvcNameSOAPElement = soapESBHeaderElmt.addChildElement("srvcName", CONTEXT_STR);
			srvcNameSOAPElement.addTextNode("MembershipService");

			SOAPElement srvcVersionSOAPElement = soapESBHeaderElmt.addChildElement("srvcVersion", CONTEXT_STR);
			srvcVersionSOAPElement.addTextNode("1.0");

			SOAPElement senderAppSOAPElement = soapESBHeaderElmt.addChildElement("senderApp", CONTEXT_STR);
			senderAppSOAPElement.addTextNode("PPORT");

			SOAPElement msgTypSOAPElement = soapESBHeaderElmt.addChildElement("msgTyp", CONTEXT_STR);
			msgTypSOAPElement.addTextNode("REQUEST");

			SOAPElement operNameSOAPElement = soapESBHeaderElmt.addChildElement("operName", CONTEXT_STR);

			if (jaxbElement.getValue() instanceof MembershipServiceUpdateMbrContactMethodRequestType)
			{
				MembershipServiceUpdateMbrContactMethodRequestType req = (MembershipServiceUpdateMbrContactMethodRequestType) jaxbElement
						.getValue();
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getUpdateMbrContactMethodRequest().getMbrInfo().getMember()
						.getSubscriberId());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, OPERATION_NAME_CHUB_UPDATE);
				operNameSOAPElement.addTextNode(OPERATION_NAME_CHUB_UPDATE);
			}
			else if (jaxbElement.getValue() instanceof MembershipServiceGetMbrContactMethodRequestType)
			{
				MembershipServiceGetMbrContactMethodRequestType req = (MembershipServiceGetMbrContactMethodRequestType) jaxbElement
						.getValue();
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getGetMbrContactMethodRequest().getMbrInfo().getMember()
						.getSubscriberId());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, OPERATION_NAME_CHUB_GET);
				operNameSOAPElement.addTextNode(OPERATION_NAME_CHUB_GET);
			}

			SOAPElement operVersionSOAPElement = soapESBHeaderElmt.addChildElement("operVersion", CONTEXT_STR);
			operVersionSOAPElement.addTextNode("1.0");

			SOAPElement transIdSOAPElement = soapESBHeaderElmt.addChildElement("transId", CONTEXT_STR);
			String transId = webServiceUtils.getTransactionId();
			transIdSOAPElement.addTextNode(transId);
			messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);

		} catch (javax.xml.soap.SOAPException e)
		{
			LOGGER.error("SOAP Exception in ChubContextInterceptor  handleRequest method  -->" + e.getMessage());
		} catch (Exception e)
		{
			LOGGER.error("Exception in ChubContextInterceptor", e);
		}
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext)
	{
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext)
	{
		return true;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException
	{
		// TODO Auto-generated method stub

	}

}