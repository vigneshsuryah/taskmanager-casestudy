package org.eox.medsupp.schema.response;

import java.io.Serializable;

public class SOASMCEmailResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7685922636762123664L;

	private String status;
	
	private String message;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
