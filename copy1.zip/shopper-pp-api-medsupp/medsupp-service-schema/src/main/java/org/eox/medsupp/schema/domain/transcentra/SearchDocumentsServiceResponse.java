/**
 * SearchDocumentsServiceResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.transcentra;


import java.math.BigInteger;


public class SearchDocumentsServiceResponse
{
	private BigInteger documentId;

	public BigInteger getDocumentId()
	{
		return documentId;
	}

	public void setDocumentId(BigInteger documentId)
	{
		this.documentId = documentId;
	}

}
