/**
 * PayerId.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

public class PayerId {

	private String type;
	private String id;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
