package org.eox.medsupp.schema.request;


public class GetLinkedAccountRequest extends BaseRequest
{

	private static final long serialVersionUID = 1L;

}
