/**
 * ExceptionResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.exception;


import java.io.Serializable;
import java.util.List;


public class ExceptionResponse implements Serializable
{
	private static final long serialVersionUID = 1L;

	private List<org.eox.medsupp.schema.exception.Exception> exceptions;

	public List<org.eox.medsupp.schema.exception.Exception> getExceptions()
	{
		return exceptions;
	}

	public void setExceptions(List<org.eox.medsupp.schema.exception.Exception> exceptions)
	{
		this.exceptions = exceptions;
	}
}
