/**
 * MedicarePayBillAccount.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class MedicarePayBillAccount implements Serializable
{
	private static final long serialVersionUID = -3856466529186538430L;
	private String productId;
	private String planName;
	private Date billDate;
	private Date dueDate;
	private Date paidToDate;
	private String subGroupName;
	private float minDue;
	private float totalDue;
	private MedicarePayPayment memberPayment;
	private MedicarePayPaymentStatus paymentStatus;
	private String billFrequency;
	private String subGroupId;
	private String coverageStatus;
	/* PP-104 Change starts */
	private boolean isPdfBillAvailable;
	/* PP-104 Change ends */
	/* PP-318 Change starts */
	private String billSource;

	private List<String> subGroupIds;

	private String billType;

  /*Async call chnages start*/
	private String groupId;
	private String lineOfBusiness;
	private String paymentMethod;
	private String billProcessedDate;
	private String primaryMemberHcid;
	private String billGroupId;
	
	/**
	 * @return the groupId
	 */
	public String getGroupId()
	{
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	@JsonIgnore
	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	/**
	 * @param lineOfBusiness the lineOfBusiness to set
	 */
	@JsonIgnore
	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod()
	{
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	@JsonIgnore
	public void setPaymentMethod(String paymentMethod)
	{
		this.paymentMethod = paymentMethod;
	}

	/**
	 * @return the billProcessedDate
	 */
	public String getBillProcessedDate()
	{
		return billProcessedDate;
	}

	/**
	 * @param billProcessedDate the billProcessedDate to set
	 */
	@JsonIgnore
	public void setBillProcessedDate(String billProcessedDate)
	{
		this.billProcessedDate = billProcessedDate;
	}

	/**
	 * @return the primaryMemberHcid
	 */
	public String getPrimaryMemberHcid()
	{
		return primaryMemberHcid;
	}

	/**
	 * @param primaryMemberHcid the primaryMemberHcid to set
	 */
	@JsonIgnore
	public void setPrimaryMemberHcid(String primaryMemberHcid)
	{
		this.primaryMemberHcid = primaryMemberHcid;
	}

	/**
	 * @return the billGroupId
	 */
	public String getBillGroupId()
	{
		return billGroupId;
	}

	/**
	 * @param billGroupId the billGroupId to set
	 */
	@JsonIgnore
	public void setBillGroupId(String billGroupId)
	{
		this.billGroupId = billGroupId;
	}
	/*Async call chnages - end*/
	
	public String getBillSource()
	{
		return billSource;
	}

	public void setBillSource(String billSource)
	{
		this.billSource = billSource;
	}

	/* PP-318 Change ends */
	public String getCoverageStatus()
	{
		return coverageStatus;
	}

	public void setCoverageStatus(String coverageStatus)
	{
		this.coverageStatus = coverageStatus;
	}

	public String getSubGroupId()
	{
		return subGroupId;
	}

	public void setSubGroupId(String subGroupId)
	{
		this.subGroupId = subGroupId;
	}

	public String getProductId()
	{
		return productId;
	}

	public void setProductId(String productId)
	{
		this.productId = productId;
	}

	public String getPlanName()
	{
		return planName;
	}

	public void setPlanName(String planName)
	{
		this.planName = planName;
	}

	public Date getBillDate()
	{
		return billDate;
	}

	public void setBillDate(Date billDate)
	{
		this.billDate = billDate;
	}

	public Date getDueDate()
	{
		return dueDate;
	}

	public void setDueDate(Date dueDate)
	{
		this.dueDate = dueDate;
	}

	public String getSubGroupName()
	{
		return subGroupName;
	}

	public void setSubGroupName(String subGroupName)
	{
		this.subGroupName = subGroupName;
	}

	public float getMinDue()
	{
		return minDue;
	}

	public void setMinDue(float minDue)
	{
		this.minDue = minDue;
	}

	public float getTotalDue()
	{
		return totalDue;
	}

	public void setTotalDue(float totalDue)
	{
		this.totalDue = totalDue;
	}

	public MedicarePayPayment getMedicarePayment()
	{
		return memberPayment;
	}

	public void setMedicarePayment(MedicarePayPayment memberPayment)
	{
		this.memberPayment = memberPayment;
	}

	public MedicarePayPaymentStatus getPaymentStatus()
	{
		return paymentStatus;
	}

	public void setPaymentStatus(MedicarePayPaymentStatus paymentStatus)
	{
		this.paymentStatus = paymentStatus;
	}

	public Date getPaidToDate()
	{
		return paidToDate;
	}

	public void setPaidToDate(Date paidToDate)
	{
		this.paidToDate = paidToDate;
	}

	public String getBillFrequency()
	{
		return billFrequency;
	}

	public void setBillFrequency(String billFrequency)
	{
		this.billFrequency = billFrequency;
	}

	/* PP-104 Changes Starts */
	public boolean isPdfBillAvailable()
	{
		return isPdfBillAvailable;
	}

	public void setPdfBillAvailable(boolean isPdfBillAvailable)
	{
		this.isPdfBillAvailable = isPdfBillAvailable;
	}

	/* PP-104 Changes Ends */

	public List<String> getSubGroupIds()
	{
		return subGroupIds;
	}

	public void setSubGroupIds(List<String> subGroupIds)
	{
		this.subGroupIds = subGroupIds;
	}

	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}

}
