/**
* EventHeader.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class EventHeader implements Serializable{

	private static final long serialVersionUID = 5194852526936664206L;
	private String eventDomain;
	private String eventGenerationTimestamp;
	private String eventGenerator;
	private String sourceSystemId;
	private String transId;
	
	public String getEventDomain() {
		return eventDomain;
	}
	public void setEventDomain(String eventDomain) {
		this.eventDomain = eventDomain;
	}
	public String getEventGenerationTimestamp() {
		return eventGenerationTimestamp;
	}
	public void setEventGenerationTimestamp(String eventGenerationTimestamp) {
		this.eventGenerationTimestamp = eventGenerationTimestamp;
	}
	public String getEventGenerator() {
		return eventGenerator;
	}
	public void setEventGenerator(String eventGenerator) {
		this.eventGenerator = eventGenerator;
	}
	public String getSourceSystemId() {
		return sourceSystemId;
	}
	public void setSourceSystemId(String sourceSystemId) {
		this.sourceSystemId = sourceSystemId;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
}
