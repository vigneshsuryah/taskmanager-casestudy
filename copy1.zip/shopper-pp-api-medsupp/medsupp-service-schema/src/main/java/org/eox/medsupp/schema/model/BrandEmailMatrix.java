package org.eox.medsupp.schema.model;

import java.io.Serializable;


public class BrandEmailMatrix implements Serializable
{

	private static final long serialVersionUID = 8911195899119805164L;
	private String imageName;
	private String planWebsiteUrl;
	private String msgCenterLink;
	private String customerServiceText;
	private String ttyUserText;
	private String companyName;
	private String brandName;
	private String alternateLangLink;
	private String federalContractStmt;
	private String privacyPolicyLink;
	private String taglineText;
	private String returnAddress;
	private String showPartBPremium;
	private String autoPayPdfName;
	private String invoiceMaterialId;
	private String payReturnMaterialId;
	private String linkAccMaterialId;
	private String unLinkAccMaterialId;
	private String invoiceComplianceCode;
	private String payReturnComplianceCode;
	private String linkAccComplianceCode;
	private String unLinkAccComplianceCode;
	private String brandId;
	private String brandAbbr;

	/**
	 * @return the brandId
	 */
	public String getBrandId()
	{
		return brandId;
	}

	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(String brandId)
	{
		this.brandId = brandId;
	}

	/**
	 * @return the brandAbbr
	 */
	public String getBrandAbbr()
	{
		return brandAbbr;
	}

	/**
	 * @param brandAbbr the brandAbbr to set
	 */
	public void setBrandAbbr(String brandAbbr)
	{
		this.brandAbbr = brandAbbr;
	}

	/**
	 * @return the invoiceMaterialId
	 */
	public String getInvoiceMaterialId()
	{
		return invoiceMaterialId;
	}

	/**
	 * @param invoiceMaterialId
	 *            the invoiceMaterialId to set
	 */
	public void setInvoiceMaterialId(String invoiceMaterialId)
	{
		this.invoiceMaterialId = invoiceMaterialId;
	}

	/**
	 * @return the payReturnMaterialId
	 */
	public String getPayReturnMaterialId()
	{
		return payReturnMaterialId;
	}

	/**
	 * @param payReturnMaterialId
	 *            the payReturnMaterialId to set
	 */
	public void setPayReturnMaterialId(String payReturnMaterialId)
	{
		this.payReturnMaterialId = payReturnMaterialId;
	}

	/**
	 * @return the linkAccMaterialId
	 */
	public String getLinkAccMaterialId()
	{
		return linkAccMaterialId;
	}

	/**
	 * @param linkAccMaterialId
	 *            the linkAccMaterialId to set
	 */
	public void setLinkAccMaterialId(String linkAccMaterialId)
	{
		this.linkAccMaterialId = linkAccMaterialId;
	}

	/**
	 * @return the unLinkAccMaterialId
	 */
	public String getUnLinkAccMaterialId()
	{
		return unLinkAccMaterialId;
	}

	/**
	 * @param unLinkAccMaterialId
	 *            the unLinkAccMaterialId to set
	 */
	public void setUnLinkAccMaterialId(String unLinkAccMaterialId)
	{
		this.unLinkAccMaterialId = unLinkAccMaterialId;
	}

	/**
	 * @return the invoiceComplianceCode
	 */
	public String getInvoiceComplianceCode()
	{
		return invoiceComplianceCode;
	}

	/**
	 * @param invoiceComplianceCode
	 *            the invoiceComplianceCode to set
	 */
	public void setInvoiceComplianceCode(String invoiceComplianceCode)
	{
		this.invoiceComplianceCode = invoiceComplianceCode;
	}

	/**
	 * @return the payReturnComplianceCode
	 */
	public String getPayReturnComplianceCode()
	{
		return payReturnComplianceCode;
	}

	/**
	 * @param payReturnComplianceCode
	 *            the payReturnComplianceCode to set
	 */
	public void setPayReturnComplianceCode(String payReturnComplianceCode)
	{
		this.payReturnComplianceCode = payReturnComplianceCode;
	}

	/**
	 * @return the linkAccComplianceCode
	 */
	public String getLinkAccComplianceCode()
	{
		return linkAccComplianceCode;
	}

	/**
	 * @param linkAccComplianceCode
	 *            the linkAccComplianceCode to set
	 */
	public void setLinkAccComplianceCode(String linkAccComplianceCode)
	{
		this.linkAccComplianceCode = linkAccComplianceCode;
	}

	/**
	 * @return the unLinkAccComplianceCode
	 */
	public String getUnLinkAccComplianceCode()
	{
		return unLinkAccComplianceCode;
	}

	/**
	 * @param unLinkAccComplianceCode
	 *            the unLinkAccComplianceCode to set
	 */
	public void setUnLinkAccComplianceCode(String unLinkAccComplianceCode)
	{
		this.unLinkAccComplianceCode = unLinkAccComplianceCode;
	}

	/**
	 * @return the autoPayPdfName
	 */
	public String getAutoPayPdfName()
	{
		return autoPayPdfName;
	}

	/**
	 * @param autoPayPdfName
	 *            the autoPayPdfName to set
	 */
	public void setAutoPayPdfName(String autoPayPdfName)
	{
		this.autoPayPdfName = autoPayPdfName;
	}

	/**
	 * @return the imageName
	 */
	public String getImageName()
	{
		return imageName;
	}

	/**
	 * @param imageName
	 *            the imageName to set
	 */
	public void setImageName(String imageName)
	{
		this.imageName = imageName;
	}

	/**
	 * @return the planWebsiteUrl
	 */
	public String getPlanWebsiteUrl()
	{
		return planWebsiteUrl;
	}

	/**
	 * @param planWebsiteUrl
	 *            the planWebsiteUrl to set
	 */
	public void setPlanWebsiteUrl(String planWebsiteUrl)
	{
		this.planWebsiteUrl = planWebsiteUrl;
	}

	/**
	 * @return the msgCenterLink
	 */
	public String getMsgCenterLink()
	{
		return msgCenterLink;
	}

	/**
	 * @param msgCenterLink
	 *            the msgCenterLink to set
	 */
	public void setMsgCenterLink(String msgCenterLink)
	{
		this.msgCenterLink = msgCenterLink;
	}

	/**
	 * @return the customerServiceText
	 */
	public String getCustomerServiceText()
	{
		return customerServiceText;
	}

	/**
	 * @param customerServiceText
	 *            the customerServiceText to set
	 */
	public void setCustomerServiceText(String customerServiceText)
	{
		this.customerServiceText = customerServiceText;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName()
	{
		return companyName;
	}

	/**
	 * @param companyName
	 *            the companyName to set
	 */
	public void setCompanyName(String companyName)
	{
		this.companyName = companyName;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName()
	{
		return brandName;
	}

	/**
	 * @param brandName
	 *            the brandName to set
	 */
	public void setBrandName(String brandName)
	{
		this.brandName = brandName;
	}

	/**
	 * @return the alternateLangLink
	 */
	public String getAlternateLangLink()
	{
		return alternateLangLink;
	}

	/**
	 * @param alternateLangLink
	 *            the alternateLangLink to set
	 */
	public void setAlternateLangLink(String alternateLangLink)
	{
		this.alternateLangLink = alternateLangLink;
	}

	/**
	 * @return the federalContractStmt
	 */
	public String getFederalContractStmt()
	{
		return federalContractStmt;
	}

	/**
	 * @param federalContractStmt
	 *            the federalContractStmt to set
	 */
	public void setFederalContractStmt(String federalContractStmt)
	{
		this.federalContractStmt = federalContractStmt;
	}

	/**
	 * @return the privacyPolicyLink
	 */
	public String getPrivacyPolicyLink()
	{
		return privacyPolicyLink;
	}

	/**
	 * @param privacyPolicyLink
	 *            the privacyPolicyLink to set
	 */
	public void setPrivacyPolicyLink(String privacyPolicyLink)
	{
		this.privacyPolicyLink = privacyPolicyLink;
	}

	/**
	 * @return the taglineText
	 */
	public String getTaglineText()
	{
		return taglineText;
	}

	/**
	 * @param taglineText
	 *            the taglineText to set
	 */
	public void setTaglineText(String taglineText)
	{
		this.taglineText = taglineText;
	}

	/**
	 * @return the returnAddress
	 */
	public String getReturnAddress()
	{
		return returnAddress;
	}

	/**
	 * @param returnAddress
	 *            the returnAddress to set
	 */
	public void setReturnAddress(String returnAddress)
	{
		this.returnAddress = returnAddress;
	}

	/**
	 * @return the showPartBPremium
	 */
	public String getShowPartBPremium()
	{
		return showPartBPremium;
	}

	/**
	 * @param showPartBPremium
	 *            the showPartBPremium to set
	 */
	public void setShowPartBPremium(String showPartBPremium)
	{
		this.showPartBPremium = showPartBPremium;
	}

	/**
	 * @return the ttyUserText
	 */
	public String getTtyUserText() {
		return ttyUserText;
	}

	/**
	 * @param ttyUserText the ttyUserText to set
	 */
	public void setTtyUserText(String ttyUserText) {
		this.ttyUserText = ttyUserText;
	}
	
}
