package org.eox.medsupp.schema.request;

import java.io.Serializable;

public class MemberBillingSummaryRequest implements Serializable{

	private static final long serialVersionUID = 3236594727845973424L;

	private String memberIdType;
	private String startDate;
	private String endDate;
	private String memberId;
	private String groupId;
	public String getMemberIdType() {
		return memberIdType;
	}
	public void setMemberIdType(String memberIdType) {
		this.memberIdType = memberIdType;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	
}
