/**
 * BaseResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.io.Serializable;

import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.MemberPaySourceSystemEnum;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseResponse implements Serializable
{

	private static final long serialVersionUID = -2077482251622980335L;

	private MedicarePayException medicarePayException;
	private MemberPaySourceSystemEnum sourceSystem;
	private Message message;

	public MedicarePayException getMedicarePayException()
	{
		return medicarePayException;
	}

	public void setMedicarePayException(MedicarePayException medicarePayException)
	{
		this.medicarePayException = medicarePayException;
	}

	public MemberPaySourceSystemEnum getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(MemberPaySourceSystemEnum sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public Message getMessage()
	{
		return message;
	}

	public void setMessage(Message message)
	{
		this.message = message;
	}

}
