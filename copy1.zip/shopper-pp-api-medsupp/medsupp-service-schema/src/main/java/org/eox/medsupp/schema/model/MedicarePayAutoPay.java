/**
 * Address.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;

import java.io.Serializable;


public class MedicarePayAutoPay implements Serializable
{

	private static final long serialVersionUID = -6013253719332531130L;

	private String lineOfBusiness;

	private String pdfName;

	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	/**
	 * @param lineOfBusiness
	 *            the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * @return the pdfName
	 */
	public String getPdfName()
	{
		return pdfName;
	}

	/**
	 * @param pdfName
	 *            the pdfName to set
	 */
	public void setPdfName(String pdfName)
	{
		this.pdfName = pdfName;
	}

}
