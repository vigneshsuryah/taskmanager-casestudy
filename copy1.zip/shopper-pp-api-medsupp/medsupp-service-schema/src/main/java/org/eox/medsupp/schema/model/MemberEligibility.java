/**
 * MemberEligibility.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberEligibility implements Serializable
{

	private static final long serialVersionUID = 8947177104871872176L;

	private MemberDemographicDetails memberDemographicDetails;

	private String stateId;

	private String coverageStatusCode;

	private String enterpriseBrand;

	private String classID;

	private String dateEffective;

	private String dateTermination;

	private String planState;

	private String groupID;

	private HealthCardId healthCardId;

	private String medicaidID;

	private String planID;

	private String planIdDescription;

	private String productDescription;

	private String productID;

	private String productName;

	private String sbrUid;

	private String subgroupID;

	private String type;

	private String coverageTypeCode;

	private String coverageTypeDescription;

	private String tobaccostatus;

	private String divisionCode;

	@JsonProperty("BillDetails")
	private BillDetails billDetails;

	/**
	 * @return the classID
	 */
	public String getClassID()
	{
		return classID;
	}

	/**
	 * @param classID
	 *            the classID to set
	 */
	public void setClassID(String classID)
	{
		this.classID = classID;
	}

	/**
	 * @return the groupID
	 */
	public String getGroupID()
	{
		return groupID;
	}

	/**
	 * @param groupID
	 *            the groupID to set
	 */
	public void setGroupID(String groupID)
	{
		this.groupID = groupID;
	}

	/**
	 * @return the medicaidID
	 */
	public String getMedicaidID()
	{
		return medicaidID;
	}

	/**
	 * @param medicaidID
	 *            the medicaidID to set
	 */
	public void setMedicaidID(String medicaidID)
	{
		this.medicaidID = medicaidID;
	}

	/**
	 * @return the planID
	 */
	public String getPlanID()
	{
		return planID;
	}

	/**
	 * @param planID
	 *            the planID to set
	 */
	public void setPlanID(String planID)
	{
		this.planID = planID;
	}

	/**
	 * @return the productID
	 */
	public String getProductID()
	{
		return productID;
	}

	/**
	 * @param productID
	 *            the productID to set
	 */
	public void setProductID(String productID)
	{
		this.productID = productID;
	}

	/**
	 * @return the subgroupID
	 */
	public String getSubgroupID()
	{
		return subgroupID;
	}

	/**
	 * @param subgroupID
	 *            the subgroupID to set
	 */
	public void setSubgroupID(String subgroupID)
	{
		this.subgroupID = subgroupID;
	}

	/**
	 * @return the billDetails
	 */
	public BillDetails getBillDetails()
	{
		return billDetails;
	}

	/**
	 * @param billDetails
	 *            the billDetails to set
	 */
	public void setBillDetails(BillDetails billDetails)
	{
		this.billDetails = billDetails;
	}

	/**
	 * @return the memberDemographicDetails
	 */
	public MemberDemographicDetails getMemberDemographicDetails()
	{
		return memberDemographicDetails;
	}

	/**
	 * @param memberDemographicDetails
	 *            the memberDemographicDetails to set
	 */
	public void setMemberDemographicDetails(MemberDemographicDetails memberDemographicDetails)
	{
		this.memberDemographicDetails = memberDemographicDetails;
	}

	/**
	 * @return the stateId
	 */
	public String getStateId()
	{
		return stateId;
	}

	/**
	 * @param stateId
	 *            the stateId to set
	 */
	public void setStateId(String stateId)
	{
		this.stateId = stateId;
	}

	/**
	 * @return the coverageStatusCode
	 */
	public String getCoverageStatusCode()
	{
		return coverageStatusCode;
	}

	/**
	 * @param coverageStatusCode
	 *            the coverageStatusCode to set
	 */
	public void setCoverageStatusCode(String coverageStatusCode)
	{
		this.coverageStatusCode = coverageStatusCode;
	}

	/**
	 * @return the enterpriseBrand
	 */
	public String getEnterpriseBrand()
	{
		return enterpriseBrand;
	}

	/**
	 * @param enterpriseBrand
	 *            the enterpriseBrand to set
	 */
	public void setEnterpriseBrand(String enterpriseBrand)
	{
		this.enterpriseBrand = enterpriseBrand;
	}

	/**
	 * @return the dateEffective
	 */
	public String getDateEffective()
	{
		return dateEffective;
	}

	/**
	 * @param dateEffective
	 *            the dateEffective to set
	 */
	public void setDateEffective(String dateEffective)
	{
		this.dateEffective = dateEffective;
	}

	/**
	 * @return the dateTermination
	 */
	public String getDateTermination()
	{
		return dateTermination;
	}

	/**
	 * @param dateTermination
	 *            the dateTermination to set
	 */
	public void setDateTermination(String dateTermination)
	{
		this.dateTermination = dateTermination;
	}

	/**
	 * @return the planState
	 */
	public String getPlanState()
	{
		return planState;
	}

	/**
	 * @param planState
	 *            the planState to set
	 */
	public void setPlanState(String planState)
	{
		this.planState = planState;
	}

	/**
	 * @return the healthCardId
	 */
	public HealthCardId getHealthCardId()
	{
		return healthCardId;
	}

	/**
	 * @param healthCardId
	 *            the healthCardId to set
	 */
	public void setHealthCardId(HealthCardId healthCardId)
	{
		this.healthCardId = healthCardId;
	}

	/**
	 * @return the planIdDescription
	 */
	public String getPlanIdDescription()
	{
		return planIdDescription;
	}

	/**
	 * @param planIdDescription
	 *            the planIdDescription to set
	 */
	public void setPlanIdDescription(String planIdDescription)
	{
		this.planIdDescription = planIdDescription;
	}

	/**
	 * @return the productDescription
	 */
	public String getProductDescription()
	{
		return productDescription;
	}

	/**
	 * @param productDescription
	 *            the productDescription to set
	 */
	public void setProductDescription(String productDescription)
	{
		this.productDescription = productDescription;
	}

	/**
	 * @return the productName
	 */
	public String getProductName()
	{
		return productName;
	}

	/**
	 * @param productName
	 *            the productName to set
	 */
	public void setProductName(String productName)
	{
		this.productName = productName;
	}

	/**
	 * @return the sbrUid
	 */
	public String getSbrUid()
	{
		return sbrUid;
	}

	/**
	 * @param sbrUid
	 *            the sbrUid to set
	 */
	public void setSbrUid(String sbrUid)
	{
		this.sbrUid = sbrUid;
	}

	/**
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * @return the coverageTypeCode
	 */
	public String getCoverageTypeCode()
	{
		return coverageTypeCode;
	}

	/**
	 * @param coverageTypeCode
	 *            the coverageTypeCode to set
	 */
	public void setCoverageTypeCode(String coverageTypeCode)
	{
		this.coverageTypeCode = coverageTypeCode;
	}

	/**
	 * @return the coverageTypeDescription
	 */
	public String getCoverageTypeDescription()
	{
		return coverageTypeDescription;
	}

	/**
	 * @param coverageTypeDescription
	 *            the coverageTypeDescription to set
	 */
	public void setCoverageTypeDescription(String coverageTypeDescription)
	{
		this.coverageTypeDescription = coverageTypeDescription;
	}


	/**
	 * @return the tobaccostatus
	 */
	public String getTobaccostatus()
	{
		return tobaccostatus;
	}

	/**
	 * @param tobaccostatus the tobaccostatus to set
	 */
	public void setTobaccostatus(String tobaccostatus)
	{
		this.tobaccostatus = tobaccostatus;
	}

	/**
	 * @return the divisionCode
	 */
	public String getDivisionCode()
	{
		return divisionCode;
	}

	/**
	 * @param divisionCode
	 *            the divisionCode to set
	 */
	public void setDivisionCode(String divisionCode)
	{
		this.divisionCode = divisionCode;
	}

}
