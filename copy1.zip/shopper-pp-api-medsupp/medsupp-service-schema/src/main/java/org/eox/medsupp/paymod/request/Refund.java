/**
 * Refund.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

public class Refund {

	private String refundReasonCode;
	private String refundReasondescription;

	public String getRefundReasonCode() {
		return refundReasonCode;
	}

	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}

	public String getRefundReasondescription() {
		return refundReasondescription;
	}

	public void setRefundReasondescription(String refundReasondescription) {
		this.refundReasondescription = refundReasondescription;
	}

}
