/**
 * PayModCancelPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

import java.io.Serializable;

public class PayModCancelPaymentRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String orderId;
	
	private Note notes;
	private String cancelledBy;
	private boolean csrFlag;
	private String paymentChannel;
	
	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Note getNotes() {
		return notes;
	}

	public void setNotes(Note notes) {
		this.notes = notes;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public boolean isCsrFlag() {
		return csrFlag;
	}

	public void setCsrFlag(boolean csrFlag) {
		this.csrFlag = csrFlag;
	}
	
}
