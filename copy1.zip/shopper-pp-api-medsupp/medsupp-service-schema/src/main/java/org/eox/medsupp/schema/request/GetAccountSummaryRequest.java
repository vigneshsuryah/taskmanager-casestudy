/**
 * GetAccountSummaryRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import org.eox.medsupp.schema.request.BaseRequest;


public class GetAccountSummaryRequest extends BaseRequest
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7615803352437029761L;

}
