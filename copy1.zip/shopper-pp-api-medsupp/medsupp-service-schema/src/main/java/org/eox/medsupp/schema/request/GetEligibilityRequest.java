package org.eox.medsupp.schema.request;


import java.io.Serializable;


public class GetEligibilityRequest implements Serializable
{

	private static final long serialVersionUID = -1476495064737534924L;

	private String memberIdType;
	private String startDate;
	private String endDate;
	private String memberId;

	public String getMemberIdType()
	{
		return memberIdType;
	}

	public void setMemberIdType(String memberIdType)
	{
		this.memberIdType = memberIdType;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate()
	{
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(String startDate)
	{
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate()
	{
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(String endDate)
	{
		this.endDate = endDate;
	}

	public String getMemberId()
	{
		return memberId;
	}

	public void setMemberId(String memberId)
	{
		this.memberId = memberId;
	}

}
