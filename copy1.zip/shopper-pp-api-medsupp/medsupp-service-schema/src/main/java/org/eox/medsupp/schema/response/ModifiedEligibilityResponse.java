package org.eox.medsupp.schema.response;


import java.util.List;
import java.util.Set;

import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;


public class ModifiedEligibilityResponse extends GetEligibilityResponse
{

	private static final long serialVersionUID = -4869045046880599360L;

	private Set<String> childHcids;
	private String status;
	private List<MedicarePayPaymentMethod> medicarePayPaymentMethods;

	public Set<String> getChildHcids()
	{
		return childHcids;
	}

	public void setChildHcids(Set<String> childHcids)
	{
		this.childHcids = childHcids;
	}

	public List<MedicarePayPaymentMethod> getMedicarePayPaymentMethods()
	{
		return medicarePayPaymentMethods;
	}

	public void setMedicarePayPaymentMethods(List<MedicarePayPaymentMethod> medicarePayPaymentMethods)
	{
		this.medicarePayPaymentMethods = medicarePayPaymentMethods;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public void setEligibilityResp(GetEligibilityResponse getEligibilityResponse)
	{
		this.setMemberEligibilityList(getEligibilityResponse.getMemberEligibilityList());
		this.setMessage(getEligibilityResponse.getMessage());
		this.setSourceSystem(getEligibilityResponse.getSourceSystem());
		this.setMemberEligibilityList(getEligibilityResponse.getMemberEligibilityList());
		this.setMedicarePayException(getEligibilityResponse.getMedicarePayException());
	}

}
