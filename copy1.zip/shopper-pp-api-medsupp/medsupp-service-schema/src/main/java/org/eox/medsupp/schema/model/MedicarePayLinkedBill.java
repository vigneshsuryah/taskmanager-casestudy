/**
 * MedicarePayLinkedBill.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MedicarePayLinkedBill implements Serializable
{
	private static final long serialVersionUID = 881393897230659223L;
	private String linkRelationship;
	private boolean canViewPdf;
	private Date requestDate;
	private Date approvedDate;
	private String action;
	private MedicarePayPerson personDetails;
	private String groupId;
	private String ebillSourceIndicator;
	private String memberSequenceNo;
	private String contractIndicators;
	private List<MedicarePayBillAccount> billAccounts;

	public String getContractIndicators()
	{
		return contractIndicators;
	}

	public void setContractIndicators(String contractIndicators)
	{
		this.contractIndicators = contractIndicators;
	}

	public String getMemberSequenceNo()
	{
		return memberSequenceNo;
	}

	public void setMemberSequenceNo(String memberSequenceNo)
	{
		this.memberSequenceNo = memberSequenceNo;
	}

	public String getEbillSourceIndicator()
	{
		return ebillSourceIndicator;
	}

	public void setEbillSourceIndicator(String ebillSourceIndicator)
	{
		this.ebillSourceIndicator = ebillSourceIndicator;
	}

	public String getGroupId()
	{
		return groupId;
	}

	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	public boolean isCanViewPdf()
	{
		return canViewPdf;
	}

	public void setCanViewPdf(boolean canViewPdf)
	{
		this.canViewPdf = canViewPdf;
	}

	public String getLinkRelationship()
	{
		return linkRelationship;
	}

	public void setLinkRelationship(String linkRelationship)
	{
		this.linkRelationship = linkRelationship;
	}

	public Date getRequestDate()
	{
		return requestDate;
	}

	public void setRequestDate(Date requestDate)
	{
		this.requestDate = requestDate;
	}

	public Date getApprovedDate()
	{
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate)
	{
		this.approvedDate = approvedDate;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public MedicarePayPerson getPersonDetails()
	{
		return personDetails;
	}

	public void setPersonDetails(MedicarePayPerson personDetails)
	{
		this.personDetails = personDetails;
	}

	public List<MedicarePayBillAccount> getBillAccounts()
	{
		if (this.billAccounts == null)
		{
			this.billAccounts = new ArrayList<MedicarePayBillAccount>();
		}

		return billAccounts;

	}

	public void setBillAccounts(List<MedicarePayBillAccount> billAccounts)
	{
		this.billAccounts = billAccounts;
	}
}
