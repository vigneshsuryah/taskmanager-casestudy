/**
 * Email.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


public class Email
{
	private String emTypCd;
	private String emlTypTxt;
	private String emailAddr;
	private String efctvDt;
	private String trmntnDt;
	private String emlStatus;

	public String getEmTypCd()
	{
		return emTypCd;
	}

	public void setEmTypCd(String emTypCd)
	{
		this.emTypCd = emTypCd;
	}

	public String getEmlTypTxt()
	{
		return emlTypTxt;
	}

	public void setEmlTypTxt(String emlTypTxt)
	{
		this.emlTypTxt = emlTypTxt;
	}

	public String getEmailAddr()
	{
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr)
	{
		this.emailAddr = emailAddr;
	}

	public String getEfctvDt()
	{
		return efctvDt;
	}

	public void setEfctvDt(String efctvDt)
	{
		this.efctvDt = efctvDt;
	}

	public String getTrmntnDt()
	{
		return trmntnDt;
	}

	public void setTrmntnDt(String trmntnDt)
	{
		this.trmntnDt = trmntnDt;
	}

	public String getEmlStatus()
	{
		return emlStatus;
	}

	public void setEmlStatus(String emlStatus)
	{
		this.emlStatus = emlStatus;
	}
}
