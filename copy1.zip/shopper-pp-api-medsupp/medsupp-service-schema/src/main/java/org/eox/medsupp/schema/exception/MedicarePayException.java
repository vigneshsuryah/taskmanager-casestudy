/**
 * MedicarePayException.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.exception;


import java.io.Serializable;
import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicarePayException extends java.lang.Exception implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String errorCode;
	private String errorMessage;
	private Throwable exception;
	private String errorType;
	private int returnStatus;

	public MedicarePayException(String errorCode, String errorMessage)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public MedicarePayException(String errorType, String errorCode, String errorMessage, int returnStatus)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorType = errorType;
		this.returnStatus = returnStatus;
	}

	public MedicarePayException()
	{

	}

	public MedicarePayException(String message)
	{
		this.errorMessage = message;
	}

	public MedicarePayException(Throwable exception, String message)
	{
		this.errorMessage = message;
		this.exception = exception;
	}

	public String getErrorCode()
	{
		return errorCode;
	}

	public void setErrorCode(String errorCode)
	{
		this.errorCode = errorCode;
	}

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public Throwable getException()
	{
		return exception;
	}

	public void setException(Throwable exception)
	{
		this.exception = exception;
	}

	public String getErrorType()
	{
		return errorType;
	}

	public void setErrorType(String errorType)
	{
		this.errorType = errorType;
	}

	public int getReturnStatus()
	{
		return returnStatus;
	}

	public void setReturnStatus(int returnStatus)
	{
		this.returnStatus = returnStatus;
	}

	public ExceptionResponse transformException()
	{
		ExceptionResponse restError = new ExceptionResponse();
		Exception exception = new Exception();
		exception.setType(this.errorType);
		exception.setCode(this.errorCode);
		exception.setMessage(this.errorMessage);
		exception.setDetail(this.errorMessage);
		Exception exceptions[] = new Exception[1];
		exceptions[0] = exception;
		restError.setExceptions(Arrays.asList(exceptions));
		return restError;
	}

}
