/**
 * SearchDocumentsServiceRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/10/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.transcentra;


public class SearchDocumentsServiceRequest
{
	private String documentType;
	private String documentValue;
	private String accountNumber;
	private String productId;
	private String billDate;
	private String billGroupId;

	public String getBillDate()
	{
		return billDate;
	}

	public void setBillDate(String billDate)
	{
		this.billDate = billDate;
	}

	public String getDocumentType()
	{
		return documentType;
	}

	public void setDocumentType(String documentType)
	{
		this.documentType = documentType;
	}

	public String getDocumentValue()
	{
		return documentValue;
	}

	public void setDocumentValue(String documentValue)
	{
		this.documentValue = documentValue;
	}

	public String getAccountNumber()
	{
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}

	public String getProductId()
	{
		return productId;
	}

	public void setProductId(String productId)
	{
		this.productId = productId;
	}

	/**
	 * @return the billGroupId
	 */
	public String getBillGroupId() {
		return billGroupId;
	}

	/**
	 * @param billGroupId the billGroupId to set
	 */
	public void setBillGroupId(String billGroupId) {
		this.billGroupId = billGroupId;
	}

}
