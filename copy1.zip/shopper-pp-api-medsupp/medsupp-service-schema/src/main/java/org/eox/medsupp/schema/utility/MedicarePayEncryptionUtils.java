/**
 * MedicarePayEncryptionUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.utility;


import org.eox.medsupp.schema.exception.MedicarePayException;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;


public final class MedicarePayEncryptionUtils
{

	private MedicarePayEncryptionUtils()
	{
	}

	public static String getDecryptedText(String key, String algorithm, String encryptedText) throws MedicarePayException
	{
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String decryptedText = "";
		try
		{
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			decryptedText = standardPBEStringEncryptor.decrypt(encryptedText);
		} catch (Exception e)
		{
			throw new MedicarePayException(e, "Tampered key/password" + e.getMessage());
		}
		return decryptedText;
	}

	public static String getEncryptedText(String key, String algorithm, String clearText) throws MedicarePayException
	{
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String encryptedText = "";
		try
		{
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			encryptedText = standardPBEStringEncryptor.encrypt(clearText);
		} catch (Exception e)
		{
			throw new MedicarePayException(e, "Tampered key/password" + e.getMessage());
		}
		return encryptedText;
	}
}
