/**
 * GetDocumentsServiceRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.transcentra;


import java.math.BigInteger;


public class GetDocumentsServiceRequest
{
	private BigInteger documentId;
	private String documentType;
	private String documentValue;

	public BigInteger getDocumentId()
	{
		return documentId;
	}

	public void setDocumentId(BigInteger documentId)
	{
		this.documentId = documentId;
	}

	public String getDocumentType()
	{
		return documentType;
	}

	public void setDocumentType(String documentType)
	{
		this.documentType = documentType;
	}

	public String getDocumentValue()
	{
		return documentValue;
	}

	public void setDocumentValue(String documentValue)
	{
		this.documentValue = documentValue;
	}

}
