package org.eox.medsupp.schema.response;


import java.util.List;

import org.eox.medsupp.schema.model.MedicareFaqDetails;


public class GetMedicareFaqResponse extends BaseResponse
{

	private static final long serialVersionUID = 1L;

	private List<MedicareFaqDetails> medicareFaqDetails;

	/**
	 * @return the medicareFaqDetails
	 */
	public List<MedicareFaqDetails> getMedicareFaqDetails()
	{
		return medicareFaqDetails;
	}

	/**
	 * @param medicareFaqDetails
	 *            the medicareFaqDetails to set
	 */
	public void setMedicareFaqDetails(List<MedicareFaqDetails> medicareFaqDetails)
	{
		this.medicareFaqDetails = medicareFaqDetails;
	}

}
