/**
 * UpdateLinkedBillRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


public class UpdateLinkedAccountRequest extends BaseRequest
{
	private static final long serialVersionUID = -5423496106383167707L;
	private String healthCardId;
	private String firstName;
	private String lastName;
	private String dob;
	private String childHealthCardId;
	private String action;
	private boolean isFromMail;
	private String key;

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getDob()
	{
		return dob;
	}

	public void setDob(String dob)
	{
		this.dob = dob;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public String getHealthCardId()
	{
		return healthCardId;
	}

	public void setHealthCardId(String healthCardId)
	{
		this.healthCardId = healthCardId;
	}

	public String getChildHealthCardId()
	{
		return childHealthCardId;
	}

	public void setChildHealthCardId(String childHealthCardId)
	{
		this.childHealthCardId = childHealthCardId;
	}

	public boolean isFromMail()
	{
		return isFromMail;
	}

	public void setFromMail(boolean isFromMail)
	{
		this.isFromMail = isFromMail;
	}

	public String getKey()
	{
		return key;
	}

	public void setKey(String key)
	{
		this.key = key;
	}

}
