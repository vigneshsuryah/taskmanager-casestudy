/**
 * BillTypeEnum.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


public enum BillTypeEnum
{

	TRANSCENRA, ONDEMAND;

}
