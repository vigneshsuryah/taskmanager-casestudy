/**
 * PayModSubmitPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

import java.io.Serializable;

public class PayModSubmitPaymentRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String anthemOrderId;
	private String matchId;
	private String acn;
	private String memberBillingName;
	private String memberBillingId;
	private String subscrName;
	private String productIdentifier;
	private String summaryBill;
	private String groupName;
	private String groupNumber;
	private String subgroupName;
	private String subgroupNumber;
	private String system;
	private String legalEntity;
	private String marketSegment;
	private String divisionCode;
	private String transactionDivisionCode;
	private String market;
	private String settleAmount;
	private String lob;
	private String hcid;
	private String thirdPartyId;
	private String thirdPartyName;
	private PayerId payerId;
	private PaymentMethod paymentMethod;
	private Transaction[] transactions;
	private String state;

	public String getAnthemOrderId() {
		return anthemOrderId;
	}

	public void setAnthemOrderId(String anthemOrderId) {
		this.anthemOrderId = anthemOrderId;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public String getMemberBillingName() {
		return memberBillingName;
	}

	public void setMemberBillingName(String memberBillingName) {
		this.memberBillingName = memberBillingName;
	}

	public String getSubscrName() {
		return subscrName;
	}

	public void setSubscrName(String subscrName) {
		this.subscrName = subscrName;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public String getSummaryBill() {
		return summaryBill;
	}

	public void setSummaryBill(String summaryBill) {
		this.summaryBill = summaryBill;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getSubgroupName() {
		return subgroupName;
	}

	public void setSubgroupName(String subgroupName) {
		this.subgroupName = subgroupName;
	}

	public String getSubgroupNumber() {
		return subgroupNumber;
	}

	public void setSubgroupNumber(String subgroupNumber) {
		this.subgroupNumber = subgroupNumber;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getDivisionCode() {
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public String getSettleAmount() {
		return settleAmount;
	}

	public void setSettleAmount(String settleAmount) {
		this.settleAmount = settleAmount;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public String getThirdPartyId() {
		return thirdPartyId;
	}

	public void setThirdPartyId(String thirdPartyId) {
		this.thirdPartyId = thirdPartyId;
	}

	public String getThirdPartyName() {
		return thirdPartyName;
	}

	public void setThirdPartyName(String thirdPartyName) {
		this.thirdPartyName = thirdPartyName;
	}

	public PayerId getPayerId() {
		return payerId;
	}

	public void setPayerId(PayerId payerId) {
		this.payerId = payerId;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public Transaction[] getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMemberBillingId() {
		return memberBillingId;
	}

	public void setMemberBillingId(String memberBillingId) {
		this.memberBillingId = memberBillingId;
	}

	public String getMatchId() {
		return matchId;
	}

	public void setMatchId(String matchId) {
		this.matchId = matchId;
	}

	public String getTransactionDivisionCode() {
		return transactionDivisionCode;
	}

	public void setTransactionDivisionCode(String transactionDivisionCode) {
		this.transactionDivisionCode = transactionDivisionCode;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}
	
}
