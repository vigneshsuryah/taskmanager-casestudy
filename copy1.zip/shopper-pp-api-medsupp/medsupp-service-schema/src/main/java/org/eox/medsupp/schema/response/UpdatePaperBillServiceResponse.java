/**
 * UpdatePaperBillServiceResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;

import java.io.Serializable;


public class UpdatePaperBillServiceResponse implements Serializable
{
	private static final long serialVersionUID = 20341082555762314L;
	private String resultStatus;

	public String getResultStatus()
	{
		return resultStatus;
	}

	public void setResultStatus(String resultStatus)
	{
		this.resultStatus = resultStatus;
	}

}
