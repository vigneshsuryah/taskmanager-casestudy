/**
 * Language.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


public class Language
{
	private String langCdTyp;
	private String langCd;

	public String getLangCdTyp()
	{
		return langCdTyp;
	}

	public void setLangCdTyp(String langCdTyp)
	{
		this.langCdTyp = langCdTyp;
	}

	public String getLangCd()
	{
		return langCd;
	}

	public void setLangCd(String langCd)
	{
		this.langCd = langCd;
	}

}
