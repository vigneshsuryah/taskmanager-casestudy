/**
 * GetPaymentMethodResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.io.Serializable;
import java.util.List;

import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetPaymentMethodResponse extends BaseResponse implements Serializable
{

	private static final long serialVersionUID = 1L;

	private List<MedicarePayPaymentMethod> medicarePayPaymentMethods;

	/**
	 * @return the medicarePayPaymentMethods
	 */
	public List<MedicarePayPaymentMethod> getMedicarePayPaymentMethods()
	{
		return medicarePayPaymentMethods;
	}

	/**
	 * @param medicarePayPaymentMethods
	 *            the medicarePayPaymentMethods to set
	 */
	public void setMedicarePayPaymentMethods(List<MedicarePayPaymentMethod> medicarePayPaymentMethods)
	{
		this.medicarePayPaymentMethods = medicarePayPaymentMethods;
	}

}
