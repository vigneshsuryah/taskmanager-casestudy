/**
 * MedicarePayAccessProviderUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.utility;


import org.apache.log4j.Logger;
import org.eox.medsupp.schema.exception.MedicarePayException;


public final class MedicarePayAccessProviderUtils
{

	final static Logger LOGGER = Logger.getLogger(MedicarePayAccessProviderUtils.class);

	private MedicarePayAccessProviderUtils()
	{

	}

	public static Boolean authenticatePassword(String encryptedText, String key, String algorithm, String clearText)
			throws MedicarePayException
	{
		try
		{
			String decryptedText = MedicarePayEncryptionUtils.getDecryptedText(key, algorithm, encryptedText);
			if (decryptedText.equals(clearText))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MemberPayAccessProviderUtils.authenticatePassword::" + e.getCause());
			throw new MedicarePayException(e, "Invalid Password");
		}

	}

	public static Boolean authenticateUserName(String consumerUserName, String producerUserName) throws MedicarePayException
	{
		try
		{
			if (consumerUserName.equals(producerUserName))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MemberPayAccessProviderUtils.authenticateUserName::" + e.getCause());
			throw new MedicarePayException(e, "Invalid User Name");
		}
	}

}
