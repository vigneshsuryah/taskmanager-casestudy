/**
 * ContactInformation.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactInformation implements Serializable
{
	private static final long serialVersionUID = -5131916578028552677L;

	private Address homeAddress;

	private boolean homeSameAsMailingAddress;

	private Address mailingAddress;
	
	private Address billingAddress;

	/**
	 * @return the homeAddress
	 */
	public Address getHomeAddress()
	{
		return homeAddress;
	}

	/**
	 * @param homeAddress
	 *            the homeAddress to set
	 */
	public void setHomeAddress(Address homeAddress)
	{
		this.homeAddress = homeAddress;
	}

	/**
	 * @return the homeSameAsMailingAddress
	 */
	public boolean isHomeSameAsMailingAddress()
	{
		return homeSameAsMailingAddress;
	}

	/**
	 * @param homeSameAsMailingAddress
	 *            the homeSameAsMailingAddress to set
	 */
	public void setHomeSameAsMailingAddress(boolean homeSameAsMailingAddress)
	{
		this.homeSameAsMailingAddress = homeSameAsMailingAddress;
	}

	/**
	 * @return the mailingAddress
	 */
	public Address getMailingAddress()
	{
		return mailingAddress;
	}

	/**
	 * @param mailingAddress
	 *            the mailingAddress to set
	 */
	public void setMailingAddress(Address mailingAddress)
	{
		this.mailingAddress = mailingAddress;
	}

	public Address getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}

}
