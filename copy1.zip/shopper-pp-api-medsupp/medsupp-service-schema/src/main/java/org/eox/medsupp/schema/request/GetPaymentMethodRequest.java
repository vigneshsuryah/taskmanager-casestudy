/**
 * GetPaymentMethodRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import java.util.Map;


public class GetPaymentMethodRequest extends BaseRequest
{
	private static final long serialVersionUID = 1L;

	private String tokenId;
	private boolean needEligiblePaymentMethods;
	private String lineOfBusiness;
	private String sourceSystem;
	private String state;
	private String paymentType;
	private Map<String, String> divisionCodeCheck;
	private boolean csrFlag;

	public String getTokenId()
	{
		return tokenId;
	}

	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	public boolean isNeedEligiblePaymentMethods()
	{
		return needEligiblePaymentMethods;
	}

	public void setNeedEligiblePaymentMethods(boolean needEligiblePaymentMethods)
	{
		this.needEligiblePaymentMethods = needEligiblePaymentMethods;
	}

	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(String paymentType)
	{
		this.paymentType = paymentType;
	}

	public Map<String, String> getDivisionCodeCheck()
	{
		return divisionCodeCheck;
	}

	public void setDivisionCodeCheck(Map<String, String> divisionCodeCheck)
	{
		this.divisionCodeCheck = divisionCodeCheck;
	}

	public boolean isCsrFlag()
	{
		return csrFlag;
	}

	public void setCsrFlag(boolean csrFlag)
	{
		this.csrFlag = csrFlag;
	}
}