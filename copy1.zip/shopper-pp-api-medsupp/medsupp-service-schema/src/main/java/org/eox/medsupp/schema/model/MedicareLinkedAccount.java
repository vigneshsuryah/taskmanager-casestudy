package org.eox.medsupp.schema.model;


import java.io.Serializable;


public class MedicareLinkedAccount implements Serializable
{

	private static final long serialVersionUID = -244902256051907158L;
	private String hcid;
	private String linkRelationship;
	private String requestDate;
	private String approvedDate;
	private String action;
	private MedicarePersonDetails personDetails;

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public String getLinkRelationship()
	{
		return linkRelationship;
	}

	public void setLinkRelationship(String linkRelationship)
	{
		this.linkRelationship = linkRelationship;
	}

	public String getRequestDate()
	{
		return requestDate;
	}

	public void setRequestDate(String requestDate)
	{
		this.requestDate = requestDate;
	}

	public String getApprovedDate()
	{
		return approvedDate;
	}

	public void setApprovedDate(String approvedDate)
	{
		this.approvedDate = approvedDate;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public MedicarePersonDetails getPersonDetails()
	{
		return personDetails;
	}

	public void setPersonDetails(MedicarePersonDetails personDetails)
	{
		this.personDetails = personDetails;
	}

}
