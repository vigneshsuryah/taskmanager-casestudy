/**
 * PaymentMethod.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

public class PaymentMethod {

	private String paymentType;
	private String paymentSubType;
	private String creditCardNumber;
	private String creditCardNumberUI;
	private String creditCardFirstSix;
	private String creditCardLastFour;
	private String tokenId;
	private String ccAuthorizationNumber;
	private String interchangeQualificationCode;
	private String bankRoutingnumber;
	private String bankAccountNumber;
	private String nameOnFundingAccount;
	private FundAccountOwnerFullAddress fundAccountOwnerFullAddress;
	private String actionCode;
	private String ccExpDate;
	private String responseReasonCode;
	private String tokenDate;
	private String isLevelThree;
	private String aVSAAV;
	private String messageType;
	private String originalTransactionAmount;
	private String recordType;
	private String submittedTransactionID;
	private String responseTransactionID;
	private String storedCredentialFlag;
	
	public String getActionCode() {
		return actionCode;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getOriginalTransactionAmount() {
		return originalTransactionAmount;
	}

	public void setOriginalTransactionAmount(String originalTransactionAmount) {
		this.originalTransactionAmount = originalTransactionAmount;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}

	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}

	public String getResponseTransactionID() {
		return responseTransactionID;
	}

	public void setResponseTransactionID(String responseTransactionID) {
		this.responseTransactionID = responseTransactionID;
	}

	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}

	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getCcExpDate() {
		return ccExpDate;
	}

	public void setCcExpDate(String ccExpDate) {
		this.ccExpDate = ccExpDate;
	}

	public String getResponseReasonCode() {
		return responseReasonCode;
	}

	public void setResponseReasonCode(String responseReasonCode) {
		this.responseReasonCode = responseReasonCode;
	}

	public String getTokenDate() {
		return tokenDate;
	}

	public void setTokenDate(String tokenDate) {
		this.tokenDate = tokenDate;
	}

	public String getIsLevelThree() {
		return isLevelThree;
	}

	public void setIsLevelThree(String isLevelThree) {
		this.isLevelThree = isLevelThree;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentSubType() {
		return paymentSubType;
	}

	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getCcAuthorizationNumber() {
		return ccAuthorizationNumber;
	}

	public void setCcAuthorizationNumber(String ccAuthorizationNumber) {
		this.ccAuthorizationNumber = ccAuthorizationNumber;
	}

	public String getInterchangeQualificationCode() {
		return interchangeQualificationCode;
	}

	public void setInterchangeQualificationCode(String interchangeQualificationCode) {
		this.interchangeQualificationCode = interchangeQualificationCode;
	}

	public String getBankRoutingnumber() {
		return bankRoutingnumber;
	}

	public void setBankRoutingnumber(String bankRoutingnumber) {
		this.bankRoutingnumber = bankRoutingnumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getNameOnFundingAccount() {
		return nameOnFundingAccount;
	}

	public void setNameOnFundingAccount(String nameOnFundingAccount) {
		this.nameOnFundingAccount = nameOnFundingAccount;
	}

	public FundAccountOwnerFullAddress getFundAccountOwnerFullAddress() {
		return fundAccountOwnerFullAddress;
	}

	public void setFundAccountOwnerFullAddress(FundAccountOwnerFullAddress fundAccountOwnerFullAddress) {
		this.fundAccountOwnerFullAddress = fundAccountOwnerFullAddress;
	}

	public String getCreditCardNumberUI() {
		return creditCardNumberUI;
	}

	public void setCreditCardNumberUI(String creditCardNumberUI) {
		this.creditCardNumberUI = creditCardNumberUI;
	}

	public String getaVSAAV() {
		return aVSAAV;
	}

	public void setaVSAAV(String aVSAAV) {
		this.aVSAAV = aVSAAV;
	}

}
