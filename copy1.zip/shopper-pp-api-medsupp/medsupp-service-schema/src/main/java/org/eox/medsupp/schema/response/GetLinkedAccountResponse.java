package org.eox.medsupp.schema.response;


import java.util.List;

import org.eox.medsupp.schema.model.MedicareLinkedAccount;


public class GetLinkedAccountResponse extends BaseResponse
{

	private static final long serialVersionUID = 1L;
	private boolean errorFlag;
	private String errorMessage;
	private List<MedicareLinkedAccount> linkedAccounts;

	public boolean isErrorFlag()
	{
		return errorFlag;
	}

	public void setErrorFlag(boolean errorFlag)
	{
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public List<MedicareLinkedAccount> getLinkedAccounts()
	{
		return linkedAccounts;
	}

	public void setLinkedAccounts(List<MedicareLinkedAccount> linkedAccounts)
	{
		this.linkedAccounts = linkedAccounts;
	}

}
