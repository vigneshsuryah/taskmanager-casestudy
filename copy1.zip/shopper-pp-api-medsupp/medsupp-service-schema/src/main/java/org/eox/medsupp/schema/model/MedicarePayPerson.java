/**
 * MedicarePayPerson.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.Date;


public class MedicarePayPerson implements Serializable
{
	private static final long serialVersionUID = -8255220129532226150L;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String hcid;
	private String summaryBillNo;
	private String sourceSystem;
	private String lineOfBusiness;
	private String state;
	private String brand;
	private Date dateOfBirth;
	private boolean emailOpted;
	private String alternateId;
	private MedicarePayAddress address;
	private String dob;
	
	public String getAlternateId()
	{
		return alternateId;
	}

	public void setAlternateId(String alternateId)
	{
		this.alternateId = alternateId;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getEmailAddress()
	{
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		if (hcid != null)
		{
			this.hcid = hcid.toUpperCase();
		}
		else
		{
			this.hcid = hcid;
		}
	}

	public Date getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public boolean isEmailOpted()
	{
		return emailOpted;
	}

	public void setEmailOpted(boolean emailOpted)
	{
		this.emailOpted = emailOpted;
	}

	public MedicarePayAddress getAddress()
	{
		return address;
	}

	public void setAddress(MedicarePayAddress address)
	{
		this.address = address;
	}

	public String getSummaryBillNo()
	{
		return summaryBillNo;
	}

	public void setSummaryBillNo(String summaryBillNo)
	{
		if (summaryBillNo != null)
		{
			this.summaryBillNo = summaryBillNo.toUpperCase();
		}
		else
		{
			this.summaryBillNo = summaryBillNo;
		}
	}

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getBrand()
	{
		return brand;
	}

	public void setBrand(String brand)
	{
		this.brand = brand;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
}
