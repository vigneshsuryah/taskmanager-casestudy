/**
 * CancelPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


public class CancelPaymentRequest extends BaseRequest
{

	private static final long serialVersionUID = 1519412316094811990L;

	private String paymentConfirmationNo;
	
	private String notes;

	//PP-15974 - Start
	private String paymentAmt;
	//PP-15974 - End
	
	public String getPaymentConfirmationNo()
	{
		return paymentConfirmationNo;
	}

	public void setPaymentConfirmationNo(String paymentConfirmationNo)
	{
		this.paymentConfirmationNo = paymentConfirmationNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	//PP-15974 - Start
	/**
	 * @return the paymentAmt
	 */
	public String getPaymentAmt() {
		return paymentAmt;
	}

	/**
	 * @param paymentAmt the paymentAmt to set
	 */
	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	//PP-15974 - End
}
