/**
 * CommComponent.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/21/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


import java.util.List;


public class CommComponent
{
	private List<Language> lang;
	private List<Preference> preference;
	private Address adrs;
	private TelephoneNumber tlphnNbr;
	private Email email;
	private String srcChnl;
	private String srcChnlTxt;
	private String mdfyUserId;
	private String commAuditTmStmp;

	public List<Language> getLang()
	{
		return lang;
	}

	public void setLang(List<Language> lang)
	{
		this.lang = lang;
	}

	public List<Preference> getPreference()
	{
		return preference;
	}

	public void setPreference(List<Preference> preference)
	{
		this.preference = preference;
	}

	public Address getAdrs()
	{
		return adrs;
	}

	public void setAdrs(Address adrs)
	{
		this.adrs = adrs;
	}

	public TelephoneNumber getTlphnNbr()
	{
		return tlphnNbr;
	}

	public void setTlphnNbr(TelephoneNumber tlphnNbr)
	{
		this.tlphnNbr = tlphnNbr;
	}

	public Email getEmail()
	{
		return email;
	}

	public void setEmail(Email email)
	{
		this.email = email;
	}

	public String getSrcChnl()
	{
		return srcChnl;
	}

	public void setSrcChnl(String srcChnl)
	{
		this.srcChnl = srcChnl;
	}

	public String getSrcChnlTxt()
	{
		return srcChnlTxt;
	}

	public void setSrcChnlTxt(String srcChnlTxt)
	{
		this.srcChnlTxt = srcChnlTxt;
	}

	public String getMdfyUserId()
	{
		return mdfyUserId;
	}

	public void setMdfyUserId(String mdfyUserId)
	{
		this.mdfyUserId = mdfyUserId;
	}

	public String getCommAuditTmStmp()
	{
		return commAuditTmStmp;
	}

	public void setCommAuditTmStmp(String commAuditTmStmp)
	{
		this.commAuditTmStmp = commAuditTmStmp;
	}
}
