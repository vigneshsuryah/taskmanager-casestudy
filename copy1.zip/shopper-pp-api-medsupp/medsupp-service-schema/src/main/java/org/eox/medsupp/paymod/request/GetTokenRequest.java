/**
 * GetTokenRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

import java.io.Serializable;

public class GetTokenRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	private String methodOfPayment;
	private String accountNumber;
	private String expirationDate;
	private String amount;
	private String integrityCheck;
	private String keyID;
	private String phaseID;
	private String cardHolderName;
	private String AddressLine1;
	private String City;
	private String State;
	private String PostalCode;
	private String anthemOrderId;
	private String divisionCode;
	private String messageType;
	private String storedCredentialFlag;
	private String submittedTransactionID;
	

	public String getMethodOfPayment() {
		return methodOfPayment;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}
	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}
	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}
	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}
	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getIntegrityCheck() {
		return integrityCheck;
	}
	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}
	public String getKeyID() {
		return keyID;
	}
	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}
	public String getPhaseID() {
		return phaseID;
	}
	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	public String getAnthemOrderId() {
		return anthemOrderId;
	}
	public void setAnthemOrderId(String anthemOrderId) {
		this.anthemOrderId = anthemOrderId;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}	

}
