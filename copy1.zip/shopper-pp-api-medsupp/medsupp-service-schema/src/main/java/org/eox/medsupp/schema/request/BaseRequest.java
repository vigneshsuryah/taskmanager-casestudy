/**
 * CancelPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/05/2019  2.0      Cognizant       CSR - Chase Integration
 */
package org.eox.medsupp.schema.request;


import java.io.Serializable;
import java.util.List;

import org.eox.medsupp.schema.model.RequestHeader;


public abstract class BaseRequest implements Serializable
{

	private static final long serialVersionUID = 1L;

	private RequestHeader requestHeader;
	private String healthCardId;
	private String endPointName;
	private String serviceEnv;
	//PP-14143 - Start
	private String csrId;
	private List<String> csrRoles;
	
	private String lob;

	/**
	 * @return the csrRoles
	 */
	public List<String> getCsrRoles() {
		return csrRoles;
	}

	/**
	 * @param csrRoles the csrRoles to set
	 */
	public void setCsrRoles(List<String> csrRoles) {
		this.csrRoles = csrRoles;
	}
	//PP-14143 -End

	public String getServiceEnv()
	{
		return serviceEnv;
	}

	public void setServiceEnv(String serviceEnv)
	{
		this.serviceEnv = serviceEnv;
	}

	public String getEndPointName()
	{
		return endPointName;
	}

	public void setEndPointName(String endPointName)
	{
		this.endPointName = endPointName;
	}

	/**
	 * @return the healthCardId
	 */
	public String getHealthCardId()
	{
		return healthCardId;
	}

	/**
	 * @param healthCardId
	 *            the healthCardId to set
	 */
	public void setHealthCardId(String healthCardId)
	{
		this.healthCardId = healthCardId;
	}

	public RequestHeader getRequestHeader()
	{
		return requestHeader;
	}

	public void setRequestHeader(RequestHeader requestHeader)
	{
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the csrId
	 */
	public String getCsrId() {
		return csrId;
	}

	/**
	 * @param csrId the csrId to set
	 */
	public void setCsrId(String csrId) {
		this.csrId = csrId;
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	
}
