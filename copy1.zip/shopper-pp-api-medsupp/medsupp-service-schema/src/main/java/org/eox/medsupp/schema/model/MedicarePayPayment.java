/**
 * MedicarePayPayment.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/08/2019  1.0      Cognizant       CSR - Chase Integration
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicarePayPayment implements Serializable
{
	private static final long serialVersionUID = -4251275981284126027L;
	private Date paymentDate;
	private float paymentAmount;
	private String paymentTrackingNo;
	private String paymentSource;
	private MedicarePayPaymentMethod paymentMethod;
	private String paymentMode;
	private String lineOfBussiness;
	
	//PP-14143 - Start
	private List<String> notes;
	
	/**
	 * @return the notes
	 */
	public List<String> getNotes() {
		return notes;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(List<String> notes) {
		this.notes = notes;
	}
	//PP-14143 - End

	public Date getPaymentDate()
	{
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	public float getPaymentAmount()
	{
		return paymentAmount;
	}

	public void setPaymentAmount(float paymentAmount)
	{
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentTrackingNo()
	{
		return paymentTrackingNo;
	}

	public void setPaymentTrackingNo(String paymentTrackingNo)
	{
		this.paymentTrackingNo = paymentTrackingNo;
	}

	public String getPaymentSource()
	{
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource)
	{
		this.paymentSource = paymentSource;
	}

	public MedicarePayPaymentMethod getPaymentMethod()
	{
		return paymentMethod;
	}

	public void setPaymentMethod(MedicarePayPaymentMethod paymentMethod)
	{
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentMode()
	{
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode)
	{
		this.paymentMode = paymentMode;
	}

	public String getLineOfBussiness() {
		return lineOfBussiness;
	}

	public void setLineOfBussiness(String lineOfBussiness) {
		this.lineOfBussiness = lineOfBussiness;
	}
}
