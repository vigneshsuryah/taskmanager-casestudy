/**
 * SubmitPaymentResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.util.List;

import org.eox.medsupp.schema.model.MemberPaySubmitPayment;


public class SubmitPaymentResponse extends BaseResponse
{

	private static final long serialVersionUID = 1192186168213316831L;
	private List<MemberPaySubmitPayment> memberpaySubmitPayments;
	private List<String> successEmailLst;
	private List<String> failureEmailLst;
	private String healthCardId;
	private boolean paymentMethodSaved;
	private String paymentDate;
	private String tokenID;

	public String getTokenID()
	{
		return tokenID;
	}

	public void setTokenID(String tokeID)
	{
		this.tokenID = tokeID;
	}

	public List<String> getSuccessEmailLst()
	{
		return successEmailLst;
	}

	public void setSuccessEmailLst(List<String> successEmailLst)
	{
		this.successEmailLst = successEmailLst;
	}

	public List<String> getFailureEmailLst()
	{
		return failureEmailLst;
	}

	public void setFailureEmailLst(List<String> failureEmailLst)
	{
		this.failureEmailLst = failureEmailLst;
	}

	public String getHealthCardId()
	{
		return healthCardId;
	}

	public void setHealthCardId(String healthCardId)
	{
		this.healthCardId = healthCardId;
	}

	public boolean isPaymentMethodSaved()
	{
		return paymentMethodSaved;
	}

	public void setPaymentMethodSaved(boolean paymentMethodSaved)
	{
		this.paymentMethodSaved = paymentMethodSaved;
	}

	public String getPaymentDate()
	{
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	public List<MemberPaySubmitPayment> getMemberpaySubmitPayments()
	{
		return memberpaySubmitPayments;
	}

	public void setMemberpaySubmitPayments(List<MemberPaySubmitPayment> memberpaySubmitPayments)
	{
		this.memberpaySubmitPayments = memberpaySubmitPayments;
	}

}
