/**
 * MemberPaySubmitPayment.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;

import org.eox.medsupp.schema.response.Message;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class MemberPaySubmitPayment implements Serializable
{

	private static final long serialVersionUID = -1917181159218313938L;

	private String childHealthCardId;

	private String planID;

	private String paymentAmount;

	private String confirmationNumber;
	
	private String divisionCode;

	private Message message;
	
	/* paymod changes */
	private String matchId;
	
	/**
	 * @return the divisionCode
	 */
	public String getDivisionCode()
	{
		return divisionCode;
	}

	/**
	 * @param divisionCode the divisionCode to set
	 */
	public void setDivisionCode(String divisionCode)
	{
		this.divisionCode = divisionCode;
	}

	public void setMessage(Message message)
	{
		this.message = message;
	}

	public Message getMessage()
	{
		return message;
	}

	private String status;

	public String getChildHealthCardId()
	{
		return childHealthCardId;
	}

	public void setChildHealthCardId(String childHealthCardId)
	{
		this.childHealthCardId = childHealthCardId;
	}

	public String getPlanID()
	{
		return planID;
	}

	public void setPlanID(String planID)
	{
		this.planID = planID;
	}

	public String getPaymentAmount()
	{
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount)
	{
		this.paymentAmount = paymentAmount;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}
	
	@JsonIgnore
	public String getMatchId() {
		return matchId;
	}

	public void setMatchId(String matchId) {
		this.matchId = matchId;
	}
}
