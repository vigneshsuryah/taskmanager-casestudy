/**
 * Preference.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


public class Preference
{
	private String prfrncTyp;
	private String prfrncTypDesc;
	private String prfrncOpt;
	private String prfrncOptDesc;
	private String lvlOfConsent;
	private String subLvlOfConsent;
	private String subLvlOfConsentDesc;
	private String efctvDt;
	private String trmntnDt;
	private String srcChnl;
	private String srcChnlTxt;
	private String mdfyUserId;
	private String prfrncAuditTmStmp;

	public String getPrfrncTyp()
	{
		return prfrncTyp;
	}

	public void setPrfrncTyp(String prfrncTyp)
	{
		this.prfrncTyp = prfrncTyp;
	}

	public String getPrfrncTypDesc()
	{
		return prfrncTypDesc;
	}

	public void setPrfrncTypDesc(String prfrncTypDesc)
	{
		this.prfrncTypDesc = prfrncTypDesc;
	}

	public String getPrfrncOpt()
	{
		return prfrncOpt;
	}

	public void setPrfrncOpt(String prfrncOpt)
	{
		this.prfrncOpt = prfrncOpt;
	}

	public String getPrfrncOptDesc()
	{
		return prfrncOptDesc;
	}

	public void setPrfrncOptDesc(String prfrncOptDesc)
	{
		this.prfrncOptDesc = prfrncOptDesc;
	}

	public String getLvlOfConsent()
	{
		return lvlOfConsent;
	}

	public void setLvlOfConsent(String lvlOfConsent)
	{
		this.lvlOfConsent = lvlOfConsent;
	}

	public String getSubLvlOfConsent()
	{
		return subLvlOfConsent;
	}

	public void setSubLvlOfConsent(String subLvlOfConsent)
	{
		this.subLvlOfConsent = subLvlOfConsent;
	}

	public String getSubLvlOfConsentDesc()
	{
		return subLvlOfConsentDesc;
	}

	public void setSubLvlOfConsentDesc(String subLvlOfConsentDesc)
	{
		this.subLvlOfConsentDesc = subLvlOfConsentDesc;
	}

	public String getEfctvDt()
	{
		return efctvDt;
	}

	public void setEfctvDt(String efctvDt)
	{
		this.efctvDt = efctvDt;
	}

	public String getTrmntnDt()
	{
		return trmntnDt;
	}

	public void setTrmntnDt(String trmntnDt)
	{
		this.trmntnDt = trmntnDt;
	}

	public String getSrcChnl()
	{
		return srcChnl;
	}

	public void setSrcChnl(String srcChnl)
	{
		this.srcChnl = srcChnl;
	}

	public String getSrcChnlTxt()
	{
		return srcChnlTxt;
	}

	public void setSrcChnlTxt(String srcChnlTxt)
	{
		this.srcChnlTxt = srcChnlTxt;
	}

	public String getMdfyUserId()
	{
		return mdfyUserId;
	}

	public void setMdfyUserId(String mdfyUserId)
	{
		this.mdfyUserId = mdfyUserId;
	}

	public String getPrfrncAuditTmStmp()
	{
		return prfrncAuditTmStmp;
	}

	public void setPrfrncAuditTmStmp(String prfrncAuditTmStmp)
	{
		this.prfrncAuditTmStmp = prfrncAuditTmStmp;
	}
}
