/**
* AdditionalPropGrpBO.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;
import java.util.List;

public class AdditionalPropGrpBO implements Serializable{

	private static final long serialVersionUID = 5755218301432171370L;
	private String additionalPropGrpNm;
	private List<PropertyBO> property;
	public String getAdditionalPropGrpNm() {
		return additionalPropGrpNm;
	}
	public void setAdditionalPropGrpNm(String additionalPropGrpNm) {
		this.additionalPropGrpNm = additionalPropGrpNm;
	}
	public List<PropertyBO> getProperty() {
		return property;
	}
	public void setProperty(List<PropertyBO> property) {
		this.property = property;
	}
}
