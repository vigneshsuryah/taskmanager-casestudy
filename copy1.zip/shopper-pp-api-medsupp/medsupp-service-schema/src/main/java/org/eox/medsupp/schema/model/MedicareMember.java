package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicareMember implements Serializable
{

	private static final long serialVersionUID = 795934305666214703L;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String healthCardId;
	private String relationShip;
	private String state;
	private String brand;
	private MedicareBillingAddress billingAddress;
	private List<MedicareBillDetails> medicareBillDetails;
	/*PP-6430 GA rebranding starts*/
	private String effectiveDate;
	/**
	 * @return the effectiveDate
	 */
	public String getEffectiveDate()
	{
		return effectiveDate;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate)
	{
		this.effectiveDate = effectiveDate;
	}
	/*PP-6430 GA rebranding ends*/
	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public String getHealthCardId()
	{
		return healthCardId;
	}

	public void setHealthCardId(String healthCardId)
	{
		this.healthCardId = healthCardId;
	}

	public String getRelationShip()
	{
		return relationShip;
	}

	public void setRelationShip(String relationShip)
	{
		this.relationShip = relationShip;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getBrand()
	{
		return brand;
	}

	public void setBrand(String brand)
	{
		this.brand = brand;
	}

	public List<MedicareBillDetails> getMedicareBillDetails()
	{
		return medicareBillDetails;
	}

	public void setMedicareBillDetails(List<MedicareBillDetails> medicareBillDetails)
	{
		this.medicareBillDetails = medicareBillDetails;
	}

	/**
	 * @return the billingAddress
	 */
	public MedicareBillingAddress getBillingAddress()
	{
		return billingAddress;
	}

	/**
	 * @param billingAddress
	 *            the billingAddress to set
	 */
	public void setBillingAddress(MedicareBillingAddress billingAddress)
	{
		this.billingAddress = billingAddress;
	}

}
