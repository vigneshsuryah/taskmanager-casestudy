/**
 * GetAccountSummaryResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.util.List;

import org.eox.medsupp.schema.model.MedicareMember;
import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;
import org.eox.medsupp.schema.model.MemberEligibility;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetAccountSummaryResponse extends BaseResponse
{

	private static final long serialVersionUID = -846297220306059825L;
	private String errorMessage;
	private boolean errorFlag;
	private int payNowCount;
	private int totalBillsAvailableCount;
	private float totalAmountDue;
	private float minDueAmount;
	private boolean bankingAllowed;
	private boolean creditDebitAllowed;
	private String todayDate;
	private List<MemberEligibility> memberEligibilityList;

	private List<MedicarePayPaymentMethod> medicarePayPaymentMethods;

	/**
	 * @return the minDueAmount
	 */
	public float getMinDueAmount()
	{
		return minDueAmount;
	}

	/**
	 * @param minDueAmount
	 *            the minDueAmount to set
	 */
	public void setMinDueAmount(float minDueAmount)
	{
		this.minDueAmount = minDueAmount;
	}

	/**
	 * @return the payNowCount
	 */
	public int getPayNowCount()
	{
		return payNowCount;
	}

	/**
	 * @param payNowCount
	 *            the payNowCount to set
	 */
	public void setPayNowCount(int payNowCount)
	{
		this.payNowCount = payNowCount;
	}

	/**
	 * @return the totalBillsAvailableCount
	 */
	public int getTotalBillsAvailableCount()
	{
		return totalBillsAvailableCount;
	}

	/**
	 * @param totalBillsAvailableCount
	 *            the totalBillsAvailableCount to set
	 */
	public void setTotalBillsAvailableCount(int totalBillsAvailableCount)
	{
		this.totalBillsAvailableCount = totalBillsAvailableCount;
	}

	/**
	 * @return the totalAmountDue
	 */
	public float getTotalAmountDue()
	{
		return totalAmountDue;
	}

	/**
	 * @param totalAmountDue
	 *            the totalAmountDue to set
	 */
	public void setTotalAmountDue(float totalAmountDue)
	{
		this.totalAmountDue = totalAmountDue;
	}

	public List<MedicarePayPaymentMethod> getMedicarePayPaymentMethods()
	{
		return medicarePayPaymentMethods;
	}

	public void setMedicarePayPaymentMethods(List<MedicarePayPaymentMethod> medicarePayPaymentMethods)
	{
		this.medicarePayPaymentMethods = medicarePayPaymentMethods;
	}

	/**
	 * @return the memberEligibilityList
	 */
	public List<MemberEligibility> getMemberEligibilityList()
	{
		return memberEligibilityList;
	}

	/**
	 * @param memberEligibilityList
	 *            the memberEligibilityList to set
	 */
	public void setMemberEligibilityList(List<MemberEligibility> memberEligibilityList)
	{
		this.memberEligibilityList = memberEligibilityList;
	}

	public List<MedicareMember> getMedicareMemberList()
	{
		return medicareMemberList;
	}

	public void setMedicareMemberList(List<MedicareMember> medicareMemberList)
	{
		this.medicareMemberList = medicareMemberList;
	}

	/**
	 * @return the errorFlag
	 */
	public boolean isErrorFlag()
	{
		return errorFlag;
	}

	/**
	 * @param errorFlag
	 *            the errorFlag to set
	 */
	public void setErrorFlag(boolean errorFlag)
	{
		this.errorFlag = errorFlag;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage()
	{
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	private List<MedicareMember> medicareMemberList;

	/**
	 * @return the bankingAllowed
	 */
	public boolean isBankingAllowed()
	{
		return bankingAllowed;
	}

	/**
	 * @param bankingAllowed
	 *            the bankingAllowed to set
	 */
	public void setBankingAllowed(boolean bankingAllowed)
	{
		this.bankingAllowed = bankingAllowed;
	}

	/**
	 * @return the creditDebitAllowed
	 */
	public boolean isCreditDebitAllowed()
	{
		return creditDebitAllowed;
	}

	/**
	 * @param creditDebitAllowed
	 *            the creditDebitAllowed to set
	 */
	public void setCreditDebitAllowed(boolean creditDebitAllowed)
	{
		this.creditDebitAllowed = creditDebitAllowed;
	}

	public String getTodayDate() {
		return todayDate;
	}

	public void setTodayDate(String todayDate) {
		this.todayDate = todayDate;
	}

}
