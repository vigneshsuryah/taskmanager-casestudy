package org.eox.medsupp.paymod.response;

import java.util.List;

public class PaymentModExceptionResponse {

	private static final long serialVersionUID = 1L;
	private List<Exceptions> exceptions;
	public List<Exceptions> getExceptions() {
		return exceptions;
	}
	public void setExceptions(List<Exceptions> exceptions) {
		this.exceptions = exceptions;
	}

}
