/**
 * PayModCancelPaymentResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.response;

import java.io.Serializable;

public class PayModCancelPaymentResponse implements Serializable{

	private static final long serialVersionUID = 1L;

	private boolean isCancelled;
	private String errorMessage;
	private String errorCode;
	private String emailId;
	private Exceptions exceptions;
	
	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}
	
	public Exceptions getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions exceptions) {
		this.exceptions = exceptions;
	}
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
