/**
 * GetAutoPaymentResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/13/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.io.Serializable;
import java.util.List;

import org.eox.medsupp.schema.model.MedicarePayAutoPay;


public class GetAutoPaymentResponse extends BaseResponse implements Serializable
{

	private static final long serialVersionUID = 1L;

	private List<MedicarePayAutoPay> medicarePayAutoPayList;

	/**
	 * @return the medicarePayAutoPayList
	 */
	public List<MedicarePayAutoPay> getMedicarePayAutoPayList()
	{
		return medicarePayAutoPayList;
	}

	/**
	 * @param medicarePayAutoPayList
	 *            the medicarePayAutoPayList to set
	 */
	public void setMedicarePayAutoPayList(List<MedicarePayAutoPay> medicarePayAutoPayList)
	{
		this.medicarePayAutoPayList = medicarePayAutoPayList;
	}

}
