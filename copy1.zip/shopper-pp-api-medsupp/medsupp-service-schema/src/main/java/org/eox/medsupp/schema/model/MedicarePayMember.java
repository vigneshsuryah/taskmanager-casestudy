/**
 * MedicarePayMember.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class MedicarePayMember implements Serializable
{
	private static final long serialVersionUID = -2539450151534678515L;
	private String hcid;
	private String summaryBillNo;
	private boolean validationStatus;
	private String action;
	private String language;
	private String resValasJson;
	private MedicarePayPaymentMethod newPaymentMethod;
	private List<MedicarePayPaymentMethod> availablePaymentMethods;
	private List<MedicarePayLinkedBill> linkedBills;
	private String defaultPaymentMethod;
	private List<String> availablePaymentMethodNickNames;

	private boolean hasSeniorMember;

	public String getDefaultPaymentMethod()
	{
		return defaultPaymentMethod;
	}

	public void setDefaultPaymentMethod(String defaultPaymentMethod)
	{
		this.defaultPaymentMethod = defaultPaymentMethod;
	}

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public boolean isValidationStatus()
	{
		return validationStatus;
	}

	public void setValidationStatus(boolean validationStatus)
	{
		this.validationStatus = validationStatus;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public String getLanguage()
	{
		return language;
	}

	public void setLanguage(String language)
	{
		this.language = language;
	}

	public String getResValasJson()
	{
		return resValasJson;
	}

	public void setResValasJson(String resValasJson)
	{
		this.resValasJson = resValasJson;
	}

	public MedicarePayPaymentMethod getNewPaymentMethod()
	{
		return newPaymentMethod;
	}

	public void setNewPaymentMethod(MedicarePayPaymentMethod newPaymentMethod)
	{
		this.newPaymentMethod = newPaymentMethod;
	}

	public List<MedicarePayPaymentMethod> getAvailablePaymentMethods()
	{
		return availablePaymentMethods;
	}

	public void setAvailablePaymentMethods(List<MedicarePayPaymentMethod> availablePaymentMethods)
	{
		this.availablePaymentMethods = availablePaymentMethods;
	}

	public List<MedicarePayLinkedBill> getLinkedBills()
	{
		if (this.linkedBills == null)
		{
			this.linkedBills = new ArrayList<MedicarePayLinkedBill>(1);
		}
		return linkedBills;
	}

	public void setLinkedBills(List<MedicarePayLinkedBill> linkedBills)
	{
		this.linkedBills = linkedBills;
	}

	public String getSummaryBillNo()
	{
		return summaryBillNo;
	}

	public void setSummaryBillNo(String summaryBillNo)
	{
		this.summaryBillNo = summaryBillNo;
	}

	public void setHasSeniorMember(boolean hasSeniorMember)
	{
		this.hasSeniorMember = hasSeniorMember;
	}

	public boolean isHasSeniorMember()
	{
		return hasSeniorMember;
	}

	public void setAvailablePaymentMethodNickNames(List<String> availablePaymentMethodNickNames)
	{
		this.availablePaymentMethodNickNames = availablePaymentMethodNickNames;
	}

	public List<String> getAvailablePaymentMethodNickNames()
	{
		return availablePaymentMethodNickNames;
	}

}
