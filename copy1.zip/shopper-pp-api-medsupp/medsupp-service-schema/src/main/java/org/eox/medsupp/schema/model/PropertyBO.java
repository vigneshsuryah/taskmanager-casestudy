/**
* PropertyBO.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class PropertyBO implements Serializable{

	private static final long serialVersionUID = 9131905908554692962L;
	private String propertyNm;
	private String propertyVal;
	
	public String getPropertyNm() {
		return propertyNm;
	}
	public void setPropertyNm(String propertyNm) {
		this.propertyNm = propertyNm;
	}
	public String getPropertyVal() {
		return propertyVal;
	}
	public void setPropertyVal(String propertyVal) {
		this.propertyVal = propertyVal;
	}
}
