/**
* AdditionalPropertiesBO.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;
import java.util.List;

public class AdditionalPropertiesBO implements Serializable{

	private static final long serialVersionUID = -8477246019112628514L;
	private List<AdditionalPropGrpBO> additionalPropGrp;

	public List<AdditionalPropGrpBO> getAdditionalPropGrp() {
		return additionalPropGrp;
	}

	public void setAdditionalPropGrp(List<AdditionalPropGrpBO> additionalPropGrp) {
		this.additionalPropGrp = additionalPropGrp;
	}
}
