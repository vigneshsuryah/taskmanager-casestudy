/**
 * MedicareEmailLogging.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


public class MedicareEmailLogging implements Serializable
{
	private static final long serialVersionUID = 6127848087999730357L;
	private BigDecimal emailLoggingId;
	private String from;
	private String to;
	private String hcid;
	private String subject;
	private String templateId;
	private Date sentDate;
	private String dynamicContent;
	private String mailType;
	private String createdBy;
	private Date createdDate;

	public BigDecimal getEmailLoggingId()
	{
		return emailLoggingId;
	}

	public void setEmailLoggingId(BigDecimal emailLoggingId)
	{
		this.emailLoggingId = emailLoggingId;
	}

	public String getFrom()
	{
		return from;
	}

	public void setFrom(String from)
	{
		this.from = from;
	}

	public String getTo()
	{
		return to;
	}

	public void setTo(String to)
	{
		this.to = to;
	}

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public String getSubject()
	{
		return subject;
	}

	public void setSubject(String subject)
	{
		this.subject = subject;
	}

	public String getTemplateId()
	{
		return templateId;
	}

	public void setTemplateId(String templateId)
	{
		this.templateId = templateId;
	}

	public Date getSentDate()
	{
		return sentDate;
	}

	public void setSentDate(Date sentDate)
	{
		this.sentDate = sentDate;
	}

	public String getDynamicContent()
	{
		return dynamicContent;
	}

	public void setDynamicContent(String dynamicContent)
	{
		this.dynamicContent = dynamicContent;
	}

	public String getMailType()
	{
		return mailType;
	}

	public void setMailType(String mailType)
	{
		this.mailType = mailType;
	}

	public String getCreatedBy()
	{
		return createdBy;
	}

	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}

	public Date getCreatedDate()
	{
		return createdDate;
	}

	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

}
