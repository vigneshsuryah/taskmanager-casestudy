/**
* NotificationPreference.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
* 03/25/2019  1.0      Cognizant       SMC mail changes
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class NotificationPreference implements Serializable{

	private static final long serialVersionUID = -7436808636413249995L;

	private String emailAddress;
	
	private String preVerificationInd;
	
	//PP-15970 - Start
	private String preferenceType;
	
	/**
	 * @return the preferenceType
	 */
	public String getPreferenceType() {
		return preferenceType;
	}

	/**
	 * @param preferenceType the preferenceType to set
	 */
	public void setPreferenceType(String preferenceType) {
		this.preferenceType = preferenceType;
	}
	//PP-15970 - End

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the preVerificationInd
	 */
	public String getPreVerificationInd() {
		return preVerificationInd;
	}

	/**
	 * @param preVerificationInd the preVerificationInd to set
	 */
	public void setPreVerificationInd(String preVerificationInd) {
		this.preVerificationInd = preVerificationInd;
	}
	
}
