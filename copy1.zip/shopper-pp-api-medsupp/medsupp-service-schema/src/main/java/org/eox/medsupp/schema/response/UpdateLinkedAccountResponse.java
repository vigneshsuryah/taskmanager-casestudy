/**
 * UpdateLinkedBillResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/16/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


public class UpdateLinkedAccountResponse extends BaseResponse
{
	private static final long serialVersionUID = 5131050451096006722L;
	private boolean errorFlag;
	private String errorMessage;
	private String subScriberName;

	public boolean isErrorFlag()
	{
		return errorFlag;
	}

	public void setErrorFlag(boolean errorFlag)
	{
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public String getSubScriberName()
	{
		return subScriberName;
	}

	public void setSubScriberName(String subScriberName)
	{
		this.subScriberName = subScriberName;
	}

}
