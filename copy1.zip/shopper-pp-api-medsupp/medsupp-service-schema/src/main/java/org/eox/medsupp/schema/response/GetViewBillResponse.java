/**
 * GetViewBillResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.util.Date;
import java.util.List;


public class GetViewBillResponse extends BaseResponse
{

	private static final long serialVersionUID = -1505621834098732684L;

	private boolean errorFlag;

	private String errorMessage;

	private String pdfString;

	private List<String> onDemandContentKeys;

	private List<String> onDemandBillDates;

	private List<DateValuePair> dateValuePairs;

	public class DateValuePair
	{

		private Date billDate;

		private String contentKey;

		public Date getBillDate()
		{
			return billDate;
		}

		public void setBillDate(Date billDate)
		{
			this.billDate = billDate;
		}

		public String getContentKey()
		{
			return contentKey;
		}

		public void setContentKey(String contentKey)
		{
			this.contentKey = contentKey;
		}

	}

	/**
	 * @return the errorFlag
	 */
	public boolean isErrorFlag()
	{
		return errorFlag;
	}

	/**
	 * @param errorFlag
	 *            the errorFlag to set
	 */
	public void setErrorFlag(boolean errorFlag)
	{
		this.errorFlag = errorFlag;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage()
	{
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the pdfString
	 */
	public String getPdfString()
	{
		return pdfString;
	}

	/**
	 * @param pdfString
	 *            the pdfString to set
	 */
	public void setPdfString(String pdfString)
	{
		this.pdfString = pdfString;
	}

	/**
	 * @return the onDemandContentKeys
	 */
	public List<String> getOnDemandContentKeys()
	{
		return onDemandContentKeys;
	}

	/**
	 * @param onDemandContentKeys
	 *            the onDemandContentKeys to set
	 */
	public void setOnDemandContentKeys(List<String> onDemandContentKeys)
	{
		this.onDemandContentKeys = onDemandContentKeys;
	}

	/**
	 * @return the onDemandBillDates
	 */
	public List<String> getOnDemandBillDates()
	{
		return onDemandBillDates;
	}

	/**
	 * @param onDemandBillDates
	 *            the onDemandBillDates to set
	 */
	public void setOnDemandBillDates(List<String> onDemandBillDates)
	{
		this.onDemandBillDates = onDemandBillDates;
	}

	/**
	 * @return the dateValuePairs
	 */
	public List<DateValuePair> getDateValuePairs()
	{
		return dateValuePairs;
	}

	/**
	 * @param dateValuePairs
	 *            the dateValuePairs to set
	 */
	public void setDateValuePairs(List<DateValuePair> dateValuePairs)
	{
		this.dateValuePairs = dateValuePairs;
	}

}
