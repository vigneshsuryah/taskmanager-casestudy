/**
 * BillDetails.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillDetails implements Serializable
{

	private static final long serialVersionUID = 6791197637134717193L;

	private String billGroupId;

	private String billType;

	private HealthCardId primaryMemberHcid;

	private String billDueDate;

	private String billFrequency;

	private String paidStatus;

	private float reconciliationAmount;

	private String billFromDateOrig;

	private String billToDateOrig;

	private String lineOfBusiness;

	private String billProcessedDate;

	private float billNetDue;

	private String statementId;
	
	private float minimumAmountDue;
	
	private String legalEntityCode;
	
	private String marketSegment;

	/**
	 * @return the billGroupId
	 */
	public String getBillGroupId()
	{
		return billGroupId;
	}

	/**
	 * @param billGroupId
	 *            the billGroupId to set
	 */
	public void setBillGroupId(String billGroupId)
	{
		this.billGroupId = billGroupId;
	}

	/**
	 * @return the billType
	 */
	public String getBillType()
	{
		return billType;
	}

	/**
	 * @param billType
	 *            the billType to set
	 */
	public void setBillType(String billType)
	{
		this.billType = billType;
	}

	/**
	 * @return the primaryMemberHcid
	 */
	public HealthCardId getPrimaryMemberHcid()
	{
		return primaryMemberHcid;
	}

	/**
	 * @param primaryMemberHcid
	 *            the primaryMemberHcid to set
	 */
	public void setPrimaryMemberHcid(HealthCardId primaryMemberHcid)
	{
		this.primaryMemberHcid = primaryMemberHcid;
	}

	/**
	 * @return the billDueDate
	 */
	public String getBillDueDate()
	{
		return billDueDate;
	}

	/**
	 * @param billDueDate
	 *            the billDueDate to set
	 */
	public void setBillDueDate(String billDueDate)
	{
		this.billDueDate = billDueDate;
	}

	/**
	 * @return the paidStatus
	 */
	public String getPaidStatus()
	{
		return paidStatus;
	}

	/**
	 * @param paidStatus
	 *            the paidStatus to set
	 */
	public void setPaidStatus(String paidStatus)
	{
		this.paidStatus = paidStatus;
	}

	/**
	 * @return the billFromDateOrig
	 */
	public String getBillFromDateOrig()
	{
		return billFromDateOrig;
	}

	/**
	 * @param billFromDateOrig
	 *            the billFromDateOrig to set
	 */
	public void setBillFromDateOrig(String billFromDateOrig)
	{
		this.billFromDateOrig = billFromDateOrig;
	}

	/**
	 * @return the billToDateOrig
	 */
	public String getBillToDateOrig()
	{
		return billToDateOrig;
	}

	/**
	 * @param billToDateOrig
	 *            the billToDateOrig to set
	 */
	public void setBillToDateOrig(String billToDateOrig)
	{
		this.billToDateOrig = billToDateOrig;
	}

	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	/**
	 * @param lineOfBusiness
	 *            the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * @return the billProcessedDate
	 */
	public String getBillProcessedDate()
	{
		return billProcessedDate;
	}

	/**
	 * @param billProcessedDate
	 *            the billProcessedDate to set
	 */
	public void setBillProcessedDate(String billProcessedDate)
	{
		this.billProcessedDate = billProcessedDate;
	}

	/**
	 * @return the billFrequency
	 */
	public String getBillFrequency()
	{
		return billFrequency;
	}

	/**
	 * @param billFrequency
	 *            the billFrequency to set
	 */
	public void setBillFrequency(String billFrequency)
	{
		this.billFrequency = billFrequency;
	}

	/**
	 * @return the reconciliationAmount
	 */
	public float getReconciliationAmount()
	{
		return reconciliationAmount;
	}

	/**
	 * @param reconciliationAmount
	 *            the reconciliationAmount to set
	 */
	public void setReconciliationAmount(float reconciliationAmount)
	{
		this.reconciliationAmount = reconciliationAmount;
	}

	/**
	 * @return the billNetDue
	 */
	public float getBillNetDue()
	{
		return billNetDue;
	}

	/**
	 * @param billNetDue
	 *            the billNetDue to set
	 */
	public void setBillNetDue(float billNetDue)
	{
		this.billNetDue = billNetDue;
	}

	/**
	 * @return the statementId
	 */
	public String getStatementId()
	{
		return statementId;
	}

	/**
	 * @param statementId
	 *            the statementId to set
	 */
	public void setStatementId(String statementId)
	{
		this.statementId = statementId;
	}

	/**
	 * @return the minimumAmountDue
	 */
	public float getMinimumAmountDue() {
		return minimumAmountDue;
	}

	/**
	 * @param minimumAmountDue the minimumAmountDue to set
	 */
	public void setMinimumAmountDue(float minimumAmountDue) {
		this.minimumAmountDue = minimumAmountDue;
	}

	public String getLegalEntityCode() {
		return legalEntityCode;
	}

	public void setLegalEntityCode(String legalEntityCode) {
		this.legalEntityCode = legalEntityCode;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

}
