/**
 * Returns.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.request;

public class Returns {

	private String returnReasonCode;
	private String returnReasonDescription;
	private String nullificationDate;

	public String getReturnReasonCode() {
		return returnReasonCode;
	}

	public void setReturnReasonCode(String returnReasonCode) {
		this.returnReasonCode = returnReasonCode;
	}

	public String getReturnReasonDescription() {
		return returnReasonDescription;
	}

	public void setReturnReasonDescription(String returnReasonDescription) {
		this.returnReasonDescription = returnReasonDescription;
	}

	public String getNullificationDate() {
		return nullificationDate;
	}

	public void setNullificationDate(String nullificationDate) {
		this.nullificationDate = nullificationDate;
	}

}
