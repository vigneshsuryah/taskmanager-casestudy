package org.eox.medsupp.schema.request;


public class GetMedicareFaqRequest extends BaseRequest
{

	private static final long serialVersionUID = 1L;

}
