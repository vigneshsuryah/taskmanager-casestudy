package org.eox.medsupp.schema.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicareBillDetails implements Serializable
{
	private static final long serialVersionUID = 281734473805723094L;
	private String billGroupId;
	private String planId;
	private String billType;
	private String primaryMemberHcid;
	private String billDueDate;
	private String paidStatus;
	private String divisionCode;
	private String lineOfBusiness;
	private String billProcessedDate;
	private float billMinDue;
	private float billNetDue;
	private String paymentMethod;
	private String productDescription;
	private String planIdDescription;
	private String subgroupId;
	private String paymentStatus;
	private boolean showToolTip;
	private String toolTipDescription;
	private boolean isPdfAvailable;
	private MedicarePayPayment medicarePayPayment;

	private String classId;
	private String groupId;
	private BrandEmailMatrix brandEmailMatrix;
	
	//PP-14143 start
	private List<MedicarePayPayment> medicarePayPayments;
	
	/**
	 * @return the medicarePayPayments
	 */
	public List<MedicarePayPayment> getMedicarePayPayments() {
		return medicarePayPayments;
	}

	/**
	 * @param medicarePayPayments the medicarePayPayments to set
	 */
	public void setMedicarePayPayments(List<MedicarePayPayment> medicarePayPayments) {
		this.medicarePayPayments = medicarePayPayments;
	}
	//PP-14143 end

	/**
	 * @return the billMinDue
	 */
	public float getBillMinDue()
	{
		return billMinDue;
	}

	/**
	 * @param billMinDue
	 *            the billMinDue to set
	 */
	public void setBillMinDue(float billMinDue)
	{
		this.billMinDue = billMinDue;
	}

	/**
	 * @return the brandEmailMatrix
	 */
	public BrandEmailMatrix getBrandEmailMatrix()
	{
		return brandEmailMatrix;
	}

	/**
	 * @param brandEmailMatrix
	 *            the brandEmailMatrix to set
	 */
	public void setBrandEmailMatrix(BrandEmailMatrix brandEmailMatrix)
	{
		this.brandEmailMatrix = brandEmailMatrix;
	}

	/**
	 * @return the classId
	 */
	public String getClassId()
	{
		return classId;
	}

	/**
	 * @param classId
	 *            the classId to set
	 */
	public void setClassId(String classId)
	{
		this.classId = classId;
	}

	/**
	 * @return the groupId
	 */
	public String getGroupId()
	{
		return groupId;
	}

	/**
	 * @param groupId
	 *            the groupId to set
	 */
	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	public String getBillGroupId()
	{
		return billGroupId;
	}

	public void setBillGroupId(String billGroupId)
	{
		this.billGroupId = billGroupId;
	}

	public String getBillType()
	{
		return billType;
	}

	public void setBillType(String billType)
	{
		this.billType = billType;
	}

	public String getPrimaryMemberHcid()
	{
		return primaryMemberHcid;
	}

	public void setPrimaryMemberHcid(String primaryMemberHcid)
	{
		this.primaryMemberHcid = primaryMemberHcid;
	}

	public String getBillDueDate()
	{
		return billDueDate;
	}

	public void setBillDueDate(String billDueDate)
	{
		this.billDueDate = billDueDate;
	}

	public String getPaidStatus()
	{
		return paidStatus;
	}

	public void setPaidStatus(String paidStatus)
	{
		this.paidStatus = paidStatus;
	}

	public String getDivisionCode()
	{
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode)
	{
		this.divisionCode = divisionCode;
	}

	public String getLineOfBusiness()
	{
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getBillProcessedDate()
	{
		return billProcessedDate;
	}

	public void setBillProcessedDate(String billProcessedDate)
	{
		this.billProcessedDate = billProcessedDate;
	}

	public String getPaymentMethod()
	{
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod)
	{
		this.paymentMethod = paymentMethod;
	}

	public String getProductDescription()
	{
		return productDescription;
	}

	public void setProductDescription(String productDescription)
	{
		this.productDescription = productDescription;
	}

	public String getSubgroupId()
	{
		return subgroupId;
	}

	public void setSubgroupId(String subgroupId)
	{
		this.subgroupId = subgroupId;
	}

	public String getPaymentStatus()
	{
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus)
	{
		this.paymentStatus = paymentStatus;
	}

	public String getToolTipDescription()
	{
		return toolTipDescription;
	}

	public void setToolTipDescription(String toolTipDescription)
	{
		this.toolTipDescription = toolTipDescription;
	}

	public boolean isShowToolTip()
	{
		return showToolTip;
	}

	public void setShowToolTip(boolean showToolTip)
	{
		this.showToolTip = showToolTip;
	}

	/**
	 * @return the billNetDue
	 */
	public float getBillNetDue()
	{
		return billNetDue;
	}

	/**
	 * @param billNetDue
	 *            the billNetDue to set
	 */
	public void setBillNetDue(float billNetDue)
	{
		this.billNetDue = billNetDue;
	}

	/**
	 * @return the medicarePayPayment
	 */
	public MedicarePayPayment getMedicarePayPayment()
	{
		return medicarePayPayment;
	}

	/**
	 * @param medicarePayPayment
	 *            the medicarePayPayment to set
	 */
	public void setMedicarePayPayment(MedicarePayPayment medicarePayPayment)
	{
		this.medicarePayPayment = medicarePayPayment;
	}

	public boolean isPdfAvailable()
	{
		return isPdfAvailable;
	}

	public void setPdfAvailable(boolean isPdfAvailable)
	{
		this.isPdfAvailable = isPdfAvailable;
	}

	public String getPlanId()
	{
		return planId;
	}

	public void setPlanId(String planId)
	{
		this.planId = planId;
	}

	public String getPlanIdDescription()
	{
		return planIdDescription;
	}

	@JsonIgnore
	public void setPlanIdDescription(String planIdDescription)
	{
		this.planIdDescription = planIdDescription;
	}

}
