/**
 * MedicarePayPaymentMethod.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicarePayPaymentMethod implements Serializable
{
	private static final long serialVersionUID = 6395871222978991940L;
	private String accNickName;
	private String accountStatus;
	private String routingNumber;
	private String accountName;
	private MedicarePayPaymentTypeEnum paymentType;
	private String requestType;
	private MedicarePayAddress billingAddress;
	private MedicarePayAcctTypeEnum bankAccountType;
	private String expiration;
	private String confirmAccountNo;
	private String tokenId;
	private String maskedAccountNumber;
	private String tokenStatus;
	private boolean isForFutureUse;
	private boolean isSelectedForPayment;

	public String getAccNickName()
	{
		return accNickName;
	}

	public void setAccNickName(String accNickName)
	{
		this.accNickName = accNickName;
	}

	public String getAccountStatus()
	{
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus)
	{
		this.accountStatus = accountStatus;
	}

	public String getRoutingNumber()
	{
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber)
	{
		this.routingNumber = routingNumber;
	}

	public String getAccountName()
	{
		return accountName;
	}

	public void setAccountName(String accountName)
	{
		this.accountName = accountName;
	}

	public MedicarePayPaymentTypeEnum getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(MedicarePayPaymentTypeEnum paymentType)
	{
		this.paymentType = paymentType;
	}

	public String getRequestType()
	{
		return requestType;
	}

	public void setRequestType(String requestType)
	{
		this.requestType = requestType;
	}

	public MedicarePayAddress getBillingAddress()
	{
		return billingAddress;
	}

	public void setBillingAddress(MedicarePayAddress billingAddress)
	{
		this.billingAddress = billingAddress;
	}

	public MedicarePayAcctTypeEnum getBankAccountType()
	{
		return bankAccountType;
	}

	public void setBankAccountType(MedicarePayAcctTypeEnum bankAccountType)
	{
		this.bankAccountType = bankAccountType;
	}

	public String getExpiration()
	{
		return expiration;
	}

	public void setExpiration(String expiration)
	{
		this.expiration = expiration;
	}

	public String getConfirmAccountNo()
	{
		return confirmAccountNo;
	}

	public void setConfirmAccountNo(String confirmAccountNo)
	{
		this.confirmAccountNo = confirmAccountNo;
	}

	public String getTokenId()
	{
		return tokenId;
	}

	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	public String getMaskedAccountNumber()
	{
		return maskedAccountNumber;
	}

	public void setMaskedAccountNumber(String maskedAccountNumber)
	{
		this.maskedAccountNumber = maskedAccountNumber;
	}

	public String getTokenStatus()
	{
		return tokenStatus;
	}

	public void setTokenStatus(String tokenStatus)
	{
		this.tokenStatus = tokenStatus;
	}

	public void setForFutureUse(boolean isForFutureUse)
	{
		this.isForFutureUse = isForFutureUse;
	}

	public boolean isForFutureUse()
	{
		return isForFutureUse;
	}

	public void setSelectedForPayment(boolean isSelectedForPayment)
	{
		this.isSelectedForPayment = isSelectedForPayment;
	}

	public boolean isSelectedForPayment()
	{
		return isSelectedForPayment;
	}

	public static MedicarePayPaymentMethod dozerCreateMethodActiveBank()
	{
		MedicarePayPaymentMethod entry = new MedicarePayPaymentMethod();
		entry.setPaymentType(MedicarePayPaymentTypeEnum.BANKINGACCOUNT);
		entry.setAccountStatus("ACTIVE");
		return entry;
	}

	public static MedicarePayPaymentMethod dozerCreateMethodActiveCC()
	{
		MedicarePayPaymentMethod entry = new MedicarePayPaymentMethod();
		entry.setPaymentType(MedicarePayPaymentTypeEnum.CREDITDEBITCARD);
		entry.setAccountStatus("ACTIVE");
		return entry;
	}
}
