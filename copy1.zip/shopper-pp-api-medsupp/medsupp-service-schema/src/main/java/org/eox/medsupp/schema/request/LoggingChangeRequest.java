/**
* LoggingChangeRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 05/02/2015  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.request;

import java.io.Serializable;

public class LoggingChangeRequest implements Serializable
{

	private static final long serialVersionUID = -5471298871648460506L;

	private String propFileName;
	private String propsKey;
	private String propsValue;

	/**
	 * @return the propFileName
	 */
	public String getPropFileName()
	{
		return propFileName;
	}

	/**
	 * @param propFileName the propFileName to set
	 */
	public void setPropFileName(String propFileName)
	{
		this.propFileName = propFileName;
	}

	public String getPropsKey() {
		return propsKey;
	}

	public void setPropsKey(String propsKey) {
		this.propsKey = propsKey;
	}

	public String getPropsValue() {
		return propsValue;
	}

	public void setPropsValue(String propsValue) {
		this.propsValue = propsValue;
	}
	
}
