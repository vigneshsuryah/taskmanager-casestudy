package org.eox.medsupp.schema.model;

import java.io.Serializable;
import java.util.List;

public class Bill implements Serializable{

	private static final long serialVersionUID = 3698749922479945159L;

	private String dueDate;
	
	private int billDays;
	
	private int billFrequency;
	
	private String billFrequenceDescription;
	
	private String billGroupId;
	
	private String billType;
	
	private String billProcessedDate;
	
	private float billedAmount;
	
	private float billNetDue;
	
	private String paidStatus;
	
	private float reconciliationAmount;
	
	private float minimumAmountDue;
	
	private String summaryGroupId;
	
	private String billFromDateOriginal;
	
	private String billToDateOriginal;
	
	private List<Payment> payments;

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public int getBillDays() {
		return billDays;
	}

	public void setBillDays(int billDays) {
		this.billDays = billDays;
	}

	public int getBillFrequency() {
		return billFrequency;
	}

	public void setBillFrequency(int billFrequency) {
		this.billFrequency = billFrequency;
	}

	public String getBillFrequenceDescription() {
		return billFrequenceDescription;
	}

	public void setBillFrequenceDescription(String billFrequenceDescription) {
		this.billFrequenceDescription = billFrequenceDescription;
	}

	public String getBillGroupId() {
		return billGroupId;
	}

	public void setBillGroupId(String billGroupId) {
		this.billGroupId = billGroupId;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getBillProcessedDate() {
		return billProcessedDate;
	}

	public void setBillProcessedDate(String billProcessedDate) {
		this.billProcessedDate = billProcessedDate;
	}

	public float getBilledAmount() {
		return billedAmount;
	}

	public void setBilledAmount(float billedAmount) {
		this.billedAmount = billedAmount;
	}

	public float getBillNetDue() {
		return billNetDue;
	}

	public void setBillNetDue(float billNetDue) {
		this.billNetDue = billNetDue;
	}

	public String getPaidStatus() {
		return paidStatus;
	}

	public void setPaidStatus(String paidStatus) {
		this.paidStatus = paidStatus;
	}

	public float getReconciliationAmount() {
		return reconciliationAmount;
	}

	public void setReconciliationAmount(float reconciliationAmount) {
		this.reconciliationAmount = reconciliationAmount;
	}

	public float getMinimumAmountDue() {
		return minimumAmountDue;
	}

	public void setMinimumAmountDue(float minimumAmountDue) {
		this.minimumAmountDue = minimumAmountDue;
	}

	public String getSummaryGroupId() {
		return summaryGroupId;
	}

	public void setSummaryGroupId(String summaryGroupId) {
		this.summaryGroupId = summaryGroupId;
	}

	public String getBillFromDateOriginal() {
		return billFromDateOriginal;
	}

	public void setBillFromDateOriginal(String billFromDateOriginal) {
		this.billFromDateOriginal = billFromDateOriginal;
	}

	public String getBillToDateOriginal() {
		return billToDateOriginal;
	}

	public void setBillToDateOriginal(String billToDateOriginal) {
		this.billToDateOriginal = billToDateOriginal;
	}

	public List<Payment> getPayments() {
		return payments;
	}

	public void setPayments(List<Payment> payments) {
		this.payments = payments;
	}

	@Override
	public String toString() {
		return "Bill [dueDate=" + dueDate + ", billDays=" + billDays + ", billFrequency=" + billFrequency
				+ ", billFrequenceDescription=" + billFrequenceDescription + ", billGroupId=" + billGroupId
				+ ", billType=" + billType + ", billProcessedDate=" + billProcessedDate + ", billedAmount="
				+ billedAmount + ", billNetDue=" + billNetDue + ", paidStatus=" + paidStatus + ", reconciliationAmount="
				+ reconciliationAmount + ", minimumAmountDue=" + minimumAmountDue + ", summaryGroupId=" + summaryGroupId
				+ ", billFromDateOriginal=" + billFromDateOriginal + ", billToDateOriginal=" + billToDateOriginal
				+ ", payments=" + payments + "]";
	}

}
