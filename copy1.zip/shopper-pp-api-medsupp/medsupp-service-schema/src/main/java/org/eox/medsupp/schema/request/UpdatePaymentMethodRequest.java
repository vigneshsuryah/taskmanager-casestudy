/**
 * UpdatePaymentMethodRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdatePaymentMethodRequest extends BaseRequest
{
	private static final long serialVersionUID = 1L;

	private String summaryNumber;
	private String action;
	private MedicarePayPaymentMethod paymentMethod;
	private String csrId;

	public String getSummaryNumber()
	{
		return summaryNumber;
	}

	public void setSummaryNumber(String summaryNumber)
	{
		this.summaryNumber = summaryNumber;
	}

	public String getAction()
	{
		return action;
	}

	public void setAction(String action)
	{
		this.action = action;
	}

	public MedicarePayPaymentMethod getPaymentMethod()
	{
		return paymentMethod;
	}

	public void setPaymentMethod(MedicarePayPaymentMethod paymentMethod)
	{
		this.paymentMethod = paymentMethod;
	}

	public String getCsrId()
	{
		return csrId;
	}

	public void setCsrId(String csrId)
	{
		this.csrId = csrId;
	}

}
