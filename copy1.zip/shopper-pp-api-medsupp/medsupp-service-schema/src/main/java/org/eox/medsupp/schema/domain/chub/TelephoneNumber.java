/**
 * TelephoneNumber.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


public class TelephoneNumber
{
	private String efctvDt;
	private String trmntnDt;
	private String tlphnStatus;
	private String tlphTypCd;
	private String tlphnNbr;
	private String araCdNbr;
	private String tlphnExtn;
	private String deviceType;

	public String getEfctvDt()
	{
		return efctvDt;
	}

	public void setEfctvDt(String efctvDt)
	{
		this.efctvDt = efctvDt;
	}

	public String getTrmntnDt()
	{
		return trmntnDt;
	}

	public void setTrmntnDt(String trmntnDt)
	{
		this.trmntnDt = trmntnDt;
	}

	public String getTlphnStatus()
	{
		return tlphnStatus;
	}

	public void setTlphnStatus(String tlphnStatus)
	{
		this.tlphnStatus = tlphnStatus;
	}

	public String getTlphTypCd()
	{
		return tlphTypCd;
	}

	public void setTlphTypCd(String tlphTypCd)
	{
		this.tlphTypCd = tlphTypCd;
	}

	public String getTlphnNbr()
	{
		return tlphnNbr;
	}

	public void setTlphnNbr(String tlphnNbr)
	{
		this.tlphnNbr = tlphnNbr;
	}

	public String getAraCdNbr()
	{
		return araCdNbr;
	}

	public void setAraCdNbr(String araCdNbr)
	{
		this.araCdNbr = araCdNbr;
	}

	public String getTlphnExtn()
	{
		return tlphnExtn;
	}

	public void setTlphnExtn(String tlphnExtn)
	{
		this.tlphnExtn = tlphnExtn;
	}

	public String getDeviceType()
	{
		return deviceType;
	}

	public void setDeviceType(String deviceType)
	{
		this.deviceType = deviceType;
	}
}
