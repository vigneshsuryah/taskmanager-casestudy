package org.eox.medsupp.paymod.request;

public class Note {

	private String csrId;
	private String noteDesc;
	private String action;
	
	public String getCsrId() {
		return csrId;
	}
	public void setCsrId(String csrId) {
		this.csrId = csrId;
	}
	public String getNoteDesc() {
		return noteDesc;
	}
	public void setNoteDesc(String noteDesc) {
		this.noteDesc = noteDesc;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

}
