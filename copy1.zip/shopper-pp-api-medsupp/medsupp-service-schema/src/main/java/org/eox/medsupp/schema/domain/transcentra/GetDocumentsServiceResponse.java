/**
 * GetDocumentsServiceResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.transcentra;


public class GetDocumentsServiceResponse
{
	private String documentUrl;

	public String getDocumentUrl()
	{
		return documentUrl;
	}

	public void setDocumentUrl(String documentUrl)
	{
		this.documentUrl = documentUrl;
	}

}
