/**
 * GetAutoPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/13/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetAutoPaymentRequest extends BaseRequest
{

	private static final long serialVersionUID = 1L;

}
