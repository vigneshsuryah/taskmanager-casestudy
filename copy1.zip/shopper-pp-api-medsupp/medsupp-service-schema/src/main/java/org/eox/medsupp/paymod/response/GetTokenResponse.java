/**
 * GetTokenResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetTokenResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String encryptedToken;
	private Exceptions exceptions;
	private String reasonCode;
	private String actionCode;
	private String levelTInd;
	private String authorizationCode;
	private String tokenPaidDate;
	private String avsaav;
	private String messageType;
	private String originalTransactionAmount;
	private String recordType;
	private String submittedTransactionID;
	private String responseTransactionID;
	private String storedCredentialFlag;
	
	
	
	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getOriginalTransactionAmount() {
		return originalTransactionAmount;
	}

	public void setOriginalTransactionAmount(String originalTransactionAmount) {
		this.originalTransactionAmount = originalTransactionAmount;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}

	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}

	public String getResponseTransactionID() {
		return responseTransactionID;
	}

	public void setResponseTransactionID(String responseTransactionID) {
		this.responseTransactionID = responseTransactionID;
	}

	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}

	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getLevelTInd() {
		return levelTInd;
	}

	public void setLevelTInd(String levelTInd) {
		this.levelTInd = levelTInd;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public String getTokenPaidDate() {
		return tokenPaidDate;
	}

	public void setTokenPaidDate(String tokenPaidDate) {
		this.tokenPaidDate = tokenPaidDate;
	}

	public String getEncryptedToken() {
		return encryptedToken;
	}

	public void setEncryptedToken(String encryptedToken) {
		this.encryptedToken = encryptedToken;
	}

	public Exceptions getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions exceptions) {
		this.exceptions = exceptions;
	}

	public String getAvsaav() {
		return avsaav;
	}

	public void setAvsaav(String avsaav) {
		this.avsaav = avsaav;
	}

}
