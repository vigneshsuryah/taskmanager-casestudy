/**
 * MedicarePayPaymentStatus.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


import java.io.Serializable;


public class MedicarePayPaymentStatus implements Serializable
{
	private static final long serialVersionUID = -257723363095970614L;

	private String paymentProcess;

	private String payNowStatus;

	private String shortContent;

	private String showContent;

	private String contentDescription;

	private String mamStatusCode;

	private String paymentProgress;

	private String schedulePaymentStatus;

	public String getMamStatusCode()
	{
		return mamStatusCode;
	}

	public void setMamStatusCode(String mamStatusCode)
	{
		this.mamStatusCode = mamStatusCode;
	}

	public String getPaymentProgress()
	{
		return paymentProgress;
	}

	public void setPaymentProgress(String paymentProgress)
	{
		this.paymentProgress = paymentProgress;
	}

	public String getSchedulePaymentStatus()
	{
		return schedulePaymentStatus;
	}

	public void setSchedulePaymentStatus(String schedulePaymentStatus)
	{
		this.schedulePaymentStatus = schedulePaymentStatus;
	}

	public String getPaymentProcess()
	{
		return paymentProcess;
	}

	public void setPaymentProcess(String paymentProcess)
	{
		this.paymentProcess = paymentProcess;
	}

	public String getPayNowStatus()
	{
		return payNowStatus;
	}

	public void setPayNowStatus(String payNowStatus)
	{
		this.payNowStatus = payNowStatus;
	}

	public String getShortContent()
	{
		return shortContent;
	}

	public void setShortContent(String shortContent)
	{
		this.shortContent = shortContent;
	}

	public String getShowContent()
	{
		return showContent;
	}

	public void setShowContent(String showContent)
	{
		this.showContent = showContent;
	}

	public String getContentDescription()
	{
		return contentDescription;
	}

	public void setContentDescription(String contentDescription)
	{
		this.contentDescription = contentDescription;
	}

}
