/**
 * GetMbrContactMethodServiceResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/21/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.io.Serializable;
import java.util.List;

import org.eox.medsupp.schema.domain.chub.CommComponent;


public class GetMbrContactMethodServiceResponse implements Serializable
{
	private static final long serialVersionUID = 8209535187042206064L;
	private List<CommComponent> commComponent;

	public List<CommComponent> getCommComponent()
	{
		return commComponent;
	}

	public void setCommComponent(List<CommComponent> commComponent)
	{
		this.commComponent = commComponent;
	}

}
