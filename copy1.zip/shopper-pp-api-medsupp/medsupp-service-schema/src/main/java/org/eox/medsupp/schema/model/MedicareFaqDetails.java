package org.eox.medsupp.schema.model;

import java.io.Serializable;


public class MedicareFaqDetails implements Serializable
{

	private static final long serialVersionUID = 7589801046410799120L;
	private int faqId;
	private MedicareFAQ medicareFAQ;

	/**
	 * @return the faqId
	 */
	public int getFaqId()
	{
		return faqId;
	}

	/**
	 * @param faqId
	 *            the faqId to set
	 */
	public void setFaqId(int faqId)
	{
		this.faqId = faqId;
	}

	/**
	 * @return the medicareFAQ
	 */
	public MedicareFAQ getMedicareFAQ()
	{
		return medicareFAQ;
	}

	/**
	 * @param medicareFAQ
	 *            the medicareFAQ to set
	 */
	public void setMedicareFAQ(MedicareFAQ medicareFAQ)
	{
		this.medicareFAQ = medicareFAQ;
	}
}
