/**
 * SearchPayModPaymentResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/05/2019  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.paymod.response;

import java.util.List;

import org.eox.medsupp.paymod.request.PayModSubmitPaymentRequest;

public class SearchPayModPaymentResponse {

	private List<PayModSubmitPaymentRequest> paymentDetailsVOs;
	private Exceptions exceptions;

	public List<PayModSubmitPaymentRequest> getPaymentDetailsVOs() {
		return paymentDetailsVOs;
	}

	public void setPaymentDetailsVOs(List<PayModSubmitPaymentRequest> paymentDetailsVOs) {
		this.paymentDetailsVOs = paymentDetailsVOs;
	}

	public Exceptions getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions exceptions) {
		this.exceptions = exceptions;
	}

}
