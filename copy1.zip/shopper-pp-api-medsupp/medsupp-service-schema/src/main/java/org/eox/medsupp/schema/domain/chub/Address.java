/**
 * Address.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.domain.chub;


public class Address
{
	private String mncpltyNm;
	private String adrsLn3Txt;
	private String cntryNm;
	private String adrseNm;
	private String nmPrfx;
	private String efctvDt;
	private String trmntnDt;
	private String adrsStatus;
	private String adrsTypCd;
	private String adrsLn1Txt;
	private String adrsLn2Txt;
	private String ctyNm;
	private String stCd;
	private String pstlCd;
	private String cntyCd;
	private String tmZn;

	public String getMncpltyNm()
	{
		return mncpltyNm;
	}

	public void setMncpltyNm(String mncpltyNm)
	{
		this.mncpltyNm = mncpltyNm;
	}

	public String getAdrsLn3Txt()
	{
		return adrsLn3Txt;
	}

	public void setAdrsLn3Txt(String adrsLn3Txt)
	{
		this.adrsLn3Txt = adrsLn3Txt;
	}

	public String getCntryNm()
	{
		return cntryNm;
	}

	public void setCntryNm(String cntryNm)
	{
		this.cntryNm = cntryNm;
	}

	public String getAdrseNm()
	{
		return adrseNm;
	}

	public void setAdrseNm(String adrseNm)
	{
		this.adrseNm = adrseNm;
	}

	public String getNmPrfx()
	{
		return nmPrfx;
	}

	public void setNmPrfx(String nmPrfx)
	{
		this.nmPrfx = nmPrfx;
	}

	public String getEfctvDt()
	{
		return efctvDt;
	}

	public void setEfctvDt(String efctvDt)
	{
		this.efctvDt = efctvDt;
	}

	public String getTrmntnDt()
	{
		return trmntnDt;
	}

	public void setTrmntnDt(String trmntnDt)
	{
		this.trmntnDt = trmntnDt;
	}

	public String getAdrsStatus()
	{
		return adrsStatus;
	}

	public void setAdrsStatus(String adrsStatus)
	{
		this.adrsStatus = adrsStatus;
	}

	public String getAdrsTypCd()
	{
		return adrsTypCd;
	}

	public void setAdrsTypCd(String adrsTypCd)
	{
		this.adrsTypCd = adrsTypCd;
	}

	public String getAdrsLn1Txt()
	{
		return adrsLn1Txt;
	}

	public void setAdrsLn1Txt(String adrsLn1Txt)
	{
		this.adrsLn1Txt = adrsLn1Txt;
	}

	public String getAdrsLn2Txt()
	{
		return adrsLn2Txt;
	}

	public void setAdrsLn2Txt(String adrsLn2Txt)
	{
		this.adrsLn2Txt = adrsLn2Txt;
	}

	public String getCtyNm()
	{
		return ctyNm;
	}

	public void setCtyNm(String ctyNm)
	{
		this.ctyNm = ctyNm;
	}

	public String getStCd()
	{
		return stCd;
	}

	public void setStCd(String stCd)
	{
		this.stCd = stCd;
	}

	public String getPstlCd()
	{
		return pstlCd;
	}

	public void setPstlCd(String pstlCd)
	{
		this.pstlCd = pstlCd;
	}

	public String getCntyCd()
	{
		return cntyCd;
	}

	public void setCntyCd(String cntyCd)
	{
		this.cntyCd = cntyCd;
	}

	public String getTmZn()
	{
		return tmZn;
	}

	public void setTmZn(String tmZn)
	{
		this.tmZn = tmZn;
	}
}
