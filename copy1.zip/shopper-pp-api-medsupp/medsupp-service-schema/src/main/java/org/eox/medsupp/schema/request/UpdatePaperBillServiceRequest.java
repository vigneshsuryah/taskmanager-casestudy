/**
 * UpdatePaperBillServiceRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;

import java.io.Serializable;


public class UpdatePaperBillServiceRequest implements Serializable
{
	private static final long serialVersionUID = -7011038015034818215L;
	private String groupId;
	private String subscriberId;
	private String memberSequenceNumber;
	private String sourceSystemId;
	private String suppressEmailInd;
	private String preferenceType;
	private String preferenceOpt;
	private String preferenceEffectiveDate;
	private String emailTypeCode;
	private String emailAddress;
	private String emailEffectiveDate;
	private String sourceChannel;

	public String getGroupId()
	{
		return groupId;
	}

	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	public String getSubscriberId()
	{
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId)
	{
		this.subscriberId = subscriberId;
	}

	public String getMemberSequenceNumber()
	{
		return memberSequenceNumber;
	}

	public void setMemberSequenceNumber(String memberSequenceNumber)
	{
		this.memberSequenceNumber = memberSequenceNumber;
	}

	public String getSourceSystemId()
	{
		return sourceSystemId;
	}

	public void setSourceSystemId(String sourceSystemId)
	{
		this.sourceSystemId = sourceSystemId;
	}

	public String getSuppressEmailInd()
	{
		return suppressEmailInd;
	}

	public void setSuppressEmailInd(String suppressEmailInd)
	{
		this.suppressEmailInd = suppressEmailInd;
	}

	public String getPreferenceType()
	{
		return preferenceType;
	}

	public void setPreferenceType(String preferenceType)
	{
		this.preferenceType = preferenceType;
	}

	public String getPreferenceOpt()
	{
		return preferenceOpt;
	}

	public void setPreferenceOpt(String preferenceOpt)
	{
		this.preferenceOpt = preferenceOpt;
	}

	public String getPreferenceEffectiveDate()
	{
		return preferenceEffectiveDate;
	}

	public void setPreferenceEffectiveDate(String preferenceEffectiveDate)
	{
		this.preferenceEffectiveDate = preferenceEffectiveDate;
	}

	public String getEmailTypeCode()
	{
		return emailTypeCode;
	}

	public void setEmailTypeCode(String emailTypeCode)
	{
		this.emailTypeCode = emailTypeCode;
	}

	public String getEmailAddress()
	{
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	public String getEmailEffectiveDate()
	{
		return emailEffectiveDate;
	}

	public void setEmailEffectiveDate(String emailEffectiveDate)
	{
		this.emailEffectiveDate = emailEffectiveDate;
	}

	public String getSourceChannel()
	{
		return sourceChannel;
	}

	public void setSourceChannel(String sourceChannel)
	{
		this.sourceChannel = sourceChannel;
	}
}
