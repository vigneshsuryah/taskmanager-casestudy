/**
 * MedicarePayConstants.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 02/05/2019  2.0      Cognizant       CSR - Chase Integration
 * 03/25/2019  1.0      Cognizant       SMC mail changes
 */
package org.eox.medsupp.schema.utililty;

public interface MedicarePayConstants
{
	String HEADER_ACCEPT = "Accept=*/*";
	String APPLICATION_TYPE_JSON = "application/json";
	String APP_PRODUCE_TYPE_1 = "application/json; charset=UTF-8";
	String APP_PRODUCE_TYPE_2 = "text/html;charset=UTF-8";
	String APP_USERNAME = "userName";
	String APP_AUTHKEY = "password";

	String PAYMENT="payment";
	String PAYMENT_RESP="Payment Received";
	String REFUND="refund";
	String REFUND_RESP="Adjustment";
	String MA = "MA";
	String MS = "MedSupp";
	String ADVANTAGE="Medicare Advantage";
	String SUPPLEMENT="Medicare Supplement";
	
	String OUT_GOING_ID = "OUT_GOING_ID";
	String META_SENDERAPP = "meta-senderapp";
	String OUT_GOING_SBRID = "OUT_GOING_SBRID";

	String EXCEPTION = "E";
	String INFORMATION = "I";

	String TECHNICAL_ERROR_MSG = "We've encountered a technical error";
	String TECHNICAL_ERROR_MSG_9003 = "We've encountered an exception in the ACI service due to invalid Request / Response.";
	String TECHNICAL_ERROR_MSG_9006 = "We've encountered a technical error in accessing Membership Service ";
	String INVALID_HCID_ERROR_MSG = "Sorry, we can't find that member ID number.";

	String ACI_FUNDING_ERRORCODE_1075 = "1075";
	String ACI_FUNDING_ERRORCODE_500 = "500";
	String ACI_FUNDING_SUCCESS_CODE_0 = "0";
	String ACI_FUNDING_ERRORCODE_9006 = "9006";

	String BANKINGACCOUNT = "BANKINGACCOUNT";
	String MEDSUP_SOURCE = "MEDSUP";
	String ACTIVE = "ACTIVE";
	String INACTIVE = "INACTIVE";

	String OUT_OPERATION = "OUT_OPERATION";
	String ACI_PAYMENT_CANCEL_FAIL_STATUS = "Failed";
	String CANCELPAYMENT_SERVICE_FAILED = "Cancel Payment Failed";

	String META_TARGET_SRC = "meta-target-source";
	String META_SRC_ENV="meta-src-envrmt";
	
	// Linked bill
	String LINK_ACTION_ADD = "ADD";
	String LINK_ACTION_REMOVE = "remove";
	String LINK_ACTION_DENY = "deny";
	String LINK_ACTION_APPROVE = "approve";
	String LINK_STATUS_APPROVE = "A";
	String LINK_STATUS_DENY = "D";
	String LINK_STATUS_REMOVE = "R";
	String INDV_MEDICARE_SUPP = "MEDICARE_SUPPLEMENT";
	String BRAND_UNICARE = "UNICARE";
	String LINK_LOGGEDIN_HCID = "loggedInHcid";
	String BRAND = "brand";
	String UNICARE = "SUP000";
	String AMERIVANTAGE = "MCR000";
	String EMPLOYER_BILL = "EMPLOYER";
	String LINK_TO_HCID = "childHcid";
	String LINK_ACTION_URL = "actionUrl";
	String LINK_CONTENT_KEY = "contentKey";
	String STATUS_UPDATE_SUCCESS = "Success";
	String LINK_PARENT_NAME = "parentName";
	String LINK_TO_EMAIL = "toEmailAddress";
	String MAIL_FROM = "noreply@anthem.com";
	String MAIL_TYPE = "Application";

	String OPT_IN_PREFERENCE = "7";
	String SOURCE_SYSTEM_ID = "705";
	String PREMIUM_NOTIFICATION_CONSENT = "100031";
	String EMAIL_TYPE_CODE = "100014";
	String SOURCE_CHANNEL = "100012";
	String MAIL_PREFERENCE_TYPE = "100002";
	String OPT_IN = "Opt-In";

	String RECURRING_PAY_ACTION_DELETE = "DEL";
	String RECURRING_PAY_UPDATE_FAILED = "Failed";
	String RECURRING_PAYMENT_ACTIVE = "ACTIVE";
	String ACI_PAYMENT_PENDING_STATUS = "PENDING";
	String ACI_PAYMENT_SCHEDULED_STATUS = "SCHEDULED";
	String YES_STR = "Yes";
	String NO_STR = "No";
	String DATE_FORMAT_yyyyMMdd = "yyyy-MM-dd";

	String WS_CONTEXT_LOG_ID = "WS_CONTEXT_LOG_ID";
	String WS_CONTEXT_OPERATION_NAME = "WS_CONTEXT_OPERATION";
	String OPERATION_NAME_CHUB_UPDATE = "Update_MbrContactMethod";
	String OPERATION_NAME_CHUB_GET = "Get_MbrContactMethod";
	String WS_CONTEXT_TRANS_ID = "WS_CONTEXT_TRANS_ID";
	String OPERATION_NAME_TRANSCENTRA_SEARCHDOC = "searchDocuments";
	String OPERATION_NAME_TRANSCENTRA_GETDOC = "getDocuments";
	String CHILD = "child";
	String PARENT = "parent";
	String LOB_MA = "MA";
	String LOB_MEDSUPP = "MEDSUPP";
	String TRAN_DOC_TYPE = "DPS";
	String MA_DOC_VAL = "WPT070";
	String MEDSUPP_DOC_VAL = "WPT170";

	String ALLOW_BUTTON_LOGO = "allowButtonLogo";
	String DENY_BUTTON_LOGO = "denyButtonLogo";
	String EMAIL_IMAGES = "/emailImages/";
	String UNDERSCORE = "_";
	String PNG = ".png";

	String APIKEY = "apiKey";
	String MEMBER_PROFILE_SERVICE = "getMemberProfile";
	String ONDEMAND_BILL_DATE_FORMAT = "MM/dd/yyyy";
	String STATE_VA = "VA";
	String PAY_METHOD_COUPON = "CPN";

	String MAIL_TYPE_ADD_LINK_ACC = "ADD_LINK_ACC";
	String MAIL_TYPE_REMOVE_LINK_ACC = "REMOVE_LINK_ACC";
	String MAIL_TYPE_PAY_FAILED = "PAYMENT_FAILURE";
	String ADD_LINK_ACC_TEMP_ID = "New Linked Account Confirmation - Important Plan Information";
	
	String ERROR_CODE_9000 = "9000";
	String ERROR_CODE_9011 = "9011";
	String ERROR_CODE_9012 = "9012";
	String ERROR_CODE_9013 = "9013";
	String ERROR_CODE_9014 = "9014";
	String ERROR_CODE_9015 = "9015";
	
	String SOA_PAY_SUCCESS_MAIL_SERVICE = "medsuppSoaPaySuccessMail";
	String META_TRANS_ID = "meta-transid";
	String SMC_PAY_SUCCESS_MAIL_FROM = "MEDSUPP API";
	String SMC_PAY_SUCCESS_MAIL_SUB = "SMC Payment Success Mail";
	
	String MEMBER_BILLING_SERVICE = "getMemberBilling";
	
	/*PP-6430,PP-6431,PP-6432,PP-6433 GA rebranding starts*/
	String GA_STATE_STR = "GA";
	String GA_REBRAND_DEF_DATE = "2019-01-01";
	String GA_RE_BRAND_TODAY_DATE_CHANGE = "medicarepay.setting.ga.rebrand.today.date";
	String GA_RE_BRAND_TODAY_DATE_CHANGE_REQUIRED = "medicarepay.setting.ga.rebrand.today.date.change.required";
	String GA_TODAY_DATE_CHANGE_REQUIRED = "Y";
	String DATE_FMT = "yyyy-MM-dd";
	String GA_MS_LOB = "MEDSUPP";
	String GA_MA_LOB = "MA";
	String GA_MS_GRP_ID = "GASUPWP0";
	String GA_REBRAND_MS_AUTO_PDF = "GA MS Rebranding2019.pdf";
	String GA_REBRAND_MA_HMO_AUTO_PDF = "GA MA HMO Rebranding2019.pdf";
	String GA_REBRAND_MA_LPPO_AUTO_PDF = "GA MA LPPO Rebranding2019.pdf";
	String GA_CLASS_ID_LPPO = "L";
	String GA_CLASS_ID_HMO = "H";
	String MEDICAREPAY_SETTING_GA_REBRANDING_DATE = "medicarepay.setting.ga.rebranding.date";
	String GA_RE_BRAND_EFF_DATE_CHANGE = "medicarepay.setting.ga.rebranding.effective.overrideDate";
	String GA_RE_BRAND_EFF_DATE_CHANGE_REQUIRED = "medicarepay.setting.ga.rebranding.effective.overrideInd";
	/*PP-6430,PP-6431,PP-6432,PP-6433 GA rebranding starts*/
	
	//PP-14143 - Start
	String CASHAPI_OUT_GOING_ID="OUT_GOING_ID";
	String PAYMOD_OPERATON_NAME="PayMod-Api";
	String PAY_MOD_REQUEST_APP="requestApplication";
	String PAY_MOD_USER_NAME="userName";
	String PAY_MOD_AUTH_KEY="password";
	String PAY_MOD_MS_LOB = "MSUP";
	String PAY_MOD_MA_LOB = "MADV";
	String[] PAY_MOD_TRAN_STATUS = {"PENDING","STAGED","EDIACCEPTED","SUBMITTED","ACCEPTED"};
	String[] PAY_MOD_TRAN_TYPE = {"PAYMENT"};
	String TRAN_STS_PENDING = "PENDING";
	String TRAN_STS_STAGED = "STAGED";
	String TRAN_TYPE_PAYMENT = "PAYMENT";
	String PAY_MOD_PAY_TYP_ACH = "ACH";
	String PAY_MOD_PAID_DATE_FMT = "yyyy-MM-dd HH:mm:ss.SSS";
	String PAY_MOD_DATE_FMT = "yyyy-MM-dd";
	
	String UNAUTHORIZED_CSR_ERROR = "Unauthorized to make payment for this HCID";
	//PP-14143 - End
	
	String SUCCESS = "Success";
	
	//PP-15970 - Start
	String SMC_PAYMENT_CONFIRMATION = "PaymentConfirmation";
	String SMC_PAYMENT_CANCELLATION = "PaymentCancellation";
	String SMC_EVENT_GENERATOR = "PPORT";
	//PP-15970 - End
}
