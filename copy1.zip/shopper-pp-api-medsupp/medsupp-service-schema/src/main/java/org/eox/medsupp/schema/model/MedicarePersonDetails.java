package org.eox.medsupp.schema.model;


import java.io.Serializable;


public class MedicarePersonDetails implements Serializable
{
	private static final long serialVersionUID = 2296698516102578805L;
	private String firstName;
	private String lastName;
	private String childMemberId;

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getChildMemberId()
	{
		return childMemberId;
	}

	public void setChildMemberId(String childMemberId)
	{
		this.childMemberId = childMemberId;
	}

}
