/**
 * SOAMemberProfile.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 * 03/25/2019  1.0      Cognizant       SMC mail changes
 */
package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class SOAMemberProfile implements Serializable{

	private static final long serialVersionUID = 2325268730133216644L;

	private String lob;
	
	private String state;
	
	private String groupId;
	
	private String classId;
	
	private String payAmt;
	
	private String confirmationNbr;
	
	private String paymentHcid;
	
	private String hcid;
	
	private String planId;
	
	//PP-15970 - Start
	private String emailAddr;
	
	private String payIndicator;
	
	/**
	 * @return the emailAddr
	 */
	public String getEmailAddr() {
		return emailAddr;
	}

	/**
	 * @param emailAddr the emailAddr to set
	 */
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}
	
	/**
	 * @return the payIndicator
	 */
	public String getPayIndicator() {
		return payIndicator;
	}

	/**
	 * @param payIndicator the payIndicator to set
	 */
	public void setPayIndicator(String payIndicator) {
		this.payIndicator = payIndicator;
	}
	//PP-15970 - End

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the classId
	 */
	public String getClassId() {
		return classId;
	}

	/**
	 * @param classId the classId to set
	 */
	public void setClassId(String classId) {
		this.classId = classId;
	}

	/**
	 * @return the payAmt
	 */
	public String getPayAmt() {
		return payAmt;
	}

	/**
	 * @param payAmt the payAmt to set
	 */
	public void setPayAmt(String payAmt) {
		this.payAmt = payAmt;
	}

	/**
	 * @return the confirmationNbr
	 */
	public String getConfirmationNbr() {
		return confirmationNbr;
	}

	/**
	 * @param confirmationNbr the confirmationNbr to set
	 */
	public void setConfirmationNbr(String confirmationNbr) {
		this.confirmationNbr = confirmationNbr;
	}

	/**
	 * @return the paymentHcid
	 */
	public String getPaymentHcid() {
		return paymentHcid;
	}

	/**
	 * @param paymentHcid the paymentHcid to set
	 */
	public void setPaymentHcid(String paymentHcid) {
		this.paymentHcid = paymentHcid;
	}

	/**
	 * @return the hcid
	 */
	public String getHcid() {
		return hcid;
	}

	/**
	 * @param hcid the hcid to set
	 */
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

}
