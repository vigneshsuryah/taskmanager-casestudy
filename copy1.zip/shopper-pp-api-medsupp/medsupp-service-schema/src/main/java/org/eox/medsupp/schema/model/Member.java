/**
* Member.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/04/2017  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class Member implements Serializable{

	private static final long serialVersionUID = -7033968565886728209L;
	private String hcid;
	private String mbrSequenceNbr;
	
	public String getHcid() {
		return hcid;
	}
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}
	public String getMbrSequenceNbr() {
		return mbrSequenceNbr;
	}
	public void setMbrSequenceNbr(String mbrSequenceNbr) {
		this.mbrSequenceNbr = mbrSequenceNbr;
	}
}
