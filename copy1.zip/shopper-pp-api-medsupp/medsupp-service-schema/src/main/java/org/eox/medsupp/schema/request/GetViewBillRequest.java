/**
 * GetViewBillRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 03/09/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import org.eox.medsupp.schema.model.BillTypeEnum;


public class GetViewBillRequest extends BaseRequest
{

	private static final long serialVersionUID = -335016861518981211L;

	private String accountNumber;

	private String billDate;

	private String productId;

	private BillTypeEnum billTypeEnum;

	private Boolean isSummaryBill;
	
	private String summaryBillNumber;
	
	private String lob;
	
	private String billType;
	
	private String billGroupId;

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the billDate
	 */
	public String getBillDate() {
		return billDate;
	}

	/**
	 * @param billDate the billDate to set
	 */
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the billTypeEnum
	 */
	public BillTypeEnum getBillTypeEnum() {
		return billTypeEnum;
	}

	/**
	 * @param billTypeEnum the billTypeEnum to set
	 */
	public void setBillTypeEnum(BillTypeEnum billTypeEnum) {
		this.billTypeEnum = billTypeEnum;
	}

	/**
	 * @return the isSummaryBill
	 */
	public Boolean getIsSummaryBill() {
		return isSummaryBill;
	}

	/**
	 * @param isSummaryBill the isSummaryBill to set
	 */
	public void setIsSummaryBill(Boolean isSummaryBill) {
		this.isSummaryBill = isSummaryBill;
	}

	/**
	 * @return the summaryBillNumber
	 */
	public String getSummaryBillNumber() {
		return summaryBillNumber;
	}

	/**
	 * @param summaryBillNumber the summaryBillNumber to set
	 */
	public void setSummaryBillNumber(String summaryBillNumber) {
		if (summaryBillNumber != null)
		{
			this.summaryBillNumber = summaryBillNumber.toUpperCase();
		}
		else
		{
			this.summaryBillNumber = summaryBillNumber;
		}
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}

	/**
	 * @return the billGroupId
	 */
	public String getBillGroupId() {
		return billGroupId;
	}

	/**
	 * @param billGroupId the billGroupId to set
	 */
	public void setBillGroupId(String billGroupId) {
		this.billGroupId = billGroupId;
	}

	

}
