/**
 * SubmitPaymentRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;


import java.util.List;

import org.eox.medsupp.schema.model.MedicarePayPaymentTypeEnum;
import org.eox.medsupp.schema.model.MemberPaySubmitPayment;

import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;


public class SubmitPaymentRequest extends BaseRequest
{

	private static final long serialVersionUID = -1673846378257446616L;

	private List<MemberPaySubmitPayment> memberpaySubmitPayments;

	private boolean newPaymentMethod;

	private boolean payMetFutureUse;

	private MedicarePayPaymentTypeEnum paymentType;

	private BankAccountDetails bankAccountDetails;

	private CreditCardDetails creditCardDetails;

	private String tokenId;

	private String paymentDate;
	
	private String notes;
	
	private String csrEnteredEmailId;

	public List<MemberPaySubmitPayment> getMemberpaySubmitPayments()
	{
		return memberpaySubmitPayments;
	}

	public void setMemberpaySubmitPayments(List<MemberPaySubmitPayment> memberpaySubmitPayments)
	{
		this.memberpaySubmitPayments = memberpaySubmitPayments;
	}

	public boolean isNewPaymentMethod()
	{
		return newPaymentMethod;
	}

	public void setNewPaymentMethod(boolean newPaymentMethod)
	{
		this.newPaymentMethod = newPaymentMethod;
	}

	public boolean isPayMetFutureUse()
	{
		return payMetFutureUse;
	}

	public void setPayMetFutureUse(boolean payMetFutureUse)
	{
		this.payMetFutureUse = payMetFutureUse;
	}

	public MedicarePayPaymentTypeEnum getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(MedicarePayPaymentTypeEnum paymentType)
	{
		this.paymentType = paymentType;
	}

	public BankAccountDetails getBankAccountDetails()
	{
		return bankAccountDetails;
	}

	public void setBankAccountDetails(BankAccountDetails bankAccountDetails)
	{
		this.bankAccountDetails = bankAccountDetails;
	}

	public CreditCardDetails getCreditCardDetails()
	{
		return creditCardDetails;
	}

	public void setCreditCardDetails(CreditCardDetails creditCardDetails)
	{
		this.creditCardDetails = creditCardDetails;
	}

	public String getTokenId()
	{
		return tokenId;
	}

	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	public String getPaymentDate()
	{
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getCsrEnteredEmailId() {
		return csrEnteredEmailId;
	}

	public void setCsrEnteredEmailId(String csrEnteredEmailId) {
		this.csrEnteredEmailId = csrEnteredEmailId;
	}

}
