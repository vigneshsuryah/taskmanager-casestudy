/**
 * GetMbrContactMethodServiceRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/21/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.request;

import java.io.Serializable;


public class GetMbrContactMethodServiceRequest implements Serializable
{
	private static final long serialVersionUID = -9083807651944657028L;
	private String groupId;
	private String subscriberId;
	private String memberSequenceNumber;
	private String sourceSystemId;

	public String getGroupId()
	{
		return groupId;
	}

	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	public String getSubscriberId()
	{
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId)
	{
		this.subscriberId = subscriberId;
	}

	public String getMemberSequenceNumber()
	{
		return memberSequenceNumber;
	}

	public void setMemberSequenceNumber(String memberSequenceNumber)
	{
		this.memberSequenceNumber = memberSequenceNumber;
	}

	public String getSourceSystemId()
	{
		return sourceSystemId;
	}

	public void setSourceSystemId(String sourceSystemId)
	{
		this.sourceSystemId = sourceSystemId;
	}

}
