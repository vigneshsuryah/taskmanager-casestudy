package org.eox.medsupp.paymod.request;

import org.eox.medsupp.paymod.response.Exceptions;

public class MamDetailsBO {

	private String system;
	private String legalEntity;
	private String marketSegment;
	private String divisionCode;
	
	private Exceptions exceptions;
	
	private String systemDescription;
	private String leState;
	private String legalDescription;
	private String marketSegmentDescription;
	private String branding;
	private String companyId;
	private String buId;
	private String bankAccountLastDigits;
	private String market;
	
	public String getSystemDescription() {
		return systemDescription;
	}
	public void setSystemDescription(String systemDescription) {
		this.systemDescription = systemDescription;
	}
	public String getLeState() {
		return leState;
	}
	public void setLeState(String leState) {
		this.leState = leState;
	}
	public String getLegalDescription() {
		return legalDescription;
	}
	public void setLegalDescription(String legalDescription) {
		this.legalDescription = legalDescription;
	}
	public String getMarketSegmentDescription() {
		return marketSegmentDescription;
	}
	public void setMarketSegmentDescription(String marketSegmentDescription) {
		this.marketSegmentDescription = marketSegmentDescription;
	}
	public String getBranding() {
		return branding;
	}
	public void setBranding(String branding) {
		this.branding = branding;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getBuId() {
		return buId;
	}
	public void setBuId(String buId) {
		this.buId = buId;
	}
	public String getBankAccountLastDigits() {
		return bankAccountLastDigits;
	}
	public void setBankAccountLastDigits(String bankAccountLastDigits) {
		this.bankAccountLastDigits = bankAccountLastDigits;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	public Exceptions getExceptions() {
		return exceptions;
	}
	public void setExceptions(Exceptions exceptions) {
		this.exceptions = exceptions;
	}
}
