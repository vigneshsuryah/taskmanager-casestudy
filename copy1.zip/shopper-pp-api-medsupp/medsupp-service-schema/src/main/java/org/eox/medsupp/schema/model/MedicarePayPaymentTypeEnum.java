/**
 * MedicarePayPaymentTypeEnum.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;


public enum MedicarePayPaymentTypeEnum
{

	NONE,

	BANKINGACCOUNT,

	CREDITDEBITCARD;

}