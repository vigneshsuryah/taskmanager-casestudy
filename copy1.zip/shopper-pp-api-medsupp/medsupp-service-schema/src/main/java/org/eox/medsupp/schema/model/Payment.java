package org.eox.medsupp.schema.model;

import java.io.Serializable;

public class Payment implements Serializable{

	private static final long serialVersionUID = -8859351225285125112L;

	private String checkNumber;

	private String paidDate;

	private float paidAmount;

	private String paymentSource;

	private String paymentMethod;

	private String paymentType;

	private String lineOfBusiness;

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}


	public float getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(float paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}

	@Override
	public String toString() {
		return "Payment [checkNumber=" + checkNumber + ", paidDate=" + paidDate + ", paidAmount=" + paidAmount
				+ ", paymentSource=" + paymentSource + ", paymentMethod=" + paymentMethod + ", paymentType="
				+ paymentType + ", lineOfBusiness=" + lineOfBusiness + "]";
	}

}
