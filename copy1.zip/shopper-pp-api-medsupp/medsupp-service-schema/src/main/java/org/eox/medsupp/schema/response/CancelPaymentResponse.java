/**
 * CancelPaymentResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


public class CancelPaymentResponse extends BaseResponse
{

	private static final long serialVersionUID = -1480902644402788016L;

	private String paymentCancelStatus;

	private String paymentConfirmationNo;

	public String getPaymentCancelStatus()
	{
		return paymentCancelStatus;
	}

	public void setPaymentCancelStatus(String paymentCancelStatus)
	{
		this.paymentCancelStatus = paymentCancelStatus;
	}

	public String getPaymentConfirmationNo()
	{
		return paymentConfirmationNo;
	}

	public void setPaymentConfirmationNo(String paymentConfirmationNo)
	{
		this.paymentConfirmationNo = paymentConfirmationNo;
	}

}
