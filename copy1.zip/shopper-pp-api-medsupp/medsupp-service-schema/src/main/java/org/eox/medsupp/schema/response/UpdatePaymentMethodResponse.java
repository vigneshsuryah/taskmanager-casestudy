/**
 * UpdatePaymentMethodResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;


import java.io.Serializable;

import org.eox.medsupp.schema.model.MedicarePayPaymentMethod;


public class UpdatePaymentMethodResponse extends BaseResponse implements Serializable
{
	private static final long serialVersionUID = 1L;

	private MedicarePayPaymentMethod medicarePayPaymentMethod;

	/**
	 * @return the medicarePayPaymentMethod
	 */
	public MedicarePayPaymentMethod getMedicarePayPaymentMethod()
	{
		return medicarePayPaymentMethod;
	}

	/**
	 * @param medicarePayPaymentMethod
	 *            the medicarePayPaymentMethod to set
	 */
	public void setMedicarePayPaymentMethod(MedicarePayPaymentMethod medicarePayPaymentMethod)
	{
		this.medicarePayPaymentMethod = medicarePayPaymentMethod;
	}

}
