package org.eox.medsupp.schema.request;

import org.eox.medsupp.schema.model.AdditionalPropertiesBO;
import org.eox.medsupp.schema.model.EventHeader;
import org.eox.medsupp.schema.model.Member;
import org.eox.medsupp.schema.model.NotificationPreference;

public class SOASMCEmailRequest {

	private AdditionalPropertiesBO additionalProperties;
	
	private EventHeader eventHeader;
	
	private Member member;
	
	private NotificationPreference notificationPreference;

	/**
	 * @return the additionalProperties
	 */
	public AdditionalPropertiesBO getAdditionalProperties() {
		return additionalProperties;
	}

	/**
	 * @param additionalProperties the additionalProperties to set
	 */
	public void setAdditionalProperties(AdditionalPropertiesBO additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	/**
	 * @return the eventHeader
	 */
	public EventHeader getEventHeader() {
		return eventHeader;
	}

	/**
	 * @param eventHeader the eventHeader to set
	 */
	public void setEventHeader(EventHeader eventHeader) {
		this.eventHeader = eventHeader;
	}

	/**
	 * @return the member
	 */
	public Member getMember() {
		return member;
	}

	/**
	 * @param member the member to set
	 */
	public void setMember(Member member) {
		this.member = member;
	}

	/**
	 * @return the notificationPreference
	 */
	public NotificationPreference getNotificationPreference() {
		return notificationPreference;
	}

	/**
	 * @param notificationPreference the notificationPreference to set
	 */
	public void setNotificationPreference(
			NotificationPreference notificationPreference) {
		this.notificationPreference = notificationPreference;
	}

}
