package org.eox.medsupp.schema.response;

import java.util.List;

import org.eox.medsupp.schema.model.MemberBillSummary;

public class MemberBillingSummaryResponse extends BaseResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5092020649772321350L;
	private List<MemberBillSummary> memberBillSummaryList;

	public List<MemberBillSummary> getMemberBillSummaryList() {
		return memberBillSummaryList;
	}

	public void setMemberBillSummaryList(List<MemberBillSummary> memberBillSummaryList) {
		this.memberBillSummaryList = memberBillSummaryList;
	}

	@Override
	public String toString() {
		return "MemberBillingSummaryResponse [memberBillSummaryList=" + memberBillSummaryList + "]";
	}
	
	

}
