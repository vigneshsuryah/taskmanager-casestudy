/**
 * ViewPaymentHistoryResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.response;

import org.eox.medsupp.schema.model.MedicarePayMember;

public class ViewPaymentHistoryResponse extends BaseResponse {


	private static final long serialVersionUID = 5873695908466534940L;

	
	private MedicarePayMember medicarePayMember;

	private String errorMessage;
	private boolean errorFlag;
	
	
	public MedicarePayMember getMedicarePayMember() {
		return medicarePayMember;
	}

	public void setMedicarePayMember(MedicarePayMember medicarePayMember) {
		this.medicarePayMember = medicarePayMember;
	}
	
	

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(boolean errorFlag) {
		this.errorFlag = errorFlag;
	}

	@Override
	public String toString() {
		return "ViewPaymentHistoryResponse [memberPayMember=" + medicarePayMember + "]";
	}






}
