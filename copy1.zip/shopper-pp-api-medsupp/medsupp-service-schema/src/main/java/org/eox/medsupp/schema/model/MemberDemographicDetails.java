/**
 * MemberDemographicDetails.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.schema.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberDemographicDetails implements Serializable
{

	private static final long serialVersionUID = -248284048630861184L;

	private ContactInformation contactInformation;

	private String dateOfBirth;

	private String firstName;

	private String lastName;

	private String maritalStatus;

	private String market;

	private String medicaidID;

	private String medicareID;

	private String middleName;

	private String namePrefix;

	private String originalEffectiveDate;

	private String recertificationDate;

	private String sex;

	/**
	 * @return the contactInformation
	 */
	public ContactInformation getContactInformation()
	{
		return contactInformation;
	}

	/**
	 * @param contactInformation
	 *            the contactInformation to set
	 */
	public void setContactInformation(ContactInformation contactInformation)
	{
		this.contactInformation = contactInformation;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth()
	{
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * @return the maritalStatus
	 */
	public String getMaritalStatus()
	{
		return maritalStatus;
	}

	/**
	 * @param maritalStatus
	 *            the maritalStatus to set
	 */
	public void setMaritalStatus(String maritalStatus)
	{
		this.maritalStatus = maritalStatus;
	}

	/**
	 * @return the market
	 */
	public String getMarket()
	{
		return market;
	}

	/**
	 * @param market
	 *            the market to set
	 */
	public void setMarket(String market)
	{
		this.market = market;
	}

	/**
	 * @return the medicaidID
	 */
	public String getMedicaidID()
	{
		return medicaidID;
	}

	/**
	 * @param medicaidID
	 *            the medicaidID to set
	 */
	public void setMedicaidID(String medicaidID)
	{
		this.medicaidID = medicaidID;
	}

	/**
	 * @return the medicareID
	 */
	public String getMedicareID()
	{
		return medicareID;
	}

	/**
	 * @param medicareID
	 *            the medicareID to set
	 */
	public void setMedicareID(String medicareID)
	{
		this.medicareID = medicareID;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName()
	{
		return middleName;
	}

	/**
	 * @param middleName
	 *            the middleName to set
	 */
	public void setMiddleName(String middleName)
	{
		this.middleName = middleName;
	}

	/**
	 * @return the namePrefix
	 */
	public String getNamePrefix()
	{
		return namePrefix;
	}

	/**
	 * @param namePrefix
	 *            the namePrefix to set
	 */
	public void setNamePrefix(String namePrefix)
	{
		this.namePrefix = namePrefix;
	}

	/**
	 * @return the originalEffectiveDate
	 */
	public String getOriginalEffectiveDate()
	{
		return originalEffectiveDate;
	}

	/**
	 * @param originalEffectiveDate
	 *            the originalEffectiveDate to set
	 */
	public void setOriginalEffectiveDate(String originalEffectiveDate)
	{
		this.originalEffectiveDate = originalEffectiveDate;
	}

	/**
	 * @return the recertificationDate
	 */
	public String getRecertificationDate()
	{
		return recertificationDate;
	}

	/**
	 * @param recertificationDate
	 *            the recertificationDate to set
	 */
	public void setRecertificationDate(String recertificationDate)
	{
		this.recertificationDate = recertificationDate;
	}

	/**
	 * @return the sex
	 */
	public String getSex()
	{
		return sex;
	}

	/**
	 * @param sex
	 *            the sex to set
	 */
	public void setSex(String sex)
	{
		this.sex = sex;
	}

}
