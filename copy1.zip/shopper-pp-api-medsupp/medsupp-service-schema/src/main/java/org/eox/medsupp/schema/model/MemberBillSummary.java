package org.eox.medsupp.schema.model;

import java.io.Serializable;
import java.util.List;


public class MemberBillSummary implements Serializable{

	private static final long serialVersionUID = -21364465750967925L;

	private String sbruid;
	
	private HealthCardId healthCardId;
	
	private HealthCardId primaryMemberHcid;
	
	private String productGroupNumber;
	
	private String accountPaymentStatusCode;
	
	private String statementId;
	
	private String divisionCode;
	
	private String sourceSystemId;
	
	private List<Bill> bills;

	public String getSbruid() {
		return sbruid;
	}

	public void setSbruid(String sbruid) {
		this.sbruid = sbruid;
	}

	public HealthCardId getHealthCardId() {
		return healthCardId;
	}

	public void setHealthCardId(HealthCardId healthCardId) {
		this.healthCardId = healthCardId;
	}

	public HealthCardId getPrimaryMemberHcid() {
		return primaryMemberHcid;
	}

	public void setPrimaryMemberHcid(HealthCardId primaryMemberHcid) {
		this.primaryMemberHcid = primaryMemberHcid;
	}

	public String getProductGroupNumber() {
		return productGroupNumber;
	}

	public void setProductGroupNumber(String productGroupNumber) {
		this.productGroupNumber = productGroupNumber;
	}

	public String getAccountPaymentStatusCode() {
		return accountPaymentStatusCode;
	}

	public void setAccountPaymentStatusCode(String accountPaymentStatusCode) {
		this.accountPaymentStatusCode = accountPaymentStatusCode;
	}

	public String getStatementId() {
		return statementId;
	}

	public void setStatementId(String statementId) {
		this.statementId = statementId;
	}

	public String getDivisionCode() {
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public String getSourceSystemId() {
		return sourceSystemId;
	}

	public void setSourceSystemId(String sourceSystemId) {
		this.sourceSystemId = sourceSystemId;
	}

	public List<Bill> getBills() {
		return bills;
	}

	public void setBills(List<Bill> bills) {
		this.bills = bills;
	}

	@Override
	public String toString() {
		return "MemberBillSummary [sbruid=" + sbruid + ", healthCardId=" + healthCardId + ", primaryMemberHcid="
				+ primaryMemberHcid + ", productGroupNumber=" + productGroupNumber + ", accountPaymentStatusCode="
				+ accountPaymentStatusCode + ", statementId=" + statementId + ", divisionCode=" + divisionCode
				+ ", sourceSystemId=" + sourceSystemId + ", bills=" + bills + "]";
	}
	
	
}
