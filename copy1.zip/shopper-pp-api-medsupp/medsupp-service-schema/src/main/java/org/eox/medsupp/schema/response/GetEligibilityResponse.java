package org.eox.medsupp.schema.response;


import java.util.List;

import org.eox.medsupp.schema.model.MemberEligibility;


public class GetEligibilityResponse extends BaseResponse
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7259446200697987665L;

	private List<MemberEligibility> memberEligibilityList;

	/**
	 * @return the memberEligibilityList
	 */
	public List<MemberEligibility> getMemberEligibilityList()
	{
		return memberEligibilityList;
	}

	/**
	 * @param memberEligibilityList
	 *            the memberEligibilityList to set
	 */
	public void setMemberEligibilityList(List<MemberEligibility> memberEligibilityList)
	{
		this.memberEligibilityList = memberEligibilityList;
	}

}
