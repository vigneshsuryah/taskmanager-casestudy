/**
* ViewPaymentHistoryRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package org.eox.medsupp.schema.request;


public class ViewPaymentHistoryRequest extends BaseRequest {

	private static final long serialVersionUID = 3159046736848740369L;
	

}
