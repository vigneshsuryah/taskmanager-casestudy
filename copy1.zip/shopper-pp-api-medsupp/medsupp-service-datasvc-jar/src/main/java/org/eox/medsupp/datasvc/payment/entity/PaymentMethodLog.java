/**
 * PaymentMethodLog.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.entity;


import java.io.Serializable;


public class PaymentMethodLog implements Serializable
{

	private static final long serialVersionUID = 1L;

	private String hcid;

	private String tokenId;

	private String paymentMode;

	private String accountType;

	private String action;

	private String status;

	private String requestingSystem;

	private String CreatedBy;

	/**
	 * @return the hcid
	 */
	public String getHcid()
	{
		return hcid;
	}

	/**
	 * @param hcid
	 *            the hcid to set
	 */
	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	/**
	 * @return the tokenId
	 */
	public String getTokenId()
	{
		return tokenId;
	}

	/**
	 * @param tokenId
	 *            the tokenId to set
	 */
	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode()
	{
		return paymentMode;
	}

	/**
	 * @param paymentMode
	 *            the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode)
	{
		this.paymentMode = paymentMode;
	}

	/**
	 * @return the accountType
	 */
	public String getAccountType()
	{
		return accountType;
	}

	/**
	 * @param accountType
	 *            the accountType to set
	 */
	public void setAccountType(String accountType)
	{
		this.accountType = accountType;
	}

	/**
	 * @return the action
	 */
	public String getAction()
	{
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action)
	{
		this.action = action;
	}

	/**
	 * @return the status
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * @return the requestingSystem
	 */
	public String getRequestingSystem()
	{
		return requestingSystem;
	}

	/**
	 * @param requestingSystem
	 *            the requestingSystem to set
	 */
	public void setRequestingSystem(String requestingSystem)
	{
		this.requestingSystem = requestingSystem;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return CreatedBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		CreatedBy = createdBy;
	}

}
