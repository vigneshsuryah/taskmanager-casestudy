/**
 * PaymentDetailsLog.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.entity;


import java.io.Serializable;


public class PaymentDetailsLog implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String paymentHcid;

	private String submittedHcid;

	private String paymentConfirmNo;

	private String paymentStatus;

	private String subGroupId;

	private String tokenId;

	private PaymentTypeEnum paymentType;

	private String paymentDate;

	private String paidAmount;

	private String createdBy;

	private String errorReason;

	private String requestingSystem;

	private String stateVal;

	/**
	 * @return the paymentHcid
	 */
	public String getPaymentHcid()
	{
		return paymentHcid;
	}

	/**
	 * @param paymentHcid
	 *            the paymentHcid to set
	 */
	public void setPaymentHcid(String paymentHcid)
	{
		this.paymentHcid = paymentHcid;
	}

	/**
	 * @return the submittedHcid
	 */
	public String getSubmittedHcid()
	{
		return submittedHcid;
	}

	/**
	 * @param submittedHcid
	 *            the submittedHcid to set
	 */
	public void setSubmittedHcid(String submittedHcid)
	{
		this.submittedHcid = submittedHcid;
	}

	/**
	 * @return the paymentConfirmNo
	 */
	public String getPaymentConfirmNo()
	{
		return paymentConfirmNo;
	}

	/**
	 * @param paymentConfirmNo
	 *            the paymentConfirmNo to set
	 */
	public void setPaymentConfirmNo(String paymentConfirmNo)
	{
		this.paymentConfirmNo = paymentConfirmNo;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus()
	{
		return paymentStatus;
	}

	/**
	 * @param paymentStatus
	 *            the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus)
	{
		this.paymentStatus = paymentStatus;
	}

	/**
	 * @return the subGroupId
	 */
	public String getSubGroupId()
	{
		return subGroupId;
	}

	/**
	 * @param subGroupId
	 *            the subGroupId to set
	 */
	public void setSubGroupId(String subGroupId)
	{
		this.subGroupId = subGroupId;
	}

	/**
	 * @return the tokenId
	 */
	public String getTokenId()
	{
		return tokenId;
	}

	/**
	 * @param tokenId
	 *            the tokenId to set
	 */
	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	/**
	 * @return the paymentType
	 */
	public PaymentTypeEnum getPaymentType()
	{
		return paymentType;
	}

	/**
	 * @param paymentType
	 *            the paymentType to set
	 */
	public void setPaymentType(PaymentTypeEnum paymentType)
	{
		this.paymentType = paymentType;
	}

	/**
	 * @return the paymentDate
	 */
	public String getPaymentDate()
	{
		return paymentDate;
	}

	/**
	 * @param paymentDate
	 *            the paymentDate to set
	 */
	public void setPaymentDate(String paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	/**
	 * @return the paidAmount
	 */
	public String getPaidAmount()
	{
		return paidAmount;
	}

	/**
	 * @param paidAmount
	 *            the paidAmount to set
	 */
	public void setPaidAmount(String paidAmount)
	{
		this.paidAmount = paidAmount;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}

	/**
	 * @return the errorReason
	 */
	public String getErrorReason()
	{
		return errorReason;
	}

	/**
	 * @param errorReason
	 *            the errorReason to set
	 */
	public void setErrorReason(String errorReason)
	{
		this.errorReason = errorReason;
	}

	/**
	 * @return the requestingSystem
	 */
	public String getRequestingSystem()
	{
		return requestingSystem;
	}

	/**
	 * @param requestingSystem
	 *            the requestingSystem to set
	 */
	public void setRequestingSystem(String requestingSystem)
	{
		this.requestingSystem = requestingSystem;
	}

	/**
	 * @return the stateVal
	 */
	public String getStateVal()
	{
		return stateVal;
	}

	/**
	 * @param stateVal
	 *            the stateVal to set
	 */
	public void setStateVal(String stateVal)
	{
		this.stateVal = stateVal;
	}

}
