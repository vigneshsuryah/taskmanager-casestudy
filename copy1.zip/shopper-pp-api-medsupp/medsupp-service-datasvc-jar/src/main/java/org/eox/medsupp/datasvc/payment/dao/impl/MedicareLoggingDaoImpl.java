/**
 * MedicareLoggingDaoImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.dao.impl;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.eox.medsupp.datasvc.payment.dao.MedicareLoggingDao;
import org.eox.medsupp.datasvc.payment.entity.PaymentDetailsLog;
import org.eox.medsupp.datasvc.payment.entity.PaymentMethodLog;
import org.eox.medsupp.datasvc.payment.entity.RSTransLog;
import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;


@Component
public class MedicareLoggingDaoImpl extends GenericDAOImpl implements MedicareLoggingDao
{

	private static final String SAVE_RS_LOGGING_SP = "OLX.OLX_MEMBER_RS_LOGS";

	private static final String SAVE_TPT_LOGGING_SP = "OLX.OLX_MEMBER_TPT_SERVICES_LOG";

	private static final String SAVE_PAYMENT_METHOD_LOGGING_SP = "OLX.MEDSUPP_PYMTMTHD_LOG";

	private static final String SAVE_PAYMENT_DETAILS_LOGGING_SP = "OLX.MEDSUPP_PAYMENT_DETAILS";

	@Override
	public void saveRSServiceLog(RSTransLog rSTransLog) throws MedicarePayException
	{
		RSServicesLogging logging = new RSServicesLogging(dataSource);
		logging.executeRSServicesLoggingSp(rSTransLog);
	}

	protected class RSServicesLogging extends DAOStoredProc
	{
		protected RSServicesLogging(DataSource ds)
		{
			super(ds, SAVE_RS_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@CHANNEL", Types.VARCHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@ERRORMSG", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@RSTRANSID", Types.BIGINT));

			compile();
		}

		protected void executeRSServicesLoggingSp(RSTransLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", "");
			inParams.put("@CHANNEL", logDataBean.getChannel());
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXML());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXML());
			inParams.put("@ERRORMSG", logDataBean.getErrorMsg());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());

			if (logDataBean.getRequestTS() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTS().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getRequestTS() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getRequestTS().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@RSTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@RSTRANSIDOUT");
			}
		}
	}

	@Override
	public void saveTPTServiceLog(TPTServicesLog logData) throws MedicarePayException
	{
		TPTServicesLogging logging = new TPTServicesLogging(dataSource);
		logging.executeTPTServicesLoggingSp(logData);
	}

	protected class TPTServicesLogging extends DAOStoredProc
	{
		protected TPTServicesLogging(DataSource ds)
		{
			super(ds, SAVE_TPT_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@ISBUSINESSFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@ISSYSTEMFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEID", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEID", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEDDATE", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@TPTTRANSIDOUT", Types.BIGINT));

			compile();
		}

		protected void executeTPTServicesLoggingSp(TPTServicesLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", logDataBean.getSbrUid());
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXml());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXml());
			if (logDataBean.getRequestTs() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTs().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getResponseTs() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getResponseTs().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}
			inParams.put("@ISBUSINESSFAULT", logDataBean.getIsBusinessFault());
			inParams.put("@ISSYSTEMFAULT", logDataBean.getIsSystemFault());
			inParams.put("@CREATEID", logDataBean.getHcid());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParams.put("@UPDATEID", logDataBean.getHcid());
			inParams.put("@UPDATEDDATE", new Timestamp(new Date().getTime()));

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@TPTTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@TPTTRANSIDOUT");
			}
		}
	}

	@Override
	public void savePaymentMethodLog(PaymentMethodLog paymentMethodLog) throws MedicarePayException
	{
		PaymentMethodLogging logging = new PaymentMethodLogging(dataSource);
		logging.executePaymentMethodLoggingSp(paymentMethodLog);
	}

	protected class PaymentMethodLogging extends DAOStoredProc
	{
		protected PaymentMethodLogging(DataSource ds)
		{
			super(ds, SAVE_PAYMENT_METHOD_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@TokenID", Types.VARCHAR));
			declareParameter(new SqlParameter("@PaymentMode", Types.CHAR));
			declareParameter(new SqlParameter("@AccountType", Types.VARCHAR));
			declareParameter(new SqlParameter("@Action", Types.CHAR));
			declareParameter(new SqlParameter("@Status", Types.CHAR));
			declareParameter(new SqlParameter("@RequestingSystem", Types.CHAR));
			declareParameter(new SqlParameter("@CreatedDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@CreatedBy", Types.VARCHAR));

			declareParameter(new SqlOutParameter("@PymtmthdIdOUT", Types.BIGINT));

			compile();
		}

		protected void executePaymentMethodLoggingSp(PaymentMethodLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@TokenID", logDataBean.getTokenId());
			inParams.put("@PaymentMode", logDataBean.getPaymentMode());
			inParams.put("@AccountType", logDataBean.getAccountType());
			inParams.put("@Action", logDataBean.getAction());
			inParams.put("@Status", logDataBean.getStatus());
			inParams.put("@RequestingSystem", logDataBean.getRequestingSystem());
			inParams.put("@CreatedDate", new Timestamp(new Date().getTime()));
			inParams.put("@CreatedBy", logDataBean.getCreatedBy());

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@PymtmthdIdOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@PymtmthdIdOUT");
			}
		}
	}

	@Override
	public void savePaymentDetailsLog(PaymentDetailsLog paymentDetailsLog) throws MedicarePayException
	{
		PaymentDetailsLogging logging = new PaymentDetailsLogging(dataSource);
		logging.executePaymentDetailsLoggingSp(paymentDetailsLog);
	}

	protected class PaymentDetailsLogging extends DAOStoredProc
	{
		protected PaymentDetailsLogging(DataSource ds)
		{
			super(ds, SAVE_PAYMENT_DETAILS_LOGGING_SP);

			declareParameter(new SqlParameter("@PaymentHCID", Types.CHAR));
			declareParameter(new SqlParameter("@SubmittedHCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@PaymentConfirmNo", Types.VARCHAR));
			declareParameter(new SqlParameter("@PaymentStatus", Types.VARCHAR));
			declareParameter(new SqlParameter("@SubGroupId", Types.CHAR));
			declareParameter(new SqlParameter("@TokenID", Types.CHAR));
			declareParameter(new SqlParameter("@PaymentType", Types.VARCHAR));
			declareParameter(new SqlParameter("@PaymentDate", Types.VARCHAR));
			declareParameter(new SqlParameter("@PaidAmount", Types.DOUBLE));
			declareParameter(new SqlParameter("@CreatedDate", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@CreatedBy", Types.VARCHAR));
			declareParameter(new SqlParameter("@ErrorReason", Types.VARCHAR));
			declareParameter(new SqlParameter("@RequestingSystem", Types.CHAR));
			declareParameter(new SqlParameter("@StateVal", Types.CHAR));

			declareParameter(new SqlOutParameter("@PaymentDetailsIdOUT", Types.BIGINT));

			compile();
		}

		protected void executePaymentDetailsLoggingSp(PaymentDetailsLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@PaymentHCID", logDataBean.getPaymentHcid());
			inParams.put("@SubmittedHCID", logDataBean.getSubmittedHcid());
			inParams.put("@PaymentConfirmNo", logDataBean.getPaymentConfirmNo());
			inParams.put("@PaymentStatus", logDataBean.getPaymentStatus());
			inParams.put("@SubGroupId", logDataBean.getSubGroupId());
			inParams.put("@TokenID", logDataBean.getTokenId());
			inParams.put("@PaymentType", logDataBean.getPaymentType());
			inParams.put("@PaymentDate", logDataBean.getPaymentDate());
			inParams.put("@PaidAmount", logDataBean.getPaidAmount());
			inParams.put("@CreatedDate", new Timestamp(new Date().getTime()));
			inParams.put("@CreatedBy", logDataBean.getCreatedBy());
			inParams.put("@ErrorReason", logDataBean.getErrorReason());
			inParams.put("@RequestingSystem", logDataBean.getRequestingSystem());
			inParams.put("@StateVal", logDataBean.getStateVal());

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@PaymentDetailsIdOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@PaymentDetailsIdOUT");
			}
		}
	}
}
