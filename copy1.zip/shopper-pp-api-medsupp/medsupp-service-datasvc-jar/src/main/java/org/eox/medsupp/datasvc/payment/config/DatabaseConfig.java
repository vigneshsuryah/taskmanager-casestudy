/**
 * DatabaseConfig.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.config;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.util.StringUtils;


@Configuration
// @Profile("!local")
// @PropertySource("classpath:application.properties")
public class DatabaseConfig
{

	@Bean(name = "dataSource")
	public DataSource olxDb(@Value("${medicarepay.db.olxdb.jndiName}") String olxDnJndiName)
	{
		if (StringUtils.isEmpty(olxDnJndiName))
		{
			throw new IllegalArgumentException("jndiName cannot be blank");
		}
		JndiDataSourceLookup lookup = new JndiDataSourceLookup();
		return lookup.getDataSource(olxDnJndiName);
	}

	@Bean(name = "jdbcTemplateOlx")
	public JdbcTemplate jdbcTemplateOlx(DataSource dataSource)
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.setResultsMapCaseInsensitive(true);
		return jdbcTemplate;
	}
}
