/**
 * TPTServicesLog.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.entity;


import java.io.Serializable;
import java.util.Date;


public class TPTServicesLog implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String hcid;
	private String sbrUid;
	private String operationName;
	private String requestXml;
	private String responseXml;
	private Date requestTs;
	private Date responseTs;
	private String isBusinessFault;
	private String isSystemFault;
	private String createId;
	private String requestingSystem;
	private String updateId;

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public String getSbrUid()
	{
		return sbrUid;
	}

	public void setSbrUid(String sbrUid)
	{
		this.sbrUid = sbrUid;
	}

	public String getOperationName()
	{
		return operationName;
	}

	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}

	public String getRequestXml()
	{
		return requestXml;
	}

	public void setRequestXml(String requestXml)
	{
		this.requestXml = requestXml;
	}

	public String getResponseXml()
	{
		return responseXml;
	}

	public void setResponseXml(String responseXml)
	{
		this.responseXml = responseXml;
	}

	public Date getRequestTs()
	{
		return requestTs;
	}

	public void setRequestTs(Date requestTs)
	{
		this.requestTs = requestTs;
	}

	public Date getResponseTs()
	{
		return responseTs;
	}

	public void setResponseTs(Date responseTs)
	{
		this.responseTs = responseTs;
	}

	public String getIsBusinessFault()
	{
		return isBusinessFault;
	}

	public void setIsBusinessFault(String isBusinessFault)
	{
		this.isBusinessFault = isBusinessFault;
	}

	public String getIsSystemFault()
	{
		return isSystemFault;
	}

	public void setIsSystemFault(String isSystemFault)
	{
		this.isSystemFault = isSystemFault;
	}

	public String getCreateId()
	{
		return createId;
	}

	public void setCreateId(String createId)
	{
		this.createId = createId;
	}

	public String getRequestingSystem()
	{
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem)
	{
		this.requestingSystem = requestingSystem;
	}

	public String getUpdateId()
	{
		return updateId;
	}

	public void setUpdateId(String updateId)
	{
		this.updateId = updateId;
	}
}
