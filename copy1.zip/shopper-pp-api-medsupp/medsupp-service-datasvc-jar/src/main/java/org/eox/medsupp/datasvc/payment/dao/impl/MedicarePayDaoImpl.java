package org.eox.medsupp.datasvc.payment.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.eox.medsupp.datasvc.payment.dao.MedicarePayDao;
import org.eox.medsupp.datasvc.payment.utility.ContentIdGenerator;
import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.MedicareEmailLogging;
import org.eox.medsupp.schema.model.MedicareLinkedAccount;
import org.eox.medsupp.schema.model.MedicarePersonDetails;
import org.eox.medsupp.schema.request.UpdateLinkedAccountRequest;
import org.eox.medsupp.schema.utililty.MedicarePayConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.stereotype.Component;


@Component
public class MedicarePayDaoImpl extends GenericDAOImpl implements MedicarePayDao, MedicarePayConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(MedicarePayDaoImpl.class);

	static final String ADD_LINKED_MEMBER_LOGGING_SP = "OLX.MEDSUPP_ADD_LINKED_MEMBER_LOGGING";

	static final String REMOVE_LINKED_MEMBER_SP = "OLX.MEDSUPP_REMOVE_LINKED_MEMBER";

	static final String DELETE_LINKED_MEMBER_SP = "OLX.MEDSUPP_DELETE_LINKED_MEMBER";

	static final String RETURN_LINKED_ACCOUNT_DETAILS_SP = "OLX.MEDSUPP_RETURN_LINKED_ACCOUNT_DETAILS";

	static final String RETURN_ACCOUNT_SUMMARY_DETAILS_SP = "OLX.MEDSUPP_RETURN_ACCOUNT_SUMMARY_DETAILS";

	static final String RETURN_LINKED_ACCOUNT_STATUS_SP = "OLX.MEDSUPP_RETURN_LINKED_ACCOUNT_STATUS";

	static final String UPDATE_APPROVE_DENY_LINKED_ACCOUNT_STATUS_SP = "OLX.MEDSUPP_UPDATE_APPROVE_DENY_LINKED_ACCOUNT_STATUS";

	static final String RETURN_LINKED_ACCOUNT_STATUS_FROM_KEY_SP = "OLX.MEDSUPP_RETURN_LINKED_ACCOUNT_STATUS_FROM_KEY";

	static final String INSERT_MEMBER_DETAILS_SP = "OLX.MEDSUPP_INSERT_MEMBER_DETAILS";

	static final String RETURN_MEMBER_DETAILS_COUNT_SP = "OLX.MEDSUPP_RETURN_MEMBER_DETAILS_COUNT";

	static final String RETURN_ALLOWED_PAYMENT_METHODS_SP = "OLX.MEDSUPP_SELECT_ACTIVE_PAYMETHOD";

	static final String UPDATE_LINKED_ACCOUNT_STATUS_FROM_KEY_SP = "OLX.MEDSUPP_UPDATE_LINKED_ACCOUNT_STATUS_FROM_KEY";

	static final String INSERT_EMAIL_LOG_SP = "OLX.MEDSUPP_SAVE_EMAIL_LOG";

	@Override
	public List<MedicareLinkedAccount> getLinkedAccount(String hcid) throws MedicarePayException
	{

		LOGGER.info("Inside getLinkedAccount() of MedicarePayDaoImpl");
		List<MedicareLinkedAccount> medicareLinkedAccount = null;
		try
		{
			medicareLinkedAccount = setLinkedAccount(hcid);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getLinkedAccount:" + e);
			throw new MedicarePayException(((MedicarePayException) e).getErrorMessage());
		}
		return medicareLinkedAccount;
	}

	private List<MedicareLinkedAccount> setLinkedAccount(String hcid) throws MedicarePayException
	{

		LOGGER.info("Start - setLinkedAccount() of MedicarePayDaoImpl");
		List<MedicareLinkedAccount> filteredLinkedAccounts = new ArrayList<>();
		List<MedicareLinkedAccount> medicareLinkedAccountList = getLinkedAccountDetail(hcid);
		if (null != medicareLinkedAccountList && medicareLinkedAccountList.size() > 0)
		{
			for (MedicareLinkedAccount medicareLinkedAccount : medicareLinkedAccountList)
			{
				if (null != medicareLinkedAccount.getAction()
						&& !LINK_STATUS_DENY.equalsIgnoreCase(medicareLinkedAccount.getAction().trim())
						&& !LINK_STATUS_REMOVE.equalsIgnoreCase(medicareLinkedAccount.getAction().trim()))
				{
					if (medicareLinkedAccount.getHcid().equalsIgnoreCase(hcid))
					{
						medicareLinkedAccount.setLinkRelationship(CHILD);
					}
					else
					{
						medicareLinkedAccount.setLinkRelationship(PARENT);
						String hcidStr = medicareLinkedAccount.getPersonDetails().getChildMemberId();
						medicareLinkedAccount.getPersonDetails().setChildMemberId(medicareLinkedAccount.getHcid());
						medicareLinkedAccount.setHcid(hcidStr);
					}
					filteredLinkedAccounts.add(medicareLinkedAccount);
				}
			}
		}
		return filteredLinkedAccounts;

	}

	public List<MedicareLinkedAccount> getLinkedAccountDetail(String hcid) throws MedicarePayException
	{

		LOGGER.debug("Inside MedicarePayDaoImpl - getLinkedAccount method - Start");
		List<MedicareLinkedAccount> getLinkedAccount = new ArrayList<MedicareLinkedAccount>();
		GetLinkedAccountQuery getLinkedAccountQuery = new GetLinkedAccountQuery(dataSource);
		getLinkedAccount = getLinkedAccountQuery.executeLinkedAccountSp(hcid);
		LOGGER.debug("Inside MedicarePayDaoImpl - getLinkedAccount method - End");
		return getLinkedAccount;
	}

	public class GetLinkedAccountQuery extends DAOStoredProc
	{

		protected GetLinkedAccountQuery(DataSource ds)
		{
			super(ds, RETURN_LINKED_ACCOUNT_DETAILS_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlReturnResultSet("rs", new LinkedAccountDetailsRowMapper()));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<MedicareLinkedAccount> executeLinkedAccountSp(String hcid)
		{
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			Map outParams = execute(inParams);
			return (List) outParams.get("rs");
		}

	}

	@SuppressWarnings("rawtypes")
	private class LinkedAccountDetailsRowMapper implements RowMapper
	{

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			MedicareLinkedAccount medicareLinkedAccount = new MedicareLinkedAccount();
			medicareLinkedAccount.setPersonDetails(new MedicarePersonDetails());

			medicareLinkedAccount.setHcid(rs.getString("HCID"));
			medicareLinkedAccount.getPersonDetails().setChildMemberId(rs.getString("CHILD_MEMBER_ID"));
			medicareLinkedAccount.setRequestDate(rs.getString("REQUEST_DATE"));
			medicareLinkedAccount.setApprovedDate(rs.getString("APPROVED_DATE"));
			medicareLinkedAccount.setAction(rs.getString("STATUS"));
			return medicareLinkedAccount;
		}
	}

	public class GetLinkedAccountHcidsQuery extends DAOStoredProc
	{

		protected GetLinkedAccountHcidsQuery(DataSource ds)
		{
			super(ds, RETURN_ACCOUNT_SUMMARY_DETAILS_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SRC_SYSTEM", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@CHILD_MEMBER_IDS", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeLinkedAccountHcidsSp(String hcid, String srcSystem)
		{
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@SRC_SYSTEM", srcSystem);

			String childMemberIds = "";
			Map outParams = execute(inParams);
			try
			{
				childMemberIds = (String) outParams.get("@CHILD_MEMBER_IDS");
			} catch (Exception e)
			{
				LOGGER.error("Exception in executeLinkedAccountHcidsSp" + e);
			}
			return childMemberIds;
		}

	}

	/**
	 * Adds a linked account
	 * 
	 * @param UpdateLinkedAccountRequest
	 * @throws MedicarePayException
	 */
	@Override
	public String addLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - addLinkedAccount() of MedicarePayDaoImpl");
		NewLinkedMemberLogging logging = new NewLinkedMemberLogging(dataSource);
		LOGGER.info("End - addLinkedAccount() of MedicarePayDaoImpl");
		return logging.executeNewLinkedMemberLoggingSp(request);
	}

	protected class NewLinkedMemberLogging extends DAOStoredProc
	{

		protected NewLinkedMemberLogging(DataSource ds)
		{

			super(ds, ADD_LINKED_MEMBER_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@CHILD_HCID", Types.CHAR));
			declareParameter(new SqlParameter("@CONTENT_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SOURCE_SYSTEM", Types.CHAR));
			declareParameter(new SqlOutParameter("@MSG_ADD", Types.VARCHAR));

			compile();
		}

		protected String executeNewLinkedMemberLoggingSp(UpdateLinkedAccountRequest request) throws MedicarePayException
		{
			Map<String, Object> inParam = new HashMap<String, Object>();
			String contentId = ContentIdGenerator.getContentId();
			inParam.put("@HCID", request.getHealthCardId());
			inParam.put("@CHILD_HCID", request.getChildHealthCardId());
			inParam.put("@CONTENT_ID", contentId);
			inParam.put("@SOURCE_SYSTEM", "MEDSUPP");

			Map<String, Object> outParam = new HashMap<String, Object>();
			outParam = execute(inParam);
			String message = (String) outParam.get("@MSG_ADD");

			if (message != null && message.equalsIgnoreCase("LINK_EXISTS"))
			{
				LOGGER.info("The account is already linked");
				throw new MedicarePayException(
						"A request to link to this account was already sent. The link may be already approved, or still waiting for approval.");
			}
			return contentId;
		}
	}

	/**
	 * deletes a linked account,in case something went wrong while adding a linked account
	 * 
	 * @param UpdateLinkedAccountRequest
	 * @exception MedicarePayException
	 */

	@Override
	public void deleteLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - deleteLinkedAccount() of MedicarePayDaoImpl");
		DelLinkedMemberLogging logging = new DelLinkedMemberLogging(dataSource);

		logging.executeDelLinkedMemberLoggingSp(request);
		LOGGER.info("End - deleteLinkedAccount() of MedicarePayDaoImpl");
	}

	protected class DelLinkedMemberLogging extends DAOStoredProc
	{

		protected DelLinkedMemberLogging(DataSource ds)
		{
			super(ds, DELETE_LINKED_MEMBER_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@CHILD_HCID", Types.CHAR));

			compile();
		}

		protected void executeDelLinkedMemberLoggingSp(UpdateLinkedAccountRequest request) throws MedicarePayException
		{
			Map<String, Object> inParam = new HashMap<String, Object>();
			inParam.put("@HCID", request.getHealthCardId());
			inParam.put("@CHILD_HCID", request.getChildHealthCardId());
			
			execute(inParam);
		}
	}

	/**
	 * Removes a linked account
	 * 
	 * @param UpdateLinkedAccountRequest
	 * @throws MedicarePayException
	 */
	@Override
	public void removeLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException
	{
		LOGGER.info("Start - removeLinkedAccount() of MedicarePayDaoImpl");
		RemoveLinkedMemberLogging logging = new RemoveLinkedMemberLogging(dataSource);
		logging.executeRemoveLinkedMemberLoggingSp(request);
		LOGGER.info("End - removeLinkedAccount() of MedicarePayDaoImpl");

	}

	protected class RemoveLinkedMemberLogging extends DAOStoredProc
	{

		protected RemoveLinkedMemberLogging(DataSource ds)
		{

			super(ds, REMOVE_LINKED_MEMBER_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@CHILD_HCID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@MSG_RMV", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		protected void executeRemoveLinkedMemberLoggingSp(UpdateLinkedAccountRequest request) throws MedicarePayException
		{
			String message = "";
			Map inParams = new HashMap();
			inParams.put("@HCID", request.getHealthCardId());
			inParams.put("@CHILD_HCID", request.getChildHealthCardId());
			Map outParams = execute(inParams);
			if (null != outParams.get("@MSG_RMV"))
			{
				message = (String) outParams.get("@MSG_RMV");
			}
			if (message != null && message.equalsIgnoreCase("LINK_ALREADY_REMOVED"))
			{
				LOGGER.info("The linked account is already removed");
				throw new MedicarePayException("This association is already removed by parent");
			}
		}
	}

	/**
	 * Get list of child hcids from database
	 * @param hcid
	 * @param serviceEnv
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public Set<String> getChildHcids(String hcid, String serviceEnv) throws MedicarePayException
	{
		Set<String> childHcids = new HashSet<String>();
		LOGGER.debug("Inside MedicarePayDaoImpl - getChildHcids method - Start");
		String getChildMemberIds = "";
		GetLinkedAccountHcidsQuery getLinkedAccountQuery = new GetLinkedAccountHcidsQuery(dataSource);
		getChildMemberIds = getLinkedAccountQuery.executeLinkedAccountHcidsSp(hcid, serviceEnv);
		if (null != getChildMemberIds && !getChildMemberIds.isEmpty())
		{
			String[] childHcidArr = getChildMemberIds.split(",");
			for (String str : childHcidArr)
			{
				childHcids.add(str);
			}
		}
		LOGGER.debug("Inside MedicarePayDaoImpl - getChildHcids method - End");
		return childHcids;
	}

	@Override
	public String getLinkedAccountStatus(UpdateLinkedAccountRequest request) throws MedicarePayException
	{

		LOGGER.info("Inside MedicarePayDaoImpl - getLinkedAccountStatus method - Start");
		String status = "";
		GetLinkedAccountStatusQuery getLinkedAccountStatusQuery = new GetLinkedAccountStatusQuery(dataSource);
		status = getLinkedAccountStatusQuery.executeGetLinkedAccountSp(request.getHealthCardId(), request.getChildHealthCardId());
		LOGGER.info("Inside MedicarePayDaoImpl - getLinkedAccountStatus method - End");
		return status;
	}

	public class GetLinkedAccountStatusQuery extends DAOStoredProc
	{

		protected GetLinkedAccountStatusQuery(DataSource ds)
		{
			super(ds, RETURN_LINKED_ACCOUNT_STATUS_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@CHILD_MEMBER_ID", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@STATUS", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeGetLinkedAccountSp(String hcid, String childHcid)
		{
			String status = "";
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@CHILD_MEMBER_ID", childHcid);
			Map outParams = execute(inParams);
			if (null != outParams.get("@STATUS"))
			{
				status = (String) outParams.get("@STATUS");
			}
			return status;
		}

	}

	@Override
	public boolean updateLinkedAccountStatus(UpdateLinkedAccountRequest request) throws MedicarePayException
	{

		LOGGER.info("Inside MedicarePayDaoImpl - updateLinkedAccountStatus method - Start");
		boolean updateStatus = false;
		UpdateLinkedAccountStatusQuery updateLinkedAccountStatusQuery = new UpdateLinkedAccountStatusQuery(dataSource);
		updateStatus = updateLinkedAccountStatusQuery.executeUpdateLinkedAccountStatusSp(request.getHealthCardId(),
				request.getChildHealthCardId(), request.getAction());
		LOGGER.info("Inside MedicarePayDaoImpl - updateLinkedAccountStatus method - End");
		return updateStatus;
	}

	public class UpdateLinkedAccountStatusQuery extends DAOStoredProc
	{

		protected UpdateLinkedAccountStatusQuery(DataSource ds)
		{
			super(ds, UPDATE_APPROVE_DENY_LINKED_ACCOUNT_STATUS_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@CHILD_MEMBER_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@ACTION", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@ROWCOUNT", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public boolean executeUpdateLinkedAccountStatusSp(String hcid, String childHcid, String action)
		{
			boolean updateStatus = false;
			int rowCount = 0;
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@CHILD_MEMBER_ID", childHcid);
			inParams.put("@ACTION", action);
			Map outParams = execute(inParams);
			if (null != outParams.get("@ROWCOUNT"))
			{
				rowCount = (int) outParams.get("@ROWCOUNT");
			}
			if (rowCount > 0)
			{
				updateStatus = true;
			}
			return updateStatus;
		}

	}

	@Override
	public String getLinkedAccountStatusFromKey(String key) throws MedicarePayException
	{

		LOGGER.info("Inside MedicarePayDaoImpl - getLinkedAccountStatusFromKey method - Start");
		String status = "";
		GetLinkedAccountStatusFromKeyQuery getLinkedAccountStatusFromKeyQuery = new GetLinkedAccountStatusFromKeyQuery(dataSource);
		status = getLinkedAccountStatusFromKeyQuery.executeGetLinkedAccountStatusSp(key);
		LOGGER.info("Inside MedicarePayDaoImpl - getLinkedAccountStatusFromKey method - End");
		return status;
	}

	public class GetLinkedAccountStatusFromKeyQuery extends DAOStoredProc
	{

		protected GetLinkedAccountStatusFromKeyQuery(DataSource ds)
		{
			super(ds, RETURN_LINKED_ACCOUNT_STATUS_FROM_KEY_SP);
			declareParameter(new SqlParameter("@KEY", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@STATUS", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeGetLinkedAccountStatusSp(String key)
		{
			String status = "";
			Map inParams = new HashMap();
			inParams.put("@KEY", key);
			Map outParams = execute(inParams);
			if (null != outParams.get("@STATUS"))
			{
				status = (String) outParams.get("@STATUS");
			}
			return status;
		}

	}

	/**
	 * Check whether the member exist in DB
	 * 
	 * @param hcid
	 * @param sourceSystem
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public boolean checkIfMemberExists(String hcid, String sourceSystem) throws MedicarePayException
	{
		LOGGER.info("Inside MedicarePayDaoImpl - checkIfMemberExists method - Start");
		boolean status = false;
		GetMemberDetailsCountQuery getMemberDetailsCountQuery = new GetMemberDetailsCountQuery(dataSource);
		int count = getMemberDetailsCountQuery.executeGetMemberDetailsCountSp(hcid, sourceSystem);
		if (count > 0)
		{
			status = true;
		}
		LOGGER.info("Inside MedicarePayDaoImpl - checkIfMemberExists method - End");
		return status;
	}

	public class GetMemberDetailsCountQuery extends DAOStoredProc
	{

		protected GetMemberDetailsCountQuery(DataSource ds)
		{
			super(ds, RETURN_MEMBER_DETAILS_COUNT_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SRC_SYS", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@ROWCOUNT", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public int executeGetMemberDetailsCountSp(String hcid, String sourceSystem)
		{
			int count = 0;
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@SRC_SYS", sourceSystem);
			Map outParams = execute(inParams);
			if (null != outParams.get("@ROWCOUNT"))
			{
				count = (Integer) outParams.get("@ROWCOUNT");
			}
			return count;
		}

	}

	/**
	 * Insert the member details in DB
	 * 
	 * @param request
	 * @param httpRequest
	 * @return
	 * @throws MedicarePayException
	 */
	@Override
	public boolean insertMemberDetails(String hcid, String sourceSystem) throws MedicarePayException
	{
		LOGGER.info("Inside MedicarePayDaoImpl - insertMemberDetails method - Start");
		boolean status = false;
		InsertMemberDetailsQuery insertMemberDetailsQuery = new InsertMemberDetailsQuery(dataSource);
		int count = insertMemberDetailsQuery.executeGetMemberDetailsCountSp(hcid, sourceSystem);
		if (count > 0)
		{
			status = true;
		}
		LOGGER.info("Inside MedicarePayDaoImpl - insertMemberDetails method - End");
		return status;
	}

	public class InsertMemberDetailsQuery extends DAOStoredProc
	{

		protected InsertMemberDetailsQuery(DataSource ds)
		{
			super(ds, INSERT_MEMBER_DETAILS_SP);
			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SRC_SYS", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@ROWCOUNT", Types.INTEGER));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public int executeGetMemberDetailsCountSp(String hcid, String sourceSystem)
		{
			int count = 0;
			Map inParams = new HashMap();
			inParams.put("@HCID", hcid);
			inParams.put("@SRC_SYS", sourceSystem);
			Map outParams = execute(inParams);
			if (null != outParams.get("@ROWCOUNT"))
			{
				count = (Integer) outParams.get("@ROWCOUNT");
			}
			return count;
		}

	}

	public List<String> getAllowedPaymentMethod(String state, String lob, String payType) throws MedicarePayException
	{
		List<String> allowedPayMethodList = new ArrayList<String>();
		LOGGER.debug("Inside MedicarePayDaoImpl - getAllowedPaymentMethod method - Start");
		GetAllowedPayMethodsQuery getLinkedAccountQuery = new GetAllowedPayMethodsQuery(dataSource);
		allowedPayMethodList = getLinkedAccountQuery.executeAllowedPayMethodsSp(state, lob, payType);
		LOGGER.debug("Inside MedicarePayDaoImpl - getAllowedPaymentMethod method - End");
		return allowedPayMethodList;
	}

	public class GetAllowedPayMethodsQuery extends DAOStoredProc
	{

		protected GetAllowedPayMethodsQuery(DataSource ds)
		{
			super(ds, RETURN_ALLOWED_PAYMENT_METHODS_SP);
			declareParameter(new SqlParameter("@STATE_CD", Types.CHAR));
			declareParameter(new SqlParameter("@LOB_CD", Types.CHAR));
			declareParameter(new SqlParameter("@PAYMENT_TYPE", Types.VARCHAR));

			declareParameter(new SqlReturnResultSet("rs", new AlloweDPayMethodsRowMapper()));

			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public List<String> executeAllowedPayMethodsSp(String state, String lob, String payType)
		{
			Map inParams = new HashMap();
			inParams.put("@STATE_CD", state);
			inParams.put("@LOB_CD", lob);
			inParams.put("@PAYMENT_TYPE", payType);

			Map outParams = execute(inParams);
			return (List) outParams.get("rs");
		}
	}

	@SuppressWarnings("rawtypes")
	private class AlloweDPayMethodsRowMapper implements RowMapper
	{

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			return rs.getString("PAYMENT_METHOD");
		}
	}

	@Override
	public String updateLinkedAccountStatusFromKey(String action, String key) throws MedicarePayException
	{

		LOGGER.info("Inside MedicarePayDaoImpl - updateLinkedAccountStatusFromKey method - Start");
		String hcid = "";
		UpdateLinkedAccountStatusFromKeyQuery updateLinkedAccountStatusFromKeyQuery = new UpdateLinkedAccountStatusFromKeyQuery(dataSource);
		hcid = updateLinkedAccountStatusFromKeyQuery.executeUpdateLinkedAccountStatusFromKeySp(action, key);
		LOGGER.info("Inside MedicarePayDaoImpl - updateLinkedAccountStatusFromKey method - End");
		return hcid;
	}

	public class UpdateLinkedAccountStatusFromKeyQuery extends DAOStoredProc
	{

		protected UpdateLinkedAccountStatusFromKeyQuery(DataSource ds)
		{
			super(ds, UPDATE_LINKED_ACCOUNT_STATUS_FROM_KEY_SP);
			declareParameter(new SqlParameter("@ACTION", Types.VARCHAR));
			declareParameter(new SqlParameter("@KEY", Types.VARCHAR));
			declareParameter(new SqlOutParameter("@HCID", Types.VARCHAR));
			compile();
		}

		@SuppressWarnings({ "unchecked", "rawtypes" })
		public String executeUpdateLinkedAccountStatusFromKeySp(String action, String key)
		{
			String hcid = "";
			Map inParams = new HashMap();
			inParams.put("@ACTION", action);
			inParams.put("@KEY", key);
			Map outParams = execute(inParams);
			if (null != outParams.get("@HCID"))
			{
				hcid = (String) outParams.get("@HCID");
			}
			return hcid;
		}

	}

	@Override
	public boolean saveEmailLog(MedicareEmailLogging memberpayEmailLogging) throws MedicarePayException
	{
		LOGGER.info("Inside MedicarePayDaoImpl - saveEmailLog method - Start");
		SaveEmailLogQuery saveEmailLogQuery = new SaveEmailLogQuery(dataSource);

		saveEmailLogQuery.executeSaveEmailLoggingSp(memberpayEmailLogging.getHcid(), memberpayEmailLogging.getFrom(),
				memberpayEmailLogging.getTo(), memberpayEmailLogging.getSubject(), memberpayEmailLogging.getTemplateId(),
				memberpayEmailLogging.getSentDate(), memberpayEmailLogging.getDynamicContent(), memberpayEmailLogging.getMailType(),
				memberpayEmailLogging.getCreatedBy(), "MEDSUPP");
		LOGGER.info("Inside MedicarePayDaoImpl - saveEmailLog method - End");
		return true;

	}

	protected class SaveEmailLogQuery extends DAOStoredProc
	{

		protected SaveEmailLogQuery(DataSource ds)
		{
			super(ds, INSERT_EMAIL_LOG_SP);

			declareParameter(new SqlParameter("@HCID", Types.VARCHAR));
			declareParameter(new SqlParameter("@FROM_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@TO_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SUBJECT", Types.VARCHAR));
			declareParameter(new SqlParameter("@TEMPLATE_ID", Types.VARCHAR));
			declareParameter(new SqlParameter("@SENT_DATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@DYNAMIC_CONTENT", Types.VARCHAR));
			declareParameter(new SqlParameter("@MAIL_TYPE", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATED_BY", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTING_SYSTEM", Types.CHAR));

			compile();
		}

		protected boolean executeSaveEmailLoggingSp(String hcid, String fromId, String toId, String subject, String templateId,
				Date sentDate, String dynamicContent, String mailType, String createdBy, String srcSystem)
				throws MedicarePayException
		{
			Map<String, Object> inParam = new HashMap<String, Object>();

			inParam.put("@HCID", hcid);
			inParam.put("@FROM_ID", fromId);
			inParam.put("@TO_ID", toId);
			inParam.put("@SUBJECT", subject);
			inParam.put("@TEMPLATE_ID", templateId);
			inParam.put("@SENT_DATE", sentDate);
			inParam.put("@DYNAMIC_CONTENT", dynamicContent);
			inParam.put("@MAIL_TYPE", mailType);
			inParam.put("@CREATED_BY", createdBy);
			inParam.put("@REQUESTING_SYSTEM", srcSystem);
			
			execute(inParam);

			return true;
		}
	}

}
