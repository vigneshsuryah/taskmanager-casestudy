package org.eox.medsupp.datasvc.payment.dao;


import java.util.List;
import java.util.Set;

import org.eox.medsupp.schema.exception.MedicarePayException;
import org.eox.medsupp.schema.model.MedicareLinkedAccount;
import org.eox.medsupp.schema.model.MedicareEmailLogging;
import org.eox.medsupp.schema.request.UpdateLinkedAccountRequest;


public interface MedicarePayDao
{

	public List<MedicareLinkedAccount> getLinkedAccount(String hcid) throws MedicarePayException;

	public String addLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException;

	public void deleteLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException;

	public void removeLinkedAccount(UpdateLinkedAccountRequest request) throws MedicarePayException;

	public Set<String> getChildHcids(String hcid, String serviceEnv) throws MedicarePayException;

	public String getLinkedAccountStatus(UpdateLinkedAccountRequest request) throws MedicarePayException;

	public boolean updateLinkedAccountStatus(UpdateLinkedAccountRequest request) throws MedicarePayException;

	public String getLinkedAccountStatusFromKey(String key) throws MedicarePayException;

	public boolean checkIfMemberExists(String hcid, String sourceSystem) throws MedicarePayException;

	public boolean insertMemberDetails(String hcid, String sourceSystem) throws MedicarePayException;

	public List<String> getAllowedPaymentMethod(String state, String lob, String payType) throws MedicarePayException;

	public String updateLinkedAccountStatusFromKey(String action, String key) throws MedicarePayException;

	public boolean saveEmailLog(MedicareEmailLogging memberpayEmailLogging) throws MedicarePayException;

}
