/**
 * RSTransLog.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/10/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.entity;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


public class RSTransLog implements Serializable
{
	private static final long serialVersionUID = -5154713930571769197L;

	private BigDecimal rsTransId;

	private String hcid;

	private String channel;

	private String operationName;

	private String requestXML;

	private String responseXML;

	private String errorMsg;

	private Date createdDate;

	private String requestingSystem;

	private Date requestTS;

	private Date responseTS;

	/**
	 * @return the rsTransId
	 */
	public BigDecimal getRsTransId()
	{
		return rsTransId;
	}

	/**
	 * @param rsTransId
	 *            the rsTransId to set
	 */
	public void setRsTransId(BigDecimal rsTransId)
	{
		this.rsTransId = rsTransId;
	}

	/**
	 * @return the hcid
	 */
	public String getHcid()
	{
		return hcid;
	}

	/**
	 * @param hcid
	 *            the hcid to set
	 */
	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	/**
	 * @return the channel
	 */
	public String getChannel()
	{
		return channel;
	}

	/**
	 * @param channel
	 *            the channel to set
	 */
	public void setChannel(String channel)
	{
		this.channel = channel;
	}

	/**
	 * @return the operationName
	 */
	public String getOperationName()
	{
		return operationName;
	}

	/**
	 * @param operationName
	 *            the operationName to set
	 */
	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}

	/**
	 * @return the requestXML
	 */
	public String getRequestXML()
	{
		return requestXML;
	}

	/**
	 * @param requestXML
	 *            the requestXML to set
	 */
	public void setRequestXML(String requestXML)
	{
		this.requestXML = requestXML;
	}

	/**
	 * @return the responseXML
	 */
	public String getResponseXML()
	{
		return responseXML;
	}

	/**
	 * @param responseXML
	 *            the responseXML to set
	 */
	public void setResponseXML(String responseXML)
	{
		this.responseXML = responseXML;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg()
	{
		return errorMsg;
	}

	/**
	 * @param errorMsg
	 *            the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate()
	{
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

	/**
	 * @return the requestingSystem
	 */
	public String getRequestingSystem()
	{
		return requestingSystem;
	}

	/**
	 * @param requestingSystem
	 *            the requestingSystem to set
	 */
	public void setRequestingSystem(String requestingSystem)
	{
		this.requestingSystem = requestingSystem;
	}

	/**
	 * @return the requestTS
	 */
	public Date getRequestTS()
	{
		return requestTS;
	}

	/**
	 * @param requestTS
	 *            the requestTS to set
	 */
	public void setRequestTS(Date requestTS)
	{
		this.requestTS = requestTS;
	}

	/**
	 * @return the responseTS
	 */
	public Date getResponseTS()
	{
		return responseTS;
	}

	/**
	 * @param responseTS
	 *            the responseTS to set
	 */
	public void setResponseTS(Date responseTS)
	{
		this.responseTS = responseTS;
	}

}
