/**
 * LocalDatabaseConfig.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.config;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


//@Configuration
//@Profile("local")
//@PropertySource("classpath:application-dev.properties")
public class LocalDatabaseConfig
{

	@Bean(name = "jdbcTemplateWallet")
	public JdbcTemplate jdbcTemplateWallet(DataSource dataSource)
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.setResultsMapCaseInsensitive(true);
		return jdbcTemplate;
	}

	@Bean(name = "walletDb")
	public DataSource walletDb(@Value("${medicarepay.db.walletdb.driverClassName}") String walletDbDriver,
			@Value("${medicarepay.db.walletdb.url}") String walletDbUrl,
			@Value("${medicarepay.db.walletdb.username}") String walletDbUsername,
			@Value("${medicarepay.db.walletdb.password}") String walletDbPassword)
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(walletDbDriver);
		dataSource.setUrl(walletDbUrl);
		dataSource.setUsername(walletDbUsername);
		dataSource.setPassword(walletDbPassword);
		return dataSource;
	}
}
