/**
 * MedicareLoggingDao.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.dao;


import org.eox.medsupp.datasvc.payment.entity.PaymentDetailsLog;
import org.eox.medsupp.datasvc.payment.entity.PaymentMethodLog;
import org.eox.medsupp.datasvc.payment.entity.RSTransLog;
import org.eox.medsupp.datasvc.payment.entity.TPTServicesLog;
import org.eox.medsupp.schema.exception.MedicarePayException;


public interface MedicareLoggingDao
{

	public void saveRSServiceLog(RSTransLog rSTransLog) throws MedicarePayException;

	public void saveTPTServiceLog(TPTServicesLog logData) throws MedicarePayException;

	public void savePaymentMethodLog(PaymentMethodLog paymentMethodLog) throws MedicarePayException;

	public void savePaymentDetailsLog(PaymentDetailsLog paymentDetailsLog) throws MedicarePayException;

}
