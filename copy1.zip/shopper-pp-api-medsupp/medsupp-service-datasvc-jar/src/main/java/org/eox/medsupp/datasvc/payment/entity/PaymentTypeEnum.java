/**
 * PaymentTypeEnum.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package org.eox.medsupp.datasvc.payment.entity;


public enum PaymentTypeEnum
{

	NONE,

	BANKINGACCOUNT,

	CREDITDEBITCARD;

	public String value()
	{
		return name();
	}

	public static PaymentTypeEnum fromValue(String v)
	{
		return valueOf(v);
	}
}