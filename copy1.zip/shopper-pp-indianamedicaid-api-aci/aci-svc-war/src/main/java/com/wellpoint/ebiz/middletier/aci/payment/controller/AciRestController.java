/**
 * MemberPayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 * 05/16/2017  1.1      Cognizant       Modified by Cognizant for TPP change July 2017
 */
package com.wellpoint.ebiz.middletier.aci.payment.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.PaymentAckDetail;
import com.wellpoint.aci.response.ResponseMessage;
import com.wellpoint.ebiz.middletier.aci.payment.service.AciService;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ThreadAttribute;


@Controller
public class AciRestController implements AciServiceConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(AciRestController.class);

	@Autowired
	private AciService memberPaymentServiceImpl;

	@Autowired
	ThreadAttribute threadAttribute;

	@Autowired
	ServiceUtil serviceUtil;	

	@RequestMapping(value = "manageAciPaymentMethod", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciFundingResponse manageAciPaymentMethod(@RequestBody AciFundingRequest request,HttpServletRequest httpRequest) throws Exception{
		AciFundingResponse response= new AciFundingResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		//Modified by Cognizant for TPP change July 2017 - Start
		request.setOrgType(ServiceUtil.getMetaOrgTypeValue(httpRequest));
		//Modified by Cognizant for TPP change July 2017 - End
		request.setEndPointName("manageAciPaymentMethod");	
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response=memberPaymentServiceImpl.manageAciPaymentMethod(request);
		response.setUserId(request.getHcid());		
		if(response.getAciException() != null){  
			throw response.getAciException();
		}

		if(null!= response.getMessage()){
			if(response.getMessage().getMessageCode()==500){
				throw new AciException("I", "AC9000","Soap Fault Occured in ACI Call",500);
			}
		}		
		if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}


	@RequestMapping(value = "searchAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciPaymentSearchResponse searchAciPayment(@RequestBody AciPaymentSearchRequest request,HttpServletRequest httpRequest) throws Exception{
		AciPaymentSearchResponse response= new AciPaymentSearchResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		request.setEndPointName("searchAciPayment");
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response=memberPaymentServiceImpl.searchAciPayment(request);
		response.setUserId(request.getHcid());
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}


	@RequestMapping(value = "submitAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciPaymentResponse submitAciPayment(@RequestBody AciPaymentRequest request,HttpServletRequest httpRequest) throws Exception{
		AciPaymentResponse response= new AciPaymentResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		//Modified by Cognizant for TPP change July 2017 - Start
		request.setOrgType(ServiceUtil.getMetaOrgTypeValue(httpRequest));
		//Modified by Cognizant for TPP change July 2017 - End
		request.setEndPointName("submitAciPayment");	
		if(null!=request && AciUtils.checkNullForAString(request.getHcid())){
			if(AciUtils.checkNullForAList(request.getAciPayments())){
				request.setHcid(request.getAciPayments().get(0).getPaymentSubmissionId());
			}
		}
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response=memberPaymentServiceImpl.submitAciPayment(request);
		response.setUserId(request.getHcid());		
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		if(null!=response && null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}
		if(null!=response && null!=response.getPaymentAckDetails()){
			List<PaymentAckDetail> paymentAckDetailLst=response.getPaymentAckDetails();
			for(PaymentAckDetail paymentAckDetail:paymentAckDetailLst){
				if(null!=paymentAckDetail.getResponseMessage()){
					setErrorMessage(paymentAckDetail.getResponseMessage());
				}
			}
		}
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}

	@RequestMapping(value = "cancelAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciCancelResponse cancelAciPayment(@RequestBody AciCancelRequest request,HttpServletRequest httpRequest) throws Exception{
		AciCancelResponse response= new AciCancelResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		request.setEndPointName("cancelAciPayment");		
		serviceUtil.addThreadAttribute(request.getPaymentConfirmationNo(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getPaymentConfirmationNo(),request.getRequestingSystem());
		response=memberPaymentServiceImpl.cancelAciPayment(request);
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}

	private void setErrorMessage(ResponseMessage response){

		if(null!=response.getMessageCode()){
			String messgaeValue=serviceUtil.getMessageBundleValue("submit.payment.error.code."+response.getMessageCode().trim());			
			if(null!=messgaeValue && messgaeValue.trim().length()>0){					
				response.setMessageDesc(messgaeValue);				
			}			
			if(response.getMessageCode().equalsIgnoreCase("1075")||
					response.getMessageCode().equalsIgnoreCase("1020")){							
				response.setMessageCode("0");				
			}			
		}


	}
}
