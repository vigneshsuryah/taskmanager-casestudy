/**
 * MedSuppAciRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.medsupp.aci.payment.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ThreadAttribute;
import com.wellpoint.ebiz.middletier.medsupp.aci.payment.service.MedSuppAciService;


@Controller
@RequestMapping(value = "medsupp")
public class MedSuppAciRestController implements AciServiceConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(MedSuppAciRestController.class);

	@Autowired
	private MedSuppAciService medSuppAciServiceImpl;

	@Autowired
	ThreadAttribute threadAttribute;

	@Autowired
	ServiceUtil serviceUtil;	

	@RequestMapping(value = "/manageAciPaymentMethod", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciFundingResponse manageAciPaymentMethod(@RequestBody AciFundingRequest request,HttpServletRequest httpRequest) throws Exception{
		AciFundingResponse response= new AciFundingResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		//request.setOrgType(ServiceUtil.getMetaOrgTypeValue(httpRequest));
		request.setEndPointName("manageAciPaymentMethod");	
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response = medSuppAciServiceImpl.manageAciPaymentMethod(request);
		response.setUserId(request.getHcid());		
		if(response.getAciException() != null){  
			throw response.getAciException();
		}

		/*if(null!= response.getMessage()){
			if(response.getMessage().getMessageCode()==500){
				throw new AciException("I", "AC9000","Soap Fault Occured in ACI Call",500);
			}
		}		
		if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}*/
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}


	@RequestMapping(value = "/searchAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciPaymentSearchResponse searchAciPayment(@RequestBody AciPaymentSearchRequest request,HttpServletRequest httpRequest) throws Exception{
		AciPaymentSearchResponse response= new AciPaymentSearchResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		request.setEndPointName("searchAciPayment");
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response = medSuppAciServiceImpl.searchAciPayment(request);
		response.setUserId(request.getHcid());
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		/*if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}*/
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}


	@RequestMapping(value = "/submitAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciPaymentResponse submitAciPayment(@RequestBody AciPaymentRequest request,HttpServletRequest httpRequest) throws Exception{
		AciPaymentResponse response= new AciPaymentResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		//request.setOrgType(ServiceUtil.getMetaOrgTypeValue(httpRequest));
		request.setEndPointName("submitAciPayment");	
		if(null == request || null == request.getHcid() || request.getHcid().isEmpty()){
			if(AciUtils.checkNullForAList(request.getAciPayments())){
				request.setHcid(request.getAciPayments().get(0).getPaymentSubmissionId());
			}
		}
		serviceUtil.addThreadAttribute(request.getHcid(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getHcid(),request.getRequestingSystem());
		response = medSuppAciServiceImpl.submitAciPayment(request);
		response.setUserId(request.getHcid());		
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		/*if(null!=response && null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}
		if(null!=response && null!=response.getPaymentAckDetails()){
			List<PaymentAckDetail> paymentAckDetailLst=response.getPaymentAckDetails();
			for(PaymentAckDetail paymentAckDetail:paymentAckDetailLst){
				if(null!=paymentAckDetail.getResponseMessage()){
					setErrorMessage(paymentAckDetail.getResponseMessage());
				}
			}
		}*/
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}

	@RequestMapping(value = "/cancelAciPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON,
			APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody AciCancelResponse cancelAciPayment(@RequestBody AciCancelRequest request,HttpServletRequest httpRequest) throws Exception{
		AciCancelResponse response= new AciCancelResponse();
		request.setRequestingSystem(ServiceUtil.getMetaSenderAppValue(httpRequest));
		request.setEndPointName("cancelAciPayment");		
		serviceUtil.addThreadAttribute(request.getPaymentConfirmationNo(), request.getRequestingSystem());
		threadAttribute.getThreadAttrs().put(SENDER_KEY+request.getPaymentConfirmationNo(),request.getRequestingSystem());
		response = medSuppAciServiceImpl.cancelAciPayment(request);
		if(response.getAciException() != null){  
			throw response.getAciException();
		}
		/*if(null!= response.getResponseMessage()){
			setErrorMessage(response.getResponseMessage());
		}*/
		serviceUtil.removeAttribute(request.getHcid());
		return response;
	}

	/*private void setErrorMessage(ResponseMessage response){

		if(null!=response.getMessageCode()){
			String messgaeValue=serviceUtil.getMessageBundleValue("submit.payment.error.code."+response.getMessageCode().trim());			
			if(null!=messgaeValue && messgaeValue.trim().length()>0){					
				response.setMessageDesc(messgaeValue);				
			}			
			if(response.getMessageCode().equalsIgnoreCase("1075")||
					response.getMessageCode().equalsIgnoreCase("1020")){							
				response.setMessageCode("0");				
			}			
		}
	}*/
}
