/**
* AciAspect.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.aspect;


import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.thoughtworks.xstream.XStream;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.request.AciBaseRequest;
import com.wellpoint.aci.request.BaseRequest;
import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.aci.response.BaseResponse;
import com.wellpoint.ebiz.middletier.aci.payment.service.AciService;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.MemberPayAccessProviderUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;


@Aspect
public class AciAspect implements AciServiceConstants
{
	@Autowired
	private AciService aciServiceImpl;
	
	@Value("${memberpay.setting.payment.ui.restconsumer.service.allowed.applications}")
	private String allowedApplication;
	
	final static Logger LOGGER = Logger.getLogger(AciAspect.class);

	@Before("execution(* com.wellpoint.ebiz.middletier.aci.payment.service.*.*(..)) && !execution(* com.wellpoint.ebiz.middletier.aci.payment.service.AciService.memberPayLogging(..)) && !execution(* com.wellpoint.ebiz.middletier.aci.payment.service.AciService.addMemberPayTPTLog(..))&& !execution(* com.wellpoint.ebiz.middletier.aci.payment.service.AciService.updateMemberPayTPTLog(..))")
	public void logBefore(JoinPoint joinPoint) throws AciException
	{
		
		Object[] objs = joinPoint.getArgs();
		LOGGER.info("About to intercept request");
		String mdcHcidAppended = "";
		for (Object obj : objs)
		{
			if (obj instanceof BaseRequest)
			{
				String metaSenderAppCheckFlag = ServiceUtil.getStringProperty("aci.setting.check.metasenderapp.value", "N");
				 BaseRequest request = (BaseRequest) obj;
				 String requestingApplication = request.getRequestingSystem();
				 String secureUserName=ServiceUtil.getStringProperty("memberpay.setting.payment.ui.restconsumer.service.username."+requestingApplication, "");
				 String securePassword=ServiceUtil.getStringProperty("memberpay.setting.payment.ui.restconsumer.service.password."+requestingApplication, "");
				 String secureAlgorithm=ServiceUtil.getStringProperty("memberpay.setting.payment.ui.restconsumer.service.algorithm."+requestingApplication, "");
				 String secureKey=ServiceUtil.getStringProperty("memberpay.setting.payment.ui.restconsumer.service.key."+requestingApplication, "");
				if(metaSenderAppCheckFlag != null && metaSenderAppCheckFlag.equalsIgnoreCase("Y"))
				{  
					if(allowedApplication == null || allowedApplication.isEmpty() || requestingApplication == null || requestingApplication.isEmpty() || 
							!ServiceUtil.checkReqAppEndPoint(requestingApplication, request.getEndPointName()))
					{
						LOGGER.error("Access Denied....Request header missing");
						throw new AciException("I","PP9044", "Access Denied....In-Valid Requesting Application", 401);
					}
				}   
				if (request.getRequestHeader() == null)   
				{
					LOGGER.error("Access Denied....Request header missing");
					throw new AciException("I","PP9025", "Access Denied. Request header missing", 403);
				}
				if (request.getRequestHeader() != null
						&& !MemberPayAccessProviderUtils.authenticateUserName(request.getRequestHeader().getUserName(), secureUserName))
				{
					LOGGER.error("Access denied In-Valid User Name");
					throw new AciException("I","PP9026", "Access Denied. In-Valid User Name",401);
				}
				
				
				
				if (request.getRequestHeader() != null
						&& !MemberPayAccessProviderUtils.authenticatePassword(request.getRequestHeader().getPassword(), secureKey,
								secureAlgorithm, securePassword))
				{
					LOGGER.error("Access denied In-Valid Password");
					throw new AciException("I","PP9027", "Access Denied. In-Valid Password",401);
				}
				
				try
				{
					if(AciUtils.checkNullForAString(request.getHcid()))
					{
						mdcHcidAppended = ServiceUtil.getEncodedText(request.getHcid());
					}
				}catch(Exception e)
				{
					mdcHcidAppended = request.getHcid();
				}
				
				MDC.put("hcid4Logging", mdcHcidAppended);
				MDC.put("requestingApplication", requestingApplication);
			}
			else
			{
				LOGGER.error("Access denied illegal request");
				throw new AciException("I","PP9028", "Access Denied. Illegal Request",403);
			}

		}
	}

	@AfterThrowing(pointcut = "execution(* com.wellpoint.ebiz.middletier.aci.payment.service.*.*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error)
	{

		LOGGER.error("Suspected error in the request::" + error.getCause());

	}

	@Around("allMethodsPointcut()")
	public Object trackReqRes(ProceedingJoinPoint joinPoint) throws Throwable
	{
		XStream xstream = new XStream();
		Object response = null;
		MemberPayLoggingRequest loggingRequest = new MemberPayLoggingRequest();
		MemberPayTransLog memberpayTransLog = new MemberPayTransLog();
		memberpayTransLog.setChannel("Application");
		String operationName = joinPoint.getSignature().getName() == null ? " " : joinPoint.getSignature().getName();
		memberpayTransLog.setOperationName(operationName);
		memberpayTransLog.setCreatedDate(new Date());
		try
		{
			Object[] objs = joinPoint.getArgs();
			String requestingSystem = "";
			for (Object obj : objs)
			{
				if (obj instanceof BaseRequest)
				{
					String hcid = ((BaseRequest) obj).getHcid() == null ? " " : ((BaseRequest) obj).getHcid();
					memberpayTransLog.setStartTime(new Date());
					if(obj instanceof AciBaseRequest && !AciUtils.checkNullForAString(hcid) && !" ".equals(hcid)){
						hcid=((AciBaseRequest) obj).getHcid();
					}
					/*if(obj instanceof AciCancelRequest){
						hcid = ((AciCancelRequest) obj).getPaymentConfirmationNo();
					}*/
					memberpayTransLog.setHcid(hcid);   
					memberpayTransLog.setRequestXML(xstream.toXML(obj));
				}
				if(obj instanceof HttpServletRequest){
					requestingSystem = ServiceUtil.getMetaSenderAppValue(((HttpServletRequest) obj));
				}
			}
			response = joinPoint.proceed();
			memberpayTransLog.setEndTime(new Date());
			if (response instanceof BaseResponse)
			{
				if (null != ((BaseResponse) response).getAciException())
				{
					memberpayTransLog.setErrorMsg(xstream.toXML(response));
				}
				else
				{
					memberpayTransLog.setResponseXML(xstream.toXML(response));
				}
			}
			if (memberpayTransLog.getRequestXML() == null || memberpayTransLog.getRequestXML().isEmpty())
			{
				memberpayTransLog.setRequestXML(" ");
			}
			loggingRequest.setMemberpayTransLog(memberpayTransLog);
			loggingRequest.setRequestingSystem(requestingSystem);
		    aciServiceImpl.memberPayLogging(loggingRequest);
		} catch (AciException e)
		{
			LOGGER.error("Exception occured in trackReqRes :" + e);
			throw e;
		}
		MDC.clear();
		return response;
	}

	@Pointcut("execution(* com.wellpoint.ebiz.middletier.aci.payment.controller.AciRestController.*(..))")
	public void allMethodsPointcut()
	{
	}      
	
}
