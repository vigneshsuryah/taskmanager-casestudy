package com.wellpoint.ebiz.middletier.aci.payment.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.log4j.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.request.LoggingChangeRequest;
import com.wellpoint.aci.response.LoggingChangeResponse;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ApplicationPropertiesService;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;

@Controller
public class UtilityController implements AciServiceConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UtilityController.class);

	
	@Autowired
	private ApplicationPropertiesService applicationProperties;
	
	@RequestMapping(value = "changeLoggingLevel", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = {
			APPLICATION_TYPE_JSON, APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	LoggingChangeResponse changeLoggingLevel(@RequestBody LoggingChangeRequest request) throws AciException
	{
		LoggingChangeResponse response= new LoggingChangeResponse();
		try
		{
			String changeLevel = request.getLoggingLevel();
			response.setChangeStatus("NOT CHANGED");
			//Veracode Fix Start - 06/05/2017
			//LOGGER.info("Inside changeLoggingLevel() of PPORTMEMBERSVCV2 :" + changeLevel + ":");
			LOGGER.info("Inside changeLoggingLevel() of PPORTMEMBERSVCV2 Changed");
			//Veracode Fix Start - 06/05/2017
			org.apache.log4j.Logger root = org.apache.log4j.Logger.getRootLogger();
			if(changeLevel != null && !changeLevel.isEmpty())
			{
				if(changeLevel.equalsIgnoreCase("ALL"))
				{
					root.setLevel(Level.ALL);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("TRACE"))
				{
					root.setLevel(Level.TRACE);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("DEBUG"))
				{
					root.setLevel(Level.DEBUG);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("INFO"))
				{
					root.setLevel(Level.INFO);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("WARN"))
				{
					root.setLevel(Level.WARN);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("ERROR"))
				{
					root.setLevel(Level.ERROR);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("FATAL"))
				{
					root.setLevel(Level.FATAL);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("OFF"))
				{
					root.setLevel(Level.OFF);
					response.setChangeStatus("CHANGED");
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in changeLoggingLevel() of PPORTMEMBERSVCV2");
		}
		return response;
	}
	
	@RequestMapping(value = "changeMessageBundlePropsValue", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = {
			APPLICATION_TYPE_JSON, APPLICATION_TYPE_XML }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody
	LoggingChangeResponse changeMessageBundlePropsValue(@RequestBody LoggingChangeRequest request) throws AciException
	{
		LoggingChangeResponse response= new LoggingChangeResponse();
		response.setChangeStatus("Value Not Changed. Error Occured.");
		try
		{
			String key = request.getPropsKey();
			String value = request.getPropsValue();
			//Veracode Fix Start - 06/05/2017
			//LOGGER.info("Inside changeMessageBundlePropsValue() of PPORTMEMBERSVCV2 : key :: " + key + ", value :: " + value);
			LOGGER.info("Inside changeMessageBundlePropsValue() of PPORTMEMBERSVCV2 : key and value changed");
			//Veracode Fix Start - 06/05/2017
			String path = "/wsapps/eox/deployment/config/memberpay/aci/service/message-bundle.properties";
			Properties props = new Properties();
			  
		      FileInputStream configStream = new FileInputStream(path);
		      props.load(configStream);
		      configStream.close();
		      
		      String existingValue = props.getProperty(key, "NOTFOUND");
		      if( existingValue != null && !existingValue.isEmpty() && !existingValue.equals("NOTFOUND"))
		      {
		    	  props.setProperty(key, value);
		    	  FileOutputStream output = new FileOutputStream(path);
			      props.store(output, "Archaius - Dynamic Loading Property file.");
			      output.close();
		    	  response.setChangeStatus("Value Changed");
		    	  applicationProperties.updateProperties();
		      }else
		      {
		    	  response.setChangeStatus("New Key - Not Added");
		      }
		} catch (Exception e)
		{
			LOGGER.error("Exception in changeMessageBundlePropsValue() of PPORTMEMBERSVCV2 : " + e);
		}
		return response;
	}
}
