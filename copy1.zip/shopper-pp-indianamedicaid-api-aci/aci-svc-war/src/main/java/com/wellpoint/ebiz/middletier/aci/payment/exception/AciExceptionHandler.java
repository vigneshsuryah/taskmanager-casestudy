/**
* AciExceptionHandler.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 10/06/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.exception;


import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.aci.exception.Exceptions;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.exception.RestError;

@ControllerAdvice
public class AciExceptionHandler
{
	
	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	public @ResponseBody RestError handleCustomException (Exception ex, HttpServletResponse response) {
		response.setHeader("Content-Type", "application/json");
		if(ex instanceof AciException){
			if(ex == null)
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				RestError restError = returnRestErrorPP9043();
				return restError;
			}else
			{
				response.setStatus(((AciException) ex).getReturnStatus());
				return ((AciException) ex).transformException();
			}
		}else
		{
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			RestError restError = returnRestErrorPP9043();
			return restError;
		}
		
	}
	
	public RestError returnRestErrorPP9043()
	{
		RestError restError = new RestError();
		Exceptions exception = new Exceptions();
		exception.setType("E");
		exception.setCode("PP9043");
		exception.setMessage("One or more of the request parameters are missing/wrong. Please correct the request.");
		exception.setDetail("One or more of the request parameters are missing/wrong. Please correct the request.");
		Exceptions exceptions[] = new Exceptions[1];
		exceptions[0] = exception;
		restError.setExceptions(exceptions);
		return restError;
	}
}
