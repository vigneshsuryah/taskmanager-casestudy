package com.wellpoint.ebiz.middletier.aci.service.test;


import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:*/spring/transcentra/root-integration-context.xml" })
public class RestConsumer
{

	/*@Test
	public void getSinglePaymentMethodRestCallTest()
	{
		GetPaymentMethodRequest request = new GetPaymentMethodRequest();
		RestTemplate restTemplate = new RestTemplate();

		RequestHeader requestHeader = new RequestHeader();
		requestHeader.setUserName("PPORT");
		requestHeader.setPassword("yB3Jid2Og5OZ062CKsLbKZvDiFZqmaRV");
		request.setRequestHeader(requestHeader);
		request.setTokenId("1");
		Gson gson = new Gson();
		try
		{
			System.out.println(gson.toJson(request));
			GetPaymentMethodResponse response = restTemplate.postForObject("http://localhost:9080/pportmembersvc/getPaymentMethod",
					request, GetPaymentMethodResponse.class);
			System.out.println(response.getMemberpayPaymentMethod() != null);
			assert response.getMemberpayPaymentMethod() != null;
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/


}
