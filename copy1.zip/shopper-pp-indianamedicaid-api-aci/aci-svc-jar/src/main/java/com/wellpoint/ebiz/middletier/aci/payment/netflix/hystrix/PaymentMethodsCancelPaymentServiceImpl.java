package com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix;

import org.apache.log4j.Logger;

import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceResponse;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.hystrix.service.CircuitBreakerService;

public class PaymentMethodsCancelPaymentServiceImpl implements CircuitBreakerService{

	private static final Logger LOGGER = Logger.getLogger(PaymentMethodsCancelPaymentServiceImpl.class);
	
	private CancelPaymentServiceRequest request;
	private AciGateway memberPayGateway;
	private String requestingSystem;
	
	public PaymentMethodsCancelPaymentServiceImpl(CancelPaymentServiceRequest request, AciGateway memberPayGateway, String requestingSystem) {
		this.request = request;
		this.memberPayGateway = memberPayGateway;
		this.requestingSystem = requestingSystem;
	}	
	
	@Override
	public Object postSuccess() throws Exception {
		LOGGER.info("PMCancelPay-ACI:postSuccess is invoked");
		try {
			CancelPaymentServiceResponse response = memberPayGateway.cancelPayment(request, requestingSystem);
			return response;
		} catch (Exception e) {
			return new CancelPaymentServiceResponse();
		}
	}

	@Override
	public Object postFailure() throws Exception {
		LOGGER.error("PMCancelPay-ACI:postFailure is invoked");
		return new CancelPaymentServiceResponse();
	}

}
