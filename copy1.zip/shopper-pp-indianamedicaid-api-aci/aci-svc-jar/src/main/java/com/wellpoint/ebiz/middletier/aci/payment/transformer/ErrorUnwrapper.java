/**
* ErrorUnwrapper.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;


import java.io.StringWriter;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.integration.Message;
import org.springframework.integration.MessageHandlingException;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.message.ErrorMessage;
import org.springframework.integration.message.GenericMessage;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.wellpoint.aci.exception.AciException;


@MessageEndpoint
public class ErrorUnwrapper
{

	public static final String CODE = "code";
	public static final String DESCRIPTION = "description";
	public static final String MESSAGE = "message";

	private static final Logger LOGGER = Logger.getLogger(ErrorUnwrapper.class);

	@Transformer
	public Message<?> transform(ErrorMessage errorMessage)
	{
		AciException errorSummary = null;
		String errorCode = "";
		String errorDescription = "";
		try
		{
			Throwable exception = errorMessage.getPayload().getCause();
			LOGGER.error("Handling webservice excpetion in error unwrapper");
			LOGGER.error("Actual Exception: Error Unwrapper: " + exception.getCause());
			if (exception instanceof SoapFaultClientException)
			{
				SoapFaultClientException soapFaultClientException = (SoapFaultClientException) exception;
				SoapFault soapFault = soapFaultClientException.getSoapFault();
				DOMSource detail = (DOMSource) soapFault.getFaultDetail().getSource();
				javax.xml.transform.Transformer transformer = TransformerFactory.newInstance().newTransformer();
				StreamResult result = new StreamResult(new StringWriter());
				transformer.transform(detail, result);
				LOGGER.error("Exception received from web service:" + result.getWriter().toString());
				Node detailNode = detail.getNode();
				NodeList childNodes = detailNode.getChildNodes();
				for (int i = 0; i < childNodes.getLength(); i++)
				{
					Node currentNode = childNodes.item(i);
					for (int j = 0; j < currentNode.getChildNodes().getLength(); j++)
					{
						Node currentchildNode = currentNode.getChildNodes().item(j);
						for (int k = 0; k < currentchildNode.getChildNodes().getLength(); k++)
						{
							Node currentchildNode2 = currentchildNode.getChildNodes().item(k);
							if (currentchildNode2.getNodeName().toLowerCase().contains(CODE))
							{
								errorCode = currentchildNode2.getTextContent();
							}
							else if (currentchildNode2.getNodeName().toLowerCase().contains(DESCRIPTION))
							{
								errorDescription = currentchildNode2.getTextContent();
							}
							else if (currentchildNode2.getNodeName().toLowerCase().contains(MESSAGE))
							{
								errorDescription = currentchildNode2.getTextContent();
							}
						}
					}
				}
				errorSummary = new AciException(errorCode, errorDescription, 500);
			}
			else if (exception instanceof MessageHandlingException)
			{
				exception = exception.getCause();
				if(exception instanceof AciException){
					errorSummary = (AciException)exception;
				}else{
					errorSummary = new AciException(exception.getMessage());
				}
				
			}
			else
			{
				errorSummary = new AciException(exception, exception.getMessage());
			}
		} catch (Exception exception)
		{
			errorSummary = new AciException(exception, exception.getLocalizedMessage());
		}
		return new GenericMessage<AciException>(errorSummary);
	}
}
