/**
* ContentIdGenerator.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.email.utility;

import java.net.UnknownHostException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ContentIdGenerator {

	private static final Logger LOGGER = LoggerFactory.getLogger(ContentIdGenerator.class);
	private static int seq = 0;
	private static String hostname;
	
	private ContentIdGenerator()
	{
		
	}

	static {
		try {
			hostname = java.net.InetAddress.getLocalHost().getCanonicalHostName();
		} catch (UnknownHostException e) {
			Random random = null;
			try {
				random = SecureRandom.getInstance("SHA1PRNG");
			} catch(NoSuchAlgorithmException nsae) {
				LOGGER.error("NoSuchAlgorithmException:"+nsae.getCause());
			}
			if(null != random){
			hostname = random.nextInt(100000)+ ".localhost";
			}
		}
	}

	public static  int getSeq() {
	return (seq++) % 100000;
	}

	public static String getContentId() {
		int seq1 = getSeq();
		return seq1 + "." + System.currentTimeMillis() + "@" + hostname;
	}
}