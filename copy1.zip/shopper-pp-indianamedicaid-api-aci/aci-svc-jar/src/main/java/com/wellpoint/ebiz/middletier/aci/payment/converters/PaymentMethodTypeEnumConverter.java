/**
* PaymentMethodTypeEnumConverter.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.converters;


import org.dozer.CustomConverter;

import com.wellpoint.aci.model.MemberPayPaymentTypeEnum;


public class PaymentMethodTypeEnumConverter implements CustomConverter
{

	@Override
	public Object convert(Object destination, Object source, Class destinationClass, Class sourceClass)
	{
		if (source == null)
		{
			return null;
		}
		if (destinationClass.equals(String.class))
		{
			MemberPayPaymentTypeEnum memberPayPaymentTypeEnum = (MemberPayPaymentTypeEnum) source;
			return memberPayPaymentTypeEnum.name();

		}
		if (destinationClass.equals(MemberPayPaymentTypeEnum.class))
		{
			String paymentType = (String) source;
			MemberPayPaymentTypeEnum memberPayPaymentTypeEnum = null;
			if (paymentType.equals(MemberPayPaymentTypeEnum.NONE.name()))
			{
				memberPayPaymentTypeEnum = MemberPayPaymentTypeEnum.NONE;
			}
			else if (paymentType.equals(MemberPayPaymentTypeEnum.BANKINGACCOUNT.name()))
			{
				memberPayPaymentTypeEnum = MemberPayPaymentTypeEnum.BANKINGACCOUNT;
			}
			else if (paymentType.equals(MemberPayPaymentTypeEnum.CREDITDEBITCARD.name()))
			{
				memberPayPaymentTypeEnum = MemberPayPaymentTypeEnum.CREDITDEBITCARD;
			}
			return memberPayPaymentTypeEnum;
		}
		return null;
	}
}
