/**
 * MemberPaymentServiceImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/10/2015  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.aci.payment.service;

import java.util.Calendar;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.model.MemberTptServiceLog;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.MemberPayLoggingResponse;
import com.wellpoint.aci.response.Message;
import com.wellpoint.ebiz.middletier.aci.payment.dao.service.AciDaoService;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciHelperUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;


@Component
public class AciServiceImpl implements AciService,AciServiceConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(AciServiceImpl.class);
	
	@Autowired
	private AciGateway aciGateway;
	@Autowired
	private AciHelperUtils aciHelperUtils;
	@Autowired
	private AciDaoService aciDaoServiceImpl;
	
	private AciException prepareGracefulMessage(AciException exception){		
		String errorMessage = exception.getErrorMessage();
		if(EMPTY_USER_GROUP_ID.equals(errorMessage)||EMPTY_TOKEN_ID.equals(errorMessage)||BANK_ACCOUNT_INVALID.equals(errorMessage)){
			exception.setErrorCode(exception.getErrorCode());
			exception.setErrorMessage(errorMessage);
			exception.setErrorType("I");
		}else{
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
		}
		return exception;
	}

	@Override
	public AciFundingResponse manageAciPaymentMethod(AciFundingRequest request)
			throws AciException {
		AciFundingResponse response = new AciFundingResponse();
		try {
			response = aciGateway.manageAciPaymentMethod(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public AciPaymentSearchResponse searchAciPayment(
			AciPaymentSearchRequest request) throws AciException {	
		AciPaymentSearchResponse response = new AciPaymentSearchResponse();
		try {
			response= aciHelperUtils.searchForPayments(request);
		}catch (AciException e) {
			AciException exception = (AciException) e;
			response.setAciException(prepareGracefulMessage(exception));
			Message message = new Message();
			message.setMessageText(e.getMessage());
			response.setMessage(message);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public AciPaymentResponse submitAciPayment(
			AciPaymentRequest request) throws AciException {		
		AciPaymentResponse response = new AciPaymentResponse();
		try {
			response = aciGateway.submitAciPayment(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
		
	}

	@Override
	public AciCancelResponse cancelAciPayment(AciCancelRequest request)
			throws AciException {
		AciCancelResponse response = new AciCancelResponse();
		try {
			response = aciHelperUtils.cancelAciPayment(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public MemberPayLoggingResponse memberPayLogging(MemberPayLoggingRequest request) throws AciException
	{
		LOGGER.info("Inside memberPayLogging() of MemberPaymentServiceImpl");
		MemberPayLoggingResponse response = new MemberPayLoggingResponse();
		try
		{
			aciDaoServiceImpl.memberPayLogging(request.getMemberpayTransLog(),request.getRequestingSystem());
			response.setErrorFlag(false);
		} catch (Exception e)
		{
			LOGGER.error("Exception in memberPayLogging() of AciServiceImpl:"+e);
			response.setErrorFlag(true);
			response.setErrorMessage("Exception occured in while memberpay logging");
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
		return response;
	}
	
	@Override
	public Future<MemberPayLoggingResponse> addMemberPayTPTLog(
			MemberPayLoggingRequest request) throws AciException {
		MemberPayLoggingResponse response = new MemberPayLoggingResponse(); 
	    Calendar calendar= Calendar.getInstance();
		MemberTptServiceLog memberTptServiceLog= new MemberTptServiceLog();	
		MemberPayTransLog memberPayTransLog = request.getMemberpayTransLog();
		memberTptServiceLog.setOperationName(memberPayTransLog.getOperationName());
		memberTptServiceLog.setRequestXML(memberPayTransLog.getRequestXML());
		memberTptServiceLog.setResponseXML(memberPayTransLog.getResponseXML());
		memberTptServiceLog.setCreatedDate(calendar.getTime());
		memberTptServiceLog.setCreatedId(request.getHcid());
		memberTptServiceLog.setRequestTimeStamp(memberPayTransLog.getRequestTime());
		memberTptServiceLog.setResponseTimeStamp(calendar.getTime());
		memberTptServiceLog.setTptTransId(memberPayTransLog.getRsTransId());
		memberTptServiceLog.setOutGoingReqId(request.getHcid()); 
		memberTptServiceLog.setBusinessFault(memberPayTransLog.isBusinesssFault()?"Y":null);
		memberTptServiceLog.setSystemFault(memberPayTransLog.isSystemFault()?"Y":null);
		memberTptServiceLog.setIgnoreStatusFromCcdi(memberPayTransLog.isIgnoreStatusFromCcdi());
		memberTptServiceLog.setRequestingSystem(request.getRequestingSystem());
		aciGateway.saveMemberTptServiceLog(memberTptServiceLog);
		//response.setTptLogId(memberTptServiceLog.getTptTransId().toString());		
		return new AsyncResult<MemberPayLoggingResponse>(response);
	}
}