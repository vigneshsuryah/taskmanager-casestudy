/**
* WsTracingInterceptor.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapMessage;

import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ThreadAttribute;
import com.wellpoint.ebiz.middletier.aci.payment.utility.WebServiceUtils;


@Component
public class WsTracingInterceptor implements ClientInterceptor
{
	final static Logger LOGGER = Logger.getLogger(WsTracingInterceptor.class);

	@Autowired
	private WebServiceUtils webServiceUtils;
	
	@Autowired
	private ThreadAttribute threadAttribute;
	
	private static final String WS_CONTEXT_LOG_ID="WS_CONTEXT_LOG_ID";
	private static final String WS_CONTEXT_OPERATION_NAME="WS_CONTEXT_OPERATION";
	private static final String WS_CONTEXT_TRANS_ID="WS_CONTEXT_TRANS_ID";
	private static final String WS_TPT_TRANS_LOG_ID="WS_TPT_TRANS_LOG_ID";
	private static final String WS_CONTEXT_REQ_SYS="WS_CONTEXT_REQ_SYS";
	String OPERATION_NAME_ONDEMAND_GETCONTENT = "getContent";
	private static final String[] FORBIDDEN_OPERATIONS_TO_LOG={"FundingAccountORCC","FundingAdminORCC","PaymentSearchORCC","PaymentServiceORCC"};
	
	@Override
	public boolean handleRequest(MessageContext messageContext)
	{
		LOGGER.debug("OUTGOING REQUEST FOR OPERATION-->::"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME));
		WebServiceMessage message = messageContext.getRequest();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();	
		PrintStream out = new PrintStream(byos);
			
			try
			{
				message.writeTo(out);
				MemberPayLoggingRequest request = webServiceUtils.prepareTptLogRequest(
						 messageContext
								.getProperty(WS_CONTEXT_OPERATION_NAME).toString(),
						 messageContext.getProperty(WS_CONTEXT_LOG_ID).toString(),
						byos.toString(),  messageContext
								.getProperty(WS_CONTEXT_TRANS_ID).toString());
				
				messageContext.setProperty(WS_TPT_TRANS_LOG_ID, request);
				
				/*LOGGER.debug(byos.toString());*/
			} catch (Exception e)
			{
				if(isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString())){
					LOGGER.error("Exception in handleRequest of WsTracingInterceptor:" + e.getMessage());
				}
			} 
			messageContext.removeProperty(WS_CONTEXT_LOG_ID);				
			messageContext.removeProperty(WS_CONTEXT_TRANS_ID);
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext)
	{	
		LOGGER.debug("INCOMING RESPONSE FOR OPERATION-->::"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME));
		WebServiceMessage messageResponse = messageContext.getResponse();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();	
		PrintStream out = new PrintStream(byos);
		try
		{	
			messageResponse.writeTo(out);
			MemberPayLoggingRequest request=(MemberPayLoggingRequest) messageContext.getProperty(WS_TPT_TRANS_LOG_ID);			
			if(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME)!=null && !messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString().equalsIgnoreCase(OPERATION_NAME_ONDEMAND_GETCONTENT)){
				request.getMemberpayTransLog().setResponseXML(byos.toString());
			}else{
				request.getMemberpayTransLog().setResponseXML("");
			}
			SoapFault soapFault = (((SoapMessage) messageResponse).getSoapBody()).getFault();
			if (null != soapFault)
			{
				WebServiceMessage messageRequest = messageContext.getRequest();
				ByteArrayOutputStream byosRequest = new ByteArrayOutputStream();	
				PrintStream in = new PrintStream(byosRequest);
				messageRequest.writeTo(in);
				if(isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString())){
						LOGGER.error("OUTGOING REQUEST  :"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME)+":"+ServiceUtil.getEncodedText(byosRequest.toString()));
						LOGGER.error("INCOMING RESPONSE :"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME)+":"+ServiceUtil.getEncodedText(byos.toString()));
				}
				request.getMemberpayTransLog().setIgnoreStatusFromCcdi(true);
			}
			request.setRequestingSystem((String) messageContext.getProperty(WS_CONTEXT_REQ_SYS));
			webServiceUtils.addTptTransactionToLog(request);
			messageContext.removeProperty(WS_CONTEXT_OPERATION_NAME);
			messageContext.removeProperty(WS_CONTEXT_REQ_SYS);
			messageContext.removeProperty(WS_TPT_TRANS_LOG_ID); 
			
		} catch (Exception e)
		{
			if(isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString())){
				LOGGER.error("Exception in handleResponse of WsTracingInterceptor:" + ServiceUtil.getEncodedText(e.getMessage()));
			}
		}
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext)
	{
		LOGGER.error("Error Message is ");
		WebServiceMessage message = messageContext.getResponse();
		ByteArrayOutputStream byos = new ByteArrayOutputStream();	
		PrintStream out = new PrintStream(byos);
		try
		{
			message.writeTo(out);
			MemberPayLoggingRequest request=(MemberPayLoggingRequest) messageContext.getProperty(WS_TPT_TRANS_LOG_ID);
			request.getMemberpayTransLog().setResponseXML(byos.toString());
			request.getMemberpayTransLog().setBusinesssFault(true);
			request.getMemberpayTransLog().setIgnoreStatusFromCcdi(true);
			request.setRequestingSystem((String) messageContext.getProperty(WS_CONTEXT_REQ_SYS));
			webServiceUtils.addTptTransactionToLog(request);
			WebServiceMessage messageRequest = messageContext.getRequest();
			ByteArrayOutputStream byosRequest = new ByteArrayOutputStream();	
			PrintStream in = new PrintStream(byosRequest);
			messageRequest.writeTo(in);
			if(isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString())){
				LOGGER.error("OUTGOING REQUEST  :"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME)+":"+ServiceUtil.getEncodedText(byosRequest.toString()));
				LOGGER.error("INCOMING RESPONSE :"+messageContext.getProperty(WS_CONTEXT_OPERATION_NAME)+":"+ServiceUtil.getEncodedText(byos.toString()));
			}
			
		} catch (Exception ioException)
		{
			if(isAllowedToLog(messageContext.getProperty(WS_CONTEXT_OPERATION_NAME).toString())){
				LOGGER.error("Exception in handleFault of WsTracingInterceptor:" + ServiceUtil.getEncodedText(ioException.getMessage()));	
			}
		}
		messageContext.removeProperty(WS_CONTEXT_OPERATION_NAME);
		messageContext.removeProperty(WS_TPT_TRANS_LOG_ID); 
		return true;
	}

	private boolean isAllowedToLog(String operationName){
		if(!Arrays.asList(FORBIDDEN_OPERATIONS_TO_LOG).contains(operationName)){
			return true;
		}else{
			return false;
		}
	}
	
}