/**
* MemberPayUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.wellpoint.aci.exception.AciException;

@Component
public final class AciUtils implements AciServiceConstants
{
	private static final int DEAFULT_LIST_SIZE = 0;
	private static final String DEFAULT_CALENDAR_DATE_FORMAT="EEE MMM d HH:mm:ss zzz yyyy";
	private static final Logger LOGGER = Logger.getLogger(AciUtils.class);

	private AciUtils()
	{

	}
	
	/**
	 * Checks for null and empty list
	 * 
	 * @param listObject
	 * @return True or False
	 */
	public static Boolean checkNullForAList(List<?> listObject) throws AciException
	{
		try
		{
			if (listObject != null && listObject.size() > DEAFULT_LIST_SIZE)
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}

	/**
	 * 
	 * @param date
	 * @param format
	 * @return Date by the passed date format
	 * @throws AciException
	 */
	public static Date getDateByString(String date, String format) throws AciException
	{
		Date formattedDate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		try
		{
			if (null != date && !date.isEmpty())
			{
				formattedDate = simpleDateFormat.parse(date);
			}
		} catch (Exception e)
		{
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
		return formattedDate;
	}

	/**
	 * Check for null and empty string
	 * 
	 * @param value
	 * @return Boolean
	 * @throws AciException
	 */
	public static Boolean checkNullForAString(String value) throws AciException
	{
		try
		{
			if (null != value && !value.trim().isEmpty())
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}

	/**
	 * Converts java.util.Date to javax.xml.datatype.XMLGregorianCalendar
	 * @param date
	 * @return javax.xml.datatype.XMLGregorianCalendar
	 * @throws AciException
	 */
	public static XMLGregorianCalendar getGregorianCalendarDate(Date date)throws AciException{
		try {
			GregorianCalendar cal= new GregorianCalendar();
			cal.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}
	
	/**
	 * 
	 * @param targetFormat
	 * @param adjustableMonth - can be 1/-1,2 etc...
	 * @return Date with the past/future date based on adjustableMonth
	 * @throws AciException
	 */
	public static Date getAdjustedDate(String targetFormat, int adjustableMonth) throws AciException{
		  
			try {
				 Calendar calendar = Calendar.getInstance();
				  calendar.add(Calendar.MONTH,adjustableMonth);
				  SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DEFAULT_CALENDAR_DATE_FORMAT);
				  DateFormat targetDateFormat = new SimpleDateFormat(targetFormat);
				  return getDateByString(targetDateFormat.format(simpleDateFormat.parse(calendar.getTime().toString())), targetFormat);				   
			} catch (Exception e) {
				throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
			}
		
	}
	
	/**
	 * This method is used to convert a ordinal string to string
	 * @param payDate
	 * @return
	 */
	public static String getOrginalStringFromOrdinal(String payDate)
	{
		StringBuffer strBuf = new StringBuffer();
		strBuf.append("0");
		if(null != payDate)
		{
			strBuf.append(payDate.charAt(0));
		}
		return strBuf.toString();
	}
	/**
	 * This method is used to convert date to string in particular format
	 * @param date
	 * @param format
	 * @return dateInStr
	 * @throws AciException
	 */
	public static String getDateForString(Date date,String format) throws AciException
	{
		String dateInStr = null;
		try
		{
			if (null != date)
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
				dateInStr = simpleDateFormat.format(date);
			}
		} catch (Exception e)
		{
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
		return dateInStr;
	}
	
	
}
