/**
* MedSuppAciDaoService.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 02/19/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.medsupp.aci.payment.dao.service;


import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.RSTransLog;
import com.wellpoint.aci.model.TPTServicesLog;


public interface MedSuppAciDaoService {

	public void saveRSServiceLog(RSTransLog rSTransLog) throws AciException;
	
	public void saveTPTServiceLog(TPTServicesLog tPTServicesLog) throws AciException;

}
