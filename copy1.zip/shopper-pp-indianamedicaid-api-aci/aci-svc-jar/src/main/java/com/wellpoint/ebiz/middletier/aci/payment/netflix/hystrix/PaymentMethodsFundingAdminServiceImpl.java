package com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix;

import org.apache.log4j.Logger;

import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceResponse;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.hystrix.service.CircuitBreakerService;

public class PaymentMethodsFundingAdminServiceImpl implements CircuitBreakerService{

	private static final Logger LOGGER = Logger.getLogger(PaymentMethodsFundingAdminServiceImpl.class);
	
	private FundingAdminServiceRequest request;
	private AciGateway aciGateway;
	private String requestingSystem;
	
	public PaymentMethodsFundingAdminServiceImpl(FundingAdminServiceRequest request, AciGateway aciGateway, String requestingSystem) {
		this.request = request;
		this.aciGateway = aciGateway;
		this.requestingSystem = requestingSystem;
	}	
	
	@Override
	public Object postSuccess() throws Exception {
		LOGGER.info("PMFAdmin-ACI:postSuccess is invoked");
		try {
			FundingAdminServiceResponse response = aciGateway.fundingAdmin(request, requestingSystem);
			return response;
		} catch (Exception e) {
			return new FundingAdminServiceResponse();
		}
	}

	@Override
	public Object postFailure() throws Exception {
		LOGGER.error("PMFAdmin-ACI:postFailure is invoked");
		return new FundingAdminServiceResponse();
	}

}
