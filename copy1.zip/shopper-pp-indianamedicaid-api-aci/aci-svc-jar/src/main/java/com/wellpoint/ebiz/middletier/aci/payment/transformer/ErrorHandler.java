/**
* ErrorHandler.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;


import org.springframework.stereotype.Component;

import com.wellpoint.aci.exception.AciException;


@Component
public class ErrorHandler
{
	public void handleError(AciException exception) throws AciException
	{
		throw exception;
	}
}