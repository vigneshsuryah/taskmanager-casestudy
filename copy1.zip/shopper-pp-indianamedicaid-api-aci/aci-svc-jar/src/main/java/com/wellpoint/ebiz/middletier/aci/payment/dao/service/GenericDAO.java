package com.wellpoint.ebiz.middletier.aci.payment.dao.service;

import javax.sql.DataSource;

public interface GenericDAO {

	public DataSource getDataSource();

	public void setDataSource(DataSource dataSource);
}
