/**
* BankAccTypeEnumConverter.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.converters;


import org.dozer.CustomConverter;

import com.wellpoint.aci.model.MemberPayAcctTypeEnum;


public class BankAccTypeEnumConverter implements CustomConverter
{

	@Override
	public Object convert(Object destination, Object source, Class destinationClass, Class sourceClass)
	{
		if (null == source && null == destination)
		{
			return null;
		}
		if (null == source && null != destination)
		{
			return destination;
		}
		if (null == destination && null != source)
		{
			if (destinationClass.equals(String.class))
			{
				MemberPayAcctTypeEnum memberPayAcctTypeEnum = (MemberPayAcctTypeEnum) source;
				return memberPayAcctTypeEnum.name();
			}
			if (destinationClass.equals(MemberPayAcctTypeEnum.class))
			{
				String accountType = (String) source;
				MemberPayAcctTypeEnum memberPayAcctTypeEnum = null;
				if (accountType.equals(MemberPayAcctTypeEnum.NONE.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.NONE;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.PERSONALCHECKING.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.PERSONALCHECKING;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.PERSONALSAVINGS.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.PERSONALSAVINGS;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.BUSCHECKING.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.BUSCHECKING;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.BUSSAVINGS.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.BUSSAVINGS;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.VISA.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.VISA;
				}
				else if (accountType.equals(MemberPayAcctTypeEnum.MASTERCARD.name()))
				{
					memberPayAcctTypeEnum = MemberPayAcctTypeEnum.MASTERCARD;
				}
				return memberPayAcctTypeEnum;
			}
		}
		return null;
	}
}
