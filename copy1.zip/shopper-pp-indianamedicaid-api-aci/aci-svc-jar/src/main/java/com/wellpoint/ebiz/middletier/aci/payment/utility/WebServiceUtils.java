/**
* WebServiceUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.ebiz.middletier.aci.payment.service.AciService;
import com.wellpoint.ebiz.middletier.medsupp.aci.payment.service.MedSuppAciService;

@Component
public class WebServiceUtils implements AciServiceConstants{
	
	@Autowired
	private AciService aciServiceImpl;
	
	@Autowired
	private MedSuppAciService medSuppAciServiceImpl;
	
	@Autowired
	private ServiceUtil serviceUtil;
	
	public String addTptTransactionToLog(MemberPayLoggingRequest request) throws AciException{
		String reqSys = "";
		try {
			//reqSys = serviceUtil.getRequestorSystem();
			reqSys = request.getRequestingSystem();
			if(null != reqSys && "MEDSUPP".equalsIgnoreCase(reqSys)) {
				return medSuppAciServiceImpl.saveTPTLog(request).get().getTptLogId();
			} else {
				return aciServiceImpl.addMemberPayTPTLog(request).get().getTptLogId();
			}
		}
		 catch (Exception e) {
			 throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}
	
	public MemberPayLoggingRequest prepareTptLogRequest(String operationName,String hcid,String requestXML,String transId) throws AciException{
		try {
			Calendar cal=Calendar.getInstance();
			MemberPayLoggingRequest request = new MemberPayLoggingRequest();
			MemberPayTransLog transLog= new MemberPayTransLog();
			request.setHcid(hcid);
			transLog.setOperationName(operationName);
			transLog.setRequestXML(requestXML);		
			transLog.setRequestTime(cal.getTime());
			request.setMemberpayTransLog(transLog);
			return request;
		}
		 catch (Exception e) {
			 throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}
	
	public String getTransactionId(){
		try {
			/*SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
			StringBuffer randomValue= new StringBuffer();			
			for (int i = 0; i < SECURE_RANDOM_LENGTH; i++) {          
				randomValue.append(number.nextInt(10));
			}
			return randomValue.toString();
			*/
			SecureRandom random = new SecureRandom();
			return new BigInteger(130, random).toString(32);
		} catch (Exception e) {
			return "213987282a";
		}
	}
}
