/**
* MemberPayGateway.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.gateway;


import java.util.concurrent.Future;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.Header;
import org.springframework.scheduling.annotation.Async;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberTptServiceLog;
import com.wellpoint.aci.model.TPTServicesLog;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceResponse;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;


public interface AciGateway
{

	@Gateway(requestChannel = "cancelPaymentRequestChannel", replyChannel = "cancelPaymentResponseChannel")
	public CancelPaymentServiceResponse cancelPayment(CancelPaymentServiceRequest cancelPaymentServiceRequest, @Header("requestingSystem") String requestingSystem);

	@Gateway(requestChannel = "fundingRetrivalRequestChannel", replyChannel = "fundingRetrivalResponseChannel")
	public FundingAccountRetrievalServiceResponse fundingRetrival(FundingAccountRetrievalServiceRequest fundingAccountRetrievalServiceResponse, @Header("requestingSystem") String requestingSystem);

	@Gateway(requestChannel = "fundingAdminRequestChannel", replyChannel = "fundingAdminResponseChannel")
	public FundingAdminServiceResponse fundingAdmin(FundingAdminServiceRequest fundingAdminServiceResponse, @Header("requestingSystem") String requestingSystem);

	@Gateway(requestChannel = "paymentSearchRequestChannel", replyChannel = "paymentSearchResponseChannel")
	public PaymentSearchServiceResponse paymentSearch(PaymentSearchServiceRequest paymentSearchServiceRequest, @Header("requestingSystem") String requestingSystem);

	@Async
	@Gateway(requestChannel = "paymentServiceRequestChannel", replyChannel = "paymentServiceResponseChannel")
	public Future<PaymentServiceServiceResponse> paymentService(PaymentServiceServiceRequest paymentServiceServiceRequest, @Header("requestingSystem") String requestingSystem);
				
	@Gateway(requestChannel = "manageAciPayMethodRequestChannel", replyChannel = "manageAciPayMethodResponseChannel")
	public AciFundingResponse manageAciPaymentMethod(AciFundingRequest request);
	
	@Gateway(requestChannel = "submitAciPaymentRequestChannel", replyChannel = "submitAciPaymentResponseChannel")
	public AciPaymentResponse submitAciPayment(AciPaymentRequest request);
	
	@Gateway(requestChannel = "saveMemberTptInChannel", replyChannel = "saveMemberTptOutChannel")
	public int saveMemberTptServiceLog(MemberTptServiceLog memberTptServiceLog) throws AciException;
	
	@Gateway(requestChannel = "saveMedSuppMemTptInChannel", replyChannel = "saveMedSuppMemTptOutChannel")
	public int saveMedSuppMemTptLog(TPTServicesLog tPTServicesLog) throws AciException;

}
