/**
* AciDaoService.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.dao.service;


import java.util.List;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayEmailLogging;
import com.wellpoint.aci.model.MemberPaySubmitPayment;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.model.MemberTptServiceLog;


public interface AciDaoService
{

	public boolean saveEmailLog(MemberPayEmailLogging memberpayEmailLogging,String requestingSystem) throws AciException;

	public void memberPayLogging(MemberPayTransLog memberpayTransLog,String requestingSystem) throws AciException;
	
	public void insertPaymentDetailsTable(List<MemberPaySubmitPayment> loggingList,String requestingSystem) throws AciException;
		
	public int saveTPTServiceLog(MemberTptServiceLog memberTptServiceLog) throws AciException;

}
