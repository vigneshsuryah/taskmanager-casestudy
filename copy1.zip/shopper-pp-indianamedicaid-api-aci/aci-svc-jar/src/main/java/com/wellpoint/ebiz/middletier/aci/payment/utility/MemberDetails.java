/**
* MemberDetails.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import java.io.Serializable;
import java.util.Date;

public class MemberDetails implements Serializable
{
	private static final long serialVersionUID = -340506370915390470L;
	
	private String hcid;
	private String summaryBillNumber;
	private String userId;
	private Date createdDate;
	private String createdId;
	private String lastLoginId;
	private Date lastLoginDate;
	private String defaultPaymentMethod;
	private String sourceSystem;
		
	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		if(hcid != null)
		{
			this.hcid = hcid.toUpperCase();
		}else
		{
			this.hcid = hcid;
		}
	}

	public String getSummaryBillNumber()
	{
		return summaryBillNumber;
	}

	public void setSummaryBillNumber(String summaryBillNumber)
	{
		if(summaryBillNumber != null)
		{
			this.summaryBillNumber = summaryBillNumber.toUpperCase();
		}else
		{
			this.summaryBillNumber = summaryBillNumber;
		}
	}

	public String getUserId()
	{
		return userId;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public Date getCreatedDate()
	{
		return createdDate;
	}

	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

	public String getCreatedId()
	{
		return createdId;
	}

	public void setCreatedId(String createdId)
	{
		this.createdId = createdId;
	}

	public String getLastLoginId()
	{
		return lastLoginId;
	}

	public void setLastLoginId(String lastLoginId)
	{
		this.lastLoginId = lastLoginId;
	}

	public Date getLastLoginDate()
	{
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate)
	{
		this.lastLoginDate = lastLoginDate;
	}

	public String getDefaultPaymentMethod()
	{
		return defaultPaymentMethod;
	}

	public void setDefaultPaymentMethod(String defaultPaymentMethod)
	{
		this.defaultPaymentMethod = defaultPaymentMethod;
	}

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}	
}
