/**
* ServiceUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
* 05/16/2017  1.1      Cognizamt	   Modified by Cognizant for TPP change July 2017
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.MDC;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.payment.domain.orcc.Identity;
import com.wellpoint.aci.response.Message;

@Component
public class ServiceUtil implements AciServiceConstants
{

	private static String userName;

	@Value("${memberpay.setting.payment.ui.restconsumer.service.username}")
	public void setUsername(String username) {
		userName = username;
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceUtil.class);
	
	static List<String> orccServices = Arrays.asList("FundingAccountORCC", "FundingAdminORCC", "PaymentSearchORCC", "PaymentServiceORCC", "CancelPaymentORCC");
	
	@Autowired
	private transient ReloadableResourceBundleMessageSource messageSource;
	
	@Autowired
	private ThreadAttribute threadAttribute;
	
	//Modified by Cognizant for TPP change July 2017 - Start
	public Identity returnIdentityNode(String senderApp, String orgType)
	{

		String businessId = "";
		String loginVal = "";
		//Veracode Fix Start - 06/05/2017
		Identity returnIdentity = new Identity();
		if(null != senderApp && "TPP".equalsIgnoreCase(senderApp)) {
			businessId=ServiceUtil.getStringProperty("memberpay.setting.aci.business-id."+senderApp+"."+orgType, "");	
			loginVal=ServiceUtil.getStringProperty("memberpay.setting.aci.login."+senderApp+"."+orgType, "");		
			returnIdentity.setPassword(ServiceUtil.getStringProperty("memberpay.setting.aci.password."+senderApp+"."+orgType, ""));
		} else {
			businessId=ServiceUtil.getStringProperty("memberpay.setting.aci.business-id."+senderApp, "");	
			loginVal=ServiceUtil.getStringProperty("memberpay.setting.aci.login."+senderApp, "");		
			returnIdentity.setPassword(ServiceUtil.getStringProperty("memberpay.setting.aci.password."+senderApp, ""));
		}
		
		returnIdentity.setBusinessId(businessId);
		returnIdentity.setLogin(loginVal);
		//Veracode Fix End - 06/05/2017
		return returnIdentity;
	}
	//Modified by Cognizant for TPP change July 2017 - End
	
	public String roundUp(String receivedValue, int digits) {
        String formatted = "";
        String value = receivedValue;
        if(value!=null && !value.isEmpty() ){
              value = value.replaceAll(",", "").replace("$", "");
        NumberFormat nf = new DecimalFormat();
        nf.setMaximumFractionDigits(digits);
        nf.setMinimumFractionDigits(digits);
        if (value != null && !"".equals(value)) { 
              formatted =  nf.format(Float.valueOf(value));
        } 
        formatted = formatted.replaceAll(",", "").replace("$", "");
        }
        return formatted;
    }

	
	public String trimCharByLength(String city, int length)
	{
		String value = "";
		if(city != null && city.length() > length)
		{
			value = city.substring(0, length);
		}else
		{
			value= city;
		}
		return value;
	}

	public boolean notNullAndEmpty(String value)
	{
		boolean returnStatus = false;
		if(value != null && !value.isEmpty())
		{
			returnStatus = true;
		}
		return returnStatus;
	}
	
	public boolean checkTPTLoggingStatus(String serviceName)
	{
		boolean loggingStatus = false;
		
		if(notNullAndEmpty(serviceName))
		{
			if(serviceName.equalsIgnoreCase("FundingAccountORCC") && getLoggingFlagValue(AciServiceConstants.TPT_FUNDINGACCOUNT).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("FundingAdminORCC") && getLoggingFlagValue(AciServiceConstants.TPT_FUNDINGADMIN).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("PaymentSearchORCC") && getLoggingFlagValue(AciServiceConstants.TPT_PAYMENTSEARCH).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("PaymentServiceORCC") && getLoggingFlagValue(AciServiceConstants.TPT_PAYMENTSERVICE).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("CancelPaymentORCC") && getLoggingFlagValue(AciServiceConstants.TPT_CANCELPAYMENT).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}
		}
		
		return loggingStatus;
	}
	
	public boolean checkRSLoggingStatus(String serviceName)
	{
		boolean loggingStatus = false;
		
		if(notNullAndEmpty(serviceName))
		{
			if(serviceName.equalsIgnoreCase("manageAciPaymentMethod") && getLoggingFlagValue(AciServiceConstants.RS_GET_ACI_PM).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("searchAciPayment") && getLoggingFlagValue(AciServiceConstants.RS_SEARCH_ACI).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("submitAciPayment") && getLoggingFlagValue(AciServiceConstants.RS_SUBMIT_ACI).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}else if(serviceName.equalsIgnoreCase("cancelAciPayment") && getLoggingFlagValue(AciServiceConstants.RS_CANCEL_ACI).equalsIgnoreCase("Y"))
			{
				loggingStatus = true;
			}
		}
		
		return loggingStatus;
	}
	
	public boolean checkACILoggingForNonSuccessTransactions(String serviceName, String responseText)
	{
		boolean loggingStatus = false;
		List<String> orccServicesRest = Arrays.asList("memberPaySubmitPayment","updatePaymentMethod","cancelPaymentMemberPay");
		/*PP-186 changes starts*/
		if(getLoggingFlagValue(AciServiceConstants.TPT_ACI_ERROR_LOGGING_STATUS).equalsIgnoreCase("Y") && 
				notNullAndEmpty(serviceName) && orccServicesRest.contains(serviceName.trim()) && notNullAndEmpty(responseText) && 
				!responseText.contains("Success"))
		/*PP-186 changes ends*/
		{
			loggingStatus = true;
		}
		return loggingStatus;
	}
	
	public boolean checkFailedORCCTransactions(String serviceName, String responseXml)
	{
		boolean flag = false;
		/*PP-186 changes starts*/
		if(getLoggingFlagValue(AciServiceConstants.TPT_ACI_ERROR_LOGGING_STATUS).equalsIgnoreCase("Y") && notNullAndEmpty(serviceName) && orccServices.contains(serviceName.trim()) && 
				notNullAndEmpty(responseXml) && !responseXml.contains("Success"))
		/*PP-186 changes ends*/
		{
			flag = true;
		}
		return flag;
	}
	
	public static String encodeRequestORCC(String serviceName, String requestXml) throws AciException
	{
		if(null != serviceName && !serviceName.isEmpty() && orccServices.contains(serviceName.trim()) && 
				null != requestXml && !requestXml.isEmpty())
		{
			requestXml = getEncodedText(requestXml);
		}
		return requestXml;
	}
	
	public String getLoggingFlagValue(String key)
	{
		String returnValue = "N";
		try
        {
			returnValue = getValueByArchaius(key);
        }catch(Exception e)
        {
        	LOGGER.debug("Exception in retriving message bundle value for " + key);
        }
		return returnValue;
	}
	
	public static String getEncodedText(String value)
	{
		String encoded = "";
		try{
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(userName);
			encoded = encryptor.encrypt(value);
		}catch(Exception e){
			try {
				byte[] message = value.getBytes("UTF-8");
				encoded = DatatypeConverter.printBase64Binary(message);
			} catch (Exception e1) {
				encoded = value;
			}
		}
		return encoded;
	}
	
	public static String getDecodedText(String encoded)
	{
		String decoded = "";
		try {
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(userName);
			decoded = encryptor.decrypt(encoded);
		} catch (Exception e) {
			decoded = encoded;
		}
		return decoded;
	}
	
	/*public static String getEncodedText(String value)
	{
		String encoded = "";
		try {  
			byte[] message = value.getBytes("UTF-8");
			encoded = DatatypeConverter.printBase64Binary(message);
		} catch (Exception e) {
			LOGGER.debug("ServiceUtil getEncryptedText error");
		}
		return encoded;
	}
	
	public static String getDecodedText(String encoded)
	{
		String decoded = "";
		try {
			byte[] decodedByte = DatatypeConverter.parseBase64Binary(encoded);
			decoded = new String(decodedByte, "UTF-8");
		} catch (Exception e) {
			LOGGER.debug("ServiceUtil getDecryptedText error");
		}
		return decoded;
	}*/


	public String getMessageBundleValue(String key)
	{
		String displayStatusString = "";
		try
		{
			displayStatusString = messageSource.getMessage(key, null, Locale.getDefault());
			
		}catch(Exception e)
		{
			LOGGER.debug("getMessageBundleValue error for key : " + key);
		}
		return displayStatusString;
	}
	
	public String getValueByArchaius(String key)
	{
		String displayStatusString = "";
		try
		{
			displayStatusString = getStringProperty(key,"");
		}catch(Exception e)
		{
			LOGGER.debug("getMessageBundleValue error for key : " + key);
		}
		return displayStatusString;
	}
	
	public String getErrorReason(Message message)
	{
		String errorReason = "";
		if(null != message)
		{
			String messageCode = message.getMessageCode() + "";
			errorReason = messageCode + "-" + message.getMessageText();
		}
		return errorReason;
	}
	
	public String getRequestorSystem()
	{
		String requestorSystem = "REIMAGINE";
		try
		{
			String value = (String) MDC.get("requestingApplication");
			LOGGER.debug("Requestor System in ServiceUtil: "+ value);
			if(value != null && !value.isEmpty())
			{
				requestorSystem = value;
			}
		}catch(Exception e)
		{
			LOGGER.error("Error in Requestor System Pull in ServiceUtil");
		}
		return requestorSystem;
	}
	
	/*public String getRequestorSystem()
	{
		String requestorSystem = "REIMAGINE";
		return requestorSystem;
	}*/
	
	public String changeDateFormat(String fromDate, String fromDateFormatString, String toDateFormatString) throws AciException
	{
		SimpleDateFormat fromDateFormat = new SimpleDateFormat(fromDateFormatString);
		SimpleDateFormat toDateFormat = new SimpleDateFormat(toDateFormatString);
		String toDate = null;
		try
		{
			if (null != fromDate)
			{
				Date date = (Date)fromDateFormat.parse(fromDate);
				toDate = toDateFormat.format(date);
			}
		} catch (Exception e)
		{
			LOGGER.debug("Exception in converting date format : " + e);
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
		return toDate;
	}
	
	public String changeDateFormat(Date date, String format) throws AciException
	{
		String dateString = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		try
		{
			if (null != date)
			{
				dateString = simpleDateFormat.format(date);
			}
		} catch (Exception e)
		{
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
		return dateString;
	}
	
	/**
	 * 
	 * @param key
	 * @param defaultValue
	 * @return the value of the given key from the property file using Archaius
	 */
	public static String getStringProperty(String key, String defaultValue) {
        final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key,
            defaultValue);
        return property.get();
    }
	
	public static String getMetaSenderAppValue(HttpServletRequest httpRequest) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader("meta-senderapp");
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching meta-senderapp header");
        }
        return value;
    }
	
	//Added by Cognizant for TPP change July 2017 - Start
	public static String getMetaOrgTypeValue(HttpServletRequest httpRequest) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader("meta-orgType");
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching meta-orgType header");
        }
        return value;
    }
	//Added by Cognizant for TPP change July 2017 - End
	
	public static boolean checkReqAppEndPoint(String requestingApplication, String endPointName)
	{
		boolean flag = false;
		try
		{
			String allowedEndpointsString = getStringProperty("aci.setting.requestingapplication.allow.endpoint."+requestingApplication, "N");
			String[] allowedEndpointsList = allowedEndpointsString.split(",");
			if(Arrays.asList(allowedEndpointsList).contains(endPointName))
			{
				flag = true;
			}
		}catch(Exception e){
			LOGGER.error("Error occured in checkReqAppEndPoint");
		}
		return flag;
	}
	
	public static String encrypt(String plainText, String encryptionKey) 
			throws Exception {
			
			byte[] encryptedBytes = null;
			try {
				
				SecretKeySpec key = null;
				byte[] iv = null;
				byte[] keyBytes = null;
				
				keyBytes = encryptionKey.getBytes(getStringProperty("memberpay.setting.encrypt.decrypt.characterset","UTF-8"));

				key = new SecretKeySpec(keyBytes, getStringProperty("memberpay.setting.encrypt.decrypt.algorithm","AES"));
				Cipher cipher = Cipher.getInstance(getStringProperty("memberpay.setting.encrypt.decrypt.transformation","AES/CBC/PKCS5Padding"));
				iv = new byte[cipher.getBlockSize()];
				cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
				encryptedBytes = cipher.doFinal(plainText.getBytes(getStringProperty("memberpay.setting.encrypt.decrypt.characterset","UTF-8")));
				
			} catch (Exception e) {
				LOGGER.error("Inside AESEncryptionWithKey.encrypt() - Error: " + e.getMessage());
			}
					
			return new Base64().encodeAsString(encryptedBytes);
		}


		@SuppressWarnings({ "static-access" })
		public static String decrypt(String cipherText, String encryptionKey)
				throws Exception {
			
			byte[] decryptedText = null;
			try {
				
				SecretKeySpec key = null;
				byte[] keyBytes = null; 
				byte[] iv = null;
				byte[] cipherBytes = null;
				
				keyBytes = encryptionKey.getBytes(getStringProperty("memberpay.setting.encrypt.decrypt.characterset","UTF-8"));
				key = new SecretKeySpec(keyBytes, getStringProperty("memberpay.setting.encrypt.decrypt.algorithm","AES"));
				Cipher cipher = Cipher.getInstance(getStringProperty("memberpay.setting.encrypt.decrypt.transformation","AES/CBC/PKCS5Padding"));
				iv = new byte[cipher.getBlockSize()];
				cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));			
				cipherBytes = new Base64().decodeBase64(cipherText);
				decryptedText = cipher.doFinal(cipherBytes);
				
			} catch (Exception e) {
				LOGGER.error("Inside AESEncryptionWithKey.decrypt() - Error: " + e.getMessage());
			}
			
			return new String(decryptedText);
		}

		public static String encryptWithKey(String plainText) throws Exception {	
			return encrypt(plainText, getStringProperty("memberpay.setting.encrypt.decrypt.key","pportencdeckeyun"));
		}

		
		public static String decryptWithKey(String cipherText) throws Exception{
			return decrypt(cipherText, getStringProperty("memberpay.setting.encrypt.decrypt.key","pportencdeckeyun"));
		}
		
		/**
		 * 
		 * @param hcid
		 * @param senderApp
		 * @throws MemberPayException
		 */
		public void addThreadAttribute(String hcid,String senderApp) throws AciException{
			try {
				if(AciUtils.checkNullForAString(hcid)){				
						threadAttribute.getThreadAttrs().put(SENDER_KEY+hcid,senderApp);					
				}
			} catch (Exception e) {
				LOGGER.error("addThreadAttribute" + e.getMessage());
			}
		}
		
		/**
		 * 
		 * @param hcid
		 */
		public void removeAttribute(String hcid){			
			try {
				if(AciUtils.checkNullForAString(hcid)){
						threadAttribute.getThreadAttrs().remove(SENDER_KEY+hcid);
					}				
			} catch (Exception e) {
				LOGGER.error("removeAttributes" + e.getMessage());
			}
		}
		
		//Added By Cognizant for MedSupp June 2018 release - Start
		/**
		 * Checks whether to log rest service request and response in DB for Medsupp 
		 * @param serviceName
		 * @return
		 */
		public boolean checkMedSuppRSLoggingStatus(String serviceName)
		{
			boolean loggingStatus = false;
			
			if(notNullAndEmpty(serviceName))
			{
				if(serviceName.equalsIgnoreCase("manageAciPaymentMethod") && getLoggingFlagValue(AciServiceConstants.MEDSUPP_RS_GET_ACI_PM).equalsIgnoreCase("Y"))
				{
					loggingStatus = true;
				}else if(serviceName.equalsIgnoreCase("searchAciPayment") && getLoggingFlagValue(AciServiceConstants.MEDSUPP_RS_SEARCH_ACI).equalsIgnoreCase("Y"))
				{
					loggingStatus = true;
				}else if(serviceName.equalsIgnoreCase("submitAciPayment") && getLoggingFlagValue(AciServiceConstants.MEDSUPP_RS_SUBMIT_ACI).equalsIgnoreCase("Y"))
				{
					loggingStatus = true;
				}else if(serviceName.equalsIgnoreCase("cancelAciPayment") && getLoggingFlagValue(AciServiceConstants.MEDSUPP_RS_CANCEL_ACI).equalsIgnoreCase("Y"))
				{
					loggingStatus = true;
				}
			}
			
			return loggingStatus;
		}
		//Added By Cognizant for MedSupp June 2018 release - End
}
