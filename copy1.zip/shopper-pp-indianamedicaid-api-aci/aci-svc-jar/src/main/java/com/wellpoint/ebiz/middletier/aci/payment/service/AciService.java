/**
* AciService.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.service;


import java.util.concurrent.Future;

import org.springframework.scheduling.annotation.Async;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.MemberPayLoggingResponse;


public interface AciService
{	
	AciFundingResponse manageAciPaymentMethod(AciFundingRequest request) throws AciException;
	AciPaymentSearchResponse searchAciPayment(AciPaymentSearchRequest request) throws AciException;
	AciPaymentResponse submitAciPayment(AciPaymentRequest request) throws AciException;
	AciCancelResponse cancelAciPayment(AciCancelRequest request) throws AciException;
	MemberPayLoggingResponse memberPayLogging(MemberPayLoggingRequest request)	throws AciException;
	@Async
	public Future<MemberPayLoggingResponse> addMemberPayTPTLog(MemberPayLoggingRequest request) throws AciException;
}
