/**
* XMLGregorianCalendarConverter.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.converters;

import javax.xml.datatype.XMLGregorianCalendar;

import org.dozer.CustomConverter;

public class XMLGregorianCalendarConverter implements CustomConverter{

	@Override
	public Object convert(Object existingDestinationFieldValue,
			Object sourceFieldValue, Class<?> destinationClass,
			Class<?> sourceClass) {
		return (XMLGregorianCalendar)sourceFieldValue;
	}

}
