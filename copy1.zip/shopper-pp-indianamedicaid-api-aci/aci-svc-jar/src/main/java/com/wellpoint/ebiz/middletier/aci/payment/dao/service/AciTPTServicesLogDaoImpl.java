package com.wellpoint.ebiz.middletier.aci.payment.dao.service;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;

import com.wellpoint.aci.model.MemberTptServiceLog;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;

@Component
public class AciTPTServicesLogDaoImpl extends GenericDAOImpl implements AciTPTServicesLogDao
{
	@Autowired
	private ServiceUtil serviceUtil;
	
	private static final String SAVE_TPT_LOGGING_SP = "GBD.GBD_MEMBER_TPT_SERVICES_LOG";
	@Override
	public void saveTptServicesLog(MemberTptServiceLog logData) {
		TPTServicesLogging logging = new TPTServicesLogging(dataSource);
		logging.executeTPTServicesLoggingSp(logData);
		
	}
	
	protected class TPTServicesLogging extends DAOStoredProc
	{
		protected TPTServicesLogging(DataSource ds)
		{
			super(ds, SAVE_TPT_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@ISBUSINESSFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@ISSYSTEMFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEID", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEID", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEDDATE", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@TPTTRANSIDOUT", Types.BIGINT));

			compile();
		}

		protected void executeTPTServicesLoggingSp(MemberTptServiceLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getOutGoingReqId());
			inParams.put("@SBRUID", "");
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXML());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXML());
			if (logDataBean.getRequestTimeStamp() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTimeStamp().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getResponseTimeStamp() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getResponseTimeStamp().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}
			inParams.put("@ISBUSINESSFAULT", logDataBean.getBusinessFault());
			inParams.put("@ISSYSTEMFAULT", logDataBean.getSystemFault());
			inParams.put("@CREATEID", logDataBean.getCreatedId());
			inParams.put("@CREATEDDATE",  new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParams.put("@UPDATEID", logDataBean.getUpdatedId());
			inParams.put("@UPDATEDDATE",  new Timestamp(new Date().getTime()));

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@TPTTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@TPTTRANSIDOUT");
			}
		}
	}

	

}
