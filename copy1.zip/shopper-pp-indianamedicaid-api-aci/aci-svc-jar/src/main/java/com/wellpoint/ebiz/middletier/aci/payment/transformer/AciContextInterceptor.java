/**
* AciContextInterceptor.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;


import javax.xml.bind.JAXBElement;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPPart;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.princetonecom.connect.fundingaccountretrievalrequest1.FundingAccountRetrievalRequest;
import com.princetonecom.connect.fundingadminrequest.FundingAdminRequest;
import com.princetonecom.connect.otpcancelstgpaymentrequest1.OtpCancelStgPaymentRequest;
import com.princetonecom.connect.paymentsearchrequest1.PaymentSearchRequest;
import com.princetonecom.connect.paymentservicerequest.PaymentServiceRequest;
import com.thoughtworks.xstream.XStream;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.WebServiceUtils;

@Component
public class AciContextInterceptor implements ClientInterceptor,AciServiceConstants
{
	private static final Logger LOGGER = Logger.getLogger(AciContextInterceptor.class);
	private static final String CONTEXT_STR = "v3";
	@Autowired
	private Jaxb2Marshaller paymentMarshaller;
	@Autowired 
	private WebServiceUtils webServiceUtils;
	
	private XStream xstream;
	
	
	@Override
	public boolean handleRequest(MessageContext messageContext)
	{
		LOGGER.info("ACIContextInterceptor handleRequest=====================================>>>>>>>>>>>>>>>>>>>");
		WebServiceMessage message = messageContext.getRequest();
		try
		{
			SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();
			
			SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
			javax.xml.soap.SOAPMessage soapMessage1 = saajSoapMessage.getSaajMessage();
			
			SOAPPart soapPart = soapMessage1.getSOAPPart();
			SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
			SOAPHeader soapHeader = soapEnvelope.getHeader();
			
			if(soapHeader != null && soapHeader.hasAttribute("requestingSystem")) {
				messageContext.setProperty(WS_CONTEXT_REQ_SYS, soapHeader.getAttribute("requestingSystem"));
				soapHeader.removeAttribute("requestingSystem");
			}
			
			SoapBody requestBody = soapMessage.getSoapBody();
			Object requestBodyObj = paymentMarshaller.unmarshal(requestBody.getPayloadSource());
			JAXBElement<?> jaxbElement = (JAXBElement<?>) requestBodyObj;
			
			Name contextheaderName = soapEnvelope.createName("ESBHeader", CONTEXT_STR, "http://wellpoint.com/esb/header/v3");
			SOAPHeaderElement soapESBHeaderElmt = soapHeader.addHeaderElement(contextheaderName);

			SOAPElement srvcNameSOAPElement = soapESBHeaderElmt.addChildElement("srvcName", CONTEXT_STR);

			SOAPElement srvcVersionSOAPElement = soapESBHeaderElmt.addChildElement("srvcVersion", CONTEXT_STR);
			srvcVersionSOAPElement.addTextNode("1.0");

			SOAPElement senderAppSOAPElement = soapESBHeaderElmt.addChildElement("senderApp", CONTEXT_STR);
			senderAppSOAPElement.addTextNode("PPORT");

			SOAPElement msgTypSOAPElement = soapESBHeaderElmt.addChildElement("transId", CONTEXT_STR);
			SOAPElement operNameSOAPElement = soapESBHeaderElmt.addChildElement("operName", CONTEXT_STR);
			
			if(jaxbElement.getValue() instanceof FundingAccountRetrievalRequest){
				FundingAccountRetrievalRequest req=(FundingAccountRetrievalRequest) jaxbElement.getValue();
				
				srvcNameSOAPElement.addTextNode("FundingAccountORCC");
				operNameSOAPElement.addTextNode("FundingRetreivel");
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getBillingAccount().getBillingAccountNumber());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, "FundingAccountORCC");
				String transId=webServiceUtils.getTransactionId();
				msgTypSOAPElement.addTextNode(transId);
				messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);
			}else if(jaxbElement.getValue() instanceof FundingAdminRequest){
				FundingAdminRequest fundingAdminRequest = (FundingAdminRequest) jaxbElement.getValue();
				
				messageContext.setProperty(WS_CONTEXT_LOG_ID, fundingAdminRequest.getBillingAccount().getBillingAccountNumber());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, "FundingAdminORCC");
				srvcNameSOAPElement.addTextNode("FundingAdminORCC");
				operNameSOAPElement.addTextNode(fundingAdminRequest.getRequestType().name());
				String transId=webServiceUtils.getTransactionId();
				msgTypSOAPElement.addTextNode(transId);
				messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);
			}else if(jaxbElement.getValue() instanceof PaymentSearchRequest){
				PaymentSearchRequest req=(PaymentSearchRequest) jaxbElement.getValue();
				
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getBillingAccount().getBillingAccountNumber());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, "PaymentSearchORCC");
				srvcNameSOAPElement.addTextNode("PaymentSearchORCC");
				operNameSOAPElement.addTextNode("PaymentSearch");
				String transId=webServiceUtils.getTransactionId();
				msgTypSOAPElement.addTextNode(transId);
				messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);
			}else if(jaxbElement.getValue() instanceof PaymentServiceRequest){
				PaymentServiceRequest req=(PaymentServiceRequest) jaxbElement.getValue();
				
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getBillingAccount().getBillingAccountNumber());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, "PaymentServiceORCC");
				srvcNameSOAPElement.addTextNode("PaymentServiceORCC");
				operNameSOAPElement.addTextNode("PaymentService");
				String transId=webServiceUtils.getTransactionId();
				msgTypSOAPElement.addTextNode(transId);
				messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);
			}else if(jaxbElement.getValue() instanceof OtpCancelStgPaymentRequest){   
				OtpCancelStgPaymentRequest req=(OtpCancelStgPaymentRequest) jaxbElement.getValue();
				
				messageContext.setProperty(WS_CONTEXT_LOG_ID, req.getConfirmationNumber());
				messageContext.setProperty(WS_CONTEXT_OPERATION_NAME, "CancelPaymentORCC");
				srvcNameSOAPElement.addTextNode("CancelPaymentORCC");
				operNameSOAPElement.addTextNode("CancelPayment");
				String transId=webServiceUtils.getTransactionId();
				msgTypSOAPElement.addTextNode(transId);
				messageContext.setProperty(WS_CONTEXT_TRANS_ID, transId);
			}

		} catch (javax.xml.soap.SOAPException e)
		{
			LOGGER.error("SOAP Exception in ACIContextInterceptor  handleRequest method  -->");
		} catch (Exception e)
		{
			LOGGER.error("Exception in ACIContextInterceptor");
		}
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext)
	{
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext)
	{
		return true;
	}
	
}
