/**
* AciServiceConstants.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


public interface AciServiceConstants {
	String HEADER_ACCEPT = "Accept=*/*";
	String APPLICATION_TYPE_JSON = "application/json";
	String APPLICATION_TYPE_XML = "application/xml";
	String APP_PRODUCE_TYPE_1 = "application/json; charset=UTF-8";
	String APP_PRODUCE_TYPE_2 = "text/html;charset=UTF-8";
	String DEF_DIV_CODE = "ICAF";
	String BRAND = "brand";
	String PAYMENT_DATE = "paymentDate";
	String TOTAL_AMOUNT = "totalPayment";
	String CUSTOMER_NUMBER = "customerNumber";
	String LINK_TO_EMAIL = "toEmailAddress";
	String MAIL_FROM = "noreply@anthem.com";
	int NINE = 9;
	String MAIL_SUBJECT_LINK_NEW_TEMP_ID = "New Linked Account - Confirmation";
	String MAIL_TYPE = "Application";
	String MAIL_PROPERTY_FILE_LOCATION = "/emailBrandDetails.properties";
	String BRAND_NAME = "brandName";
	String BRAND_URL = "brandUrl";
	String MESSAGE_CENTER_URL = "messageCenterUrl";
	String FOOTER_CONTENT = "footerContent";
	String BRAND_NAME_US = "brandname_";
	String BRAND_URL_US = "url_";
	String MESSAGE_CENTER_URL_US = "messagecentreurl_";
	String FOOTER_CONTENT_US = "footercontent_";
	String MIME_TYPE_RELATED = "related";
	String HEADER_LOGO = "headerLogo";
	String FACEBOOK_LOGO = "facebookLogo";
	String TWITTER_LOGO = "twitterLogo";
	String YOUTUBE_LOGO = "youtubeLogo";
	String LINKEDIN_LOGO = "linkedInLogo";
	String ALLOW_BUTTON_LOGO = "allowButtonLogo";
	String DENY_BUTTON_LOGO = "denyButtonLogo";
	String FOOTER_LOGO = "footerLogo";
	String EMAIL_IMAGES = "/emailImages/";
	String UNDERSCORE = "_";
	String PNG = ".png";
	String CONTENT_ID = "Content-ID";
	String ACI_PAYMENT_SEARCH_DATE_FORMAT = "yyyy-MM-dd";
	int PPORT_HCID_LENGTH = 9;
	int PPORT_SBN_LENGTH = 6;
	String WS_CONTEXT_LOG_ID = "WS_CONTEXT_LOG_ID";
	String WS_CONTEXT_REQ_SYS = "WS_CONTEXT_REQ_SYS";
	String WS_CONTEXT_OPERATION_NAME = "WS_CONTEXT_OPERATION";
	String WS_CONTEXT_TRANS_ID = "WS_CONTEXT_TRANS_ID";
	int STALE_CONNECTION_MAX_RETRY_COUNT=3;
	
	String TECHINICAL_ERROR_MSG = "We've encountered a technical error";

	String TPT_FUNDINGACCOUNT = "aci.setting.service.logging.fundingaccount";
	String TPT_FUNDINGADMIN = "aci.setting.service.logging.fundingadmin";
	String TPT_PAYMENTSEARCH = "aci.setting.service.logging.paymentsearch";
	String TPT_PAYMENTSERVICE = "aci.setting.service.logging.paymentservice";
	String TPT_CANCELPAYMENT = "aci.setting.service.logging.cancelpayment";
	
	String TPT_ACI_ERROR_LOGGING_STATUS = "memberpay.setting.service.logging.aci.error.logging.status";

	String ACI_RS_XML_LOG_STATUS  = "aci.setting.rs.log.req.res.xml";
	String ACI_TPT_XML_LOG_STATUS  = "aci.setting.tpt.log.req.res.xml";
		
	String[] ACI_SUCCESS_CODE={"0","1075","1020"};
	String ACI_SUCCESS_MSG="Success";
	String ACI_FAILURE_MSG="Failed";
	
	
	String RS_GET_ACI_PM  = "aci.setting.rest.endpoint.logging.manageAciPaymentMethod";
	String RS_SEARCH_ACI  = "aci.setting.rest.endpoint.logging.searchAciPayment";
	String RS_SUBMIT_ACI  = "aci.setting.rest.endpoint.logging.submitAciPayment";
	String RS_CANCEL_ACI  = "aci.setting.rest.endpoint.logging.cancelAciPayment";
	
	
	String HYSTRIX_APP_NAME="PPORT";
	String HYSTRIX_PM_FUNDINGACCOUNT_COMMAND="PM-ACI-FUNDACCOUNT";
	String HYSTRIX_PM_SUBMITPAYMENT_COMMAND="PM-ACI-SUBMITPAY";
	String HYSTRIX_PM_CANCELPAYMENT_COMMAND="PM-ACI-CANCELPAY";
	String HYSTRIX_PM_FUNDINGADMIN_COMMAND="PM-ACI-FUNDADMIN";
	String HYSTRIX_ACTSUM_PAYMENTSEARCH_COMMAND="ACTSUM-ACI-PAYMENTSEARCH";
	
	String EMPPAY_SENDERAPP="EMPPAY";
	
	String SENDER_KEY="SENDERAPP-";
	String DEF_SENDER_APP="EPORT";
	String DEF_REMIT_FEE="0.00";
	String ZERO_REMIT_VALUE="0";
	String EMPTY_USER_GROUP_ID="UserId/GroupId is missing in the request";
	String EMPTY_TOKEN_ID="TokenId is missing in the request";
	String BANK_ACCOUNT_INVALID="Bank Account Details invalid";
	int ROUTING_NO_LEN=9;
	String EMP_PAYMENT_SUCCESS_TEMPLATE = "/emailTemplate/employerPaymentProcessed.vm";
	String EMP_PAYMENT_FAILED_TEMPLATE = "/emailTemplate/employerPaymentReturned.vm";
	String EMP_PAYMENT_SUCCESS_SUBJECT = "Thanks for your payment";
	String EMP_PAYMENT_FAILED_SUBJECT = "There is an issue with your payment";
	String EMP_PAYMENT_SUCCESS_TEMPLATE_ID = "Payment Successful";
	String EMP_PAYMENT_FAILED_TEMPLATE_ID = "Payment Failed";
	
	String DEF_EMP_BRAND = "ABCBSHK";
	
	String EMP_PAYMENT_SUCCESS = "Success";
	String EMP_PAYMENT_FAILED = "Failed";
	
	String DATE_FORMAT_yyyyMMdd="yyyy-MM-dd";
	String DATE_FORMAT_MMddyyyy="MM/dd/yyyy";
	String EMPTY_STRING="";
	
	//Added By Cognizant for MedSupp June 2018 release - Start
	String MEDSUPP_RS_GET_ACI_PM  = "medsupp.aci.setting.rest.endpoint.logging.manageAciPaymentMethod";
	String MEDSUPP_RS_SEARCH_ACI  = "medsupp.aci.setting.rest.endpoint.logging.searchAciPayment";
	String MEDSUPP_RS_SUBMIT_ACI  = "medsupp.aci.setting.rest.endpoint.logging.submitAciPayment";
	String MEDSUPP_RS_CANCEL_ACI  = "medsupp.aci.setting.rest.endpoint.logging.cancelAciPayment";
	//Added By Cognizant for MedSupp June 2018 release - End
}

