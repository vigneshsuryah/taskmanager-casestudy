/**
* MCPSocketFactory.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MCPSocketFactory {

	public static SSLSocketFactory socketFactory = null;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MCPSocketFactory.class);
	
	public static SSLSocketFactory getSocketFactory()
	{
		if(socketFactory==null)
		{
			try
			{
				TrustAllCertsTrustManager test = new TrustAllCertsTrustManager();
				TrustManager[] trustManager = new TrustManager[] {test};
				SSLContext  sslContext = SSLContext.getInstance("TLS");
				sslContext.init(null, trustManager, null);
				socketFactory = sslContext.getSocketFactory();
			}
			catch(Exception ex)
			{
				LOGGER.error("Error Initializing Socket Factory:"+ex.getMessage());
			}
		}
		return socketFactory;
	}

	public static class TrustAllCertsTrustManager implements X509TrustManager {
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {   }

        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {   }
    }

}
