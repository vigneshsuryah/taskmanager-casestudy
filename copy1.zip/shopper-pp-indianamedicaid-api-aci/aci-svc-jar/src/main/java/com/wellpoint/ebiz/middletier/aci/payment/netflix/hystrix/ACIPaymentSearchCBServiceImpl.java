package com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix;

import org.apache.log4j.Logger;

import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceResponse;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.hystrix.service.CircuitBreakerService;
/**PP-173 New class */
public class ACIPaymentSearchCBServiceImpl implements CircuitBreakerService{

	private static final Logger LOGGER = Logger.getLogger(ACIPaymentSearchCBServiceImpl.class);
	
	private PaymentSearchServiceRequest request;
	private AciGateway memberPayGateway;
	private String requestingSystem;
	
	
	public ACIPaymentSearchCBServiceImpl(
			PaymentSearchServiceRequest request,
			AciGateway memberPayGateway, String requestingSystem) {
		this.request = request;
		this.memberPayGateway = memberPayGateway;
		this.requestingSystem = requestingSystem;
	}

	@Override
	public Object postSuccess() throws Exception {   
		LOGGER.info("ACI Payment Search:postSuccess is invoked");      
		 try {
			return memberPayGateway.paymentSearch(request, requestingSystem);
		} catch (Exception e) {
			return new PaymentSearchServiceResponse();
		}
	}

	@Override
	public Object postFailure() throws Exception {
		LOGGER.error("ACI Payment Search:postFailure is invoked");     
		return new PaymentSearchServiceResponse();
	}

}
