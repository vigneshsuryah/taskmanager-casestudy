package com.wellpoint.ebiz.middletier.aci.payment.dao.service;

import com.wellpoint.aci.model.MemberTptServiceLog;

public interface AciTPTServicesLogDao {
	void saveTptServicesLog(MemberTptServiceLog logData);
}
