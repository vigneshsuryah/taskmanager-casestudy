package com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix;

import java.util.concurrent.Future;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.AsyncResult;

import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceResponse;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.hystrix.service.CircuitBreakerService;

public class PaymentMethodsSubmitPaymentServiceImpl implements CircuitBreakerService{

	private static final Logger LOGGER = Logger.getLogger(PaymentMethodsSubmitPaymentServiceImpl.class);
	
	private PaymentServiceServiceRequest request;
	private AciGateway memberPayGateway;
	private String requestingSystem;
	
	public PaymentMethodsSubmitPaymentServiceImpl(PaymentServiceServiceRequest request, AciGateway memberPayGateway, String requestingSystem) {
		this.request = request;
		this.memberPayGateway = memberPayGateway;
		this.requestingSystem = requestingSystem;
	}	
	
	@Override
	public Object postSuccess() throws Exception {
		LOGGER.info("PMCancelPay-ACI:postSuccess is invoked");
		try {
			Future<PaymentServiceServiceResponse> response = memberPayGateway.paymentService(request, requestingSystem);
			return response;
		} catch (Exception e) {
			return new AsyncResult<PaymentServiceServiceResponse>(new PaymentServiceServiceResponse());
		}
	}

	@Override
	public Object postFailure() throws Exception {
		LOGGER.error("PMCancelPay-ACI:postFailure is invoked");
		return new AsyncResult<PaymentServiceServiceResponse>(new PaymentServiceServiceResponse());
	}

}
