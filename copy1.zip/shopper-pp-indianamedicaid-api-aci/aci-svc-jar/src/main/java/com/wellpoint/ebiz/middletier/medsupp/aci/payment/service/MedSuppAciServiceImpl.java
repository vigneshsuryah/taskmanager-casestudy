/**
 * MedSuppAciServiceImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.ebiz.middletier.medsupp.aci.payment.service;

import java.util.Calendar;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.model.RSTransLog;
import com.wellpoint.aci.model.TPTServicesLog;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.request.MemberPayLoggingRequest;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.MemberPayLoggingResponse;
import com.wellpoint.aci.response.Message;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciHelperUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;
import com.wellpoint.ebiz.middletier.medsupp.aci.payment.dao.service.MedSuppAciDaoService;


@Component
public class MedSuppAciServiceImpl implements MedSuppAciService, AciServiceConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(MedSuppAciServiceImpl.class);
	
	@Autowired
	private AciGateway aciGateway;
	
	@Autowired
	private AciHelperUtils aciHelperUtils;
	
	@Autowired
	private MedSuppAciDaoService medSuppAciDaoServiceImpl;
	
	@Autowired
	private ServiceUtil serviceUtil;
	
	private AciException prepareGracefulMessage(AciException exception){		
		String errorMessage = exception.getErrorMessage();
		if(EMPTY_USER_GROUP_ID.equals(errorMessage)||EMPTY_TOKEN_ID.equals(errorMessage)||BANK_ACCOUNT_INVALID.equals(errorMessage)){
			exception.setErrorCode(exception.getErrorCode());
			exception.setErrorMessage(errorMessage);
			exception.setErrorType("I");
		}else{
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
		}
		return exception;
	}

	@Override
	public AciFundingResponse manageAciPaymentMethod(AciFundingRequest request)
			throws AciException {
		AciFundingResponse response = new AciFundingResponse();
		try {
			response = aciGateway.manageAciPaymentMethod(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public AciPaymentSearchResponse searchAciPayment(
			AciPaymentSearchRequest request) throws AciException {	
		AciPaymentSearchResponse response = new AciPaymentSearchResponse();
		try {
			response= aciHelperUtils.searchForPayments(request);
		}catch (AciException e) {
			AciException exception = (AciException) e;
			response.setAciException(prepareGracefulMessage(exception));
			Message message = new Message();
			message.setMessageText(e.getMessage());
			response.setMessage(message);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public AciPaymentResponse submitAciPayment(
			AciPaymentRequest request) throws AciException {		
		AciPaymentResponse response = new AciPaymentResponse();
		try {
			response = aciGateway.submitAciPayment(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
		
	}

	@Override
	public AciCancelResponse cancelAciPayment(AciCancelRequest request)
			throws AciException {
		AciCancelResponse response = new AciCancelResponse();
		try {
			response = aciHelperUtils.cancelAciPayment(request);
		} catch (Exception e) {
			AciException exception = new AciException();
			exception.setErrorMessage(TECHINICAL_ERROR_MSG);
			exception.setErrorType("E");
			exception.setErrorCode("PP9000");
			exception.setReturnStatus(500);
			response.setAciException(exception);
		}
		return response;
	}
	
	@Override
	public void saveRSServiceLog(RSTransLog rSTransLog) throws AciException {
		LOGGER.info("Inside memberPayLogging() of MemberPaymentServiceImpl");
		try {
			if(null != rSTransLog && serviceUtil.checkMedSuppRSLoggingStatus(rSTransLog.getOperationName())) {
				medSuppAciDaoServiceImpl.saveRSServiceLog(rSTransLog);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in MedSuppAciServiceImpl saveRSServiceLog :"+e);
			//throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
		}
	}
	
	@Override
	public Future<MemberPayLoggingResponse> saveTPTLog(MemberPayLoggingRequest request) throws AciException {
		MemberPayLoggingResponse response = new MemberPayLoggingResponse(); 
	    Calendar calendar= Calendar.getInstance();
	    TPTServicesLog tPTServicesLog= new TPTServicesLog();	
		MemberPayTransLog memberPayTransLog = request.getMemberpayTransLog();
		tPTServicesLog.setOperationName(memberPayTransLog.getOperationName());
		tPTServicesLog.setRequestXml(memberPayTransLog.getRequestXML());
		tPTServicesLog.setResponseXml(memberPayTransLog.getResponseXML());
		tPTServicesLog.setCreateId(request.getHcid());
		tPTServicesLog.setRequestTs(memberPayTransLog.getRequestTime());
		tPTServicesLog.setResponseTs(calendar.getTime());
		tPTServicesLog.setHcid(request.getHcid()); 
		tPTServicesLog.setIsBusinessFault(memberPayTransLog.isBusinesssFault()?"Y":null);
		tPTServicesLog.setIsSystemFault(memberPayTransLog.isSystemFault()?"Y":null);
		//tPTServicesLog.setRequestingSystem(serviceUtil.getRequestorSystem());
		tPTServicesLog.setRequestingSystem(request.getRequestingSystem());
		aciGateway.saveMedSuppMemTptLog(tPTServicesLog);
		return new AsyncResult<MemberPayLoggingResponse>(response);
	}
	
}