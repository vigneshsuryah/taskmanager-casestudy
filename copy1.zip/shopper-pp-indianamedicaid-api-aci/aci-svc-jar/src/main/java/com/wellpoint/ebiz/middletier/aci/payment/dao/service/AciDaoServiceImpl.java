/**
* AciDaoServiceImpl.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.dao.service;


import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.List;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ibm.websphere.ce.cm.StaleConnectionException;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayEmailLogging;
import com.wellpoint.aci.model.MemberPaySubmitPayment;
import com.wellpoint.aci.model.MemberPayTransLog;
import com.wellpoint.aci.model.MemberTptServiceLog;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciUtils;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ApplicationContextProvider;
import com.wellpoint.ebiz.middletier.aci.payment.utility.MemberDetails;
import com.wellpoint.ebiz.middletier.aci.payment.utility.MemberRestServiceLog;
import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;


@Component
public class AciDaoServiceImpl implements AciDaoService, AciServiceConstants
{

	private static final Logger LOGGER = LoggerFactory.getLogger(AciDaoServiceImpl.class);

	@Autowired
	private ServiceUtil serviceUtil;
	
	@Autowired
	private AciTPTServicesLogDaoImpl aciTPTServicesLogDao;
	
	@Autowired
	private Mapper dozerMapper;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ApplicationContextProvider applicationContextProvider;
	
	@Value("${aci.setting.spring.integration.tpt.logging.flag}")
	private boolean tptLoggingFlag;
		
	private final String insertEmailLog = "INSERT INTO GBD.GBD_EMAIL_LOGGING (" + "	HCID, "
	+ "	FROM_ID, " + "	TO_ID, " + "	SUBJECT, " + "	TEMPLATE_ID, " + "	SENT_DATE, " + "	DYNAMIC_CONTENT, "
	+ "	MAIL_TYPE, " + "	CREATED_BY, " + "	CREATED_DATE, " + "	REQUESTING_SYSTEM) "
	+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private final String insertRsLog = "INSERT INTO GBD.GBD_MEMBER_RS_LOGS (" + "	HCID, " + "	CHANNEL, " + "	OPERATION_NAME, "
			+ "	REQUEST_XML, " + "	RESPONSE_XML, " + "	ERROR_MSG, " + "	CREATED_DATE, " + "	REQUESTING_SYSTEM," + " REQUEST_TS, " + "RESPONSE_TS) " + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private final String insertPaymentDetailsTbl = "INSERT INTO GBD.GBD_PAYMENT_DETAILS (PAYMENT_HCID, SUBMITTED_HCID, PAYMENT_CONFIRM_NO, PAYMENT_STATUS, SUB_GROUP_ID, TOKEN_ID, PAYMENT_TYPE, PAYMENT_DATE, PAID_AMOUNT, CREATED_DATE, CREATED_BY, STATE_VAL, ERROR_REASON, REQUESTING_SYSTEM) "
		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private final String[] MEMBER_SUMBITPAYMENT ={"cancelAciPayment","manageAciPaymentMethod","searchAciPayment","submitAciPayment"};
	
	private String MAM_TABLE_LKUP = "SELECT MPL.MAM_TABLE_NAME FROM GBD.GBD_MAM_LD_LOOKUP MPL WHERE MPL.SYSTEM_POINTING = ? WITH UR";
	//Veracode Fix Start - End 06/05/2017 getDivisionCode is removed
	@Override
	public void memberPayLogging(MemberPayTransLog memberpayTransLog,String requestingSystem) throws AciException
	{
		LOGGER.info("Inside memberPayLogging of MPDSI");
		if(null != memberpayTransLog && serviceUtil.checkRSLoggingStatus(memberpayTransLog.getOperationName()))
		{
			boolean attemptRetry = false;
			int retryCount = 1;
			MemberRestServiceLog memberTransLog = dozerMapper.map(memberpayTransLog, MemberRestServiceLog.class);
			MemberDetails member = new MemberDetails();
			member.setHcid(memberpayTransLog.getHcid());
			memberTransLog.setMemberDetails(member);
			do
			{
				try
				{
					String rsLogReqResStatus = serviceUtil.getValueByArchaius(ACI_RS_XML_LOG_STATUS);
					String requestXML = memberTransLog.getRequestXML();
					String responseXML = memberTransLog.getResponseXML();
					
					if(AciUtils.checkNullForAString(memberpayTransLog.getOperationName()) && Arrays.asList(MEMBER_SUMBITPAYMENT).contains((memberpayTransLog.getOperationName()))){						
						requestXML=memberTransLog.getRequestXML()!=null?ServiceUtil.getEncodedText(memberTransLog.getRequestXML()):memberTransLog.getRequestXML();
						responseXML=memberTransLog.getResponseXML()!=null?ServiceUtil.getEncodedText(memberTransLog.getResponseXML()):memberTransLog.getResponseXML();
					}
					
					if(rsLogReqResStatus == null || !rsLogReqResStatus.equalsIgnoreCase("Y"))
					{
						requestXML = "";
						responseXML = "";
					}
					Object[] params = new Object[] { memberTransLog.getMemberDetails().getHcid(), memberTransLog.getChannel(),
							memberTransLog.getOperationName(), requestXML, responseXML,
							memberTransLog.getErrorMsg(), memberTransLog.getCreatedDate(), requestingSystem, memberTransLog.getStartTime(),
							memberTransLog.getEndTime()};
	
					int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
							Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP };
					String jdbcTemplateName = requestingSystem.toLowerCase()+"JdbcTemplate";
					if(null != applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName)){
						jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName);
					}else{
						jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean("jdbcTemplate");
					}
					int i = jdbcTemplate.update(insertRsLog, params, types);
					LOGGER.debug("Inserted the record inside RS logs : " + i);
					attemptRetry = false;  
				} catch (Exception e)
				{
					if (e instanceof StaleConnectionException && retryCount <= STALE_CONNECTION_MAX_RETRY_COUNT)
					{
						attemptRetry = true;
						retryCount++;
					}
					else
					{
						LOGGER.error("Exception in memberPayLogging : " + e);
					}
	
				}
			} while (attemptRetry);
		}
		LOGGER.info("End of memberPayLogging of MPDSI");
	}

	
	@Override
	public void insertPaymentDetailsTable(final List<MemberPaySubmitPayment> loggingList,String requestingSystem) throws AciException
	{
		boolean attemptRetry = false;
		int retryCount = 1;
		LOGGER.debug("Inside insertPaymentDetailsTable method");
		do
		{
			try
			{
				final java.util.Date today = new java.util.Date();
	            final java.sql.Date currentDate = new java.sql.Date(today.getTime());
	            String jdbcTemplateName = requestingSystem.toLowerCase()+"JdbcTemplate";
				if(null != applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName)){
					jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName);
				}else{
					jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean("jdbcTemplate");
				}
				int[] insertResult = jdbcTemplate.batchUpdate(insertPaymentDetailsTbl,
                        new BatchPreparedStatementSetter() {

                              @Override
                              public int getBatchSize() {
                                    return loggingList.size();
                              }

                              @Override
                              public void setValues(PreparedStatement pst, final int i) throws SQLException {
                                    final MemberPaySubmitPayment loggingItem = loggingList.get(i);
                                    pst.setString(1, loggingItem.getPaymentHcid());
                                    pst.setString(2, loggingItem.getSubmittedHcid());
                                    pst.setString(3, loggingItem.getConfirmationNumber());
                                    pst.setString(4, loggingItem.getStatus());
                                    pst.setString(5, loggingItem.getSubGroupId());
                                    pst.setString(6, loggingItem.getTokenId());
                                    if(loggingItem.getPaymentType() != null)
                                    {
                                    	pst.setString(7, loggingItem.getPaymentType().name());
                                    }else
                                    {
                                    	pst.setString(7, "");
                                    }
                                    pst.setString(8, loggingItem.getPaymentDate());
                                    pst.setString(9, loggingItem.getPaymentAmount());
                                    pst.setDate(10, currentDate);
                                    pst.setString(11, loggingItem.getSubmittedHcid());
                                    pst.setString(12, loggingItem.getState());
                                    pst.setString(13, serviceUtil.getErrorReason(loggingItem.getMessage()));
                                    pst.setString(14, loggingItem.getRequestingSystem());
                              }
                        });
				attemptRetry = false;
				LOGGER.debug("Inserted the record inside insertPaymentDetailsTable : " + insertResult);
				
			} catch (Exception e)
			{
				if (e instanceof StaleConnectionException && retryCount <= STALE_CONNECTION_MAX_RETRY_COUNT)
				{
					attemptRetry = true;
					retryCount++;
				}
				else
				{
					LOGGER.error("Exception in insertPaymentDetailsTable : " + e);
				}

			}
		} while (attemptRetry);
	}
	
	@Override
	public boolean saveEmailLog(MemberPayEmailLogging memberpayEmailLogging,String requestingSystem) throws AciException
	{
		boolean attemptRetry = false;  
		int retryCount = 1;
		do
		{
			try
			{
				Object[] params = new Object[] { memberpayEmailLogging.getHcid(), memberpayEmailLogging.getFrom(), memberpayEmailLogging.getTo(),
						memberpayEmailLogging.getSubject(), memberpayEmailLogging.getTemplateId(), memberpayEmailLogging.getSentDate(), 
						memberpayEmailLogging.getDynamicContent(), memberpayEmailLogging.getMailType(), memberpayEmailLogging.getCreatedBy(), 
						memberpayEmailLogging.getCreatedDate(), serviceUtil.getRequestorSystem()};

				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR,
						Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR};
				String jdbcTemplateName = requestingSystem.toLowerCase()+"JdbcTemplate";
				if(null != applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName)){
					jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName);
				}else{
					jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean("jdbcTemplate");
				}
				jdbcTemplate.update(insertEmailLog, params, types);
				attemptRetry = false;
			} catch (Exception e)
			{
				if (e instanceof StaleConnectionException && retryCount <= STALE_CONNECTION_MAX_RETRY_COUNT)
				{
					attemptRetry = true;
					retryCount++;
				}
				else
				{
					LOGGER.error("Exception in saveEmailLog : " + e);
				}

			}

		} while (attemptRetry);

		return true;
	}

	
	public String getMamLookUpValueForWebApplication() throws AciException
	{
		String tableName = "";
		List<String> tableNameList = null;
		boolean attemptRetry = false;
		int retryCount = 1;
		do
		{
			try
			{
				jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean("jdbcTemplate");
				tableNameList  = jdbcTemplate.queryForList(MAM_TABLE_LKUP, new Object[] { "WEBAPPLICATION" }, String.class);
						
				if (tableNameList != null) {
			    	tableName = tableNameList.get(0);
			    }
				attemptRetry = false;
			} catch (Exception e)
			{
				if (e instanceof StaleConnectionException && retryCount <= STALE_CONNECTION_MAX_RETRY_COUNT)
				{
					attemptRetry = true;
					retryCount++;
				}
				else
				{
					throw new AciException(e, "Error in fetching getMamLookUpValueForWebApplication");
				}

			}

		} while (attemptRetry);
		
		return tableName;
	}
	
	@Override
	public int saveTPTServiceLog(MemberTptServiceLog memberTptServiceLog) throws AciException
	{
		int row = 0;
		if(null != memberTptServiceLog && tptLoggingFlag)
		{
			if(serviceUtil.checkTPTLoggingStatus(memberTptServiceLog.getOperationName()) ||
					serviceUtil.checkFailedORCCTransactions(memberTptServiceLog.getOperationName(), memberTptServiceLog.getResponseXML())){
				boolean attemptRetry = false;
				int retryCount = 1;
				do
				{
					try
					{
						String tptLogReqResStatus = serviceUtil.getValueByArchaius(ACI_TPT_XML_LOG_STATUS);
						String requestXML = ServiceUtil.encodeRequestORCC(memberTptServiceLog.getOperationName(), memberTptServiceLog.getRequestXML());
						String responseXML = memberTptServiceLog.getResponseXML();
						if(tptLogReqResStatus == null || !tptLogReqResStatus.equalsIgnoreCase("Y"))
						{
							requestXML = "";
							responseXML = "";
						}
						memberTptServiceLog.setRequestXML(requestXML);
						memberTptServiceLog.setResponseXML(responseXML);
						aciTPTServicesLogDao.saveTptServicesLog(memberTptServiceLog);
						
//						Object[] params = new Object[] { memberTptServiceLog.getOutGoingReqId(), memberTptServiceLog.getOperationName(),
//								requestXML, responseXML, memberTptServiceLog.getRequestTimeStamp(), memberTptServiceLog.getResponseTimeStamp(),
//								memberTptServiceLog.getBusinessFault(), memberTptServiceLog.getSystemFault(), memberTptServiceLog.getUpdatedId(),
//								memberTptServiceLog.getUpdatedDate(), memberTptServiceLog.getCreatedId(), memberTptServiceLog.getCreatedDate(), serviceUtil.getRequestorSystem() };
//		
//						int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP,
//								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR };
//						String requestingSystem = threadAttribute.getThreadAttrs().get("SENDERAPP-"+memberTptServiceLog.getOutGoingReqId());
//						String jdbcTemplateName = requestingSystem.toLowerCase()+"JdbcTemplate";
//						if(null != applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName)){
//							jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean(jdbcTemplateName);
//						}else{
//							jdbcTemplate  = (JdbcTemplate) applicationContextProvider.getApplicationContext().getBean("jdbcTemplate");
//						}
//						row = jdbcTemplate.update(insertTptLog, params, types);
						attemptRetry = false;
					} catch (Exception e)
					{
						if (e instanceof StaleConnectionException && retryCount <= STALE_CONNECTION_MAX_RETRY_COUNT)
						{
							attemptRetry = true;
							retryCount++;
						}
						else
						{
							LOGGER.error("Exception in saveTPTServiceLog : " + e);
						}
		
					}
		
				} while (attemptRetry);
			}
		}
		return row;
	}

}
