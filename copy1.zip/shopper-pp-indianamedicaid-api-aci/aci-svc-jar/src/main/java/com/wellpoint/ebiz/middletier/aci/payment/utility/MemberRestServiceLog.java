/**
* MemberRestServiceLog.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MemberRestServiceLog implements Serializable
{
	private static final long serialVersionUID = -1472182988392133478L;
	private BigDecimal rsTransId;
	private MemberDetails memberDetails;
	private String channel;
	private String operationName;
	private String requestXML;
	private String responseXML;
	private String errorMsg;
	private Date createdDate;
	private Date startTime;
	private Date endTime;
	public BigDecimal getRsTransId()
	{
		return rsTransId;
	}
	public void setRsTransId(BigDecimal rsTransId)
	{
		this.rsTransId = rsTransId;
	}
	public MemberDetails getMemberDetails()
	{
		return memberDetails;
	}
	public void setMemberDetails(MemberDetails memberDetails)
	{
		this.memberDetails = memberDetails;
	}
	public String getChannel()
	{
		return channel;
	}
	public void setChannel(String channel)
	{
		this.channel = channel;
	}
	public String getOperationName()
	{
		return operationName;
	}
	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}
	public String getRequestXML()
	{
		return requestXML;
	}
	public void setRequestXML(String requestXML)
	{
		this.requestXML = requestXML;
	}
	public String getResponseXML()
	{
		return responseXML;
	}
	public void setResponseXML(String responseXML)
	{
		this.responseXML = responseXML;
	}
	public String getErrorMsg()
	{
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}
	public Date getCreatedDate()
	{
		return createdDate;
	}
	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}
	public Date getStartTime()
	{
		return startTime;
	}
	public void setStartTime(Date startTime)
	{
		this.startTime = startTime;
	}
	public Date getEndTime()
	{
		return endTime;
	}
	public void setEndTime(Date endTime)
	{
		this.endTime = endTime;
	}

}
