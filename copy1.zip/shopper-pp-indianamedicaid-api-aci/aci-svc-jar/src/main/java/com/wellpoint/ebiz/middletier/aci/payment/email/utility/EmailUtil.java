/**
* EmailUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.email.utility;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayEmailLogging;
import com.wellpoint.ebiz.middletier.aci.payment.dao.service.AciDaoService;
import com.wellpoint.ebiz.middletier.aci.payment.utility.AciServiceConstants;


@Component
public class EmailUtil implements AciServiceConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtil.class);
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private VelocityEngine velocityEngine;
	@Autowired
	private AciDaoService memberPaymentDaoServiceImpl;
	private String emailContent;

	public JavaMailSender getMailSender()
	{
		return mailSender;
	}

	public void setMailSender(JavaMailSender mailSender)
	{
		this.mailSender = mailSender;
	}

	public VelocityEngine getVelocityEngine()
	{
		return velocityEngine;
	}

	public void setVelocityEngine(VelocityEngine velocityEngine)
	{
		this.velocityEngine = velocityEngine;
	}

	public void sendMail(Mail mail, Map<String, Object> model,String requestingSystem) throws AciException
	{
		LOGGER.info("Start sendMail() of EmailUtil");
		try{
			sendConfirmationEmail(mail, model);
		}catch(Exception e){
			LOGGER.error("Exception occured in sendMail() of EmailUtil "+e.getMessage());
			throw new AciException("I","PP9013","You're trying to link to an account that doesn't have a working email address. " +
			"That member needs to update their email address before you can link accounts.",400);
		}
	    try{
	    	logEmail(mail,requestingSystem);
	    	LOGGER.info("End sendMail() of EmailUtil");
	    }catch (Exception e) {
	    	LOGGER.error("Exception occured in logging the mail "+e.getMessage());
			throw new AciException("E","PP9000",TECHINICAL_ERROR_MSG,500);
	    }
	} 

	private void logEmail(Mail mail,String requestingSystem) throws AciException
	{
		LOGGER.info("Start logEmail() of EmailUtil");
		MemberPayEmailLogging memberpayEmailLogging = new MemberPayEmailLogging();
		memberpayEmailLogging.setFrom(mail.getMailFrom());
		memberpayEmailLogging.setTo(mail.getMailTo());
		memberpayEmailLogging.setHcid(mail.getToHcid());
		memberpayEmailLogging.setSubject(mail.getMailSubject());
		memberpayEmailLogging.setTemplateId(mail.getTemplateId());
		memberpayEmailLogging.setSentDate(new Date());
		memberpayEmailLogging.setDynamicContent(emailContent);
		memberpayEmailLogging.setMailType(mail.getMailType());
		memberpayEmailLogging.setCreatedBy(mail.getCreatedBy());
		memberpayEmailLogging.setCreatedDate(new Date());
		memberPaymentDaoServiceImpl.saveEmailLog(memberpayEmailLogging,requestingSystem);
		LOGGER.info("End logEmail() of EmailUtil");
	}

	private void sendConfirmationEmail(final Mail mail, final Map<String, Object> model)
	{
		LOGGER.info("Start sendConfirmationEmail() of EmailUtil");
		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator()
		{
			private Properties properties = new Properties();
			private InputStream input = null;

			@Override
			public void prepare(MimeMessage mimeMessage) throws MessagingException, IOException, URISyntaxException
			{
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				String brand = (String) model.get(BRAND);
				input = new FileInputStream(this.getClass().getResource(MAIL_PROPERTY_FILE_LOCATION).getFile());
				properties.load(input);
				String brandName = properties.getProperty(BRAND_NAME_US + brand);
				message.setFrom(MAIL_FROM);
				message.setTo(mail.getMailTo());
				message.setSubject(mail.getMailSubject());
				model.put(BRAND_NAME, brandName);
				model.put(BRAND_URL, properties.getProperty(BRAND_URL_US + brand));
				model.put(MESSAGE_CENTER_URL, properties.getProperty(MESSAGE_CENTER_URL_US + brand));
				model.put(FOOTER_CONTENT, properties.getProperty(FOOTER_CONTENT_US + brand));

				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, mail.getTemplateLocation(), "UTF-8", model);
				/*PP-208 changes starts*/
				if(text != null && !text.isEmpty())
				{
					text = text.replace("<%@ page language='java' contentType='text/html; charset=ISO-8859-1' pageEncoding='ISO-8859-1'%>", "");
				}
				/*PP-208 changes ends*/
				BodyPart messageBodyPart = new MimeBodyPart();
				messageBodyPart.setContent(text, mail.getContentType()); 
				MimeMultipart multipart = new MimeMultipart(MIME_TYPE_RELATED);
				multipart.addBodyPart(messageBodyPart);
				// set signature,header logo,footer logo,footer content based on brand.
				attachImage(model, mimeMessage, multipart, HEADER_LOGO, brand);
				attachImage(model, mimeMessage, multipart, FACEBOOK_LOGO, null);
				attachImage(model, mimeMessage, multipart, TWITTER_LOGO, null);
				attachImage(model, mimeMessage, multipart, YOUTUBE_LOGO, null);
				attachImage(model, mimeMessage, multipart, LINKEDIN_LOGO, null);
				if (MAIL_SUBJECT_LINK_NEW_TEMP_ID.equalsIgnoreCase(mail.getTemplateId()))
				{
					attachImage(model, mimeMessage, multipart, ALLOW_BUTTON_LOGO, null);
					attachImage(model, mimeMessage, multipart, DENY_BUTTON_LOGO, null);
				}
				attachImage(model, mimeMessage, multipart, FOOTER_LOGO, brand);
				emailContent = text;
				LOGGER.info("End sendConfirmationEmail() of EmailUtil");
			}

			private void attachImage(final Map<String, Object> model, MimeMessage mimeMessage, MimeMultipart multipart, String image,
					String brand) throws IOException, MessagingException
			{

				LOGGER.info("Start attachImage() of EmailUtil");
				MimeBodyPart imagePart = new MimeBodyPart();
				URL url;
				if (brand == null)
				{
					url = this.getClass().getResource(EMAIL_IMAGES + image + PNG);
				}
				else
				{
					url = this.getClass().getResource(EMAIL_IMAGES +  image +UNDERSCORE+brand + PNG);
				}
				String path = url.getPath();
				imagePart.attachFile(path);
				imagePart.setHeader(CONTENT_ID, image);
				imagePart.setDisposition(MimeBodyPart.INLINE);
				multipart.addBodyPart(imagePart);
				mimeMessage.setContent(multipart);
				LOGGER.info("End attachImage() of EmailUtil");
			}
		};
		this.mailSender.send(mimeMessagePreparator);
	}
}
