package com.wellpoint.ebiz.middletier.aci.payment.utility;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("threadAttribute")
@Scope(value=BeanDefinition.SCOPE_SINGLETON)
public class ThreadAttribute {
	 private Map<String, String> threadAttrs = new HashMap<String, String>();

	public Map<String, String> getThreadAttrs() {
		return threadAttrs;
	}

	public void setThreadAttrs(Map<String, String> threadAttrs) {
		this.threadAttrs = threadAttrs;
	} 

	    
}
