/**
* AciHelperUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 05/16/2017   1.1      Cognizant      Modified by Cognizant for TPP change July 2017 
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;
import org.dozer.Mapper;
import org.dozer.MappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.netflix.hystrix.HystrixCommand;
import com.wellpoint.aci.exception.AciException;
import com.wellpoint.aci.model.MemberPayPaymentTypeEnum;
import com.wellpoint.aci.model.MemberPaySubmitPayment;
import com.wellpoint.aci.payment.domain.orcc.BankAccount;
import com.wellpoint.aci.payment.domain.orcc.BillingAccount;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.CreditCardAccount;
import com.wellpoint.aci.payment.domain.orcc.CreditDebitIndicator;
import com.wellpoint.aci.payment.domain.orcc.EcommerceIndicator;
import com.wellpoint.aci.payment.domain.orcc.FlagField;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.MaintenanceIndicator;
import com.wellpoint.aci.payment.domain.orcc.NachaStandardEntryClass;
import com.wellpoint.aci.payment.domain.orcc.PaymentInfo;
import com.wellpoint.aci.payment.domain.orcc.PaymentRemitField;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.Remittance;
import com.wellpoint.aci.request.AciBaseRequest;
import com.wellpoint.aci.request.AciCancelRequest;
import com.wellpoint.aci.request.AciFundingRequest;
import com.wellpoint.aci.request.AciPayment;
import com.wellpoint.aci.request.AciPaymentRequest;
import com.wellpoint.aci.request.AciPaymentSearchRequest;
import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;
import com.wellpoint.aci.response.AciCancelResponse;
import com.wellpoint.aci.response.AciFundingResponse;
import com.wellpoint.aci.response.AciPaymentDetail;
import com.wellpoint.aci.response.AciPaymentResponse;
import com.wellpoint.aci.response.AciPaymentSearchResponse;
import com.wellpoint.aci.response.FundingAccount;
import com.wellpoint.aci.response.Message;
import com.wellpoint.aci.response.PaymentAckDetail;
import com.wellpoint.aci.response.RemittanceDetail;
import com.wellpoint.aci.response.ResponseMessage;
import com.wellpoint.ebiz.middletier.aci.payment.dao.service.AciDaoService;
import com.wellpoint.ebiz.middletier.aci.payment.email.utility.EmailUtil;
import com.wellpoint.ebiz.middletier.aci.payment.email.utility.Mail;
import com.wellpoint.ebiz.middletier.aci.payment.gateway.AciGateway;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.ACIPaymentSearchCBServiceImpl;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.HystrixUtils;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.PaymentMethodsCancelPaymentServiceImpl;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.PaymentMethodsFundingAccountServiceImpl;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.PaymentMethodsFundingAdminServiceImpl;
import com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix.PaymentMethodsSubmitPaymentServiceImpl;
import com.wellpoint.hystrix.service.CircuitBreakerCommand;


@Component("aciHelperUtils")
public class AciHelperUtils implements AciServiceConstants
{

	@Autowired
	private ServiceUtil serviceUtil;

	@Autowired
	private Mapper dozerMapper;

	@Autowired
	private AciGateway aciGateway;

	@Autowired
	private HystrixUtils hystrixUtils;

	@Autowired
	private EmailUtil emailUtil;

	@Autowired
	private AciDaoService aciDaoServiceImpl;
	private static final Logger LOGGER = LoggerFactory.getLogger(AciHelperUtils.class);

	/**
	 * 
	 * @param EmployerFundingRequest
	 *            request Creates a payment method add request
	 * @return FundingAdminServiceRequest
	 */
	public FundingAdminServiceRequest createPaymentMethodRequest(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->createPaymentMethodRequest");
		FundingAdminServiceRequest fundingAdminServiceRequest = getACIBaseRequest(request, MaintenanceIndicator.CREATE);
		fundingAdminServiceRequest.setBankAccount(getBankAccDetails(request));
		fundingAdminServiceRequest.setCreditCardAccount(getCreditCardDetails(request));
		LOGGER.info("Completed AciHelperUtils-->createPaymentMethodRequest");
		return fundingAdminServiceRequest;
	}

	public BankAccount getBankAccDetails(AciBaseRequest request) throws AciException
	{
		BankAccount bankAccountDetails = null;
		String nickName = " ";
		if (request instanceof AciFundingRequest){
			AciFundingRequest aciFundingRequest = (AciFundingRequest) request;
			if(null != aciFundingRequest.getBankAccountDetails())
			{
				bankAccountDetails = new BankAccount();
				dozerMapper.map(aciFundingRequest.getBankAccountDetails(), bankAccountDetails);
				if(null != aciFundingRequest.getBankAccountDetails().getAccountNickname() && !aciFundingRequest.getBankAccountDetails().getAccountNickname().isEmpty())
				{
					nickName = aciFundingRequest.getBankAccountDetails().getAccountNickname();
				}
				bankAccountDetails.setAccountNickname(nickName);
				bankAccountDetails.setAccountHolderName(trimCharByLength(bankAccountDetails.getAccountHolderName(), 40));
				bankAccountDetails.setAccountAddress1(trimCharByLength(bankAccountDetails.getAccountAddress1(), 40));
				bankAccountDetails.setAccountAddress2(trimCharByLength(bankAccountDetails.getAccountAddress2(), 20));
				bankAccountDetails.setAccountCity(trimCharByLength(bankAccountDetails.getAccountCity(), 20));
				bankAccountDetails.setAccountState(trimCharByLength(bankAccountDetails.getAccountState(), 2));
				bankAccountDetails.setAccountPostalCode(trimCharByLength(bankAccountDetails.getAccountPostalCode(), 5));
			}
		}else if (request instanceof AciPaymentRequest)
		{
			AciPaymentRequest aciPaymentRequest = (AciPaymentRequest) request;
			if(null != aciPaymentRequest.getBankAccountDetails())
			{
				bankAccountDetails = new BankAccount();
				dozerMapper.map(aciPaymentRequest.getBankAccountDetails(), bankAccountDetails);
				bankAccountDetails.setAccountHolderName(trimCharByLength(bankAccountDetails.getAccountHolderName(), 40));
				bankAccountDetails.setAccountAddress1(trimCharByLength(bankAccountDetails.getAccountAddress1(), 40));
				bankAccountDetails.setAccountAddress2(trimCharByLength(bankAccountDetails.getAccountAddress2(), 20));
				bankAccountDetails.setAccountCity(trimCharByLength(bankAccountDetails.getAccountCity(), 20));
				bankAccountDetails.setAccountState(trimCharByLength(bankAccountDetails.getAccountState(), 2));
				bankAccountDetails.setAccountPostalCode(trimCharByLength(bankAccountDetails.getAccountPostalCode(), 5));
			}
		}
		return bankAccountDetails;
	}

	public CreditCardAccount getCreditCardDetails(AciBaseRequest request) throws AciException{
		CreditCardAccount creditCardAccount = null;
		String nickName = " ";
		if (request instanceof AciFundingRequest){
			AciFundingRequest aciFundingRequest = (AciFundingRequest) request;
			if(null != aciFundingRequest.getCreditCardDetails()){
				creditCardAccount = new CreditCardAccount();
				dozerMapper.map(aciFundingRequest.getCreditCardDetails(), creditCardAccount);
				creditCardAccount.setCreditCardNumber(creditCardAccount.getCreditCardNumber());
				creditCardAccount.setExpirationMonth(creditCardAccount.getExpirationMonth());
				creditCardAccount.setExpirationYear(creditCardAccount.getExpirationYear());
				if(null != aciFundingRequest.getCreditCardDetails().getAccountNickname() && !aciFundingRequest.getCreditCardDetails().getAccountNickname().isEmpty())
				{
					nickName = aciFundingRequest.getCreditCardDetails().getAccountNickname();
				}
				creditCardAccount.setAccountNickname(nickName);
				creditCardAccount.setAccountHolderName(trimCharByLength(creditCardAccount.getAccountHolderName(), 40));
				creditCardAccount.setAccountAddress1(trimCharByLength(creditCardAccount.getAccountAddress1(), 40));
				creditCardAccount.setAccountAddress2(trimCharByLength(creditCardAccount.getAccountAddress2(), 20));
				creditCardAccount.setAccountCity(trimCharByLength(creditCardAccount.getAccountCity(), 20));
				creditCardAccount.setAccountState(trimCharByLength(creditCardAccount.getAccountState(), 2));
				creditCardAccount.setAccountPostalCode(trimCharByLength(creditCardAccount.getAccountPostalCode(), 5));
			}
		}else if (request instanceof AciPaymentRequest)
		{
			AciPaymentRequest aciPaymentRequest = (AciPaymentRequest) request;
			if(null != aciPaymentRequest.getCreditCardDetails()){
				creditCardAccount = new CreditCardAccount();
				dozerMapper.map(aciPaymentRequest.getCreditCardDetails(), creditCardAccount);
				creditCardAccount.setCreditCardNumber(creditCardAccount.getCreditCardNumber());
				creditCardAccount.setExpirationMonth(creditCardAccount.getExpirationMonth());
				creditCardAccount.setExpirationYear(creditCardAccount.getExpirationYear());
				creditCardAccount.setAccountNickname(creditCardAccount.getAccountNickname());
				creditCardAccount.setAccountHolderName(trimCharByLength(creditCardAccount.getAccountHolderName(), 40));
				creditCardAccount.setAccountAddress1(trimCharByLength(creditCardAccount.getAccountAddress1(), 40));
				creditCardAccount.setAccountAddress2(trimCharByLength(creditCardAccount.getAccountAddress2(), 20));
				creditCardAccount.setAccountCity(trimCharByLength(creditCardAccount.getAccountCity(), 20));
				creditCardAccount.setAccountState(trimCharByLength(creditCardAccount.getAccountState(), 2));
				creditCardAccount.setAccountPostalCode(trimCharByLength(creditCardAccount.getAccountPostalCode(), 5));				
			}
		}
		return creditCardAccount;

	}

	/**
	 * 
	 * @param valueToCheck
	 * @param length
	 * @return trimmed value by the length
	 */
	public String trimCharByLength(String valueToCheck, int length)
	{
		String value = EMPTY_STRING;
		if (valueToCheck != null && valueToCheck.length() > length)
		{
			value = valueToCheck.substring(0, length);
		}
		else
		{
			value = valueToCheck;
		}
		return value;
	}

	/**
	 * 
	 * @param AciFundingRequest
	 * @return AciFundingResponse after connecting to ACI service
	 * @throws AciException
	 */
	public AciFundingResponse createPaymentMethod(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->createPaymentMethod");
		AciFundingResponse response = null;
		try
		{
			FundingAdminServiceRequest fundingAdminServiceRequest = createPaymentMethodRequest(request);
			FundingAdminServiceResponse fundingAdminServiceResponse = invokeAciFundingAdmin(fundingAdminServiceRequest, request.getRequestingSystem());
			response = prepareApiResponse(fundingAdminServiceResponse, response);
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->createPaymentMethod");
		return response;
	}

	/**
	 * 
	 * @param fundingAdminServiceResponse
	 * @param response
	 * @return Mapped ACI response to the custom object
	 * @throws AciException
	 */
	private AciFundingResponse prepareApiResponse(FundingAdminServiceResponse fundingAdminServiceResponse,
			AciFundingResponse response) throws AciException
			{
		LOGGER.info("Inside AciHelperUtils-->prepareApiResponse");
		if (null != fundingAdminServiceResponse)
		{
			response = new AciFundingResponse();
			if (null != fundingAdminServiceResponse.getBankAccount())
			{
				BankAccountDetails bankAccountDetail = new BankAccountDetails();
				List<BankAccountDetails> bankAccountDetails = new ArrayList<BankAccountDetails>();
				dozerMapper.map(fundingAdminServiceResponse.getBankAccount(), bankAccountDetail);
				bankAccountDetail.setTokenId(fundingAdminServiceResponse.getFundingTokenId());
				bankAccountDetails.add(bankAccountDetail);
				response.setBankAccountDetails(bankAccountDetails);
			}else if(null != fundingAdminServiceResponse.getCreditCardAccount()){
				CreditCardDetails cardDetails = new CreditCardDetails();
				List<CreditCardDetails> creditCardDetails = new ArrayList<CreditCardDetails>();
				dozerMapper.map(fundingAdminServiceResponse.getCreditCardAccount(), cardDetails);
				cardDetails.setTokenId(fundingAdminServiceResponse.getFundingTokenId());
				creditCardDetails.add(cardDetails);
				response.setCreditCardDetails(creditCardDetails);
			}

			if (null != fundingAdminServiceResponse && null != fundingAdminServiceResponse.getMessage())
			{
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessageCode(String.valueOf(fundingAdminServiceResponse.getMessage().getMessageCode()));
				responseMessage.setMessageDesc(fundingAdminServiceResponse.getMessage().getMessageText());
				response.setResponseMessage(responseMessage);
				response.setAckStatus(Arrays.asList(ACI_SUCCESS_CODE).contains(responseMessage.getMessageCode()) ? ACI_SUCCESS_MSG
						: ACI_FAILURE_MSG);
			}
			else
			{
				response.setAckStatus(ACI_FAILURE_MSG);
			}
		}
		LOGGER.info("Completed AciHelperUtils-->prepareApiResponse");
		return response;
			}

	/**
	 * 
	 * @param request
	 * @return EmployerFundingResponse with summary of payment method returned by ACI service
	 * @throws AciException
	 */
	public AciFundingResponse getPaymentMethodSummary(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->getPaymentMethodSummary");
		AciFundingResponse response = new AciFundingResponse();
		try
		{
			FundingAccountRetrievalServiceRequest fundingAccountRetrievalServiceRequest = new FundingAccountRetrievalServiceRequest();
			BillingAccount billingAccount = new BillingAccount();
			billingAccount.setBillingAccountNumber(request.getHcid());
			billingAccount.setDivisionCode(DEF_DIV_CODE);
			fundingAccountRetrievalServiceRequest.setBillingAccount(billingAccount);
			//Modified by Cognizant for TPP change July 2017 - Start
			fundingAccountRetrievalServiceRequest.setIdentity(serviceUtil.returnIdentityNode(request.getRequestingSystem(), request.getOrgType()));
			//Modified by Cognizant for TPP change July 2017 - End
			/*Hystrix Changes Starts*/
			HystrixCommand<Object> hystrixCommand = CircuitBreakerCommand.getCBInstance(new PaymentMethodsFundingAccountServiceImpl(fundingAccountRetrievalServiceRequest, aciGateway, request.getRequestingSystem()),
					HYSTRIX_APP_NAME, HYSTRIX_PM_FUNDINGACCOUNT_COMMAND, hystrixUtils.getCBThreshold(), hystrixUtils.getCBTimeOutMillis(), hystrixUtils.getCBSleepWindowMillis(), hystrixUtils.getCBEnabled());
			FundingAccountRetrievalServiceResponse fundingAccountRetrievalServiceResponse = (FundingAccountRetrievalServiceResponse) hystrixCommand.execute();
			/*Hystrix Changes Ends*/
			List<BankAccountDetails> bankAccountDetails = preparePaymentMethods(fundingAccountRetrievalServiceResponse);
			List<CreditCardDetails> ccDetails = prepareCCPaymentMethods(fundingAccountRetrievalServiceResponse);
			if (null != fundingAccountRetrievalServiceResponse && null != fundingAccountRetrievalServiceResponse.getMessage())
			{
				response.setBankAccountDetails(bankAccountDetails);
				response.setCreditCardDetails(ccDetails);
				ResponseMessage responseMessage = new ResponseMessage();
				responseMessage.setMessageCode(String.valueOf(fundingAccountRetrievalServiceResponse.getMessage().getMessageCode()));
				responseMessage.setMessageDesc(fundingAccountRetrievalServiceResponse.getMessage().getMessageText());
				response.setResponseMessage(responseMessage);
				response.setAckStatus(Arrays.asList(ACI_SUCCESS_CODE).contains(responseMessage.getMessageCode()) ? ACI_SUCCESS_MSG
						: ACI_FAILURE_MSG);
			}
			else
			{
				response.setAckStatus(ACI_FAILURE_MSG);
			}
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->getPaymentMethodSummary");
		return response;
	}

	/**
	 * 
	 * @param fundingAccountRetrievalServiceResponse
	 * @return Helper utility to prepare the payment methods
	 * @throws AciException
	 */
	private List<BankAccountDetails> preparePaymentMethods(FundingAccountRetrievalServiceResponse fundingAccountRetrievalServiceResponse)
			throws AciException
			{
		LOGGER.info("Inside AciHelperUtils-->preparePaymentMethods");
		List<BankAccountDetails> bankAccountDetails = null;
		try
		{
			if (null != fundingAccountRetrievalServiceResponse
					&& AciUtils.checkNullForAList(fundingAccountRetrievalServiceResponse.getBankAccount()))
			{
				bankAccountDetails = new ArrayList<BankAccountDetails>(fundingAccountRetrievalServiceResponse.getBankAccount().size());
				for (BankAccount bankAccount : fundingAccountRetrievalServiceResponse.getBankAccount())
				{
					BankAccountDetails bankAccountDetail = new BankAccountDetails();
					dozerMapper.map(bankAccount, bankAccountDetail);
					bankAccountDetail.setTokenId(bankAccount.getFundingTokenId());
					bankAccountDetails.add(bankAccountDetail);
				}
			}
		} catch (MappingException e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->preparePaymentMethods");
		return bankAccountDetails;
			}

	/**
	 * 
	 * @param fundingAccountRetrievalServiceResponse
	 * @return Helper utility to prepare the payment methods
	 * @throws AciException
	 */
	private List<CreditCardDetails> prepareCCPaymentMethods(FundingAccountRetrievalServiceResponse fundingAccountRetrievalServiceResponse)
			throws AciException
			{
		LOGGER.info("Inside AciHelperUtils-->preparePaymentMethods");
		List<CreditCardDetails> creditCardDetails = null;
		try
		{
			if (null != fundingAccountRetrievalServiceResponse
					&& AciUtils.checkNullForAList(fundingAccountRetrievalServiceResponse.getCreditCardAccount()))
			{
				creditCardDetails = new ArrayList<CreditCardDetails>(fundingAccountRetrievalServiceResponse.getCreditCardAccount().size());
				for (CreditCardAccount ccAccount : fundingAccountRetrievalServiceResponse.getCreditCardAccount())
				{
					CreditCardDetails ccAccDetail = new CreditCardDetails();
					dozerMapper.map(ccAccount, ccAccDetail);
					ccAccDetail.setTokenId(ccAccount.getFundingTokenId());
					creditCardDetails.add(ccAccDetail);
				}
			}
		} catch (MappingException e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->preparePaymentMethods");
		return creditCardDetails;
			}

	/**
	 * 
	 * @param request
	 * @param indicator
	 * @return FundingAdminServiceRequest which has the base request values for the ACI service
	 */
	private FundingAdminServiceRequest getACIBaseRequest(AciFundingRequest request, MaintenanceIndicator indicator)
	{
		LOGGER.info("Inside AciHelperUtils-->getACIBaseRequest");
		FundingAdminServiceRequest fundingAdminServiceRequest = new FundingAdminServiceRequest();
		BillingAccount billingAccount = new BillingAccount();
		billingAccount.setBillingAccountNumber(request.getHcid());
		billingAccount.setDivisionCode(DEF_DIV_CODE);
		fundingAdminServiceRequest.setBillingAccount(billingAccount);
		fundingAdminServiceRequest.setCreditCardAccount(null);
		fundingAdminServiceRequest.setBankAccount(null);
		fundingAdminServiceRequest.setRequestType(indicator);
		//Modified by Cognizant for TPP change July 2017 - Start
		fundingAdminServiceRequest.setIdentity(serviceUtil.returnIdentityNode(request.getRequestingSystem(), request.getOrgType()));
		//Modified by Cognizant for TPP change July 2017 - End
		LOGGER.info("Completed AciHelperUtils-->getACIBaseRequest");
		return fundingAdminServiceRequest;
	}

	/**
	 * 
	 * @param request
	 * @return EmployerFundingResponse, connects to ACI service to delete the payment method
	 * @throws AciException
	 */
	public AciFundingResponse deletePaymentMethod(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->deletePaymentMethod");
		AciFundingResponse response = new AciFundingResponse();
		try
		{
			FundingAdminServiceRequest fundingAdminServiceRequest = getACIBaseRequest(request, MaintenanceIndicator.DELETE);
			fundingAdminServiceRequest.setFundingTokenId(request.getTokenId());
			FundingAdminServiceResponse fundingAdminServiceResponse = invokeAciFundingAdmin(fundingAdminServiceRequest, request.getRequestingSystem());
			response = prepareApiResponse(fundingAdminServiceResponse, response);
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->deletePaymentMethod");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @return EmployerFundingResponse, connects to ACI service to update the payment method
	 * @throws AciException
	 */
	public AciFundingResponse updatePaymentMethod(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->updatePaymentMethod");
		AciFundingResponse response = null;
		try
		{
			FundingAdminServiceResponse fundingAdminServiceResponse = invokeAciFundingAdmin(getUpdateRequest(request), request.getRequestingSystem());
			response = prepareApiResponse(fundingAdminServiceResponse, response);
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->updatePaymentMethod");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @return Invokes the ACI payment search service
	 * @throws AciException
	 */
	public AciPaymentSearchResponse searchForPayments(AciPaymentSearchRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->searchForPayments");
		try
		{
			LOGGER.info("Completed AciHelperUtils-->searchForPayments");
			return invokeSearchPayment(request);
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
	}

	/**
	 * 
	 * @param request
	 * @return Helper utility to invoke the Payment search
	 * @throws AciException
	 */
	private AciPaymentSearchResponse invokeSearchPayment(AciPaymentSearchRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->invokeSearchPayment");
		PaymentSearchServiceRequest searchRequest = new PaymentSearchServiceRequest();
		BillingAccount billingAccount = new BillingAccount();
		searchRequest.setFromDate(AciUtils.getGregorianCalendarDate(AciUtils
				.getAdjustedDate(ACI_PAYMENT_SEARCH_DATE_FORMAT, -1)));
		searchRequest.setToDate(AciUtils.getGregorianCalendarDate(AciUtils.getAdjustedDate(ACI_PAYMENT_SEARCH_DATE_FORMAT, 2)));
		billingAccount.setBillingAccountNumber(request.getHcid());
		billingAccount.setDivisionCode(DEF_DIV_CODE);
		searchRequest.setBillingAccount(billingAccount);
		//Modified by Cognizant for TPP change July 2017 - Start
		searchRequest.setIdentity(serviceUtil.returnIdentityNode(request.getRequestingSystem(), request.getOrgType()));
		//Modified by Cognizant for TPP change July 2017 - End
		/** Hystrix Changes start */
		HystrixCommand<Object> hystrixCommand = CircuitBreakerCommand.getCBInstance(new ACIPaymentSearchCBServiceImpl(searchRequest,
				aciGateway, request.getRequestingSystem()), HYSTRIX_APP_NAME, HYSTRIX_ACTSUM_PAYMENTSEARCH_COMMAND, hystrixUtils.getCBThreshold(), hystrixUtils
				.getCBTimeOutMillis(), hystrixUtils.getCBSleepWindowMillis(), hystrixUtils.getCBEnabled());
		PaymentSearchServiceResponse serachResponse = (PaymentSearchServiceResponse) hystrixCommand.execute();
		/** Hystrix Changes end */
		AciPaymentSearchResponse response = prepareSearchResponse(serachResponse);
		LOGGER.info("Completed AciHelperUtils-->invokeSearchPayment");
		return response;
	}

	/**
	 * 
	 * @param aciResponse
	 * @return EmployerPaymentSearchResponse, prepares the response from ACI response
	 * @throws AciException
	 */
	private AciPaymentSearchResponse prepareSearchResponse(PaymentSearchServiceResponse aciResponse) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->prepareSearchResponse");
		AciPaymentSearchResponse response = new AciPaymentSearchResponse();
		if (null != aciResponse && AciUtils.checkNullForAList(aciResponse.getPayment()))
		{
			List<AciPaymentDetail> aciPaymentDetails = new ArrayList<AciPaymentDetail>(aciResponse.getPayment().size());
			for (PaymentInfo paymentInfo : aciResponse.getPayment())
			{
				AciPaymentDetail aciPaymentDetail = new AciPaymentDetail();
				FundingAccount fundingAccount = new FundingAccount();
				RemittanceDetail remittanceDetail = new RemittanceDetail();
				aciPaymentDetail.setPaymentStatus(paymentInfo.getPaymentStatus().value());
				aciPaymentDetail.setPaymentDate(AciUtils.getDateForString(paymentInfo.getPaymentDate().toGregorianCalendar()
						.getTime(), DATE_FORMAT_yyyyMMdd));
				aciPaymentDetail.setPaymentConfirmationNo(paymentInfo.getConfirmationNumber());
				aciPaymentDetail.setPaymentAmount(String.valueOf(paymentInfo.getPaymentAmount()));
				fundingAccount.setFundingAccountType(paymentInfo.getFundingAccount().getFundingAccountType().name());
				fundingAccount.setMaskedAccountNo(paymentInfo.getFundingAccount().getFundingAccountNumber());
				fundingAccount.setTokenId(paymentInfo.getFundingAccount().getFundingTokenId());
				fundingAccount.setAccountNickname(paymentInfo.getFundingAccount().getAccountNickname());
				aciPaymentDetail.setFundingAccount(fundingAccount);
				remittanceDetail.setBillingAccountNumber(paymentInfo.getRemittance().getBillingAccount().getBillingAccountNumber());
				remittanceDetail.setRemitAmount(paymentInfo.getRemittance().getRemitAmount().toString());
				remittanceDetail.setRemitFee(paymentInfo.getRemittance().getRemitFee().toString());
				remittanceDetail.setProductId(getProductId(paymentInfo.getRemittance().getPaymentRemitField()));
				aciPaymentDetail.setRemittanceDetail(remittanceDetail);
				aciPaymentDetails.add(aciPaymentDetail);
				response.setAciPaymentDetails(aciPaymentDetails);
			}
		}
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessageCode(String.valueOf(aciResponse.getMessage().getMessageCode()));
		responseMessage.setMessageDesc(aciResponse.getMessage().getMessageText());
		response.setResponseMessage(responseMessage);
		response.setAckStatus(Arrays.asList(ACI_SUCCESS_CODE).contains(responseMessage.getMessageCode()) ? ACI_SUCCESS_MSG
				: ACI_FAILURE_MSG);
		LOGGER.info("Completed AciHelperUtils-->prepareSearchResponse");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @return Do Payments using the existing token id
	 * @throws AciException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public AciPaymentResponse doPaymentWithExistingToken(AciPaymentRequest request) throws AciException,
	InterruptedException, ExecutionException
	{
		LOGGER.info("Inside AciHelperUtils-->doPaymentWithExistingToken");
		AciPaymentResponse response = new AciPaymentResponse();
		try
		{
			List<PaymentAckDetail> paymentAckDetails = invokePaymentService(preparePayments(request, false), request.getRequestingSystem());		
			response.setUserId(request.getHcid());
			response.setTokenId(request.getTokenId());
			response.setPaymentMethodSaved(true);
			response.setPaymentAckDetails(paymentAckDetails);
			response.setRequestingSystem(request.getRequestingSystem());
			response.setAckStatus(getPaymentAckStatus(response.getPaymentAckDetails()));
			//logPayments(response);
			mapEmailAddress(request, response);
			sendConfirmationEmail(response);
		} catch (Exception e)
		{
			LOGGER.error("Exception in doPaymentWithExistingToken() of AciHelperUtils :" + e);
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->doPaymentWithExistingToken");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @return Do payment using store flag N
	 * @throws AciException
	 */
	public AciPaymentResponse doPaymentAndFlushToken(AciPaymentRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->doPaymentAndFlushToken");
		AciPaymentResponse response = new AciPaymentResponse();
		try
		{
			List<PaymentAckDetail> paymentAckDetails = invokePaymentService(preparePayments(request, true), request.getRequestingSystem());			
			response.setUserId(request.getHcid());
			response.setPaymentAckDetails(paymentAckDetails);
			response.setRequestingSystem(request.getRequestingSystem());
			response.setAckStatus(getPaymentAckStatus(response.getPaymentAckDetails()));
			//logPayments(response);
			mapEmailAddress(request, response);
			sendConfirmationEmail(response);
		} catch (Exception e)
		{
			LOGGER.error("Exception in doPaymentAndFlushToken() of AciHelperUtils :" + e);
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
		LOGGER.info("Completed AciHelperUtils-->doPaymentAndFlushToken");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @return Create a payment method and then do a payment, the token will be deleted in case the payment is failed
	 * @throws AciException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public AciPaymentResponse doPaymentAndSaveToken(AciPaymentRequest request) throws AciException, InterruptedException,
	ExecutionException
	{
		LOGGER.info("Inside AciHelperUtils-->doPaymentAndSaveToken");
		AciFundingRequest employerFundingRequest = new AciFundingRequest();
		AciPaymentResponse response = new AciPaymentResponse();
		dozerMapper.map(request, employerFundingRequest);
		AciFundingResponse gbdFundingResponse = createPaymentMethod(employerFundingRequest);
		if (null != gbdFundingResponse && ACI_SUCCESS_MSG.equals(gbdFundingResponse.getAckStatus()))
		{
			if (AciUtils.checkNullForAList(gbdFundingResponse.getBankAccountDetails()))
			{
				request.setTokenId(gbdFundingResponse.getBankAccountDetails().get(0).getTokenId());				
				response = doPaymentWithExistingToken(request);			
				if (!checkPaymentStatus(response))
				{
					AciFundingRequest deleteTokenRequest = new AciFundingRequest();
					dozerMapper.map(request, deleteTokenRequest);
					deletePaymentMethod(deleteTokenRequest);
					response.setPaymentMethodSaved(false);
					response.setTokenId(EMPTY_STRING);
				}
			}else if (AciUtils.checkNullForAList(gbdFundingResponse.getCreditCardDetails())){
				request.setTokenId(gbdFundingResponse.getCreditCardDetails().get(0).getTokenId());
				response = doPaymentWithExistingToken(request);				
				if (!checkPaymentStatus(response))
				{
					AciFundingRequest deleteTokenRequest = new AciFundingRequest();					
					dozerMapper.map(request, deleteTokenRequest);
					deletePaymentMethod(deleteTokenRequest);
					response.setPaymentMethodSaved(false);
					response.setTokenId(EMPTY_STRING);
				}
			}

		}else {
			if (null != gbdFundingResponse && null!= gbdFundingResponse.getResponseMessage().getMessageCode()){
				ResponseMessage responseMessage=new ResponseMessage();
				responseMessage.setMessageCode(gbdFundingResponse.getResponseMessage().getMessageCode());
				responseMessage.setMessageDesc(gbdFundingResponse.getResponseMessage().getMessageDesc());				
				response.setResponseMessage(responseMessage);				
			}
		}
		LOGGER.info("Completed AciHelperUtils-->doPaymentAndSaveToken");
		return response;
	}

	/**
	 * 
	 * @param request
	 * @param storeFlag
	 * @return Helps to prepare the ACI Payment request object
	 * @throws AciException
	 */
	private List<PaymentServiceServiceRequest> preparePayments(AciPaymentRequest request, boolean storeFlag) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->preparePayments");
		List<PaymentServiceServiceRequest> paymentRequests = new ArrayList<PaymentServiceServiceRequest>();
		if (null != request && AciUtils.checkNullForAList(request.getAciPayments()))
		{
			for (AciPayment aciPayment : request.getAciPayments())
			{
				PaymentServiceServiceRequest paymentServiceServiceRequest = new PaymentServiceServiceRequest();
				paymentServiceServiceRequest.setRequestedPaymentDate(AciUtils.getGregorianCalendarDate(AciUtils
						.getDateByString(request.getPaymentDate(), DATE_FORMAT_MMddyyyy)));
				BillingAccount billingAccount = new BillingAccount();
				billingAccount.setBillingAccountNumber(aciPayment.getPaymentSubmissionId());	
				if(null != request.getRequestingSystem() && "MEDSUPP".equalsIgnoreCase(request.getRequestingSystem())) {
					billingAccount.setDivisionCode(aciPayment.getDivisionCode());
				}else{
					billingAccount.setDivisionCode(request.getDivisionCode());
				}
				paymentServiceServiceRequest.setRemittance(prepareRemittance(aciPayment, request.getRequestingSystem(), request.getOrgName()));
				if(request.getPaymentType().equalsIgnoreCase("CREDITDEBITCARD")){
					paymentServiceServiceRequest.setEcommerceIndicator(EcommerceIndicator.ECOMMERCE);
				}else{
					//Modified by Cognizant for TPP change July 2017 - Start
					if(isBusinessBankAccountType(request)) {
						paymentServiceServiceRequest.setNachaStandardEntryClass(NachaStandardEntryClass.CCD);
					} else {
						paymentServiceServiceRequest.setNachaStandardEntryClass(NachaStandardEntryClass.WEB);
					}
					//Modified by Cognizant for TPP change July 2017 - End
				}
				paymentServiceServiceRequest.setCreditDebitIndicator(CreditDebitIndicator.DEBIT);								
				if (storeFlag)
				{
					paymentServiceServiceRequest.setBankAccount(getBankAccDetails(request));
					paymentServiceServiceRequest.setCreditCardAccount(getCreditCardDetails(request));
					if(null != paymentServiceServiceRequest.getBankAccount())
					{
						paymentServiceServiceRequest.setCreditDebitIndicator(CreditDebitIndicator.DEBIT);
					}else if(null != paymentServiceServiceRequest.getCreditCardAccount()){
						paymentServiceServiceRequest.setCreditDebitIndicator(CreditDebitIndicator.CREDIT);
						paymentServiceServiceRequest.setEcommerceIndicator(EcommerceIndicator.ECOMMERCE);
					}
					paymentServiceServiceRequest.setStoreFundingFlag(FlagField.N);
				}
				else
				{
					paymentServiceServiceRequest.setStoreFundingFlag(null);
				}
				paymentServiceServiceRequest.setFundingTokenId(request.getTokenId());
				//Modified by Cognizant for TPP change July 2017 - Start
				paymentServiceServiceRequest.setIdentity(serviceUtil.returnIdentityNode(request.getRequestingSystem(), request.getOrgType()));
				//Modified by Cognizant for TPP change July 2017 - End
				paymentServiceServiceRequest.setBillingAccount(billingAccount);
				paymentRequests.add(paymentServiceServiceRequest);
			}
		}
		LOGGER.info("Completed AciHelperUtils-->preparePayments");
		return paymentRequests;
	}

	private boolean isBusinessBankAccountType(AciPaymentRequest request) {
		boolean isBusinessCheckingSavings = false;
		
		//If condition will be executed for payment with existing token. Else if will be executed for new payment
		if(null != request.getBankAccountType() && ("BUSINESS_CHECKING".equalsIgnoreCase(request.getBankAccountType()) ||
				"BUSINESS_SAVINGS".equalsIgnoreCase(request.getBankAccountType()))) {
			isBusinessCheckingSavings = true;
			return isBusinessCheckingSavings;
		} else if (null != request.getBankAccountDetails() && null != request.getBankAccountDetails().getBankAccountType() &&
				("BUSINESS_CHECKING".equalsIgnoreCase(request.getBankAccountDetails().getBankAccountType().name()) || 
						"BUSINESS_SAVINGS".equalsIgnoreCase(request.getBankAccountDetails().getBankAccountType().name()))) {
			isBusinessCheckingSavings = true;
			return isBusinessCheckingSavings;
		}
		return isBusinessCheckingSavings;
	}
	//Modified by Cognizant for TPP change July 2017 - Start
	
	/**
	 * 
	 * @param aciPayment
	 * @return Helper Utility to create Remittance node
	 */
	private List<Remittance> prepareRemittance(AciPayment aciPayment, String senderApp, String orgName)
	{
		LOGGER.info("Inside AciHelperUtils-->prepareRemittance");
		List<Remittance> remittances = new ArrayList<Remittance>();
		Remittance remittance = new Remittance();
		BigDecimal remitAmount = new BigDecimal(serviceUtil.roundUp(aciPayment.getRemitAmount(), 2));
		remittance.setRemitAmount(remitAmount);
		remittance.setRemitFee(new BigDecimal(DEF_REMIT_FEE));
		List<PaymentRemitField> paymentRemitFields = new ArrayList<PaymentRemitField>();
		PaymentRemitField paymentRemitField1 = new PaymentRemitField();
		PaymentRemitField paymentRemitField2 = new PaymentRemitField();
		PaymentRemitField paymentRemitField3 = new PaymentRemitField();
		
		paymentRemitField1.setValue(ZERO_REMIT_VALUE);
		paymentRemitField2.setValue("0");
		paymentRemitField3.setValue(aciPayment.getProductCode());
		paymentRemitFields.add(paymentRemitField1);
		paymentRemitFields.add(paymentRemitField2);
		paymentRemitFields.add(paymentRemitField3);
		
		if(null != senderApp && "TPP".equalsIgnoreCase(senderApp)) {
			PaymentRemitField paymentRemitField4 = new PaymentRemitField();
			paymentRemitField4.setValue(orgName);
			paymentRemitFields.add(paymentRemitField4);
		}
		
		
		remittance.setPaymentRemitField(paymentRemitFields);
		remittances.add(remittance);
		LOGGER.info("Completed AciHelperUtils-->prepareRemittance");
		return remittances;
	}
	//Modified by Cognizant for TPP change July 2017 - End

	/**
	 * 
	 * @param paymentServiceServiceRequests
	 * @return Calls the ACI gateway asynchronously
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @throws AciException
	 */
	@SuppressWarnings({ "unchecked" })
	private List<PaymentAckDetail> invokePaymentService(List<PaymentServiceServiceRequest> paymentServiceServiceRequests, String requestingSystem)
			throws InterruptedException, ExecutionException, AciException
			{
		LOGGER.info("Inside AciHelperUtils-->invokePaymentService");
		List<Future<PaymentServiceServiceResponse>> restobjs = new ArrayList<Future<PaymentServiceServiceResponse>>();
		List<PaymentServiceServiceResponse> resultList = new ArrayList<PaymentServiceServiceResponse>();
		for (PaymentServiceServiceRequest oneRequest : paymentServiceServiceRequests)
		{
			/* Hystrix Changes Starts */
			HystrixCommand<Object> hystrixCommand = CircuitBreakerCommand.getCBInstance(new PaymentMethodsSubmitPaymentServiceImpl(
					oneRequest, aciGateway, requestingSystem), HYSTRIX_APP_NAME, HYSTRIX_PM_SUBMITPAYMENT_COMMAND, hystrixUtils.getCBThreshold(),
					hystrixUtils.getCBTimeOutMillis(), hystrixUtils.getCBSleepWindowMillis(), hystrixUtils.getCBEnabled());
			Future<PaymentServiceServiceResponse> result = (Future<PaymentServiceServiceResponse>) hystrixCommand.execute();
			/* Hystrix Changes Ends */
			restobjs.add(result);
		}

		for (Future<PaymentServiceServiceResponse> eachResponse : restobjs)
		{
			resultList.add(eachResponse.get());
		}
		LOGGER.info("Completed AciHelperUtils-->invokePaymentService");
		return extractAckDetails(resultList);
	}

	/**
	 * 
	 * @param resultList
	 * @return Helper utility to extract the payment Ack details
	 * @throws AciException
	 */
	private List<PaymentAckDetail> extractAckDetails(List<PaymentServiceServiceResponse> resultList) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->extractAckDetails");
		List<PaymentAckDetail> paymentAckDetails = new ArrayList<PaymentAckDetail>();
		if (null != resultList && AciUtils.checkNullForAList(resultList))
		{
			for (PaymentServiceServiceResponse response : resultList)
			{
				PaymentAckDetail paymentAckDetail = new PaymentAckDetail();
				ResponseMessage responseMessage = new ResponseMessage();
				paymentAckDetail.setPaymentStatus(("0".equals(String.valueOf(response.getMessage().getMessageCode())) ? ACI_SUCCESS_MSG
						: ACI_FAILURE_MSG));
				if (ACI_SUCCESS_MSG.equals(paymentAckDetail.getPaymentStatus()))
				{
					paymentAckDetail.setConfirmationNumber(response.getConfirmationNumber());
					paymentAckDetail.setPaymentDate(AciUtils.getDateForString(response.getFinalPaymentDate().toGregorianCalendar()
							.getTime(), DATE_FORMAT_yyyyMMdd));
				}
				if (AciUtils.checkNullForAList(response.getRemittance()))
				{
					paymentAckDetail.setPaymentAmount(response.getRemittance().get(0).getRemitAmount().toString());
					if(AciUtils.checkNullForAList(response.getRemittance().get(0).getPaymentRemitField()) && response.getRemittance().get(0).getPaymentRemitField().size() > 1){
						paymentAckDetail.setProductCode(response.getRemittance().get(0).getPaymentRemitField().get(2).getValue());
					}
				}
				paymentAckDetail.setPaymentSubmissionId(response.getBillingAccount().getBillingAccountNumber());
				if(null != response.getBankAccount()){
					paymentAckDetail.setPaymentType(MemberPayPaymentTypeEnum.BANKINGACCOUNT);
				}else if(null != response.getCreditCardAccount()){
					paymentAckDetail.setPaymentType(MemberPayPaymentTypeEnum.CREDITDEBITCARD);
				}
				responseMessage.setMessageCode(String.valueOf(response.getMessage().getMessageCode()));
				responseMessage.setMessageDesc(response.getMessage().getMessageText());
				paymentAckDetail.setResponseMessage(responseMessage);
				paymentAckDetails.add(paymentAckDetail);
			}
		}
		LOGGER.info("Completed AciHelperUtils-->extractAckDetails");
		return paymentAckDetails;
	}

	/**
	 * 
	 * @param paymentAckDetails
	 * @return The Success/Failure Status
	 * @throws AciException
	 */
	private String getPaymentAckStatus(List<PaymentAckDetail> paymentAckDetails) throws AciException
	{
		String ackStatus = ACI_SUCCESS_MSG;
		if (AciUtils.checkNullForAList(paymentAckDetails))
		{
			for (PaymentAckDetail paymentAckDetail : paymentAckDetails)
			{
				if (ACI_FAILURE_MSG.equals(paymentAckDetail.getPaymentStatus()))
				{
					ackStatus = ACI_FAILURE_MSG;
					break;
				}
			}
		}
		return ackStatus;

	}

	/**
	 * Inserts in Payment Details Log table
	 * 
	 * @param response
	 * @throws AciException
	 */
	private void logPayments(AciPaymentResponse response) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->logPayments");
		try
		{
			List<MemberPaySubmitPayment> loggingList = new ArrayList<MemberPaySubmitPayment>();
			if (null != response && AciUtils.checkNullForAList(response.getPaymentAckDetails()))
			{
				for (PaymentAckDetail paymentAckDetail : response.getPaymentAckDetails())
				{
					MemberPaySubmitPayment memberPaySubmitPayment = new MemberPaySubmitPayment();
					Message message = new Message();
					memberPaySubmitPayment.setPaymentHcid(paymentAckDetail.getPaymentSubmissionId());
					memberPaySubmitPayment.setSubmittedHcid(response.getUserId());
					memberPaySubmitPayment.setConfirmationNumber(paymentAckDetail.getConfirmationNumber());
					memberPaySubmitPayment.setStatus(paymentAckDetail.getPaymentStatus());
					memberPaySubmitPayment.setSubGroupId(paymentAckDetail.getProductCode());
					memberPaySubmitPayment.setTokenId(response.getTokenId());
					memberPaySubmitPayment.setPaymentAmount(paymentAckDetail.getPaymentAmount());
					memberPaySubmitPayment.setPaymentDate(paymentAckDetail.getPaymentDate());
					memberPaySubmitPayment.setRequestingSystem(response.getRequestingSystem());
					memberPaySubmitPayment.setState(EMPTY_STRING);
					memberPaySubmitPayment.setPaymentType(paymentAckDetail.getPaymentType());
					message.setMessageCode(Integer.valueOf(paymentAckDetail.getResponseMessage().getMessageCode()));
					message.setMessageText(paymentAckDetail.getResponseMessage().getMessageDesc());
					memberPaySubmitPayment.setMessage(message);
					loggingList.add(memberPaySubmitPayment);
				}
				aciDaoServiceImpl.insertPaymentDetailsTable(loggingList,response.getRequestingSystem());
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in logPaymentDetailsTable() of AciHelperUtils :" + e);
		}
		LOGGER.info("Completed AciHelperUtils-->logPayments");
	}

	/**
	 * 
	 * @param response
	 * @return check for Ack status of submit payment, returns true if payment is success else false
	 */
	private boolean checkPaymentStatus(AciPaymentResponse response)
	{
		if (null != response && ACI_SUCCESS_MSG.equals(response.getAckStatus()))
		{
			return Boolean.TRUE;
		}
		else
		{
			return Boolean.FALSE;
		}
	}

	/**
	 * 
	 * @param request
	 * @return Helper utility to prepare the base update request for calling ACI service
	 * @throws AciException
	 */
	private FundingAdminServiceRequest getUpdateRequest(AciFundingRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->getUpdateRequest");
		FundingAdminServiceRequest fundingAdminServiceRequest = getACIBaseRequest(request, MaintenanceIndicator.MODIFY);
		fundingAdminServiceRequest.setBankAccount(getBankAccDetails(request));
		fundingAdminServiceRequest.setCreditCardAccount(getCreditCardDetails(request));
		fundingAdminServiceRequest.setFundingTokenId(request.getTokenId());
		LOGGER.info("Completed AciHelperUtils-->getUpdateRequest");
		return fundingAdminServiceRequest;
	}

	/**
	 * 
	 * @param fundingAdminServiceRequest
	 * @return Invokes the actual ACI funding admin service
	 * @throws AciException
	 */
	private FundingAdminServiceResponse invokeAciFundingAdmin(FundingAdminServiceRequest fundingAdminServiceRequest, String requestingSystem)
			throws AciException
			{
		LOGGER.info("Inside AciHelperUtils-->invokeAciFundingAdmin");
		try
		{
			/* Hystrix Changes Starts */
			HystrixCommand<Object> hystrixCommand = CircuitBreakerCommand.getCBInstance(new PaymentMethodsFundingAdminServiceImpl(
					fundingAdminServiceRequest, aciGateway, requestingSystem), HYSTRIX_APP_NAME, HYSTRIX_PM_FUNDINGADMIN_COMMAND, hystrixUtils
					.getCBThreshold(), hystrixUtils.getCBTimeOutMillis(), hystrixUtils.getCBSleepWindowMillis(), hystrixUtils
					.getCBEnabled());
			return (FundingAdminServiceResponse) hystrixCommand.execute();
			/* Hystrix Changes Ends */
		} catch (Exception e)
		{
			throw new AciException("E", "PP9000", TECHINICAL_ERROR_MSG, 500);
		}
			}
	/**
	 * 
	 * @param response
	 * @throws AciException
	 * Sends the payment confirmation email to the recipient only if the payment is successful.
	 */
	private void sendConfirmationEmail(AciPaymentResponse response) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->sendConfirmationEmail");
		try
		{
			Map<String, Object> model = new HashMap<String, Object>();

			for (PaymentAckDetail paymentAckDetail : response.getPaymentAckDetails())
			{
				if (!StringUtils.isBlank(paymentAckDetail.getEmployerEmail()))
				{
					model.put(LINK_TO_EMAIL, paymentAckDetail.getEmployerEmail());
					model.put(CUSTOMER_NUMBER, paymentAckDetail.getPaymentSubmissionId());
					model.put(BRAND, DEF_EMP_BRAND);
					model.put(PAYMENT_DATE, AciUtils.getDateForString(AciUtils.getDateByString(paymentAckDetail.getPaymentDate(), DATE_FORMAT_yyyyMMdd), DATE_FORMAT_MMddyyyy));
					model.put(TOTAL_AMOUNT, paymentAckDetail.getPaymentAmount());
					sendPaymentProcessingEmail(model, paymentAckDetail.getPaymentStatus(),response.getRequestingSystem());
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in sendConfirmationEmail() of AciHelperUtils :" + e);
		}
		LOGGER.info("Completed AciHelperUtils-->sendConfirmationEmail");
	}
	/**
	 * 
	 * @param model
	 * @param action
	 * @throws AciException
	 * Helper utility to a send email
	 */
	private void sendPaymentProcessingEmail(Map<String, Object> model, String action,String requestingSystem) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->sendPaymentProcessingEmail");
		Mail mail = new Mail();
		mail.setMailFrom(MAIL_FROM);
		if (EMP_PAYMENT_SUCCESS.equalsIgnoreCase(action))
		{
			mail.setMailSubject(EMP_PAYMENT_SUCCESS_SUBJECT);
			mail.setTemplateLocation(EMP_PAYMENT_SUCCESS_TEMPLATE);
			mail.setTemplateId(EMP_PAYMENT_SUCCESS_TEMPLATE_ID);
			mail.setMailType(MAIL_TYPE);
			mail.setToHcid((String) model.get(CUSTOMER_NUMBER));
			mail.setCreatedBy((String) model.get(CUSTOMER_NUMBER));
			mail.setMailTo((String) model.get(LINK_TO_EMAIL));
			emailUtil.sendMail(mail, model,requestingSystem);
		}
		LOGGER.info("Completed AciHelperUtils-->sendPaymentProcessingEmail");
	}
	/**
	 * 
	 * @param request
	 * @param response
	 * Helps to map the email address from the request to the response object
	 */
	private void mapEmailAddress(AciPaymentRequest request, AciPaymentResponse response)
	{
		LOGGER.info("Inside AciHelperUtils-->mapEmailAddress");
		try
		{
			for (PaymentAckDetail paymentAckDetail : response.getPaymentAckDetails())
			{
				for (AciPayment aciPayment : request.getAciPayments())
				{
					if (aciPayment.getPaymentSubmissionId().equalsIgnoreCase(paymentAckDetail.getPaymentSubmissionId()))
					{
						paymentAckDetail.setEmployerEmail(aciPayment.getEmployerEmail());
						paymentAckDetail.setPaymentDate(request.getPaymentDate());
						break;
					}
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in mapEmailAddress() of AciHelperUtils :" + e);
		}
		LOGGER.info("Completed AciHelperUtils-->mapEmailAddress");
	}

	public AciCancelResponse cancelAciPayment(AciCancelRequest request) throws AciException{

		return invokeCancelPayment(request);

	}

	/**
	 * 
	 * @param request
	 * @return Helper utility to invoke the Payment Cancel
	 * @throws AciException
	 */
	private AciCancelResponse invokeCancelPayment(AciCancelRequest request) throws AciException
	{
		LOGGER.info("Inside AciHelperUtils-->invokeCancelPayment");
		CancelPaymentServiceRequest cancelRequest = new CancelPaymentServiceRequest();
		cancelRequest.setIdentity(serviceUtil.returnIdentityNode(request.getRequestingSystem(), request.getOrgType()));
		cancelRequest.setConfirmationNumber(request.getPaymentConfirmationNo());
		/** Hystrix Changes start */
		HystrixCommand<Object> hystrixCommand = CircuitBreakerCommand.getCBInstance(new PaymentMethodsCancelPaymentServiceImpl(cancelRequest,
				aciGateway, request.getRequestingSystem()), HYSTRIX_APP_NAME, HYSTRIX_PM_CANCELPAYMENT_COMMAND, hystrixUtils.getCBThreshold(), hystrixUtils
				.getCBTimeOutMillis(), hystrixUtils.getCBSleepWindowMillis(), hystrixUtils.getCBEnabled());
		CancelPaymentServiceResponse cancelResponse = (CancelPaymentServiceResponse) hystrixCommand.execute();
		/** Hystrix Changes end */
		AciCancelResponse response = new AciCancelResponse();
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setMessageCode(String.valueOf(cancelResponse.getMessage().getMessageCode()));
		responseMessage.setMessageDesc(cancelResponse.getMessage().getMessageText());
		response.setResponseMessage(responseMessage);
		response.setAckStatus(Arrays.asList(ACI_SUCCESS_CODE).contains(responseMessage.getMessageCode()) ? ACI_SUCCESS_MSG
				: ACI_FAILURE_MSG);
		response.setPaymentCancelStatus(Arrays.asList(ACI_SUCCESS_CODE).contains(responseMessage.getMessageCode()) ? ACI_SUCCESS_MSG
				: ACI_FAILURE_MSG);
		response.setPaymentConfirmationNo(cancelResponse.getConfirmationNumber());
		LOGGER.info("Completed AciHelperUtils-->invokeCancelPayment");
		return response;
	}
	
	private String getProductId(List<PaymentRemitField> paymentRemitFields){
		String productId = "";
		try {
			LOGGER.info("Inside AccountSummaryHelper-->getProductId");
			for(PaymentRemitField paymentRemitField: paymentRemitFields)
			{
				if(AciUtils.checkNullForAString(paymentRemitField.getValue()) && !paymentRemitField.getValue().trim().equals("0") && !paymentRemitField.getValue().trim().equals("00000000000000000000"))
				{
					productId = paymentRemitField.getValue();
					break;
				}
			} 
			/*LOGGER.info("Completed AccountSummaryHelper-->getProductId :: " + productId);*/
		
		} catch (Exception e) {
			LOGGER.error("Error in getProductId:" + e);
			productId = "";
		}
		return productId;
	}
}
