package com.wellpoint.ebiz.middletier.aci.payment.utility;

import org.apache.commons.configuration.AbstractConfiguration;
import org.springframework.stereotype.Component;

import com.netflix.config.ConcurrentCompositeConfiguration;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicPropertyUpdater;
import com.netflix.config.DynamicStringProperty;
import com.netflix.config.PollResult;

@Component
public class ApplicationPropertiesService
{
	private ConcurrentCompositeConfiguration finalConfig = new ConcurrentCompositeConfiguration();
	private DynamicPropertyUpdater dynamicPropertyUpdater = new DynamicPropertyUpdater();

	public String getStringProperty(String key, String defaultValue) {
		final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, defaultValue);
		return property.get();
	}
	
	public String getStringProperty(String key) {
		return getStringProperty(key, null);
	}

	public void updateProperty(String key, String value) {
		finalConfig.setOverrideProperty(key, value);
	}
	
	public void updateProperties() {
		try {
			AbstractConfiguration config= ConfigurationManager.getConfigInstance();
			if (config instanceof DynamicConfiguration) {
				PollResult result = ((DynamicConfiguration) config).getSource().poll(false, null);
				dynamicPropertyUpdater.updateProperties(result, config, false);
			}
		} catch (Exception e) {
			/*e.printStackTrace();*/

		}
	}
	
}
