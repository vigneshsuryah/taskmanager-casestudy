package com.wellpoint.ebiz.middletier.aci.payment.netflix.hystrix;

import org.springframework.stereotype.Component;

import com.wellpoint.ebiz.middletier.aci.payment.utility.ServiceUtil;

@Component("hystrixUtils")
public class HystrixUtils {	
	
	/**
	 * 
	 * @return Circuit Breaker Threshold limit
	 */
	public Integer getCBThreshold(){
		return Integer.valueOf(ServiceUtil.getStringProperty("memberpay.setting.circuitbreaker.request.volume.threshold", "10"));
	}
	
	/**
	 * 
	 * @return Circuit Breaker TimeOutMillis
	 */
	public Integer getCBTimeOutMillis(){
		return Integer.valueOf(ServiceUtil.getStringProperty("memberpay.setting.circuitbreaker.execution.timeout.in.milliseconds", "10000"));
	}
	
	/**
	 * 
	 * @return Circuit Breaker SleepWindowMillis
	 */
	public Integer getCBSleepWindowMillis(){
		return Integer.valueOf(ServiceUtil.getStringProperty("memberpay.setting.circuitbreaker.sleep.window.in.milliseconds", "60000"));
	}
	
	/**
	 * 
	 * @return Circuit Breaker Enable flag
	 */
	public boolean getCBEnabled(){
		return Boolean.valueOf(ServiceUtil.getStringProperty("memberpay.setting.circuitbreaker.enabled", "true"));
	}
}
