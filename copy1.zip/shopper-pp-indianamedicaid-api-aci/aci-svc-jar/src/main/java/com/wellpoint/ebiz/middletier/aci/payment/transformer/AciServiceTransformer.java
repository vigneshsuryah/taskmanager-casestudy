/**
* AciServiceTransformer.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.transformer;


import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Header;
import org.springframework.integration.annotation.Transformer;
import org.springframework.stereotype.Component;
import org.xmlsoap.schemas.soap.envelope.Fault;

import com.princetonecom.connect.fundingaccountretrievalrequest1.FundingAccountRetrievalRequest;
import com.princetonecom.connect.fundingaccountretrievalresponse1.FundingAccountRetrievalResponse;
import com.princetonecom.connect.fundingadminrequest.FundingAdminRequest;
import com.princetonecom.connect.fundingadminresponse.FundingAdminResponse;
import com.princetonecom.connect.otpcancelstgpaymentrequest1.OtpCancelStgPaymentRequest;
import com.princetonecom.connect.otpcancelstgpaymentresponse1.OtpCancelStgPaymentResponse;
import com.princetonecom.connect.paymentsearchrequest1.PaymentSearchRequest;
import com.princetonecom.connect.paymentsearchresponse1.PaymentSearchResponse;
import com.princetonecom.connect.paymentservicerequest.PaymentServiceRequest;
import com.princetonecom.connect.paymentserviceresponse.PaymentServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.CancelPaymentServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAccountRetrievalServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.FundingAdminServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.Message;
import com.wellpoint.aci.payment.domain.orcc.PaymentRemitField;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentSearchServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceRequest;
import com.wellpoint.aci.payment.domain.orcc.PaymentServiceServiceResponse;
import com.wellpoint.aci.payment.domain.orcc.Remittance;


@Component
public class AciServiceTransformer
{

	@Autowired
	private Mapper dozerMapper;
	
	private static final String UNCHECKED = "unchecked";

	private static final String RAWTYPES = "rawtypes";

	@SuppressWarnings({ RAWTYPES, UNCHECKED })
	@Transformer
	public JAXBElement<?> createCancelPaymentRequest(CancelPaymentServiceRequest cancelPaymentServiceRequest, @Header("requestingSystem") String requestingSystem)	
	{
		OtpCancelStgPaymentRequest cancelPaymentRequest = dozerMapper.map(cancelPaymentServiceRequest, OtpCancelStgPaymentRequest.class);
		return new JAXBElement(new QName("http://www.princetonecom.com/connect/otpcancelstgpaymentrequest1","otp-cancel-stg-payment-request"),
				cancelPaymentRequest.getClass(), null, cancelPaymentRequest);
	}

	@Transformer
	public CancelPaymentServiceResponse processCancelPaymentResponse(JAXBElement<?> jaxbElement)
	{
		OtpCancelStgPaymentResponse cancelPaymentResponse = (OtpCancelStgPaymentResponse) jaxbElement.getValue();
		return dozerMapper.map(cancelPaymentResponse, CancelPaymentServiceResponse.class);
	}

	@SuppressWarnings({ RAWTYPES, UNCHECKED })
	@Transformer 
	public JAXBElement<?> createFundingAccountRetrievalRequest(FundingAccountRetrievalServiceRequest fundingAccountRetrivalServiceRequest, @Header("requestingSystem") String requestingSystem)
	{
		FundingAccountRetrievalRequest fundingAccountRetrievalRequest = dozerMapper.map(fundingAccountRetrivalServiceRequest,
				FundingAccountRetrievalRequest.class);
		return new JAXBElement(new QName("http://www.princetonecom.com/connect/fundingaccountretrievalrequest1",
		"funding-account-retrieval-request"), fundingAccountRetrievalRequest.getClass(), null, fundingAccountRetrievalRequest);
	}

	@Transformer
	public FundingAccountRetrievalServiceResponse processFundingAccountRetrivalResponse(JAXBElement<?> jaxbElement)
	{
		FundingAccountRetrievalResponse fundingAccountRetrievalResponse = (FundingAccountRetrievalResponse) jaxbElement.getValue();
		return dozerMapper.map(fundingAccountRetrievalResponse,FundingAccountRetrievalServiceResponse.class);
	}

	@SuppressWarnings({ RAWTYPES, UNCHECKED })
	@Transformer
	public JAXBElement<?> createFundingAdminRequest(FundingAdminServiceRequest fundingAdminServiceRequest, @Header("requestingSystem") String requestingSystem)
	{
		FundingAdminRequest fundingAdminRequest = dozerMapper.map(fundingAdminServiceRequest, FundingAdminRequest.class);
		return new JAXBElement(new QName("http://www.princetonecom.com/connect/fundingadminrequest",
		"funding-admin-request"), fundingAdminRequest.getClass(), null, fundingAdminRequest);
	}

	@Transformer
	public FundingAdminServiceResponse processFundingAdminResponse(JAXBElement<?> jaxbElement) throws Exception
	{
		Object response = jaxbElement.getValue();
		if (response instanceof Fault) {
			Fault fault = (Fault) jaxbElement.getValue();
			Message message = new Message();
			message.setMessageCode(500);
			message.setMessageText(fault.getFaultstring());
			FundingAdminServiceResponse fundingAdminServiceResponse = new FundingAdminServiceResponse();
			fundingAdminServiceResponse.setMessage(message);
			return fundingAdminServiceResponse;
		}
		FundingAdminResponse fundingAdminResponse = (FundingAdminResponse) jaxbElement.getValue();
		return dozerMapper.map(fundingAdminResponse, FundingAdminServiceResponse.class);
	}

	@SuppressWarnings({ RAWTYPES, UNCHECKED })
	@Transformer
	public JAXBElement<?> createPaymentSearchRequest(PaymentSearchServiceRequest paymentSearchServiceRequest, @Header("requestingSystem") String requestingSystem)
	{
		PaymentSearchRequest paymentSearchRequest = dozerMapper.map(paymentSearchServiceRequest, PaymentSearchRequest.class);
		return new JAXBElement(new QName("http://www.princetonecom.com/connect/paymentsearchrequest1",
		"payment-search-request"), paymentSearchRequest.getClass(), null, paymentSearchRequest);
	}

	@Transformer
	public PaymentSearchServiceResponse processPaymentSearchResponse(JAXBElement<?> jaxbElement)
	{
		PaymentSearchResponse paymentSearchResponse = (PaymentSearchResponse) jaxbElement.getValue();
		return dozerMapper.map(paymentSearchResponse, PaymentSearchServiceResponse.class);
	}

	@SuppressWarnings({ RAWTYPES, UNCHECKED })
	@Transformer
	public JAXBElement<?> createPaymentServiceRequest(PaymentServiceServiceRequest paymentServiceServiceRequest, @Header("requestingSystem") String requestingSystem)
	{
		List<Remittance> remittances = paymentServiceServiceRequest.getRemittance();
		PaymentServiceRequest paymentServiceRequest = dozerMapper.map(paymentServiceServiceRequest, PaymentServiceRequest.class);
		for(Remittance remittance: remittances)
		{
			com.princetonecom.connect.paymentservicerequest.Remittance remittanceSer = dozerMapper.map(remittance, com.princetonecom.connect.paymentservicerequest.Remittance.class);
			for(PaymentRemitField payRemit : remittance.getPaymentRemitField()){
				remittanceSer.getPaymentRemitField().add(dozerMapper.map(payRemit,com.princetonecom.connect.paymentservicerequest.PaymentRemitField.class));
			}
			paymentServiceRequest.getRemittance().add(remittanceSer);
		}
		return new JAXBElement(new QName("http://www.princetonecom.com/connect/paymentservicerequest",
		"payment-service-request"), paymentServiceRequest.getClass(), null, paymentServiceRequest);
	}

	@Transformer
	public PaymentServiceServiceResponse processPaymentServiceResponse(JAXBElement<?> jaxbElement)
	{
		PaymentServiceResponse paymentServiceResponse = (PaymentServiceResponse) jaxbElement.getValue();
		return dozerMapper.map(paymentServiceResponse, PaymentServiceServiceResponse.class);
	}
}
