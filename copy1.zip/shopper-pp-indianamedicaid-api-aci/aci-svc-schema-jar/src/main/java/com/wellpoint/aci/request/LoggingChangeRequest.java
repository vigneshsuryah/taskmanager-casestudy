/**
* LoggingChangeRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 05/02/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.request;

public class LoggingChangeRequest
{

	private static final long serialVersionUID = -5471298871648460506L;

	private String loggingLevel;
	private String propsKey;
	private String propsValue;

	public String getLoggingLevel() {
		return loggingLevel;
	}

	public void setLoggingLevel(String loggingLevel) {
		this.loggingLevel = loggingLevel;
	}

	public String getPropsKey() {
		return propsKey;
	}

	public void setPropsKey(String propsKey) {
		this.propsKey = propsKey;
	}

	public String getPropsValue() {
		return propsValue;
	}

	public void setPropsValue(String propsValue) {
		this.propsValue = propsValue;
	}
	
}
