/**
* FundingAccount.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import javax.xml.datatype.XMLGregorianCalendar;

import com.wellpoint.aci.payment.mam.utility.CustomFundingAccountTypeEnum;


public class FundingAccount
{

	private Long fundingAccountId;

	private String fundingTokenId;

	private String accountNickname;

	private XMLGregorianCalendar createDate;

	private XMLGregorianCalendar lastUpdateDate;

	private XMLGregorianCalendar lastUsedDate;

	private AccountStatus accountStatus;
	
	private CustomFundingAccountTypeEnum fundingAccountType;
	
	private String fundingAccountNumber;

	public Long getFundingAccountId()
	{
		return fundingAccountId;
	}

	public void setFundingAccountId(Long fundingAccountId)
	{
		this.fundingAccountId = fundingAccountId;
	}

	public String getFundingTokenId()
	{
		return fundingTokenId;
	}

	public void setFundingTokenId(String fundingTokenId)
	{
		this.fundingTokenId = fundingTokenId;
	}

	public String getAccountNickname()
	{
		return accountNickname;
	}

	public void setAccountNickname(String accountNickname)
	{
		this.accountNickname = accountNickname;
	}

	public XMLGregorianCalendar getCreateDate()
	{
		return createDate;
	}

	public void setCreateDate(XMLGregorianCalendar createDate)
	{
		this.createDate = createDate;
	}

	public XMLGregorianCalendar getLastUpdateDate()
	{
		return lastUpdateDate;
	}

	public void setLastUpdateDate(XMLGregorianCalendar lastUpdateDate)
	{
		this.lastUpdateDate = lastUpdateDate;
	}

	public XMLGregorianCalendar getLastUsedDate()
	{
		return lastUsedDate;
	}

	public void setLastUsedDate(XMLGregorianCalendar lastUsedDate)
	{
		this.lastUsedDate = lastUsedDate;
	}

	public AccountStatus getAccountStatus()
	{
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus)
	{
		this.accountStatus = accountStatus;
	}

	public void setFundingAccountType(CustomFundingAccountTypeEnum fundingAccountType) {
		this.fundingAccountType = fundingAccountType;
	}

	public CustomFundingAccountTypeEnum getFundingAccountType() {
		return fundingAccountType;
	}

	public void setFundingAccountNumber(String fundingAccountNumber) {
		this.fundingAccountNumber = fundingAccountNumber;
	}

	public String getFundingAccountNumber() {
		return fundingAccountNumber;
	}
}
