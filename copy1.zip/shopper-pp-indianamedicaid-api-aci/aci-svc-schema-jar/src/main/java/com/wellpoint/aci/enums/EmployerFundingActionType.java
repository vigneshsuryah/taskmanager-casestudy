package com.wellpoint.aci.enums;

public enum EmployerFundingActionType {

	CREATE,MODIFY,DELETE,GETSUM
}
