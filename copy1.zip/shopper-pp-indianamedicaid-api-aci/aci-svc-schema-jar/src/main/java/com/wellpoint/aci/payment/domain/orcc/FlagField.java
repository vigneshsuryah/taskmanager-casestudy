/**
* FlagField.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public enum FlagField
{

	Y, N;

	public String value()
	{
		return name();
	}

	public static FlagField fromValue(String v)
	{
		return valueOf(v);
	}
}
