package com.wellpoint.aci.enums;

public enum EmployerPaymentTypeEnum {
	BANKINGACCOUNT,	CREDITDEBITCARD;
}
