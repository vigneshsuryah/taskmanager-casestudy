package com.wellpoint.aci.response;


public class RemittanceDetail {
	private String billingAccountNumber;
	
	private String remitAmount;
	
	private String remitFee;
	
	private String productId;

	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}

	public void setBillingAccountNumber(String billingAccountNumber) {
		this.billingAccountNumber = billingAccountNumber;
	}

	public String getRemitAmount() {
		return remitAmount;
	}

	public void setRemitAmount(String remitAmount) {
		this.remitAmount = remitAmount;
	}

	public String getRemitFee() {
		return remitFee;
	}

	public void setRemitFee(String remitFee) {
		this.remitFee = remitFee;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	
	
}
