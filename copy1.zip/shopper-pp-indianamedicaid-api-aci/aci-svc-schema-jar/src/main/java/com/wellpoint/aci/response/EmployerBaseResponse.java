package com.wellpoint.aci.response;



public class EmployerBaseResponse extends BaseResponse{

	private static final long serialVersionUID = -2870351888745496371L;
	
	private String ackStatus;
	
	private String groupId;
	private String userId;	
	private ResponseMessage responseMessage;	
	

	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getAckStatus() {
		return ackStatus;
	}

	public void setAckStatus(String ackStatus) {
		this.ackStatus = ackStatus;
	}

	
}
