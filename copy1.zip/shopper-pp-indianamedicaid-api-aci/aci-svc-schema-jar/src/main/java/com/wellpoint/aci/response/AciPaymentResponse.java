package com.wellpoint.aci.response;


import java.util.List;

public class AciPaymentResponse extends AciBaseResponse{	
	
	private static final long serialVersionUID = -6695666150917581788L; 
	
	private String tokenId;
	
	private boolean paymentMethodSaved;
	
	public boolean isPaymentMethodSaved() {
		return paymentMethodSaved;
	}

	public void setPaymentMethodSaved(boolean paymentMethodSaved) {
		this.paymentMethodSaved = paymentMethodSaved;
	}

	private List<PaymentAckDetail> paymentAckDetails;

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public List<PaymentAckDetail> getPaymentAckDetails() {
		return paymentAckDetails;
	}

	public void setPaymentAckDetails(List<PaymentAckDetail> paymentAckDetails) {
		this.paymentAckDetails = paymentAckDetails;
	}
	
	
	
	
	
	
}
