package com.wellpoint.aci.response;



public class AciPaymentDetail {
	
	private String paymentStatus;
	
	private String paymentAmount;
	
	private String paymentDate;
	
	private String paymentConfirmationNo;
	
	private FundingAccount fundingAccount;
	
	private RemittanceDetail remittanceDetail;

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentConfirmationNo() {
		return paymentConfirmationNo;
	}

	public void setPaymentConfirmationNo(String paymentConfirmationNo) {
		this.paymentConfirmationNo = paymentConfirmationNo;
	}

	public FundingAccount getFundingAccount() {
		return fundingAccount;
	}

	public void setFundingAccount(FundingAccount fundingAccount) {
		this.fundingAccount = fundingAccount;
	}

	public RemittanceDetail getRemittanceDetail() {
		return remittanceDetail;
	}

	public void setRemittanceDetail(RemittanceDetail remittanceDetail) {
		this.remittanceDetail = remittanceDetail;
	}
	
	
	
	
}
