/**
* MemberPayLoggingResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.response;



public class MemberPayLoggingResponse extends BaseResponse
{
	private static final long serialVersionUID = 8529635759308976914L;
	private boolean errorFlag;
	private String errorMessage;
	private String tptLogId;
	
	
	public String getTptLogId() {
		return tptLogId;
	}

	public void setTptLogId(String tptLogId) {
		this.tptLogId = tptLogId;
	}

	public boolean isErrorFlag()
	{
		return errorFlag;
	}

	public void setErrorFlag(boolean errorFlag)
	{
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
}
