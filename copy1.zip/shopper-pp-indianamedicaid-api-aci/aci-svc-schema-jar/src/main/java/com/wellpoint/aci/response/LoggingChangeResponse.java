/**
* LoggingChangeResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 05/02/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.response;


public class LoggingChangeResponse extends BaseResponse
{

	private static final long serialVersionUID = -7634428706697495544L;

	private String changeStatus;

	public String getChangeStatus() {
		return changeStatus;
	}

	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}
	

}
