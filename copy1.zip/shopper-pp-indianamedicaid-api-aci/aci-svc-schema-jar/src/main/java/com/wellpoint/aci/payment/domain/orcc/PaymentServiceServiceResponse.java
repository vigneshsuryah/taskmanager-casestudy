/**
* PaymentServiceServiceResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;


public class PaymentServiceServiceResponse  extends ConnectResponse
{

	private BillingAccount billingAccount;

	private String fundingTokenId;

	private BankAccount bankAccount;

	private CreditCardAccount creditCardAccount;

	private FlagField storeFundingFlag;

	private CreditDebitIndicator creditDebitIndicator;

	private NachaStandardEntryClass nachaStandardEntryClass;

	private String confirmationNumber;

	private XMLGregorianCalendar finalPaymentDate;

	private String responseCode;

	private String authorizationCode;

	private String addressValidationCode;

	private String securityResultCode;

	private String traceCode;

	private List<Remittance> remittance;

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public String getFundingTokenId()
	{
		return fundingTokenId;
	}

	public void setFundingTokenId(String fundingTokenId)
	{
		this.fundingTokenId = fundingTokenId;
	}

	public BankAccount getBankAccount()
	{
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount)
	{
		this.bankAccount = bankAccount;
	}

	public CreditCardAccount getCreditCardAccount()
	{
		return creditCardAccount;
	}

	public void setCreditCardAccount(CreditCardAccount creditCardAccount)
	{
		this.creditCardAccount = creditCardAccount;
	}

	public FlagField getStoreFundingFlag()
	{
		return storeFundingFlag;
	}

	public void setStoreFundingFlag(FlagField storeFundingFlag)
	{
		this.storeFundingFlag = storeFundingFlag;
	}

	public CreditDebitIndicator getCreditDebitIndicator()
	{
		return creditDebitIndicator;
	}

	public void setCreditDebitIndicator(CreditDebitIndicator creditDebitIndicator)
	{
		this.creditDebitIndicator = creditDebitIndicator;
	}

	public NachaStandardEntryClass getNachaStandardEntryClass()
	{
		return nachaStandardEntryClass;
	}

	public void setNachaStandardEntryClass(NachaStandardEntryClass nachaStandardEntryClass)
	{
		this.nachaStandardEntryClass = nachaStandardEntryClass;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public XMLGregorianCalendar getFinalPaymentDate()
	{
		return finalPaymentDate;
	}

	public void setFinalPaymentDate(XMLGregorianCalendar finalPaymentDate)
	{
		this.finalPaymentDate = finalPaymentDate;
	}

	public String getResponseCode()
	{
		return responseCode;
	}

	public void setResponseCode(String responseCode)
	{
		this.responseCode = responseCode;
	}

	public String getAuthorizationCode()
	{
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode)
	{
		this.authorizationCode = authorizationCode;
	}

	public String getAddressValidationCode()
	{
		return addressValidationCode;
	}

	public void setAddressValidationCode(String addressValidationCode)
	{
		this.addressValidationCode = addressValidationCode;
	}

	public String getSecurityResultCode()
	{
		return securityResultCode;
	}

	public void setSecurityResultCode(String securityResultCode)
	{
		this.securityResultCode = securityResultCode;
	}

	public String getTraceCode()
	{
		return traceCode;
	}

	public void setTraceCode(String traceCode)
	{
		this.traceCode = traceCode;
	}

	public List<Remittance> getRemittance()
	{
		return remittance;
	}

	public void setRemittance(List<Remittance> remittance)
	{
		this.remittance = remittance;
	}
}
