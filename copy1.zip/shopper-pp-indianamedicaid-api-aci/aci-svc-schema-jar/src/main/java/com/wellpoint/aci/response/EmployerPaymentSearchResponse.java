package com.wellpoint.aci.response;


import java.util.List;

public class EmployerPaymentSearchResponse extends EmployerBaseResponse{

	private static final long serialVersionUID = -496769461147342937L;
	
	private List<EmloyerPaymentDetail> emloyerPaymentDetails;
	
	private ResponseMessage responseMessage;
	
	public List<EmloyerPaymentDetail> getEmloyerPaymentDetails() {
		return emloyerPaymentDetails;
	}
	public void setEmloyerPaymentDetails(
			List<EmloyerPaymentDetail> emloyerPaymentDetails) {
		this.emloyerPaymentDetails = emloyerPaymentDetails;
	}
	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}
	
	
	

}
