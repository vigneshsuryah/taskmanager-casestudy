/**
* CustomFundingAccountTypeEnum.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.mam.utility;


public enum CustomFundingAccountTypeEnum {
	    PERSONAL_CHECKING("PERSONAL CHECKING"),
	    PERSONAL_SAVINGS("PERSONAL SAVINGS"),
	    BUSINESS_CHECKING("BUSINESS CHECKING"),
	    BUSINESS_SAVINGS("BUSINESS SAVINGS"),
	    MONEY_MARKET("MONEY MARKET"),
	    MC("MC"),
	    VISA("VISA"),
	    DISC("DISC"),
	    AMEX("AMEX"),
	    MASTERCARD("MASTERCARD");
	    private final String value;

	    CustomFundingAccountTypeEnum(String v) {
	        value = v;
	    }

	    public String value() {
	        return value;
	    }

	   
}
