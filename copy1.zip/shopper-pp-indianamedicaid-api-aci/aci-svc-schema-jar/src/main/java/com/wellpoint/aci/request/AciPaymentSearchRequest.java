package com.wellpoint.aci.request;



public class AciPaymentSearchRequest extends AciBaseRequest{

	private static final long serialVersionUID = 2061284613083384349L;

}
