/**
* PaymentInfo.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.math.BigDecimal;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;


public class PaymentInfo
{

	private PaymentStatus paymentStatus;

	private BigDecimal paymentAmount;

	private XMLGregorianCalendar paymentDate;

	private XMLGregorianCalendar cancelDate;

	private XMLGregorianCalendar returnDate;

	private String returnReason;
	private List<Reimbursements> reimbursement;

	private String confirmationNumber;

	private FundingAccount fundingAccount;

	private Remittance remittance;

	public PaymentStatus getPaymentStatus()
	{
		return paymentStatus;
	}

	public void setPaymentStatus(PaymentStatus paymentStatus)
	{
		this.paymentStatus = paymentStatus;
	}

	public BigDecimal getPaymentAmount()
	{
		return paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount)
	{
		this.paymentAmount = paymentAmount;
	}

	public XMLGregorianCalendar getPaymentDate()
	{
		return paymentDate;
	}

	public void setPaymentDate(XMLGregorianCalendar paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	public XMLGregorianCalendar getCancelDate()
	{
		return cancelDate;
	}

	public void setCancelDate(XMLGregorianCalendar cancelDate)
	{
		this.cancelDate = cancelDate;
	}

	public XMLGregorianCalendar getReturnDate()
	{
		return returnDate;
	}

	public void setReturnDate(XMLGregorianCalendar returnDate)
	{
		this.returnDate = returnDate;
	}

	public String getReturnReason()
	{
		return returnReason;
	}

	public void setReturnReason(String returnReason)
	{
		this.returnReason = returnReason;
	}

	public List<Reimbursements> getReimbursement()
	{
		return reimbursement;
	}

	public void setReimbursement(List<Reimbursements> reimbursement)
	{
		this.reimbursement = reimbursement;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public FundingAccount getFundingAccount()
	{
		return fundingAccount;
	}

	public void setFundingAccount(FundingAccount fundingAccount)
	{
		this.fundingAccount = fundingAccount;
	}

	public Remittance getRemittance()
	{
		return remittance;
	}

	public void setRemittance(Remittance remittance)
	{
		this.remittance = remittance;
	}
}
