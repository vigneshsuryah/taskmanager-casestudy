/**
* MemberTptServiceLog.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Transient;

public class MemberTptServiceLog implements Serializable
{
	private static final long serialVersionUID = -340506370915390470L;
	private BigDecimal tptTransId;
	
	private String outGoingReqId ;
	
	private String operationName;
	private String requestXML;
	private String responseXML;
	private Date requestTimeStamp;
	private Date responseTimeStamp;
	private String businessFault;
	private String systemFault;
	private String updatedId;
	private Date updatedDate;
	private String createdId;
	private Date createdDate;
	private String requestingSystem;
	@Transient
	private boolean ignoreStatusFromCcdi;
	public BigDecimal getTptTransId()
	{
		return tptTransId;
	}
	public void setTptTransId(BigDecimal tptTransId)
	{
		this.tptTransId = tptTransId;
	}
	public String getOutGoingReqId()
	{
		return outGoingReqId;
	}
	public void setOutGoingReqId(String outGoingReqId)
	{
		this.outGoingReqId = outGoingReqId;
	}
	public String getOperationName()
	{
		return operationName;
	}
	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}
	public String getRequestXML()
	{
		return requestXML;
	}
	public void setRequestXML(String requestXML)
	{
		this.requestXML = requestXML;
	}
	public String getResponseXML()
	{
		return responseXML;
	}
	public void setResponseXML(String responseXML)
	{
		this.responseXML = responseXML;
	}
	public Date getRequestTimeStamp()
	{
		return requestTimeStamp;
	}
	public void setRequestTimeStamp(Date requestTimeStamp)
	{
		this.requestTimeStamp = requestTimeStamp;
	}
	public Date getResponseTimeStamp()
	{
		return responseTimeStamp;
	}
	public void setResponseTimeStamp(Date responseTimeStamp)
	{
		this.responseTimeStamp = responseTimeStamp;
	}
	public String getBusinessFault()
	{
		return businessFault;
	}
	public void setBusinessFault(String businessFault)
	{
		this.businessFault = businessFault;
	}
	public String getSystemFault()
	{
		return systemFault;
	}
	public void setSystemFault(String systemFault)
	{
		this.systemFault = systemFault;
	}
	public String getUpdatedId()
	{
		return updatedId;
	}
	public void setUpdatedId(String updatedId)
	{
		this.updatedId = updatedId;
	}
	public Date getUpdatedDate()
	{
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate)
	{
		this.updatedDate = updatedDate;
	}
	public String getCreatedId()
	{
		return createdId;
	}
	public void setCreatedId(String createdId)
	{
		this.createdId = createdId;
	}
	public Date getCreatedDate()
	{
		return createdDate;
	}
	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}
	public boolean isIgnoreStatusFromCcdi()
	{
		return ignoreStatusFromCcdi;
	}
	public void setIgnoreStatusFromCcdi(boolean ignoreStatusFromCcdi)
	{
		this.ignoreStatusFromCcdi = ignoreStatusFromCcdi;
	}
	public String getRequestingSystem() {
		return requestingSystem;
	}
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
}
