package com.wellpoint.aci.response;


public class FundingAccount { 
	
	private String fundingAccountType;
	
	private String maskedAccountNo;
	 
	private String tokenId;
	
	private String accountNickname;
	
	public String getFundingAccountType() {
		return fundingAccountType; 
	}
	public void setFundingAccountType(String fundingAccountType) {
		this.fundingAccountType = fundingAccountType;
	}
	public String getMaskedAccountNo() {
		return maskedAccountNo;
	}
	public void setMaskedAccountNo(String maskedAccountNo) {
		this.maskedAccountNo = maskedAccountNo;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getAccountNickname() {
		return accountNickname;
	}
	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}
	
	
}
