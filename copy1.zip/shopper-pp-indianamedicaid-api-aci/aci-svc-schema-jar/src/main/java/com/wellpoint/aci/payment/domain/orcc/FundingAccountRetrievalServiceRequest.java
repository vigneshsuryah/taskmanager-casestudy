/**
* FundingAccountRetrievalServiceRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class FundingAccountRetrievalServiceRequest extends ConnectRequest
{
	private BillingAccount billingAccount;

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}
}
