/**
* Reimbursements.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.math.BigDecimal;

import javax.xml.datatype.XMLGregorianCalendar;


public class Reimbursements
{

	private BigDecimal reimbursementAmount;

	private XMLGregorianCalendar reimbursementDate;

	private String reimbursementReason;

	public BigDecimal getReimbursementAmount()
	{
		return reimbursementAmount;
	}

	public void setReimbursementAmount(BigDecimal reimbursementAmount)
	{
		this.reimbursementAmount = reimbursementAmount;
	}

	public XMLGregorianCalendar getReimbursementDate()
	{
		return reimbursementDate;
	}

	public void setReimbursementDate(XMLGregorianCalendar reimbursementDate)
	{
		this.reimbursementDate = reimbursementDate;
	}

	public String getReimbursementReason()
	{
		return reimbursementReason;
	}

	public void setReimbursementReason(String reimbursementReason)
	{
		this.reimbursementReason = reimbursementReason;
	}
}
