/**
* CustomCoverageTypeEnum.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.mam.utility;


public enum CustomCoverageTypeEnum
{

	MEDICAL("Medical Account"), DENTAL("Dental Account"), RX(""), VISION("Vision Account"), LIFE("Life Account"), ADD(""), STD(""), LTD(""), FSA(""), EAP(""), OTHER(""), QHE(""), MIA(""), HEARING("Hearing Account"), CHIROPRACTIC(""), HEALTHANDWELLNESS("");

	private String coverageType;
	
	CustomCoverageTypeEnum(String covType){	
		coverageType=covType;
	}
	
	public String showValue()
	{
		return coverageType;
	}

}
