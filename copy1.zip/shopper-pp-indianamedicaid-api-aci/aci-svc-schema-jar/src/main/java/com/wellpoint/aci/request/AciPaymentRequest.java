package com.wellpoint.aci.request;


import java.util.List;

public class AciPaymentRequest extends AciBaseRequest{


	private static final long serialVersionUID = 5913326199392395479L;
	private Boolean isNewPaymentMethod;
	
	private Boolean isForFutureUse;
	
	private BankAccountDetails bankAccountDetails;
	 
	private CreditCardDetails creditCardDetails;
	
	private List<AciPayment> aciPayments;
	
	private String divisionCode;
	
	private String paymentType;
	
	private String tokenId;
	
	private String paymentDate;

	//Added by Cognizant for TPP change July 2017 - Start
	private String bankAccountType;
	
	private String orgName;
	//Added by Cognizant for TPP change July 2017 - End
	
	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getDivisionCode() {
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public Boolean getIsNewPaymentMethod() {
		return isNewPaymentMethod;
	}

	public void setIsNewPaymentMethod(Boolean isNewPaymentMethod) {
		this.isNewPaymentMethod = isNewPaymentMethod;
	}

	public Boolean getIsForFutureUse() {
		return isForFutureUse;
	}

	public void setIsForFutureUse(Boolean isForFutureUse) {
		this.isForFutureUse = isForFutureUse;
	}

	public BankAccountDetails getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(BankAccountDetails bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public CreditCardDetails getCreditCardDetails() {
		return creditCardDetails;
	}

	public void setCreditCardDetails(CreditCardDetails creditCardDetails) {
		this.creditCardDetails = creditCardDetails;
	}

	public List<AciPayment> getAciPayments() {
		return aciPayments;
	}

	public void setAciPayments(List<AciPayment> aciPayments) {
		this.aciPayments = aciPayments;
	}

	//Added by Cognizant for TPP change July 2017 - Start
	/**
	 * @return the bankAccountType
	 */
	public String getBankAccountType() {
		return bankAccountType;
	}

	/**
	 * @param bankAccountType the bankAccountType to set
	 */
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	/**
	 * @return the orgName
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * @param orgName the orgName to set
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	//Added by Cognizant for TPP change July 2017 - End
}
