/**
* PaymentSearchServiceResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;


public class PaymentSearchServiceResponse extends ConnectResponse
{

	private XMLGregorianCalendar toDate;

	private BillingAccount billingAccount;

	private String confirmationNumber;

	private List<PaymentInfo> payment;

	private XMLGregorianCalendar fromDate;

	public XMLGregorianCalendar getFromDate()
	{
		return fromDate;
	}

	public void setFromDate(XMLGregorianCalendar fromDate)
	{
		this.fromDate = fromDate;
	}

	public XMLGregorianCalendar getToDate()
	{
		return toDate;
	}

	public void setToDate(XMLGregorianCalendar toDate)
	{
		this.toDate = toDate;
	}

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public List<PaymentInfo> getPayment()
	{
		return payment;
	}

	public void setPayment(List<PaymentInfo> payment)
	{
		this.payment = payment;
	}
}
