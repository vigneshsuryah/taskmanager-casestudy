package com.wellpoint.aci.request;




public class AciPayment {
	
	private String remitAmount;
	
	private String remitFee;
	
	private String remitField;
	
	private String paymentSubmissionId;
	
	private String productCode;
	
	private String employerEmail;
	
	/* Medsupp Changes - Starts*/
	private String divisionCode;
	/* Medsupp Changes - Ends*/
	
	public String getEmployerEmail()
	{
		return employerEmail;
	}
	public void setEmployerEmail(String employerEmail)
	{
		this.employerEmail = employerEmail;
	}
	public String getPaymentSubmissionId() {
		return paymentSubmissionId;
	}
	public void setPaymentSubmissionId(String paymentSubmissionId) {
		this.paymentSubmissionId = paymentSubmissionId;
	}
	public String getRemitAmount() {
		return remitAmount;
	}
	public void setRemitAmount(String remitAmount) {
		this.remitAmount = remitAmount;
	}
	public String getRemitFee() {
		return remitFee;
	}
	public void setRemitFee(String remitFee) {
		this.remitFee = remitFee;
	}
	public String getRemitField() {
		return remitField;
	}
	public void setRemitField(String remitField) {
		this.remitField = remitField;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/* Medsupp Changes - Starts*/
	/**
	 * @return the divisionCode
	 */
	public String getDivisionCode()
	{
		return divisionCode;
	}
	/**
	 * @param divisionCode the divisionCode to set
	 */
	public void setDivisionCode(String divisionCode)
	{
		this.divisionCode = divisionCode;
	}
	
	/* Medsupp Changes - Ends*/
	
	
}
