package com.wellpoint.aci.enums;

public enum AciFundingActionType {

	CREATE,MODIFY,DELETE,GETSUM
}
