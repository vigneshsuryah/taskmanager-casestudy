/**
* CreditCardAccount.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class CreditCardAccount extends FundingAccount
{

	private String creditCardNumber;

	private CreditCardType creditCardType;

	private String expirationMonth;

	private String expirationYear;

	private String securityCode;

	private String accountHolderName;

	private String accountAddress1;

	private String accountAddress2;

	private String accountCity;

	private String accountState;

	private String accountPostalCode;

	private CountryCode accountCountryCode;

	public String getCreditCardNumber()
	{
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber)
	{
		this.creditCardNumber = creditCardNumber;
	}

	public CreditCardType getCreditCardType()
	{
		return creditCardType;
	}

	public void setCreditCardType(CreditCardType creditCardType)
	{
		this.creditCardType = creditCardType;
	}

	public String getExpirationMonth()
	{
		return expirationMonth;
	}

	public void setExpirationMonth(String expirationMonth)
	{
		this.expirationMonth = expirationMonth;
	}

	public String getExpirationYear()
	{
		return expirationYear;
	}

	public void setExpirationYear(String expirationYear)
	{
		this.expirationYear = expirationYear;
	}

	public String getSecurityCode()
	{
		return securityCode;
	}

	public void setSecurityCode(String securityCode)
	{
		this.securityCode = securityCode;
	}

	public String getAccountHolderName()
	{
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName)
	{
		this.accountHolderName = accountHolderName;
	}

	public String getAccountAddress1()
	{
		return accountAddress1;
	}

	public void setAccountAddress1(String accountAddress1)
	{
		this.accountAddress1 = accountAddress1;
	}

	public String getAccountAddress2()
	{
		return accountAddress2;
	}

	public void setAccountAddress2(String accountAddress2)
	{
		this.accountAddress2 = accountAddress2;
	}

	public String getAccountCity()
	{
		return accountCity;
	}

	public void setAccountCity(String accountCity)
	{
		this.accountCity = accountCity;
	}

	public String getAccountState()
	{
		return accountState;
	}

	public void setAccountState(String accountState)
	{
		this.accountState = accountState;
	}

	public String getAccountPostalCode()
	{
		return accountPostalCode;
	}

	public void setAccountPostalCode(String accountPostalCode)
	{
		this.accountPostalCode = accountPostalCode;
	}

	public CountryCode getAccountCountryCode()
	{
		return accountCountryCode;
	}

	public void setAccountCountryCode(CountryCode accountCountryCode)
	{
		this.accountCountryCode = accountCountryCode;
	}
}
