/**
* MemberPayAccessProviderUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import org.apache.log4j.Logger;

import com.wellpoint.aci.exception.AciException;


public final class MemberPayAccessProviderUtils
{

	final static Logger LOGGER = Logger.getLogger(MemberPayAccessProviderUtils.class);
	
	private MemberPayAccessProviderUtils()
	{
		
	}

	public static Boolean authenticatePassword(String encryptedText, String key, String algorithm, String clearText)
			throws AciException
	{
		try
		{
			String decryptedText = MemberPayEncryptionUtils.getDecryptedText(key, algorithm, encryptedText);
			if (decryptedText.equals(clearText))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MemberPayAccessProviderUtils.authenticatePassword::" + e.getCause());
			throw new AciException("I","PP9027","Access Denied. In-Valid Password",401);
		}

	}

	public static Boolean authenticateUserName(String consumerUserName, String producerUserName) throws AciException
	{
		try
		{
			if (consumerUserName.equals(producerUserName))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MemberPayAccessProviderUtils.authenticateUserName::" + e.getCause());
			throw new AciException("I","PP9026", "Access Denied. In-Valid User Name",401);
		}
	}
	
	public static Boolean authenticateRequestingApplication(String requestingApplicationName, String allowedApplication) throws AciException
	{
		Boolean returnFlag = Boolean.FALSE;
		
		try
		{
			if (allowedApplication == null || allowedApplication.isEmpty() || requestingApplicationName == null || requestingApplicationName.isEmpty())
			{
				return returnFlag;
			}
			else
			{
				String[] applicationsList = allowedApplication.split(",");
				for(String nameVal :applicationsList)
				{
					if(requestingApplicationName.equalsIgnoreCase(nameVal))
					{
						returnFlag = Boolean.TRUE;
						break;
					}
				}
				return returnFlag; 
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in MemberPayAccessProviderUtils.authenticateRequestingApplication::" + e.getCause());
			throw new AciException("I","PP9044", "Access Denied. In-Valid Requesting Application",401);
		}
	}

}
