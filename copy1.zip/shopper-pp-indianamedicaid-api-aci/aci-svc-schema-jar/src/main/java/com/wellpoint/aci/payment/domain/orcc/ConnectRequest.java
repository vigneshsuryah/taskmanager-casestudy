/**
* ConnectRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class ConnectRequest
{

	private Identity identity;

	public void setIdentity(Identity identity)
	{
		this.identity = identity;
	}

	public Identity getIdentity()
	{
		return identity;
	}
}
