/**
* BankAccountType.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public enum BankAccountType
{
	PERSONAL_CHECKING("PERSONAL CHECKING"),

	PERSONAL_SAVINGS("PERSONAL SAVINGS"),

	BUSINESS_CHECKING("BUSINESS CHECKING"),

	BUSINESS_SAVINGS("BUSINESS SAVINGS"),

	MONEY_MARKET("MONEY MARKET");

	private final String value;

	private BankAccountType(String v)
	{
		this.value = v;
	}

	public String value()
	{
		return this.value;
	}

	public static BankAccountType fromValue(String v)
	{
		for (BankAccountType c : values())
		{
			if (c.value.equals(v))
			{
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
