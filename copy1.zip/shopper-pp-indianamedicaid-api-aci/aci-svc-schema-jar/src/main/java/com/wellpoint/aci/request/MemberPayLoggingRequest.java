/**
* MemberPayLoggingRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.request;


import com.wellpoint.aci.model.MemberPayTransLog;


public class MemberPayLoggingRequest extends BaseRequest
{
	private static final long serialVersionUID = 8602468603883813492L;
	private MemberPayTransLog memberpayTransLog;
	public MemberPayTransLog getMemberpayTransLog()
	{
		return memberpayTransLog;
	}

	public void setMemberpayTransLog(MemberPayTransLog memberpayTransLog)
	{
		this.memberpayTransLog = memberpayTransLog;
	}

}
