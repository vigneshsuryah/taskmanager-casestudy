/**
* FundingAccountRetrievalServiceResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.util.List;


public class FundingAccountRetrievalServiceResponse extends ConnectResponse
{

	private BillingAccount billingAccount;
	private List<BankAccount> bankAccount;
	private List<CreditCardAccount> creditCardAccount;

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public List<BankAccount> getBankAccount()
	{
		return bankAccount;
	}

	public void setBankAccount(List<BankAccount> bankAccount)
	{
		this.bankAccount = bankAccount;
	}

	public List<CreditCardAccount> getCreditCardAccount()
	{
		return creditCardAccount;
	}

	public void setCreditCardAccount(List<CreditCardAccount> creditCardAccount)
	{
		this.creditCardAccount = creditCardAccount;
	}
}
