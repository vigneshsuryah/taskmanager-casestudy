package com.wellpoint.aci.response;

import java.io.Serializable;


public class ResponseMessage implements Serializable {
	private static final long serialVersionUID = 1L;

	private String messageCode;
	
	private String messageDesc;

	public String getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getMessageDesc() {
		return messageDesc;
	}

	public void setMessageDesc(String messageDesc) {
		this.messageDesc = messageDesc;
	}
}
