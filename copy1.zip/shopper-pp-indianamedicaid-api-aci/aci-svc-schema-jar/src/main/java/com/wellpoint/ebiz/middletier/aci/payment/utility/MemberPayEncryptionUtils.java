/**
* MemberPayEncryptionUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.ebiz.middletier.aci.payment.utility;


import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

import com.wellpoint.aci.exception.AciException;


public final class MemberPayEncryptionUtils
{

	private MemberPayEncryptionUtils()
	{
	}

	public static String getDecryptedText(String key, String algorithm, String encryptedText) throws AciException
	{
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String decryptedText = "";
		try
		{
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			decryptedText = standardPBEStringEncryptor.decrypt(encryptedText);
		} catch (Exception e)
		{
			throw new AciException("E","PP9000","We've encountered a technical error",500);
		}
		return decryptedText;
	}

	public static String getEncryptedText(String key, String algorithm, String clearText) throws AciException
	{
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String encryptedText = "";
		try
		{
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			encryptedText = standardPBEStringEncryptor.encrypt(clearText);
		} catch (Exception e)
		{
			throw new AciException("E","PP9000","We've encountered a technical error",500);
		}
		return encryptedText;
	}

}
