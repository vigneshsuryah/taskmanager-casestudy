package com.wellpoint.aci.response;


import java.util.List;

public class EmployerPaymentResponse extends EmployerBaseResponse{	
	
	private static final long serialVersionUID = -6695666150917581788L; 
	
	private String tokenId;
	
	private List<PaymentAckDetail> paymentAckDetails;

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public List<PaymentAckDetail> getPaymentAckDetails() {
		return paymentAckDetails;
	}

	public void setPaymentAckDetails(List<PaymentAckDetail> paymentAckDetails) {
		this.paymentAckDetails = paymentAckDetails;
	}
	
	
	
	
	
	
}
