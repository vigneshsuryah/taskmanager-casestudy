package com.wellpoint.aci.response;


import java.util.List;

import com.wellpoint.aci.request.BankAccountDetails;
import com.wellpoint.aci.request.CreditCardDetails;


public class AciFundingResponse extends AciBaseResponse{

	private static final long serialVersionUID = 7185833140043049272L;
	private List<BankAccountDetails> bankAccountDetails;
	private List<CreditCardDetails> creditCardDetails;

	public List<BankAccountDetails> getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(List<BankAccountDetails> bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}

	public List<CreditCardDetails> getCreditCardDetails() {
		return creditCardDetails;
	}

	public void setCreditCardDetails(List<CreditCardDetails> creditCardDetails) {
		this.creditCardDetails = creditCardDetails;
	}	
	

}
