package com.wellpoint.aci.response;

import com.wellpoint.aci.model.MemberPayPaymentTypeEnum;


public class PaymentAckDetail {

	private String paymentStatus;
	
	private String confirmationNumber;
	
	private String paymentDate;
	
	private String paymentAmount;
	private MemberPayPaymentTypeEnum paymentType;
	private String paymentSubmissionId;	
	private String productCode;
	private String employerEmail;
	
	
	public String getEmployerEmail()
	{
		return employerEmail;
	}
	public void setEmployerEmail(String employerEmail)
	{
		this.employerEmail = employerEmail;
	}
	public String getPaymentSubmissionId() {
		return paymentSubmissionId;
	}
	public void setPaymentSubmissionId(String paymentSubmissionId) {
		this.paymentSubmissionId = paymentSubmissionId;
	}
	
	private ResponseMessage responseMessage;

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public MemberPayPaymentTypeEnum getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(MemberPayPaymentTypeEnum paymentType) {
		this.paymentType = paymentType;
	}	
	
}
