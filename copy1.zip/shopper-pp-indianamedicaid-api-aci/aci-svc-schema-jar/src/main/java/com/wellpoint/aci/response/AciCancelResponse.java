/**
* AciCancelResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.response;


public class AciCancelResponse extends AciBaseResponse
{

	private static final long serialVersionUID = -8466534542210198811L;

	private String paymentCancelStatus;
	
	private String paymentConfirmationNo;

	public String getPaymentCancelStatus()
	{
		return paymentCancelStatus;
	}

	public void setPaymentCancelStatus(String paymentCancelStatus)
	{
		this.paymentCancelStatus = paymentCancelStatus;
	}

	public String getPaymentConfirmationNo() {
		return paymentConfirmationNo;
	}

	public void setPaymentConfirmationNo(String paymentConfirmationNo) {
		this.paymentConfirmationNo = paymentConfirmationNo;
	}

}
