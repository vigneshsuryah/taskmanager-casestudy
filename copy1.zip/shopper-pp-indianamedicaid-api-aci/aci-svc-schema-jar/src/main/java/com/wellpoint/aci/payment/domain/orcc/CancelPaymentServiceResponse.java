/**
* CancelPaymentServiceResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class CancelPaymentServiceResponse extends ConnectResponse
{

	private Long paymentId;

	private String confirmationNumber;

	public void setPaymentId(Long paymentId)
	{
		this.paymentId = paymentId;
	}

	public Long getPaymentId()
	{
		return paymentId;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}
}
