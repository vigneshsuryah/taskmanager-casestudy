/**
* FundingAdminServiceRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class FundingAdminServiceRequest extends ConnectRequest
{

	private MaintenanceIndicator requestType;

	private BillingAccount billingAccount;

	private String fundingTokenId;

	private CreditCardAccount creditCardAccount;

	private BankAccount bankAccount;

	public MaintenanceIndicator getRequestType()
	{
		return requestType;
	}

	public void setRequestType(MaintenanceIndicator requestType)
	{
		this.requestType = requestType;
	}

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public String getFundingTokenId()
	{
		return fundingTokenId;
	}

	public void setFundingTokenId(String fundingTokenId)
	{
		this.fundingTokenId = fundingTokenId;
	}

	public CreditCardAccount getCreditCardAccount()
	{
		return creditCardAccount;
	}

	public void setCreditCardAccount(CreditCardAccount creditCardAccount)
	{
		this.creditCardAccount = creditCardAccount;
	}

	public BankAccount getBankAccount()
	{
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount)
	{
		this.bankAccount = bankAccount;
	}
}
