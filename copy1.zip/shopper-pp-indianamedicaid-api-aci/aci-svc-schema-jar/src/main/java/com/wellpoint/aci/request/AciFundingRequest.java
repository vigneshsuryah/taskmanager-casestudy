package com.wellpoint.aci.request;

import com.wellpoint.aci.enums.AciFundingActionType;

public class AciFundingRequest extends AciBaseRequest{

	private static final long serialVersionUID = 6844035108369218658L; 
	
	private AciFundingActionType fundingRequestActionType;
	private BankAccountDetails bankAccountDetails;
	private CreditCardDetails creditCardDetails;
	private String tokenId;
	public AciFundingActionType getFundingRequestActionType() {
		return fundingRequestActionType;
	}
	public void setFundingRequestActionType(
			AciFundingActionType fundingRequestActionType) {
		this.fundingRequestActionType = fundingRequestActionType;
	}
	public BankAccountDetails getBankAccountDetails() {
		return bankAccountDetails;
	}
	public void setBankAccountDetails(BankAccountDetails bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}
	public CreditCardDetails getCreditCardDetails() {
		return creditCardDetails;
	}
	public void setCreditCardDetails(CreditCardDetails creditCardDetails) {
		this.creditCardDetails = creditCardDetails;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
}
