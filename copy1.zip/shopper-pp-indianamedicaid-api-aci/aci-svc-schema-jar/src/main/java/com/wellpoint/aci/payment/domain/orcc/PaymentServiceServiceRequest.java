/**
* PaymentServiceServiceRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;


public class PaymentServiceServiceRequest  extends ConnectRequest
{

	private BillingAccount billingAccount;

	private String fundingTokenId;

	private BankAccount bankAccount;

	private CreditCardAccount creditCardAccount;

	private FlagField storeFundingFlag;

	private CreditDebitIndicator creditDebitIndicator;

	private NachaStandardEntryClass nachaStandardEntryClass;
	
	private EcommerceIndicator ecommerceIndicator;

	private XMLGregorianCalendar requestedPaymentDate;

	private List<Remittance> remittance;

	public BillingAccount getBillingAccount()
	{
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount)
	{
		this.billingAccount = billingAccount;
	}

	public String getFundingTokenId()
	{
		return fundingTokenId;
	}

	public void setFundingTokenId(String fundingTokenId)
	{
		this.fundingTokenId = fundingTokenId;
	}

	public BankAccount getBankAccount()
	{
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount)
	{
		this.bankAccount = bankAccount;
	}

	public CreditCardAccount getCreditCardAccount()
	{
		return creditCardAccount;
	}

	public void setCreditCardAccount(CreditCardAccount creditCardAccount)
	{
		this.creditCardAccount = creditCardAccount;
	}

	public FlagField getStoreFundingFlag()
	{
		return storeFundingFlag;
	}

	public void setStoreFundingFlag(FlagField storeFundingFlag)
	{
		this.storeFundingFlag = storeFundingFlag;
	}

	public CreditDebitIndicator getCreditDebitIndicator()
	{
		return creditDebitIndicator;
	}

	public void setCreditDebitIndicator(CreditDebitIndicator creditDebitIndicator)
	{
		this.creditDebitIndicator = creditDebitIndicator;
	}

	public NachaStandardEntryClass getNachaStandardEntryClass()
	{
		return nachaStandardEntryClass;
	}

	public void setNachaStandardEntryClass(NachaStandardEntryClass nachaStandardEntryClass)
	{
		this.nachaStandardEntryClass = nachaStandardEntryClass;
	}

	public XMLGregorianCalendar getRequestedPaymentDate()
	{
		return requestedPaymentDate;
	}

	public void setRequestedPaymentDate(XMLGregorianCalendar requestedPaymentDate)
	{
		this.requestedPaymentDate = requestedPaymentDate;
	}

	public List<Remittance> getRemittance()
	{
		return remittance;
	}

	public void setRemittance(List<Remittance> remittance)
	{
		this.remittance = remittance;
	}

	public void setEcommerceIndicator(EcommerceIndicator ecommerceIndicator) {
		this.ecommerceIndicator = ecommerceIndicator;
	}

	public EcommerceIndicator getEcommerceIndicator() {
		return ecommerceIndicator;
	}
}
