/**
* BaseResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.response;


import java.io.Serializable;

import com.wellpoint.aci.exception.AciException;


public class BaseResponse implements Serializable
{

	private static final long serialVersionUID = 8482083239638202067L;

	private AciException aciException;
	private Message message; 

	public void setMessage(Message message) {
		this.message = message;
	}

	public Message getMessage() {
		return message;
	}

	public AciException getAciException() {
		return aciException;
	}

	public void setAciException(AciException aciException) {
		this.aciException = aciException;
	}
}
