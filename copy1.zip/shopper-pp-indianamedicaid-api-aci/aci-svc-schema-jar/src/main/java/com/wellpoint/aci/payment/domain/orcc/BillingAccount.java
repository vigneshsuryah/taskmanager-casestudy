/**
* BillingAccount.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public class BillingAccount
{

	private String billingAccountNumber;

	private String divisionCode;

	public void setBillingAccountNumber(String billingAccountNumber)
	{
		this.billingAccountNumber = billingAccountNumber;
	}

	public String getBillingAccountNumber()
	{
		return billingAccountNumber;
	}

	public void setDivisionCode(String divisionCode)
	{
		this.divisionCode = divisionCode;
	}

	public String getDivisionCode()
	{
		return divisionCode;
	}
}
