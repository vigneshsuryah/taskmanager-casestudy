/**
* CreditCardType.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


public enum CreditCardType
{
	MC, VISA, DISC, AMEX, MASTERCARD;

	public String value()
	{
		return name();
	}

	public static CreditCardType fromValue(String v)
	{
		return valueOf(v);
	}
}
