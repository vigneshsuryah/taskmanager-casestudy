package com.wellpoint.aci.response;


import java.util.List;

public class AciPaymentSearchResponse extends AciBaseResponse{

	private static final long serialVersionUID = -496769461147342937L;
	
	private List<AciPaymentDetail> aciPaymentDetails;
	
	private ResponseMessage responseMessage;
	
	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<AciPaymentDetail> getAciPaymentDetails() {
		return aciPaymentDetails;
	}
	public void setAciPaymentDetails(List<AciPaymentDetail> aciPaymentDetails) {
		this.aciPaymentDetails = aciPaymentDetails;
	}
	
	
	

}
