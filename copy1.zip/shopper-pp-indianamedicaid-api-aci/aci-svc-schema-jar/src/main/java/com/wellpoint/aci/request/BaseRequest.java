/**
* BaseRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
* 05/16/2017  1.1      Cognizant       Modified by Cognizant for TPP change July 2017
*/
package com.wellpoint.aci.request;


import java.io.Serializable;


public class BaseRequest implements Serializable
{

	private static final long serialVersionUID = -8259955797943904092L;
	private RequestHeader requestHeader;
	private String hcid;
	private String requestingSystem;
	private String endPointName;
	//Modified by Cognizant for TPP change July 2017 - Start
	private String orgType;
	//Modified by Cognizant for TPP change July 2017 - End
	public RequestHeader getRequestHeader()
	{
		return requestHeader;
	}

	public void setRequestHeader(RequestHeader requestHeader)
	{
		this.requestHeader = requestHeader;
	}

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		if(hcid != null && hcid.length() == 9)
		{
			this.hcid = hcid.toUpperCase();
		}else
		{
			this.hcid = hcid;
		}
	}

	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}

	public String getRequestingSystem() {
		return requestingSystem;
	}

	public String getEndPointName() {
		return endPointName;
	}

	public void setEndPointName(String endPointName) {
		this.endPointName = endPointName;
	}

	//Modified by Cognizant for TPP change July 2017 - Start
	/**
	 * @return the orgType
	 */
	public String getOrgType() {
		return orgType;
	}

	/**
	 * @param orgType the orgType to set
	 */
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	//Modified by Cognizant for TPP change July 2017 - End
}
