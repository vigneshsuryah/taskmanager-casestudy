/**
* MemberPaySubmitPayment.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.wellpoint.aci.response.Message;

public class MemberPaySubmitPayment implements Serializable
{
	private static final long serialVersionUID = -1917181159218313938L;

	private BigDecimal id;

	private String submittedHcid;

	private String paymentHcid;

	private String contractCode;

	private String paymentAmount;

	private String confirmationNumber;

	private String tokenId;

	private String status;

	private String paymentDate;

	private String nameOfAccount;

	private String routingNumber;

	private String accNickName;

	private MemberPayPaymentTypeEnum paymentType;

	private MemberPayAddress billingAddress;

	private MemberPayAcctTypeEnum bankAccountType; 

	private String expiration;

	private String confirmAccountNo;
	
	private String subGroupId;
	
	private String summaryBillNo;
	
	private Message message; 
	
	private String firstName;
	private String lastName;
	private String state;
	private Date dateOfBirth;
	private String brand;
	private String mamStatusCode;
	private boolean whetherSummaryBillNo;
	
	private String subscriberId;
	private String memberSequenceNumber;
	
	
	private String requestingSystem;	

	public String getRequestingSystem() {
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem) {
		if(null!=requestingSystem && !requestingSystem.isEmpty()){
			this.requestingSystem = requestingSystem;
		}else{
			this.requestingSystem = "REIMAGINE";
		}
	}

	public String getAccNickName()
	{
		return accNickName;
	}

	public void setAccNickName(String accNickName)
	{
		this.accNickName = accNickName;
	}

	public MemberPayPaymentTypeEnum getPaymentType()
	{
		return paymentType;
	}

	public void setPaymentType(MemberPayPaymentTypeEnum paymentType)
	{
		this.paymentType = paymentType;
	}

	public MemberPayAddress getBillingAddress()
	{
		return billingAddress;
	}

	public void setBillingAddress(MemberPayAddress billingAddress)
	{
		this.billingAddress = billingAddress;
	}

	public MemberPayAcctTypeEnum getBankAccountType()
	{
		return bankAccountType;
	}

	public void setBankAccountType(MemberPayAcctTypeEnum bankAccountType)
	{
		this.bankAccountType = bankAccountType;
	}

	public String getExpiration()
	{
		return expiration;
	}

	public void setExpiration(String expiration)
	{
		this.expiration = expiration;
	}

	public String getConfirmAccountNo()
	{
		return confirmAccountNo;
	}

	public void setConfirmAccountNo(String confirmAccountNo)
	{
		this.confirmAccountNo = confirmAccountNo;
	}

	public BigDecimal getId()
	{
		return id;
	}

	public void setId(BigDecimal id)
	{
		this.id = id;
	}

	public String getSubmittedHcid()
	{
		return submittedHcid;
	}

	public void setSubmittedHcid(String submittedHcid)
	{
		this.submittedHcid = submittedHcid;
	}

	public String getPaymentHcid()
	{
		return paymentHcid;
	}

	public void setPaymentHcid(String paymentHcid)
	{
		this.paymentHcid = paymentHcid;
	}

	public String getContractCode()
	{
		return contractCode;
	}

	public void setContractCode(String contractCode)
	{
		this.contractCode = contractCode;
	}

	public String getPaymentAmount()
	{
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount)
	{
		this.paymentAmount = paymentAmount;
	}

	public String getConfirmationNumber()
	{
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber)
	{
		this.confirmationNumber = confirmationNumber;
	}

	public String getTokenId()
	{
		return tokenId;
	}

	public void setTokenId(String tokenId)
	{
		this.tokenId = tokenId;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getPaymentDate()
	{
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate)
	{
		this.paymentDate = paymentDate;
	}

	public String getNameOfAccount()
	{
		return nameOfAccount;
	}

	public void setNameOfAccount(String nameOfAccount)
	{
		this.nameOfAccount = nameOfAccount;
	}

	public String getRoutingNumber()
	{
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber)
	{
		this.routingNumber = routingNumber;
	}

	public void setSubGroupId(String subGroupId) {
		this.subGroupId = subGroupId;
	}

	public String getSubGroupId() {
		return subGroupId;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public Message getMessage() {
		return message;
	}

	public void setSummaryBillNo(String summaryBillNo) {
		this.summaryBillNo = summaryBillNo;
	}

	public String getSummaryBillNo() {
		return summaryBillNo;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getBrand() {
		return brand;
	}

	public void setMamStatusCode(String mamStatusCode) {
		this.mamStatusCode = mamStatusCode;
	}

	public String getMamStatusCode() {
		return mamStatusCode;
	}

	public void setWhetherSummaryBillNo(boolean whetherSummaryBillNo) {
		this.whetherSummaryBillNo = whetherSummaryBillNo;
	}

	public boolean isWhetherSummaryBillNo() {
		return whetherSummaryBillNo;
	}

	public void setMemberSequenceNumber(String memberSequenceNumber) {
		this.memberSequenceNumber = memberSequenceNumber;
	}

	public String getMemberSequenceNumber() {
		return memberSequenceNumber;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

}
