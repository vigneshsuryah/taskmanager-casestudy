/**
* EcommerceIndicator.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;

public enum EcommerceIndicator {

	ECOMMERCE("ECOMMERCE"), TELEPHONE("TELEPHONE"), RECURRING("RECURRING"), VOICE_RESPONSE_UNIT(
			"VOICE RESPONSE UNIT");

	private final String value;

	private EcommerceIndicator(String v) {
		this.value = v;
	}

	public String value() {
		return this.value;
	}

	public static EcommerceIndicator fromValue(String v) {
		for (EcommerceIndicator c : values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
