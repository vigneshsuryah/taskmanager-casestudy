/**
* AciCancelRequest.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.request;


public class AciCancelRequest extends AciBaseRequest
{

	private static final long serialVersionUID = 983772060488094869L;
	private String paymentConfirmationNo;
	public String getPaymentConfirmationNo() {
		return paymentConfirmationNo;
	}
	public void setPaymentConfirmationNo(String paymentConfirmationNo) {
		this.paymentConfirmationNo = paymentConfirmationNo;
	}

	

}
