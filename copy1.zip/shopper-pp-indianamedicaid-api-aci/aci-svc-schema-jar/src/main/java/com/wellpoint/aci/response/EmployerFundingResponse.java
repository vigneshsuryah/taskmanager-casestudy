package com.wellpoint.aci.response;


import java.util.List;

import com.wellpoint.aci.request.BankAccountDetails;


public class EmployerFundingResponse extends EmployerBaseResponse{

	private static final long serialVersionUID = 2647092982693123552L;
	
	private List<BankAccountDetails> bankAccountDetails;

	public List<BankAccountDetails> getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(List<BankAccountDetails> bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}	
	

}
