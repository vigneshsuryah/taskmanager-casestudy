package com.wellpoint.aci.response;



public class AciBaseResponse extends BaseResponse{

	private static final long serialVersionUID = 4327264193867444318L;

	private String ackStatus;
	private String userId;	
	private ResponseMessage responseMessage;	
	private String requestingSystem;
	

	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAckStatus() {
		return ackStatus;
	}

	public void setAckStatus(String ackStatus) {
		this.ackStatus = ackStatus;
	}

	public String getRequestingSystem() {
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}

	
}
