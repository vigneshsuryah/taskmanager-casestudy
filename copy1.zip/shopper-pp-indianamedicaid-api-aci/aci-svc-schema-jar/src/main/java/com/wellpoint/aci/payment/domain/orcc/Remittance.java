/**
* Remittance.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.payment.domain.orcc;


import java.math.BigDecimal;
import java.util.List;


public class Remittance
{

	private BigDecimal remitAmount;

	private BigDecimal remitFee;

	private String feeWaiverReason;

	private List<PaymentRemitField> paymentRemitField;
	
	private BillingAccount billingAccount;
	

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	public BigDecimal getRemitAmount()
	{
		return remitAmount;
	}

	public void setRemitAmount(BigDecimal remitAmount)
	{
		this.remitAmount = remitAmount;
	}

	public BigDecimal getRemitFee()
	{
		return remitFee;
	}

	public void setRemitFee(BigDecimal remitFee)
	{
		this.remitFee = remitFee;
	}

	public String getFeeWaiverReason()
	{
		return feeWaiverReason;
	}

	public void setFeeWaiverReason(String feeWaiverReason)
	{
		this.feeWaiverReason = feeWaiverReason;
	}

	public List<PaymentRemitField> getPaymentRemitField()
	{
		return paymentRemitField;
	}

	public void setPaymentRemitField(List<PaymentRemitField> paymentRemitField)
	{
		this.paymentRemitField = paymentRemitField;
	}
}
