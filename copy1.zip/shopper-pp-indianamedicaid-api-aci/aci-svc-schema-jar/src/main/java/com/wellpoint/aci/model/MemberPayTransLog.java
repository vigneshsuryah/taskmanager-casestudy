/**
* MemberPayTransLog.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


public class MemberPayTransLog implements Serializable
{
	private static final long serialVersionUID = -5154713930571769197L;
	private BigDecimal rsTransId;
	private String hcid;
	private String channel;
	private String operationName;
	private String requestXML;
	private String responseXML;
	private String errorMsg;
	private Date createdDate;
	private Date requestTime;
	private boolean isBusinesssFault;
	private boolean isSystemFault;
	private boolean ignoreStatusFromCcdi;
	private Date startTime;
	private Date endTime;

	public Date getRequestTime()
	{
		return requestTime;
	}

	public void setRequestTime(Date requestTime)
	{
		this.requestTime = requestTime;
	}

	public BigDecimal getRsTransId()
	{
		return rsTransId;
	}

	public void setRsTransId(BigDecimal rsTransId)
	{
		this.rsTransId = rsTransId;
	}

	public String getHcid()
	{
		return hcid;
	}

	public void setHcid(String hcid)
	{
		this.hcid = hcid;
	}

	public String getChannel()
	{
		return channel;
	}

	public void setChannel(String channel)
	{
		this.channel = channel;
	}

	public String getOperationName()
	{
		return operationName;
	}

	public void setOperationName(String operationName)
	{
		this.operationName = operationName;
	}

	public String getRequestXML()
	{
		return requestXML;
	}

	public void setRequestXML(String requestXML)
	{
		this.requestXML = requestXML;
	}

	public String getResponseXML()
	{
		return responseXML;
	}

	public void setResponseXML(String responseXML)
	{
		this.responseXML = responseXML;
	}

	public String getErrorMsg()
	{
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

	public Date getCreatedDate()
	{
		return createdDate;
	}

	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

	public boolean isBusinesssFault() {
		return isBusinesssFault;
	}

	public void setBusinesssFault(boolean isBusinesssFault) {
		this.isBusinesssFault = isBusinesssFault;
	}

	public boolean isSystemFault() {
		return isSystemFault;
	}

	public void setSystemFault(boolean isSystemFault) {
		this.isSystemFault = isSystemFault;
	}

	public boolean isIgnoreStatusFromCcdi() {
		return ignoreStatusFromCcdi;
	}

	public void setIgnoreStatusFromCcdi(boolean ignoreStatusFromCcdi) {
		this.ignoreStatusFromCcdi = ignoreStatusFromCcdi;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
}
