/**
* RequestHeader.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
*/
package com.wellpoint.aci.request;

import java.io.Serializable;


public class RequestHeader implements Serializable
{
	private static final long serialVersionUID = 3098850963927720479L;
	private String userName;
	private String password;
	/*private String requestApplication;*/

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	/*public void setRequestApplication(String requestApplication) {
		this.requestApplication = requestApplication;
	}

	public String getRequestApplication() {
		return requestApplication;
	}*/

}
