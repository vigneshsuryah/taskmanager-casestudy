package com.wellpoint.aci.request;


public class AciBaseRequest extends BaseRequest{

	private static final long serialVersionUID = 113063741695450066L;

}
