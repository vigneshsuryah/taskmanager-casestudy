package com.wellpoint.aci.enums;


public enum CreditCardType
{
	MC, VISA, DISC, AMEX, MASTERCARD;

	public String value()
	{
		return name();
	}

	public static CreditCardType fromValue(String v)
	{
		return valueOf(v);
	}
}
