/**
* EnvironmentAwareAppContextInitializer.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 30/06/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.config;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.web.context.ConfigurableWebApplicationContext;
import org.springframework.web.context.ConfigurableWebEnvironment;

public class EnvironmentAwareAppContextInitializer implements ApplicationContextInitializer<ConfigurableWebApplicationContext>
{
	private static final String ENVIRONMENT_KEY = "eox.environment";

	@Override
	public void initialize(ConfigurableWebApplicationContext applicationContext)
	{
		ConfigurableWebEnvironment environment = (ConfigurableWebEnvironment) applicationContext.getEnvironment();
		if (environment != null)
		{
			String env = System.getProperty(ENVIRONMENT_KEY);
			if (env != null && !env.isEmpty())
			{
				environment.addActiveProfile(env);
			}
		}
	}
}
