package com.wellpoint.middletier.gbd.gateway.exception;

import java.util.List;

public class PaymentModException extends Exception{

	private static final long serialVersionUID = 1L;
	
	private Exceptions[] exceptions;
	private String errorCode;
	private String errorMessage;
	private String errorType;
	private int returnStatus;
	public PaymentModException(){}
	
	public PaymentModException(String errorType,String errorCode, String errorMessage, int returnStatus){
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorType = errorType;
		this.setReturnStatus(returnStatus);
	}
	public PaymentModException(Exceptions[] exceptions , int returnStatus){
		super();
		this.exceptions = exceptions;
		this.setReturnStatus(returnStatus);
	}
	public RestError transformException() {
		RestError restError = new RestError();
		restError.setExceptions(this.exceptions);
		return restError;
	}

	public int getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(int returnStatus) {
		this.returnStatus = returnStatus;
	}
	
}
