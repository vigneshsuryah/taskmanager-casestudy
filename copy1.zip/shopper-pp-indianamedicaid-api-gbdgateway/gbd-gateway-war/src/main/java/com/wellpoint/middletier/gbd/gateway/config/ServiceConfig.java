/**
* ServiceConfig.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 30/06/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.config;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.FixedDelayPollingScheduler;
import com.netflix.config.sources.URLConfigurationSource;


@Configuration
@PropertySources(value = { @PropertySource("classpath:gateway-app.properties") })
@ImportResource({
	"classpath:gateway-app-config.xml"
})
public class ServiceConfig extends WebMvcConfigurerAdapter {
	
	public static final String DEFAULT_RESOURCE_LOCATION = "/wsapps/eox/deployment/config/memberpay/gbd/gateway/gateway-app.properties";
	public static final String DEFAULT_RESOURCE_KEY = "gbd.setting.archaius.resource.location";
	public static final int DEFAULT_RESOURCE_POLLTIME = 300000;
	public static final String DEFAULT_RESOURCE_POLLTIME_KEY = "gbd.setting.archaius.resource.poll.time";
	
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resource*").addResourceLocations("/resource/*").
                addResourceLocations("/resource/");
    }

	@Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
	
	@Bean
	public String loadArchaiusProps() throws IOException {
		String resourceLocation = "file:" + ApplicationPropertiesUI.getStringProperty(DEFAULT_RESOURCE_KEY, DEFAULT_RESOURCE_LOCATION);
		int resourcePollTime = Integer.valueOf(ApplicationPropertiesUI.getStringProperty(DEFAULT_RESOURCE_POLLTIME_KEY,String.valueOf(DEFAULT_RESOURCE_POLLTIME)));
		URLConfigurationSource src = new URLConfigurationSource(resourceLocation);
		DynamicConfiguration configuration = new DynamicConfiguration(src,new FixedDelayPollingScheduler(0, resourcePollTime, true));
		configuration.stopLoading();
		ConfigurationManager.install(configuration);
		return "";
	}
}

