package com.wellpoint.middletier.gbd.gateway.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.wellpoint.middletier.gbd.gateway.bo.DeleteUserAccountResponse;
import com.wellpoint.middletier.gbd.gateway.bo.DeleteUserAccountRestResponse;
import com.wellpoint.middletier.gbd.gateway.bo.LoginResponse;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.middletier.gbd.gateway.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.gateway.response.SearchUserDetailsRestResponse;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;

@Controller  
public class TpcRestController implements GbdConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(TpcRestController.class);
	@Autowired
	private ApplicationPropertiesUI applicationProperties;	
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private GbdUtil gbdUtil;
	
	public String getSecureRestPath() {
		return applicationProperties.getStringProperty("gbd.setting.rest.service.endpoint");
	}

	@RequestMapping(value = "/tpclogin/generateTokenWithSMHeaders", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody LoginResponse generateTokenWithSMHeaders(HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in generateTokenWithSMHeaders() of GbdGatewayRestController");
		LoginResponse response = new LoginResponse();
		try{
			String userName = httpRequest.getHeader("SM_USER");
			String userDn = httpRequest.getHeader("SM_USERDN");
			if(null == userName || userName.isEmpty()){
				throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
			}else{
				String jwtToken=gbdUtil.getJWTToken(userName, applicationProperties.getStringProperty("gbd.setting.member.jwt.secret.key"));
				
				SearchUserDetailsRestRequest searchUserDetailsRestRequest = new SearchUserDetailsRestRequest();
				searchUserDetailsRestRequest.setUserName(userName);
				HttpEntity<Object> requestEntity = new HttpEntity<Object>(searchUserDetailsRestRequest,getTPCLoginHttpHeaders(httpRequest));			
				SearchUserDetailsRestResponse searchUserDetailsRestResponse = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/getRegisterUserDetails",requestEntity, SearchUserDetailsRestResponse.class);
				
				response.setAuthToken(jwtToken);
				response.setUserDn(userDn);
				if(null != searchUserDetailsRestResponse.getUser()){
					response.setRelShpType(searchUserDetailsRestResponse.getUser().getOrgType());
					response.setRelShpName(searchUserDetailsRestResponse.getUser().getOrgName());
					response.setUserName(searchUserDetailsRestResponse.getUser().getUsername());
					response.setAuthFlag(searchUserDetailsRestResponse.getUser().isAuthFlag());
				}else{
					response.setUserName(userName);
				}
				
				String aciEnableFlag = getAciEnableFlag();
				if(null != aciEnableFlag && !aciEnableFlag.isEmpty() && aciEnableFlag.equalsIgnoreCase("true")){
					response.setAciFlag(true);
				}else{
					response.setAciFlag(false);
				}
			}
		}catch(Exception e){
			LOGGER.error("Exception in getToken() of Gateway "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}	
	
	public String getAciEnableFlag() {
		return applicationProperties.getStringProperty("tpp.setting.aci.sections.enable.flag");
	}

	@RequestMapping(value = "/tpcloginservices/v1/gbd/register/createuser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object createuser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in createuser() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/createuser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in createuser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/register/getSecretQuestions", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getSecretQuestions(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getSecretQuestions() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/getSecretQuestions",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getSecretQuestions() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/register/validateSecretAnswerForForgotPassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateSecretAnswerForForgotPassword(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateSecretAnswerForForgotPassword() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/validateSecretAnswerForForgotPassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotPassword() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/register/validateSecretAnswerForForgotUserName", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateSecretAnswerForForgotUserName(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateSecretAnswerForForgotUserName() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/validateSecretAnswerForForgotUserName",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotUserName() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object changePasswordUnSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in changePasswordUnSecure() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/changePassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in changePasswordUnSecure() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object searchUserUnSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in searchUser() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/searchUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in searchUser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}	
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/getUserIdDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getUserIdDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getUserIdDetails() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/getUserIdFromEmailId",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getUserIdDetails() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/deleteUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object deleteUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in deleteUser() of TpcRestController");
		Object response = null;
		Boolean deleteUserAccountResponse = false;
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));	
			deleteUserAccountResponse = (Boolean) restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/deleteRecurringSetup",requestEntity, Object.class);
			if(deleteUserAccountResponse) {
				response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/deleteUser",requestEntity, Object.class);
			} else {
				response = new DeleteUserAccountRestResponse();
				((DeleteUserAccountRestResponse) response).setDeleteUserStatus(false);
			}
		}catch(Exception e){
			LOGGER.error("Exception in deleteUser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object searchUserSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in searchUser() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/searchUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in searchUser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/authenticateUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object authenticateUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in authenticateUser() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/authenticateUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in authenticateUser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/modifyUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object modifyUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in modifyUser() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/modifyUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in modifyUser() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object changePasswordSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in changePasswordSecure() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/changePassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in changePasswordSecure() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/account/getFaqQnA", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getFaqQnA(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getFaqQnA() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/getFaqQnA",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getFaqQnA() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	private HttpHeaders getTPCLoginHttpHeaders(HttpServletRequest httpRequest){
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		if(null == senderApp){
			senderApp = "TPC";
		}
		String senderAppKey = applicationProperties.getStringProperty("gbd.meta.senderapp.secretkey." + senderApp);
		senderAppKey = GbdUtil.getDecodedText(senderAppKey);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", senderApp);
		headers.add("meta-senderapp-key", senderAppKey);
		return headers;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/getTPCMembers", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getTPCMembers(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getTPCMembers() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/getTPCMembers",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getTPCMembers() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/updateTPCMembers", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateTPCMembers(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateTPCMembers() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/updateTPCMembers",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in updateTPCMembers() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/getTPCPaymentMethods", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getTPCPaymentMethods(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getTPCPaymentMethods() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/getTPCPaymentMethods",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getTPCPaymentMethods() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/updateTPCPaymentMethods", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateTPCPaymentMethods(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateTPCPaymentMethods() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/updateTPCPaymentMethods",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in updateTPCPaymentMethods() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/getTPCRecurringPaymentDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getTPCRecurringPaymentDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getTPCRecurringPaymentDetails() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/getTPCRecurringPaymentDetails",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getTPCRecurringPaymentDetails() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/updateTPCRecurringPayments", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateTPCRecurringPayment(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateTPCRecurringPayment() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/updateTPCRecurringPayments",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in updateTPCRecurringPayment() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/cancelTPCPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object cancelTPCPayment(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in cancelTPCPayment() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/cancelTPCPayment",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in cancelTPCPayment() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/tpc/myaccount/submitTPCPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object submitTPCPayment(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in submitTPCPayment() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPCLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/pportmembersvcV2/tpcsecure/submitTPCPayment",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in submitTPCPayment() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	/*2fa change for TPP/KYTPP starts here*/
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/validateLoginInformation", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateLoginInformation(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateLoginInformation() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/validateLoginInformation",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateLoginInformation() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/validateRegisterUserDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateRegisterUserDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateRegisterUserDetails() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/validateRegisterUserDetails",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateRegisterUserDetails() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/otp/attemptsRemaining", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object attemptsRemaining(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/attemptsRemaining() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/attemptsRemaining",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/attemptsRemaining() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/users/profile", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object usersProfile(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in users/profile() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/users/profile",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in users/profile() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/threatapi", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object threatapi(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in threatapi() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/threatapi",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in threatapi() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/dfp/save", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object dfpSave(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in dfp/save() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/dfp/save",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in dfp/save() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/getChannelDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getChannelDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in dfp/save() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/getChannelDetails",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in dfp/save() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/otp/send", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object otpSend(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/send() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/send",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/send() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/tpcloginservices/v1/gbd/account/otp/validate", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object otpValidate(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/validate() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/validate",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/validate() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundindv/secure/v1/gbd/account/updateAuthFlag", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateAuthFlag(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateAuthFlag() of TpcRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/updateAuthFlag",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in updateAuthFlag() of TpcRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	private HttpHeaders get2FAHttpHeaders(HttpServletRequest httpRequest){
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		if(null == senderApp){
			senderApp = "TPC";
		}
		String senderAppKey = applicationProperties.getStringProperty("gbd.meta.senderapp.secretkey." + senderApp);
		senderAppKey = GbdUtil.getDecodedText(senderAppKey);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", senderApp);
		headers.add("meta-senderapp-key", senderAppKey);
		String ipaddress = getHeaderValueFromRequest(httpRequest, "ipaddress");
		if(!ipaddress.isEmpty()) {
			headers.add("ipaddress", getIpAddress(httpRequest));
		}
		String senderapp = getHeaderValueFromRequest(httpRequest, "senderapp");
		if(!senderapp.isEmpty()) {
			headers.add("senderapp", senderapp);
		}
		String webguid = getHeaderValueFromRequest(httpRequest, "webguid");
		if(!webguid.isEmpty()) {
			headers.add("webguid", webguid);
		}
		String module = getHeaderValueFromRequest(httpRequest, "module");
		if(!module.isEmpty()) {
			headers.add("module", module);
		}
		String usernm = getHeaderValueFromRequest(httpRequest, "usernm");
		if(!usernm.isEmpty()) {
			headers.add("usernm", usernm);
		}
		return headers;
	}

	public static String getHeaderValueFromRequest(HttpServletRequest httpRequest, String headerName) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader(headerName);
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching header - " + headerName + " - value");
        }
        return value == null ? "":value;
    }
	
	public static String getIpAddress(HttpServletRequest request) {
        String xffStr = StringUtils.defaultString(request.getHeader("x-forwarded-for"));
        if (StringUtils.isEmpty(xffStr)) {
            xffStr = StringUtils.defaultString(request.getRemoteAddr());
        }
        return xffStr;
    }
	
	/*2fa change for TPP/KYTPP ends here*/
	
}
