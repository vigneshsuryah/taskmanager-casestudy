/**
 * DeleteUserAccountRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.gateway.bo;

public class DeleteUserAccountRestResponse {
	
	private boolean deleteUserStatus;
	
	public boolean isDeleteUserStatus() {
		return deleteUserStatus;
	}
	public void setDeleteUserStatus(boolean deleteUserStatus) {
		this.deleteUserStatus = deleteUserStatus;
	}
}
