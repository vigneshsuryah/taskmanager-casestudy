/**
 * GbdGatewayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 08/09/2018  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.gateway.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.remoting.jaxws.JaxWsSoapFaultException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.ebiz.middletier.enrollment.message.GetApplicationRequest;
import com.wellpoint.ebiz.middletier.enrollment.message.GetApplicationResponse;
import com.wellpoint.ebiz.middletier.enrollment.message.SetPaymentRequest;
import com.wellpoint.ebiz.middletier.enrollment.message.SetPaymentResponse;
import com.wellpoint.ebiz.middletier.enrollment.message.SubmitApplicationRequest;
import com.wellpoint.ebiz.middletier.enrollment.message.SubmitApplicationResponse;
import com.wellpoint.ebiz.middletier.enrollment.service.ApplicationCaptureService;
import com.wellpoint.ebiz.middletier.enrollment.service.GetApplicationFault;
import com.wellpoint.ebiz.middletier.enrollment.service.GetApplicationFault1;
import com.wellpoint.ebiz.middletier.enrollment.service.SetPaymentFault;
import com.wellpoint.ebiz.middletier.enrollment.service.SetPaymentFault1;
import com.wellpoint.ebiz.middletier.enrollment.service.SubmitApplicationFault;
import com.wellpoint.ebiz.middletier.enrollment.service.SubmitApplicationFault1;
import com.wellpoint.ebiz.middletier.message.BusinessError;
import com.wellpoint.ebiz.middletier.message.SystemError;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;


@Controller
public class EnrollmentServiceRestController implements GbdConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(EnrollmentServiceRestController.class);
	
	@Autowired
	private ApplicationCaptureService applicationCaptureService;
	
	@RequestMapping(value = "/csr/secure/v1/enroll/setPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetPaymentResponse setPayment(@RequestBody SetPaymentRequest request, HttpServletRequest httpRequest) throws GbdException {
		SetPaymentResponse rsResponse = new SetPaymentResponse();
		try {
			rsResponse = applicationCaptureService.setPayment(request);
		} catch (SetPaymentFault e) {
			LOGGER.error("SetPaymentFault occurred in EnrollmentServiceRestController setPayment : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getBusinessErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (SetPaymentFault1 e) {
			LOGGER.error("SetPaymentFault1 occurred in EnrollmentServiceRestController setPayment : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getSystemErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (JaxWsSoapFaultException e) {
			LOGGER.error("JaxWsSoapFaultException occurred in EnrollmentServiceRestController setPayment : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (Exception e) {
			LOGGER.error("Exception occurred in EnrollmentServiceRestController setPayment : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return rsResponse;
	}
	
	@RequestMapping(value = "/csr/secure/v1/enroll/submitApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SubmitApplicationResponse submitApplication(@RequestBody SubmitApplicationRequest request, HttpServletRequest httpRequest) throws GbdException {
		SubmitApplicationResponse rsResponse = new SubmitApplicationResponse();
		try {
			rsResponse = applicationCaptureService.submitApplication(request);
		} catch (SubmitApplicationFault e) {
			LOGGER.error("SubmitApplicationFault occurred in EnrollmentServiceRestController submitApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getBusinessErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (SubmitApplicationFault1 e) {
			LOGGER.error("SubmitApplicationFault1 occurred in EnrollmentServiceRestController submitApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getSystemErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (JaxWsSoapFaultException e) {
			LOGGER.error("JaxWsSoapFaultException occurred in EnrollmentServiceRestController submitApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (Exception e) {
			LOGGER.error("Exception occurred in EnrollmentServiceRestController submitApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return rsResponse;
	}
	
	@RequestMapping(value = "/csr/secure/v1/enroll/getApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetApplicationResponse getApplication(@RequestBody GetApplicationRequest request, HttpServletRequest httpRequest) throws GbdException {
		GetApplicationResponse rsResponse = new GetApplicationResponse();
		try {
			rsResponse = applicationCaptureService.getApplication(request);
		} catch (GetApplicationFault e) {
			LOGGER.error("GetApplicationFault occurred in EnrollmentServiceRestController getApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getBusinessErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (GetApplicationFault1 e) {
			LOGGER.error("GetApplicationFault1 occurred in EnrollmentServiceRestController getApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_INVALID_INPUT, getSystemErrorMsg(e.getFaultInfo(), e.getMessage()), REST_ERROR_400);
		} catch (JaxWsSoapFaultException e) {
			LOGGER.error("JaxWsSoapFaultException occurred in EnrollmentServiceRestController getApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (Exception e) {
			LOGGER.error("Exception occurred in EnrollmentServiceRestController getApplication : " + e);
			throw new GbdException(ERROR_TYPE, IPP_TECH_ERROR_CODE, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return rsResponse;
	}
	
	private String getBusinessErrorMsg(BusinessError e, String errorMsg) {
		String desc = "";
		if(null != e && null != e.getError() && e.getError().length > 0) {
			desc = e.getError(0).getDescription();
		} else {
			desc = errorMsg;
		}
		return desc;
	}
	
	private String getSystemErrorMsg(SystemError e, String errorMsg) {
		String desc = "";
		if(null != e && null != e.getDescription()) {
			desc = e.getDescription();
		} else {
			desc = errorMsg;
		}
		return desc;
	}
}
