/**
* GbdHelperUtils.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 12/10/2015  1.0      Cognizant       Initial Version
* 05/16/2017  1.1      Cognizant       Modified by Cognizant for TPP change July 2017
*/
package com.wellpoint.midletier.gbd.gateway.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellpoint.ebiz.middletier.pport.payment.utility.MemberPayEncryptionUtils;
import com.wellpoint.memberpay.request.BaseRequest;
import com.wellpoint.memberpay.request.RequestHeader;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;


@Component
public class GbdHelperUtils implements GbdConstants
{
	@Autowired
	private ApplicationPropertiesUI applicationProperties;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GbdHelperUtils.class);

	//Modified by Cognizant for TPP change July 2017 - Start
	@SuppressWarnings("unchecked")
	public <T extends Object> T getRequestInstance(Class<T> targetClass, String senderApp) throws GbdException
	{
		BaseRequest request = null;
		try
		{
			LOGGER.info("Inside GbdHelperUtils.getRequestInstance ");
			RequestHeader requestHeader = new RequestHeader();
			requestHeader.setPassword(MemberPayEncryptionUtils.getEncryptedText(getSecureKey(senderApp), getSecureAlgorithm(senderApp), getSecurePassword(senderApp)));
			requestHeader.setUserName(getSecureUserName(senderApp));
			request = (BaseRequest) targetClass.newInstance();
			request.setRequestHeader(requestHeader);
			LOGGER.info("Request header has been set for the class::"+targetClass.getCanonicalName());
		} catch (Exception e)
		{
			LOGGER.error("Possibly illegal class passed as argument::"+e.getCause());
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return (T) request;
	}

	protected String getSecureUserName(String senderApp) {
		String userName = GbdConstants.EMPTY;
		if(null != senderApp && GbdConstants.TPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			userName = applicationProperties.getStringProperty("tpp.setting.payment.ui.restconsumer.service.username");
		} else if(null != senderApp && GbdConstants.KYTPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			userName = applicationProperties.getStringProperty("kytpp.setting.payment.ui.restconsumer.service.username");
		} else if(null != senderApp && GbdConstants.KYPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			userName = applicationProperties.getStringProperty("kypp.setting.payment.ui.restconsumer.service.username");
		} else {
			userName = applicationProperties.getStringProperty("gbd.setting.payment.ui.restconsumer.service.username");
		}
		return userName;
	}

	protected String getSecurePassword(String senderApp) {
		String pwd = GbdConstants.EMPTY;
		if(null != senderApp && GbdConstants.TPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			pwd = applicationProperties.getStringProperty("tpp.setting.payment.ui.restconsumer.service.password");
		} else if(null != senderApp && GbdConstants.KYTPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			pwd = applicationProperties.getStringProperty("kytpp.setting.payment.ui.restconsumer.service.password");
		} else if(null != senderApp && GbdConstants.KYPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			pwd = applicationProperties.getStringProperty("kypp.setting.payment.ui.restconsumer.service.password");
		} else {
			pwd = applicationProperties.getStringProperty("gbd.setting.payment.ui.restconsumer.service.password");
		}
		return pwd;
	}

	protected String getSecureKey(String senderApp) {
		String secureKey = GbdConstants.EMPTY;
		if(null != senderApp && GbdConstants.TPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureKey = applicationProperties.getStringProperty("tpp.setting.payment.ui.restconsumer.service.key");
		} else if(null != senderApp && GbdConstants.KYTPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureKey = applicationProperties.getStringProperty("kytpp.setting.payment.ui.restconsumer.service.key");
		} else if(null != senderApp && GbdConstants.KYPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureKey = applicationProperties.getStringProperty("kypp.setting.payment.ui.restconsumer.service.key");
		} else {
			secureKey = applicationProperties.getStringProperty("gbd.setting.payment.ui.restconsumer.service.key");
		}
		return secureKey;
	}

	protected String getSecureAlgorithm(String senderApp) {
		String secureAlgorithm = GbdConstants.EMPTY;
		if(null != senderApp && GbdConstants.TPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureAlgorithm = applicationProperties.getStringProperty("tpp.setting.payment.ui.restconsumer.service.algorithm");
		} else if(null != senderApp && GbdConstants.KYTPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureAlgorithm = applicationProperties.getStringProperty("kytpp.setting.payment.ui.restconsumer.service.algorithm");
		} else if(null != senderApp && GbdConstants.KYPP_SENDER_APP.equalsIgnoreCase(senderApp)) {
			secureAlgorithm = applicationProperties.getStringProperty("kypp.setting.payment.ui.restconsumer.service.algorithm");
		} else {
			secureAlgorithm = applicationProperties.getStringProperty("gbd.setting.payment.ui.restconsumer.service.algorithm");
		}
		return secureAlgorithm;
	}
	//Modified by Cognizant for TPP change July 2017 - End
	
}
