package com.wellpoint.middletier.gbd.gateway.bo;

import com.wellpoint.memberpay.request.RequestHeader;

public class DeleteUserAccountRestRequestKYTPPService {

	private String dn;
	private String requestingSystem;
	private String userName;
	private String relationShipType;
	
	private RequestHeader requestHeader;
	private String healthCardId;
	private String serviceEnv;
	private String endPointName;
	
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getRelationShipType() {
		return relationShipType;
	}
	public void setRelationShipType(String relationShipType) {
		this.relationShipType = relationShipType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEndPointName() {
		return endPointName;
	}
	public void setEndPointName(String endPointName) {
		this.endPointName = endPointName;
	}
	public String getRequestingSystem() {
		return requestingSystem;
	}
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}
	public String getHealthCardId() {
		return healthCardId;
	}
	public void setHealthCardId(String healthCardId) {
		this.healthCardId = healthCardId;
	}
	public String getServiceEnv() {
		return serviceEnv;
	}
	public void setServiceEnv(String serviceEnv) {
		this.serviceEnv = serviceEnv;
	}
}
