/**
* MacAppUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 30/06/2016  1.0      Cognizant       Initial Version
* 05/16/2017  1.1      Cognizant       Modified by Cognizant for TPP change July 2017
*/
package com.wellpoint.midletier.gbd.gateway.util;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;

/**
 * This class contains util methods required for GBD appointment
 * @author CTS
 *
 */
@Component
public class GbdUtil implements GbdConstants{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GbdUtil.class);

	private static SecureRandom random = new SecureRandom();
	
	@Autowired
	private ApplicationPropertiesUI applicationProperties;
	
	public GbdUtil(){
		//Can't initialize this class
	}
	
	private static String UNDER_SCORE = "_";
	
	/**
	 * This method encodes a string using base64
	 * @param value
	 * @return
	 */
	public static String getEncodedText(String value)
	{
		String encoded = "";
		try {
			byte[] byteArray = Base64.encodeBase64(value.getBytes());
			encoded = new String(byteArray);
		} catch (Exception e) {
			LOGGER.debug("Exception in getEncodedText() "+e);
		}
		return encoded;
	}
    
	/**
	 * This method decodes a string using base64
	 * @param encoded
	 * @return
	 */
    public static String getDecodedText(String encoded)
    {
    	String decoded = "";
    	try {
    		byte[] byteArray = Base64.decodeBase64(encoded.getBytes());
    		decoded = new String(byteArray);
    		decoded = decoded.replaceAll("[\n\r]", "");
    	} catch (Exception e){ 
    		LOGGER.debug("Exception in getDecodedText() "+e);
    	}
    	return decoded;
    }
    
    /**
	 * This method generates JWT token with the secure information we provide
	 * @param param1
	 * @param param2
	 * @return jwtToken
	 */
	public String getJWTToken(String param1, String key)
    {
    	String jwtToken = "";
    	String secureValue = getDecodedText(applicationProperties.getStringProperty("gbd.token.generation.private.secret.key"));
    	if(null == secureValue){
    		secureValue = "-gbdappsecure";
    	}
    	String finalParam = param1 + secureValue;
    	try {
    		jwtToken = Jwts.builder()
	    				.setSubject(finalParam)
	    				.setIssuedAt(new Date())
	    				.signWith(SignatureAlgorithm.HS256, key)
	    				.compact();
    	} catch (Exception e){ 
    		LOGGER.debug("Exception in getJWTToken() "+e);
    	}
    	return jwtToken;
    }
    
    /**
     * This method validates the token for jwt filter
     * @param request
     * @param key
     * @throws ServletException
     */
    public static void validateToken(final HttpServletRequest request, String key)
			throws ServletException {
    	
		final String authHeader = request.getHeader("Authorization");
		final String userName = request.getHeader("UserName");
		String claimsSubject = "";
		
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
		    throw new ServletException("Missing or invalid Authorization header.");
		}	

		final String token = authHeader.substring(7);
 
		try {
		    final Claims claims = Jwts.parser().setSigningKey(key)
		        .parseClaimsJws(token).getBody();
		    String userNameSeperated = "";
		    if(null != claims.get("sub")){
		    	claimsSubject = (String) claims.get("sub");
		    	if(claimsSubject != null && !claimsSubject.isEmpty()){
		    		String[] claimsSubjectDelimited = claimsSubject.split("-");
		    		userNameSeperated = claimsSubjectDelimited[0];
		    	}
		    }
		    request.setAttribute("claims", claims);
	    	if(!userNameSeperated.equalsIgnoreCase(userName)){
	    		LOGGER.error("Exception in Filter Invalid token, claims not matching id.");
	    		throw new ServletException("Invalid token.");
	    	}
		}
		catch (final SignatureException e) {
			LOGGER.error("Exception in Filter Invalid token : "+e);
		    throw new ServletException("Invalid token.");
		}
	}
    
    /**
     * This method generates csrf token for adding in jwt token
     */
    public static String getCSRFToken() {
        String csrfToken = new BigInteger(130, random).toString(32);
        return csrfToken;
    }
	
    //Added by Cognizant for TPP change July 2017 - Start
    public static String getMetaSenderAppValue(HttpServletRequest httpRequest) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader("meta-senderapp");
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching meta-senderapp header");
        }
        return value;
    }
    
    public static String getCsrIdValue(HttpServletRequest httpRequest) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader("csrId");
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching csrId header");
        }
        return value;
    }
    
	public static String getMetaOrgTypeValue(HttpServletRequest httpRequest) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader("meta-orgType");
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching meta-orgType header");
        }
        return value;
    }
	
	public List<String> getMatchingUserRole(String value){
		List<String> userRoles = new ArrayList<String>();
		List<String> allowableRoles = new ArrayList<String>();
		String allowableRolesString = applicationProperties.getStringProperty("gbd.setting.apt.portal.allowable.roles.list");
		if(allowableRolesString != null && !allowableRolesString.isEmpty()) {
			String[] allowableRolesStringArray = allowableRolesString.split(",");
			allowableRoles = Arrays.asList(allowableRolesStringArray);
		}
		if(null != value && !value.isEmpty() && allowableRoles != null && allowableRoles.size() > 0) {
			value = value.toUpperCase();
			if(value.contains(CN + GBDPPORTCSR + COMMA) && allowableRoles.contains(GBDPPORTCSR)) {
				userRoles.add(GBDPPORTCSR);
			}
			if(value.contains(CN + MACAPPADMIN + COMMA) && allowableRoles.contains(MACAPPADMIN)) {
				userRoles.add(MACAPPADMIN);
			}
			if(value.contains(CN + PPORTCSR + COMMA) && allowableRoles.contains(PPORTCSR)) {
				userRoles.add(PPORTCSR);
			}
			if(value.contains(CN + CSRPAYMENT + COMMA) && allowableRoles.contains(CSRPAYMENT)) {
				userRoles.add(CSRPAYMENT);
			}
			if(value.contains(CN + HIPCSRPAYMENT + COMMA) && allowableRoles.contains(HIPCSRPAYMENT)) {
				userRoles.add(HIPCSRPAYMENT);
			}
			if(value.contains(CN + KYHCSRPAYMENT + COMMA) && allowableRoles.contains(KYHCSRPAYMENT)) {
				userRoles.add(KYHCSRPAYMENT);
			}
			if(value.contains(CN + KYHPPORTCSR + COMMA) && allowableRoles.contains(KYHPPORTCSR)) {
				userRoles.add(KYHPPORTCSR);
			}
			if(value.contains(CN + PPCSRADMIN + COMMA) && allowableRoles.contains(PPCSRADMIN)) {
				userRoles.add(PPCSRADMIN);
			}
			if(value.contains(CN + WGSCSRPAYMENT + COMMA) && allowableRoles.contains(WGSCSRPAYMENT)) {
				userRoles.add(WGSCSRPAYMENT);
			}
			if(value.contains(CN + GBDCSRSUBMIT + COMMA) && allowableRoles.contains(GBDCSRSUBMIT)) {
				userRoles.add(GBDCSRSUBMIT);
			}
			if(value.contains(CN + KYHCSRSUBMIT + COMMA) && allowableRoles.contains(KYHCSRSUBMIT)) {
				userRoles.add(KYHCSRSUBMIT);
			}
			if(value.contains(CN + MACSRSUBMIT + COMMA) && allowableRoles.contains(MACSRSUBMIT)) {
				userRoles.add(MACSRSUBMIT);
			}
			if(value.contains(CN + MSCSRSUBMIT + COMMA) && allowableRoles.contains(MSCSRSUBMIT)) {
				userRoles.add(MSCSRSUBMIT);
			}
			if(value.contains(CN + PPORTCSRSUBMIT + COMMA) && allowableRoles.contains(PPORTCSRSUBMIT)) {
				userRoles.add(PPORTCSRSUBMIT);
			}
			if(value.contains(CN + REPORTSADMIN + COMMA) && allowableRoles.contains(REPORTSADMIN)) {
				userRoles.add(REPORTSADMIN);
			}
			if(value.contains(CN + MSMACSRSUBMIT + COMMA) && allowableRoles.contains(MSMACSRSUBMIT)) {
				userRoles.add(MSMACSRSUBMIT);
			}
			if(value.contains(CN + WGSCSRSUBMIT + COMMA) && allowableRoles.contains(WGSCSRSUBMIT)) {
				userRoles.add(WGSCSRSUBMIT);
			}
			if(value.contains(CN + ADHOCREPORT + COMMA) && allowableRoles.contains(ADHOCREPORT)) {
				userRoles.add(ADHOCREPORT);
			}
			if(value.contains(CN + REFUNDSADMIN + COMMA) && allowableRoles.contains(REFUNDSADMIN)) {
				userRoles.add(REFUNDSADMIN);
			}
		}
		return userRoles;
	}
	//Added by Cognizant for TPP change July 2017 - End
}
