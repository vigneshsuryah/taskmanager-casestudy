package com.wellpoint.middletier.gbd.gateway.request;

public class BaseRequest {

	private String userName;
	private String endPointName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEndPointName() {
		return endPointName;
	}

	public void setEndPointName(String endPointName) {
		this.endPointName = endPointName;
	}
	
}
