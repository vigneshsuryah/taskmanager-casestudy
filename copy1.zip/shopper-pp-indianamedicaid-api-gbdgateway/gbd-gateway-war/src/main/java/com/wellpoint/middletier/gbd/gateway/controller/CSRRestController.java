package com.wellpoint.middletier.gbd.gateway.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.wellpoint.memberpay.request.BaseRequest;
import com.wellpoint.memberpay.request.CancelPaymentMemberPayRequest;
import com.wellpoint.memberpay.request.GetAccountSummaryDetailsRequest;
import com.wellpoint.memberpay.request.GetPaymentMethodRequest;
import com.wellpoint.memberpay.request.GetPdfBillRequest;
import com.wellpoint.memberpay.request.GetRecurringPaymentDetailsRequest;
import com.wellpoint.memberpay.request.SubmitPaymentRequest;
import com.wellpoint.memberpay.request.UpdatePaymentMethodRequest;
import com.wellpoint.memberpay.request.UpdateRecurringPaymentRequest;
import com.wellpoint.memberpay.request.ViewPaymentHistoryRequest;
import com.wellpoint.middletier.gbd.gateway.bo.LoginRequest;
import com.wellpoint.middletier.gbd.gateway.bo.LoginResponse;
import com.wellpoint.middletier.gbd.gateway.bo.UserRulesResponse;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.APIExceptions;
import com.wellpoint.middletier.gbd.gateway.exception.Exceptions;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.middletier.gbd.gateway.exception.PaymentModException;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;
import com.wellpoint.midletier.gbd.gateway.util.GbdHelperUtils;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;
import com.wellpoint.midletier.gbd.gateway.util.VeracodeCleanerUtil;

@Controller  
public class CSRRestController implements GbdConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(CSRRestController.class);
	@Autowired
	private ApplicationPropertiesUI applicationProperties;	
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private GbdUtil gbdUtil;
	@Autowired
	private GbdHelperUtils gbdHelperUtils;
	
	@Autowired
	private VeracodeCleanerUtil veracodeCleanerUtil;
	
	public String getSecureRestPath()
	{
		return applicationProperties.getStringProperty("gbd.setting.rest.service.endpoint");
	}
	
	public String getSecurePayModRestPath(){
		return applicationProperties.getStringProperty("paymod.setting.rest.service.endpoint");
	}
	
	public String getSecureNodePath(){
		return applicationProperties.getStringProperty("rules.consumer.node.service.endpoint");
	}
	
	/* start of ky gbd csr end-points */

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/getmethods", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMethods(@RequestBody GetPaymentMethodRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getmethods() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetPaymentMethodRequest> requestEntity = new HttpEntity<GetPaymentMethodRequest>(getMethodsRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getmethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getmethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/v1/gbd/bills/getsummary", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getSummary(@RequestBody GetAccountSummaryDetailsRequest getSummaryRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getSummary() of GbdGatewayRestController");
		Object response = null;
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getSummaryRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getHttpHeaders();
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<GetAccountSummaryDetailsRequest> requestEntity = new HttpEntity<GetAccountSummaryDetailsRequest>(getSummaryRequest,
					httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/getsummary", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getSummary() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/getrecurring", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getRecurring(@RequestBody GetRecurringPaymentDetailsRequest getMethodsRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in getrecurring() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetRecurringPaymentDetailsRequest> requestEntity = new HttpEntity<GetRecurringPaymentDetailsRequest>(
					getMethodsRequest, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getrecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getrecurring() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}


	@RequestMapping(value = "/csr/secure/v1/gbd/payments/updaterecurring", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateRecurring(@RequestBody UpdateRecurringPaymentRequest getMethodsRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in getrecurring() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<UpdateRecurringPaymentRequest> requestEntity = new HttpEntity<UpdateRecurringPaymentRequest>(getMethodsRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updaterecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updaterecurring() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/updatemethods", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateMethods(@RequestBody UpdatePaymentMethodRequest updateMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in updateMethods() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		try
		{
			updateMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
					.getRequestHeader());
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(updateMethodsRequest, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updatemethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/bills/history", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getHistory(@RequestBody ViewPaymentHistoryRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getsummary() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<ViewPaymentHistoryRequest> requestEntity = new HttpEntity<ViewPaymentHistoryRequest>(getMethodsRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/history", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in history() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/bills/viewbill", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object viewBill(@RequestBody GetPdfBillRequest viewBillRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in viewBill() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		viewBillRequest
				.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(viewBillRequest, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/viewbill", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in viewBill() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/v1/gbd/payments/submittransaction", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object submitPayment(@RequestBody SubmitPaymentRequest submitPaymentRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in submitPayment() of GbdGatewayRestController");
		Object response = null;
		
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		submitPaymentRequest
				.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getHttpHeaders();
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(submitPaymentRequest, httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/submittransaction", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in submitPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/v1/gbd/payments/canceltransaction", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object cancelTransaction(@RequestBody CancelPaymentMemberPayRequest submitPaymentRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in cancelTransaction() of GbdGatewayRestController");
		Object response = null;
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		submitPaymentRequest
				.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getHttpHeaders();
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(submitPaymentRequest, httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/canceltransaction", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in cancelTransaction() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/v1/gbd/bills/checkhohmember", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYPPCSR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object checkForHohMember(@RequestBody GetAccountSummaryDetailsRequest getSummaryRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in checkForHohMember() of GbdGatewayRestController");
		Object response = null;
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getSummaryRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetAccountSummaryDetailsRequest> requestEntity = new HttpEntity<GetAccountSummaryDetailsRequest>(getSummaryRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/checkhohmember", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in checkForHohMember() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/generateTokenCSR", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody LoginResponse checkSiteminderHeaders(HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in checkSiteminderHeaders() of GbdGatewayRestController");
		LoginResponse response = new LoginResponse();
		List<String> userRole = new ArrayList<String>(); 
		try{
			String userName = httpRequest.getHeader("SM_USER");
			String firstName = httpRequest.getHeader("SM_FIRSTNAME");
			String lastName = httpRequest.getHeader("SM_LASTNAME");
			String jwtToken=gbdUtil.getJWTToken(userName, applicationProperties.getStringProperty("gbd.setting.member.jwt.secret.key"));
			
			String userDn = httpRequest.getHeader("SM_USERDN");
			String userGroup = httpRequest.getHeader("SM_GROUP");
			String userRoleVal = httpRequest.getHeader("SM_ROLE");
			
			LOGGER.debug("userGroup in checkSiteminderHeaders" + veracodeCleanerUtil.escapeLoggerStmt(userGroup));
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.ALL));
			headers.set("UserName", userName);
			headers.set("Authorization", "Bearer "+jwtToken);
			
			response.setRules(new ArrayList<String>());
			try{
				HttpEntity<Object> requestEntity = new HttpEntity<Object>(headers);
				String userId = "";
				if(null != userName && !userName.isEmpty()){
					userId = userName.toUpperCase();
				}
				ResponseEntity<UserRulesResponse> userRulesResponse  = restTemplate.exchange(getSecureNodePath() + "payments/getUserRules?userID="+userId, HttpMethod.GET, requestEntity, UserRulesResponse.class);
				if(userRulesResponse.getBody().isSuccess()){
					response.setRules(userRulesResponse.getBody().getRules());
				}
				LOGGER.info("rulesList::::"+userRulesResponse.getBody().getRules());
			}catch (Exception e)
			{
				LOGGER.error("Exception in getRules - generateTokenCSR of Gateway " + e);
			}
			 
			response.setUserName(userName);
			response.setFirstName(firstName);
			response.setLastName(lastName);
			response.setAuthToken(jwtToken);
			response.setUserDn(userDn);
			userRole = gbdUtil.getMatchingUserRole(userGroup);
			response.setRelShpType(userRole.toString());
			/*mock starts*/
			/*userRole.add(KYHPPORTCSR);*/
			/*mock ends*/
			response.setUserRole(userRole);
			
			response.setRelShpName(userRoleVal);
		}catch(Exception e){
			LOGGER.error("Exception in getToken() of Gateway "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	private HttpHeaders getHttpHeaders()
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", applicationProperties.getStringProperty("kypp.meta.senderapp.value"));
		headers.add("meta-src-envrmt", applicationProperties.getStringProperty("kypp.meta.src.envrmt.value"));
		headers.add("meta-target-source", applicationProperties.getStringProperty("kypp.meta.target.source.value"));
		headers.add("state-of-business", applicationProperties.getStringProperty("kypp.state.of.business.value"));
		headers.add("line-of-business", applicationProperties.getStringProperty("kypp.line.of.business.value"));
		return headers;
	}

	/* end of ky gbd csr end-points */

	@RequestMapping(value = "/csr/secure/csrendpointtotest", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody LoginResponse secureCsrEndpoint(@RequestBody LoginRequest request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in secureCsrEndpoint() of GbdGatewayRestController");
		LoginResponse response = new LoginResponse();
		try{
			
			String userGroup = httpRequest.getHeader("SM_GROUP");
			String userRole = httpRequest.getHeader("SM_ROLE");
			
			response.setUserName(request.getUserName());
			response.setRelShpType(userRole);
			response.setRelShpName(userGroup);
			
		}catch(Exception e){
			LOGGER.error("Exception in getToken() of Gateway "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/reports/getRegistrationDetail", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getTppayersList(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getTppayersList() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.ALL));
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, headers);
			response = restTemplate.postForObject(getSecureRestPath() + "pportmembersvcV2/reports/getRegistrationDetail ", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getTppayersList() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/csr/secure/reports/getCashPayDetails", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getCashPayDetails(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getCashPayDetails() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.ALL));
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, headers);
			response = restTemplate.postForObject(getSecureRestPath() + "pportmembersvcV2/reports/getCashPayDetails ", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getCashPayDetails() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	//Added by Cognizant for WGS change Oct 2018 release - Start
	@RequestMapping(value = "/wgs/secure/v1/payments/getmethods", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMethods(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getMethods() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWgsHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "payment/wgs/getPaymentMethods", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getMethods() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/wgs/secure/v1/payments/updatemethods", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateMethods(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in updateMethods() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWgsHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "payment/wgs/updatePaymentMethods", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMethods() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/wgs/secure/v1/payments/submitpayment", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object memberPaySubmitPayment(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in memberPaySubmitPayment() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWgsHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "payment/wgs/memberPaySubmitPayment", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in memberPaySubmitPayment() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/wgs/secure/v1/payments/cancelpayment", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object cancelPaymentMemberPay(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in cancelPaymentMemberPay() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWgsHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "payment/wgs/cancelPaymentMemberPay", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in cancelPaymentMemberPay() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/wgs/secure/v1/payments/getsummary", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getSummary(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in cancelPaymentMemberPay() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWgsHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "payment/wgs/getSummary", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getSummary() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/wgs/secure/v1/payments/validateRoutingNumber", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object validateRoutingNumber(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in validateRoutingNumber() of CSRRestController");
		Object response = null;
		
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, getWalletHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "sales/payment-wallet/v1/validateRoutingNumber", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in validateRoutingNumber() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	private HttpHeaders getWgsHttpHeaders(HttpServletRequest httpRequest) {
		HttpHeaders headers = new HttpHeaders();
		String csrId = httpRequest.getHeader("csrId");
		if(null != csrId && !csrId.isEmpty()) {
			headers.add("csrId", csrId);
		}
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		return headers;
	}
	
	private HttpHeaders getWalletHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("requestApplication", applicationProperties.getStringProperty("wgs.meta.senderapp.value"));
		headers.add("userName", applicationProperties.getStringProperty("wgs.setting.payment.ui.restconsumer.service.username"));
		headers.add("password", applicationProperties.getStringProperty("wgs.setting.payment.ui.restconsumer.service.password"));
		return headers;
	}
	//Added by Cognizant for WGS change Oct 2018 release - End
	
	
	
	@RequestMapping(value = "/csr/secure/mwp/getdetailsforcsr", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMwpServiceUrl(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getTppayersList() of CSRRestController");
		Object response = null;
		
		try
		{
			String endPoint = httpRequest.getHeader("meta-endpoint");
			String csrId = httpRequest.getHeader("csrId");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.ALL));
			headers.add("meta-senderapp", applicationProperties.getStringProperty("mwp.meta.senderapp.value"));
			headers.add("csrId", csrId);
			
			Object sendObj = addRequestHeaderObject(objRequest);
			
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(sendObj, headers);
			response = restTemplate.postForObject(getSecureRestPath() + "pportmembersvcV2/" + endPoint, requestEntity, Object.class);
			
		}catch(HttpClientErrorException e){	
			LOGGER.error("HttpClientErrorException in getMwpServiceUrl() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in getMwpServiceUrl() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch (HttpServerErrorException e){
			LOGGER.error("HttpServerErrorException in getMwpServiceUrl() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in getMwpServiceUrl() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch(Exception e){
			LOGGER.error("Exception in getMwpServiceUrl() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} 
		return response;
	}
	
	public Object addRequestHeaderObject(Object object){
		Object sendObject = new Object();
		
		JSONObject requestHeader = new JSONObject();
		requestHeader.put("userName", applicationProperties.getStringProperty("mwp.setting.payment.reimagine.restconsumer.service.username"));
		requestHeader.put("password", applicationProperties.getStringProperty("mwp.setting.payment.reimagine.restconsumer.service.password"));
		
		String jsonInString = new Gson().toJson(object);
		JSONObject realObject = new JSONObject(jsonInString);
		realObject.put("requestHeader", requestHeader);
		
		sendObject = new Gson().fromJson(realObject.toString(), Object.class);
	    return sendObject;
	}
	
	private void convertSOAExceptionsToMemberPayException(String bodyString) throws GbdException{
		org.codehaus.jackson.map.ObjectMapper mapper = new org.codehaus.jackson.map.ObjectMapper();
		APIExceptions exceptionObject = new APIExceptions();
		try {
			exceptionObject = mapper.readValue(bodyString, APIExceptions.class);
			Exceptions exception = exceptionObject.getExceptions()[0];
			throw new GbdException(exception.getType(), exception.getCode(), exception.getMessage(), REST_ERROR_200);
		} catch (JsonParseException e) {
			LOGGER.debug("JsonParseException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (JsonMappingException e) {
			LOGGER.debug("JsonMappingException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (IOException e) {
			LOGGER.debug("IOException in convertSOAExceptionsToGbd");
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
	}
	
	private void handlePayModExceptions(String bodyString) throws PaymentModException{
		org.codehaus.jackson.map.ObjectMapper mapper = new org.codehaus.jackson.map.ObjectMapper();
		APIExceptions exceptionObject = new APIExceptions();
		try {
			exceptionObject = mapper.readValue(bodyString, APIExceptions.class);
			Exceptions[] exceptions = exceptionObject.getExceptions();
			throw new PaymentModException(exceptions, REST_ERROR_200);
		} catch (JsonParseException e) {
			LOGGER.debug("JsonParseException in handlePayModExceptions");
			throw new PaymentModException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (JsonMappingException e) {
			LOGGER.debug("JsonMappingException in handlePayModExceptions");
			throw new PaymentModException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} catch (IOException e) {
			LOGGER.debug("IOException in handlePayModExceptions");
			throw new PaymentModException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
	}
	
	@RequestMapping(value = "/csr/secure/v1/payments/validateRoutingNumber", method = RequestMethod.POST, headers = { "Accept=*/*"}, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateBankDetails(@RequestBody Object req, HttpServletRequest httpRequest) throws PaymentModException{
		
		LOGGER.info("in validateBankDetails() of PayModRestController-- Start");
		Object response = null;
		try{
			String endPoint = httpRequest.getHeader("meta-endpoint");
			HttpHeaders headers = new HttpHeaders();
			managePayModHeaders(headers);
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(req, headers);
			response = restTemplate.postForObject(getSecurePayModRestPath()+endPoint, requestEntity, Object.class);
		} catch(HttpClientErrorException e){	
			handlePayModExceptions(e.getResponseBodyAsString());
		}catch (HttpServerErrorException e){
			handlePayModExceptions(e.getResponseBodyAsString());
		} catch (Exception e){
			LOGGER.error("Exception in validateRoutingNumber() of CSRRestController " + e);
			e.printStackTrace();
			throw new PaymentModException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
		}


	private HttpHeaders managePayModHeaders(HttpHeaders headers) {
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.set("userName", applicationProperties.getStringProperty("paymod.setting.payment.restconsumer.service.username"));
		headers.set("password", applicationProperties.getStringProperty("paymod.setting.payment.restconsumer.service.password"));
		headers.set("requestApplication", applicationProperties.getStringProperty("paymod.setting.payment.restconsumer.service.requestingApplication"));
		return headers;
	}
	
	/* MSMA CSR endpoints - Start */
	@RequestMapping(value = "/csr/secure/v1/msma/getMSMAdetailsforcsr", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMSMAServiceUrl(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getMSMAServiceUrl() of CSRRestController");
		Object response = null;
		
		try
		{
			String endPoint = httpRequest.getHeader("meta-endpoint");
			
			Object sendObj = addMSMAReqHeaderObject(objRequest);
			
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(sendObj, getMSMAHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath() + "medSupp/v1/" + endPoint, requestEntity, Object.class);
			
		}catch(HttpClientErrorException e){	
			LOGGER.error("HttpClientErrorException in getMSMAServiceUrl() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in getMSMAServiceUrl() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch (HttpServerErrorException e){
			LOGGER.error("HttpServerErrorException in getMSMAServiceUrl() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in getMSMAServiceUrl() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch(Exception e){
			LOGGER.error("Exception in getMSMAServiceUrl() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} 
		return response;
	}
	
	public Object addMSMAReqHeaderObject(Object object){
		Object sendObject = new Object();
		
		JSONObject requestHeader = new JSONObject();
		requestHeader.put("userName", applicationProperties.getStringProperty("msma.setting.payment.ui.restconsumer.service.username"));
		requestHeader.put("password", applicationProperties.getStringProperty("msma.setting.payment.ui.restconsumer.service.password"));
		
		String jsonInString = new Gson().toJson(object);
		JSONObject realObject = new JSONObject(jsonInString);
		realObject.put("requestHeader", requestHeader);
		
		sendObject = new Gson().fromJson(realObject.toString(), Object.class);
	    return sendObject;
	}
	
	private HttpHeaders getMSMAHttpHeaders(HttpServletRequest httpRequest)
	{
		String csrId = "";
		String csrRole = "";
		String lob = "";
		if(null != httpRequest) {
			csrId = httpRequest.getHeader("csrId");
			csrRole = httpRequest.getHeader("csrRole");
			lob = httpRequest.getHeader("lob");
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", applicationProperties.getStringProperty("msma.meta.senderapp.value"));
		headers.add("csrId", csrId);
		headers.add("csrRole", csrRole);
		headers.add("lob", lob);
		return headers;
	}
	/* MSMA CSR endpoints - End */
	
	@RequestMapping(value = "/csr/secure/payment/paymod/refund", method = RequestMethod.POST, headers = { "Accept=*/*" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object refundAPI(@RequestBody Object objRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in refundAPI() of CSRRestController");
		Object response = null;
		try
		{
			String endPoint = "";
			String csrId = "";
			String lob = "";
			if(null != httpRequest) {
				endPoint = httpRequest.getHeader("meta-endpoint");
				csrId = httpRequest.getHeader("csrId");
				lob = httpRequest.getHeader("lob");
			}
			
			HttpHeaders headers = new HttpHeaders();
			headers.add("lob", lob);
			headers.add("csrId", csrId);
			managePayModHeaders(headers);
			
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(objRequest, headers);
			response = restTemplate.postForObject(getSecureRestPath() + "payment/paymod/" + endPoint, requestEntity, Object.class);
			
		}catch(HttpClientErrorException e){	
			LOGGER.error("HttpClientErrorException in refundAPI() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in refundAPI() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch (HttpServerErrorException e){
			LOGGER.error("HttpServerErrorException in refundAPI() of CSRRestController " + e);
			LOGGER.error("HttpClientErrorException in refundAPI() of CSRRestController Status Code :: " + e.getResponseBodyAsString());
			convertSOAExceptionsToMemberPayException(e.getResponseBodyAsString());
		}catch(Exception e){
			LOGGER.error("Exception in refundAPI() of CSRRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		} 
		return response;
	}
}
