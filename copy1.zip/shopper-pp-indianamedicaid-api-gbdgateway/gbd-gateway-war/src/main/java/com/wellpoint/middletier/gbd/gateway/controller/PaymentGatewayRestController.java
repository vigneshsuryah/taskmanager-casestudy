package com.wellpoint.middletier.gbd.gateway.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.wellpoint.ebiz.middletier.payment.rest.request.GetApplicationRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.GetPaymentRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.SearchPaymentRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.SetApplicationRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.SetPaymentRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.SubmitApplicationRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.request.ValidateZipCodeRequestRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.GetApplicationResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.GetPaymentResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.SearchPaymentResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.SetApplicationResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.SetPaymentResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.SubmitApplicationResponseRS;
import com.wellpoint.ebiz.middletier.payment.rest.response.ValidateZipCodeResponseRS;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;

@RestController
public class PaymentGatewayRestController implements GbdConstants {
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentGatewayRestController.class);

	@Autowired
	private ApplicationPropertiesUI applicationProperties;
	@Autowired
	private RestTemplate restTemplate;

	private String generateRestEndPointUrl(String endPointName) {
		String restEndPointPrefix = applicationProperties.getStringProperty("WellPoint.Ebiz.MiddleTier.Services.REST.Endpoints.PaymentWebService.Prefix");
		String value = restEndPointPrefix + endPointName;
		return value;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/getPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public GetPaymentResponseRS getPayment(@RequestBody GetPaymentRequestRS getPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		GetPaymentResponseRS getPaymentResponseRS = null;
		try {
			getPaymentResponseRS = restTemplate.postForObject(generateRestEndPointUrl("getPayment"), getPaymentRequestRS, GetPaymentResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in getPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return getPaymentResponseRS;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/getApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public GetApplicationResponseRS getApplication(@RequestBody GetApplicationRequestRS getApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		GetApplicationResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("getApplication"), getApplicationRequestRS, GetApplicationResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in getApplication() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/setApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public SetApplicationResponseRS setApplication(@RequestBody SetApplicationRequestRS setApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		SetApplicationResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("setApplication"), setApplicationRequestRS, SetApplicationResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in setApplication() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/setPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public SetPaymentResponseRS setPayment(@RequestBody SetPaymentRequestRS setPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		SetPaymentResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("setPayment"), setPaymentRequestRS, SetPaymentResponseRS.class);

		} catch (Exception e) {
			LOGGER.error("Exception in setPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/submitApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public SubmitApplicationResponseRS submitApplication(@RequestBody SubmitApplicationRequestRS submitApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		SubmitApplicationResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("submitApplication"), submitApplicationRequestRS, SubmitApplicationResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in submitApplication() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/searchPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public SearchPaymentResponseRS searchPayment(@RequestBody SearchPaymentRequestRS searchPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		SearchPaymentResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("searchPayment"), searchPaymentRequestRS, SearchPaymentResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in searchPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/validateZipCode", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public ValidateZipCodeResponseRS validateZipCode(@RequestBody ValidateZipCodeRequestRS validateZipCodeRequest, HttpServletRequest httpRequest) throws GbdException {
		ValidateZipCodeResponseRS response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("validateZipCode"), validateZipCodeRequest, ValidateZipCodeResponseRS.class);
		} catch (Exception e) {
			LOGGER.error("Exception in validateZipCode() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	
	
	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/getPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object getPaymentCSRPayment(@RequestBody Object getPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object getPaymentResponseRS = null;
		try {
			getPaymentResponseRS = restTemplate.postForObject(generateRestEndPointUrl("getPayment"), getPaymentRequestRS, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in getPaymentCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return getPaymentResponseRS;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/getApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object getApplicationCSRPayment(@RequestBody Object getApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("getApplication"), getApplicationRequestRS, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in getApplicationCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/setApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object setApplicationCSRPayment(@RequestBody Object setApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("setApplication"), setApplicationRequestRS, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in setApplicationCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/setPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object setPaymentCSRPayment(@RequestBody Object setPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("setPayment"), setPaymentRequestRS, Object.class);

		} catch (Exception e) {
			LOGGER.error("Exception in setPaymentCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/submitApplication", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object submitApplicationCSRPayment(@RequestBody Object submitApplicationRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("submitApplication"), submitApplicationRequestRS, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in submitApplicationCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/searchPayment", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object searchPaymentCSRPayment(@RequestBody Object searchPaymentRequestRS, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("searchPayment"), searchPaymentRequestRS, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in searchPaymentCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/ipp/csrpayment/validateZipCode", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json" }, produces = { "application/json; charset=UTF-8" })
	public Object validateZipCodeCSRPayment(@RequestBody Object validateZipCodeRequest, HttpServletRequest httpRequest) throws GbdException {
		Object response = null;
		try {
			response = restTemplate.postForObject(generateRestEndPointUrl("validateZipCode"), validateZipCodeRequest, Object.class);
		} catch (Exception e) {
			LOGGER.error("Exception in validateZipCodeCSRPayment() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

}
