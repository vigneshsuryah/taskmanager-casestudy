/**
 * GbdGatewayRestController.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 30/06/2016  1.0      Cognizant       Initial Version
 * 05/16/2017  1.1      Cognizant       Modified by Cognizant for TPP change July 2017
 * 06/27/2018  1.1      Cognizant       Modified by Cognizant for KYTPP change July 2018
 */
package com.wellpoint.middletier.gbd.gateway.controller;


import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.wellpoint.memberpay.exception.MemberPayException;
import com.wellpoint.memberpay.request.BaseRequest;
import com.wellpoint.memberpay.request.CancelPaymentMemberPayRequest;
import com.wellpoint.memberpay.request.GetAccountSummaryDetailsRequest;
import com.wellpoint.memberpay.request.GetPaymentMethodRequest;
import com.wellpoint.memberpay.request.GetPdfBillRequest;
import com.wellpoint.memberpay.request.GetRecurringPaymentDetailsRequest;
import com.wellpoint.memberpay.request.SubmitPaymentRequest;
import com.wellpoint.memberpay.request.SubmitPaymentTPPRequest;
import com.wellpoint.memberpay.request.UpdatePaymentMethodRequest;
import com.wellpoint.memberpay.request.UpdateRecurringPaymentRequest;
import com.wellpoint.memberpay.request.ViewPaymentHistoryRequest;
import com.wellpoint.middletier.gbd.gateway.bo.LoginRequest;
import com.wellpoint.middletier.gbd.gateway.bo.LoginResponse;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;
import com.wellpoint.midletier.gbd.gateway.util.GbdHelperUtils;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;
import com.wellpoint.tpp.request.GetMemberRequest;
import com.wellpoint.tpp.request.UpdateMemberRequest;


/**
 * This class contains list of rest services exposed
 * 
 * @author CTS
 */
@Controller
public class GbdGatewayRestController implements GbdConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(GbdGatewayRestController.class);
	@Autowired
	private ApplicationPropertiesUI applicationProperties;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private GbdUtil gbdUtil;
	@Autowired
	private Mapper dozerMapper;
	@Autowired
	private GbdHelperUtils gbdHelperUtils;

	public String getSecureRestPath()
	{
		return applicationProperties.getStringProperty("gbd.setting.rest.service.endpoint");
	}

	/* start of gbd admin end-points */

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/getmethods", method = RequestMethod.POST, headers = { "Accept=*/*",
			"meta-senderapp=GBDMBR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMethods(@RequestBody GetPaymentMethodRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getmethods() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetPaymentMethodRequest> requestEntity = new HttpEntity<GetPaymentMethodRequest>(getMethodsRequest,
					getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getmethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getmethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/getrecurring", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getRecurring(@RequestBody GetRecurringPaymentDetailsRequest getMethodsRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in getrecurring() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetRecurringPaymentDetailsRequest> requestEntity = new HttpEntity<GetRecurringPaymentDetailsRequest>(
					getMethodsRequest, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getrecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getrecurring() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/bills/getsummary", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getsummary(@RequestBody GetAccountSummaryDetailsRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getsummary() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getHttpHeaders();
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<GetAccountSummaryDetailsRequest> requestEntity = new HttpEntity<GetAccountSummaryDetailsRequest>(getMethodsRequest,
					httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/getsummary", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getsummary() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/updaterecurring", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateRecurring(@RequestBody UpdateRecurringPaymentRequest getMethodsRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in getrecurring() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<UpdateRecurringPaymentRequest> requestEntity = new HttpEntity<UpdateRecurringPaymentRequest>(getMethodsRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updaterecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updaterecurring() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/updatemethods", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=GBDMBR" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateMethods(@RequestBody UpdatePaymentMethodRequest updateMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in updateMethods() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		try
		{
			updateMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
					.getRequestHeader());
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(updateMethodsRequest, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updatemethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/bills/history", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getHistory(@RequestBody ViewPaymentHistoryRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getsummary() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<ViewPaymentHistoryRequest> requestEntity = new HttpEntity<ViewPaymentHistoryRequest>(getMethodsRequest,
					getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/history", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in history() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/canceltransaction", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object cancelTransaction(@RequestBody CancelPaymentMemberPayRequest cancelTransactionRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in cancelTransaction() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		cancelTransactionRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getHttpHeaders();
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(cancelTransactionRequest, httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/canceltransaction", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in cancelTransaction() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/bills/viewbill", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object viewBill(@RequestBody GetPdfBillRequest viewBillRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in viewBill() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		viewBillRequest
				.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(viewBillRequest, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/bills/viewbill", requestEntity, Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in viewBill() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/csr/secure/v1/gbd/payments/submittransaction", method = RequestMethod.POST, headers = { "Accept=*/*",
			"meta-senderapp=GBDMBR" }, consumes = { "application/json", "application/xml" }, produces = {
			"application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object submitTransaction(@RequestBody SubmitPaymentRequest submitTransactionRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in submitTransaction() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		String csrId = GbdUtil.getCsrIdValue(httpRequest);
		submitTransactionRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpHeaders httpHeaders = getTPPHttpHeaders(senderApp, orgType);
			if(csrId != null && !csrId.isEmpty()) {
				httpHeaders.add("csrId", csrId);
			}
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(submitTransactionRequest, httpHeaders);
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/submittransaction", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in submitTransaction() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/login/gettoken", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	LoginResponse getToken(@RequestBody LoginRequest loginRequest) throws GbdException
	{
		LOGGER.info("in getToken() of GbdGatewayRestController");
		LoginResponse response = new LoginResponse();
		try
		{

			String jwtToken = gbdUtil.getJWTToken(loginRequest.getUserName(),
					applicationProperties.getStringProperty("gbd.setting.member.jwt.secret.key"));
			response.setAuthToken(jwtToken);

		} catch (Exception e)
		{
			LOGGER.error("Exception in getToken() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	private HttpHeaders getHttpHeaders()
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", applicationProperties.getStringProperty("gbd.meta.senderapp.value"));
		headers.add("meta-src-envrmt", applicationProperties.getStringProperty("gbd.meta.src.envrmt.value"));
		return headers;
	}

	/* end of gbd admin end-points */
	
	/* start of gbd tpp end-points */

	@RequestMapping(value = "/gofundhip/secure/v1/gbd/payments/getmethods", method = RequestMethod.POST, headers = { "Accept=*/*",
			"meta-senderapp=TPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMethodsTPP(@RequestBody GetPaymentMethodRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getmethods() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetPaymentMethodRequest> requestEntity = new HttpEntity<GetPaymentMethodRequest>(getMethodsRequest,
					getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getmethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getmethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/payments/updatemethods", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=TPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateMethodsTPP(@RequestBody UpdatePaymentMethodRequest updateMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in updateMethods() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		try
		{
			updateMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
					.getRequestHeader());
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(updateMethodsRequest, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updatemethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMethods() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/payments/updateMember", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateTPPMember(@RequestBody UpdateMemberRequest request, HttpServletRequest httpRequest) throws MemberPayException,
			GbdException
	{
		LOGGER.info("in updateMember() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<UpdateMemberRequest> requestEntity = new HttpEntity<UpdateMemberRequest>(request, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updateMember", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMember() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/gofundhip/secure/v1/gbd/payments/getMembers", method = RequestMethod.POST, headers = "Accept=*/*", consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getTPPMembers(@RequestBody GetMemberRequest request, HttpServletRequest httpRequest) throws MemberPayException, GbdException
	{
		LOGGER.info("in getMembers() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<GetMemberRequest> requestEntity = new HttpEntity<GetMemberRequest>(request, getHttpHeaders());
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getMembers", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getMembers() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/gofundhip/secure/v1/gbd/payments/submittransaction", method = RequestMethod.POST, headers = { "Accept=*/*",
			"meta-senderapp=TPP" }, consumes = { "application/json", "application/xml" }, produces = { "application/json; charset=UTF-8",
			"text/html;charset=UTF-8" })
	public @ResponseBody
	Object submitTPPTransaction(@RequestBody SubmitPaymentTPPRequest submitTransactionRequest, HttpServletRequest httpRequest)
			throws GbdException
	{
		LOGGER.info("in submitTransaction() of GbdGatewayRestController");
		Object response = null;
		// TPP change
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		submitTransactionRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(submitTransactionRequest, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/submittransaction", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in submitTransaction() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	private HttpHeaders getTPPHttpHeaders(String senderApp, String orgType)
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		if (null != senderApp && (GbdConstants.TPP_SENDER_APP.equalsIgnoreCase(senderApp) || GbdConstants.KYTPP_SENDER_APP.equalsIgnoreCase(senderApp)))
		{
			headers.add("meta-senderapp", senderApp);
			if(null != orgType){
				headers.add("meta-orgType", orgType);
			}
		}
		else
		{
			headers.add("meta-senderapp", applicationProperties.getStringProperty("gbd.meta.senderapp.value"));
		}
		headers.add("meta-src-envrmt", applicationProperties.getStringProperty("gbd.meta.src.envrmt.value"));
		return headers;
	}
	
	/* end of gbd tpp end-points */
	
	
	
	/* start of gbd ky tpp end-points */

	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/getmethods", method = RequestMethod.POST, headers = { "Accept=*/*",
			"meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getMethodsKYTPP(@RequestBody GetPaymentMethodRequest getMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in getMethodsKYTPP() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		getMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
				.getRequestHeader());
		try
		{
			HttpEntity<GetPaymentMethodRequest> requestEntity = new HttpEntity<GetPaymentMethodRequest>(getMethodsRequest,
					getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getmethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getMethodsKYTPP() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/updatemethods", method = RequestMethod.POST, headers = { "Accept=*/*",
	"meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateMethodsKYTPP(@RequestBody UpdatePaymentMethodRequest updateMethodsRequest, HttpServletRequest httpRequest) throws GbdException
	{
		LOGGER.info("in updateMethodsKYTPP() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		try
		{
			updateMethodsRequest.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
					.getRequestHeader());
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(updateMethodsRequest, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updatemethods", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateMethodsKYTPP() of Gateway " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/getMembers", method = RequestMethod.POST, headers = { "Accept=*/*", "meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getKYTPPMembers(@RequestBody GetMemberRequest request, HttpServletRequest httpRequest) throws MemberPayException, GbdException
	{
		LOGGER.info("in getKYTPPMembers() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<GetMemberRequest> requestEntity = new HttpEntity<GetMemberRequest>(request, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getMembers", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getKYTPPMembers() of GbdGatewayRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/updateMember", method = RequestMethod.POST, headers = { "Accept=*/*", "meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateKYTPPMember(@RequestBody UpdateMemberRequest request, HttpServletRequest httpRequest) throws MemberPayException,
			GbdException
	{
		LOGGER.info("in updateKYTPPMember() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<UpdateMemberRequest> requestEntity = new HttpEntity<UpdateMemberRequest>(request, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updateMember", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateKYTPPMember() of GbdGatewayRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/submittransaction", method = RequestMethod.POST, headers = { "Accept=*/*", "meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object submitKYTPPTransaction(@RequestBody SubmitPaymentTPPRequest request, HttpServletRequest httpRequest) throws MemberPayException,
			GbdException
	{
		LOGGER.info("in submitKYTPPTransaction() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<SubmitPaymentTPPRequest> requestEntity = new HttpEntity<SubmitPaymentTPPRequest>(request, getTPPHttpHeaders(senderApp, orgType));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/submittransaction", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in submitKYTPPTransaction() of GbdGatewayRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/getrecurring", method = RequestMethod.POST, headers = { "Accept=*/*", "meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object getKYTPPRecurring(@RequestBody GetRecurringPaymentDetailsRequest request, HttpServletRequest httpRequest) throws MemberPayException,
			GbdException
	{
		LOGGER.info("in getKYTPPRecurring() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<GetRecurringPaymentDetailsRequest> requestEntity = new HttpEntity<GetRecurringPaymentDetailsRequest>(request, getTPPHttpHeaders(senderApp, null));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/getrecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in getKYTPPRecurring() of GbdGatewayRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/payments/updaterecurring", method = RequestMethod.POST, headers = { "Accept=*/*", "meta-senderapp=KYTPP" }, consumes = {
			"application/json", "application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	Object updateKYTPPRecurring(@RequestBody UpdateRecurringPaymentRequest request, HttpServletRequest httpRequest) throws MemberPayException,
			GbdException
	{
		LOGGER.info("in updateKYTPPRecurring() of GbdGatewayRestController");
		Object response = null;
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		request.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp)).getRequestHeader());
		try
		{
			HttpEntity<UpdateRecurringPaymentRequest> requestEntity = new HttpEntity<UpdateRecurringPaymentRequest>(request, getTPPHttpHeaders(senderApp, null));
			response = restTemplate.postForObject(getSecureRestPath() + "gbdpaymentsvc/v1/gbd/payments/updaterecurring", requestEntity,
					Object.class);
		} catch (Exception e)
		{
			LOGGER.error("Exception in updateKYTPPRecurring() of GbdGatewayRestController " + e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	/* end of gbd ky tpp end-points */
}
