/**
* RestError.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 07/07/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.exception;

public class RestError {
	private Exceptions[] exceptions;

	public Exceptions[] getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions[] exceptions) {
		this.exceptions = exceptions;
	}
}
