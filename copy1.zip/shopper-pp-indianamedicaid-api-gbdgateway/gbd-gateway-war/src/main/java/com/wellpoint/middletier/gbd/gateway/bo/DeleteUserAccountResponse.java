package com.wellpoint.middletier.gbd.gateway.bo;

import java.io.Serializable;

public class DeleteUserAccountResponse implements Serializable{

	private static final long serialVersionUID = -6536686524570573130L;
	
	private boolean userAccountDeleted;

	/**
	 * @return the userAccountDeleted
	 */
	public boolean isUserAccountDeleted() {
		return userAccountDeleted;
	}

	/**
	 * @param userAccountDeleted the userAccountDeleted to set
	 */
	public void setUserAccountDeleted(boolean userAccountDeleted) {
		this.userAccountDeleted = userAccountDeleted;
	}
	
}
