package com.wellpoint.middletier.gbd.gateway.bo;

import java.io.Serializable;
import java.util.List;

public class UserRulesResponse implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private boolean success;
	private List<String> rules;
	private String message;
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public List<String> getRules() {
		return rules;
	}
	public void setRules(List<String> rules) {
		this.rules = rules;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
