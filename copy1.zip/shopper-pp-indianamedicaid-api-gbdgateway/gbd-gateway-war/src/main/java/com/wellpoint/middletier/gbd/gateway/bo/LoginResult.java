/**
* LoginResult.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 08/30/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.bo;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

public class LoginResult {
	LoginStatusEnum loginStatus;
	Cookie[] cookies;
	Map headers;

	public LoginStatusEnum getLoginStatus()
	{
		return loginStatus;
	}
	public void setLoginStatus(LoginStatusEnum loginStatus)
	{
		this.loginStatus = loginStatus;
	}

	public Cookie[] getCookies()
	{
		return cookies;
	}

	public void setCookies(Cookie[] cookies)
	{
		this.cookies = cookies;
	}

	public Map getHeaders()
	{
		if(headers == null)
		{
			headers = new HashMap();
		}
		return headers;
	}
}
