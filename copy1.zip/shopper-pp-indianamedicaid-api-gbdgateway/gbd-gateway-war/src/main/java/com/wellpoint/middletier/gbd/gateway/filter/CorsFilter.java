/**
* CorsFilter.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 30/06/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CorsFilter implements Filter {

	private static final Logger LOGGER = LoggerFactory.getLogger(CorsFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
    	LOGGER.info("Adding Access Control Response Headers");
    	
    	HttpServletRequest request = (HttpServletRequest) servletRequest;
    	
    	/*LOGGER.error("************************************************************************************************");
    	LOGGER.error(printHeaders(request));
    	LOGGER.error("************************************************************************************************");*/
    	
    	
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, x-forwarded-for, Content-Type, Content-Length, Accept-Encoding, Accept, Authorization, UserName, meta-senderapp, meta-orgType, SM_GROUP, ipaddress, module, senderapp, usernm, webguid, meta-transid, meta-endpoint, csrId, csrRole, lob");
        filterChain.doFilter(servletRequest, servletResponse);
    }

    public static String getIpAddress(HttpServletRequest request) {
        String xffStr = StringUtils.defaultString(request.getHeader("x-forwarded-for"));
        if (StringUtils.isEmpty(xffStr)) {
            xffStr = StringUtils.defaultString(request.getRemoteAddr());
        }
        return xffStr;
    }
    
    @SuppressWarnings("unchecked")
	public String printHeaders(HttpServletRequest request)
	{
		String headerName = null;
		String headerValue = null;
		ArrayList<String> headers = new ArrayList<String>();
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements())
		{
			headerName = (String) headerNames.nextElement();
			headerValue = request.getHeader(headerName);
			headers.add(headerName + "=" + headerValue + " || ");
		}
		return headers.toString();
	}
    
    @Override
    public void destroy() {

    }
}
