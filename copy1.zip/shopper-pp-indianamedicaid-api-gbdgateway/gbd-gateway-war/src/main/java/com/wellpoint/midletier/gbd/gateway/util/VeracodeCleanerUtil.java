/**
* VeracodeCleanerUtil.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 06/08/2018  1.0      Cognizant       Initial Version
*/
package com.wellpoint.midletier.gbd.gateway.util;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.text.translate.CharSequenceTranslator;
import org.apache.commons.lang3.text.translate.LookupTranslator;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;


@Component
public class VeracodeCleanerUtil
{

	private static final Logger LOGGER = Logger.getLogger(VeracodeCleanerUtil.class);


	public String escapeFilePath(String path)
	{
		//boolean validpath = false;
		//String validatedPath = null;
		/*try
		{
			if (path != null)
			{
				String pathInDBList = applicationConfigUtil.getApplicationConfig("FILE_PATH_CONFIG", "FILE_PATH_CONFIG");
				for (String pathInDB : pathInDBList.split(","))
				{
					if (path.contains(pathInDB))
					{
						validpath = true;
						break;
					}
				}
			}
			if (!validpath)
			{
				throw new EHBException("Not a valid path");
			}
		} catch (EHBException e)
		{
			LOGGER.error("Exception while fetching the file path");
			throw new EHBException("Not a valid path");
		}
		validpath = true;

		if(validpath)
		{
			validatedPath = StringEscapeUtils.escapeJava(path);
		}*/

		return StringEscapeUtils.escapeJava(path);
	}

	/*
	public String unEscapeTrustedBoundaryViolation(String escapedValue)
	{
		String unescapedValue = null;
		unescapedValue =  StringEscapeUtils.unescapeJava(escapedValue);
		return unescapedValue;
	}*/
	/*public RenewalConfigureQuote escapeTrustedBoundaryViolationFrObj(RenewalConfigureQuote renewalConfigureQuote){
	RenewalConfigureQuote renewalConfigureQuoteTmp=new RenewalConfigureQuote();
	renewalConfigureQuoteTmp=renewalConfigureQuote;
	return renewalConfigureQuoteTmp;

}*/

/*public String escapeSpecialChar(String actualValue){
	String processedValue=null;
	processedValue=ESCAPE_JAVA_SPL.translate(actualValue);
	return processedValue;
}*/

	public static final CharSequenceTranslator ESCAPE_JAVA_SPL =
        new LookupTranslator(
          new String[][] {
                  {"\b", "\\b"},
                  {"\n", "\\n"},
                  {"\t", "\\t"},
                  {"\f", "\\f"},
                  {"\r", "\\r"}
              });
	public boolean escapeBooleanValues(boolean unescapedValue){
		boolean trueBoolean=true;
		boolean falseBoolean=false;
		if(unescapedValue){
			return trueBoolean;
		}else{
			return falseBoolean;
		}
	}
	public Integer escapeIntegerValues(Integer unescapedValue){
		Integer escapedValue=null;
		if(unescapedValue!=null){
			int tmpVal=unescapedValue.intValue();
			escapedValue = Integer.valueOf(tmpVal);
		}
		return escapedValue;
	}
	public List<String> escStringList(List<String> unEscList){
		LOGGER.debug("Inside escStringList");
		List<String> escRatingList=null;
		if(unEscList!=null){
			LOGGER.debug("List Size : "+unEscList.size());
			escRatingList=new ArrayList<String>();
			for(int i=0;i<unEscList.size();i++){
				escRatingList.add(i, escapeTrustedBoundaryViolation(unEscList.get(i)));
			}
		}
		return escRatingList;
	}
	public String[] escStrArray(String[] unescStrArr){
		LOGGER.debug("Inside escStringArray");
		String[] escStrArr=null;
		if(unescStrArr!=null){
			int arrSize=unescStrArr.length;
			escStrArr=new String[arrSize];
			for(int j=0;j<arrSize;j++){
				escStrArr[j]=escapeTrustedBoundaryViolation(unescStrArr[j]);
			}
		}
		return escStrArr;
	}
	
	public String escapeTrustedBoundaryViolation(String unescapedValue)
	{
		String escapedValue = null;
//		LOGGER.debug("String before escape : "+unescapedValue);
		escapedValue =  ESCAPE_JAVA_SPL.translate(unescapedValue);
		LOGGER.debug("String after escape : "+escapedValue);
		return escapedValue;
	}

	public String escapeHeaderInjection(String unescapedValue)
	{
		String escapedValue = null;
		LOGGER.debug("String before escape : "+unescapedValue);
		escapedValue= ESCAPE_JAVA_SPL.translate(unescapedValue);
		LOGGER.debug("String after escape : "+escapedValue);
		return escapedValue;
	}
	public String escapeLoggerStmt(String unescapedValue)
	{
		String escapedValue = null;
		escapedValue =  ESCAPE_JAVA_SPL.translate(unescapedValue);
		return escapedValue;
	}
	public String escapeCRLFStmt(String unescapedValue)
	{
		String escapedValue = null;
		escapedValue =  ESCAPE_JAVA_SPL.translate(unescapedValue);
		return escapedValue;
	}
	
	public String escapeURLRedirectionStmt(String unescapedValue)
	{
		String escapedValue = null;
		escapedValue =  ESCAPE_JAVA_SPL.translate(unescapedValue);
		return escapedValue;
	}
	
}
