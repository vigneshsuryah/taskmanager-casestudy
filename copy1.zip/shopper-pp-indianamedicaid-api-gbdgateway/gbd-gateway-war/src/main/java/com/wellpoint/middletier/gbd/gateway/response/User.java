/**
 * User.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.gateway.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class User implements Serializable {

	private static final long serialVersionUID = 3789885083993979488L;
	private String hcid;
	private String emailAddress;
	private String username;
	private String iamGuid;
	private String secretQuestion;
	private String secretAnswer;
	private String hcidPrefix;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String phoneNumber;
	private String dn;
	private String registrationDate;
	private String repositoryEnum;
	private String userRoleEnum;
	private String brandEnum;
	private String securityGroupEnum;
	private String[] memberOf;
	private String[] ssoID;
	private String memberId;
	private String ssoUniqueId;
	private String ssoClientId;
	private String orgType;
	private String orgName;
	private boolean authFlag;
	
	public String[] getSsoID() {
		return ssoID;
	}

	public void setSsoID(String[] ssoID) {
		this.ssoID = ssoID;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getSsoUniqueId() {
		return ssoUniqueId;
	}

	public void setSsoUniqueId(String ssoUniqueId) {
		this.ssoUniqueId = ssoUniqueId;
	}

	public String getSsoClientId() {
		return ssoClientId;
	}

	public void setSsoClientId(String ssoClientId) {
		this.ssoClientId = ssoClientId;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the memberOf
	 */
	public String[] getMemberOf() {
		return memberOf;
	}

	/**
	 * @param memberOf
	 *            the memberOf to set
	 */
	public void setMemberOf(String[] memberOf) {
		this.memberOf = memberOf;
	}

	/**
	 * @return the hcid
	 */
	public String getHcid() {
		return this.hcid;
	}

	/**
	 * @param hcid
	 *            the hcid to set
	 */
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the iamGuid
	 */
	public String getIamGuid() {
		return iamGuid;
	}

	/**
	 * @param iamGuid
	 *            the iamGuid to set
	 */
	public void setIamGuid(String iamGuid) {
		this.iamGuid = iamGuid;
	}

	/**
	 * @return the secretQuestion
	 */
	public String getSecretQuestion() {
		return secretQuestion;
	}

	/**
	 * @param secretQuestion
	 *            the secretQuestion to set
	 */
	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	/**
	 * @return the secretAnswer
	 */
	public String getSecretAnswer() {
		return secretAnswer;
	}

	/**
	 * @param secretAnswer
	 *            the secretAnswer to set
	 */
	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}

	/**
	 * @return the hcidPrefix
	 */
	public String getHcidPrefix() {
		return hcidPrefix;
	}

	/**
	 * @param hcidPrefix
	 *            the hcidPrefix to set
	 */
	public void setHcidPrefix(String hcidPrefix) {
		this.hcidPrefix = hcidPrefix;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the dn
	 */
	public String getDn() {
		return dn;
	}

	/**
	 * @param dn
	 *            the dn to set
	 */
	public void setDn(String dn) {
		this.dn = dn;
	}

	/**
	 * @return the registrationDate
	 */
	public String getRegistrationDate() {
		return registrationDate;
	}

	/**
	 * @param registrationDate
	 *            the registrationDate to set
	 */
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	/**
	 * @return the repositoryEnum
	 */
	public String getRepositoryEnum() {
		return repositoryEnum;
	}

	/**
	 * @param repositoryEnum
	 *            the repositoryEnum to set
	 */
	public void setRepositoryEnum(String repositoryEnum) {
		this.repositoryEnum = repositoryEnum;
	}

	/**
	 * @return the userRoleEnum
	 */
	public String getUserRoleEnum() {
		return userRoleEnum;
	}

	/**
	 * @param userRoleEnum
	 *            the userRoleEnum to set
	 */
	public void setUserRoleEnum(String userRoleEnum) {
		this.userRoleEnum = userRoleEnum;
	}

	/**
	 * @return the brandEnum
	 */
	public String getBrandEnum() {
		return brandEnum;
	}

	/**
	 * @param brandEnum
	 *            the brandEnum to set
	 */
	public void setBrandEnum(String brandEnum) {
		this.brandEnum = brandEnum;
	}

	/**
	 * @return the securityGroupEnum
	 */
	public String getSecurityGroupEnum() {
		return securityGroupEnum;
	}

	/**
	 * @param securityGroupEnum
	 *            the securityGroupEnum to set
	 */
	public void setSecurityGroupEnum(String securityGroupEnum) {
		this.securityGroupEnum = securityGroupEnum;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public boolean isAuthFlag() {
		return authFlag;
	}

	public void setAuthFlag(boolean authFlag) {
		this.authFlag = authFlag;
	}
}