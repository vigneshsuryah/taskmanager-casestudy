/**
* MemberJwtFilter.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 30/06/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.GenericFilterBean;

import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;

public class GbdJwtFilter extends GenericFilterBean {
	private static final Logger MBLOGGER = LoggerFactory.getLogger(GbdJwtFilter.class);

    @Override
    public void doFilter(final ServletRequest req,
                         final ServletResponse res,
                         final FilterChain chain) throws IOException, ServletException {
    	MBLOGGER.debug("Inside GBD JWT filter");

        final HttpServletRequest request = (HttpServletRequest) req;
        String url = request.getRequestURL().toString();
        
        if(url.contains("/csr/secure/generateTokenCSR")){
        	chain.doFilter(req, res);
        }else{
        	if(!"OPTIONS".equals(request.getMethod()))
            {
            	GbdUtil.validateToken(request,ApplicationPropertiesUI.getStringProperty("gbd.setting.member.jwt.secret.key",null));
            }
        	chain.doFilter(req, res);
        }
    }

}
