/**
* LoginStatusEnum.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 08/30/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.bo;

import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;

public class LoginStatusEnum implements java.io.Serializable,GbdConstants {
	private static final long serialVersionUID = 1L;
	private java.lang.String _value_;
    @SuppressWarnings("rawtypes")
	private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    @SuppressWarnings("unchecked")
	protected LoginStatusEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _SUCCESS = "SUCCESS";
    public static final java.lang.String _DISABLED = "DISABLED";
    public static final java.lang.String _FORCE_CHANGE_PD = "Rk9SQ0VfQ0hBTkdFX1BBU1NXT1JE";
    public static final java.lang.String _LOCKED = "LOCKED";
    public static final java.lang.String _INVALID_LOGIN = "INVALID_LOGIN";
    public static final java.lang.String _PD_CHANGE_SUCESS = "UEFTU1dPUkRfQ0hBTkdFX1NVQ0VTUw==";
    public static final java.lang.String _PD_INVALID = "UEFTU1dPUkRfSU5WQUxJRA==";
    public static final java.lang.String _UNKNOWN = "UNKNOWN";

    public static final LoginStatusEnum SUCCESS = new LoginStatusEnum(_SUCCESS);
    public static final LoginStatusEnum DISABLED = new LoginStatusEnum(_DISABLED);
    public static final LoginStatusEnum FORCE_CHANGE_PWD = new LoginStatusEnum(GbdUtil.getDecodedText(_FORCE_CHANGE_PD));
    public static final LoginStatusEnum LOCKED = new LoginStatusEnum(_LOCKED);
    public static final LoginStatusEnum INVALID_LOGIN= new LoginStatusEnum(_INVALID_LOGIN);
    public static final LoginStatusEnum PWD_CHANGE_SUCESS = new LoginStatusEnum(GbdUtil.getDecodedText(_PD_CHANGE_SUCESS));
    public static final LoginStatusEnum PWD_INVALID = new LoginStatusEnum(GbdUtil.getDecodedText(_PD_INVALID));
    public static final LoginStatusEnum UNKNOWN = new LoginStatusEnum(_UNKNOWN);

    public java.lang.String getValue() { return _value_;}
    public static LoginStatusEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        LoginStatusEnum enumeration = (LoginStatusEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static LoginStatusEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
}
