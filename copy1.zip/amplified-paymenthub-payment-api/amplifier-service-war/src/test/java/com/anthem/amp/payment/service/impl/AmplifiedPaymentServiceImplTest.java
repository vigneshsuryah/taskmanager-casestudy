package com.anthem.amp.payment.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.test.context.ContextConfiguration;

import com.anthem.amp.payment.entity.PaymentDetails;
import com.anthem.amp.payment.entity.PaymentWallet;
import com.anthem.amp.payment.exception.handler.AmplifiedException;
import com.anthem.amp.payment.repository.PaymentDetailsRepository;
import com.anthem.amp.payment.repository.PaymentWalletRepository;
import com.anthem.amp.payment.request.CancelPaymentRequest;
import com.anthem.amp.payment.request.DeletePaymentMethodRequest;
import com.anthem.amp.payment.request.GetPaymentMethodRequest;
import com.anthem.amp.payment.request.PaymentHistoryRequest;
import com.anthem.amp.payment.request.SubmitPaymentRequest;
import com.anthem.amp.payment.request.UpdatePaymentMethodRequest;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.response.DeletePaymentMethodResponse;
import com.anthem.amp.payment.response.GetPaymentMethodResponse;
import com.anthem.amp.payment.response.GetTokenResponse;
import com.anthem.amp.payment.response.PaymentHistoryResponse;
import com.anthem.amp.payment.response.SubmitPaymentResponse;
import com.anthem.amp.payment.response.UpdatePaymentMethodResponse;
import com.anthem.amp.payment.util.AmplifierUtils;
import com.anthem.amp.payment.util.ChaseServiceUtil;
import com.anthem.amp.payment.util.UnitTestApplicationConfig;
import com.anthem.amp.payment.vo.BankAccountDetails;
import com.anthem.amp.payment.vo.BillingAddress;
import com.anthem.amp.payment.vo.CreditCardDetails;
import com.anthem.amp.payment.vo.Note;
import com.anthem.amp.payment.vo.Payment;
import com.anthem.amp.payment.vo.PaymentMethod;
import com.anthem.amp.payment.vo.Service;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = { UnitTestApplicationConfig.class })
public class AmplifiedPaymentServiceImplTest {

	@InjectMocks
	private AmplifiedPaymentServiceImpl amplifiedPaymentServiceImpl;

	@Spy
	private DozerBeanMapper dozerMapper;

	@Mock
	private MongoTemplate mongoTemplate;

	@Mock
	private PaymentWalletRepository paymentWalletRepository;

	@Mock
	private PaymentDetailsRepository paymentDetailsRepository;

	@Mock
	private MongoOperations mongoOperations;

	@Mock
	private ChaseServiceUtil chaseServiceUtil;

	@Mock
	private AmplifierUtils amplifierUtils;

	@Test
	public void testGetPaymentMethods_Success() throws Exception {
		GetPaymentMethodRequest request = new GetPaymentMethodRequest();
		request.setAcid("1234");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);

		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(paymentWallets);
		GetPaymentMethodResponse response = amplifiedPaymentServiceImpl.getPaymentMethods(request);
		assertNotNull(response);
		assertNotNull(response.getPaymentMethods());
		assertEquals(2, response.getPaymentMethods().size());

	}
	
	@Test
	public void testGetPaymentMethods_SuccessWithAction() throws Exception {
		GetPaymentMethodRequest request = new GetPaymentMethodRequest();
		request.setAcid("1234");
		request.setStatus("active");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		when(paymentWalletRepository.getPaymentWalletWithStatus(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets);
		GetPaymentMethodResponse response = amplifiedPaymentServiceImpl.getPaymentMethods(request);
		assertNotNull(response);
		assertNotNull(response.getPaymentMethods());
		assertEquals(2, response.getPaymentMethods().size());

	}
	
	@Test
	public void testGetPaymentMethods_SuccessWithTokenId() throws Exception {
		GetPaymentMethodRequest request = new GetPaymentMethodRequest();
		request.setAcid("1234");
		request.setStatus("active");
		request.setPaymentMethodID("N19S1QUV9YX0");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);

		when(paymentWalletRepository.getPaymentWalletForTokenID(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets);
		GetPaymentMethodResponse response = amplifiedPaymentServiceImpl.getPaymentMethods(request);
		assertNotNull(response);
		assertNotNull(response.getPaymentMethods());
		assertEquals(2, response.getPaymentMethods().size());

	}

	@Test
	public void testGetPaymentMethods_WithEmptyResults() throws Exception {
		GetPaymentMethodRequest request = new GetPaymentMethodRequest();
		request.setAcid("1234");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		try {
			amplifiedPaymentServiceImpl.getPaymentMethods(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("1009", ex.getErrorCode());
		}

	}

	@Test
	public void testGetPaymentHistory_Success() throws Exception {
		PaymentHistoryRequest request = new PaymentHistoryRequest();
		request.setAcid("1234");
		TypeReference<List<PaymentDetails>> mapObj = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper.readValue(file, mapObj);

		when(paymentDetailsRepository.getPaymentDetailsByAcid(Mockito.anyString())).thenReturn(paymentDetails);
		PaymentHistoryResponse response = amplifiedPaymentServiceImpl.getPaymentHistory(request);
		assertNotNull(response);
		assertNotNull(response.getPaymentHistory());
		assertEquals(2, response.getPaymentHistory().size());

	}

	@Test
	public void testGetPaymentHistory_WithEmptyResults() throws Exception {
		PaymentHistoryRequest request = new PaymentHistoryRequest();
		request.setAcid("1234");
		when(paymentDetailsRepository.getPaymentDetailsByAcid(Mockito.anyString())).thenReturn(null);
		try {
			amplifiedPaymentServiceImpl.getPaymentHistory(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("1009", ex.getErrorCode());
		}

	}
	
	@Test
	public void testDeletePaymentMethod_Success() throws Exception {
		DeletePaymentMethodRequest request = new DeletePaymentMethodRequest();
		request.setAcid("1234");
		request.setPaymentMethodID("N19S1QUV9YX0");
		request.setEmail("");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);

		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentWallets.get(0));
		DeletePaymentMethodResponse response = amplifiedPaymentServiceImpl.deletePaymentMethod(request);
		assertNotNull(response);
		assertEquals(request.getPaymentMethodID(), response.getPaymentMethodId());
	}
	
	@Test
	public void testDeletePaymentMethod_WithNoTokenId() throws Exception {
		DeletePaymentMethodRequest request = new DeletePaymentMethodRequest();
		request.setAcid("1234");
		request.setPaymentMethodID("N19S1QUV9YX0");
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		try {
			amplifiedPaymentServiceImpl.deletePaymentMethod(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("1008", ex.getErrorCode());
		}

	}
	
	@Test
	public void testDeletePaymentMethod_AlreadyDeleted() throws Exception {
		DeletePaymentMethodRequest request = new DeletePaymentMethodRequest();
		request.setAcid("1234");
		request.setPaymentMethodID("M5DOOS81NC0H");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);

		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		try {
			amplifiedPaymentServiceImpl.deletePaymentMethod(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("This Payment Method is already deleted.", ex.getErrorMessage());
		}
	}
	
	@Test
	public void testCancelPayment_Success() throws Exception {
		CancelPaymentRequest request = new CancelPaymentRequest();
		request.setOrderId("ampk190321m21412736");
		request.setCancelledBy("");
		request.setEmail("");
		request.setPaymentChannel("");
		Note note = new Note();
		note.setNoteDesc("Cancelled");
		request.setNotes(note);
		TypeReference<List<PaymentDetails>> mapObj = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper.readValue(file, mapObj);

		when(paymentDetailsRepository.getPaymentDetailsByOrderId(Mockito.anyString())).thenReturn(paymentDetails);
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentDetails.get(0));
		CancelPaymentResponse response = amplifiedPaymentServiceImpl.cancelPayment(request);
		assertNotNull(response);
		assertEquals("DNF", response.getStatus());
	}
	
	@Test
	public void testCancelPayment_WithNoOrderId() throws Exception {
		CancelPaymentRequest request = new CancelPaymentRequest();
		request.setOrderId("ampk190321m21412736");
		
		when(paymentDetailsRepository.getPaymentDetailsByOrderId(Mockito.anyString())).thenReturn(null);
		
		CancelPaymentResponse response = amplifiedPaymentServiceImpl.cancelPayment(request);
		assertNotNull(response);
		assertEquals("DNF", response.getStatus());
	}
	
	@Test
	public void testCancelPayment_Success_CC() throws Exception {
		CancelPaymentRequest request = new CancelPaymentRequest();
		request.setOrderId("ampk190329u58157536");
		Note note = new Note();
		note.setNoteDesc("Cancelled");
		request.setNotes(note);
		TypeReference<List<PaymentDetails>> mapObj = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper.readValue(file, mapObj);
		GetTokenResponse tokenResponse = new GetTokenResponse();
		tokenResponse.setAccountNumber("21345678955263");
		when(amplifierUtils.roundUp(Mockito.anyString(),Mockito.anyInt())).thenReturn("18.23");
		when(chaseServiceUtil.getTokenInformation(Mockito.any(),Mockito.anyString())).thenReturn(tokenResponse);
		when(paymentDetailsRepository.getPaymentDetailsByOrderId(Mockito.anyString())).thenReturn(Arrays.asList(paymentDetails.get(1)));
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentDetails.get(1));
		CancelPaymentResponse response = amplifiedPaymentServiceImpl.cancelPayment(request);
		assertNotNull(response);
		assertEquals("DNF", response.getStatus());
	}
	
	@Test
	public void testUpdatePaymentMethod_AddNew_Success() throws Exception {
		UpdatePaymentMethodRequest request = new UpdatePaymentMethodRequest();
		request.setAcid("1234");
		request.setEmail("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		request.setPaymentMethod(paymentMethod);
		
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());;
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		UpdatePaymentMethodResponse response = amplifiedPaymentServiceImpl.addOrUpdatePaymentMethod(request, "ADD");
		assertNotNull(response);
		assertNotNull(response.getPaymentMethodId());
	}
	
	@Test
	public void testUpdatePaymentMethod_AddNewWithExisting_Success() throws Exception {
		UpdatePaymentMethodRequest request = new UpdatePaymentMethodRequest();
		request.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		request.setPaymentMethod(paymentMethod);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(paymentWallets);
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentWallets.get(0));
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		UpdatePaymentMethodResponse response = amplifiedPaymentServiceImpl.addOrUpdatePaymentMethod(request, "ADD");
		assertNotNull(response);
		assertNotNull(response.getPaymentMethodId());
	}
	
	@Test
	public void testUpdatePaymentMethod_Upd_Success_ACH() throws Exception {
		UpdatePaymentMethodRequest request = new UpdatePaymentMethodRequest();
		request.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		paymentMethod.setPaymentMethodId("N19S1QUV9YX0");
		request.setPaymentMethod(paymentMethod);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentWallets.get(0));
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		UpdatePaymentMethodResponse response = amplifiedPaymentServiceImpl.addOrUpdatePaymentMethod(request, "UPD");
		assertNotNull(response);
		assertNotNull(response.getPaymentMethodId());
	}
	
	@Test
	public void testUpdatePaymentMethod_Upd_Success_CC() throws Exception {
		UpdatePaymentMethodRequest request = new UpdatePaymentMethodRequest();
		request.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		creditCardDetails.setCreditCardNumber("5454541024782578");
		creditCardDetails.setCreditCardType("MC");
		creditCardDetails.setExpirationMonth("02");
		creditCardDetails.setExpirationYear("2021");
		creditCardDetails.setIntegrityCheck("84699d3f63db5b21");
		creditCardDetails.setKeyID("bc56af7a");
		creditCardDetails.setPhaseID("1");
		paymentMethod.setCreditCardDetails(creditCardDetails);
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		paymentMethod.setPaymentMethodId("N19S1QUV9YX0");
		request.setPaymentMethod(paymentMethod);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("MC");
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		when(mongoOperations.findAndModify(any(Query.class), any(Update.class), any())).thenReturn(paymentWallets.get(0));
		GetTokenResponse tokenResponse = new GetTokenResponse();
		tokenResponse.setAccountNumber("21345678955263");
		when(chaseServiceUtil.getTokenInformation(Mockito.any(),Mockito.anyString())).thenReturn(tokenResponse);
		
		UpdatePaymentMethodResponse response = amplifiedPaymentServiceImpl.addOrUpdatePaymentMethod(request, "UPD");
		assertNotNull(response);
		assertNotNull(response.getPaymentMethodId());
	}
	
	@Test
	public void testUpdatePaymentMethod_Upd_Failure() throws Exception {
		UpdatePaymentMethodRequest request = new UpdatePaymentMethodRequest();
		request.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		paymentMethod.setPaymentMethodId("N19S1QUV9YX0");
		request.setPaymentMethod(paymentMethod);
		
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		
		try {
			amplifiedPaymentServiceImpl.addOrUpdatePaymentMethod(request, "UPD");
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("1009", ex.getErrorCode());
		}
	}
	
	@Test
	public void testSubmitPayment_Success_ACH() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("PERSONAL CHECKING");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper.readValue(file, mapObj);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		SubmitPaymentResponse response = amplifiedPaymentServiceImpl.submitPayment(request);
		assertNotNull(response);
		assertNotNull(response.getOrderId());
	}
	
	@Test
	public void testSubmitPayment_Success_ACHWithExisting() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		BankAccountDetails bankAccountDetails = new BankAccountDetails();
		bankAccountDetails.setBankAccountNumber("123456789");
		bankAccountDetails.setRoutingNumber("071103473");
		bankAccountDetails.setBankAccountType("PERSONALCHECKING");
		paymentMethod.setBankAccountDetails(bankAccountDetails);
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("PERSONAL CHECKING");
		
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(paymentWallets);
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj1 = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader1 = getClass().getClassLoader();
		File file1 = new File(classLoader1.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper1 = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper1.readValue(file1, mapObj1);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		SubmitPaymentResponse response = amplifiedPaymentServiceImpl.submitPayment(request);
		assertNotNull(response);
		assertNotNull(response.getOrderId());
	}
	
	@Test
	public void testSubmitPayment_Success_CC() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("test");
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		creditCardDetails.setCreditCardNumber("5454541024782578");
		creditCardDetails.setCreditCardType("MC");
		creditCardDetails.setExpirationMonth("02");
		creditCardDetails.setExpirationYear("2021");
		creditCardDetails.setIntegrityCheck("84699d3f63db5b21");
		creditCardDetails.setKeyID("bc56af7a");
		creditCardDetails.setPhaseID("1");
		paymentMethod.setCreditCardDetails(creditCardDetails);
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.roundUp(Mockito.anyString(),Mockito.anyInt())).thenReturn("18.23");
		GetTokenResponse tokenResponse = new GetTokenResponse();
		tokenResponse.setAccountNumber("21345678955263");
		tokenResponse.setEncryptedToken("545454CZGLRL2578");;
		when(chaseServiceUtil.getTokenInformation(Mockito.any(),Mockito.anyString())).thenReturn(tokenResponse);
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("MC");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper.readValue(file, mapObj);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		SubmitPaymentResponse response = amplifiedPaymentServiceImpl.submitPayment(request);
		assertNotNull(response);
		assertNotNull(response.getOrderId());
	}
	
	@Test
	public void testSubmitPayment_Success_CC_WithExistingToken() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setPaymentMethodId("M5DOOS81NC0H");
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.roundUp(Mockito.anyString(),Mockito.anyInt())).thenReturn("18.23");
		GetTokenResponse tokenResponse = new GetTokenResponse();
		tokenResponse.setAccountNumber("21345678955263");
		tokenResponse.setEncryptedToken("545454CZGLRL2578");;
		when(chaseServiceUtil.getTokenInformation(Mockito.any(),Mockito.anyString())).thenReturn(tokenResponse);
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("MC");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj1 = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader1 = getClass().getClassLoader();
		File file1 = new File(classLoader1.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper1 = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper1.readValue(file1, mapObj1);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		SubmitPaymentResponse response = amplifiedPaymentServiceImpl.submitPayment(request);
		assertNotNull(response);
		assertNotNull(response.getOrderId());
	}
	
	@Test
	public void testSubmitPayment_Success_CC_1008() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setPaymentMethodId("M5DOOS81NC0H");
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		
		try {
			amplifiedPaymentServiceImpl.submitPayment(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("1008", ex.getErrorCode());
		}
	}
	
	@Test
	public void testSubmitPayment_Success_CC_1301() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setPaymentMethodId("M5D1OS81NC0H");
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		
		try {
			amplifiedPaymentServiceImpl.submitPayment(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("PP-1301", ex.getErrorCode());
		}
	}

	@Test
	public void testSubmitPayment_CC_1400() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setPaymentMethodId("M5DOOS81NC0H");
		paymentMethod.setPaymentType("CC");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.roundUp(Mockito.anyString(),Mockito.anyInt())).thenReturn("18.23");
		GetTokenResponse tokenResponse = new GetTokenResponse();
		tokenResponse.setAccountNumber("21345678955263");
		when(chaseServiceUtil.getTokenInformation(Mockito.any(),Mockito.anyString())).thenReturn(tokenResponse);
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("MC");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj1 = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader1 = getClass().getClassLoader();
		File file1 = new File(classLoader1.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper1 = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper1.readValue(file1, mapObj1);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		try {
			amplifiedPaymentServiceImpl.submitPayment(request);
		} catch (AmplifiedException ex) {
			assertNotNull(ex);
			assertEquals("PP-1400", ex.getErrorCode());
		}
	}
	
	@Test
	public void testSubmitPayment_Success_ACH_WithExistingToken() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		request.setEmail("");
		Payment payment = new Payment();
		payment.setPaymentDate("");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setPaymentMethodId("N19S1QUV9YX0");
		paymentMethod.setPaymentType("ACH");
		paymentMethod.setPaymentFutureUse(true);
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("test");
		billingAddress.setCity("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		Service service = new Service();
		service.setAmount("18.23");
		service.setSku("123456");
		request.setServices(Arrays.asList(service));
		
		when(amplifierUtils.roundUp(Mockito.anyString(),Mockito.anyInt())).thenReturn("18.23");
		when(amplifierUtils.returnPaymentSubType(Mockito.anyString())).thenReturn("PERSONAL CHECKING");
		when(amplifierUtils.getRandomString(Mockito.anyInt())).thenReturn("M5DOOS81NC0H");
		when(amplifierUtils.generateOrderId(Mockito.anyString())).thenReturn("ampk190329u58157536");
		when(paymentWalletRepository.getPaymentWalletByAcid(Mockito.anyString())).thenReturn(null);
		TypeReference<List<PaymentWallet>> mapObj = new TypeReference<List<PaymentWallet>>() {
		};
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("paymentwallet.json").getFile());
		ObjectMapper mapper = new ObjectMapper();
		List<PaymentWallet> paymentWallets = mapper.readValue(file, mapObj);
		
		when(paymentWalletRepository.getPaymentWalletWithTokenID(Mockito.anyString(),Mockito.anyString())).thenReturn(paymentWallets.get(0));
		Mockito.doNothing().when(mongoTemplate).save(Mockito.any());
		TypeReference<List<PaymentDetails>> mapObj1 = new TypeReference<List<PaymentDetails>>() {
		};
		ClassLoader classLoader1 = getClass().getClassLoader();
		File file1 = new File(classLoader1.getResource("paymentdetails.json").getFile());
		ObjectMapper mapper1 = new ObjectMapper();
		List<PaymentDetails> paymentDetails = mapper1.readValue(file1, mapObj1);
		
		when(paymentDetailsRepository.save(Mockito.any(PaymentDetails.class))).thenReturn(paymentDetails.get(1));
		
		when(amplifierUtils.dateToStr(Mockito.any())).thenReturn("2019-04-01 02:17:15.560");
		
		SubmitPaymentResponse response = amplifiedPaymentServiceImpl.submitPayment(request);
		assertNotNull(response);
		assertNotNull(response.getOrderId());
	}
}
