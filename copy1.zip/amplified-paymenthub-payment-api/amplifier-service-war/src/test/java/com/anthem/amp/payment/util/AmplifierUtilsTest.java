package com.anthem.amp.payment.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AmplifierUtilsTest {
	
	@InjectMocks
	private AmplifierUtils amplifierUtils;
	
	@Test
	public void testReturnPaymentSubType_Type_PC() throws Exception{
		assertEquals("PERSONAL CHECKING",amplifierUtils.returnPaymentSubType("PERSONALCHECKING"));
	}
	
	@Test
	public void testReturnPaymentSubType_Type_PS() throws Exception{
		assertEquals("PERSONAL SAVINGS",amplifierUtils.returnPaymentSubType("PERSONALSAVINGS"));
	}
	
	@Test
	public void testReturnPaymentSubType_Type_BC() throws Exception{
		assertEquals("BUSINESS CHECKING",amplifierUtils.returnPaymentSubType("BUSCHECKING"));
	}
	
	@Test
	public void testReturnPaymentSubType_Type_BS() throws Exception{
		assertEquals("BUSINESS SAVINGS",amplifierUtils.returnPaymentSubType("BUSSAVINGS"));
	}
	
	@Test
	public void testReturnPaymentSubType_Type_VI() throws Exception{
		assertEquals("VISA",amplifierUtils.returnPaymentSubType("VI"));
	}
	
	@Test
	public void testReturnPaymentSubType_Type_MC() throws Exception{
		assertEquals("MC",amplifierUtils.returnPaymentSubType("MC"));
	}
	
	@Test
	public void testGetRandomString() throws Exception{
		assertEquals(12,amplifierUtils.getRandomString(12).length());
	}
	
	@Test
	public void testGenerateOrderId() throws Exception{
		assertEquals(19,amplifierUtils.generateOrderId("ampk").length());
	}
	
	@Test
	public void testConvertPaymentSubType_Type_PC() throws Exception{
		assertEquals("PERSONALCHECKING",amplifierUtils.convertPaymentSubType("PERSONAL CHECKING"));
	}
	
	@Test
	public void testConvertPaymentSubType_Type_PS() throws Exception{
		assertEquals("PERSONALSAVINGS",amplifierUtils.convertPaymentSubType("PERSONAL SAVINGS"));
	}
	
	@Test
	public void testConvertPaymentSubType_Type_BC() throws Exception{
		assertEquals("BUSCHECKING",amplifierUtils.convertPaymentSubType("BUSINESS CHECKING"));
	}
	
	@Test
	public void testConvertPaymentSubType_Type_BS() throws Exception{
		assertEquals("BUSSAVINGS",amplifierUtils.convertPaymentSubType("BUSINESS SAVINGS"));
	}
	
	@Test
	public void testConvertPaymentSubType_Type_VI() throws Exception{
		assertEquals("VISA",amplifierUtils.convertPaymentSubType("VI"));
	}
	
	@Test
	public void testConvertPaymentSubType_Type_MC() throws Exception{
		assertEquals("MC",amplifierUtils.convertPaymentSubType("MC"));
	}
	
	@Test
	public void testDateToStr() throws Exception{
		assertNotNull(amplifierUtils.dateToStr(new Date()));
	}
	
	@Test
	public void testStrToDate() throws Exception{
		assertNotNull(amplifierUtils.strToDate("2019-04-01"));
	}
	
	@Test
	public void testRoundUp() throws Exception{
		assertEquals("18.23",amplifierUtils.roundUp("18.2389",2));
	}
	
	@Test
	public void testMaskString() throws Exception{
		assertEquals("************2578",amplifierUtils.maskString("5454541024782578",0,12,'*'));
	}


}
