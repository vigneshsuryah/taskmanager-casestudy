package com.anthem.amp.payment.controller;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.anthem.amp.payment.AmplifiedPaymentApplication;
import com.anthem.amp.payment.exception.handler.AmplifiedException;
import com.anthem.amp.payment.request.CancelPaymentRequest;
import com.anthem.amp.payment.request.DeletePaymentMethodRequest;
import com.anthem.amp.payment.request.GetPaymentMethodRequest;
import com.anthem.amp.payment.request.PaymentHistoryRequest;
import com.anthem.amp.payment.request.SubmitPaymentRequest;
import com.anthem.amp.payment.request.UpdatePaymentMethodRequest;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.response.DeletePaymentMethodResponse;
import com.anthem.amp.payment.response.GetPaymentMethodResponse;
import com.anthem.amp.payment.response.PaymentHistoryResponse;
import com.anthem.amp.payment.response.SubmitPaymentResponse;
import com.anthem.amp.payment.response.UpdatePaymentMethodResponse;
import com.anthem.amp.payment.service.AmplifiedPaymentService;
import com.anthem.amp.payment.util.UnitTestApplicationConfig;
import com.anthem.amp.payment.vo.BillingAddress;
import com.anthem.amp.payment.vo.CreditCardDetails;
import com.anthem.amp.payment.vo.Payment;
import com.anthem.amp.payment.vo.PaymentMethod;
import com.anthem.amp.payment.vo.Service;
import com.google.gson.Gson;


@SpringBootTest(classes = AmplifiedPaymentApplication.class)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(classes = { UnitTestApplicationConfig.class })
public class AmplifiedPaymentControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AmplifiedPaymentService service;
	
	HttpHeaders headers = new HttpHeaders();
	
	Gson gson = new Gson();
	
	@Before
	public void setUp() throws Exception {
		given(service.getPaymentMethods(new GetPaymentMethodRequest())).willReturn(getMockPayMethodsRes());
		
		given(service.deletePaymentMethod(new DeletePaymentMethodRequest())).willReturn(getMockDelPayMethodsRes());
		given(service.getPaymentHistory(new PaymentHistoryRequest())).willReturn(getMockPayHisRes());
		given(service.submitPayment(new SubmitPaymentRequest())).willReturn(getMockSubmitPayRes());
		given(service.cancelPayment(new CancelPaymentRequest())).willReturn(getMockCancelPayRes());
	}
	
	@Test
	public void test_getPaymentMethods() throws Exception {
		this.mockMvc.perform(post("/paymenthub/v1/wallet").contentType(MediaType.APPLICATION_JSON)
				.content(createGetPayMethodReq()).headers(headers)).andExpect(status().isOk());
	}
	
	@Test
	public void test_204_getPaymentMethods() throws Exception {
		GetPaymentMethodRequest req = new GetPaymentMethodRequest();
		req.setAcid("1234");
		given(service.getPaymentMethods(req)).willThrow(new AmplifiedException("1009", "No result found"));
		this.mockMvc.perform(post("/paymenthub/v1/wallet").contentType(MediaType.APPLICATION_JSON)
				.content(createGetPayMethodReq()).headers(headers)).andExpect(status().is2xxSuccessful());
	}
	
	
	@Test
	public void test_addPaymentMethods() throws Exception {
		UpdatePaymentMethodRequest methodRequest = new UpdatePaymentMethodRequest();
		methodRequest.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("name");
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("adft");
		billingAddress.setCity("California");
		billingAddress.setCountry("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		creditCardDetails.setCreditCardNumber("1234567897894561");
		creditCardDetails.setCreditCardType("MC");
		creditCardDetails.setExpirationMonth("02");
		creditCardDetails.setExpirationYear("2025");
		creditCardDetails.setIntegrityCheck("efgh145614789564");
		creditCardDetails.setKeyID("ddd45891");
		creditCardDetails.setPhaseID("0");
		paymentMethod.setCreditCardDetails(creditCardDetails);
		paymentMethod.setPaymentType("CC");
		methodRequest.setPaymentMethod(paymentMethod);
		given(service.addOrUpdatePaymentMethod(new UpdatePaymentMethodRequest(), "ADD")).willReturn(getMockUpdatePayMethodRes());
		this.mockMvc.perform(post("/paymenthub/v1/wallet/add").contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(methodRequest)).headers(headers)).andExpect(status().isOk());
	}
	
	
	@Test
	public void test_updatePaymentMethods() throws Exception {
		UpdatePaymentMethodRequest methodRequest = new UpdatePaymentMethodRequest();
		methodRequest.setAcid("1234");
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("name");
		paymentMethod.setPaymentMethodId("N19S1QUV9YX0");
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("adft");
		billingAddress.setCity("California");
		billingAddress.setCountry("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		creditCardDetails.setCreditCardNumber("1234567897894561");
		creditCardDetails.setCreditCardType("MC");
		creditCardDetails.setExpirationMonth("02");
		creditCardDetails.setExpirationYear("2025");
		creditCardDetails.setIntegrityCheck("efgh145614789564");
		creditCardDetails.setKeyID("ddd45891");
		creditCardDetails.setPhaseID("0");
		paymentMethod.setCreditCardDetails(creditCardDetails);
		paymentMethod.setPaymentType("CC");
		methodRequest.setPaymentMethod(paymentMethod);
		given(service.addOrUpdatePaymentMethod(new UpdatePaymentMethodRequest(), "UPD")).willReturn(getMockUpdatePayMethodRes());
		this.mockMvc.perform(post("/paymenthub/v1/wallet/update").contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(methodRequest)).headers(headers)).andExpect(status().isOk());
	}
	
	
	@Test
	public void test_deletePaymentMethods() throws Exception {
		DeletePaymentMethodRequest request = new DeletePaymentMethodRequest();
		request.setAcid("1234");
	
		request.setPaymentMethodID("N19S1QUV9YX0");
		this.mockMvc.perform(post("/paymenthub/v1/wallet/delete").contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request)).headers(headers)).andExpect(status().isOk());
	}
	
	
	@Test
	public void test_getPaymentHistory() throws Exception {
		this.mockMvc.perform(post("/paymenthub/v1/payment/history").contentType(MediaType.APPLICATION_JSON)
				.content(createGetPayMethodReq()).headers(headers)).andExpect(status().isOk());
	}
	

	@Test
	public void test_submitPayment() throws Exception {
		SubmitPaymentRequest request = new SubmitPaymentRequest();
		request.setAcid("1234");
		List<Service> services = new ArrayList<Service>();
		Service service = new Service();
		service.setAmount("12");
		service.setSku("456");
		services.add(service);
		request.setServices(services);
		Payment payment = new Payment();
		payment.setPaymentAmount("12");
		payment.setPaymentDate(dateToStr(new Date()));
		PaymentMethod paymentMethod = new PaymentMethod();
		paymentMethod.setAccNickName("test");
		paymentMethod.setAccountHolderName("name");
		BillingAddress billingAddress = new BillingAddress();
		billingAddress.setAddressLine1("adft");
		billingAddress.setCity("California");
		billingAddress.setCountry("CA");
		billingAddress.setPostalCode("90001");
		billingAddress.setState("CA");
		paymentMethod.setBillingAddress(billingAddress);
		paymentMethod.setPaymentFutureUse(true);
		CreditCardDetails creditCardDetails = new CreditCardDetails();
		creditCardDetails.setCreditCardNumber("1234567897894561");
		creditCardDetails.setCreditCardType("MC");
		creditCardDetails.setExpirationMonth("02");
		creditCardDetails.setExpirationYear("2025");
		creditCardDetails.setIntegrityCheck("efgh145614789564");
		creditCardDetails.setKeyID("ddd45891");
		creditCardDetails.setPhaseID("0");
		paymentMethod.setCreditCardDetails(creditCardDetails);
		paymentMethod.setPaymentType("CC");
		payment.setPaymentMethod(paymentMethod);
		request.setPayments(payment);
		request.setServices(services);
		this.mockMvc.perform(post("/paymenthub/v1/payment/submit").contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request)).headers(headers)).andExpect(status().isOk());
	}
	
	
	@Test
	public void test_cancelPayment() throws Exception {
		CancelPaymentRequest cancelPaymentRequest = new CancelPaymentRequest();
		cancelPaymentRequest.setAcid("1234");
		cancelPaymentRequest.setOrderId("ampk190321m21412736");
		this.mockMvc.perform(post("/paymenthub/v1/payment/cancel").contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(cancelPaymentRequest)).headers(headers)).andExpect(status().isOk());
	}
	
	
	private static String createGetPayMethodReq() {
		return "{\"acid\" : 1}";
	}
		
	
	private GetPaymentMethodResponse getMockPayMethodsRes() {
		return new GetPaymentMethodResponse();
	}
	
	private UpdatePaymentMethodResponse getMockUpdatePayMethodRes() {
		return new UpdatePaymentMethodResponse();
	}
	
	private DeletePaymentMethodResponse getMockDelPayMethodsRes() {
		return new DeletePaymentMethodResponse();
	}
	
	private PaymentHistoryResponse getMockPayHisRes() {
		return new PaymentHistoryResponse();
	}
	
	private SubmitPaymentResponse getMockSubmitPayRes() {
		return new SubmitPaymentResponse();
	}
	
	private CancelPaymentResponse getMockCancelPayRes() {
		return new CancelPaymentResponse();
	}
	
	public String dateToStr(Date date)
	{
		String dateStr = "";
		try
		{
			if(null != date)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
				dateStr = sdf.format(date);
			}
		} catch (Exception e)
		{
			dateStr = "";
		}
		return dateStr;
	}

}
