package com.anthem.amp.payment.config;


import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.anthem.amp.payment.entity.BankAccount;
import com.anthem.amp.payment.entity.CreditCard;
import com.anthem.amp.payment.entity.FundAccOwnerFullAddress;
import com.anthem.amp.payment.entity.PaymentWallet;
import com.anthem.amp.payment.vo.BankAccountDetails;
import com.anthem.amp.payment.vo.BillingAddress;
import com.anthem.amp.payment.vo.CreditCardDetails;
import com.anthem.amp.payment.vo.PaymentMethod;


@Configuration
public class MappingConfig
{

	@Bean(name = "org.dozer.Mapper")
	public DozerBeanMapper dozerBean()
	{
		DozerBeanMapper dozerBean = new DozerBeanMapper();
		dozerBean.addMapping(getPaymentWallet());
		dozerBean.addMapping(getFundAccFullAddress());
		dozerBean.addMapping(getBankAccDetails());
		dozerBean.addMapping(getCreditCardDetails());
		return dozerBean;
	}

	private BeanMappingBuilder getPaymentWallet() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(PaymentMethod.class, type(PaymentWallet.class))
				.fields("accNickName","tokens[0].accNickName")
				.fields("accountHolderName","tokens[0].nameOnFundingAcc")
				.fields("paymentMethodId","tokens[0].tokenId")
				.fields("paymentType","tokens[0].paymentType");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getFundAccFullAddress() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(BillingAddress.class, type(FundAccOwnerFullAddress.class))
				.fields("addressLine1","address1")
				.fields("addressLine2","address2")
				.fields("city","city")
				.fields("state","state")
				.fields("postalCode","zipcode");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getBankAccDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(BankAccountDetails.class, type(BankAccount.class))
				.fields("bankAccountNumber","bankAccountNumber")
				.fields("routingNumber","bankRoutingNumber");
			}
		};
		return builder;
	}
	
	private BeanMappingBuilder getCreditCardDetails() {
		BeanMappingBuilder builder = new BeanMappingBuilder() {
			
			@Override
			protected void configure() {
				mapping(CreditCardDetails.class, type(CreditCard.class))
				.fields("creditCardNumber","creditCardNumber")
				.fields("expirationMonth","expirationMonth")
				.fields("expirationYear","expirationYear")
				.fields("expirationMonth","expirationMonth")
				.fields("integrityCheck","integrityCheck")
				.fields("keyID","keyID")
				.fields("phaseID","phaseID");
			}
		};
		return builder;
	}
	
}
