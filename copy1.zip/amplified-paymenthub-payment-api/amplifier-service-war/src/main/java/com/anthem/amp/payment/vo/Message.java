package com.anthem.amp.payment.vo;


import java.io.Serializable;


public class Message implements Serializable
{

	private static final long serialVersionUID = 1272505096331547138L;

	private String messageCode;

	private String messageText;

	public String getMessageCode()
	{
		return messageCode;
	}

	public void setMessageCode(String messageCode)
	{
		this.messageCode = messageCode;
	}

	public String getMessageText()
	{
		return messageText;
	}

	public void setMessageText(String messageText)
	{
		this.messageText = messageText;
	}

}
