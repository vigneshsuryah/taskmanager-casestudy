package com.anthem.amp.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Note {
	
	@Field("note_desc")
	private String noteDesc;

	public String getNoteDesc() {
		return noteDesc;
	}

	public void setNoteDesc(String noteDesc) {
		this.noteDesc = noteDesc;
	}
}
