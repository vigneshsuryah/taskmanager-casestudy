package com.anthem.amp.payment.response;

import java.io.Serializable;

public class GetTokenResponse extends BaseResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String encryptedToken;
	private String reasonCode;	
	private String actionCode;
	private String levelTInd;
	private String authorizationCode;
	private String tokenPaidDate;
	
	private String orderId;
	
	//Auth Reversal Changes
	private String accountNumber;
	private String MOP;
	private String responseDate;
	private String numExtraFields;
	private boolean isConvError;
	private String leftOverData;
	private String errorDescription;
	private String avsaav;
	private String cardSecurityValue;
	private String cavv;
	private String expirationDate;
	private String paymentAdviceCode;
	private String recurringPaymentAdviceCode;
	//chase certification changes
	private String messageType;
	private String originalTransactionAmount;
	private String recordType;
	private String submittedTransactionID;
	private String responseTransactionID;
	private String storedCredentialFlag;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getOriginalTransactionAmount() {
		return originalTransactionAmount;
	}

	public void setOriginalTransactionAmount(String originalTransactionAmount) {
		this.originalTransactionAmount = originalTransactionAmount;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}

	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}

	public String getResponseTransactionID() {
		return responseTransactionID;
	}

	public void setResponseTransactionID(String responseTransactionID) {
		this.responseTransactionID = responseTransactionID;
	}

	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}

	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getMOP() {
		return MOP;
	}

	public void setMOP(String mOP) {
		MOP = mOP;
	}

	public String getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}

	public String getNumExtraFields() {
		return numExtraFields;
	}

	public void setNumExtraFields(String numExtraFields) {
		this.numExtraFields = numExtraFields;
	}

	public boolean isConvError() {
		return isConvError;
	}

	public void setConvError(boolean isConvError) {
		this.isConvError = isConvError;
	}

	public String getLeftOverData() {
		return leftOverData;
	}

	public void setLeftOverData(String leftOverData) {
		this.leftOverData = leftOverData;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getAvsaav() {
		return avsaav;
	}

	public void setAvsaav(String avsaav) {
		this.avsaav = avsaav;
	}

	public String getCardSecurityValue() {
		return cardSecurityValue;
	}

	public void setCardSecurityValue(String cardSecurityValue) {
		this.cardSecurityValue = cardSecurityValue;
	}

	public String getCavv() {
		return cavv;
	}

	public void setCavv(String cavv) {
		this.cavv = cavv;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getPaymentAdviceCode() {
		return paymentAdviceCode;
	}

	public void setPaymentAdviceCode(String paymentAdviceCode) {
		this.paymentAdviceCode = paymentAdviceCode;
	}

	public String getRecurringPaymentAdviceCode() {
		return recurringPaymentAdviceCode;
	}

	public void setRecurringPaymentAdviceCode(String recurringPaymentAdviceCode) {
		this.recurringPaymentAdviceCode = recurringPaymentAdviceCode;
	}

	public String getTokenPaidDate() {
		return tokenPaidDate;
	}

	public void setTokenPaidDate(String tokenPaidDate) {
		this.tokenPaidDate = tokenPaidDate;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getLevelTInd() {
		return levelTInd;
	}

	public void setLevelTInd(String levelTInd) {
		this.levelTInd = levelTInd;
	}

	private com.anthem.amp.payment.vo.Exception exceptionDetails;
	
	public String getEncryptedToken() {
		return encryptedToken;
	}

	public void setEncryptedToken(String encryptedToken) {
		this.encryptedToken = encryptedToken;
	}

	public com.anthem.amp.payment.vo.Exception getExceptionDetails() {
		return exceptionDetails;
	}

	public void setExceptionDetails(com.anthem.amp.payment.vo.Exception exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
