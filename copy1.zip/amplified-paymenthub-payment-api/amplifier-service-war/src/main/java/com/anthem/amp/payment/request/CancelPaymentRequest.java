package com.anthem.amp.payment.request;

import com.anthem.amp.payment.vo.Note;

import io.swagger.annotations.ApiModelProperty;

public class CancelPaymentRequest extends BaseRequest {

	@ApiModelProperty(required = true)
	private String orderId;
	private Note notes;
	private String cancelledBy;
	private String paymentChannel;
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Note getNotes() {
		return notes;
	}

	public void setNotes(Note notes) {
		this.notes = notes;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}
}
