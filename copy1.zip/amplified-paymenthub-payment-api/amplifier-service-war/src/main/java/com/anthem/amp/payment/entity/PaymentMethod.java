package com.anthem.amp.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class PaymentMethod {

	@Field("accNickName")
	private String accNickName;
	@Field("accountHolderName")
	private String accountHolderName;
	@Field("paymentFutureUse")
	private Boolean paymentFutureUse;
	@Field("paymentMethodId")
	private String paymentMethodId;
	@Field("paymentType")
	private String paymentType;
	@Field("bankAccountDetails")
	private BankAccountDetails bankAccountDetails;
	@Field("billingAddress")
	private BillingAddress billingAddress;
	@Field("creditCardDetails")
	private CreditCardDetails creditCardDetails;

	public String getAccNickName() {
		return accNickName;
	}

	public void setAccNickName(String accNickName) {
		this.accNickName = accNickName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public Boolean getPaymentFutureUse() {
		return paymentFutureUse;
	}

	public void setPaymentFutureUse(Boolean paymentFutureUse) {
		this.paymentFutureUse = paymentFutureUse;
	}

	public String getPaymentMethodId() {
		return paymentMethodId;
	}

	public void setPaymentMethodId(String paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public BankAccountDetails getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(BankAccountDetails bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}

	public BillingAddress getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public CreditCardDetails getCreditCardDetails() {
		return creditCardDetails;
	}

	public void setCreditCardDetails(CreditCardDetails creditCardDetails) {
		this.creditCardDetails = creditCardDetails;
	}
	
}
