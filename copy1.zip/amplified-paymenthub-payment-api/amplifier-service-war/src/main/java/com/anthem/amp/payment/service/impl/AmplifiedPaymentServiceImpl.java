package com.anthem.amp.payment.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.anthem.amp.payment.entity.BankAccount;
import com.anthem.amp.payment.entity.CreditCard;
import com.anthem.amp.payment.entity.FundAccOwnerFullAddress;
import com.anthem.amp.payment.entity.Note;
import com.anthem.amp.payment.entity.PaymentDetails;
import com.anthem.amp.payment.entity.PaymentWallet;
import com.anthem.amp.payment.entity.Token;
import com.anthem.amp.payment.exception.handler.AmplifiedException;
import com.anthem.amp.payment.repository.PaymentDetailsRepository;
import com.anthem.amp.payment.repository.PaymentWalletRepository;
import com.anthem.amp.payment.request.CancelPaymentRequest;
import com.anthem.amp.payment.request.DeletePaymentMethodRequest;
import com.anthem.amp.payment.request.GetPaymentMethodRequest;
import com.anthem.amp.payment.request.GetTokenRequest;
import com.anthem.amp.payment.request.PaymentHistoryRequest;
import com.anthem.amp.payment.request.SubmitPaymentRequest;
import com.anthem.amp.payment.request.UpdatePaymentMethodRequest;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.response.DeletePaymentMethodResponse;
import com.anthem.amp.payment.response.GetPaymentMethodResponse;
import com.anthem.amp.payment.response.GetTokenResponse;
import com.anthem.amp.payment.response.PaymentHistoryResponse;
import com.anthem.amp.payment.response.SubmitPaymentResponse;
import com.anthem.amp.payment.response.UpdatePaymentMethodResponse;
import com.anthem.amp.payment.service.AmplifiedPaymentService;
import com.anthem.amp.payment.util.AmplifiedPaymentConstants;
import com.anthem.amp.payment.util.AmplifierUtils;
import com.anthem.amp.payment.util.ChaseServiceUtil;
import com.anthem.amp.payment.vo.BankAccountDetails;
import com.anthem.amp.payment.vo.BillingAddress;
import com.anthem.amp.payment.vo.CreditCardDetails;
import com.anthem.amp.payment.vo.Payment;
import com.anthem.amp.payment.vo.PaymentHistory;
import com.anthem.amp.payment.vo.PaymentMethod;

@Service
public class AmplifiedPaymentServiceImpl implements AmplifiedPaymentService, AmplifiedPaymentConstants {


	private final static Logger LOGGER = LoggerFactory.getLogger(AmplifiedPaymentServiceImpl.class);

	@Autowired
	private Mapper dozerMapper;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private PaymentWalletRepository paymentWalletRepository;

	@Autowired
	private PaymentDetailsRepository paymentDetailsRepository;

	@Autowired
	private MongoOperations mongoOperations;

	@Autowired
	private ChaseServiceUtil chaseServiceUtil;

	@Autowired
	private AmplifierUtils amplifierUtils;

	@Override
	public SubmitPaymentResponse submitPayment(SubmitPaymentRequest submitPaymentRequest) throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - submitPayment - Start");
		SubmitPaymentResponse response = new SubmitPaymentResponse();
		String orderIdReturned = "";
		try {
			String orderId = amplifierUtils.generateOrderId("ampk");
			constructTokenResponseForSubmitPayment(submitPaymentRequest, orderId);
			String paymentMethodId = savePaymentWalletInfo(submitPaymentRequest);
			PaymentDetails payDetails = dozerMapper.map(submitPaymentRequest, PaymentDetails.class);
			payDetails.setAcid(submitPaymentRequest.getAcid());
			if (null != payDetails && null != payDetails.getPayments()) {

				com.anthem.amp.payment.entity.Payment paymentObj = payDetails.getPayments();
				com.anthem.amp.payment.entity.CreditCardDetails creditCardDetails = null != paymentObj.getPaymentMethod()
						? paymentObj.getPaymentMethod().getCreditCardDetails()
						: null;
				com.anthem.amp.payment.entity.BankAccountDetails bnkDetails = null != paymentObj.getPaymentMethod()
						? paymentObj.getPaymentMethod().getBankAccountDetails()
						: null;
				if (null != bnkDetails && "ACH".equalsIgnoreCase(paymentObj.getPaymentMethod().getPaymentType())) {
					bnkDetails.setBankAccountType(amplifierUtils.returnPaymentSubType(bnkDetails.getBankAccountType()));
				}
				if (null != creditCardDetails
						&& "CC".equalsIgnoreCase(paymentObj.getPaymentMethod().getPaymentType())) {
					creditCardDetails.setCreditCardType(
							amplifierUtils.returnPaymentSubType(creditCardDetails.getCreditCardType()));
					if (null != submitPaymentRequest && null != submitPaymentRequest.getPayments()) {
						Payment payment = submitPaymentRequest.getPayments();
						CreditCardDetails ccDetails = null != payment.getPaymentMethod()
								? payment.getPaymentMethod().getCreditCardDetails()
								: null;
						if (null != ccDetails && "CC".equalsIgnoreCase(payment.getPaymentMethod().getPaymentType())
								&& null != ccDetails.getCreditCardNumber() && ccDetails.getCreditCardNumber()
								.equalsIgnoreCase(creditCardDetails.getCreditCardNumber())) {

							if (null != ccDetails.getGetTokenResponse()
									&& null != ccDetails.getGetTokenResponse().getExceptionDetails()) {
								throw new AmplifiedException(
										ccDetails.getGetTokenResponse().getExceptionDetails().getCode(),
										ccDetails.getGetTokenResponse().getExceptionDetails().getMessage());
							} else if (null != ccDetails.getGetTokenResponse()) {
								creditCardDetails.setActionCode(ccDetails.getGetTokenResponse().getActionCode());
								creditCardDetails.setCcAuthorizationNumber(
										ccDetails.getGetTokenResponse().getAuthorizationCode());
								creditCardDetails.setCcExpDate(ccDetails.getExpirationMonth()+ccDetails.getExpirationYear().substring(ccDetails.getExpirationYear().length()-2,ccDetails.getExpirationYear().length()));
								creditCardDetails.setCreditCardNumber(ccDetails.getGetTokenResponse().getEncryptedToken());
								GetTokenResponse getTokenResponse = ccDetails.getGetTokenResponse();
								creditCardDetails.setMessageType(getTokenResponse.getMessageType());
								creditCardDetails.setOriginalTransactionAmount(getTokenResponse.getOriginalTransactionAmount());
								creditCardDetails.setRecordType(getTokenResponse.getRecordType());
								creditCardDetails.setResponseTransactionID(getTokenResponse.getResponseTransactionID());
								creditCardDetails.setStoredCredentialFlag(getTokenResponse.getStoredCredentialFlag());
								creditCardDetails.setSubmittedTransactionID(getTokenResponse.getSubmittedTransactionID());
								String ccNo = ccDetails.getCreditCardNumber();
								if (null != ccNo && ccNo.length() == 16) {
									creditCardDetails.setCreditCardFirstSix(ccNo.substring(0, 6));
									creditCardDetails.setCreditCardLastFour(ccNo.substring(ccNo.length() - 4));
								}
								creditCardDetails.setInterchangeQualificationCode("");
								creditCardDetails.setIsLevelThree(ccDetails.getGetTokenResponse().getLevelTInd());
								creditCardDetails
										.setResponseReasonCode(ccDetails.getGetTokenResponse().getReasonCode());
								creditCardDetails.setTokenDate(ccDetails.getGetTokenResponse().getTokenPaidDate());
							}
						}
					}
				}
				paymentObj.setTransactionStatus("PENDING");
				paymentObj.setTransactionType("PAYMENT");
				paymentObj.setCreatedDt(new Date());
//				paymentObj.setCreatedDt(amplifierUtils.strToDate(submitPaymentRequest.getPayments().getPaymentDate()));
				payDetails.setAnthemOrderId(orderId);
				List<com.anthem.amp.payment.vo.Service> services = submitPaymentRequest.getServices();
				com.anthem.amp.payment.entity.Service srvce = null;
				List<com.anthem.amp.payment.entity.Service> srvces = new LinkedList<>();
				for(com.anthem.amp.payment.vo.Service service: services){
					srvce = new com.anthem.amp.payment.entity.Service();
					dozerMapper.map(service,srvce);
					srvce.setQty(Integer.toString(services.size()));
					srvce.setOrder_items_service_Id(amplifierUtils.generateOrderId(""));
					srvces.add(srvce);
				}
				payDetails.setService(srvces);
				paymentObj.setSystem("12"); //Hardcoded - Need to Check
				paymentObj.setMarketSegment("020"); //Hardcoded - Need to Check
				paymentObj.setLegalEntity("10"); //Hardcoded - Need to Check
				paymentObj.setDivisionCode("FHIP"); //Hardcoded - Need to Check
				paymentObj.setTransactionDivisionCode("355959"); //Hardcoded - Need to Check

				paymentDetailsRepository.save(payDetails);
				orderIdReturned = null != payDetails ? payDetails.getAnthemOrderId() : null;

				if(StringUtils.isNotEmpty(paymentMethodId) && StringUtils.isNotBlank(paymentMethodId) && submitPaymentRequest.getPayments().getPaymentMethod().getPaymentFutureUse()){
					response.setPaymentMethodId(paymentMethodId);
				}else{
					response.setPaymentMethodId(null);
				}
				response.setOrderId(orderIdReturned);
				response.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
				LOGGER.info("Inside AmplifiedPaymentServiceImpl - submitPayment - End");
				return response;
			} else {
				throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);
			}
		} catch (Exception e) {
			if (e instanceof AmplifiedException) {
				throw e;
			} else {
				throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);
			}
		}
	}

	private String savePaymentWalletInfo(SubmitPaymentRequest submitPaymentRequest) throws AmplifiedException {
		String paymentMethodId = "";
		if (null != submitPaymentRequest.getPayments() && null != submitPaymentRequest.getPayments().getPaymentMethod() && (null == submitPaymentRequest.getPayments().getPaymentMethod().getPaymentMethodId() ||
				submitPaymentRequest.getPayments().getPaymentMethod().getPaymentMethodId().isEmpty())) {
			PaymentMethod payMethod = submitPaymentRequest.getPayments().getPaymentMethod();
			Token newToken = new Token();
			newToken.setAccNickName(payMethod.getAccNickName());
			newToken.setNameOnFundingAcc(payMethod.getAccountHolderName());
			newToken.setPaymentType(payMethod.getPaymentType());
			if (null != payMethod.getBillingAddress()) {
				FundAccOwnerFullAddress fundAccAddress = dozerMapper.map(payMethod.getBillingAddress(),
						FundAccOwnerFullAddress.class);
				newToken.setFundAccOwnerFullAddress(fundAccAddress);
			}
			if (null != payMethod.getBankAccountDetails()) {
				BankAccount bankAcc = dozerMapper.map(payMethod.getBankAccountDetails(), BankAccount.class);
				bankAcc.setBankAccountType(amplifierUtils.returnPaymentSubType(payMethod.getBankAccountDetails().getBankAccountType()));
				newToken.setBankAccount(bankAcc);
			}
			if (null != payMethod.getCreditCardDetails()) {
				CreditCard creditCard = dozerMapper.map(payMethod.getCreditCardDetails(),
						CreditCard.class);
				creditCard.setCreditCardType(amplifierUtils.returnPaymentSubType(payMethod.getCreditCardDetails().getCreditCardType()));

				GetTokenResponse getTokenResponse = payMethod.getCreditCardDetails().getGetTokenResponse();
				if (null != getTokenResponse && null != getTokenResponse.getExceptionDetails()) {
					throw new AmplifiedException(getTokenResponse.getExceptionDetails().getCode(),
							getTokenResponse.getExceptionDetails().getMessage());
				} 
				creditCard.setCreditCardTokenNumber(getTokenResponse.getEncryptedToken());
				newToken.setCreditCard(creditCard);
			}
			if (null != submitPaymentRequest.getPayments() && null != submitPaymentRequest.getPayments().getPaymentMethod()) {
				String status = submitPaymentRequest.getPayments().getPaymentMethod().getPaymentFutureUse() ? ACTIVE_STR : INACTIVE_STR;
				newToken.setStatus(status);
			}
			newToken.setCreatedDt(new Date());
			newToken.setCreatedId(submitPaymentRequest.getAcid());
			paymentMethodId = amplifierUtils.getRandomString(12);
			newToken.setTokenId(paymentMethodId);
			payMethod.setPaymentMethodId(paymentMethodId);
			List<PaymentWallet> payWallets = paymentWalletRepository.getPaymentWalletByAcid(submitPaymentRequest.getAcid());
			if(null != payWallets && payWallets.size() > 0) {
				for(PaymentWallet payWallet : payWallets) {
					if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
						int count = 0;
						for(Token token : payWallet.getTokens()) {
							if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && payMethod.getPaymentFutureUse()) {
                                findAndModifyInactiveStatus(count, token, submitPaymentRequest.getAcid());
                            }
							count++;
						}
						newToken.setCreatedDt(new Date());
						newToken.setCreatedId(submitPaymentRequest.getAcid());
						newToken.setTokenId(paymentMethodId);
                        findAndModifyToken(submitPaymentRequest.getAcid(),newToken, payWallet, newToken.getTokenId());
					}
				}
			}else {
				paymentMethodId = submitPaymentRequest.getPayments().getPaymentMethod().getPaymentMethodId();
				PaymentWallet paymentWallet = dozerMapper.map(submitPaymentRequest.getPayments().getPaymentMethod(),
						PaymentWallet.class);
				paymentWallet.setAcid(submitPaymentRequest.getAcid());
				Token[] tokens = new Token[1];
				tokens[0] = newToken;
				paymentWallet.setTokens(tokens);
				mongoTemplate.save(paymentWallet);
			}
		}
		return paymentMethodId;
	}

	private void constructTokenResponseForSubmitPayment(SubmitPaymentRequest submitPaymentRequest, String orderID) throws AmplifiedException {
		GetTokenResponse getTokenResponse = new GetTokenResponse();
		String tokenNumber = null;
		boolean hasActiveTokens = false;
		if (null != submitPaymentRequest && null != submitPaymentRequest.getPayments()) {
			Payment paymentObj = submitPaymentRequest.getPayments();
			if(null != paymentObj.getPaymentMethod() && null != paymentObj.getPaymentMethod().getPaymentMethodId() && !paymentObj.getPaymentMethod().getPaymentMethodId().isEmpty()) {
				PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						submitPaymentRequest.getAcid(), paymentObj.getPaymentMethod().getPaymentMethodId());
				if(null != paymentWallet && null != paymentWallet.getTokens() && paymentWallet.getTokens().length > 0) {
					for (Token token : paymentWallet.getTokens()) {
						if(paymentObj.getPaymentMethod().getPaymentMethodId().equalsIgnoreCase(token.getTokenId())) {
							PaymentMethod payMethod = new PaymentMethod();
							if(ACTIVE_STR.equalsIgnoreCase(token.getStatus())){
								hasActiveTokens = true;
							}
							boolean payFutureUse = ACTIVE_STR.equalsIgnoreCase(token.getStatus());
							payMethod.setPaymentFutureUse(payFutureUse);
							payMethod.setAccNickName(token.getAccNickName());
							payMethod.setAccountHolderName(token.getNameOnFundingAcc());
							if (null != token.getBankAccount()) {
								BankAccountDetails bankAccountDetails = dozerMapper.map(token.getBankAccount(),
										BankAccountDetails.class);
								bankAccountDetails.setBankAccountType(
										amplifierUtils.convertPaymentSubType(token.getBankAccount().getBankAccountType()));
								payMethod.setBankAccountDetails(bankAccountDetails);
							}
							if (null != token.getFundAccOwnerFullAddress()) {
								payMethod.setBillingAddress(
										dozerMapper.map(token.getFundAccOwnerFullAddress(), BillingAddress.class));
							}
							if (null != token.getCreditCard()) {
								CreditCardDetails creditCardDetails = dozerMapper.map(token.getCreditCard(),
										CreditCardDetails.class);
								tokenNumber = token.getCreditCard().getCreditCardTokenNumber();
								if(StringUtils.isEmpty(tokenNumber) || StringUtils.isBlank(tokenNumber)){
									throw new AmplifiedException("PP-1300","Credit Card details are expired.");
								}
								creditCardDetails.setCreditCardType(
										amplifierUtils.convertPaymentSubType(token.getCreditCard().getCreditCardType()));
								payMethod.setCreditCardDetails(creditCardDetails);
							}
							payMethod.setPaymentMethodId(token.getTokenId());
							payMethod.setPaymentType(token.getPaymentType());
							paymentObj.setPaymentMethod(payMethod);
							break;
						}

					}
				}else {
					throw new AmplifiedException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008);
				}
				if(!hasActiveTokens){
					throw new AmplifiedException("PP-1301","No active payment methods found");
				}
			}
			if (null != paymentObj.getPaymentMethod()
					&& "CC".equalsIgnoreCase(paymentObj.getPaymentMethod().getPaymentType())
					&& null != paymentObj.getPaymentMethod().getCreditCardDetails()) {
				String ccNo = null;
				GetTokenRequest getTokenRequest = new GetTokenRequest();
				if(
						StringUtils.isNotBlank(submitPaymentRequest.getPayments().getPaymentMethod().getPaymentMethodId()) &&
						StringUtils.isNotEmpty(submitPaymentRequest.getPayments().getPaymentMethod().getPaymentMethodId())){
					ccNo = tokenNumber;
					getTokenRequest.setEncryptionFlag("204");
					getTokenRequest.setStoredCredentialFlag("Y");
					getTokenRequest.setMessageType("CUSE");
				}else{
					ccNo = paymentObj.getPaymentMethod().getCreditCardDetails().getCreditCardNumber();
					getTokenRequest.setEncryptionFlag("201");
				}
				getTokenRequest.setMerchantOrderNumber(orderID);
				getTokenRequest.setAccountNumber(ccNo);
				getTokenRequest.setCardHolderName(paymentObj.getPaymentMethod().getAccountHolderName());
                setBillAddrToTokenizeRequest(getTokenRequest, paymentObj.getPaymentMethod());
                String paymentAmount = "";
				if(null != paymentObj.getPaymentAmount() && !paymentObj.getPaymentAmount().isEmpty()){
					paymentAmount = amplifierUtils.roundUp(paymentObj.getPaymentAmount(), 2);
				} else{
					Double totalAmount = 0.0;
					for(com.anthem.amp.payment.vo.Service service: submitPaymentRequest.getServices()){
						if(StringUtils.isNotBlank(service.getAmount()) && StringUtils.isNotEmpty(service.getAmount())){
							totalAmount+=Double.valueOf(service.getAmount());
						}
					}
					paymentAmount = amplifierUtils.roundUp(Double.toString(totalAmount), 2);
				}
				paymentAmount = paymentAmount.replace(".","");

				getTokenRequest.setAmount(paymentAmount);

				if (null != paymentObj.getPaymentMethod().getCreditCardDetails().getExpirationMonth()
						&& null != paymentObj.getPaymentMethod().getCreditCardDetails().getExpirationYear()) {
					getTokenRequest.setExpirationDate(paymentObj.getPaymentMethod().getCreditCardDetails()
							.getExpirationMonth()
							+ paymentObj.getPaymentMethod().getCreditCardDetails().getExpirationYear().substring(
							paymentObj.getPaymentMethod().getCreditCardDetails().getExpirationYear().length()
									- 2));
				}
				getTokenRequest
						.setIntegrityCheck(paymentObj.getPaymentMethod().getCreditCardDetails().getIntegrityCheck());
				getTokenRequest.setKeyID(paymentObj.getPaymentMethod().getCreditCardDetails().getKeyID());
				getTokenRequest.setPhaseID(paymentObj.getPaymentMethod().getCreditCardDetails().getPhaseID());
				String ccType = paymentObj.getPaymentMethod().getCreditCardDetails().getCreditCardType();
				getTokenRequest.setMethodOfPayment(
						(null != ccType && !ccType.isEmpty() && "VISA".equalsIgnoreCase(ccType)) ? "VI" : ccType);
                if(!hasActiveTokens){
                    getTokenRequest.setMessageType("CSTO");
                    getTokenRequest.setStoredCredentialFlag("N");
                } else{
                    getTokenRequest.setMessageType("CUSE");
                    getTokenRequest.setStoredCredentialFlag("Y");
                }
				getTokenResponse = chaseServiceUtil.getTokenInformation(getTokenRequest,"PD");
				if(null!=getTokenResponse && null!= getTokenResponse.getExceptionDetails()){
					com.anthem.amp.payment.vo.Exception exceptionDetails = getTokenResponse.getExceptionDetails();
					throw new AmplifiedException(exceptionDetails.getCode(), exceptionDetails.getMessage());
				}
				paymentObj.getPaymentMethod().getCreditCardDetails().setGetTokenResponse(getTokenResponse);
			}
		}
	}

    private void setBillAddrToTokenizeRequest(GetTokenRequest getTokenRequest, PaymentMethod paymentMethod) {
        if (null != paymentMethod.getBillingAddress()) {
//            getTokenRequest
//                    .setAddressLine1(paymentMethod.getBillingAddress().getAddressLine1());
//            getTokenRequest.setCity(paymentMethod.getBillingAddress().getCity());
            getTokenRequest.setPostalCode(paymentMethod.getBillingAddress().getPostalCode());
//            getTokenRequest.setState(paymentMethod.getBillingAddress().getState());
        }
    }

    @Override
	public CancelPaymentResponse cancelPayment(CancelPaymentRequest cancelPaymentRequest) throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - cancelPayment - Start");
		CancelPaymentResponse response = new CancelPaymentResponse();
		boolean isPaymentCancelled = false;

		String errorMessage = "DNF";
		try {
			String orderId = cancelPaymentRequest.getOrderId();

			List<PaymentDetails> paymentDetailsByOrderId = paymentDetailsRepository.getPaymentDetailsByAOID(orderId,cancelPaymentRequest.getAcid());

			if (null != paymentDetailsByOrderId && paymentDetailsByOrderId.size() > 0) {
				for (PaymentDetails payDetailByOrderId : paymentDetailsByOrderId) {
					if (null != payDetailByOrderId.getPayments()) {
						com.anthem.amp.payment.entity.Payment payment = payDetailByOrderId.getPayments();
						String transactionStatus = payment.getTransactionStatus();
						String transactionType = payment.getTransactionType();

						if (null != transactionStatus && null != transactionType
								&& "PAYMENT".equalsIgnoreCase(transactionType)
								&& "PENDING".equalsIgnoreCase(transactionStatus)) {
							GetTokenResponse getTokenResponse = new GetTokenResponse();
							if(null != payDetailByOrderId.getPayments() && null != payDetailByOrderId.getPayments().getPaymentMethod() && 
									"CC".equalsIgnoreCase(payDetailByOrderId.getPayments().getPaymentMethod().getPaymentType())){
								getTokenResponse = doAuthReversal(payDetailByOrderId);
								if(null!=getTokenResponse && null != getTokenResponse.getExceptionDetails()) {
									throw new AmplifiedException(getTokenResponse.getExceptionDetails().getCode(),
											getTokenResponse.getExceptionDetails().getMessage());
								}
							}
							Query query = new Query();
							query.addCriteria(Criteria.where("anthem_orderid").is(orderId));

							Update update = new Update();
							update.set("payments.transaction_status", "CANCELLED");
							update.set("payments.updated_dt", new Date());
							if (null != cancelPaymentRequest.getNotes()) {
								Note cancelNote = dozerMapper.map(cancelPaymentRequest.getNotes(), Note.class);
								List<Note> notes = payment.getNotes();
								if (null != notes) {
                                    notes.add(cancelNote);
                                    update.set("payments.notes", notes);
								}
							}
							// update cancel details node - auth reversal changes
							com.anthem.amp.payment.entity.CancelDetails cancelDetails = new com.anthem.amp.payment.entity.CancelDetails();
							cancelDetails.setCancelledBy(cancelPaymentRequest.getCancelledBy()); // have to check
							cancelDetails.setPaymentChannel(cancelPaymentRequest.getPaymentChannel()); // have to check
							
							if(null != getTokenResponse && null != payDetailByOrderId.getPayments() && null != payDetailByOrderId.getPayments().getPaymentMethod() && 
									"CC".equalsIgnoreCase(payDetailByOrderId.getPayments().getPaymentMethod().getPaymentType())){
								cancelDetails.setAccountNumber(getTokenResponse.getAccountNumber());
								cancelDetails.setExpirationDate(getTokenResponse.getExpirationDate());
								cancelDetails.setAvsaav(getTokenResponse.getAvsaav());
								cancelDetails.setCardSecurityValue(getTokenResponse.getCardSecurityValue());
								cancelDetails.setCavv(getTokenResponse.getCavv());
								cancelDetails.setMOP(getTokenResponse.getMOP());
								cancelDetails.setPaymentAdviceCode(getTokenResponse.getPaymentAdviceCode());
								cancelDetails.setRecurringPaymentAdviceCode(getTokenResponse.getRecurringPaymentAdviceCode());
								cancelDetails.setResponseDate(getTokenResponse.getResponseDate());
								cancelDetails.setTokenNumber(getTokenResponse.getEncryptedToken());
							}
							
							update.set("payments.cancelDetails", cancelDetails);
							
							mongoOperations.findAndModify(query, update, PaymentDetails.class);
							isPaymentCancelled = true;
						}
					}
				}
			}
		} catch (AmplifiedException e){
			throw e;
		}catch (Exception e) {
			isPaymentCancelled = false;
		}
		if (!isPaymentCancelled) {
			response.setStatus(errorMessage);
			response.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
		} else {
			response.setStatus("Cancelled");
			response.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
		}
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - cancelPayment - End");
		return response;
	}

	@Override
	public UpdatePaymentMethodResponse addOrUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action)
			throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - addOrUpdatePaymentMethod - Start");
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		String tokenId = amplifierUtils.getRandomString(12);
		try {
			if("ADD".equalsIgnoreCase(action)) {
				updatePaymentMethodRequest.getPaymentMethod().setPaymentFutureUse(true);
				List<PaymentWallet> payWallets = paymentWalletRepository.getPaymentWalletByAcid(updatePaymentMethodRequest.getAcid());
				if(null != payWallets && payWallets.size() > 0) {
					for(PaymentWallet payWallet : payWallets) {
						if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
							int count = 0;
							for(Token token : payWallet.getTokens()) {
								if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != updatePaymentMethodRequest.getPaymentMethod() &&
										updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse()) {
                                    findAndModifyInactiveStatus(count, token, updatePaymentMethodRequest.getAcid());
                                }
								count++;
							}
                            Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
                            findAndModifyToken(updatePaymentMethodRequest.getAcid(),newToken, payWallet, tokenId);
                        }
					}
				}else {
					PaymentWallet paymentWallet = dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod(),
							PaymentWallet.class);
					paymentWallet.setAcid(updatePaymentMethodRequest.getAcid());
					constructPaymentWalletForAdd(updatePaymentMethodRequest, paymentWallet);
					paymentWallet.getTokens()[0].setCreatedDt(new Date());
					paymentWallet.getTokens()[0].setCreatedId(updatePaymentMethodRequest.getAcid());
					paymentWallet.getTokens()[0].setTokenId(tokenId);
//					tokenId = paymentWallet.getTokens()[0].getTokenId();
					mongoTemplate.save(paymentWallet);
				}
				
			}else if("UPD".equalsIgnoreCase(action) && null != updatePaymentMethodRequest.getPaymentMethod()) {
				boolean hasActive = false;
				PaymentWallet payWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						updatePaymentMethodRequest.getAcid(), updatePaymentMethodRequest.getPaymentMethod().getPaymentMethodId());

				if(null != payWallet && null != payWallet.getTokens() && payWallet.getTokens().length > 0) {
					Token[] tokens = Arrays.stream(payWallet.getTokens()).filter(token -> ACTIVE_STR.equalsIgnoreCase(token.getStatus()))
							.filter(token -> token.getTokenId().equalsIgnoreCase(updatePaymentMethodRequest.getPaymentMethod().getPaymentMethodId())).toArray(Token[]::new);
					if(tokens.length==0){
						throw new AmplifiedException(AMP_ERR_CODE_1009, AMP_ERR_MSG_PP_1009);
					}else {
						payWallet.setTokens(tokens);
					}
					int count = 0;
					for(Token token : payWallet.getTokens()) {
						if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() &&
								token.getTokenId().equalsIgnoreCase(updatePaymentMethodRequest.getPaymentMethod().getPaymentMethodId()) && updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse()) {
                            findAndModifyInactiveStatus(count, token, updatePaymentMethodRequest.getAcid());
                        }
						count++;
					}
                    Token newToken = constructPaymentWalletForUpd(updatePaymentMethodRequest);
                    findAndModifyToken(updatePaymentMethodRequest.getAcid(),newToken, payWallet, tokenId);
                }else {
					throw new AmplifiedException(AMP_ERR_CODE_1009, AMP_ERR_MSG_PP_1009);
				}
			}
			paymentMethodResponse.setPaymentMethodId(tokenId);
			paymentMethodResponse.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
		}
		catch(Exception e) {
			LOGGER.error("Exception in add/update payment method: " + e);
			if (e instanceof AmplifiedException) {
				AmplifiedException ex = (AmplifiedException) e;
				if(AMP_ERR_CODE_1008.equalsIgnoreCase(ex.getErrorCode())) {
					throw e;
				}else {
					throw new AmplifiedException(ex.getErrorCode(), ex.getErrorMessage());
				}
			} else {
				throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);

			}
		}

		LOGGER.info("Inside AmplifiedPaymentServiceImpl - addOrUpdatePaymentMethod - End");
		return paymentMethodResponse;
	}

    private void findAndModifyToken(String acid,Token newToken, PaymentWallet payWallet, String tokenId){
        newToken.setCreatedDt(new Date());
        newToken.setCreatedId(acid);
        newToken.setTokenId(tokenId);
        Query query = new Query();
        query.addCriteria(Criteria.where("acid").is(acid));
        Update update = new Update();
        update.set("tokens." + payWallet.getTokens().length, newToken);
        mongoOperations.findAndModify(query, update, PaymentWallet.class);
    }


    private void constructPaymentWalletForAdd(UpdatePaymentMethodRequest updatePaymentMethodRequest,
			PaymentWallet paymentWallet) throws AmplifiedException {
		Token[] tokens = new Token[1];
		tokens[0] = constructPaymentWalletForUpd(updatePaymentMethodRequest);
		paymentWallet.setTokens(tokens);
	}
	
	private Token constructPaymentWalletForUpd(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws AmplifiedException {
		Token token = new Token();
		token.setAccNickName(updatePaymentMethodRequest.getPaymentMethod().getAccNickName());
		token.setNameOnFundingAcc(updatePaymentMethodRequest.getPaymentMethod().getAccountHolderName());
		token.setPaymentType(updatePaymentMethodRequest.getPaymentMethod().getPaymentType());
		if (null != updatePaymentMethodRequest.getPaymentMethod().getBillingAddress()) {
			FundAccOwnerFullAddress fundAccAddress = dozerMapper.map(
					updatePaymentMethodRequest.getPaymentMethod().getBillingAddress(), FundAccOwnerFullAddress.class);
			token.setFundAccOwnerFullAddress(fundAccAddress);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails()) {
			BankAccount bankAcc = dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails(),
					BankAccount.class);
			bankAcc.setBankAccountType(amplifierUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getBankAccountDetails().getBankAccountType()));
			token.setBankAccount(bankAcc);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()) {
			CreditCard creditCard =  dozerMapper.map(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails(),
					CreditCard.class);
			creditCard.setCreditCardType(amplifierUtils.returnPaymentSubType(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardType()));
			String ccNo = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getCreditCardNumber();
			GetTokenRequest getTokenRequest = new GetTokenRequest();
			getTokenRequest.setMerchantOrderNumber(amplifierUtils.generateOrderId("ampk"));
			getTokenRequest.setEncryptionFlag("201");
			getTokenRequest.setAccountNumber(ccNo);
			getTokenRequest.setCardHolderName(updatePaymentMethodRequest.getPaymentMethod().getAccountHolderName());
			String paySubType = creditCard.getCreditCardType();
			getTokenRequest.setMethodOfPayment(
					(null != paySubType && !paySubType.isEmpty() && "VISA".equalsIgnoreCase(paySubType)) ? "VI"
							: paySubType);
            setBillAddrToTokenizeRequest(getTokenRequest, updatePaymentMethodRequest.getPaymentMethod());
            getTokenRequest.setAmount("0"); // have to check -- hardcoded
			if (null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth()
					&& null != updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
					.getExpirationYear()) {
				String expYear = updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails()
						.getExpirationYear();
				getTokenRequest.setExpirationDate(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getExpirationMonth() + expYear.substring(expYear.length() - 2));
			}
			getTokenRequest.setIntegrityCheck(
					updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getIntegrityCheck());
			getTokenRequest.setMessageType("CSTO");
			getTokenRequest.setStoredCredentialFlag("N");
			getTokenRequest.setKeyID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getKeyID());
			getTokenRequest
			.setPhaseID(updatePaymentMethodRequest.getPaymentMethod().getCreditCardDetails().getPhaseID());


			GetTokenResponse getTokenResponse = chaseServiceUtil.getTokenInformation(getTokenRequest,"PW");
			if (null != getTokenResponse && null != getTokenResponse.getExceptionDetails()) {
				throw new AmplifiedException(getTokenResponse.getExceptionDetails().getCode(),
						getTokenResponse.getExceptionDetails().getMessage());
			} 
			creditCard.setCreditCardTokenNumber(getTokenResponse.getEncryptedToken());
			token.setCreditCard(creditCard);
		}
		if (null != updatePaymentMethodRequest.getPaymentMethod()) {
			String status = updatePaymentMethodRequest.getPaymentMethod().getPaymentFutureUse() ? ACTIVE_STR : INACTIVE_STR;
			token.setStatus(status);
		}
		return token;
	}

	@Override
	public DeletePaymentMethodResponse deletePaymentMethod(DeletePaymentMethodRequest deletePaymentMethodRequest)
			throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - deletePaymentMethod - Start");
		DeletePaymentMethodResponse deletePaymentMethodResponse = new DeletePaymentMethodResponse();
		try {
			if (null != deletePaymentMethodRequest.getPaymentMethodID()) {
				PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(
						deletePaymentMethodRequest.getAcid(), deletePaymentMethodRequest.getPaymentMethodID());
				if (null != paymentWallet && null != paymentWallet.getTokens()
						&& paymentWallet.getTokens().length > 0) {
					int count = 0;
					boolean hasActive = false;
					for(Token token : paymentWallet.getTokens()) {
						if(null != token && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && null != token.getTokenId() && 
								token.getTokenId().equalsIgnoreCase(deletePaymentMethodRequest.getPaymentMethodID())) {
							hasActive = true;
                            findAndModifyInactiveStatus(count, token, deletePaymentMethodRequest.getAcid());
                        }
						count++;
					}
					if(!hasActive){
						throw new AmplifiedException("1009","This Payment Method is already deleted.");
					}
				}else {
					throw new AmplifiedException(AMP_ERR_CODE_1008, AMP_ERR_MSG_1008);
				}
				deletePaymentMethodResponse.setPaymentMethodId(deletePaymentMethodRequest.getPaymentMethodID());
				deletePaymentMethodResponse.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
			}
		} catch (Exception e) {
			LOGGER.error("Exception in delete payment method: " + e);
			if (e instanceof AmplifiedException) {
				throw e;
			} else {
				throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);

			}
		}
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - deletePaymentMethod - End");
		return deletePaymentMethodResponse;
	}

    private void findAndModifyInactiveStatus(int count, Token token, String acid) {
        token.setUpdatedDt(new Date());
        token.setUpdatedId(acid);
        token.setStatus(INACTIVE_STR);
        Query query = new Query();
        query.addCriteria(Criteria.where("acid").is(acid).and("tokens." + count + ".token_id").is(token.getTokenId()));
        Update update = new Update();
        update.set("tokens." + count, token);
        mongoOperations.findAndModify(query, update, PaymentWallet.class);
    }

    @Override
	public GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest)
			throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - getPaymentMethods - start");
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		try {
			if (null != getPaymentMethodRequest.getAcid()) {
				List<PaymentWallet> paymentWallets = null;
				if (null != getPaymentMethodRequest.getPaymentMethodID()
						&& !getPaymentMethodRequest.getPaymentMethodID().isEmpty()) {
					if (null != getPaymentMethodRequest.getStatus() && !getPaymentMethodRequest.getStatus().isEmpty()) {
						paymentWallets = paymentWalletRepository.getPaymentWalletForTokenID(
								getPaymentMethodRequest.getAcid(), getPaymentMethodRequest.getStatus().toUpperCase(),
								getPaymentMethodRequest.getPaymentMethodID());
                        paymentWallets = filterPaymentWalletsWithPayID(getPaymentMethodRequest, paymentWallets);
                    } else{
                        paymentWallets = filterPaymentWalletsWithPayID(getPaymentMethodRequest, null);
                    }
				} else {
					if (null != getPaymentMethodRequest.getStatus() && !getPaymentMethodRequest.getStatus().isEmpty()) {
						paymentWallets = paymentWalletRepository.getPaymentWalletWithStatus(
								getPaymentMethodRequest.getAcid(), getPaymentMethodRequest.getStatus().toUpperCase());
					} else {
						paymentWallets = paymentWalletRepository.getPaymentWalletByAcid(getPaymentMethodRequest.getAcid());
					}
				}
				if (null != paymentWallets && paymentWallets.size() > 0) {
					List<PaymentMethod> paymentMethods = new ArrayList<PaymentMethod>();
					for (PaymentWallet payment : paymentWallets) {
						if (null != payment.getTokens() && payment.getTokens().length > 0) {
							for (Token token : payment.getTokens()) {
								if(null ==  getPaymentMethodRequest.getStatus() || getPaymentMethodRequest.getStatus().equalsIgnoreCase(token.getStatus())) {
									PaymentMethod payMethod = new PaymentMethod();
									boolean payFutureUse = ACTIVE_STR.equalsIgnoreCase(token.getStatus());
									payMethod.setPaymentFutureUse(payFutureUse);
									payMethod.setAccNickName(token.getAccNickName());
									payMethod.setAccountHolderName(token.getNameOnFundingAcc());
									if (null != token.getBankAccount()) {
										BankAccountDetails bankAccountDetails = dozerMapper.map(token.getBankAccount(),
												BankAccountDetails.class);
										String accNo = bankAccountDetails.getBankAccountNumber();
										accNo = "*"+ accNo.subSequence(accNo.length()-4, accNo.length());
										bankAccountDetails.setBankAccountNumber(accNo);
										bankAccountDetails.setBankAccountType(
												amplifierUtils.convertPaymentSubType(token.getBankAccount().getBankAccountType()));
										payMethod.setBankAccountDetails(bankAccountDetails);
									}
									if (null != token.getFundAccOwnerFullAddress()) {
										payMethod.setBillingAddress(
												dozerMapper.map(token.getFundAccOwnerFullAddress(), BillingAddress.class));
									}
									if (null != token.getCreditCard()) {
										CreditCardDetails creditCardDetails = dozerMapper.map(token.getCreditCard(),
												CreditCardDetails.class);
										creditCardDetails.setCreditCardType(
												amplifierUtils.convertPaymentSubType(token.getCreditCard().getCreditCardType()));
										creditCardDetails.setIntegrityCheck(null);
										creditCardDetails.setKeyID(null);
										creditCardDetails.setPhaseID(null);
										String ccNo = amplifierUtils.maskString(creditCardDetails.getCreditCardNumber(), 0,creditCardDetails.getCreditCardNumber().length() - 4, '*');
										creditCardDetails.setCreditCardNumber(ccNo);
										payMethod.setCreditCardDetails(creditCardDetails);
									}
									payMethod.setPaymentMethodId(token.getTokenId());
									payMethod.setPaymentType(token.getPaymentType());

									paymentMethods.add(payMethod);
								}

							}
						}
					}
					response.setPaymentMethods(paymentMethods);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getPaymentMethods " + e);
			throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);
		}
		if(null != response && (null == response.getPaymentMethods() || response.getPaymentMethods().isEmpty())){
			throw new AmplifiedException(AMP_ERR_CODE_1009, AMP_ERR_MSG_1009);
		}
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - getPaymentMethods - End");
		return response;
	}

    private List<PaymentWallet> filterPaymentWalletsWithPayID(GetPaymentMethodRequest getPaymentMethodRequest, List<PaymentWallet> paymentWallets) {
        List<PaymentWallet> wallets = new LinkedList<>();
        PaymentWallet paymentWallet= paymentWalletRepository.getPaymentWalletWithTokenID(getPaymentMethodRequest.getAcid(), getPaymentMethodRequest.getPaymentMethodID());
        Token[] tokens = null;
        if(null!=paymentWallet){
            tokens = Arrays.stream(paymentWallet.getTokens())
                    .filter(token -> token.getTokenId().equalsIgnoreCase(getPaymentMethodRequest.getPaymentMethodID()))
                    .toArray(Token[]::new);
        }

        if(null!=tokens && tokens.length>0){
            paymentWallet.setTokens(tokens);
            wallets.add(paymentWallet);
            paymentWallets = wallets;
        }
        return paymentWallets;
    }

    @Override
	public PaymentHistoryResponse getPaymentHistory(PaymentHistoryRequest paymentHistoryRequest)
			throws AmplifiedException {
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - getPaymentHistory - Start");
		PaymentHistoryResponse paymentHistoryResponse = new PaymentHistoryResponse();
		try {
			if (null != paymentHistoryRequest.getAcid() && !paymentHistoryRequest.getAcid().isEmpty()) {
				List<PaymentDetails> paymentDetails = paymentDetailsRepository
						.getPaymentDetailsByAcid(paymentHistoryRequest.getAcid());
				if (null != paymentDetails && paymentDetails.size() > 0) {
					List<PaymentHistory> paymentHistory = new ArrayList<>();
					for (PaymentDetails details : paymentDetails) {
						PaymentHistory history = new PaymentHistory();
						history.setOrderId(details.getAnthemOrderId());
						history.setAcid(paymentHistoryRequest.getAcid());
						if (null != details.getPayments()) {
							com.anthem.amp.payment.entity.Payment paymentObj = details.getPayments();
							Double paymentAmount = 0D;
							Payment actualObj = dozerMapper.map(paymentObj, Payment.class);
							if(null == actualObj.getPaymentAmount()){
                                for(com.anthem.amp.payment.entity.Service service :details.getService()){
                                    if(StringUtils.isNotEmpty(service.getAmount()) && StringUtils.isNotBlank(service.getAmount()))
							        paymentAmount+=Double.parseDouble(service.getAmount());
                                }
                            }
							actualObj.setPaymentAmount(paymentAmount.toString());

							if (null != paymentObj.getPaymentMethod()
									&& null != paymentObj.getPaymentMethod().getCreditCardDetails()) {
								com.anthem.amp.payment.entity.CreditCardDetails ccDetails = paymentObj.getPaymentMethod()
										.getCreditCardDetails();
								String expDate = ccDetails.getCcExpDate();
								String []expArr= new String[2];
								if(expDate.contains("/")){
								    expArr = expDate.split("/");
                                }else{
								    expArr[0] = expDate.substring(0,2);
								    expArr[1] = expDate.substring(2);
                                }
								if (null != actualObj.getPaymentMethod()
										&& null != actualObj.getPaymentMethod().getCreditCardDetails()) {
								    actualObj.getPaymentMethod().getCreditCardDetails().setCreditCardNumber(
								            amplifierUtils.maskString(ccDetails.getCreditCardNumber(),0,ccDetails.getCreditCardNumber().length() - 4, '*'));
									actualObj.getPaymentMethod().getCreditCardDetails().setExpirationMonth(expArr[0]);
									actualObj.getPaymentMethod().getCreditCardDetails().setExpirationYear(expArr[1]);
									actualObj.getPaymentMethod().getCreditCardDetails().setCreditCardType(
											amplifierUtils.convertPaymentSubType(ccDetails.getCreditCardType()));
								}

							}
							if (null != paymentObj.getPaymentMethod()
									&& null != paymentObj.getPaymentMethod().getBankAccountDetails()) {
								if (null != actualObj.getPaymentMethod()
										&& null != actualObj.getPaymentMethod().getBankAccountDetails()) {
								    paymentObj.getPaymentMethod().setPaymentFutureUse(null);
									actualObj.getPaymentMethod().getBankAccountDetails()
											.setBankAccountType(amplifierUtils.convertPaymentSubType(paymentObj
													.getPaymentMethod().getBankAccountDetails().getBankAccountType()));
									String accNo = paymentObj.getPaymentMethod().getBankAccountDetails().getBankAccountNumber();
                                    actualObj.getPaymentMethod().getBankAccountDetails()
                                            .setBankAccountNumber("*"+ accNo.subSequence(accNo.length()-4, accNo.length()));
								}
							}
							if(null!=actualObj.getPaymentMethod().getPaymentFutureUse()){
								actualObj.getPaymentMethod().setPaymentFutureUse(null);
							}
							history.setPayments(actualObj);
						}

						if (null != details.getService()) {
							com.anthem.amp.payment.vo.Service actualObj = null;
							List<com.anthem.amp.payment.vo.Service> actualObjs = new LinkedList<>();
							List<com.anthem.amp.payment.entity.Service> services = details.getService();
							for(com.anthem.amp.payment.entity.Service service: services){
								actualObj = new com.anthem.amp.payment.vo.Service();
								dozerMapper.map(service,actualObj);
								actualObjs.add(actualObj);
							}
							history.setServices(actualObjs);
						}
						paymentHistory.add(history);
					}
					paymentHistoryResponse.setPaymentHistory(paymentHistory);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getPaymentHistory " + e);
			throw new AmplifiedException(AMP_ERR_CODE_1005, AMP_ERR_MSG_1005);
		}
		if(null != paymentHistoryResponse && (null == paymentHistoryResponse.getPaymentHistory() || paymentHistoryResponse.getPaymentHistory().isEmpty())){
			throw new AmplifiedException(AMP_ERR_CODE_1009, AMP_ERR_MSG_1009);
		}
		LOGGER.info("Inside AmplifiedPaymentServiceImpl - getPaymentHistory - End");
		return paymentHistoryResponse;
	}
	
	private GetTokenResponse doAuthReversal(PaymentDetails payDetailByOrderId) {
		GetTokenResponse getTokenResponse = null;

		GetTokenRequest getTokenRequest = new GetTokenRequest();
		com.anthem.amp.payment.entity.PaymentMethod paymentMethod = payDetailByOrderId.getPayments().getPaymentMethod();
		if(null != paymentMethod.getCreditCardDetails()) {
			com.anthem.amp.payment.entity.CreditCardDetails ccDetails = paymentMethod.getCreditCardDetails();
					
			getTokenRequest.setAccountNumber(ccDetails.getCreditCardNumber());
			getTokenRequest.setTokenizedDate(ccDetails.getTokenDate());
			getTokenRequest.setResponseCode(ccDetails.getCcAuthorizationNumber());
			String[] expDte = new String[2];
			if(ccDetails.getCcExpDate().contains("/")){
				 expDte = ccDetails.getCcExpDate().split("/");
			}else{
				expDte[0] = ccDetails.getCcExpDate().substring(0,2);
				expDte[1] = ccDetails.getCcExpDate().substring(2);
			}

			String expDate = expDte[0]+expDte[1].substring(expDte[1].length()-2);
			getTokenRequest.setExpirationDate(expDate);
			getTokenRequest.setMerchantOrderNumber(payDetailByOrderId.getAnthemOrderId());
			getTokenRequest.setEncryptionFlag("204");
			getTokenRequest.setMessageType(payDetailByOrderId.getPayments().getPaymentMethod().getCreditCardDetails().getMessageType());
			getTokenRequest.setStoredCredentialFlag(payDetailByOrderId.getPayments().getPaymentMethod().getCreditCardDetails().getStoredCredentialFlag());
			if(null!=payDetailByOrderId.getPayments().getPaymentMethod().getCreditCardDetails().getSubmittedTransactionID()){
				getTokenRequest.setSubmittedTransactionID(payDetailByOrderId.getPayments().getPaymentMethod().getCreditCardDetails().getSubmittedTransactionID());

			}

			Double totalAmount = 0.0;
			if(null != payDetailByOrderId.getService() && payDetailByOrderId.getService().size() > 0) {
				for(com.anthem.amp.payment.entity.Service service: payDetailByOrderId.getService()){
					if(StringUtils.isNotBlank(service.getAmount()) && StringUtils.isNotEmpty(service.getAmount())){
						totalAmount+=Double.valueOf(service.getAmount());
					}
				}
				String paymentAmount = amplifierUtils.roundUp(Double.toString(totalAmount), 2);
				paymentAmount = paymentAmount.replaceAll("\\.","");
				getTokenRequest.setAmount(paymentAmount);
			}
			if(null != payDetailByOrderId.getPayments()) {
				getTokenRequest.setDivisionCode(payDetailByOrderId.getPayments().getTransactionDivisionCode());
				String ccType = paymentMethod.getCreditCardDetails().getCreditCardType();
				getTokenRequest.setMethodOfPayment((null != ccType && !ccType.isEmpty() && "VISA".equalsIgnoreCase(ccType)) ? "VI" : ccType);
			}
			getTokenResponse = chaseServiceUtil.getTokenInformation(getTokenRequest,"PC");
		}

		return getTokenResponse;
	}


}