package com.anthem.amp.payment.request;

public class DeletePaymentMethodRequest extends BaseRequest {

	private String email;

	private String paymentMethodID;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPaymentMethodID() {
		return paymentMethodID;
	}

	public void setPaymentMethodID(String paymentMethodID) {
		this.paymentMethodID = paymentMethodID;
	}

}
