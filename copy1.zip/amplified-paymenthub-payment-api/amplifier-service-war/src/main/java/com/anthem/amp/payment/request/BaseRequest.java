package com.anthem.amp.payment.request;

import io.swagger.annotations.ApiModelProperty;

public class BaseRequest {

	@ApiModelProperty(required = true)
	private String acid;

	public String getAcid() {
		return acid;
	}

	public void setAcid(String acid) {
		this.acid = acid;
	}


	
	
}
