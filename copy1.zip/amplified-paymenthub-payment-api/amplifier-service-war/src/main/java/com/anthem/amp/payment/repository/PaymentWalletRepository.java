package com.anthem.amp.payment.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.amp.payment.entity.PaymentWallet;

@Repository
public interface PaymentWalletRepository extends MongoRepository<PaymentWallet, String>{

	@Query(value = "{ 'acid' : ?0}")
	List<PaymentWallet> getPaymentWalletByAcid(String acid);
	
	@Query(value = "{ 'acid' : ?0, 'tokens.status' : ?1}")
	List<PaymentWallet> getPaymentWalletWithStatus(String acid, String status);
	
	@Query(value = "{ 'acid' : ?0, 'tokens.status' : ?1, 'tokens.token_id' : ?2}")
	List<PaymentWallet> getPaymentWalletForTokenID(String acid, String status, String tokenId);

	@Query(value = "{ 'acid' : ?0,  'tokens.token_id' : ?1}")
	PaymentWallet getPaymentWalletWithTokenID(String acid, String tokenId);
	
}
