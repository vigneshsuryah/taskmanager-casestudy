package com.anthem.amp.payment.util;


import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.anthem.amp.payment.request.GetTokenRequest;
import com.anthem.amp.payment.response.GetTokenResponse;
import com.google.gson.Gson;
import com.jpmc.cms.sdk.configurator.ConfiguratorException;
import com.jpmc.cms.sdk.framework.Dispatcher;
import com.jpmc.cms.sdk.framework.SLM.NewTransaction;
import com.jpmc.cms.sdk.framework.SLMResp;
import com.jpmc.cms.sdk.framework.SLMResp.Online.TokenIDResponse;
import com.jpmc.cms.sdk.framework.exceptions.RequestException;
import com.jpmc.cms.sdk.framework.interfaces.DispatcherIF;
import com.jpmc.cms.sdk.framework.interfaces.RequestIF;
import com.jpmc.cms.sdk.framework.interfaces.ResponseIF;

@Component
public class ChaseServiceUtil {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(ChaseServiceUtil.class);
	
	@Value("${amplifier.chase.sdk.config.username}")
	private String config_userName;

	@Value("${amplifier.chase.sdk.config.userpwd}")
	private String config_userPassword;

	@Value("${amplifier.chase.sdk.config.proxyusername}")
	private String config_proxyUserName;

	@Value("${amplifier.chase.sdk.config.proxyuserpwd}")
	private String config_ProxyUserPassword;

	@Value("${amplifier.chase.sdk.config.MSDK.currencyCode}")
	private String currencyCode;

    @Value("${amplifier.chase.sdk.config.MSDK.transactionType}")
    private String transactionType;

    @Value("${amplifier.chase.sdk.config.MSDK.actionCode}")
    private String actionCode;

    @Value("${amplifier.chase.sdk.config.MSDK.subscriberID}")
    private String subscriberID;

    @Value("${amplifier.chase.sdk.config.MSDK.cardSecurityPresence}")
    private String cardSecurityPresence;

    @Value("${amplifier.chase.sdk.config.MSDK.divisionNumber}")
    private String divisionNumber;

    @Value("${amplifier.chase.sdk.config.MSDK.formatID}")
    private String formatID;

    @Value("${amplifier.chase.sdk.config.MSDK.encryptionFlag}")
    private String encryptionFlag;
    
    @Value("${amplifier.chase.sdk.config.MSDK.merchantOrderNumber}")
    private String merchantOrderNumber;
    
    @Autowired
    AmplifierUtils amplifierUtils;
    
	
	public GetTokenResponse getTokenInformation(GetTokenRequest getTokenRequest, String action) {

		DispatcherIF dispatcher = null;
		Gson gson = new Gson();
		LOGGER.info("Request details " + gson.toJson(getTokenRequest));
		GetTokenResponse response = new GetTokenResponse();
		response.setEncryptedToken("");
		try {
			dispatcher = new Dispatcher();
			RequestIF request = dispatcher.createRequest("NewTransaction", "HTTPSConnectSLM");
			request = buildIncomingRequest(request, getTokenRequest, action);

			LOGGER.info("Request data from SDK " + request.dumpFieldValues());

			ResponseIF resp = dispatcher.processRequest(request);
			//System.out.println(resp.getFieldArray(TokenIDResponse.TokenID));
			// Check for any conversion error
			if (resp.isConversionError()) {
				LOGGER.error("There is data that the SDK didn't expect. These must have been added after"
						+ resp.getLeftoverData());
			}

			int respCode = resp.getIntField(SLMResp.Online.Response.ResponseReasonCode);
			LOGGER.info("Reponse dumpFieldValues : " + resp.dumpFieldValues());
			LOGGER.info("Reponse dumpFieldIdentifiers : " + resp.dumpFieldIdentifiers());
			LOGGER.info("Reponse dumpMaskedFieldValues : " + resp.dumpMaskedFieldValues());
			
			String acceptCodesStringList = amplifierUtils.getMessageBundleValue("chase.accept.codes.list");
			List<String> acceptCodesList = Arrays.asList(acceptCodesStringList.split(","));

			//if (respCode >= 100 && respCode<=199) {
			if(acceptCodesList.contains(Integer.toString(respCode))) {
				//Chase certification changes
				response.setMessageType(resp.getField(SLMResp.Online.MessageType.MessageType));
				response.setRecordType(resp.getField(SLMResp.Online.MessageType.RecordType));
				response.setOriginalTransactionAmount(resp.getField(SLMResp.Online.MessageType.OriginalTransactionAmount));
				response.setResponseTransactionID(resp.getField(SLMResp.Online.MessageType.ResponseTransactionID));
				response.setStoredCredentialFlag(resp.getField(SLMResp.Online.MessageType.StoredCredentialFlag));
				response.setSubmittedTransactionID(resp.getField(SLMResp.Online.MessageType.SubmittedTransactionID));

				if("PC".equalsIgnoreCase(action)){
					response.setAccountNumber(resp.getField(SLMResp.Online.Response.AccountNumber));
					response.setExpirationDate(resp.getField(SLMResp.Online.Response.ExpirationDate));
					response.setActionCode("AR");
					response.setAvsaav(resp.getField(SLMResp.Online.Response.AVSAAV));
					response.setCardSecurityValue(resp.getField(SLMResp.Online.Response.CardSecurityValue));
					response.setCavv(resp.getField(SLMResp.Online.Response.CAVV));
					response.setReasonCode(Integer.toString(respCode));
					response.setAuthorizationCode(resp.getField(SLMResp.Online.Response.AuthVerificationCode));
					response.setResponseDate(resp.getField(SLMResp.Online.Response.ResponseDate));
					response.setMOP(resp.getField(SLMResp.Online.Response.MOP));
					response.setRecurringPaymentAdviceCode(resp.getField(SLMResp.Online.Response.RecurringPaymentAdviceCode));
				}

				if("PD".equalsIgnoreCase(action) || "PW".equalsIgnoreCase(action)){
					response.setEncryptedToken(resp.getField(TokenIDResponse.TokenID));
					//PP-15623 changes
					response.setAuthorizationCode(resp.getField(SLMResp.Online.Response.AuthVerificationCode));
					response.setReasonCode(Integer.toString(respCode));
					if("PD".equalsIgnoreCase(action)){
						response.setActionCode("AU"); 
					}else {
						response.setActionCode("VF"); 
					}
					
					response.setTokenPaidDate(resp.getField(SLMResp.Online.Response.ResponseDate));
					if("PD".equalsIgnoreCase(action)){
						response.setLevelTInd(resp.getField(SLMResp.Online.CardTypeIndicatorResponse2.Level3Eligible));
					}
				}
				
			}
			if("PC".equalsIgnoreCase(action) && 100 != respCode){
				setChaseExceptionDetails(response, String.valueOf(respCode));
				LOGGER.info("\n************************Failed to process AuthReversal request****************************");
			}else if((response.getEncryptedToken() == null || response.getEncryptedToken().isEmpty()) && !"PC".equals(action))	{
				setChaseExceptionDetails(response, String.valueOf(respCode));
				LOGGER.info("\n************************Failed to process the request****************************");
			}

			LOGGER.info("Response code =>" + resp.getField(SLMResp.Online.Response.ResponseReasonCode));
			LOGGER.info("Auth verification code =>" + resp.getField(SLMResp.Online.Response.AuthVerificationCode));
			
		} catch (Exception e) {
			/*e.printStackTrace();*/
			setChaseExceptionDetails(response, "");
			LOGGER.error("Exception -- while creating Dispatcher request" + e.toString());
		}

		return response;
	}

	private void setChaseExceptionDetails(GetTokenResponse response, String respCode) {
		String messageString = amplifierUtils.getMessageBundleValue("chase.error.code." + respCode);
		if (null == messageString || messageString.isEmpty()) {
			LOGGER.debug("\n*********** error code mapping not available for response code " + respCode);
			messageString = amplifierUtils.getMessageBundleValue("chase.error.code.");
		}
		String[] messageStringArray = messageString.split("\\|");
		com.anthem.amp.payment.vo.Exception exceptionDetails = new com.anthem.amp.payment.vo.Exception();
		exceptionDetails.setCode(messageStringArray[0]);
		exceptionDetails.setMessage(messageStringArray[1]);
		response.setExceptionDetails(exceptionDetails);
	}

	private RequestIF buildIncomingRequest(RequestIF request, GetTokenRequest getTokenRequest, String action)
			throws RequestException, ConfiguratorException {

		request.getConfig().setField("UserName", config_userName);
		request.getConfig().setField("UserPassword", config_userPassword);
		request.getConfig().setField("ProxyUserName", config_proxyUserName);
		request.getConfig().setField("ProxyUserPassword", config_ProxyUserPassword);

		request.setField(NewTransaction.CurrencyCode, currencyCode);
		request.setField(NewTransaction.TransactionType, transactionType);
		request.setField(NewTransaction.Fraud.CardSecurityPresence, cardSecurityPresence);

		request.setField(NewTransaction.DivisionNumber, divisionNumber);
		request.setField(NewTransaction.MethodOfPayment, getTokenRequest.getMethodOfPayment());
		request.setField(NewTransaction.AccountNumber, getTokenRequest.getAccountNumber());
		request.setField(NewTransaction.ExpirationDate, getTokenRequest.getExpirationDate());
		request.setField(NewTransaction.MerchantOrderNumber, getTokenRequest.getMerchantOrderNumber());

		request.setField(NewTransaction.SafetechPageEncryption.SubscriberID, subscriberID);
		request.setField(NewTransaction.SafetechPageEncryption.FormatID, formatID);

		//add Message Type request Params
		request.setField(NewTransaction.MessageType.MessageType, getTokenRequest.getMessageType());
		request.setField(NewTransaction.MessageType.SubmittedTransactionID, getTokenRequest.getSubmittedTransactionID());
		request.setField(NewTransaction.MessageType.StoredCredentialFlag, getTokenRequest.getStoredCredentialFlag());

		/*Payment Details & Payment Wallet*/
		if("PD".equalsIgnoreCase(action) || "PW".equalsIgnoreCase(action)) {

			if("PD".equalsIgnoreCase(action)){
				request.setField(NewTransaction.ActionCode, "AU");
				request.setField(NewTransaction.PaymentIndicator,"Y");
				request.setField(NewTransaction.Amount, getTokenRequest.getAmount());
				//L3 card type indicator
				request.setField(NewTransaction.CardTypeIndicator.FormatVersion,"02");
			}else{
				request.setField(NewTransaction.ActionCode, "VF");
				request.setField(NewTransaction.Amount, "0");
			}

			if("204".equalsIgnoreCase(getTokenRequest.getEncryptionFlag())){
				request.setField(NewTransaction.EncryptionFlag, getTokenRequest.getEncryptionFlag());
			}else{
				request.setField(NewTransaction.EncryptionFlag, "201");
				request.setField(NewTransaction.SafetechPageEncryption.IntegrityCheck, getTokenRequest.getIntegrityCheck());
				request.setField(NewTransaction.SafetechPageEncryption.KeyID, getTokenRequest.getKeyID());
				request.setField(NewTransaction.SafetechPageEncryption.PhaseID, getTokenRequest.getPhaseID());
			}

			request.setField(NewTransaction.PostalCodeOnlyAddress.PostalCode, getTokenRequest.getPostalCode());



		}/*Payment Cancel*/
		else if("PC".equalsIgnoreCase(action)) {
			request.setField(NewTransaction.Amount, getTokenRequest.getAmount());
			request.setField(NewTransaction.ActionCode, "AR");
			request.setField(NewTransaction.EncryptionFlag, "204");
			request.setField(NewTransaction.PriorAuthorization.ResponseDate, getTokenRequest.getTokenizedDate());
			request.setField(NewTransaction.PriorAuthorization.AuthorizationCode, getTokenRequest.getResponseCode());
		}

		return request;
	}

}
