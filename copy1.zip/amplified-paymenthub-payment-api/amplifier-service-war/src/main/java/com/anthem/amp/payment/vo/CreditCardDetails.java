package com.anthem.amp.payment.vo;


import com.anthem.amp.payment.response.GetTokenResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCardDetails {

	@ApiModelProperty(required = true)
	private String creditCardNumber;
	
	@ApiModelProperty(required = true)
	private String creditCardType;

	@ApiModelProperty(required = true)
	private String expirationMonth;

	@ApiModelProperty(required = true)
	private String expirationYear;

	@ApiModelProperty(required = true)
	private String integrityCheck;

	@ApiModelProperty(required = true)
	private String keyID;

	@ApiModelProperty(required = true)
	private String phaseID;
	
	private GetTokenResponse getTokenResponse;

	public GetTokenResponse getGetTokenResponse() {
		return getTokenResponse;
	}

	@JsonIgnore
	public void setGetTokenResponse(GetTokenResponse getTokenResponse) {
		this.getTokenResponse = getTokenResponse;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public String getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}

	public String getIntegrityCheck() {
		return integrityCheck;
	}

	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}

	public String getKeyID() {
		return keyID;
	}

	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	public String getPhaseID() {
		return phaseID;
	}

	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}

}
