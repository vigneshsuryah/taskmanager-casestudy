package com.anthem.amp.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class BankAccount {

	@Field("bank_routing_number")
	private String bankRoutingNumber;

	@Field("bank_account_number")
	private String bankAccountNumber;

	@Field("bank_account_type")
	private String bankAccountType;

	@Field("institution_name")
	private String institutionName;

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

}
