package com.anthem.amp.payment.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Service {

	@Field("amount")
	private String amount;
	@Field("sku")
	private String sku;
	@Field("order_items_service_Id")
	private String order_items_service_Id;
	@Field("qty")
	private String qty;

	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getOrder_items_service_Id() {
		return order_items_service_Id;
	}

	public void setOrder_items_service_Id(String order_items_service_Id) {
		this.order_items_service_Id = order_items_service_Id;
	}
}
