package com.anthem.amp.payment.vo;

import com.anthem.amp.payment.response.GetTokenResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Service {

	@ApiModelProperty(required = true)
	private String amount;

	@ApiModelProperty(required = true)
	private String sku;

	private String order_items_service_Id;

	private String qty;

	private GetTokenResponse getTokenResponse;

	public GetTokenResponse getGetTokenResponse() {
		return getTokenResponse;
	}

	@JsonIgnore
	public void setGetTokenResponse(GetTokenResponse getTokenResponse) {
		this.getTokenResponse = getTokenResponse;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getOrder_items_service_Id() {
		return order_items_service_Id;
	}

	public void setOrder_items_service_Id(String order_items_service_Id) {
		this.order_items_service_Id = order_items_service_Id;
	}

	public String getQty() {
		return qty;
	}

	public void setQty(String qty) {
		this.qty = qty;
	}
}
