package com.anthem.amp.payment.response;

import java.util.List;

import com.anthem.amp.payment.vo.PaymentMethod;

public class GetPaymentMethodResponse extends BaseResponse {

	private List<PaymentMethod> paymentMethods;

	public List<PaymentMethod> getPaymentMethods() {
		return paymentMethods;
	}

	public void setPaymentMethods(List<PaymentMethod> paymentMethods) {
		this.paymentMethods = paymentMethods;
	}

}
