package com.anthem.amp.payment.response;

import java.util.List;

import com.anthem.amp.payment.vo.PaymentHistory;

public class PaymentHistoryResponse extends BaseResponse {

	private List<PaymentHistory> paymentHistory;

	public List<PaymentHistory> getPaymentHistory() {
		return paymentHistory;
	}

	public void setPaymentHistory(List<PaymentHistory> paymentHistory) {
		this.paymentHistory = paymentHistory;
	}

}
