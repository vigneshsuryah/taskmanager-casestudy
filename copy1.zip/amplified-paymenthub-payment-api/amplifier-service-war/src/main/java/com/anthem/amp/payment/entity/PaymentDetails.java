package com.anthem.amp.payment.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Document(collection="payment_details")
public class PaymentDetails {

	@Id
	public ObjectId _id;

	@Field("anthem_orderid")
	private String anthemOrderId;
	@Field("email")
	private String email;
	@Field("acid")
	private String acid;
	@Field("payments")
	private Payment payments;
	@Field("services")
	private List<Service> service;
	
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getAnthemOrderId() {
		return anthemOrderId;
	}
	public void setAnthemOrderId(String anthemOrderId) {
		this.anthemOrderId = anthemOrderId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAcid() {
		return acid;
	}
	public void setAcid(String acid) {
		this.acid = acid;
	}
	public Payment getPayments() {
		return payments;
	}
	public void setPayments(Payment payments) {
		this.payments = payments;
	}
	public List<Service> getService() {
		return service;
	}
	public void setService(List<Service> service) {
		this.service = service;
	}
}
