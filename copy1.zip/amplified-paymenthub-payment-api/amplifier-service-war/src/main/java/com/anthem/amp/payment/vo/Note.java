package com.anthem.amp.payment.vo;

public class Note {

	private String noteDesc;

	public String getNoteDesc() {
		return noteDesc;
	}

	public void setNoteDesc(String noteDesc) {
		this.noteDesc = noteDesc;
	}
}
