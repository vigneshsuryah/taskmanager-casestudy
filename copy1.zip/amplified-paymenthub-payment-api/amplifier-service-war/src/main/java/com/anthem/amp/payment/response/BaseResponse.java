package com.anthem.amp.payment.response;

public class BaseResponse {

}
