package com.anthem.amp.payment.util;

import com.anthem.amp.payment.request.*;
import com.anthem.amp.payment.response.AmplifiedExceptionResponse;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.vo.*;
import com.anthem.amp.payment.vo.Exception;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

@Component
public class ValidationUtils implements AmplifiedPaymentConstants{

    @Autowired
    private AmplifierUtils amplifierUtils;


    public AmplifiedExceptionResponse validateCancelPaymentRequest(CancelPaymentRequest request){
        AmplifiedExceptionResponse amplifiedExceptionResponse = new AmplifiedExceptionResponse();
        List<Exception> exceptions= new LinkedList<>();
        if(isEmptyAndPattern(request.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000, AMP_ERR_MSG_PP_1000));
        }
        if(isEmptyAndPattern(request.getOrderId(),"^[a-zA-Z0-9]{19}$") || !request.getOrderId().startsWith("ampk")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1001, AMP_ERR_MSG_PP_1001));
        }
      
        amplifiedExceptionResponse.setExceptions(exceptions);
        amplifiedExceptionResponse.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));

        return amplifiedExceptionResponse;
    }

//    public AmplifiedExceptionResponse validateCancelPaymentResponse(CancelPaymentResponse response) {
//        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
//        LinkedList<Exception> exceptions = new LinkedList<>();
//        if("DNF".equalsIgnoreCase(response.getStatus())){
//            exceptions.add(new Exception(AMP_ERR_CODE_PP_1002,AMP_ERR_MSG_PP_1002));
//        }
//        amplifiedException.setExceptions(exceptions);
//        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
//        return amplifiedException;
//    }

    public AmplifiedExceptionResponse validateDeletePaymentRequest(DeletePaymentMethodRequest deletePaymentMethodRequest) {
        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
        LinkedList<Exception> exceptions = new LinkedList<>();

        if(isEmptyAndPattern(deletePaymentMethodRequest.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000, AMP_ERR_MSG_PP_1000));
        }
        if(isEmptyAndPattern(deletePaymentMethodRequest.getPaymentMethodID(),"^[a-zA-Z0-9]{12}$")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1003,AMP_ERR_MSG_PP_1003));
        } 
        amplifiedException.setExceptions(exceptions);
        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
        return amplifiedException;
    }

    public AmplifiedExceptionResponse validatePaymentHistoryRequest(PaymentHistoryRequest paymentHistoryRequest) {
        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
        LinkedList<Exception> exceptions = new LinkedList<>();
        if(isEmptyAndPattern(paymentHistoryRequest.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000, AMP_ERR_MSG_PP_1000));
        }
        amplifiedException.setExceptions(exceptions);
        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
        return amplifiedException;
    }

    public AmplifiedExceptionResponse validateGetPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) {
        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
        LinkedList<Exception> exceptions = new LinkedList<>();

        if(!isEmpty(getPaymentMethodRequest.getPaymentMethodID())){
            if((isEmptyAndPattern(getPaymentMethodRequest.getPaymentMethodID(),"^[a-zA-Z0-9]{12}$"))){
                exceptions.add(new Exception(AMP_ERR_CODE_PP_1004, AMP_ERR_MSG_PP_1004));
            }
        }

        if(isEmptyAndPattern(getPaymentMethodRequest.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000, AMP_ERR_MSG_PP_1000));
        }
        if(!isEmpty(getPaymentMethodRequest.getStatus())){
            if( isEmptyAndPattern(getPaymentMethodRequest.getStatus().toLowerCase(),"active|inactive")){
                exceptions.add(new Exception(AMP_ERR_CODE_PP_1005, AMP_ERR_MSG_PP_1005));
            }
        }
        amplifiedException.setExceptions(exceptions);
        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
        return amplifiedException;
    }

    public AmplifiedExceptionResponse validateSubmitPaymentRequest(SubmitPaymentRequest submitPaymentRequest) {
        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
        LinkedList<Exception> exceptions = new LinkedList<>();
        if(isEmptyAndPattern(submitPaymentRequest.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000,AMP_ERR_MSG_PP_1000));
        }
        if(null == submitPaymentRequest.getServices()){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1006,AMP_ERR_MSG_PP_1006));
        }

        Payment payment = submitPaymentRequest.getPayments();
        if(null == payment) {
        	 exceptions.add(new Exception(AMP_ERR_CODE_PP_1007,AMP_ERR_MSG_PP_1007));
        }else {
        	if(isEmptyAndPattern(payment.getPaymentAmount(),"^[\\d]*([\\.][\\d]{0,2})$") && checkEmptyPaymentAmounts(submitPaymentRequest.getServices())){
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1012,AMP_ERR_MSG_PP_1012));
        	}
        	if(isEmpty(payment.getPaymentDate())){
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1008,AMP_ERR_MSG_PP_1008));
        	}else{
        		if(isBeforeDate(payment.getPaymentDate())){
        			exceptions.add(new Exception(AMP_ERR_CODE_PP_1009,AMP_ERR_MSG_PP_1009));
        		}
        	}
        	PaymentMethod paymentMethod = payment.getPaymentMethod();
        	if(null == paymentMethod) {
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1010,AMP_ERR_MSG_PP_1010));
        	}else {
        		if(null == paymentMethod.getPaymentMethodId() || paymentMethod.getPaymentMethodId().isEmpty()) {
                    if(null == paymentMethod.getPaymentFutureUse()){
                        exceptions.add(new Exception(AMP_ERR_CODE_PP_1022,AMP_ERR_MSG_PP_1022));
                    }
        			if(null == paymentMethod.getAccountHolderName() || isEmptyAndPattern(paymentMethod.getAccountHolderName(),"^[a-zA-Z\\s]{0,40}$")) {
        				exceptions.add(new Exception(AMP_ERR_CODE_PP_1019,AMP_ERR_MSG_PP_1019));
        			}
        			Exception ex = null;
        			if(null == paymentMethod.getCreditCardDetails() && null == paymentMethod.getBankAccountDetails()) {
        				exceptions.add(new Exception(AMP_ERR_CODE_PP_1011,AMP_ERR_MSG_PP_1011));
        			}else {
        				if(null != paymentMethod.getCreditCardDetails()){
        					if(null == paymentMethod.getPaymentType() || isEmptyAndPattern(paymentMethod.getPaymentType(),"CC")) {
                				exceptions.add(new Exception(AMP_ERR_CODE_PP_1018,AMP_ERR_MSG_PP_1018));
                			}
        					if(isFutureDate(payment.getPaymentDate())){
        						exceptions.add(new Exception(AMP_ERR_CODE_PP_1013,AMP_ERR_MSG_PP_1013));
        					}
        					ex = validateCardDetails(exceptions, paymentMethod);
        				}
        				if(null != paymentMethod.getBankAccountDetails()) {
        					if(null == paymentMethod.getPaymentType() || isEmptyAndPattern(paymentMethod.getPaymentType(),"ACH")) {
                				exceptions.add(new Exception(AMP_ERR_CODE_PP_1018,AMP_ERR_MSG_PP_1018));
                			}
        					ex = validateACHDetails(exceptions, paymentMethod);
        				}
        			}
        			if(null != ex){
        				exceptions.add(ex);
        			}

        			BillingAddress billingAddress = paymentMethod.getBillingAddress();
        			ex = validateBillingDetails(exceptions, billingAddress);
        			if(null != ex){
        				exceptions.add(ex);
        			}
        		}
        	}
        }
        amplifiedException.setExceptions(exceptions);
        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
        return amplifiedException;
    }


    private Exception validateBillingDetails(LinkedList<Exception> exceptions, BillingAddress billingAddress) {
        if(null==billingAddress){
            exceptions.add( new Exception(AMP_ERR_CODE_PP_1014, AMP_ERR_MSG_PP_1014));
        } else if(
                isEmptyAndPattern(billingAddress.getAddressLine1(),"^[a-zA-Z0-9\\s]{0,40}$")    ||
                isEmptyAndPattern(billingAddress.getCity(),"^[a-zA-Z\\s]{0,20}$")            ||
                isEmptyAndPattern(billingAddress.getState(),"^[a-zA-Z]{2}$")           ||
                isEmptyAndPattern(billingAddress.getPostalCode(),"^[0-9]{5}$")
        ){
            return new Exception(AMP_ERR_CODE_PP_1015, AMP_ERR_MSG_PP_1015);
        }
        return null;
    }

    private Exception validateCardDetails(LinkedList<Exception> exceptions, PaymentMethod paymentMethod) {
        CreditCardDetails cardDetails = paymentMethod.getCreditCardDetails();
        if(isEmpty(cardDetails.getCreditCardNumber())    ||
                isEmpty(cardDetails.getCreditCardType()) ||
                isEmpty(cardDetails.getExpirationMonth()+"/"+cardDetails.getExpirationYear())||
                isEmpty(cardDetails.getIntegrityCheck()) ||
                isEmpty(cardDetails.getKeyID())          ||
                isEmpty(cardDetails.getPhaseID())){
            return new Exception(AMP_ERR_CODE_PP_1017,AMP_ERR_MSG_PP_1017);
        } else if(isEmptyAndPattern(cardDetails.getCreditCardNumber(),"^[0-9]{16}$")    ||
                isEmptyAndPattern(cardDetails.getCreditCardType(),"MC|VI|VISA|MASTERCARD") ||
                !validateCCExpirationString(cardDetails.getExpirationMonth()+"/"+cardDetails.getExpirationYear())||
                isEmptyAndPattern(cardDetails.getIntegrityCheck(),"^[a-z0-9]{16}$") ||
                isEmptyAndPattern(cardDetails.getKeyID(),"^[a-z0-9]{8}$")          ||
                isEmptyAndPattern(cardDetails.getPhaseID(),"0|1")
        ){
            return new Exception(AMP_ERR_CODE_PP_1017,AMP_ERR_MSG_PP_1017);
        }else{
         return null;
        }
    }
    
    private Exception validateACHDetails(LinkedList<Exception> exceptions, PaymentMethod paymentMethod) {
        BankAccountDetails accountDetails = paymentMethod.getBankAccountDetails();
        if(isEmpty(accountDetails.getBankAccountNumber())    ||
                isEmpty(accountDetails.getBankAccountType()) ||
                isEmpty(accountDetails.getRoutingNumber())){
            return new Exception(AMP_ERR_CODE_PP_1021,AMP_ERR_MSG_PP_1021);
        } else if(isEmptyAndPattern(accountDetails.getBankAccountNumber(),"^[0-9]{4,17}$")    ||
                isEmptyAndPattern(accountDetails.getBankAccountType(),"PERSONALCHECKING|PERSONALSAVINGS|BUSCHECKING|BUSSAVINGS") ||
                !isRoutingNoValid(accountDetails.getRoutingNumber()))
        {
            return new Exception(AMP_ERR_CODE_PP_1021,AMP_ERR_MSG_PP_1021);
        }else{
         return null;
        }
    }
    
    public boolean isRoutingNoValid(String routingNo)
	{
		final int FIRST_MULTIPLER = 3;
		final int SECOND_MULTIPLER = 7;
		final int THIRD_MULTIPLER = 1;
		if (!StringUtils.isNumeric(routingNo) || routingNo.length() != 9)
		{
			return false;
		}
		char[] routingArray = routingNo.toCharArray();
		int firstNumber = Integer.parseInt(String.valueOf(routingArray[0]));
		int secondNumber = Integer.parseInt(String.valueOf(routingArray[1]));
		int thridNumber = Integer.parseInt(String.valueOf(routingArray[2]));
		int fourthNumber = Integer.parseInt(String.valueOf(routingArray[3]));
		int fifthNumber = Integer.parseInt(String.valueOf(routingArray[4]));
		int sixthNumber = Integer.parseInt(String.valueOf(routingArray[5]));
		int seventhNumber = Integer.parseInt(String.valueOf(routingArray[6]));
		int eighthNumber = Integer.parseInt(String.valueOf(routingArray[7]));
		int checkDigit = Integer.parseInt(String.valueOf(routingArray[8]));
		int productsSumOrg = (firstNumber * FIRST_MULTIPLER) + (fourthNumber * FIRST_MULTIPLER) + (seventhNumber * FIRST_MULTIPLER)
				+ (secondNumber * SECOND_MULTIPLER) + (fifthNumber * SECOND_MULTIPLER) + (eighthNumber * SECOND_MULTIPLER)
				+ (thridNumber * THIRD_MULTIPLER) + (sixthNumber * THIRD_MULTIPLER);
		int productsSumArr = productsSumOrg;
		if (productsSumOrg % 10 > 0)
		{
			productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
		}
		if (productsSumArr - productsSumOrg == checkDigit)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

    private boolean checkEmptyPaymentAmounts(List<Service> services) {
        Double totalAmount = 0.0;
        if(null != services) {
        	for(Service service:services){
        		if(null!=service.getAmount() && !isEmpty(service.getAmount())){
        			totalAmount+=Double.parseDouble(service.getAmount());
        		}
        	}
        }
        if(totalAmount==0.0){
            return true;
        } else return false;
    }

    public boolean isEmptyAndPattern(String value, String regex){
        boolean isValidationError = false;
        isValidationError =  isEmpty(value);
        boolean isPatternValidationError = false;
        if(null!=value){
            isPatternValidationError = !Pattern.matches(regex,value);
        }

        return isValidationError || isPatternValidationError;
    }
    public boolean isEmpty(String value){
      return StringUtils.isBlank(value) || StringUtils.isEmpty(value);
    }

    public boolean isBeforeDate(String paymentDate){
        LocalDate date = null;
        LocalDate today = LocalDate.now(Clock.systemUTC());
        try{
            date = LocalDate.parse(paymentDate);

        }catch (java.lang.Exception e){
            return true;
        }
        return (date.isBefore(today));
    }

    public boolean isFutureDate(String paymentDate){
        LocalDate date = null;
        LocalDate today = LocalDate.now(Clock.systemUTC());
        try{
            date = LocalDate.parse(paymentDate);

        }catch (java.lang.Exception e){
            return true;
        }
        return (date.isAfter(today));
    }

    public AmplifiedExceptionResponse validateUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action) {
        AmplifiedExceptionResponse amplifiedException = new AmplifiedExceptionResponse();
        LinkedList<Exception> exceptions = new LinkedList<>();

        if(isEmptyAndPattern(updatePaymentMethodRequest.getAcid(),"^[a-zA-Z0-9]*")){
            exceptions.add(new Exception(AMP_ERR_CODE_PP_1000,AMP_ERR_MSG_PP_1000));
        }
        PaymentMethod paymentMethod = updatePaymentMethodRequest.getPaymentMethod();
        if( null == paymentMethod) {
        	  exceptions.add(new Exception(AMP_ERR_CODE_PP_1010,AMP_ERR_MSG_PP_1010));
        }else {
        	
        	if(null == paymentMethod.getAccountHolderName() || isEmptyAndPattern(paymentMethod.getAccountHolderName(),"^[a-zA-Z\\s]{0,40}$")) {
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1019,AMP_ERR_MSG_PP_1019));
        	}
        	Exception ex = null;
        	if(null == paymentMethod.getCreditCardDetails() && null == paymentMethod.getBankAccountDetails()) {
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1011,AMP_ERR_MSG_PP_1011));
        	}else {
        		if(null != paymentMethod.getCreditCardDetails()){
        			if(null == paymentMethod.getPaymentType() || isEmptyAndPattern(paymentMethod.getPaymentType(),"CC")) {
                		exceptions.add(new Exception(AMP_ERR_CODE_PP_1018,AMP_ERR_MSG_PP_1018));
                	}
        			ex = validateCardDetails(exceptions, paymentMethod);
        		}
        		if(null != paymentMethod.getBankAccountDetails()) {
        			if(null == paymentMethod.getPaymentType() || isEmptyAndPattern(paymentMethod.getPaymentType(),"ACH")) {
                		exceptions.add(new Exception(AMP_ERR_CODE_PP_1018,AMP_ERR_MSG_PP_1018));
                	}
        			ex = validateACHDetails(exceptions, paymentMethod);
        		}
        	}
        	if(null != ex){
        		exceptions.add(ex);
        	}
        	if("UPD".equalsIgnoreCase(action) && (null == paymentMethod.getPaymentMethodId() || isEmptyAndPattern(paymentMethod.getPaymentMethodId(),"^[a-zA-Z0-9]{12}$"))) {
        		exceptions.add(new Exception(AMP_ERR_CODE_PP_1020,AMP_ERR_MSG_PP_1020));
        	}
        	
        	BillingAddress billingAddress = paymentMethod.getBillingAddress();
        	Exception exception = validateBillingDetails(exceptions, billingAddress);
        	if(null != exception){
        		exceptions.add(exception);
        	}
        }
        amplifiedException.setExceptions(exceptions);
        amplifiedException.setTransactionTimestamp(amplifierUtils.dateToStr(new Date()));
        return amplifiedException;
    }
    
    public boolean validateCCExpirationString(String expString) {
		boolean flag = true;
		DateFormat dateFormatYear = new SimpleDateFormat("yyyy");
		DateFormat dateFormatMonth = new SimpleDateFormat("MM");
		String currentYearString = dateFormatYear.format(Calendar.getInstance().getTime());
		int currentYear = Integer.parseInt(currentYearString);
		String currentMonthString = dateFormatMonth.format(Calendar.getInstance().getTime());
		int currentMonth = Integer.parseInt(currentMonthString);
		if (expString != null && !expString.isEmpty())
		{
			String[] expArr = {};
			expArr = expString.split("/");
			if(expArr.length == 2 && expArr[0].length() == 2 && expArr[1].length() == 4) {
				int month = 0;
				int year = 0;
				try {
					month = Integer.parseInt(expArr[0]);
					year = Integer.parseInt(expArr[1]);
				}catch(java.lang.Exception e) {
					 flag = false;
				}
				if(year > currentYear) {
                    if(month < 1 || month > 12) {
                           flag = false;
                    }else {
                           flag = true;
                    }
		         }else if(year == currentYear) {
	                if(month < currentMonth || month > 12) {
	                       flag = false;
	                }else {
	                       flag = true;
	                }
		         }else {
		            flag = false;
		         }
			}else {
				flag = false;
			}
		}else {
			flag = false;
		}
		return flag;
	}
}
