package com.anthem.amp.payment.request;

public class PaymentHistoryRequest extends BaseRequest {

//	private String email;
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}

}
