package com.anthem.amp.payment.exception.handler;

import java.io.Serializable;

public class AmplifiedException extends Exception implements Serializable {	
	
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String acid;
	private String errorMessage;
	private Throwable exception;

	public AmplifiedException(String errorCode, String errorMessage)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public AmplifiedException(String errorCode, String errorMessage, String acid) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.acid = acid;
	}
	
	public AmplifiedException(String acid, Throwable throwable) {
		super();
		this.acid = acid;
		this.exception = throwable;
	}
	public AmplifiedException(String errorCode, String errorMessage, String acid, Throwable throwable) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.acid = acid;
		this.exception = throwable;
	}

	public AmplifiedException() {

	}

	public AmplifiedException(String message) {
		this.errorMessage = message;
	}

	public AmplifiedException(Throwable exception, String message) {
		this.errorMessage = message;
		this.exception =exception;
	}
	
	public AmplifiedException(String errorCode, String errorMessage, Throwable exception) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.exception = exception;
	}


	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Throwable getException() {
		return exception;
	}

	public void setException(Throwable exception) {
		this.exception = exception;
	}

	public String getAcid() {
		return acid;
	}

	public void setAcid(String acid) {
		this.acid = acid;
	}
}