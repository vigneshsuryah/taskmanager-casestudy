package com.anthem.amp.payment.response;


import com.fasterxml.jackson.annotation.JsonInclude;

public class SubmitPaymentResponse extends BaseResponse {

	private String orderId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String paymentMethodId;
	private String transactionTimestamp;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTransactionTimestamp() {
		return transactionTimestamp;
	}

	public void setTransactionTimestamp(String transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}

	public String getPaymentMethodId() {
		return paymentMethodId;
	}

	public void setPaymentMethodId(String paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}

	//	private List<PaymentSubmission> payments;
//
//	public List<PaymentSubmission> getPayments() {
//		return payments;
//	}
//
//	public void setPayments(List<PaymentSubmission> payments) {
//		this.payments = payments;
//	}

}
