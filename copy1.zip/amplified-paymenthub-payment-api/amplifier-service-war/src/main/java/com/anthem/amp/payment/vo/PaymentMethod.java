package com.anthem.amp.payment.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethod {

	private String accNickName;
	
	@ApiModelProperty(required = true)
	private String accountHolderName;

	@ApiModelProperty(required = true)
	private Boolean paymentFutureUse;

	
	private String paymentMethodId;

	private String paymentType;

	private BankAccountDetails bankAccountDetails;

	
	@ApiModelProperty(required = true)
	private BillingAddress billingAddress;

	private CreditCardDetails creditCardDetails;

	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccNickName() {
		return accNickName;
	}

	public void setAccNickName(String accNickName) {
		this.accNickName = accNickName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public Boolean getPaymentFutureUse() {
		return paymentFutureUse;
	}

	public void setPaymentFutureUse(Boolean paymentFutureUse) {
		this.paymentFutureUse = paymentFutureUse;
	}

	public String getPaymentMethodId() {
		return paymentMethodId;
	}

	public void setPaymentMethodId(String paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public BankAccountDetails getBankAccountDetails() {
		return bankAccountDetails;
	}

	public void setBankAccountDetails(BankAccountDetails bankAccountDetails) {
		this.bankAccountDetails = bankAccountDetails;
	}

	public BillingAddress getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public CreditCardDetails getCreditCardDetails() {
		return creditCardDetails;
	}

	public void setCreditCardDetails(CreditCardDetails creditCardDetails) {
		this.creditCardDetails = creditCardDetails;
	}

}
