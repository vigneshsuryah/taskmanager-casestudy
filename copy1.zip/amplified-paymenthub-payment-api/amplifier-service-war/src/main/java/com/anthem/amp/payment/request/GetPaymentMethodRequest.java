package com.anthem.amp.payment.request;

public class GetPaymentMethodRequest extends BaseRequest {

	private String paymentMethodID;

	private String status;

	public String getPaymentMethodID() {
		return paymentMethodID;
	}

	public void setPaymentMethodID(String paymentMethodID) {
		this.paymentMethodID = paymentMethodID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
