package com.anthem.amp.payment.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

public class Payment {

	@Field("notes")
	private List<Note> notes;
	@Field("paymentAmount")
	private String paymentAmount;
	@Field("paymentDate")
	private String paymentDate;
	@Field("paymentMethod")
	private PaymentMethod paymentMethod;
	@Field("created_dt")
	private Date createdDt;
	@Field("updated_dt")
	private Date updatedDt;
	@Field("cancel_details")
	private CancelDetails cancelDetails;
	@Field("transaction_status")
	private String transactionStatus;
	@Field("transaction_type")
	private String transactionType;
	@Field("system")
	private String system;
	@Field("legal_entity")
	private String legalEntity;
	@Field("market_segment")
	private String marketSegment;
	@Field("division_code")
	private String divisionCode;
	@Field("transaction_division_code")
	private String transactionDivisionCode;
	
	public List<Note> getNotes() {
		return notes;
	}
	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public Date getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
	public CancelDetails getCancelDetails() {
		return cancelDetails;
	}
	public void setCancelDetails(CancelDetails cancelDetails) {
		this.cancelDetails = cancelDetails;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	public String getTransactionDivisionCode() {
		return transactionDivisionCode;
	}
	public void setTransactionDivisionCode(String transactionDivisionCode) {
		this.transactionDivisionCode = transactionDivisionCode;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}
}
