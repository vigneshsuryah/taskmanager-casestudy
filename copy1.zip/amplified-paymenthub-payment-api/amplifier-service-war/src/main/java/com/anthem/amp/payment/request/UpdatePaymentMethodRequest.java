package com.anthem.amp.payment.request;

import com.anthem.amp.payment.vo.PaymentMethod;

public class UpdatePaymentMethodRequest extends BaseRequest {

	private String email;

	private PaymentMethod paymentMethod;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

}
