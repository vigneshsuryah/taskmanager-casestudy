package com.anthem.amp.payment.request;

import java.util.List;

import com.anthem.amp.payment.vo.Payment;
import com.anthem.amp.payment.vo.Service;

public class SubmitPaymentRequest extends BaseRequest {

	private String email;
	
	private List<Service> services;
	
	private Payment payments;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	public Payment getPayments() {
		return payments;
	}

	public void setPayments(Payment payments) {
		this.payments = payments;
	}
}
