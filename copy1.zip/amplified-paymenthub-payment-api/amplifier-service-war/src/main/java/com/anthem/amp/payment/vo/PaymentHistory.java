package com.anthem.amp.payment.vo;

import java.util.List;

public class PaymentHistory {

	private String orderId;

	private String acid;

	private Payment payments;

	private List<Service> services;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Payment getPayments() {
		return payments;
	}

	public void setPayments(Payment payments) {
		this.payments = payments;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	public String getAcid() {
		return acid;
	}

	public void setAcid(String acid) {
		this.acid = acid;
	}
}
