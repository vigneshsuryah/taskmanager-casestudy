package com.anthem.amp.payment.response;

import java.util.List;

import com.anthem.amp.payment.vo.Exception;

public class AmplifiedExceptionResponse extends BaseResponse {

	private List<Exception> exceptions;

	private String transactionTimestamp;

	public List<Exception> getExceptions() {
		return exceptions;
	}

	public void setExceptions(List<Exception> asList) {
		this.exceptions = asList;
	}

	public String getTransactionTimestamp() {
		return transactionTimestamp;
	}

	public void setTransactionTimestamp(String transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}

}
