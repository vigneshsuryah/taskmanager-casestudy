package com.anthem.amp.payment.controller;

import javax.validation.Valid;

import com.anthem.amp.payment.util.ValidationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.amp.payment.exception.handler.AmplifiedException;
import com.anthem.amp.payment.request.CancelPaymentRequest;
import com.anthem.amp.payment.request.DeletePaymentMethodRequest;
import com.anthem.amp.payment.request.GetPaymentMethodRequest;
import com.anthem.amp.payment.request.PaymentHistoryRequest;
import com.anthem.amp.payment.request.SubmitPaymentRequest;
import com.anthem.amp.payment.request.UpdatePaymentMethodRequest;
import com.anthem.amp.payment.response.AmplifiedExceptionResponse;
import com.anthem.amp.payment.response.BaseResponse;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.response.DeletePaymentMethodResponse;
import com.anthem.amp.payment.response.GetPaymentMethodResponse;
import com.anthem.amp.payment.response.PaymentHistoryResponse;
import com.anthem.amp.payment.response.SubmitPaymentResponse;
import com.anthem.amp.payment.response.UpdatePaymentMethodResponse;
import com.anthem.amp.payment.service.AmplifiedPaymentService;
import com.anthem.amp.payment.util.AmplifiedPaymentConstants;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AmplifiedPaymentController implements AmplifiedPaymentConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(AmplifiedPaymentController.class);

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private AmplifiedPaymentService amplifiedPaymentService;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/payment/cancel", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Cancel Payment", notes = "The api call is used to cancel the payment")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = CancelPaymentResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> cancelPayment(@RequestBody @Valid CancelPaymentRequest cancelPaymentRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside cancel payment - start");
		AmplifiedExceptionResponse amplifiedRequestException = validationUtils.validateCancelPaymentRequest(cancelPaymentRequest);

		if(amplifiedRequestException.getExceptions().size()>0){
			return new ResponseEntity(amplifiedRequestException, HttpStatus.BAD_REQUEST);
		}

		CancelPaymentResponse cancelPaymentResponse = amplifiedPaymentService.cancelPayment(cancelPaymentRequest);

		if(null != cancelPaymentResponse && "DNF".equalsIgnoreCase(cancelPaymentResponse.getStatus())){
			return  new ResponseEntity(HttpStatus.NO_CONTENT);
		}

		LOGGER.info("AmplifiedPaymentController: Inside cancel payment - end");

		return new ResponseEntity(cancelPaymentResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/payment/history", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Payment History", notes = "The api call is used to retrieve the payment history")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = PaymentHistoryResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 204, message = AMP_NO_DATA),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getPaymentHistory(@RequestBody @Valid PaymentHistoryRequest paymentHistoryRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside getPaymentHistory - start");

		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validatePaymentHistoryRequest(paymentHistoryRequest);
		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		PaymentHistoryResponse paymentHistoryResponse = amplifiedPaymentService.getPaymentHistory(paymentHistoryRequest);
		
		LOGGER.info("AmplifiedPaymentController: Inside getPaymentHistory - end");

		return new ResponseEntity(paymentHistoryResponse, HttpStatus.OK);
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/payment/submit", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Submit Payment", notes = "The api call is used to make the payment")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = SubmitPaymentResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> submitPayment(@RequestBody @Valid SubmitPaymentRequest submitPaymentRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside submitPayment - start");

		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validateSubmitPaymentRequest(submitPaymentRequest);
		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		SubmitPaymentResponse submitPaymentResponse = amplifiedPaymentService.submitPayment(submitPaymentRequest);
		
		LOGGER.info("AmplifiedPaymentController: Inside submitPayment - end");

		return new ResponseEntity(submitPaymentResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Methods", notes = "The api call is used to retrieve the payment methods")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = GetPaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 204, message = AMP_NO_DATA),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getPaymentMethods(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside getPaymentMethods - start");

		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validateGetPaymentMethods(getPaymentMethodRequest);
		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		GetPaymentMethodResponse getPaymentMethodResponse = amplifiedPaymentService.getPaymentMethods(getPaymentMethodRequest);
		
		LOGGER.info("AmplifiedPaymentController: Inside getPaymentMethods - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/add", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Add Payment Method", notes = "The api call is used to add payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> addPaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside addPaymentMethod - start");

		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validateUpdatePaymentMethod(updatePaymentMethodRequest,"ADD");
		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		UpdatePaymentMethodResponse updatePaymentMethodResponse = amplifiedPaymentService.addOrUpdatePaymentMethod(updatePaymentMethodRequest,"ADD");
		
		LOGGER.info("AmplifiedPaymentController: Inside addPaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/delete", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Delete Payment Method", notes = "The api call is used to delete payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = DeletePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> deletePaymentMethod(@RequestBody DeletePaymentMethodRequest deletePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside deletePaymentMethod - start");
		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validateDeletePaymentRequest(deletePaymentMethodRequest);

		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		DeletePaymentMethodResponse deletePaymentMethodResponse = amplifiedPaymentService.deletePaymentMethod(deletePaymentMethodRequest);

		LOGGER.info("AmplifiedPaymentController: Inside deletePaymentMethod - end");

		return new ResponseEntity(deletePaymentMethodResponse, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/paymenthub/v1/wallet/update", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Update Payment Method", notes = "The api call is used to edit payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = AMP_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = AMP_BAD_REQUEST, response = AmplifiedExceptionResponse.class),
			@ApiResponse(code = 201, message = AMP_CREATED),
			@ApiResponse(code = 401, message = AMP_UNAUTH),
			@ApiResponse(code = 403, message = AMP_FORBIDDEN),
			@ApiResponse(code = 404, message = AMP_NOT_FOUND),
			@ApiResponse(code = 500, message = AMP_SERVICE_NOT_AVAILABLE, response = AmplifiedExceptionResponse.class) })
	public ResponseEntity<BaseResponse> updatePaymentMethod(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws AmplifiedException  {
		
		LOGGER.info("AmplifiedPaymentController: Inside updatePaymentMethod - start");

		AmplifiedExceptionResponse amplifiedExceptionResponse = validationUtils.validateUpdatePaymentMethod(updatePaymentMethodRequest,"UPD");
		if(amplifiedExceptionResponse.getExceptions().size()>0){
			return new ResponseEntity(amplifiedExceptionResponse, HttpStatus.BAD_REQUEST);
		}
		UpdatePaymentMethodResponse updatePaymentMethodResponse = amplifiedPaymentService.addOrUpdatePaymentMethod(updatePaymentMethodRequest,"UPD");
		
		LOGGER.info("AmplifiedPaymentController: Inside updatePaymentMethod - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}

}
