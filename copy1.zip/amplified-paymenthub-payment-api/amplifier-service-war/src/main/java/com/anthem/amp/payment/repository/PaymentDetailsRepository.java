package com.anthem.amp.payment.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.amp.payment.entity.PaymentDetails;

@Repository
public interface PaymentDetailsRepository extends MongoRepository<PaymentDetails, String>{
	
	@Query(value = "{ 'anthemOrderId' : ?0}")
	List<PaymentDetails> getPaymentDetailsByOrderId(String anthemOrderId);

	@Query(value = "{ 'anthemOrderId' : ?0, 'acid' : ?1}")
	List<PaymentDetails> getPaymentDetailsByAOID(String anthemOrderId, String acid);

	@Query(value = "{ 'acid' : ?0}")
	List<PaymentDetails> getPaymentDetailsByAcid(String acid);
    
}
