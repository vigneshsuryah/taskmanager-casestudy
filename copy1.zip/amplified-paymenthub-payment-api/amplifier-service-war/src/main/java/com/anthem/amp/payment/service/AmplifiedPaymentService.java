package com.anthem.amp.payment.service;

import com.anthem.amp.payment.exception.handler.AmplifiedException;
import com.anthem.amp.payment.request.CancelPaymentRequest;
import com.anthem.amp.payment.request.DeletePaymentMethodRequest;
import com.anthem.amp.payment.request.GetPaymentMethodRequest;
import com.anthem.amp.payment.request.PaymentHistoryRequest;
import com.anthem.amp.payment.request.SubmitPaymentRequest;
import com.anthem.amp.payment.request.UpdatePaymentMethodRequest;
import com.anthem.amp.payment.response.CancelPaymentResponse;
import com.anthem.amp.payment.response.DeletePaymentMethodResponse;
import com.anthem.amp.payment.response.GetPaymentMethodResponse;
import com.anthem.amp.payment.response.PaymentHistoryResponse;
import com.anthem.amp.payment.response.SubmitPaymentResponse;
import com.anthem.amp.payment.response.UpdatePaymentMethodResponse;

public interface AmplifiedPaymentService {


	SubmitPaymentResponse submitPayment(SubmitPaymentRequest submitPaymentRequest) throws AmplifiedException;

    CancelPaymentResponse cancelPayment(CancelPaymentRequest cancelPaymentRequest) throws AmplifiedException;
    
    UpdatePaymentMethodResponse addOrUpdatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest, String action) throws AmplifiedException;
    
    DeletePaymentMethodResponse deletePaymentMethod(DeletePaymentMethodRequest deletePaymentMethodRequest) throws AmplifiedException;
    
    GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws AmplifiedException;
    
    PaymentHistoryResponse getPaymentHistory(PaymentHistoryRequest paymentHistoryRequest) throws AmplifiedException;

}
