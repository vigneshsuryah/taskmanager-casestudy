package com.anthem.payment.paymod.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;

@Configuration
@EnableMongoRepositories(basePackages = "com.anthem.payment.paymod.repository.wallet", mongoTemplateRef = "mongoWalletTemplate")
public class MongoWalletConfiguration {

	@Autowired
	private MongoWalletProperties mongoWalletProperties;
	
	@Bean(name = "mongoWalletTemplate")
	public MongoTemplate mongoWalletTemplate() throws Exception {
		return new MongoTemplate(payModMongoWalletDbFactory());
	}

	public MongoDbFactory payModMongoWalletDbFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClientURI(mongoWalletProperties.getUri()));
	}
	
	public Builder customMongoBuilder() {
		// Mongo database client options to override the default behavior 
		MongoClientOptions.Builder builder = MongoClientOptions.builder();
		return builder;
	}
}
