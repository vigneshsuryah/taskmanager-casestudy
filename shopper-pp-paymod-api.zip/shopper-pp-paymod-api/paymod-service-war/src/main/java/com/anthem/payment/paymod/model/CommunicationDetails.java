package com.anthem.payment.paymod.model;

public class CommunicationDetails {

	private String emailId;
	private MailingAddress mailingAddress;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public MailingAddress getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(MailingAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

}
