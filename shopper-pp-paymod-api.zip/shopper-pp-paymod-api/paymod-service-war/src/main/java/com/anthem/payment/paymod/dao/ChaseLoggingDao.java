/**
 * MedicareLoggingDao.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.dao;


import com.anthem.payment.paymod.entity.RSTransLog;
import com.anthem.payment.paymod.entity.TPTServicesLog;
import com.anthem.payment.paymod.handler.PaymentModException;


public interface ChaseLoggingDao
{

	public void saveRSServiceLog(RSTransLog rSTransLog) throws PaymentModException;

	public void saveTPTServiceLog(TPTServicesLog logData) throws PaymentModException;

}
