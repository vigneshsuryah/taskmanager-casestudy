package com.anthem.payment.paymod.request;

import io.swagger.annotations.ApiModelProperty;

import org.hibernate.validator.constraints.NotBlank;

public class RefundPaymentRequest extends BaseRequest {
    
	private static final long serialVersionUID = 1L;
    
	private String lob;
	private String csrId;
	private String confirmEmail;
	private String notes;
	
	@NotBlank
    private String orderId;
    
    @NotBlank
    private String refundAmount;
    
    @NotBlank
    private String refundReason;  

    public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	@ApiModelProperty(required=true)
    public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	@ApiModelProperty(required=true)
    public String getRefundAmount() {
    	return refundAmount;
    }
    public void setRefundAmount(String refundAmount) {
    	this.refundAmount = refundAmount;
    }

    public String getRefundReason() {
    	return refundReason;
    }

    public void setRefundReason(String refundReason) {
    	this.refundReason = refundReason;
    }

	public String getCsrId() {
		return csrId;
	}

	public void setCsrId(String csrId) {
		this.csrId = csrId;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getConfirmEmail() {
		return confirmEmail;
	}

	public void setConfirmEmail(String confirmEmail) {
		this.confirmEmail = confirmEmail;
	}
}
