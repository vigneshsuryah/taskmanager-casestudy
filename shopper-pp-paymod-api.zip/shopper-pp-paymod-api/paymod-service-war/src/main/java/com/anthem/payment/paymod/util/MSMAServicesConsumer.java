package com.anthem.payment.paymod.util;

import java.util.Arrays;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.anthem.payment.paymod.config.ApplicationProperties;
import com.anthem.payment.paymod.handler.PaymentModException;
import com.anthem.payment.paymod.request.GetMemberBillingAddrRequest;
import com.anthem.payment.paymod.request.RefundEmailRequest;
import com.anthem.payment.paymod.request.RefundPaymentRequest;
import com.anthem.payment.paymod.response.GetMemberBillingAddrResponse;
import com.google.gson.Gson;

@Component
public class MSMAServicesConsumer implements PaymentModConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(MSMAServicesConsumer.class);
	
	@Value("${msma.setting.refundemailapi.readtimeout}")
	private int readTimeout;

	@Value("${msma.setting.refundemailapi.connectiontimeout}")
	private int connectionTimeout;
	
	@Value("${msma.setting.refundemailapi.endpoint}")
	String refundEmailEndpoint;
	
	@Value("${msma.setting.endpoint}")
	String msmaEndpoint;
	
	@Autowired
	private ApplicationProperties applicationProperties;
	
	public HttpEntity<String> invokeRefundEmail(RefundEmailRequest refundEmailRequest, RefundPaymentRequest refundPaymentRequest) throws PaymentModException
	{
		HttpEntity<String> responseEntity = new HttpEntity<String>("Success");
		try {
			Object sendObj = addMSMAReqHeaderObject(refundEmailRequest);
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(sendObj, getMSMAHttpHeaders(refundPaymentRequest));
			
			LOGGER.info("About to send request for MSMA refund email rest API");
			responseEntity = getRestTemplate().exchange(refundEmailEndpoint, HttpMethod.POST, requestEntity, String.class);
			} catch (Exception e) {
				LOGGER.error("Error in invokeRefundEmail::" + e.getMessage());
		}
	return responseEntity;
	}
	
	public GetMemberBillingAddrResponse getMemberBillingAddress(GetMemberBillingAddrRequest request) throws PaymentModException
	{
		HttpEntity<GetMemberBillingAddrResponse> responseEntity = null;
		GetMemberBillingAddrResponse response = null;
		try {
			Object sendObj = addMSMAReqHeaderObject(request);
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(sendObj, getMSMABillingAddrHttpHeaders());
			
			LOGGER.info("About to send request for MSMA getMemberBillingAddress rest API");
			responseEntity = getRestTemplate().exchange(msmaEndpoint + "medSupp/v1/getMemberBillingAddress", HttpMethod.POST, requestEntity, GetMemberBillingAddrResponse.class);
			if(null != responseEntity) {
				response = responseEntity.getBody();
			}
		} catch (Exception e) {
			LOGGER.error("Error in getMemberBillingAddress::" + e.getMessage());
		}
		return response;
	}
	
	public Object addMSMAReqHeaderObject(Object object) throws JSONException{
		Object sendObject = new Object();
		
		JSONObject requestHeader = new JSONObject();
		requestHeader.put("userName", applicationProperties.getStringProperty("medicarepay.setting.payment.ui.restconsumer.service.username", ""));
		requestHeader.put("password", applicationProperties.getStringProperty("medicarepay.setting.payment.ui.restconsumer.service.password", ""));
		
		String jsonInString = new Gson().toJson(object);
		JSONObject realObject = new JSONObject(jsonInString);
		realObject.put("requestHeader", requestHeader);
		
		sendObject = new Gson().fromJson(realObject.toString(), Object.class);
	    return sendObject;
	}
	
	private HttpHeaders getMSMAHttpHeaders(RefundPaymentRequest refundPaymentRequest)
	{
		String csrId = "";
		if(null != refundPaymentRequest) {
			csrId = refundPaymentRequest.getCsrId();
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", applicationProperties.getStringProperty("msma.meta.senderapp.value", ""));
		headers.add("csrId", csrId);
		return headers;
	}
	
	private HttpHeaders getMSMABillingAddrHttpHeaders()
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", applicationProperties.getStringProperty("msma.meta.senderapp.value", ""));
		return headers;
	}
	
	/**
	 * Returns the Http header params
	 * @param requestContext
	 * @return
	 */
	private MultiValueMap<String, String> getHttpHeaders() {

		LOGGER.info("About to get HttpHeaders");
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.debug(headers.toString());
		LOGGER.info("Got HttpHeaders");
		return headers;
	
	}

	/**
	 * Returns the rest template object for ACI service call
	 * @return
	 */
	public RestTemplate getRestTemplate()
	{
		LOGGER.info("Above to get RestTemplate");
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		LOGGER.info("Got the RestTemplate");
		return restTemplate;
	}

	/**
	 * Returns clientHttpRequestFactory object
	 * @return
	 */
	private ClientHttpRequestFactory clientHttpRequestFactory()
	{
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setReadTimeout(readTimeout);
		factory.setConnectTimeout(connectionTimeout);
		ClientHttpRequestFactory requestFactory = new BufferingClientHttpRequestFactory(factory);
		return requestFactory;
	}

}
