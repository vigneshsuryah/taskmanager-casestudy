package com.anthem.payment.paymod.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class Returns {

	@Field("return_reason_code")
	private String returnReasonCode;
	@Field("return_reason_description")
	private String returnReasonDescription;
	@Field("nullification_date")
	private Date nullificationDate;

	public String getReturnReasonCode() {
		return returnReasonCode;
	}

	public void setReturnReasonCode(String returnReasonCode) {
		this.returnReasonCode = returnReasonCode;
	}

	public String getReturnReasonDescription() {
		return returnReasonDescription;
	}

	public void setReturnReasonDescription(String returnReasonDescription) {
		this.returnReasonDescription = returnReasonDescription;
	}

	public Date getNullificationDate() {
		return nullificationDate;
	}

	public void setNullificationDate(Date nullificationDate) {
		this.nullificationDate = nullificationDate;
	}

}
