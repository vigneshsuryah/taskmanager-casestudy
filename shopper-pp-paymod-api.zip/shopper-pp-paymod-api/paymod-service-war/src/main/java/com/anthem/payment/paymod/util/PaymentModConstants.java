package com.anthem.payment.paymod.util;

import java.util.HashMap;
import java.util.Map;

public interface PaymentModConstants {

	String HEADER_ACCEPT = "Accept=*/*";
	String APPLICATION_TYPE_JSON = "application/json";
	String APP_PRODUCE_TYPE_1 = "application/json; charset=UTF-8";
	String APP_PRODUCE_TYPE_2 = "text/html;charset=UTF-8";
	String PAYMENT_MOD_ERR_TYPE_ERROR = "ERROR";
	String PAYMENT_MOD_TECH_ERROR_CODE = "9000";
	String PAYMENT_MOD_EMP_ERR_CODE = "Required Field";
	String PAYMENT_MOD_REQUIRED = "Required";
	String PAYMENT_MOD_ERR_9107 = "9107";
	String PAYMENT_MOD_ERR_9108 = "9108";
	String PAYMENT_MOD_ERR_001 = "1001";
	String PAYMENT_MOD_ERR_002 = "1002";
	String PAYMENT_MOD_ERR_004 = "1008";
	String PAYMENT_MOD_ERR_005 = "1005";
	String PAYMENT_MOD_ERR_006 = "1006";
	String PAYMENT_MOD_ERR_9123 = "9123";
	String PAYMENT_MOD_ERR_9111 = "9111";
	String PAYMENT_MOD_ERR_MSG_9111 = "Please enter the full 9-digit bank routing number or, Please enter a valid bank routing number (no letters or special characters and full 9-digits).";
	String PAYMENT_MOD_ERR_9112 = "9112";
	String PAYMENT_MOD_ERR_MSG_9112 = "Please enter a valid bank account number";
	String PAYMENT_MOD_ERR_9116 = "9116";
	String PAYMENT_MOD_ERR_MSG_9116 = "Please enter a valid bank routing number (no letters or special characters).";
	String PAYMENT_MOD_ERR_9125 = "9125";
	String PAYMENT_MOD_ERR_MSG_9125 = "Please enter correct account number";
	String PAYMENT_MOD_ERR_MSG_001 = "Please enter a valid bank account number";
	String PAYMENT_MOD_ERR_MSG_002 = "Please enter correct account number";
	String PAYMENT_MOD_ERR_MSG_003 = "Please enter a valid bank routing number (no letters or special characters and full 9-digits).";
	String PAYMENT_MOD_ERR_MSG_005 = "Internal server error";
	String PAYMENT_MOD_ERR_MSG_006 = "Payment cancellation failed";
	String PAYMENT_MOD_CHASE_ERR_MSG = "Credit Card Validation is failed";
	String PAYMENT_MOD_TECH_ERROR_MSG = "System is unavailable. Please try again later. ";
	String PAYMENT_MOD_SUCCESS_STATUS = "SUCCESS";
	String PAYMENT_MOD_VALIDATION_ERROR = "Validation Error";
	String PAYMENT_MOD_ERR_9001_REQ_MISSING = "9001";
	String PAYMENT_MOD_ERR_9001_REQ_MISSING_DESC = "Request header missing";
	String PAYMENT_MOD_ERR_9001_ILLEGAL_REQ = "9001";
	String PAYMENT_MOD_ERR_9001_ILLEGAL_REQ_DESC = "Illegal Request";
	String PAYMENT_MOD_ERR_9002 = "9002";
	String PAYMENT_MOD_ERR_9002_DESC = "In-Valid User Name";
	String PAYMENT_MOD_ERR_9003 = "9003";
	String PAYMENT_MOD_ERR_9003_DESC = "In-Valid Password";
	String PAYMENT_MOD_ERR_9004 = "9004";
	String PAYMENT_MOD_ERR_9004_DESC = "In-Valid Requesting Application";
	String PAYMENT_MOD_REQ_APPLICATION = "requestApplication";
	String PAYMENT_MOD_USERNAME = "userName";
	String PAYMENT_MOD_AUTH_KEY = "password";
	String PAYMENT_MOD_BAD_REQUEST = "BAD REQUEST";
	String PAYMENT_MOD_SERVICE_NOT_AVAILABLE = "SERVICE NOT AVAILABLE";
	String PAYMENT_MOD_REQ_PROC_ERROR = "Request processing error";
	String PAYMENT_MOD_MISSING_PARAMETERS = "One or more of the request parameters are missing/wrong. Please correct the request.";
 

	String PAYMENT_STATUS_SUBMITTED = "Payment Submitted";
	String PAYMENT_STATUS_CANCELLED = "Payment Cancelled";

	Map<String, String> ERROR_MAPPING = new HashMap<String, String>(){
		private static final long serialVersionUID = 1L;
	{
		put("9107","Required Field");
		put("9108","Required Field");
		put("9109","Please enter the full 16-digit credit card number");
		put("9110","Please enter the correct 5-digit ZIP code");
		put("9113","Please enter a valid card expiration date (mmyy) or, The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.");
		put("9176","The Payment Amount is invalid. Please try again");
		put("9115","Please only use letters when entering a name (no numbers or special characters).");
		put("9116","Please enter a valid bank routing number (no letters or special characters).");
		put("9117","Please enter a valid account holder name (no numbers or special characters).");
		put("9118","Please enter the address without any special characters");
		put("9119","Please enter a valid city name (no special characters). Or, Please enter a valid city name (no numbers or special characters).");
		put("9120","Please enter a valid state name (no numbers or special characters).");
		put("9121","Sorry, you already have a payment method with that nickname in the system.");
		put("9122","The automatic payment deletion failed.");
		put("9125","Please enter a valid method of payment");
		 
	}};
	
	Map<String, String> REFUND_CODE_MAPPING = new HashMap<String, String>(){
		private static final long serialVersionUID = 1L;
	{
		put("Q00","Duplicate Payment");
		put("Q02","Overpayment");
		put("Q04","Customer Initiated Error");
		put("Q06","Service Cancellation");
		put("Q07","Miscellaneous");
	}};
	
	String PAYMENT_MOD_ERR_9201_AMOUNT = "9201";
	String PAYMENT_MOD_ERR_9201_AMOUNT_DESC = "The amount Request is invalid for this transaction.";
	String PAYMENT_MOD_ERR_9202_RETURNED = "9202";
	String PAYMENT_MOD_ERR_9202_RETURNED_DESC = "Returned transactions are not eligible for Refunds.";
	String PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS = "9203";
	String PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC = "The information entered is either invalid for this LOB or has no valid transaction(s)";
	String PAYMENT_MOD_ERR_9204_NOT_COMPLETED = "9204";
	String PAYMENT_MOD_ERR_9204_NOT_COMPLETED_DESC = "Sorry, the transaction cannot be refunded if its not complete.";
	String PAYMENT_MOD_ERR_9205_INVALID_DATE = "9205";
	String PAYMENT_MOD_ERR_9205_INVALID_DATE_DESC = "Sorry, an ACH transaction cannot be refunded if it is not more than 7 calendar days from the deposit date.";
	String PAYMENT_MOD_ERR_9206_NO_DATA = "9206";
	String PAYMENT_MOD_ERR_9206_NO_DATA_DESC = "Sorry, there are no transactions available for the entered information.";
	String PAYMENT_MOD_ERR_9207_MONGO_EXP = "9207";
	String PAYMENT_MOD_ERR_9207_MONGO_EXP_DESC = "Mongo exception  during the refund payment";
	
	//PP-16301, PP-16303 - Start
	String PAYMENT_MOD_ERR_FETCH_PAYMENT_METHOD = "Sorry, Unexpected error occured while fetching payment methods.";
	String PAYMENT_MOD_ERR_ADD_PAYMENT_METHOD = "Sorry, Unexpected error occured while adding payment method.";
	String PAYMENT_MOD_ERR_UPDATE_PAYMENT_METHOD = "Sorry, Unexpected error occured while updating payment method.";
	String PAYMENT_MOD_ERR_DELETE_PAYMENT_METHOD = "Sorry, Unexpected error occured while deleting payment method.";
	String PAYMENT_MOD_ERR_GET_TOKEN = "Sorry, Unexpected error occured while fetching encrypted Credit card token.";
	String MISSING_PARAMETERS = "One or more of the request parameters are missing/wrong. Please correct the request.";
	String INACTIVE_STR = "INACTIVE";
	String ACTIVE_STR = "ACTIVE";
	
	String PAYMENT_TYPE_CC = "CC";
	String PAYMENT_TYPE_ACH = "ACH";
	
	String[] ALLOWED_LOB = {"GBDIN","GBDKY","WGS","GOFUNDHIP","GOFUNDKYHP"};
	String[] ALLOWED_PAY_TYPE = {"ACH","CC"};
	String[] ALLOWED_PAY_SUB_TYPE = {"PERSONAL CHECKING","PERSONAL SAVINGS","BUSINESS CHECKING","BUSINESS SAVINGS","VISA","MC"};
	String[] ALLOWED_ACTION = {"CREATE","MODIFY","DELETE"};
	String TECHINICAL_ERROR_MSG = "We've encountered a technical error";
	//PP-16301, PP-16303 - End
	
	//Sonar issue fix
	String CHASE_ERROR_CODE_ = "chase.error.code.";
	String CC_EXPIRATION_MSG = "The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.";
	String ERR_CODE_PP9022 = "PP9022";
	String CREATE ="CREATE";
	String MODIFY = "MODIFY";
	String SUCCESS = "Success";
	String CHASE_LOGS = "chase-logs";
	
	String[] MSMA_LOB = {"MSUP","MADV"};
}
