package com.anthem.payment.paymod.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="td_codes_mapping")
public class TransactionDivision {

	@Id
	public ObjectId _id;

	@Field("sys_code")
	private String systemCode;
	@Field("legal_code")
	private String legalCode;
	@Field("mrkt_sgmt")
	private String marketSegment;
	@Field("transaction_division")
	private String transactionDivision;
	
	@Field("sys_desc")
	private String systemDescription;
	@Field("le_state")
	private String leState;
	@Field("legal_desc")
	private String legalDescription;
	@Field("mrkt_sgmt_desc")
	private String marketSegmentDescription;
	@Field("branding")
	private String branding;
	@Field("company_id")
	private String companyId;
	@Field("bu_id")
	private String buId;
	@Field("bank_account_last_four")
	private String bankAccountLastDigits;
	@Field("mrkt")
	private String market;
	
	public String getSystemDescription() {
		return systemDescription;
	}
	public void setSystemDescription(String systemDescription) {
		this.systemDescription = systemDescription;
	}
	public String getLeState() {
		return leState;
	}
	public void setLeState(String leState) {
		this.leState = leState;
	}
	public String getLegalDescription() {
		return legalDescription;
	}
	public void setLegalDescription(String legalDescription) {
		this.legalDescription = legalDescription;
	}
	public String getMarketSegmentDescription() {
		return marketSegmentDescription;
	}
	public void setMarketSegmentDescription(String marketSegmentDescription) {
		this.marketSegmentDescription = marketSegmentDescription;
	}
	public String getBranding() {
		return branding;
	}
	public void setBranding(String branding) {
		this.branding = branding;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getBuId() {
		return buId;
	}
	public void setBuId(String buId) {
		this.buId = buId;
	}
	public String getBankAccountLastDigits() {
		return bankAccountLastDigits;
	}
	public void setBankAccountLastDigits(String bankAccountLastDigits) {
		this.bankAccountLastDigits = bankAccountLastDigits;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	
	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getLegalCode() {
		return legalCode;
	}

	public void setLegalCode(String legalCode) {
		this.legalCode = legalCode;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getTransactionDivision() {
		return transactionDivision;
	}

	public void setTransactionDivision(String transactionDivision) {
		this.transactionDivision = transactionDivision;
	}

}
