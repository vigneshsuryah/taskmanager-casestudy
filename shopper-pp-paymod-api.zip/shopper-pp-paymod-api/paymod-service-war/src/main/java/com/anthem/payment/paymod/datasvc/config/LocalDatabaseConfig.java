/**
 * LocalDatabaseConfig.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.datasvc.config;


import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


@Configuration
@Profile("local")
@PropertySource("classpath:application-local.properties")
public class LocalDatabaseConfig
{

	@Bean(name = "dataSource")
	public DataSource walletDb(@Value("${olx.db.walletdb.driverClassName}") String walletDbDriver,
			@Value("${olx.db.walletdb.url}") String walletDbUrl,
			@Value("${olx.db.walletdb.username}") String walletDbUsername,
			@Value("${olx.db.walletdb.password}") String walletDbPassword)
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(walletDbDriver);
		dataSource.setUrl(walletDbUrl);
		dataSource.setUsername(walletDbUsername);
		dataSource.setPassword(walletDbPassword);
		return dataSource;
	}
}
