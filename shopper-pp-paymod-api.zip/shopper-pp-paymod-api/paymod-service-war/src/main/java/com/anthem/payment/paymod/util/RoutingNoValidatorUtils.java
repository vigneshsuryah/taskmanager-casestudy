/**
 * RoutingNoValidatorUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0       Cognizant      Initial Version
 */
package com.anthem.payment.paymod.util;


import org.apache.commons.lang3.StringUtils;


public class RoutingNoValidatorUtils {

	public static final int FIRST_MULTIPLER = 3;
	public static final int SECOND_MULTIPLER = 7;
	public static final int THIRD_MULTIPLER = 1;
	

	/**
	 * 	1	Multiply the first, fourth and seventh numbers in the routing number by 3. For example, if your routing number was 123456780, you would multiply 1, 4 and 7 by 3 to get 3, 12 and 21.											
												
	 *	2	Multiply the second, fifth and eighth digit in the routing number by 7. Continuing the example, with a routing number of 123456780, you would multiply 2, 5 and 8 by 7 to get 14, 35 and 56.											
														
	 *	3	Multiply the third and sixth digit in the routing number by 1. In this example with, you would multiply 3 and 6 by 1 to get 3 and 6.											
														
	 *	4	Add the products from the first three steps. In this example, you would add 3, 12, 21, 14, 35, 56, 3 and 6 to get a total of 150.											
														
	 *	5	Find the next highest multiple of 10, or use the result from Step 4 if it is a multiple of 10. In this example, 150 is a multiple of 10 so you use 150. However, if the result had been 151, you would have used 160.											
														
	 *	6	Subtract sum of the products from the next highest multiple of 10 to find the check digit. In this example, you would subtract 150 from 150 to find that the check digit would be 0, which is the last digit in the routing number.
	 * 
	 *    {@link #isRoutingNoValid(java.lang.String)} method.
	 * @param routingNo
	 * @return true/false for the passed routing number
	 * 
	 */
	public static Boolean isRoutingNoValid(String routingNo)
	{
		if (!StringUtils.isNumeric(routingNo) || routingNo.length() != 9)
		{
			return Boolean.FALSE;
		}
		char[] routingArray = routingNo.toCharArray();
		int firstNumber = Integer.parseInt(String.valueOf(routingArray[0]));
		int secondNumber = Integer.parseInt(String.valueOf(routingArray[1]));
		int thridNumber = Integer.parseInt(String.valueOf(routingArray[2]));
		int fourthNumber = Integer.parseInt(String.valueOf(routingArray[3]));
		int fifthNumber = Integer.parseInt(String.valueOf(routingArray[4]));
		int sixthNumber = Integer.parseInt(String.valueOf(routingArray[5]));
		int seventhNumber = Integer.parseInt(String.valueOf(routingArray[6]));
		int eighthNumber = Integer.parseInt(String.valueOf(routingArray[7]));
		int checkDigit = Integer.parseInt(String.valueOf(routingArray[8]));
		int productsSumOrg = (firstNumber * FIRST_MULTIPLER) + (fourthNumber * FIRST_MULTIPLER) + (seventhNumber * FIRST_MULTIPLER)
				+ (secondNumber * SECOND_MULTIPLER) + (fifthNumber * SECOND_MULTIPLER) + (eighthNumber * SECOND_MULTIPLER)
				+ (thridNumber * THIRD_MULTIPLER) + (sixthNumber * THIRD_MULTIPLER);
		int productsSumArr = productsSumOrg;
		if (productsSumOrg % 10 > 0)
		{
			productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
		}
		if (productsSumArr - productsSumOrg == checkDigit)
		{
			return Boolean.TRUE;
		}
		else
		{
			return Boolean.FALSE;
		}

	}
}
