package com.anthem.payment.paymod.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class CancelDetails {

	@Field("is_csr")
	private boolean isCsr;
	@Field("payment_channel")
	private String paymentChannel;
	@Field("cancelled_by")
	private String cancelledBy;
	@Field("cancelled_dt")
	private Date cancelledDt;
	//Auth Reversal Changes
	@Field("account_number")
	private String accountNumber;
	@Field("MOP")
	private String MOP;
	@Field("response_date")
	private String responseDate;
	@Field("avsaav")
	private String avsaav;
	@Field("card_security_value")
	private String cardSecurityValue;
	@Field("cavv")
	private String cavv;
	@Field("expiration_date")
	private String expirationDate;
	@Field("payment_advice_code")
	private String paymentAdviceCode;
	@Field("recurring_payment_advice_code")
	private String recurringPaymentAdviceCode;
	@Field("cc_token_number")
	private String tokenNumber;

	public boolean isCsr() {
		return isCsr;
	}
	public void setCsr(boolean isCsr) {
		this.isCsr = isCsr;
	}
	public String getCancelledBy() {
		return cancelledBy;
	}
	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}
	public String getPaymentChannel() {
		return paymentChannel;
	}
	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getMOP() {
		return MOP;
	}

	public void setMOP(String MOP) {
		this.MOP = MOP;
	}

	public String getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}

	public String getAvsaav() {
		return avsaav;
	}

	public void setAvsaav(String avsaav) {
		this.avsaav = avsaav;
	}

	public String getCardSecurityValue() {
		return cardSecurityValue;
	}

	public void setCardSecurityValue(String cardSecurityValue) {
		this.cardSecurityValue = cardSecurityValue;
	}

	public String getCavv() {
		return cavv;
	}

	public void setCavv(String cavv) {
		this.cavv = cavv;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getPaymentAdviceCode() {
		return paymentAdviceCode;
	}

	public void setPaymentAdviceCode(String paymentAdviceCode) {
		this.paymentAdviceCode = paymentAdviceCode;
	}

	public String getRecurringPaymentAdviceCode() {
		return recurringPaymentAdviceCode;
	}

	public void setRecurringPaymentAdviceCode(String recurringPaymentAdviceCode) {
		this.recurringPaymentAdviceCode = recurringPaymentAdviceCode;
	}

	public String getTokenNumber() {
		return tokenNumber;
	}

	public void setTokenNumber(String tokenNumber) {
		this.tokenNumber = tokenNumber;
	}
	public Date getCancelledDt() {
		return cancelledDt;
	}
	public void setCancelledDt(Date cancelledDt) {
		this.cancelledDt = cancelledDt;
	}
}
