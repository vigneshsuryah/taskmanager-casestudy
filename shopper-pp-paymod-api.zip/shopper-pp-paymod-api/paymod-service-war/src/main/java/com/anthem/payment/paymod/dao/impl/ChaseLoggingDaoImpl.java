/**
 * MedicareLoggingDaoImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.dao.impl;


import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Component;

import com.anthem.payment.paymod.dao.ChaseLoggingDao;
import com.anthem.payment.paymod.entity.RSTransLog;
import com.anthem.payment.paymod.entity.TPTServicesLog;
import com.anthem.payment.paymod.handler.PaymentModException;


@Component
public class ChaseLoggingDaoImpl extends GenericDAOImpl implements ChaseLoggingDao
{

	private static final String SAVE_RS_LOGGING_SP = "OLX.OLX_MEMBER_RS_LOGS";

	private static final String SAVE_TPT_LOGGING_SP = "OLX.OLX_MEMBER_TPT_SERVICES_LOG";

	@Override
	public void saveRSServiceLog(RSTransLog rSTransLog) throws PaymentModException
	{
		RSServicesLogging logging = new RSServicesLogging(dataSource);
		logging.executeRSServicesLoggingSp(rSTransLog);
	}

	protected class RSServicesLogging extends DAOStoredProc
	{
		protected RSServicesLogging(DataSource ds)
		{
			super(ds, SAVE_RS_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@CHANNEL", Types.VARCHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@ERRORMSG", Types.VARCHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@RSTRANSID", Types.BIGINT));

			compile();
		}

		protected void executeRSServicesLoggingSp(RSTransLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", "");
			inParams.put("@CHANNEL", logDataBean.getChannel());
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXML());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXML());
			inParams.put("@ERRORMSG", logDataBean.getErrorMsg());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());

			if (logDataBean.getRequestTS() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTS().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getRequestTS() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getRequestTS().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@RSTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@RSTRANSIDOUT");
			}
		}
	}

	@Override
	public void saveTPTServiceLog(TPTServicesLog logData) throws PaymentModException
	{
		TPTServicesLogging logging = new TPTServicesLogging(dataSource);
		logging.executeTPTServicesLoggingSp(logData);
	}

	protected class TPTServicesLogging extends DAOStoredProc
	{
		protected TPTServicesLogging(DataSource ds)
		{
			super(ds, SAVE_TPT_LOGGING_SP);

			declareParameter(new SqlParameter("@HCID", Types.CHAR));
			declareParameter(new SqlParameter("@SBRUID", Types.CHAR));
			declareParameter(new SqlParameter("@OPERATIONNAME", Types.VARCHAR));
			declareParameter(new SqlParameter("@REQUESTXML", Types.CLOB));
			declareParameter(new SqlParameter("@RESPONSEXML", Types.CLOB));
			declareParameter(new SqlParameter("@REQUESTTS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@RESPONSETS", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@ISBUSINESSFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@ISSYSTEMFAULT", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEID", Types.CHAR));
			declareParameter(new SqlParameter("@CREATEDDATE", Types.TIMESTAMP));
			declareParameter(new SqlParameter("@REQUESTINGSYSTEM", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEID", Types.CHAR));
			declareParameter(new SqlParameter("@UPDATEDDATE", Types.TIMESTAMP));

			declareParameter(new SqlOutParameter("@TPTTRANSIDOUT", Types.BIGINT));

			compile();
		}

		protected void executeTPTServicesLoggingSp(TPTServicesLog logDataBean)
		{
			// Set inParams
			Map<String, Object> inParams = new HashMap<String, Object>();
			inParams.put("@HCID", logDataBean.getHcid());
			inParams.put("@SBRUID", logDataBean.getSbrUid());
			inParams.put("@OPERATIONNAME", logDataBean.getOperationName());
			inParams.put("@REQUESTXML", logDataBean.getRequestXml());
			inParams.put("@RESPONSEXML", logDataBean.getResponseXml());
			if (logDataBean.getRequestTs() != null)
			{
				inParams.put("@REQUESTTS", new Timestamp(logDataBean.getRequestTs().getTime()));
			}
			else
			{
				inParams.put("@REQUESTTS", null);
			}
			if (logDataBean.getResponseTs() != null)
			{
				inParams.put("@RESPONSETS", new Timestamp(logDataBean.getResponseTs().getTime()));
			}
			else
			{
				inParams.put("@RESPONSETS", null);
			}
			inParams.put("@ISBUSINESSFAULT", logDataBean.getIsBusinessFault());
			inParams.put("@ISSYSTEMFAULT", logDataBean.getIsSystemFault());
			inParams.put("@CREATEID", logDataBean.getHcid());
			inParams.put("@CREATEDDATE", new Timestamp(new Date().getTime()));
			inParams.put("@REQUESTINGSYSTEM", logDataBean.getRequestingSystem());
			inParams.put("@UPDATEID", logDataBean.getHcid());
			inParams.put("@UPDATEDDATE", new Timestamp(new Date().getTime()));

			Map<String, Object> outParams = execute(inParams);
			if (outParams.get("@TPTTRANSIDOUT") != null)
			{
				@SuppressWarnings("unused")
				long insertedId = (Long) outParams.get("@TPTTRANSIDOUT");
			}
		}
	}

}
