/**
 * Address.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address implements Serializable
{

	private static final long serialVersionUID = 7561590194179220571L;

	private String addressLineOne;

	private String addressLineThree;

	private String addressLineTwo;

	private String city;

	private String county;

	private String phone;

	private String phoneExtension;

	private String state;

	private String zipCode;

	/**
	 * @return the addressLineOne
	 */
	public String getAddressLineOne()
	{
		return addressLineOne;
	}

	/**
	 * @param addressLineOne
	 *            the addressLineOne to set
	 */
	public void setAddressLineOne(String addressLineOne)
	{
		this.addressLineOne = addressLineOne;
	}

	/**
	 * @return the addressLineThree
	 */
	public String getAddressLineThree()
	{
		return addressLineThree;
	}

	/**
	 * @param addressLineThree
	 *            the addressLineThree to set
	 */
	public void setAddressLineThree(String addressLineThree)
	{
		this.addressLineThree = addressLineThree;
	}

	/**
	 * @return the addressLineTwo
	 */
	public String getAddressLineTwo()
	{
		return addressLineTwo;
	}

	/**
	 * @param addressLineTwo
	 *            the addressLineTwo to set
	 */
	public void setAddressLineTwo(String addressLineTwo)
	{
		this.addressLineTwo = addressLineTwo;
	}

	/**
	 * @return the city
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 * @param city
	 *            the city to set
	 */
	public void setCity(String city)
	{
		this.city = city;
	}

	/**
	 * @return the country
	 */
	public String getCounty()
	{
		return county;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCounty(String county)
	{
		this.county = county;
	}

	/**
	 * @return the phone
	 */
	public String getPhone()
	{
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	/**
	 * @return the phoneExtension
	 */
	public String getPhoneExtension()
	{
		return phoneExtension;
	}

	/**
	 * @param phoneExtension
	 *            the phoneExtension to set
	 */
	public void setPhoneExtension(String phoneExtension)
	{
		this.phoneExtension = phoneExtension;
	}

	/**
	 * @return the state
	 */
	public String getState()
	{
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state)
	{
		this.state = state;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode()
	{
		return zipCode;
	}

	/**
	 * @param zipCode
	 *            the zipCode to set
	 */
	public void setZipCode(String zipCode)
	{
		this.zipCode = zipCode;
	}

}
