package com.anthem.payment.paymod.response;

import java.io.Serializable;

public class CCPayMethodFieldsUpdateResponse extends BaseResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String message;
	private Exception exceptionDetails;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Exception getExceptionDetails() {
		return exceptionDetails;
	}
	public void setExceptionDetails(Exception exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}
	
}
