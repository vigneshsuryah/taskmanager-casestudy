package com.anthem.payment.paymod.model;

public class Refund {

	private String refundReasonCode;
	private String refundReasondescription;

	public String getRefundReasonCode() {
		return refundReasonCode;
	}

	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}

	public String getRefundReasondescription() {
		return refundReasondescription;
	}

	public void setRefundReasondescription(String refundReasondescription) {
		this.refundReasondescription = refundReasondescription;
	}

}
