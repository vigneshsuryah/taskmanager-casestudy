package com.anthem.payment.paymod.model;

import java.util.List;

public class Transaction {

	private String createdDt;
	private String createdId;
	private String updatedDt;
	private String updatedId;
	private boolean isCsr;
	private String paymentChannel;
	private String premiumAmount;
	private String paidDate;
	private String feeAmount;
	private String transactionStatus;
	private String frequency;
	private String invoiceNumber;
	private String paymentConfirmationEmailAddress;
	private CancelDetails cancelDetails;
	private String notificationIndicator;
	private String updatedToPsd;
	private CommunicationDetails communicationDetails;
	private List<Note> notes;
	private String transactionType;
	private String nocReceived;
	private AnthemBankDetails anthemBankDetails;
	private Journal journal;
	private Returns returns;
	private Refund refund;
	private String checkId;
	private String planId;
	private String classId;
	private String submissionDt;
	private String prfDt;
	/*PP-17513 Starts*/
	private String billDueDate;
	
	/*PP-17513 Ends*/

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedId() {
		return createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	public boolean isCsr() {
		return isCsr;
	}

	public void setCsr(boolean isCsr) {
		this.isCsr = isCsr;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}

	public String getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(String feeAmount) {
		this.feeAmount = feeAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getPaymentConfirmationEmailAddress() {
		return paymentConfirmationEmailAddress;
	}

	public void setPaymentConfirmationEmailAddress(String paymentConfirmationEmailAddress) {
		this.paymentConfirmationEmailAddress = paymentConfirmationEmailAddress;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getNocReceived() {
		return nocReceived;
	}

	public void setNocReceived(String nocReceived) {
		this.nocReceived = nocReceived;
	}

	public AnthemBankDetails getAnthemBankDetails() {
		return anthemBankDetails;
	}

	public void setAnthemBankDetails(AnthemBankDetails anthemBankDetails) {
		this.anthemBankDetails = anthemBankDetails;
	}

	public Journal getJournal() {
		return journal;
	}

	public void setJournal(Journal journal) {
		this.journal = journal;
	}

	public Returns getReturns() {
		return returns;
	}

	public void setReturns(Returns returns) {
		this.returns = returns;
	}

	public Refund getRefund() {
		return refund;
	}

	public void setRefund(Refund refund) {
		this.refund = refund;
	}

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}

	public CancelDetails getCancelDetails() {
		return cancelDetails;
	}

	public void setCancelDetails(CancelDetails cancelDetails) {
		this.cancelDetails = cancelDetails;
	}

	public String getNotificationIndicator() {
		return notificationIndicator;
	}

	public void setNotificationIndicator(String notificationIndicator) {
		this.notificationIndicator = notificationIndicator;
	}

	public CommunicationDetails getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(CommunicationDetails communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public String getUpdatedToPsd() {
		return updatedToPsd;
	}

	public void setUpdatedToPsd(String updatedToPsd) {
		this.updatedToPsd = updatedToPsd;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getSubmissionDt() {
		return submissionDt;
	}

	public void setSubmissionDt(String submissionDt) {
		this.submissionDt = submissionDt;
	}

	public String getPrfDt() {
		return prfDt;
	}

	public void setPrfDt(String prfDt) {
		this.prfDt = prfDt;
	}

	public String getBillDueDate() {
		return billDueDate;
	}

	public void setBillDueDate(String billDueDate) {
		this.billDueDate = billDueDate;
	}

}
