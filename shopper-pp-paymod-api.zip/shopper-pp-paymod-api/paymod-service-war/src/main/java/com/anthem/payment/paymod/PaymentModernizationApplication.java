package com.anthem.payment.paymod;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.dozer.DozerBeanMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

@SpringBootApplication
@EnableEncryptableProperties
public class PaymentModernizationApplication extends SpringBootServletInitializer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PaymentModernizationApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(PaymentModernizationApplication.class, args);
	}

	@Bean(name = "dozerMapper")
	public DozerBeanMapper dozerBean() {
		List<String> mappingFiles = Arrays.asList("dozer-bean-mappings.xml");

		DozerBeanMapper dozerBean = new DozerBeanMapper();
		dozerBean.setMappingFiles(mappingFiles);
		return dozerBean;
	}
	
	@Bean(name = "messageSource")
    public MessageSource messageSource() {
    	ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasenames("classpath:chase_errorcode_mapping");
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setUseCodeAsDefaultMessage(true);
        return messageSource;
    }

}
