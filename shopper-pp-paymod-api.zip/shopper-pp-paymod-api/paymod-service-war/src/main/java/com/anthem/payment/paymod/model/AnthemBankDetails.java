package com.anthem.payment.paymod.model;

public class AnthemBankDetails {

	private String anthemDepostingBank;
	private String businessUnit;
	private String anthemBankAccount;
	private String transactionDivision;
	private String chaseBatchSubmission;
	private String chaseRecordReference;
	private String payDate;
	private String otherChaseFields;

	public String getAnthemDepostingBank() {
		return anthemDepostingBank;
	}

	public void setAnthemDepostingBank(String anthemDepostingBank) {
		this.anthemDepostingBank = anthemDepostingBank;
	}

	public String getAnthemBankAccount() {
		return anthemBankAccount;
	}

	public void setAnthemBankAccount(String anthemBankAccount) {
		this.anthemBankAccount = anthemBankAccount;
	}

	public String getTransactionDivision() {
		return transactionDivision;
	}

	public void setTransactionDivision(String transactionDivision) {
		this.transactionDivision = transactionDivision;
	}

	public String getChaseBatchSubmission() {
		return chaseBatchSubmission;
	}

	public void setChaseBatchSubmission(String chaseBatchSubmission) {
		this.chaseBatchSubmission = chaseBatchSubmission;
	}

	public String getChaseRecordReference() {
		return chaseRecordReference;
	}

	public void setChaseRecordReference(String chaseRecordReference) {
		this.chaseRecordReference = chaseRecordReference;
	}

	public String getPayDate() {
		return payDate;
	}

	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}

	public String getOtherChaseFields() {
		return otherChaseFields;
	}

	public void setOtherChaseFields(String otherChaseFields) {
		this.otherChaseFields = otherChaseFields;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

}
