package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Refund {
	
	@Field("refund_id")
	private String refundId;

	@Field("refund_reason_code")
	private String refundReasonCode;
	
	@Field("refund_reason_description")
	private String refundReasondescription;
	
	public String getRefundId() {
		return refundId;
	}

	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}

	public String getRefundReasonCode() {
		return refundReasonCode;
	}

	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}

	public String getRefundReasondescription() {
		return refundReasondescription;
	}

	public void setRefundReasondescription(String refundReasondescription) {
		this.refundReasondescription = refundReasondescription;
	}

}
