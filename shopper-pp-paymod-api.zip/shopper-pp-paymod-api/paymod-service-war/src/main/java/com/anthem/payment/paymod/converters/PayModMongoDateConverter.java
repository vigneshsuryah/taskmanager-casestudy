package com.anthem.payment.paymod.converters;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.dozer.CustomConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PayModMongoDateConverter implements CustomConverter{

	private static final Logger LOGGER  = LoggerFactory.getLogger(PayModMongoDateConverter.class);
	
	@Override
	public Object convert(Object existingDestinationFieldValue,
			Object sourceFieldValue, Class<?> destinationClass,
			Class<?> sourceClass) {
		
		Object returnObject = null;
		
			
		if(null != sourceFieldValue && sourceFieldValue instanceof Date) {
			// MongoDB date to String flow - search payment response
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			try
			{
				if(null != sourceFieldValue && null != (Date) sourceFieldValue) {
					returnObject = simpleDateFormat.format((Date) sourceFieldValue);		// return string
				}
			} catch (Exception e)
			{
				LOGGER.error("Parse Exception occured while converting date to string" + e);
			}
		}else if(null != sourceFieldValue && sourceFieldValue instanceof String) {
			// String to mongo db store flow - submit payment response
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			try
			{
				if(null != sourceFieldValue && null != (String) sourceFieldValue) {
					returnObject = simpleDateFormat.parse((String) sourceFieldValue);		// return date
				}
			} catch (Exception e)
			{
				LOGGER.error("Parse Exception occured while converting string to date" + e);
			}
		}
		return returnObject;
	}

}
