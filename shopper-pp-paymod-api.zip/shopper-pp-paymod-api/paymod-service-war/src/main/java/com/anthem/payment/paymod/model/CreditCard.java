package com.anthem.payment.paymod.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCard {

	private String creditCardNumber;

	private String expirationMonth;
	
	private String expirationYear;

	private String integrityCheck;
	
	private String keyID;
	
	private String phaseID;
	
	private String creditCardNumberUI;
	
	private String creditCardFirstSix;
	
	private String creditCardLastFour;

	/**
	 * @return the creditCardNumber
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * @param creditCardNumber the creditCardNumber to set
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * @return the expirationMonth
	 */
	public String getExpirationMonth() {
		return expirationMonth;
	}

	/**
	 * @param expirationMonth the expirationMonth to set
	 */
	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	/**
	 * @return the expirationYear
	 */
	public String getExpirationYear() {
		return expirationYear;
	}

	/**
	 * @param expirationYear the expirationYear to set
	 */
	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}

	/**
	 * @return the integrityCheck
	 */
	public String getIntegrityCheck() {
		return integrityCheck;
	}

	/**
	 * @param integrityCheck the integrityCheck to set
	 */
	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}

	/**
	 * @return the keyID
	 */
	public String getKeyID() {
		return keyID;
	}

	/**
	 * @param keyID the keyID to set
	 */
	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	/**
	 * @return the phaseID
	 */
	public String getPhaseID() {
		return phaseID;
	}

	/**
	 * @param phaseID the phaseID to set
	 */
	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}

	/**
	 * @return the creditCardNumberUI
	 */
	public String getCreditCardNumberUI() {
		return creditCardNumberUI;
	}

	/**
	 * @param creditCardNumberUI the creditCardNumberUI to set
	 */
	public void setCreditCardNumberUI(String creditCardNumberUI) {
		this.creditCardNumberUI = creditCardNumberUI;
	}

	/**
	 * @return the creditCardFirstSix
	 */
	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	/**
	 * @param creditCardFirstSix the creditCardFirstSix to set
	 */
	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	/**
	 * @return the creditCardLastFour
	 */
	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	/**
	 * @param creditCardLastFour the creditCardLastFour to set
	 */
	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}
	
}
