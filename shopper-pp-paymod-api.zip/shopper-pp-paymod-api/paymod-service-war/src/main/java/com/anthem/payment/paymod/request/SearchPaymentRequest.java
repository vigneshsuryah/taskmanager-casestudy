package com.anthem.payment.paymod.request;

import java.util.List;

public class SearchPaymentRequest extends BaseRequest {

	private static final long serialVersionUID = -5771743012778663678L;
	private String lob;
	private String hcid;
	private List<String> transactionType;
	private List<String> transactionStatus;

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public List<String> getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(List<String> transactionType) {
		this.transactionType = transactionType;
	}

	public List<String> getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(List<String> transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

}
