package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class CreditCard {

	@Field("credit_card_number")
	private String creditCardNumber;

	@Field("expiration_month")
	private String expirationMonth;
	
	@Field("expiration_year")
	private String expirationYear;

	@Field("integrity_check")
	private String integrityCheck;
	
	@Field("key_id")
	private String keyID;
	
	@Field("phase_id")
	private String phaseID;
	
	@Field("credit_card_token_number")
	private String creditCardTokenNumber;
	
	@Field("credit_card_number_ui")
	private String creditCardNumberUI;
	
	@Field("credit_card_first_six")
	private String creditCardFirstSix;
	
	@Field("credit_card_last_four")
	private String creditCardLastFour;
	
	@Field("action_code")
	private String actionCode;
	
	@Field("response_reason_code")
	private String responseReasonCode;
	
	@Field("token_response_date")
	private String tokenDate;
	
	@Field("is_level3")
	private String isLevelThree;
	
	@Field("AVSAAV")
	private String aVSAAV;

	@Field("cc_authorization_number")
	private String ccAuthorizationNumber;
	
	@Field("interchange_qualification_code")
	private String interchangeQualificationCode;
	
	@Field("response_transaction_id")
	private String responseTransactionID;

	/**
	 * @return the creditCardNumber
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * @param creditCardNumber the creditCardNumber to set
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * @return the expirationMonth
	 */
	public String getExpirationMonth() {
		return expirationMonth;
	}

	/**
	 * @param expirationMonth the expirationMonth to set
	 */
	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	/**
	 * @return the expirationYear
	 */
	public String getExpirationYear() {
		return expirationYear;
	}

	/**
	 * @param expirationYear the expirationYear to set
	 */
	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}

	/**
	 * @return the integrityCheck
	 */
	public String getIntegrityCheck() {
		return integrityCheck;
	}

	/**
	 * @param integrityCheck the integrityCheck to set
	 */
	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}

	/**
	 * @return the keyID
	 */
	public String getKeyID() {
		return keyID;
	}

	/**
	 * @param keyID the keyID to set
	 */
	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	/**
	 * @return the phaseID
	 */
	public String getPhaseID() {
		return phaseID;
	}

	/**
	 * @param phaseID the phaseID to set
	 */
	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}

	/**
	 * @return the creditCardTokenNumber
	 */
	public String getCreditCardTokenNumber() {
		return creditCardTokenNumber;
	}

	/**
	 * @param creditCardTokenNumber the creditCardTokenNumber to set
	 */
	public void setCreditCardTokenNumber(String creditCardTokenNumber) {
		this.creditCardTokenNumber = creditCardTokenNumber;
	}

	/**
	 * @return the creditCardNumberUI
	 */
	public String getCreditCardNumberUI() {
		return creditCardNumberUI;
	}

	/**
	 * @param creditCardNumberUI the creditCardNumberUI to set
	 */
	public void setCreditCardNumberUI(String creditCardNumberUI) {
		this.creditCardNumberUI = creditCardNumberUI;
	}

	/**
	 * @return the creditCardFirstSix
	 */
	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	/**
	 * @param creditCardFirstSix the creditCardFirstSix to set
	 */
	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	/**
	 * @return the creditCardLastFour
	 */
	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	/**
	 * @param creditCardLastFour the creditCardLastFour to set
	 */
	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}

	/**
	 * @return the actionCode
	 */
	public String getActionCode() {
		return actionCode;
	}

	/**
	 * @param actionCode the actionCode to set
	 */
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	/**
	 * @return the responseReasonCode
	 */
	public String getResponseReasonCode() {
		return responseReasonCode;
	}

	/**
	 * @param responseReasonCode the responseReasonCode to set
	 */
	public void setResponseReasonCode(String responseReasonCode) {
		this.responseReasonCode = responseReasonCode;
	}

	/**
	 * @return the tokenDate
	 */
	public String getTokenDate() {
		return tokenDate;
	}

	/**
	 * @param tokenDate the tokenDate to set
	 */
	public void setTokenDate(String tokenDate) {
		this.tokenDate = tokenDate;
	}

	/**
	 * @return the isLevelThree
	 */
	public String getIsLevelThree() {
		return isLevelThree;
	}

	/**
	 * @param isLevelThree the isLevelThree to set
	 */
	public void setIsLevelThree(String isLevelThree) {
		this.isLevelThree = isLevelThree;
	}

	/**
	 * @return the aVSAAV
	 */
	public String getaVSAAV() {
		return aVSAAV;
	}

	/**
	 * @param aVSAAV the aVSAAV to set
	 */
	public void setaVSAAV(String aVSAAV) {
		this.aVSAAV = aVSAAV;
	}

	/**
	 * @return the ccAuthorizationNumber
	 */
	public String getCcAuthorizationNumber() {
		return ccAuthorizationNumber;
	}

	/**
	 * @param ccAuthorizationNumber the ccAuthorizationNumber to set
	 */
	public void setCcAuthorizationNumber(String ccAuthorizationNumber) {
		this.ccAuthorizationNumber = ccAuthorizationNumber;
	}

	/**
	 * @return the interchangeQualificationCode
	 */
	public String getInterchangeQualificationCode() {
		return interchangeQualificationCode;
	}

	/**
	 * @param interchangeQualificationCode the interchangeQualificationCode to set
	 */
	public void setInterchangeQualificationCode(String interchangeQualificationCode) {
		this.interchangeQualificationCode = interchangeQualificationCode;
	}

	public String getResponseTransactionID() {
		return responseTransactionID;
	}

	public void setResponseTransactionID(String responseTransactionID) {
		this.responseTransactionID = responseTransactionID;
	}

}
