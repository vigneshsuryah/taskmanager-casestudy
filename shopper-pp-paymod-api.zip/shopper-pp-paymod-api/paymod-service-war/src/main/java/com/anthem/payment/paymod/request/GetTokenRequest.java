package com.anthem.payment.paymod.request;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class GetTokenRequest extends BaseRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	/*@NotBlank
	private String merchantOrderNumber;*/

	@NotBlank
	@Pattern(regexp = "MC|VI", message = "9125")
	private String methodOfPayment;
	
	@NotBlank
	@Pattern(regexp = "^[a-zA-Z0-9]{16}$", message = "9109")
	private String accountNumber;
	
	@NotBlank
	@Pattern(regexp = "^(0[1-9]|10|11|12)[0-9]{2}$", message = "9113")
	private String expirationDate;
	
	@NotBlank
	@Pattern(regexp = "^[\\d]*([\\.][\\d]{0,2})*$", message = "9176")
	private String amount;
	
	@NotBlank
	private String integrityCheck;
	
	@NotBlank
	private String keyID;
	
	@NotBlank
	private String phaseID;
	
	@NotBlank
	private String anthemOrderId;
	
	@NotBlank
	private String divisionCode;

	private String encryptionFlag;

	@NotBlank
	@Pattern(regexp = "[a-zA-Z\\s]+(\\s[a-zA-Z]+)?", message = "9115")
	private String cardHolderName;

	@NotBlank
	@Pattern(regexp = "^[A-Za-z0-9'\\.\\-\\s\\,\\@\\;\\/]*$", message = "9118")
	private String AddressLine1;

	@NotBlank
	@Pattern(regexp = "^[A-Za-z0-9'\\.\\-\\s\\,\\@\\;\\/]*$", message = "9118")
	private String AddressLine2;

	@NotBlank
	@Pattern(regexp = "[a-zA-Z\\s]+(\\s[a-zA-Z]+)?", message = "9119")
	private String City;

	@NotBlank
	@Pattern(regexp = "^[a-zA-Z]*$", message = "9120")
	private String State;
	
	@NotBlank
	@Pattern(regexp = "^[0-9]{5,9}$", message = "9110")
	private String PostalCode;

	private String responseCode;

	private String tokenizedDate;

	@NotBlank
	private String messageType;

	@NotBlank
	private String storedCredentialFlag;

	private String submittedTransactionID;
	
	/*public String getMerchantOrderNumber() {
		return merchantOrderNumber;
	}
	public void setMerchantOrderNumber(String merchantOrderNumber) {
		this.merchantOrderNumber = merchantOrderNumber;
	}*/
	public String getMethodOfPayment() {
		return methodOfPayment;
	}
	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getIntegrityCheck() {
		return integrityCheck;
	}
	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}
	public String getKeyID() {
		return keyID;
	}
	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}
	public String getPhaseID() {
		return phaseID;
	}
	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return AddressLine1;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	/*public String getEncryptionFlag() {return encryptionFlag; }
	public void setEncryptionFlag(String encryptionFlag){this.encryptionFlag=encryptionFlag;}*/
	public String getAnthemOrderId() {
		return anthemOrderId;
	}
	public void setAnthemOrderId(String anthemOrderId) {
		this.anthemOrderId = anthemOrderId;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	public String getTokenizedDate() {
		return tokenizedDate;
	}

	public void setTokenizedDate(String tokenizedDate) {
		this.tokenizedDate = tokenizedDate;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;

	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}

	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}

	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}

	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}
	/**
	 * @return the encryptionFlag
	 */
	public String getEncryptionFlag() {
		return encryptionFlag;
	}
	/**
	 * @param encryptionFlag the encryptionFlag to set
	 */
	public void setEncryptionFlag(String encryptionFlag) {
		this.encryptionFlag = encryptionFlag;
	}
	
}
