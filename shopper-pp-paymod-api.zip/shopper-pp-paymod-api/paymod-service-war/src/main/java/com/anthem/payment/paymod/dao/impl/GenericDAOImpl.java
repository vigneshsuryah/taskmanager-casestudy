/**
 * GenericDAOImpl.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.dao.impl;


import javax.sql.DataSource;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.object.StoredProcedure;


public class GenericDAOImpl
{

	public static String UPDATE = "UPDATE";
	public static String DELETE = "DELETE";
	public static String NONE = "NONE";

	@Autowired
	protected DataSource dataSource;

	public void afterPropertiesSet() throws Exception
	{
		if (dataSource == null)
		{
			throw new BeanCreationException("Data Source Cannot Be Empty");
		}
	}

	protected abstract class DAOStoredProc extends StoredProcedure
	{

		protected DAOStoredProc(DataSource ds, String sp)
		{
			setDataSource(ds);
			setFunction(false);
			setSql(sp);
		}
	}
}
