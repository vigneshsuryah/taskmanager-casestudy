package com.anthem.payment.paymod.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

public class Transaction {

	@Field("created_dt")
	private Date createdDt;
	@Field("created_id")
	private String createdId;
	@Field("updated_dt")
	private Date updatedDt;
	@Field("updated_id")
	private String updatedId;
	@Field("cancel_details")
	private CancelDetails cancelDetails;
	@Field("iscsr")
	private boolean isCsr;
	@Field("payment_channel")
	private String paymentChannel;
	@Field("premium_amount")
	private double premiumAmount;
	@Field("paid_date")
	private Date paidDate;
	@Field("fee_amount")
	private double feeAmount;
	@Field("transaction_status")
	private String transactionStatus;
	@Field("frequency")
	private String frequency;
	@Field("invoice_number")
	private String invoiceNumber;
	@Field("payment_confirmation_email_address")
	private String paymentConfirmationEmailAddress;
	@Field("notification_indicator")
	private String notificationIndicator;
	@Field("updated_to_psd")
	private String updatedToPsd;
	@Field("communication_details")
	private CommunicationDetails communicationDetails;
	@Field("notes")
	private List<Note> notes;
	@Field("transaction_type")
	private String transactionType;
	@Field("noc_received")
	private boolean nocReceived;
	@Field("anthem_bank_details")
	private AnthemBankDetails anthemBankDetails;
	@Field("journal")
	private Journal journal;
	@Field("returns")
	private Returns returns;
	@Field("refund")
	private Refund refund;
	@Field("check_id")
	private String checkId;
	@Field("plan_id")
	private String planId;
	@Field("class_id")
	private String classId;
	@Field("submission_date")
	private Date submissionDt;
	@Field("bkndst_ts")
	private Date prfDt;
	/*PP-17513 Starts*/
	@Field("bill_due_date")
	private Date billDueDate;
	
	public String getCheckId() {
		return checkId;
	}

	/**
	 * @return the billDueDate
	 */
	public Date getBillDueDate() {
		return billDueDate;
	}

	/**
	 * @param billDueDate the billDueDate to set
	 */
	public void setBillDueDate(Date billDueDate) {
		this.billDueDate = billDueDate;
	}
	/*PP-17513 Ends*/
	
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedId() {
		return createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	public boolean isCsr() {
		return isCsr;
	}

	public void setCsr(boolean isCsr) {
		this.isCsr = isCsr;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

	public double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Date getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(Date paidDate) {
		this.paidDate = paidDate;
	}

	public double getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(double feeAmount) {
		this.feeAmount = feeAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getPaymentConfirmationEmailAddress() {
		return paymentConfirmationEmailAddress;
	}

	public void setPaymentConfirmationEmailAddress(String paymentConfirmationEmailAddress) {
		this.paymentConfirmationEmailAddress = paymentConfirmationEmailAddress;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public boolean isNocReceived() {
		return nocReceived;
	}

	public void setNocReceived(boolean nocReceived) {
		this.nocReceived = nocReceived;
	}

	public AnthemBankDetails getAnthemBankDetails() {
		return anthemBankDetails;
	}

	public void setAnthemBankDetails(AnthemBankDetails anthemBankDetails) {
		this.anthemBankDetails = anthemBankDetails;
	}

	public Journal getJournal() {
		return journal;
	}

	public void setJournal(Journal journal) {
		this.journal = journal;
	}

	public Returns getReturns() {
		return returns;
	}

	public void setReturns(Returns returns) {
		this.returns = returns;
	}

	public Refund getRefund() {
		return refund;
	}

	public void setRefund(Refund refund) {
		this.refund = refund;
	}
	
	public CancelDetails getCancelDetails() {
		return cancelDetails;
	}

	public void setCancelDetails(CancelDetails cancelDetails) {
		this.cancelDetails = cancelDetails;
	}
	
	public String getNotificationIndicator() {
		return notificationIndicator;
	}

	public void setNotificationIndicator(String notificationIndicator) {
		this.notificationIndicator = notificationIndicator;
	}

	public String getUpdatedToPsd() {
		return updatedToPsd;
	}

	public void setUpdatedToPsd(String updatedToPsd) {
		this.updatedToPsd = updatedToPsd;
	}

	public CommunicationDetails getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(CommunicationDetails communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public Date getSubmissionDt() {
		return submissionDt;
	}

	public void setSubmissionDt(Date submissionDt) {
		this.submissionDt = submissionDt;
	}

	public Date getPrfDt() {
		return prfDt;
	}

	public void setPrfDt(Date prfDt) {
		this.prfDt = prfDt;
	}
	
}
