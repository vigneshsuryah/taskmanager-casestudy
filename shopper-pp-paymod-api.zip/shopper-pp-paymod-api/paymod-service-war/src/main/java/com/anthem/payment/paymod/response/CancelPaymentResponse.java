package com.anthem.payment.paymod.response;

import java.io.Serializable;

public class CancelPaymentResponse extends BaseResponse  implements Serializable{

	private static final long serialVersionUID = 1L;

	private boolean isCancelled;
	
	private String errorMessage;
	private String errorCode;
	private String emailId;
	
	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
