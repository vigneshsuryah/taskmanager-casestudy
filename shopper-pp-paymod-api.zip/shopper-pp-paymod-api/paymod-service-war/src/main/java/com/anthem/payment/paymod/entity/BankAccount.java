package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class BankAccount {

	@Field("bank_routing_number")
	private String bankRoutingNumber;

	@Field("bank_account_number")
	private String bankAccountNumber;

	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

}
