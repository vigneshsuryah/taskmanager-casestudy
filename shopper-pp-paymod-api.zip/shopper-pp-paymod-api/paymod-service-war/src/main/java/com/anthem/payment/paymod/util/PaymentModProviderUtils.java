package com.anthem.payment.paymod.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.payment.paymod.handler.PaymentModException;

public final class PaymentModProviderUtils implements PaymentModConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentModProviderUtils.class);
	
	private PaymentModProviderUtils() {
	
	}

	public static Boolean authenticatePassword(String encryptedText, String key, String algorithm, String pwd) throws PaymentModException {
		try {
			String decryptedText = PaymentModEncryptionUtils.getDecryptedText(
					PaymentModBase64EncodeUtils.getDecodedText(key), algorithm, encryptedText);
			if (decryptedText.equals(PaymentModBase64EncodeUtils.getDecodedText(pwd)))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentChaseAccessProviderUtils.authenticatePassword::" + e.getCause());
			throw new PaymentModException(PAYMENT_MOD_ERR_9003, PAYMENT_MOD_ERR_9003_DESC);
		}

	}

	public static Boolean authenticateUserName(String consumerUserName, String producerUserName) throws PaymentModException {
		try
		{
			if (consumerUserName.equals(PaymentModBase64EncodeUtils.getDecodedText(producerUserName)))
			{
				return Boolean.TRUE;
			}
			else
			{
				return Boolean.FALSE;
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in PaymentChaseAccessProviderUtils.authenticateUserName::" + e.getCause());
			throw new PaymentModException(PAYMENT_MOD_ERR_9002, PAYMENT_MOD_ERR_9002_DESC);
		}
	}
	
	public static Boolean authenticateRequestingApplication(String requestingApplicationName, String allowedApplication) throws PaymentModException
	{
		Boolean returnFlag = Boolean.FALSE;
		
		try
		{
			if (allowedApplication == null || allowedApplication.isEmpty() || requestingApplicationName == null || requestingApplicationName.isEmpty())
			{
				return returnFlag;
			}
			else
			{
				String[] applicationsList = allowedApplication.split(",");
				for(String nameVal :applicationsList)
				{
					if(requestingApplicationName.equalsIgnoreCase(nameVal))
					{
						returnFlag = Boolean.TRUE;
						break;
					}
				}
				return returnFlag; 
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in PaymentChaseAccessProviderUtils.authenticateRequestingApplication::" + e.getCause());
			throw new PaymentModException(PAYMENT_MOD_ERR_9004, PAYMENT_MOD_ERR_9004_DESC);
		}
	}

}
