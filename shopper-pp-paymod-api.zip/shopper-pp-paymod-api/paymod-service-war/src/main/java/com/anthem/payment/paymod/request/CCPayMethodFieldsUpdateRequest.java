package com.anthem.payment.paymod.request;

import java.io.Serializable;
import java.util.List;

public class CCPayMethodFieldsUpdateRequest extends BaseRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private List<String> hcids;
	private String lob;
	private String divisionCode;
	
	public List<String> getHcids() {
		return hcids;
	}
	public void setHcids(List<String> hcids) {
		this.hcids = hcids;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
}
