package com.anthem.payment.paymod.validator;

import org.springframework.stereotype.Component;

@Component
public class PaymentModValidator {

}
