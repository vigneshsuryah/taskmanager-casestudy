/**
 * GetMemberBillingAddrRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 07/30/2019  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.request;


import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetMemberBillingAddrRequest extends BaseRequest
{
	private static final long serialVersionUID = 1L;

	private String groupId;

	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

}
