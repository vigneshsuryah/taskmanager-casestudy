/**
 * GenericDAO.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 02/19/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.dao;


import javax.sql.DataSource;


public interface GenericDAO
{

	public DataSource getDataSource();

	public void setDataSource(DataSource dataSource);
}
