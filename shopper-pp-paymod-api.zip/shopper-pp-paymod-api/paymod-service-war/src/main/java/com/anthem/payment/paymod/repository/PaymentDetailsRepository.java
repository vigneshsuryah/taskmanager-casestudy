package com.anthem.payment.paymod.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.payment.paymod.entity.PaymentDetails;

@Repository
public interface PaymentDetailsRepository extends MongoRepository<PaymentDetails, String>{
	
	@Query(value = "{ 'hcid' : ?0, 'productIdentifier' : ?1, 'transactions.paidDate' : ?2}")
	List<PaymentDetails> getPaymentDetails(String hcid, String productId, Date paymentDate);
	
	@Query(value = "{ $or:[{'hcid' : ?0},{'summaryBill' : ?0}], 'lob' : ?1, 'transactions.transactionStatus' : {$in: ?2}, 'transactions.transactionType' : {$in: ?3}}")
	List<PaymentDetails> searchPaymentDetails(String hcid, String lob, List<String> transactionStatus, List<String> transactionType);

    @Query(value = "{ 'anthemOrderId' : ?0}")
	List<PaymentDetails> getPaymentDetailsByOrderId(String anthemOrderId);
  
}
