package com.anthem.payment.paymod.request;

public class RefundEmailRequest extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String childHealthCardId;

	private String planID;

	private String paymentAmount;

	private String confirmationNumber;
	
	private String paymentDate;
	
	private String csrEnteredEmailId;
	
	private String orderId;
	
	private String groupId;

	public String getChildHealthCardId() {
		return childHealthCardId;
	}

	public void setChildHealthCardId(String childHealthCardId) {
		this.childHealthCardId = childHealthCardId;
	}

	public String getPlanID() {
		return planID;
	}

	public void setPlanID(String planID) {
		this.planID = planID;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getCsrEnteredEmailId() {
		return csrEnteredEmailId;
	}

	public void setCsrEnteredEmailId(String csrEnteredEmailId) {
		this.csrEnteredEmailId = csrEnteredEmailId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

}
