/**
 * GetMemberBillingAddrResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 07/30/2019  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.response;

import java.io.Serializable;

import com.anthem.payment.paymod.model.Address;

public class GetMemberBillingAddrResponse implements Serializable
{
	private static final long serialVersionUID = 20341082555762314L;
	
	private Address address;

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

}
