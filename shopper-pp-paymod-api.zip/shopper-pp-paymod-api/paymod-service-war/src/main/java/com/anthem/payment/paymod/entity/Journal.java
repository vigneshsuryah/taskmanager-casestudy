package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Journal {

	@Field("journal_id")
	private String journalId;
	@Field("journal_date")
	private String journalDate;
	@Field("legal_entity_code")
	private String legalEntityCode;

	public String getJournalId() {
		return journalId;
	}

	public void setJournalId(String journalId) {
		this.journalId = journalId;
	}

	public String getJournalDate() {
		return journalDate;
	}

	public void setJournalDate(String journalDate) {
		this.journalDate = journalDate;
	}

	public String getLegalEntityCode() {
		return legalEntityCode;
	}

	public void setLegalEntityCode(String legalEntityCode) {
		this.legalEntityCode = legalEntityCode;
	}

}
