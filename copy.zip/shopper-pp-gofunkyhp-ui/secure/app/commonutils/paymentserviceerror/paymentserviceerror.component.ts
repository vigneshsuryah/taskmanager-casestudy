import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { kytppServiceList } from '../../shared/kytpp-service/index';

@Component({
  moduleId: module.id,
  selector: 'kytpp-paymentserviceerror',
  templateUrl: 'paymentserviceerror.component.html'
})
export class PaymentServiceErrorComponent implements OnInit {

  
  constructor(public router: Router, private kytppServiceList: kytppServiceList) {
  }

  ngOnInit() {
    
  }

 }



