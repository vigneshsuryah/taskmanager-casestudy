import { Component,ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../shared/kytpp-service/authentication.service';
import { DOCUMENT } from '@angular/platform-browser';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'kytpp-header',
  templateUrl: 'header.component.html' ,
  styleUrls: ['header.component.css']
})

export class HeaderComponent implements OnInit { 

   logoutAutoTimerVar : any;

   constructor(public router: Router, private authserv : AuthenticationService, @Inject(DOCUMENT) private document: any) {
    
   }

  ngOnInit() {
    
  }

  toLogOut(){
    jQuery("#logout-submit").click();
  }

  openLogoutPopup(){
    this.logoutAutoTimerVar = setTimeout(() => {
      this.toLogOut()
    }, 30000);
    jQuery("#logout-popup-click").click();
  }

  clearLogoutTimer(){
    clearTimeout(this.logoutAutoTimerVar);
  }

} 

