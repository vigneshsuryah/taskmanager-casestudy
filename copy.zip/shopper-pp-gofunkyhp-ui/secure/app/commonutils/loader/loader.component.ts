import { Component,ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'kytpp-loader',
  templateUrl: 'loader.component.html' ,
  styleUrls: ['loader.component.css']
})

export class LoaderComponent implements OnInit { 
  
  ngOnInit() {
    
  }
  
} 

