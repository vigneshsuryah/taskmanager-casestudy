import { NgModule, ModuleWithProviders } from '@angular/core';

import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UxModule } from '../shared/ux.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BackdropComponent } from './backdrop/backdrop.component';
import { LoaderComponent } from './loader/loader.component';
import { ScreenFreezeComponent } from './screenfreeze/screenfreeze.component';
import { TechErrSectionComponent } from './techerrsection/techerrsection.component';
import { PasswordValidatorDirective } from '../shared/directives/passwordValidatorDir';
import { ConfirmPasswordValidatorDirective } from '../shared/directives/confirmPasswordValidatorDir';
import { EmailValidatorDirective } from '../shared/directives/emailValidatorDir';
import { NameValidatorDirective } from '../shared/directives/nameFieldValidator';
import { ExpirationDateValidatorDirective } from '../shared/directives/expirationDateValidator';
import { ConfirmEmailAddressValidatorDirective } from '../shared/directives/confirmEmailValidatorDir';
import { AuthenticationService } from '../shared/kytpp-service/authentication.service';
import { PaymentServiceErrorComponent } from './paymentserviceerror/paymentserviceerror.component';
import { AllowOnlyNumber } from '../shared/directives/allowOnlyNumber';
import { AllowOnlyDecimal } from '../shared/directives/allowOnlyDecimal';
import { AmountPipe } from '../shared/directives/amountFilter';
import { CurrencyPipe  } from "@angular/common";
import { IterateMapPipe } from '../shared/directives/iterateMap';

@NgModule({
  imports: [CommonModule, RouterModule, FormsModule, UxModule],
  declarations: [HeaderComponent, FooterComponent,BackdropComponent,LoaderComponent,ScreenFreezeComponent, TechErrSectionComponent,PasswordValidatorDirective,ConfirmPasswordValidatorDirective,EmailValidatorDirective,NameValidatorDirective,ExpirationDateValidatorDirective,ConfirmEmailAddressValidatorDirective, PaymentServiceErrorComponent,AllowOnlyNumber,AllowOnlyDecimal,AmountPipe, IterateMapPipe],
  exports: [HeaderComponent, FooterComponent, LoaderComponent, ScreenFreezeComponent, TechErrSectionComponent, PaymentServiceErrorComponent,
    CommonModule, FormsModule, RouterModule, BackdropComponent,PasswordValidatorDirective,ConfirmPasswordValidatorDirective,EmailValidatorDirective,NameValidatorDirective,ExpirationDateValidatorDirective,ConfirmEmailAddressValidatorDirective,AllowOnlyNumber,AllowOnlyDecimal,AmountPipe, IterateMapPipe],
    providers: [AuthenticationService,CurrencyPipe]
})
export class CommonutilsModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CommonutilsModule,      
    };
  }

  
}
