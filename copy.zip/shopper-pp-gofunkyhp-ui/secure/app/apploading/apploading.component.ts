import { Component, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { kytppServiceList } from '../shared/kytpp-service/index';
import { Router } from '@angular/router';
import { User } from '../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'kytpp-apploading',
  templateUrl: 'apploading.component.html'
})
export class AppLoadingComponent { 
 
    constructor (public kytppServiceList: kytppServiceList, public fb: FormBuilder,public router : Router, private currentUser: User){
      
    }
    
    ngOnInit(){
      setTimeout(()=>{
        if(!this.currentUser.authFlag){
          this.router.navigate(['/accountSettings']);
        } else {
          this.router.navigate(['/myAccount']);
        }
      },2000);
    }


}
