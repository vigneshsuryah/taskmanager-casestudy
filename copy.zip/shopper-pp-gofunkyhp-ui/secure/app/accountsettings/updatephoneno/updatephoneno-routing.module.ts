import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UpdatePhonenoComponent } from './updatephoneno.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'updatePhoneno', component: UpdatePhonenoComponent }
    ])
  ],
  exports: [RouterModule]
})
export class UpdatePhonenoRoutingModule { }
