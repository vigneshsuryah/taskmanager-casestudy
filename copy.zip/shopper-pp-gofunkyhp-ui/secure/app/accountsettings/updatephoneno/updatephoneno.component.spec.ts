import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { soaServiceList } from '../../shared/kytpp-service/index';
import { AuthenticationService } from '../../shared/kytpp-service/index';

import { UpdatePhonenoModule } from './updatephoneno.module';

import { Observable } from 'rxjs/Observable';

import { User } from '../../shared/models/user';
import { AccountSettingsComponent } from '../../accountsettings/accountsettings.component';
import { BackdropComponent } from '../../commonutils/backdrop/backdrop.component';
import { CommonutilsModule } from '../../commonutils/commonutils.module';

import { TechnicalErrorComponent } from '../../commonutils/technicalerror/technicalerror.component';
import { TechnicalErrorModule } from '../../commonutils/technicalerror/technicalerror.module';

export function main() {
  
  describe('Update Phone Nbr component', () => {
    let config: Route[] = [
      { path: 'accountSettings', component: AccountSettingsComponent },
      { path: 'technicalError', component: TechnicalErrorComponent }
    ];

    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, UpdatePhonenoModule, CommonutilsModule, RouterTestingModule.withRoutes(config)],
        declarations: [UpdatePhoneNbrTestComponent, AccountSettingsComponent, TechnicalErrorComponent],
        providers: [
          soaServiceList,
          AuthenticationService,
          User,
          BaseRequestOptions,
          MockBackend,
          BackdropComponent,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

   it('updatePhoneno should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(UpdatePhoneNbrTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      it('updatePhoneno updatePhoneNo should return false when called', async(() => {
        TestBed
          .compileComponents()
          .then(() => {
          let mockBackend = TestBed.get(MockBackend);

          let user = TestBed.get(User);
          user.username = 'vsuser101';
          user.orgType = 'Test';
          user.orgName = 'Cognizant';
          user.userDn = 'CN=vsuser038,OU=eMembers,OU=webUsers,OU=usersAndGroups,DC=webdevad,DC=wellpoint,DC=com';
          user.iamGuid = 'f5e94997-4e8c-4e3f-bcb2-91afa6daac75';

          let actualRes : any;
          actualRes = {
            "errorMessage": null,
            "modified": true,
            "user": {
                "hcid": null,
                "emailAddress": "test123@anthem.com",
                "username": "vsuser038",
                "iamGuid": "6dc632f8-7c8b-44f2-af64-932e4ce7ae6e",
                "secretQuestion": null,
                "secretAnswer": null,
                "hcidPrefix": null,
                "firstName": "Vignesh",
                "lastName": "Suryah",
                "dateOfBirth": null,
                "phoneNumber": null,
                "dn": "CN=vsuser038,OU=eMembers,OU=webUsers,OU=usersAndGroups,DC=webdevad,DC=wellpoint,DC=com",
                "registrationDate": null,
                "repositoryEnum": "IAM",
                "userRoleEnum": "MEMBER",
                "brandEnum": null,
                "securityGroupEnum": null,
                "userAccountStatus": {
                    "disabled": false,
                    "locked": false,
                    "forceChangePassword": false,
                    "badSecretAnsCount": 1,
                    "badPasswordCount": 1,
                    "lastLoginTime": null,
                    "comments": null,
                    "userNameValid": false,
                    "secretQuestionValid": false
                },
                "otherAttributes": null,
                "memberOf": [
                    "CN=eMember,OU=identityMinder,OU=Application Groups,OU=Wellpoint,OU=Groups,OU=usersAndGroups,DC=webdevad,DC=wellpoint,DC=com"
                ],
                "ssoID": [],
                "secretQuestionAnswers": [
                    {
                        "question": "in what city or town was your first job?",
                        "answer": "TFfwyI2YRGMDJ2I2M84mnPgmq5k=",
                        "encrypted": true,
                        "questionValid": true
                    },
                    {
                        "question": "what school did you attend for the third grade?",
                        "answer": "RIuxxbOJT7h9ggk81/mnmkQfVHE=",
                        "encrypted": true,
                        "questionValid": true
                    },
                    {
                        "question": "what is your maternal grandmother's maiden name?",
                        "answer": "uYVdX5B/B5JuzEa094yuFZiJjF8=",
                        "encrypted": true,
                        "questionValid": true
                    }
                ],
                "memberId": null,
                "ssoUniqueId": null,
                "ssoClientId": null,
                "orgType": null,
                "orgName": null
            }
        };
          
          let authenticationService = TestBed.get(AuthenticationService);
          authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

          mockBackend.connections.subscribe((c: any) => {
            c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
          });

          let phoneData = {
            "newPhoneNo":"123456789"
          };
          
          let fixture = TestBed.createComponent(UpdatePhoneNbrTestComponent);
          let instance = fixture.debugElement.children[0].componentInstance;
          fixture.detectChanges();

          instance.updatePhoneNo(phoneData);
          expect(instance.screenLoader).toBe(false);
        });
    }));
      
  });
}

@Component({
  selector: 'test-cmp',
  template: '<kytpp-updatePhoneno></kytpp-updatePhoneno>'
})
class UpdatePhoneNbrTestComponent { }
