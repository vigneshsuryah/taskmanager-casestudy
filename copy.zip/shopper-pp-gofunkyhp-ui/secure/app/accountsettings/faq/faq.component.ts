import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/kytpp-service/index';
import { kytppServiceList } from '../../shared/kytpp-service/index';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'kytpp-faq',
  templateUrl: 'faq.component.html',
  styleUrls: ['faq.component.css']
})
export class FAQComponent implements OnInit {

  screenLoader: boolean;
  inputParam: any = {};
  getFaqQnAResponse: any = {};
  showContent: any;
  faqHeadingList: any = [];

  constructor (public router : Router, private kytppServiceList: kytppServiceList, private soaServiceList : soaServiceList, private currentUser: User){

  }

  ngOnInit() {
    this.screenLoader = false;

    this.kytppServiceList.getFaqQnA(this.inputParam).subscribe(
      (data: any) => {
        this.getFaqQnAResponse = data;   
        for(let i=0;i<this.getFaqQnAResponse.length;i++){
          var faqArray = this.getFaqQnAResponse[i].label.split(" ");
          this.faqHeadingList.push(faqArray[0]);
        } 
      },
      (err: any) => {
        this.showContent = 'techerror';
      }    
    );
  }

  returnToMyAccount (): any{
    this.router.navigate(['/myAccount']);
  }

  toggleFaqSection(label: string, sectionNumber: string): any{
    //console.log("sectionNumber inside method: "+sectionNumber+label);
    jQuery("#faq-section-"+label+"-"+sectionNumber).slideToggle();
    if(jQuery("#faq-section-click-"+label+"-"+sectionNumber).hasClass('glyphicon-plus')){
      jQuery("#faq-section-click-"+label+"-"+sectionNumber).removeClass('glyphicon-plus').addClass('glyphicon-minus');
    }else{
      jQuery("#faq-section-click-"+label+"-"+sectionNumber).removeClass('glyphicon-minus').addClass('glyphicon-plus');
    }
  }

}