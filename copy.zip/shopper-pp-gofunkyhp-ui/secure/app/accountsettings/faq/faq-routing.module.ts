import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FAQComponent } from './faq.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'faq', component: FAQComponent }
    ])
  ],
  exports: [RouterModule]
})
export class FAQRoutingModule { }
