import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AccountSettingsComponent } from './accountsettings.component';

import { AuthGuard } from '../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'accountSettings', component: AccountSettingsComponent }
    ])
  ],
  exports: [RouterModule]
})
export class AccountSettingsRoutingModule { }
