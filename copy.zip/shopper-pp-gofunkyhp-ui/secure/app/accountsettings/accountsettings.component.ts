import { Component, EventEmitter,OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { soaServiceList } from '../shared/kytpp-service/index';
import { kytppServiceList } from '../shared/kytpp-service/index';
import { User } from '../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'kytpp-accountsettings',
  templateUrl: 'accountsettings.component.html',
  styleUrls: ['accountsettings.component.css']
})
export class AccountSettingsComponent implements OnInit{ 

  showErrorMessagePassword: boolean = false;
  showErrorMessageName: boolean = false;
  showErrorMessageEmail: boolean = false;
  showErrorMessagePhone: boolean = false;
  accountDetails : any = {};
  screenLoader: boolean = false;
  inputParam: any = '';
  currentPasswordShowFlag : boolean = false;
  newPasswordShowFlag : boolean = false;
  confirmNewPasswordShowFlag : boolean = false;
  constructor(public router: Router,private soaServiceList : soaServiceList, public kytppServiceList: kytppServiceList, private currentUser: User) {
  }

  ngOnInit(){
    
    this.screenLoader = true;
    this.showErrorMessagePassword = false;
    this.showErrorMessageName = false;
    this.showErrorMessageEmail = false;
    this.showErrorMessagePhone = false;
    jQuery("#passwordChange").hide();
    jQuery("#nameChange").hide();
    jQuery("#emailChange").hide();
    jQuery("#phoneChange").hide();

     this.inputParam = {
       "userName":this.currentUser.username
     }
    
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.searchUser(this.inputParam).subscribe(
      (data: any) => {
        if(data.user !== undefined && data.user !== null){
              this.currentUser.iamGuid = data.user.iamGuid;
              this.soaServiceList.consoleLog("Current User :"+JSON.stringify(this.currentUser));
              this.accountDetails = {
                          "userName":this.currentUser.username,
                          "orgName":this.currentUser.orgName,
                          "pswdalias":"*******",
                          "name":data.user.firstName+" "+data.user.lastName,
                          "email":data.user.emailAddress,
                          "phone":data.user.phoneNumber,
                          "currentPassword":"",
                          "newPassword":"",
                          "confirmNewPassword":"",
                          "updateFirstName":"",
                          "updateLastName":"",
                          "updateNewEmail":"",
                          "updateNewPhone":"",
                          "orgname":data.user.orgName
              };
        }else{
           this.soaServiceList.consoleLog(data.errorMessage);
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
        }
      this.screenLoader = false;
    },
    (err: any) => {
       this.soaServiceList.consoleLog(err);
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
    if(!this.currentUser.authFlag){
      jQuery("#emailPopUp").click();
    }
  }

  updatePassword(){
    this.screenLoader = true;
    this.showErrorMessagePassword = false;
    
     this.inputParam = {
       "userName":this.currentUser.username,
       "dn":this.currentUser.userDn,
       "iamGuid":this.currentUser.iamGuid,
       "currentPassword":this.accountDetails.currentPassword,
       "newPassword":this.accountDetails.newPassword
     }
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.changePassword(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.changeStatus){
                this.router.navigate(['/accountSettings']);
                this.togglePasswordSection();
          }else{
                if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'PWDALREADYUSED'){
                   jQuery("#change-password-error-msg").text("New Password entered is same as the current password.");
                   this.showErrorMessagePassword = true;
                }else if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'UNKNOWN'){
                  jQuery("#change-password-error-msg").text("Hmmm...Something’s not right. Please check your password and try again.");
                  this.showErrorMessagePassword = true;
                }
                /* TODO - call logout functionality on ACCOUNT LOCKED */
                else{
                      this.soaServiceList.consoleLog(data);
                      this.screenLoader = false;
                      this.router.navigate(['/technicalError']);
                }
          }
      
      this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

  updateEmailAddress(){
    this.screenLoader = true;
    this.showErrorMessageEmail = false;
    
     this.inputParam = {
       "userName":this.currentUser.username,
       "dn":this.currentUser.userDn,
       "iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"EMAIL_ADDRESS",
         "attributeValue": this.accountDetails.updateNewEmail
       }]
     }
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
            this.accountDetails.email = this.accountDetails.updateNewEmail;
            this.router.navigate(['/accountSettings']);
            this.toggleEmailSection();
          }else{
            if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'EMAILIDALREADYEXISTS'){
                  jQuery("#update-email-error-msg").text("Hmmm... The email address you provided is already registered. Please provide a different email or log in with your existing account.");
                  this.showErrorMessageEmail = true;
              }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
                }
          }
          this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

  updatePhoneNo(){
    this.screenLoader = true;
    this.showErrorMessagePhone = false;
    
     this.inputParam = {
       "userName":this.currentUser.username,
       "dn":this.currentUser.userDn,
       "iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"PHONE_NUMBER",
         "attributeValue": this.accountDetails.updateNewPhone
         }]
     }
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
            this.accountDetails.phone = this.accountDetails.updateNewPhone;
            this.router.navigate(['/accountSettings']);
            this.togglePhoneSection();
          }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
          }
          this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
  }

    updateName(){
    this.screenLoader = true;
    this.showErrorMessageName = false;
    
     this.inputParam = {
       "userName":this.currentUser.username,
       "dn":this.currentUser.userDn,
       "iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"FIRST_NAME",
         "attributeValue": this.accountDetails.updateFirstName
         },
         {
         "attributeName":"LAST_NAME",
         "attributeValue": this.accountDetails.updateLastName
         }]
     }
    this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
             this.accountDetails.name = this.accountDetails.updateFirstName+" "+this.accountDetails.updateLastName,
             this.router.navigate(['/accountSettings']);
             this.toggleNameSection();
          }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
          }
          this.screenLoader = false;
    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
  }

  updateAuthFlagCall (): any {
    if(!this.currentUser.authFlag){
      this.updateAuthFlag();
    }  
  }

  updateAuthFlag() {
    this.screenLoader = true;
    this.inputParam = {
      "userName": this.currentUser.username,
    }
    this.kytppServiceList.consoleLog(this.inputParam);
    this.kytppServiceList.updateAuthFlag(this.inputParam).subscribe(
      (data: any) => {
        this.screenLoader = false;
        if (data !== undefined && data !== null) {
          if(data.updateStatus) {
            this.currentUser.authFlag = true;
          } else {
            this.currentUser.authFlag = false;
          }
        } else {
          this.kytppServiceList.consoleLog(data);
          this.screenLoader = false;
          this.router.navigate(['/technicalError']);
        }
      },
      (err: any) => {
        this.screenLoader = false;
        this.router.navigate(['/technicalError']);
      }
    );
  }

  returnToMyAccount (): any{
    this.router.navigate(['/myAccount']);
  }

  togglePasswordSection (): any{
    //this.accountDetails.currentPassword = '';
    //this.accountDetails.newPassword = '';
    //this.accountDetails.confirmNewPassword = '';
    this.showErrorMessagePassword = false;
    jQuery("#passwordChange").slideToggle();
  }
  toggleNameSection (): any{ 
   // this.accountDetails.updateFirstName = '';
    //this.accountDetails.updateLastName = '';
    jQuery("#nameChange").slideToggle();
  }
   toggleEmailSection (): any{
     //this.accountDetails.updateNewEmail = '';
     this.showErrorMessageEmail = false;
    jQuery("#emailChange").slideToggle();
  }
   togglePhoneSection (): any{
   // this.accountDetails.updateNewPhone = '';
    jQuery("#phoneChange").slideToggle();
   }



  //jQuery("#firstNameDiv").removeClass("hasError");
  setFocusForElement(id: string){
    jQuery("#"+id).focus();   
  }
  
}