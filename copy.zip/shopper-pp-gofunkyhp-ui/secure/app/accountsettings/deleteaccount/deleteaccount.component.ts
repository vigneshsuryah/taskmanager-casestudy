import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/kytpp-service/index';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'kytpp-deleteaccount',
  templateUrl: 'deleteaccount.component.html'
})
export class DeleteAccountComponent implements OnInit {

  screenLoader: boolean;
  inputParam: any = '';
  errorMessage: string = "";
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.screenLoader = false;
  }

  cancelToMyAccount(){
    this.router.navigate(['/myAccount']);
  }

  openDeleteConfirmPopup(){
    jQuery("#deleteConfirmPopupDataTarget").click();
  }

  confirmDeleteAccount(){
    this.screenLoader = true;
     this.inputParam = {
       "userName":this.currentUser.username,
       "dn":this.currentUser.userDn
    }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.deleteUser(this.inputParam).subscribe(
      (data: any) => {
        this.soaServiceList.consoleLog(data);
          this.screenLoader = false;
          if(data !== undefined && data.deleteUserStatus){
               window.location.href='/sgofundkyhp/logout.html'; 
          }else{
             //this.router.navigate(['/technicalError']);
             this.errorMessage = "Hmmm...There was a problem with deleting your account. One or more of the automatic payments set up are using this payment method, so it can't be deleted. Please try again later.";
             document.getElementById('deleteAccountErrorModalOpener').click();
          }
      
    },
    (err: any) => {
           this.screenLoader = false;
           this.errorMessage = "Hmmm...There was a problem with deleting your account. Please try again later.";
            document.getElementById('deleteAccountErrorModalOpener').click();
           //this.router.navigate(['/technicalError']);
      } 
    );
  }

  closeDeleteAccountErrorPopup(){
    document.getElementById('deleteAccountErrorModalOpener').click();
    this.router.navigate(['']); 
   }

}