import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DeleteAccountComponent } from './deleteaccount.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'deleteAccount', component: DeleteAccountComponent }
    ])
  ],
  exports: [RouterModule]
})
export class DeleteAccountRoutingModule { }
