import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UpdateEmailComponent } from './updateemail.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'updateEmail', component: UpdateEmailComponent }
    ])
  ],
  exports: [RouterModule]
})
export class UpdateEmailRoutingModule { }
