import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { soaServiceList } from '../shared/kytpp-service/index';
import { AuthenticationService } from '../shared/kytpp-service/index';

import { AccountSettingsModule } from './accountsettings.module';
import { ChangePasswordRoutingModule } from './changepassword/changepassword-routing.module';
import { ChangePasswordModule } from './changepassword/changepassword.module';
import { UpdateEmailRoutingModule } from './updateemail/updateemail-routing.module';
import { UpdateEmailModule } from './updateemail/updateemail.module';
import { UpdatePhonenoRoutingModule } from './updatephoneno/updatephoneno-routing.module';
import { UpdatePhonenoModule } from './updatephoneno/updatephoneno.module';
import { UpdateOrgrepRoutingModule } from './updateorgrep/updateorgrep-routing.module';
import { UpdateOrgrepModule } from './updateorgrep/updateorgrep.module';
import { DeleteAccountRoutingModule } from './deleteaccount/deleteaccount-routing.module';
import { DeleteAccountModule } from './deleteaccount/deleteaccount.module';

import { Observable } from 'rxjs/Observable';

import { User } from '../shared/models/user';

import { AccountSettingsComponent } from './accountsettings.component';
import { TechnicalErrorComponent } from '../commonutils/technicalerror/technicalerror.component';
import { ChangePasswordComponent } from './changepassword/changepassword.component';

export function main() {
  
  let actualRes : any;
  actualRes = {
      "errorMessage": '',
      "user": {
        "iamGuid": '',
        "emailAddress": '',
        "orgName": '',
        "firstName": '',
        "lastName": '',
        "phoneNumber": ''
      }
  };
  
  describe('AccountSettings component', () => {
    let config: Route[] = [
      { path: 'myAccount', component: AccountSettingsComponent },
      { path: 'technicalError', component: TechnicalErrorComponent },
      { path: 'changePassword', component: ChangePasswordComponent }
    ];

    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, AccountSettingsModule, ChangePasswordModule,ChangePasswordRoutingModule, 
                  UpdateEmailModule,UpdateEmailRoutingModule, UpdatePhonenoModule,UpdatePhonenoRoutingModule, UpdateOrgrepModule,
                  UpdateOrgrepRoutingModule, DeleteAccountModule,DeleteAccountRoutingModule, RouterTestingModule],
        declarations: [AccountSettingsTestComponent],
        providers: [
          soaServiceList,
          AuthenticationService,
          User,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

   it('accountsettings should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(AccountSettingsTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));


      it('accountsettings searchUser success',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            
            
            let soaService = TestBed.get(soaServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
                         
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let fixture = TestBed.createComponent(AccountSettingsTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            expect(instance.screenLoader).toBe(false);
            
          });

      }));



      it('accountsettings searchUser - no data',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            
            
            let soaService = TestBed.get(soaServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
                         
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let fixture = TestBed.createComponent(AccountSettingsTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            expect(instance.screenLoader).toBe(false);
            
          });

      }));

   
      
  });
}

@Component({
  selector: 'test-cmp',
  template: '<kytpp-accountsettings></kytpp-accountsettings>'
})
class AccountSettingsTestComponent { }
