import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Router } from '@angular/router';
import { UpdateOrgrepComponent } from './updateorgrep.component';
import { CommonutilsModule } from '../../commonutils/commonutils.module';
import { soaServiceList } from '../../shared/kytpp-service/index';
import { User } from '../../shared/models/user';

@NgModule({
  imports: [CommonModule,CommonutilsModule.forRoot()],
  declarations: [UpdateOrgrepComponent],
  exports: [UpdateOrgrepComponent],
  providers:[soaServiceList,User]  
})
export class UpdateOrgrepModule {}