import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountSettingsComponent } from './accountsettings.component';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { AccountSettingsRoutingModule } from './accountsettings-routing.module';
import { DeleteAccountRoutingModule } from './deleteaccount/deleteaccount-routing.module';
import { DeleteAccountModule } from './deleteaccount/deleteaccount.module';
import { FAQRoutingModule } from './faq/faq-routing.module';
import { FAQModule } from './faq/faq.module';
import { soaServiceList } from '../shared/kytpp-service/index';
import { User } from '../shared/models/user';

@NgModule({
  imports: [CommonModule, AccountSettingsRoutingModule, 
  DeleteAccountModule,DeleteAccountRoutingModule,
  FAQModule,FAQRoutingModule, 
  CommonutilsModule.forRoot()],
  declarations: [AccountSettingsComponent],
  providers:[soaServiceList, User],
  exports: [AccountSettingsComponent]
})
export class AccountSettingsModule { }
