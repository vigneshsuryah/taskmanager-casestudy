export const environment = {
  production: true,
  API:'https://shop.dev2.va.anthem.com/paymentgateway/',
  NodeAPI: 'https://va10dlvwbs339.wellpoint.com:7576/payments/',
  loggingflag: false,
  environment: 'DEV'
};
