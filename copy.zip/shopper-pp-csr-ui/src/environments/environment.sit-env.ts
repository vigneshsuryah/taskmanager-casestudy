export const environment = {
  production: true,
  API:'https://payment.sit2.va.anthem.com/paymentgateway/',
  NodeAPI: 'https://va10tlvwbs490.wellpoint.com:7576/payments/',
  loggingflag: false,
  environment: 'SIT'
};
