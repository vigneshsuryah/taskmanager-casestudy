export const environment = {
  production: true,
  API:'https://payment.uat2.va.anthem.com/paymentgateway/',
  NodeAPI: 'https://va10tlvwbs491.wellpoint.com:7576/payments/',
  loggingflag: false,
  environment: 'UAT'
};
