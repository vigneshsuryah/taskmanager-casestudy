export const environment = {
  production: true,
  API:'https://payment.anthem.com/paymentgateway/',
  NodeAPI: 'https://prod-phub-njs-internal.anthem.com/payments/',
  loggingflag: false,
  environment: 'PROD'
};
