import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { AutoPaymentModel } from '../../../../shared/models/indvmemberpay/autopayment.model';
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indveditautopayment',
  templateUrl: 'indveditautopayment.component.html',
  styleUrls: ['indveditautopayment.component.css']
})
export class IndvEditAutoPaymentComponent implements OnInit {

  autoPaymentModel = new AutoPaymentModel();
  responseLength: any = 0;
  hcidEntered: string = '';
  selectedProductId: string = '';
  paymentType: string = '';
  tokenId: string = '';
  selectedTokenId: string = '';
  emailAddressTxt: string = '';
  errorMessage: string = '';
  brand: string = '';
  brandText: string = '';
  contractIndicator: string = null;
  screenLoader: boolean;
  techerror: boolean = false;
  isCC: boolean = false;
  isBA: boolean = false;
  emailAddressChecked: boolean = false;
  updatedFlag: boolean = true;
  automaticPayments: any = [];
  paymentMethods: any = [];
  ccList: any = [];
  bnkList: any = [];
  paymentMethodsListComposed: any = [];
  content : any = {};
  selectedBill: any = {};
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  ccResponse: any = {};
  baResponse: any = {};
  
  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService){
    if (this.currentUser.userRole === undefined) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.content = content;
    if(null !== this.mwpCsrHttpService.dayOfMonth && undefined !== this.mwpCsrHttpService.dayOfMonth){
      this.autoPaymentModel.dayOfMonth = '0'+this.mwpCsrHttpService.dayOfMonth.substring(0,1);
    }
    jQuery("#editSummaryBillChecked").find(".pcOption").prop('disabled',true);
    jQuery("#editSummaryBillChecked").find(".pcLabel").addClass('pcOptionDisabled');
    this.hcidEntered = this.mwpCsrHttpService.hcid;
    this.automaticPayments = this.mwpCsrHttpService.automaticPayments;
    this.selectedProductId = this.mwpCsrHttpService.selectProductId;
     
    for (let automaticPayment of this.automaticPayments) {
      if (automaticPayment.productId == this.selectedProductId) {
        for (let linkedBill of automaticPayment.memberDetails.linkedBills) {
          for (let billAccount of linkedBill.billAccounts) {
            if (this.selectedProductId == billAccount.subGroupId) {
              this.contractIndicator = linkedBill.contractIndicators;
              let hcidOrSummaryNo = linkedBill.contractIndicators === 'SUMMARY_BILLED_MEMBER' ? linkedBill.groupId : this.hcidEntered;
              this.selectedBill = {
                "subGroupName": billAccount.subGroupName,
                "productId": billAccount.subGroupId,
                "hcidOrSummaryNo": hcidOrSummaryNo,
                "planName": billAccount.planName,
                "subscriberName": automaticPayment.memberDetails.firstName + " " + automaticPayment.memberDetails.lastName,
                "billDate": billAccount.billDate,
                "minDue": billAccount.minDue,
                "totalDue": billAccount.totalDue,
                "dueDate": billAccount.dueDate
              }
              break;
            }
          }
        }
        this.selectedTokenId = null !== automaticPayment.paymentMethods ? automaticPayment.paymentMethods.tokenId : null;
        this.brand = automaticPayment.memberDetails.brand;
      }
    }
    this.getPaymentMethods(this.selectedTokenId);
    this.getBrandName(this.brand);
  }

 getPaymentMethods(selectedTokenId: string){
    this.screenLoader = true;
    this.paymentMethods = [];
    this.paymentMethodsListComposed = [];
    var inputParam = {
       "hcids" : [
         this.hcidEntered
        ]
    }
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'v2/getPaymentMethods').subscribe((data:any) => {
    if(null !== data && undefined !== data && null !== data.memberpayPaymentMethods && undefined !== data.memberpayPaymentMethods && 
        data.memberpayPaymentMethods.length > 0){
          this.paymentMethods = data.memberpayPaymentMethods;
          this.ccList = [];
          this.bnkList = [];
          for(var i=0; i<=this.paymentMethods.length-1;i++){
              if (this.paymentMethods[i].paymentType === 'CREDITDEBITCARD'){
                this.ccList.push(this.paymentMethods[i]);
              }
              if (this.paymentMethods[i].paymentType === 'BANKINGACCOUNT') {
                this.bnkList.push(this.paymentMethods[i]);
              }
          }

          if (this.ccList.length === 0 && this.bnkList.length === 0) {
            this.responseLength = 0;
          } else {
            if (this.ccList.length > 0) {
              this.responseLength += this.ccList.length;
              for(var i = 0; i <= this.ccList.length-1; i++){
                var labelString = '';
                this.creditCardBankAccNbrMap[this.ccList[i].tokenId] = this.ccList[i].creditCardNumber;
                this.paymentTypeMap[this.ccList[i].tokenId] = 'CreditDebitCard';

                if(this.ccList[i].bankAccountType == "MASTERCARD"){
                  labelString = "Mastercard ending in ";
                }else if(this.ccList[i].bankAccountType == "VISA"){
                  labelString = "VISA ending in ";
                }
                labelString = labelString + this.ccList[i].confirmAccountNo.slice(-4) + (("" !== this.ccList[i].accNickName && null !== this.ccList[i].accNickName) ? (' - ' + this.ccList[i].accNickName) : '');
                var tempCCItem = {
                  label : labelString,
                  value : this.ccList[i].tokenId
                }
                this.paymentMethodsListComposed.push(tempCCItem);
                }
            }

            if (this.bnkList.length > 0) {
              this.responseLength += this.bnkList.length;
              for(var i = 0; i <= this.bnkList.length-1; i++){
                var labelString = '';
                this.creditCardBankAccNbrMap[this.bnkList[i].tokenId] = this.bnkList[i].bankAccountNumber;
                this.paymentTypeMap[this.bnkList[i].tokenId] = 'Banking';
                this.bankAccountTypeMap[this.bnkList[i].tokenId] = this.bnkList[i].bankAccountType;

                if(this.bnkList[i].bankAccountType == "BUSSAVINGS" || this.bnkList[i].bankAccountType == "PERSONALSAVINGS"){
                  labelString = "Savings ending in ";
                }else if(this.bnkList[i].bankAccountType == "BUSCHECKING" || this.bnkList[i].bankAccountType == "PERSONALCHECKING"){
                  labelString = "Checking ending in ";
                }
                labelString = labelString + this.bnkList[i].confirmAccountNo.slice(-4) + (("" !== this.bnkList[i].accNickName && null !== this.bnkList[i].accNickName) ? (' - ' + this.bnkList[i].accNickName) : '');
                var tempBnkItem = {
                  label : labelString,
                  value : this.bnkList[i].tokenId
                }
                this.tokenId = this.bnkList[i].tokenId; 
                this.paymentMethodsListComposed.push(tempBnkItem);
              }            
            }
          }
          if(null !== selectedTokenId && undefined !== selectedTokenId){
            this.selectedPaymentMethod(selectedTokenId);
            this.autoPaymentModel.paymentMethod = selectedTokenId;    
          }
       } else {
         var tempItem = {
            label : 'No Saved payment method',
            value : ''
         }
         this.paymentMethodsListComposed.push(tempItem);
       }
       this.screenLoader = false;
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
      this.content.paymentMethodsList = this.paymentMethodsListComposed;
    }

    selectedPaymentMethod(selectedPayment: string){
     if(this.paymentTypeMap[selectedPayment] === 'CreditDebitCard'){
       this.isCC = true;
       this.isBA = false;
       for(let creditCardDetails of this.ccList){
         if(creditCardDetails.tokenId === selectedPayment){
            this.ccResponse = creditCardDetails;
            break;
         }
       }
       this.paymentType = "CREDITDEBITCARD"; 
     } else if(this.paymentTypeMap[selectedPayment] === 'Banking'){
       this.isBA = true;
       this.isCC = false;
        for(let bankAccountDetails of this.bnkList){
           if(bankAccountDetails.tokenId === selectedPayment){
            this.baResponse = bankAccountDetails;
            break;
         }
        }
        this.paymentType = "BANKINGACCOUNT";
     }
   }

   editAutoPaymentMethod (autoPaymentModel: any){    
    let recurringList = [];
    let recurringPaymentDetails: any = {};
    for (let automaticPayment of this.automaticPayments) {
      if (automaticPayment.productId == this.selectedProductId) {
        for (let linkedBill of automaticPayment.memberDetails.linkedBills) {
          for (let billAccount of linkedBill.billAccounts) {
            if (this.selectedProductId == billAccount.subGroupId) {
              recurringPaymentDetails.productId = this.selectedProductId;
              let paymentMethods = {
                "paymentType": this.paymentType,
                "bankAccountType": this.paymentType === 'BANKINGACCOUNT' ? this.baResponse.bankAccountType : this.ccResponse.bankAccountType,
                "tokenId": autoPaymentModel.paymentMethod
              }
              recurringPaymentDetails.paymentMethods = paymentMethods;
              let billAccounts = [];
              let billAccDet = {
                "paidToDate": billAccount.paidToDate,
                "subGroupId": billAccount.subGroupId
              }
              billAccounts.push(billAccDet);
              let linkedBills = [];
              let linkedBillDet = {
                "linkRelationship": linkedBill.linkRelationship,
                "contractIndicators": (null !== this.contractIndicator && undefined !== this.contractIndicator && this.contractIndicator === 'SUMMARY_BILLED_MEMBER') ? 'SUMMARY_BILLED_MEMBER' : null,
                "personDetails": {
                  "hcid": this.hcidEntered,
                  "brand": automaticPayment.memberDetails.brand,
                  "summaryBillNo": (null !== this.contractIndicator && undefined !== this.contractIndicator && this.contractIndicator === 'SUMMARY_BILLED_MEMBER') ? linkedBill.groupId : null
                },
                "billAccounts": billAccounts
              }
              linkedBills.push(linkedBillDet);
              var memberDetails = {
                "hcid": this.hcidEntered,
                "linkedBills": linkedBills
              }
              recurringPaymentDetails.memberDetails = memberDetails;
              recurringPaymentDetails.payDate = this.formatPayDate(autoPaymentModel.dayOfMonth);
              recurringPaymentDetails.createdBy = this.currentUser.username;
              recurringPaymentDetails.authMode = autoPaymentModel.authorization;
              if (this.emailAddressChecked && null != this.emailAddressTxt && this.emailAddressTxt !== '') {
                recurringPaymentDetails.emailId = this.emailAddressTxt;
              }
              recurringList.push(recurringPaymentDetails);
            }
          }
        }
      }
    }
    var inputParam = {
      "hcid": this.hcidEntered,
      "action": "UPD",
      "recurringPaymentDetails": recurringList
    }
    this.screenLoader = true;
    this.automaticPayments = [];
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'updateRecurringPayment').subscribe((data: any) => {

      if (null != data.recurringPaymentDetails && undefined !== data.recurringPaymentDetails && data.recurringPaymentDetails.length > 0) {
        for (let autoPay of data.recurringPaymentDetails) {
          if (autoPay.productId == this.selectedProductId) {
            this.updatedFlag = autoPay.confirmStatus == 'Failed' ? false : true;
            this.errorMessage = autoPay.errorMessage;
          }
        }
      }
      if (this.updatedFlag) {
        this.screenLoader = false;
        jQuery("#confirmationModalOpener").click();
      }
      else {
        this.screenLoader = false;
        return;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
   }

   getBrandName(brand: string){
      if(brand === 'ABC'){
        this.brandText = 'Anthem BlueCross';
      } else if(brand === 'ABCBS'){
        this.brandText = 'Anthem Blue Cross and Blue Shield';
      } else if(brand === 'BCBSGA'){
        this.brandText = 'BlueCross BlueShield of Georgia';
      } else if(brand === 'EBCBS'){
        this.brandText = 'Empire BlueCross BlueShield';
      } else if(brand === 'EBC'){
        this.brandText = 'Empire BlueCross';
      }
   }

   formatPayDate(dayOfMonth: string){
    var payDay;
     if (dayOfMonth == "01") {
           payDay = "1st"; 
        } else if (dayOfMonth == "02") {
           payDay = "2nd";
        } else if (dayOfMonth == "03") {
           payDay = "3rd";
        } else {
           payDay = dayOfMonth.slice(-1) + "th";
        }
        this.mwpCsrHttpService.dayOfMonth = payDay;
        return payDay;
   }

   redirectToHome(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   redirectToAutoPay(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery('#confirmationModalOpener').click();
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   formatAccountType(accountType: string){
     if(accountType === 'BUSINESSSAVINGS'){
       return accountType = 'Business Savings';
     }else if(accountType === 'PERSONALSAVINGS'){
       return accountType = 'Personal Savings';
     }else if(accountType === 'BUSINESSCHECKING'){
       return accountType = 'Business Checking';
     }else if(accountType === 'PERSONALCHECKING'){
       return accountType = 'Personal Checking';
     }else if(accountType === 'MASTERCARD'){
        return accountType = 'Master Card';
     }else if(accountType === 'VISA'){
        return accountType = 'VISA';
     }
   }

}
