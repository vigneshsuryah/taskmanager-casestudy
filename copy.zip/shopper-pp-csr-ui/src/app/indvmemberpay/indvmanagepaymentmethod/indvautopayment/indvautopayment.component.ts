import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery: any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { MwpCsrHttpService } from '../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvautopayment',
  templateUrl: 'indvautopayment.component.html',
  styleUrls: ['indvautopayment.component.css']
})
export class IndvAutoPaymentComponent implements OnInit {

  content: any = {};
  inputParam: any = {};
  selectedMethod: string;
  hcidEntered: string = '';
  screenLoader: boolean = false;
  techerror: boolean = false;
  automaticPayments: any = [];
  recurringSubGroupIdList: any = [];
  hasPaymentMethods: boolean;
  hasRecurring: boolean;
  hasProducts: boolean;

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService) {
    if (this.currentUser.userRole === undefined) {
      this.router.navigate(['']);
    }
    this.hcidEntered = mwpCsrHttpService.hcid;
  }

  ngOnInit() {
    this.screenLoader = false;
    this.inputParam = {
      "hcids": [
        this.hcidEntered
      ]
    }
    this.selectedMethod = 'MAM';
    this.mwpCsrHttpService.selectedMethod = 'MAM';
    this.screenLoader = true;
    this.automaticPayments = [];
    this.recurringSubGroupIdList = [];
    this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getRecurringPaymentDetails').subscribe((data: any) => {
      if (null !== data && undefined !== data && null !== data.memberpayRecurringPaymentsMap && undefined !== data.memberpayRecurringPaymentsMap &&
        Object.keys(data.memberpayRecurringPaymentsMap).length > 0) {
        this.automaticPayments = data.memberpayRecurringPaymentsMap[this.hcidEntered];
        this.mwpCsrHttpService.automaticPayments = this.automaticPayments;
        if(this.automaticPayments.length > 0){
          this.hasRecurring = true;
          for(let memberpayRecurringPayments of this.automaticPayments){
            if(memberpayRecurringPayments.recurringPayStatus.toUpperCase() === 'ACTIVE'){
              this.recurringSubGroupIdList.push(memberpayRecurringPayments.productId);
            }
          }
        } else {
          this.hasRecurring = false;
        }
        this.mwpCsrHttpService.recurringSubGroupIdList = this.recurringSubGroupIdList;
      } 

      this.getPaymentMethods();

    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }

  getSummary(){
    this.screenLoader = true;
    let getSummaryResponseList = [];
    let subGroupIdList = [];
    let linkedBillsList = [];
    this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getSummary').subscribe((data:any) => {
      if(undefined !== data && null !== data && undefined !== data.memberpayMember && null !== data.memberpayMember){
        getSummaryResponseList = data.memberpayMember.linkedBills;
        if(getSummaryResponseList.length > 0){
          for(let linkedBills of getSummaryResponseList){
            let billAccountsList = linkedBills.billAccounts;
            if(billAccountsList.length > 0){
              for(let billAccounts of billAccountsList){
                if(this.recurringSubGroupIdList.length > 0){
                  if(this.recurringSubGroupIdList.indexOf(billAccounts.subGroupId) < 0){
                    subGroupIdList.push(billAccounts.subGroupId);
                  }
                } else {
                  subGroupIdList.push(billAccounts.subGroupId);
                }
              }
              if(subGroupIdList.length > 0){
                 for(let billAccounts of billAccountsList){
                   for(let subGroupIds of subGroupIdList){
                     if(subGroupIds === billAccounts.subGroupId){
                        billAccounts.summaryOrHCID = null != linkedBills.personDetails.summaryBillNo ? linkedBills.personDetails.summaryBillNo : linkedBills.personDetails.hcid;
                        linkedBillsList.push(billAccounts);
                     }
                   }
                  }
                }
              }
            } 
          
          if(linkedBillsList.length === 0){
            this.hasProducts = false;
          } else{ 
            this.hasProducts = true;
          }
          this.screenLoader = false; 
        }  
      }
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }

  getPaymentMethods(){
    this.screenLoader = true;
    this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getPaymentMethods').subscribe((data:any) => {
      if(null !== data && undefined !== data  && null !== data.memberpayPaymentMethods && undefined !== data.memberpayPaymentMethods){
          if(data.memberpayPaymentMethods.length > 0){
            this.hasPaymentMethods = true;
          } else {
            this.hasPaymentMethods = false;
          }
      }
      this.getSummary();             
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }
  
  addAutoPayments() {
    this.router.navigate(['/memberpay/addnewautopayment']);
  }

  delete(productId) {
    this.mwpCsrHttpService.selectProductId = productId;
    this.router.navigate(['/memberpay/deleteautopayment']);
  }

  edit(automaticPayment: any) {
    this.mwpCsrHttpService.dayOfMonth = automaticPayment.payDate;
    this.mwpCsrHttpService.selectProductId = automaticPayment.productId;
    this.router.navigate(['/memberpay/editautopayment']);
  }

  redirectToHome(selected: string) {
    this.mwpCsrHttpService.selectedMethod = selected;
    this.router.navigate(['/memberpay/paymentmethod']);
  }

  changePaymentMethod(selectedMethod: string) {
    if (selectedMethod === 'MPM') {
      this.selectedMethod = 'MPM';
    } else if (selectedMethod === 'MAM') {
      this.selectedMethod = 'MAM';
    } else if (selectedMethod === 'EM') {
      this.selectedMethod = 'EM';
    }
  }

  redirectToMemberSearch() {
      this.router.navigate(['/memberpay/home']);
  }

}
