import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute  } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'csr-technicaleerror',
  templateUrl: 'technicalerror.component.html',
  styleUrls: ['technicalerror.component.css']
})
export class TechnicalErrorComponent implements OnInit {

  errorMsg: string;
  url: string;

  constructor(public router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.queryParams
      .filter(params => params.errorMsg)
      .subscribe(params => {
        this.url = params.url;
        this.errorMsg = params.errorMsg;
    });
  }

  backToSearch(){
      this.router.navigate([this.url]);
  }

 }



