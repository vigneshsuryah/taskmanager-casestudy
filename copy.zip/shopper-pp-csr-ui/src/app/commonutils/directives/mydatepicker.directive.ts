import { Directive, ElementRef, OnInit, Output, EventEmitter, Input } from '@angular/core';
declare var jQuery:any;
declare var $:any;

@Directive({
  selector: '[mydatepicker]'
})
export class MydatepickerDirective implements OnInit {
  @Output() dateChange = new EventEmitter();
  @Input() dateOption;
  datepicker;

  constructor(public el: ElementRef) { }

  ngOnInit() {
    if (this.dateOption) {
      this.datepicker = $(this.el.nativeElement).datepicker(this.dateOption);
    } else {
      this.datepicker = $(this.el.nativeElement).datepicker({
        format: 'mm/dd/yyyy',
        autoclose: true
      });
    }
    this.datepicker.on('change', (event) => {
      if (event && event.target && event.target.value) {
        this.dateChange.next(event.target.value);
      }
    });

  }

}
