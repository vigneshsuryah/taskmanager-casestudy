import { Validator, AbstractControl, NG_VALIDATORS } from '@angular/forms';
import { Directive } from '@angular/core';

@Directive({
  selector: '[payIdValidator]',
  providers: [
      { provide: NG_VALIDATORS, useExisting: PayIdValidator, multi: true }
  ]
})
export class PayIdValidator implements Validator {

  validate(c: AbstractControl): {[key: string]: any} {
    if (c !== undefined && c.value && c.value !== '') {
      const val: string = c.value;
      if (val.length > 21 && val.length !== 36) {
        return { 'paydid': {value: val}};
      }
    }
    return null;
  }
}
