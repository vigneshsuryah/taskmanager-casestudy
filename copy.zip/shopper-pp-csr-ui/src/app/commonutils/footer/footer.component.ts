import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, EventEmitter, Input, SimpleChange, OnChanges,DoCheck } from '@angular/core';
import { content } from '../../shared/constants/constants';
declare var jQuery:any;

/**
 * This class represents the toolbar component.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-footer',
  templateUrl: 'footer.component.html',
  styleUrls: ['footer.component.css']
})
export class FooterComponent implements OnInit { 

  content : any = {};
  modalTitle : string;
  modalBody : string;
  modalPara1 : string;
  modalPara2 : string;
  modalPara3 : string;
  modalBtn : string;
  langType :any ={};

  ngOnInit() {
    this.content = content;
    this.langType = {
      "langSelected":"default"
    };
  }

   languageTypeDropdown(){ 
     setTimeout(()=>{  
        let langTypeTemp = this.langType.langSelected;
        for(let lang of this.content.footerLangList){
          if(langTypeTemp === "3" && langTypeTemp === lang.value){
            jQuery("#language3PopupModalOpener").click(); 
          }
          if(langTypeTemp === "5" && langTypeTemp === lang.value){
            this.modalTitle = lang.modalheading;
            this.modalBody = lang.modalbody;
            this.modalPara1 = lang.modalpara1;
            this.modalPara2 = lang.modalpara2;
            this.modalPara3 = lang.modalpara3;
            this.modalBtn = lang.modalbutton;
            jQuery("#language5PopupModalOpener").click(); 
          }
          if(langTypeTemp === "29" && langTypeTemp === lang.value){
            this.modalTitle = lang.modalheading;
            this.modalBody = lang.modalbody;
            this.modalPara1 = lang.modalpara1;
            this.modalPara2 = lang.modalpara2;
            this.modalBtn = lang.modalbutton;
            jQuery("#language29PopupModalOpener").click(); 
          }
          if((langTypeTemp === "40" || langTypeTemp === "41" || langTypeTemp === "42" || langTypeTemp === "43") 
              && langTypeTemp === lang.value){
            this.modalTitle = lang.modalheading;
            this.modalBody = lang.modalbody;
            this.modalPara1 = lang.modalpara1;
            this.modalPara2 = lang.modalpara2;
            this.modalBtn = lang.modalbutton;
            jQuery("#languageAbv40PopupModalOpener").click(); 
          }
          if(langTypeTemp === "47" && langTypeTemp === lang.value){
            jQuery("#language47PopupModalOpener").click(); 
          }
          if(langTypeTemp != "0" && langTypeTemp != "3" && langTypeTemp != "5" && langTypeTemp != "29" 
              && langTypeTemp != "40" && langTypeTemp != "41" && langTypeTemp != "42" 
              && langTypeTemp != "43" && langTypeTemp != "47" && langTypeTemp === lang.value){
            this.modalTitle = lang.modalheading;
            this.modalBody = lang.modalbody;
            this.modalBtn = lang.modalbutton;
            jQuery("#languagePopupModalOpener").click(); 
          }
        }
        
     },100);
   }

   onCloseLanguagePopup(){
     this.langType.langSelected = "";
   }

}

