import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../shared/models/user';
import { AuthenticationService } from '../shared/csr-service/authentication.service';
declare var jQuery:any;

@Component({
  selector: 'csr-apploading',
  templateUrl: './apploading.component.html',
  styleUrls: ['./apploading.component.css']
})
export class AppLoadingComponent implements OnInit{

    constructor (public router : Router, private authenticationService: AuthenticationService){

    }

    ngOnInit(){
      jQuery(".nav-menu-item").hide();
      jQuery("#menuBarId").hide();
      setTimeout(()=>{
        this.afterAppLoadingGenerateToken();
      },6000);
    }

    afterAppLoadingGenerateToken(){

        this.authenticationService.userDetails.subscribe((data: User) => {

          // set logged in user name in the header
          if (data.firstName || data.lastName) {
            jQuery("#headerUserName").text(data.firstName + " " + data.lastName);
          }

          // assign the actual user roles to the local object
          var userRoles = data.userRole;
         
          var rules = data.rules;
         
          console.log(JSON.stringify(data));
          // userRoles.push('REPORTSROLE'); // hard coded - to remove
          
            // folder indvmemberpay
            // ISG Individual Payments - One Time Payment [PPORTCSRSUBMIT], Manage Payment Methods & Manage Automatic Payments [PPORTCSR]
            if(userRoles.indexOf('PPORTCSR') > -1 || userRoles.indexOf('PPORTCSRSUBMIT') > -1){
              jQuery("#memberCsrPaymentMenuItem").show();
            }

            // folder gbdpay
            // GBD Medicaid Payments - One Time Payment [GBDCSRSUBMIT, KYHCSRSUBMIT], Manage Payment Methods & Manage Automatic Payments [GBDPPORTCSR, KYHPPORTCSR]
            if(userRoles.indexOf('KYHPPORTCSR') > -1 || userRoles.indexOf('GBDPPORTCSR') > -1 || userRoles.indexOf('GBDCSRSUBMIT') > -1 || userRoles.indexOf('KYHCSRSUBMIT') > -1){
              jQuery("#medicaidRecurringPaymentMenuItem").show();
            }

            // folder ipp for CSRPAYMENT
            // folder medicaidpay for HIPCSRPAYMENT and KYHCSRPAYMENT
            // CSR Initial Payment
            if(userRoles.indexOf('HIPCSRPAYMENT') > -1 || userRoles.indexOf('KYHCSRPAYMENT') > -1 || 
               userRoles.indexOf('CSRPAYMENT') > -1){
              jQuery("#medicaidInitialPaymentMenuItem").show();
              if(userRoles.indexOf('CSRPAYMENT') > -1){
                jQuery(".class-CSRPAYMENT").show();
              }
              if(userRoles.indexOf('HIPCSRPAYMENT') > -1){
                jQuery(".class-HIPCSRPAYMENT").show();
              }
              if(userRoles.indexOf('KYHCSRPAYMENT') > -1){
                jQuery(".class-KYHCSRPAYMENT").show();
              }
            }

            // folder gbdmsma
            // GBD MSMA Payments - One Time Payment [MSCSRSUBMIT, MACSRSUBMIT], Manage Payment Methods & Manage Automatic Payments [MSPPORTCSR, MAPPORTCSR]
            if(userRoles.indexOf('MSPPORTCSR') > -1 || userRoles.indexOf('MAPPORTCSR') > -1 || userRoles.indexOf('MSCSRSUBMIT') > -1 || userRoles.indexOf('MACSRSUBMIT') > -1){
              jQuery("#msmaPaymentMenuItem").show();
            }

            // folder wgs
            // WGS Individually Billed Payments - One Time Payment [WGSCSRSUBMIT], Manage Payment Methods & Manage Automatic Payments [WGSCSRPAYMENT]
            if(userRoles.indexOf('WGSCSRPAYMENT') > -1 || userRoles.indexOf('WGSCSRSUBMIT') > -1){
              jQuery("#wgsMenuItem").show();
            }

            // folder dashboard
            // Dashboard
            if(userRoles.indexOf('PPCSRADMIN') > -1){
              jQuery("#dashBoardMenuItem").show();
            }

            // folder superuser
            // Super User
            if(undefined !== rules && null !== rules && rules.indexOf('SUPERADMIN') > -1){
              jQuery("#superUserMenuItem").show();
            }

            // folder refund
            // Refund
            if(userRoles.indexOf('REFUNDSADMIN') > -1){
              jQuery("#refundMenuItem").show();
            }

       
            // folder reports
            // Reports
            if(userRoles.indexOf('ADHOCREPORT') > -1){           
              jQuery("#reportsMenuItem").show(); 
            }


            // folder research
            // Research
            if(userRoles.indexOf('REPORTSADMIN') > -1){
              jQuery("#researchMenuItem").show();   
                         
            }


            // folder feedback
            // Feedback
            jQuery("#feedbackMenuItem").show();

            jQuery("#menuBarId").show();
            
            // to show root home page
            this.router.navigate(['/roothome']);

        });
    }

    includes(container, value) {
      var returnValue = false;
      var pos = container.indexOf(value);
      if (pos >= 0) {
          returnValue = true;
      }
      return returnValue;
    }
}

