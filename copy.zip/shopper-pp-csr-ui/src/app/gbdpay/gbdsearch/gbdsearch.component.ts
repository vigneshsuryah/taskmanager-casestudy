import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import { GbdPayMethodService } from './gbdmanagepayment/gbdpaymethod.service';
import { Kyhpportcsr } from '../../shared/models/gbdpay/kyhpportcsr';
import { KyhpportcsrService } from '../../shared/csr-service/kyhpportcsr-service';
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: "csr-gbdsearch",
  templateUrl: "gbdsearch.component.html",
  styleUrls: ["gbdsearch.component.css"]
})
export class GBDSearchComponent {
  content: any = {};
  hcid: string;
  screenLoader: boolean = false;
  responseCode: string;
  showContent: string;
  isHOH: boolean = true;
  isExactLength: boolean = true;
  isValidHcid: boolean = true;
  hasHcid: boolean = true;
  showError :boolean = false;
  showErrorContent :string = '';
  hasKYHCSRSUBMIT: boolean = false;
  hasKYHPPORTCSR: boolean = false;

  gbdSearchModel = {
    hcid: ""
  };

  constructor(
    public router: Router,
    private gbdPayMethodService: GbdPayMethodService,
    public kyhpportcsr: Kyhpportcsr,
    public kyhpportcsrService: KyhpportcsrService,
    private currentUser: User
  ) {
    if (this.currentUser.userRole === undefined) {
      this.router.navigate([""]);
    }
    if (this.currentUser && this.currentUser.userRole) {
      if (this.currentUser.userRole.indexOf("KYHCSRSUBMIT") > -1) {
        this.hasKYHCSRSUBMIT = true;
      }
      if (this.currentUser.userRole.indexOf("KYHPPORTCSR") > -1) {
        this.hasKYHPPORTCSR = true;
      }
    } else {
      this.router.navigate(["/roothome"]);
    }
  }

  validateHcid(hcid: string, selectedApp: string) {
    if (hcid.length == 0) {
      this.isHOH = true;
      this.isValidHcid = true;
      this.hasHcid = false;
      this.isExactLength = true;
    } else if (hcid.length > 9 || hcid.length < 9) {
      this.isHOH = true;    
      this.isValidHcid = true;
      this.hasHcid = true;
      this.isExactLength = false;
    } else {
      this.isValidMember(hcid, selectedApp);
    }
  }

  isValidMember(hcid: string, selectedApp: string) {
    this.screenLoader = true;
    let inputParams = {
      "healthCardId" : hcid
    };

    this.kyhpportcsrService.validateMember(inputParams).subscribe((data: any) => {
        this.screenLoader = false;
        this.responseCode = data.messageCode;

        if(this.responseCode === "0"){
          this.isHOH = true;
          this.isValidHcid = true;
          this.hasHcid = true;
          this.isExactLength = true;
          if(selectedApp === 'PD'){
            this.getPaymentDetails(hcid);
          } else if (selectedApp === 'PH'){
            this.getPaymentHistory(hcid);
          }
        } else if(this.responseCode === "8"){
          this.isHOH = false;
          this.isValidHcid = true;
          this.hasHcid = true;
          this.isExactLength = true;
        } else {
          this.isHOH = false;
          this.isValidHcid = false;
          this.hasHcid = true;
          this.isExactLength = true;
        }
      },
      (err: any) => {
        this.screenLoader = false;
        this.isValidHcid = false;
        this.isHOH = true;
        this.hasHcid = true;
        this.isExactLength = true;
        this.showContent = 'techerror';
      });
    }


  getPaymentDetails(hcid: string) {
    if(this.hasKYHCSRSUBMIT){
      this.gbdPayMethodService.memberPaymentOptions = 'AS';
      this.kyhpportcsrService.gbdAcntSummaryRefresh = true;
    } else if(this.hasKYHPPORTCSR){
      this.gbdPayMethodService.memberPaymentOptions = 'MPM';
    }
    this.gbdPayMethodService.hcid = hcid;
    this.kyhpportcsr.healthCardId = hcid;
    this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
  }

  getPaymentHistory(hcid: string) {
    this.kyhpportcsr.healthCardId = hcid;
    this.router.navigate(["/gbdpay/gbdpaymenthistory"]);
  }
}
