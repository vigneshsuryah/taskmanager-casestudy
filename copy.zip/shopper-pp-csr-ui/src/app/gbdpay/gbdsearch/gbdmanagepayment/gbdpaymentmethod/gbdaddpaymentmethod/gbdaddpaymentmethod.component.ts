import { Component, OnInit, OnDestroy, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../../shared/models/user';
import { content } from '../../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../../shared/models/paymentmethod.model'
import { GbdPayMethodService } from '../../gbdpaymethod.service';
import { PaymentMethod } from '../../../../../shared/models/gbdpay/paymentmethod.model';
import { UpdatePayResponse } from '../../../../../shared/models/gbdpay/updatepayresponse.model';
import { NgModel, FormControl, NgForm } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdaddpaymentmethod',
  templateUrl: 'gbdaddpaymentmethod.component.html',
  styleUrls: ['gbdaddpaymentmethod.component.css']
})
export class GBDAddPaymentMethodComponent implements OnInit {
  @ViewChild('addNewPaymentForm') addForm: NgForm;
  newPay = new PaymentMethod();
  usedNickNames: string[] = [];
  inputReEnterbankAccountNbr = '';
  screenLoader: boolean = false;
  techerror: boolean = false;
  addError = '';
  errorMsg = {
    'invalidCard': 'Please enter the full 16-digit credit card number',
    'invalidExpiry': 'The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.',
    'invalidCardHolderName': 'Please only use letters when entering a name (no numbers or special characters).',
    'invalidAdd1': 'Please enter the address without any special characters',
    'invalidCity': 'Please enter a valid city name (no numbers or special characters).',
    'invalidState': 'Please enter a valid state name (no numbers or special characters).',
    'invalidZip': 'Please enter the correct 5-digit ZIP code',
    'invalidRouting': 'Please enter a valid bank routing number (no letters or special characters and full 9-digits).',
    'invalidBankAct': 'Please enter a valid bank account number',
    'invalidReenterDoesNotMatch': 'Please enter correct account number',
    'invalidBankAccountHolder': 'Please enter a valid account holder name (no numbers or special characters).',
    'invalidNickName': 'Please only use letters when entering a nickname (no numbers or special characters).',
    'duplicateNickName': 'Sorry, you already have a payment method with that nickname in the system.',
    'required': 'Required field',
    'techError': 'Sorry, our system isn\'t working the way it should. Please try again later.'
  };

  paymentMethodModel = {
    'paymentMethod': '',
    'expiryDate': '',
    'nickName': '',
    'accountType': '',
    'bankRoutingNbr': '',
    'bankAccountNbr': '',
    'reEnterbankAccountNbr': '',
    'accountHolderName': '',
    'addressOnAccount': '',
    'address1': '',
    'address2': '',
    'city': '',
    'state': '',
    'zipCode': '',
    'cardNumber':'',
    'cvvCode':'',
    'cardName':''
  }
  content : any ={};
  value: string;

  constructor(public router: Router, public gbdPayMethodService: GbdPayMethodService, private currentUser: User) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    if (this.gbdPayMethodService.hcid === undefined) {
      this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
    }
    setTimeout(() => {
      this.changeAddressOnAccount('SubscriberAddr');
    }, 100);
    this.content = content;
    this.paymentMethodModel.paymentMethod = 'Banking';
    this.value = 'Banking';
    this.usedNickNames = this.gbdPayMethodService.existingNickNames;
  }

   savePaymentMethod () {
    this.screenLoader = true;
    if (this.paymentMethodModel.paymentMethod === 'CreditDebit') {
      const datestr = this.paymentMethodModel.expiryDate.split('/');
      this.newPay.expirationMonth = datestr[0];
      this.newPay.expirationYear = datestr[1];
      this.newPay.bankAccountType = undefined;
      this.newPay.routingNumber = undefined;
      this.newPay.bankAccountNumber = undefined;
    } else {
      this.newPay.creditCardNumber = undefined;
      this.newPay.creditCardType = undefined;
      this.newPay.expirationMonth = undefined;
      this.newPay.expirationYear = undefined;
    }

    this.techerror = false;
    this.addError = this.errorMsg.techError;
    this.gbdPayMethodService.addPaymentMethod(this.newPay).subscribe(
      (data: UpdatePayResponse) => {
        if (data && data.message && data.message.messageCode === '0') {
          document.getElementById('confirmationModalOpener').click();
        } else {
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          if ( data.message.messageText &&  data.message.messageText !== '') {
            this.addError = data.message.messageText;
          }
          this.techerror = true;
        }
        this.screenLoader = false;
      },
      error => {
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.screenLoader = false;
        this.techerror = true;
      }
    );
   }

   redirectToHome(selected: string) {
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

   cancel(selected: string){
     this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

   changePaymentMethod(paymentMethod: string){
     if(paymentMethod == 'CreditDebit') {
          this.value = "CreditDebit";
          this.paymentMethodModel.paymentMethod = 'CreditDebit';
      } else {
          this.value = "Banking";
          this.paymentMethodModel.paymentMethod = 'Banking';
      }
   }

   changeAddressOnAccount(newValue) {
    this.paymentMethodModel.addressOnAccount = newValue;
    if (newValue === 'SubscriberAddr') {
      const memberAdd = this.gbdPayMethodService.memberPayAddress;
      if (memberAdd !== undefined) {
       this.newPay.accountAddress1 = memberAdd.addressLine1;
       this.newPay.accountAddress2 = '';
       this.newPay.accountCity = memberAdd.city;
       this.newPay.accountState = memberAdd.state;
       if (memberAdd.postalCode && memberAdd.postalCode.length > 5) {
        this.newPay.accountPostalCode = memberAdd.postalCode.substr(0, 5);
       } else {
        this.newPay.accountPostalCode = memberAdd.postalCode;
       }
       this.addForm.controls['address1'].markAsTouched();
       this.addForm.controls['city'].markAsTouched();
       this.addForm.controls['state'].markAsTouched();
       this.addForm.controls['zipCode'].markAsTouched();
      }
    } else {
       this.newPay.accountAddress1 = '';
       this.newPay.accountAddress2 = '';
       this.newPay.accountCity = '';
       this.newPay.accountState = '';
       this.newPay.accountPostalCode = '';
       this.addForm.controls['address1'].markAsPristine();
       this.addForm.controls['city'].markAsPristine();
       this.addForm.controls['state'].markAsPristine();
       this.addForm.controls['zipCode'].markAsPristine();
       this.addForm.controls['address1'].markAsUntouched();
       this.addForm.controls['city'].markAsUntouched();
       this.addForm.controls['state'].markAsUntouched();
       this.addForm.controls['zipCode'].markAsUntouched();
    }
  }

   updateCardType(cardno) {
     if (cardno !== undefined && cardno !== '') {
       if (cardno.startsWith('4')) {
         this.newPay.creditCardType = 'VISA';
       } else {
        this.newPay.creditCardType = 'MC';
       }
     }
   }

  //  validateZip(newValue, field: NgModel) {
  //    const fieldError = {
  //     'invalid.zip' : true
  //    };
  //    if (newValue && newValue.length === 5) {
  //      this.gbdPayMethodService.getZipData(newValue).subscribe((data: any) => {
  //        if (data && data.zipCodeResponse && data.zipCodeResponse.zipCode && data.zipCodeResponse.zipCode.zipCode) {
  //          const zipData: ZipCode = data.zipCodeResponse.zipCode;
  //          this.newPay.accountState = zipData.stateCode;
  //          field.control.setErrors(null);
  //        } else {
  //         field.control.setErrors(fieldError);
  //        }
  //      }, (error) => {
  //       field.control.setErrors(fieldError);
  //      });
  //    } else {
  //      console.log('more than five');
  //      field.control.setErrors(fieldError);
  //    }
  //  }
}
