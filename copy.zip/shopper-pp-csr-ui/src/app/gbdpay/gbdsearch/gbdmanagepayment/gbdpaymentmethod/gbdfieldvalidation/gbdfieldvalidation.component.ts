import { Component, Input, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdfieldvalidation',
  templateUrl: 'gbdfieldvalidation.component.html'
})
export class GbdFieldValidationComponent{
  @Input() field: NgModel;
  @Input() invalidMsg: string = '';
  @Input() requiredMsg: string = 'Required field';
  @Input() isOptional: boolean = false;

}
