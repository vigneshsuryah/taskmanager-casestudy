import { BankAccountDetails, CancelPaymentUIDetails } from './../../../shared/models/gbdpay/gbdpaymentmethod.model';
import { LinkedBill, GBDAccountSummary, BillAccount, MemberPayment } from './../../../shared/models/gbdpay/accountsummaryresponse.model';
import { User } from './../../../shared/models/user';
import { GbdINPayService } from './../../../shared/csr-service/gbdinpay.service';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

declare var PIE: any;
declare var jQuery: any;
@Component({
  selector: 'csr-gbdinaccountsummary',
  templateUrl: './gbdinaccountsummary.component.html',
  styleUrls: ['./gbdinaccountsummary.component.css']
})
export class GbdINAccountSummaryComponent implements OnInit {
  paymentType:string = '';
  hcidEntered: string;
  hasBills: boolean = false;
  linkedBillsList: Array<LinkedBill> = [];
  selectedPlan: string = '';
  enteredAmount: number;
  screenLoader: boolean = false;
  serviceerror: boolean = false;
  techerror: boolean = false;
  min: number = 1;
  max: number = 5;
  billAcc: any = {};
  errorMessage: string = '';
  isTouched: boolean = false;
  selectedPlansForPayment: Array<any> = [];
  paymentTrackingNo: string = '';
  subscriberName: string='';
  selectedMethod: string;
  selectedCancelPaymentMethodDetail: CancelPaymentUIDetails;
  pendingPayMessage: string = 'A Payment is already pending or submitted for this plan, do you want to proceed anyway?';
  showNotesSection: boolean = false;
  
  
  constructor(public router: Router, private currentUser: User, public gbdINPayService: GbdINPayService) { }

  @ViewChild('submitPaymentForm') submitPaymentForm: NgForm;
 
  ngOnInit() {
    this.selectedCancelPaymentMethodDetail = new CancelPaymentUIDetails();
    let getKeyUrl = 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/' + 64100000000181 + '/getkey.js';
    this.loadScript(getKeyUrl);

    if (this.gbdINPayService.hcid === undefined || this.gbdINPayService.hcid === '') {
      this.router.navigate(['/gbdpay/gbdinsearch']);
    }
    if (this.gbdINPayService.gbdAcntSummaryRefresh) {
      this.callAccountSummary();
    } else {
      this.processData();
    }
    
    if (this.gbdINPayService.hcid) {
      this.hcidEntered = this.gbdINPayService.hcid;
    }
    
  }

  private processData() {
    if (this.gbdINPayService.gbdAccountSummary) {
      this.linkedBillsList = this.gbdINPayService.gbdAccountSummary.linkedBills;
      for (let bill of this.linkedBillsList) {
        if (null !== bill && null !== bill.billAccounts && undefined !== bill.billAccounts && bill.billAccounts.length > 0) {
          for (let billAcnt of bill.billAccounts) {
            this.hasBills = true;
            billAcnt.paymentAmt = null;
              billAcnt.errorFlag = true;
              billAcnt.errorMessage = 'Required Field';
              billAcnt.isTouched = false;
              if (billAcnt && billAcnt.totalDue && parseFloat(billAcnt.totalDue) < 0) {
                billAcnt.totalDue = '0.00';
              }
              if(billAcnt && billAcnt.minDue && parseFloat(billAcnt.minDue)<0){
                billAcnt.minDue = '0.00';
              }
            }
      }
    }
  }
  }

  private callAccountSummary() {
    this.screenLoader = true;

    var inputParam = {
      "healthCardId": this.gbdINPayService.gbdAccountSummary.healthCardId
    }
    this.gbdINPayService.getSummary(inputParam).subscribe((data: GBDAccountSummary) => {
      if (data && data.message.messageCode==='0') {
        this.gbdINPayService.gbdAccountSummary = data;
        this.gbdINPayService.gbdAcntSummaryRefresh = false;
        this.processData();
        this.screenLoader = false;
      }
    },
      (err: any) => {
        this.gbdINPayService.gbdAcntSummaryRefresh = true;
        this.screenLoader = false;
        this.techerror = true;
      });

  }

  viewPaymentDetails(bills: LinkedBill, billAccount: BillAccount, memberPayment: MemberPayment) {
    this.selectedCancelPaymentMethodDetail.accountName = bills.personDetails.firstName + ' '+ bills.personDetails.lastName;
    if(memberPayment.paymentMethod.bankAccountDetails){
      this.selectedCancelPaymentMethodDetail.accountTypeKey ="Account Type";
      this.selectedCancelPaymentMethodDetail.accountTypeValue = memberPayment.paymentMethod.bankAccountDetails[0].bankAccountType;
    } else{
      this.selectedCancelPaymentMethodDetail.accountTypeKey = "Card Type"
      this.selectedCancelPaymentMethodDetail.accountTypeValue = memberPayment.paymentMethod.creditCardDetails[0].creditCardType;
    }
    this.selectedCancelPaymentMethodDetail.billDate = billAccount.billDate;
    this.selectedCancelPaymentMethodDetail.confirmationNumber = memberPayment.paymentTrackingNo;
    this.selectedCancelPaymentMethodDetail.notes = memberPayment.notes;
    this.selectedCancelPaymentMethodDetail.dueDate = billAccount.billToDt;
    this.selectedCancelPaymentMethodDetail.minDue = billAccount.minDue;
    this.selectedCancelPaymentMethodDetail.paidAmount = memberPayment.paymentAmount;
    this.selectedCancelPaymentMethodDetail.paymentDate = memberPayment.paymentDate;
    this.selectedCancelPaymentMethodDetail.paymentStatus = billAccount.paymentStatus.payNowStatus;
    this.selectedCancelPaymentMethodDetail.planName = billAccount.planName;
    this.selectedCancelPaymentMethodDetail.subscriberName = bills.personDetails.firstName+ ' '+bills.personDetails.lastName;
    this.selectedCancelPaymentMethodDetail.totalDue = parseFloat(billAccount.totalDue);
    if(memberPayment.paymentTrackingNo){
      this.selectedCancelPaymentMethodDetail.disabledStatus = false;
    }else{
      this.selectedCancelPaymentMethodDetail.disabledStatus = true;
    }
    jQuery("#viewPaymentDetailModalOpener").click();
  }

  closePayDetails(selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#viewPaymentDetailModalOpener").click();
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  goBack(selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#viewPaymentDetailModalOpener").click();
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  cancelPayment(paymentTrackingNo: string, selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#notes").val("");
    jQuery('#count_message').html(150 + ' characters remaining');
    let numericRegex =  /^[0-9]+$/;
      if (paymentTrackingNo.match(numericRegex)) {
        this.showNotesSection = false;
      } else {
        this.showNotesSection = true;
      }
    jQuery("#viewPaymentDetailModalOpener").click();
    jQuery("#cancelPaymentModalOpener").click();
    this.paymentTrackingNo = paymentTrackingNo;
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  redirectToHome(selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#cancelPaymentModalOpener").click();
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  confirmCancelPayment(selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#cancelPaymentModalOpener").click();
    this.screenLoader = true;
    var inputParam = {
      "healthCardId": this.hcidEntered,
      "paymentConfirmationNo": this.paymentTrackingNo,
      "notes": jQuery("#notes").val()
    };
    console.log(inputParam);
    this.gbdINPayService.cancelPayment(inputParam).subscribe((data: any) => {
      console.log("from cancel payment" + data);
      if (null !== data && undefined !== data && null !== data.paymentCancelStatus && undefined !== data.paymentCancelStatus
        && 'Success' === data.paymentCancelStatus) {
        this.screenLoader = false;
        jQuery("#cancelConfirmationModalOpener").click();
      } else {
        this.screenLoader = false;
        this.serviceerror = true;
        this.errorMessage = data.message.messageText;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
    this.selectedMethod = 'AS';
  }

  success(selected: string) {
    this.gbdINPayService.memberPaymentOptions = selected;
    jQuery("#cancelConfirmationModalOpener").click();
    this.callAccountSummary();
  }

  loadScript(url) {
    let node = document.createElement('script');
    node.src = url;
    node.type = 'text/javascript';
    document.getElementById('script-load-div').appendChild(node);
  }

  private validateNoSpaces(amt: string) {
    return /\s/g.test(amt) ? true : false;
  }

  private validateNoSpecialChar(amt: string) {
    return /[-~{}!#%&*()+[\]^_`\\":;'@?>=<,/|]+/g.test(amt) ? true : false;
  }

  private validateNoLetter(amt: string) {
    return (/[a-zA-Z]/g.test(amt)) ? true : false;
  }

  private validatePattern(amt: string) {
    return (/^\$?[0-9][0-9\,]*(\.\d{1,2})?$|^\$?[\.]([\d][\d]?)$/g.test(amt)) ? true : false;
  }

  validateAmountEntered(bill: any) {
    bill.errorMessage = undefined;
    bill.amtGreaterWarningMessage = undefined;
    bill.amtWarningMessage = undefined;
    bill.errorFlag = false;
    bill.warningGreaterAmtFlag = false;
    bill.warningFlag = false;
    this.selectedPlan = bill.subGroupId;
    bill.isTouched = true;
    if (bill.paymentAmt === undefined || bill.paymentAmt === '') {
      bill.errorFlag = true;
      bill.errorMessage = "Required Field";
    } else if (this.validatePattern(bill.paymentAmt) && !this.validateNoSpaces(bill.paymentAmt) && !this.validateNoSpecialChar(bill.paymentAmt) && !this.validateNoLetter(bill.paymentAmt)) {
      if (bill.paymentAmt !== undefined && bill.paymentAmt !== '') {
        if (bill.paymentAmt.indexOf('$') == -1 && bill.paymentAmt.indexOf('.') == -1) {
          bill.paymentAmt = '$' + bill.paymentAmt;
        } else if (bill.paymentAmt.length == 1 && (bill.paymentAmt == '$' || bill.paymentAmt == ".")) {
          bill.paymentAmt = '';
        }
        if (bill.paymentAmt.indexOf('$') >= 0) {
          this.enteredAmount = +bill.paymentAmt.slice(1);
        } else {
          this.enteredAmount = +bill.paymentAmt;
        }
        bill.errorFlag = false;
        if (this.enteredAmount < 1 ) {
          bill.errorFlag = true;
          bill.errorMessage = "Amount should not be less than $1";
        }
        if (this.enteredAmount > 9999.99) {
          bill.warningGreaterAmtFlag = true;
          bill.amtGreaterWarningMessage = "This payment exceeds $9,999.99. Do you want to proceed anyway?";
        }
        if (this.enteredAmount > bill.totalDue) {
          bill.warningFlag = true;
          bill.amtWarningMessage = "Entered amount exceeds current Amount Due";
        }
      } else {
        bill.errorFlag = true;
        bill.errorMessage = "Required Field";
      }
    } else {
      bill.errorFlag = true;
      bill.errorMessage = "Please enter valid amount";
    }
  }

  paySelectedPlan(bill: BillAccount, amount: string) {
    this.gbdINPayService.gbdAccountSummary.linkedBills[0].billAccounts[0].paymentAmt = bill.paymentAmt;
    this.router.navigate(['/gbdpay/gbdinonetimepayment']);
  }

  redirectToMemberSearch() {
    this.router.navigate(['/gbdpay/gbdinsearch']);
  }

  onKeyUp(event: any) {
        var text_length = event.target.value.length;
        var text_remaining = 150 - text_length;
        jQuery('#count_message').html(text_remaining + ' characters remaining');
    }

}
