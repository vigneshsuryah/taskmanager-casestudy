import { GBDAccountSummary } from './../../shared/models/gbdpay/accountsummaryresponse.model';
import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { GbdINPayService } from '../../shared/csr-service/gbdinpay.service';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-gbdinsearch',
  templateUrl: 'gbdinsearch.component.html',
  styleUrls: ['gbdinsearch.component.css']
})
export class GBDINSearchComponent {

  content : any ={};
  hcid: string;
  screenLoader: boolean = false;
  responseCode: string;
  showContent: string;
  isExactLength: boolean = true;
  isValidHcid: boolean = true;
  hasHcid: boolean = true;

  hasGBDCSRSUBMIT: boolean = false;
  hasGBDPPORTCSR: boolean = false;

  gbdSearchModel = {
    'hcid':'',
  }

  constructor (public router: Router, public gbdINPayService: GbdINPayService, private user: User ) {
      if(this.user.userRole === undefined){
        this.router.navigate(['']);
      }
      if (this.user && this.user.userRole) {
        if (this.user.userRole.indexOf('GBDCSRSUBMIT') > -1) {
          this.hasGBDCSRSUBMIT = true;
        }
        if (this.user.userRole.indexOf('GBDPPORTCSR') > -1) {
          this.hasGBDPPORTCSR = true;
        }
      } else {
        this.router.navigate(['/roothome']);
      }
  }

  validateHcid(hcid: string, selectedApp: string) {
    if(hcid.length == 0){
      this.hasHcid = false;
      this.isExactLength = true;
      this.isValidHcid = true;
    } else if(hcid.length > 9 || hcid.length < 9){
      this.isExactLength = false;
      this.hasHcid = true;
      this.isValidHcid = true;
    } else {
      this.isValidINMember(hcid, selectedApp);
    }
  }

  isValidINMember(hcid: string, selectedApp: string){
    this.hasHcid = true;
    this.isValidHcid = true;
    this.isExactLength = true;   
    this.screenLoader = true

    var inputParams = {
      "healthCardId" : hcid
    }
    this.gbdINPayService.getSummary(inputParams).subscribe((data: GBDAccountSummary) => {
      this.screenLoader = false;
      if(null !== data && undefined !== data && data.message.messageCode==='0') {
        this.gbdINPayService.hcid = hcid;
        if(selectedApp === 'PD'){
          if(this.hasGBDCSRSUBMIT){
            this.gbdINPayService.memberPaymentOptions = 'AS';
            this.gbdINPayService.gbdAccountSummary = data;
          }else if(this.hasGBDPPORTCSR){
            this.gbdINPayService.memberPaymentOptions = 'MPM';
          }
          this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
        } else if (selectedApp === 'PH'){
          this.router.navigate(['/gbdpay/gbdinpaymenthistory']);
        }
      }
    },
    (err: any) => {
      this.screenLoader = false;
      this.isValidHcid = false;
    });
  }

}
