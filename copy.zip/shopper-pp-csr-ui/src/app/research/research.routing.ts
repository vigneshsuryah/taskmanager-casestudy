import { Routes } from '@angular/router';

import { ResearchHomeComponent } from './home/researchhome.component';
import { SearchResultComponent } from './query/searchresult/searchresult.component';
import { ConfirmationDetailsComponent } from './query/confirmationdetails/confirmationdetails.component';

export const routes: Routes = [
    { path: 'home', component: ResearchHomeComponent },
    { path: 'searchresult', component: SearchResultComponent },
    { path: 'confirmationdetails', component: ConfirmationDetailsComponent }
];