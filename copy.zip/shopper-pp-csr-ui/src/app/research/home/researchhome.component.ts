import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../../shared/models/user';

/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-researchhome',
  templateUrl: 'researchhome.component.html',
  styleUrls: ['researchhome.component.css']
})
export class ResearchHomeComponent implements OnInit {

  selectedMethod: string;
  
  constructor (public router : Router, private currentUser: User, public activeRoute: ActivatedRoute) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
    this.activeRoute.queryParams.subscribe(params => {
      this.selectedMethod = params['page'] || 'CASHOPERATIONS';
    });
    console.log('result: ' + this.selectedMethod)
  }

  ngOnInit(){
    
  }

  changePaymentMethod(selectedMethod: string){
    if(selectedMethod === 'CASHPAY'){
      this.selectedMethod = 'CASHPAY';
    } else if(selectedMethod === 'TPTS'){
      this.selectedMethod = 'TPTS';    
    } else if(selectedMethod === 'QUERY'){
      this.selectedMethod = 'QUERY';
    }  
 }

}