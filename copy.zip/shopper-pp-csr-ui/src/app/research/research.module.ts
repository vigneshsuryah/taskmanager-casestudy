import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResearchHomeComponent } from './home/researchhome.component';
import { TPPayersComponent } from './tppayers/tppayers.component';
import { CashPayDetailsComponent } from './cashpay/cashpay.component'; 
import { QueryComponent } from './query/query.component';
import { SearchResultComponent } from './query/searchresult/searchresult.component';
import { ConfirmationDetailsComponent } from './query/confirmationdetails/confirmationdetails.component';
import { routes } from './research.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { ReportsService } from '../shared/csr-service/reports.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
 
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    AngularMultiSelectModule,
    CommonutilsModule.forRoot(),    
    RouterModule.forChild(routes)
  ],
   providers: [
    ReportsService,
    DatePipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [ResearchHomeComponent, TPPayersComponent, CashPayDetailsComponent, QueryComponent, SearchResultComponent, ConfirmationDetailsComponent]
})
export class ResearchModule { 

}
