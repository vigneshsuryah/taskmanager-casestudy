import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'; 
declare var jQuery: any;

import { QueryModel } from '../../../shared/models/reports/query.model';
import { ReportsService } from '../../../shared/csr-service/reports.service';
import { User } from '../../../shared/models/user';

@Component({
  moduleId: module.id,
  templateUrl: 'searchresult.component.html',
  styleUrls: ['searchresult.component.css']
})
export class SearchResultComponent implements OnInit {

  techerror: boolean = false;
  screenLoader: boolean = false;
  queryResult: any = [];
  searchCriteria: any = {};

  constructor(public router: Router, private currentUser: User, private reportsService: ReportsService, private datePipe: DatePipe) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.searchCriteria = this.reportsService.searchCriteria;
    this.getQueryResults(this.searchCriteria);
  }

  getQueryResults(queryModel: QueryModel) {

    this.screenLoader = true;

    var payType = 'NA';
    if (queryModel.achType === 'achType') {
      payType = 'ACH';
    } else if (queryModel.ccType === 'ccType') {
      payType = 'CC';
    }
    var inputParams = {
      'orderId' : queryModel.orderId,
      'memberBillingId' : queryModel.memberBillingId,
      'type': payType,
      'creditCardLastFour' : queryModel.ccLastFourDigits,
      'creditCardFirstSix' : queryModel.ccBinNo,
      'routingNumber' : queryModel.routingNo,
      'accountNumber' : queryModel.accountNo,
      'nameOnFundingAccount' : queryModel.fundingName,
      'TotalAmount' : queryModel.totDbtCdt,
      'paymentConfirmationEmail' : queryModel.emailAddr,
      'loginId' : queryModel.loginPayment,
      'startDate' : this.datePipe.transform(queryModel.fromdate,'yyyy-MM-dd'),
      'endDate' : this.datePipe.transform(queryModel.todate,'yyyy-MM-dd'),
      'dateType': queryModel.dateType
    };
    
    this.reportsService.getQueryResults(inputParams).subscribe((result:any) => {
      this.screenLoader = false;
      if(result.success) {
        if(null !== result.data && undefined !== result.data) {
          this.queryResult = result.data;

          setTimeout(() => {
            if (jQuery.fn.dataTable.isDataTable('#reports-table')) {
              jQuery('#reports-table').DataTable();
            } else {
              jQuery('#reports-table').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [5, 10, 15, 20],
                "dom": '<"table-div-wrapper"t><"clear"lip>',
                "language": {
                  "paginate": {
                    "previous": "Previous",
                    "next": "Next",
                    "first": "First",
                    "last": "Last"
                  }
                }
              });
            }
            // setting width internally
            var widthOfTable = jQuery("#reports-table_wrapper").width();
            jQuery(".table-div-wrapper").width(widthOfTable);
          }, 100);
        } 
      } else {
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
      }
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }

  backToSearch(): any {
    this.reportsService.isEdit = false;
    this.router.navigate(['/research/home'], { queryParams: { page: 'QUERY' } });
  }

  editSearch(searchCriteria: any): any {
    this.reportsService.searchCriteria = searchCriteria;
    this.reportsService.isEdit = true;
    this.router.navigate(['/research/home'], { queryParams: { page: 'QUERY' } });
  }

  getConfirmationDetails(orderId: string, status: string) {
    this.reportsService.orderId = orderId;
    this.reportsService.transactionStatus = status;
    this.router.navigate(['/research/confirmationdetails']);    
  }

}
