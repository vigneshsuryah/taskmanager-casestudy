export const content = {
  radioObjectVisa: {
    label: '<img src="assets/images/visa.png" width="50px" height="32px">Visa',
    id: 'ddlPayType15',
    name: 'Visa Card',
    value: 'VISA'
  },
  radioObjectMC: {
    label: '<img src="assets/images/mc.png" width="50px" height="32px">MasterCard',
    id: 'ddlPayType16',
    name: 'Master Card',
    value: 'MASTERCARD'
  },
  creditCardChecked: {
    id: 'ddlPayType17',
    name: 'creditCardChecked',
    label: 'I want to use this credit/debit card account for automatic monthly payments for my coverage.',
    trueValue: true,
    falseValue: false
  },
  radioObjectCardHolderAddr: {
    label: 'Enter Cardholder Address',
    id: 'ddlPayType18',
    name: 'Enter Cardholder Address',
    value: 'CardHolderAddr'
  },
  radioObjectHomeAddr: {
    label: 'Use my Applicant Home Address',
    id: 'ddlPayType19',
    name: 'Use my Applicant Home Address',
    value: 'AppHomeAddr'
  },
  radioObjectBillAddr: {
    label: 'Use my Applicant Billing Address',
    id: 'ddlPayType20',
    name: 'Use my Applicant Billing Address',
    value: 'AppBillAddr'
  },
  radioObjectYes: {
    label: 'Yes',
    id: 'ddlPayType21',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectNo: {
    label: 'No',
    id: 'ddlPayType22',
    name: 'No',
    value: 'No'
  },
  radioObjectPersonalChecking: {
    label: 'Personal Checking',
    id: 'ddlPayType23',
    name: 'Personal Checking',
    value: 'PERSONALCHECKING'
  },
  radioObjectBusinessChecking: {
    label: 'Business Checking',
    id: 'ddlPayType24',
    name: 'Business Checking',
    value: 'BUSCHECKING'
  },
  radioObjectPersonalSaving: {
    label: 'Personal Savings',
    id: 'ddlPayType25',
    name: 'Personal Saving',
    value: 'PERSONALSAVINGS'
  },
  radioObjectBusinessSaving: {
    label: 'Business Savings',
    id: 'ddlPayType26',
    name: 'Business Saving',
    value: 'BUSSAVINGS'
  },
  autoPayChecked: {
    id: 'ddlPayType27',
    name: 'autoPayChecked',
    label: 'I want to use this bank account for automatic monthly payments for my coverage.',
    trueValue: true,
    falseValue: false
  },
  radioObjectEbillYes: {
    label: 'Yes',
    id: 'ddlPayType28',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectEbillNo: {
    label: 'No',
    id: 'ddlPayType29',
    name: 'No',
    value: 'No'
  },
  radioObjectPolicyInfoYes: {
    label: 'Yes',
    id: 'ddlPayType30',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectPolicyInfoNo: {
    label: 'No',
    id: 'ddlPayType31',
    name: 'No',
    value: 'No'
  },
  stateList: [{
    label: 'Alabama',
    value: 'AL'
  },
  {
    label: 'Alaska',
    value: 'AK'
  },
  {
    label: '	Arizona',
    value: 'AZ'
  },
  {
    label: 'Arkansas',
    value: 'AR'
  },
  {
    label: 'California',
    value: 'CA'
  },
  {
    label: 'Colorado',
    value: 'CO'
  },
  {
    label: 'Connecticut',
    value: 'CT'
  },
  {
    label: 'Delaware',
    value: 'DE'
  },
  {
    label: 'Florida',
    value: 'FL'
  },
  {
    label: 'Georgia',
    value: 'GA'
  },
  {
    label: 'Hawaii',
    value: 'HI'
  },
  {
    label: 'Idaho',
    value: 'ID'
  },
  {
    label: 'Illinois',
    value: 'IL'
  },
  {
    label: 'Indiana',
    value: 'IN'
  },
  {
    label: 'Iowa',
    value: 'IA'
  },
  {
    label: 'Kansas',
    value: 'KS'
  },
  {
    label: 'Kentucky',
    value: 'KY'
  },
  {
    label: 'Louisiana',
    value: 'LA'
  },
  {
    label: 'Maine',
    value: 'ME'
  },
  {
    label: 'Maryland',
    value: 'MD'
  },
  {
    label: 'Massachusetts',
    value: 'MA'
  },
  {
    label: 'Michigan',
    value: 'MI'
  },
  {
    label: 'Minnesota',
    value: 'MN'
  },
  {
    label: 'Mississippi',
    value: 'MS'
  },
  {
    label: 'Missouri',
    value: 'MO'
  },
  {
    label: 'Montana',
    value: 'MT'
  },
  {
    label: 'Nebraska',
    value: 'NE'
  },
  {
    label: 'Nevada',
    value: 'NV'
  },
  {
    label: 'New Hampshire',
    value: 'NH'
  },
  {
    label: 'New Jersey',
    value: 'NJ'
  },
  {
    label: 'New Mexico',
    value: 'NM'
  },
  {
    label: 'New York',
    value: 'NY'
  },
  {
    label: 'North Carolina',
    value: 'NC'
  },
  {
    label: 'North Dakota',
    value: 'ND'
  },
  {
    label: 'Ohio',
    value: 'OH'
  },
  {
    label: 'Oklahoma',
    value: 'OK'
  },
  {
    label: 'Oregon',
    value: 'OR'
  },
  {
    label: 'Pennsylvania',
    value: 'PA'
  },
  {
    label: 'Rhode Island',
    value: 'RI'
  },
  {
    label: 'South Carolina',
    value: 'SC'
  },
  {
    label: 'South Dakota',
    value: 'SD'
  },
  {
    label: 'Tennessee',
    value: 'TN'
  },
  {
    label: 'Texas',
    value: 'TX'
  },
  {
    label: 'Utah',
    value: 'UT'
  },
  {
    label: 'Vermont',
    value: 'VT'
  },
  {
    label: 'Virginia',
    value: 'VA'
  },
  {
    label: 'Washington',
    value: 'WA'
  },
  {
    label: 'West Virginia',
    value: 'WV'
  },
  {
    label: 'Wisconsin',
    value: 'WI'
  },
  {
    label: 'Wyoming',
    value: 'WY'
  }],
  radioObjectSubscriberAddr: {
    label: 'Use Subscriber\'s Address',
    id: 'ddlPayType29',
    name: 'Use Subscriber\'s Address',
    value: 'SubscriberAddr'
  },
  radioObjectAlternativeAddr: {
    label: 'Use an Alternative Address',
    id: 'ddlPayType30',
    name: 'Use an Alternative Address',
    value: 'AlternativeAddr'
  },
  accountType: [{
    label: 'Personal Checking',
    value: 'PERSONAL_CHECKING'
  }, {
    label: 'Personal Savings',
    value: 'PERSONAL_SAVINGS'
  }, {
    label: 'Business Checking',
    value: 'BUSINESS_CHECKING'
  }, {
    label: 'Business Savings',
    value: 'BUSINESS_SAVINGS'
  }],
  creditCardType: [{
    label: 'VISA',
    value: 'VISA'
  }, {
    label: 'Mastercard',
    value: 'MC'
  }],
  paymentMethod: [{
    label: 'Credit/Debit Card',
    value: 'CreditDebit'
  }, {
    label: 'Banking Account',
    value: 'Banking'
  }],
  oneTimePaymentMethod: [{
    label: 'Bank Account',
    value: 'Banking'
  }, {
    label: 'Credit/Debit Card',
    value: 'CreditDebit'
  }],
  authorization: [{
    label: 'Telephone',
    value: 'Telephone'
  },
  {
    label: 'Paper',
    value: 'Paper'
  }],
  dayOfMonth: [{
    label: '1st Day of month',
    value: '01'
  }, {
    label: '2nd Day of month',
    value: '02'
  }, {
    label: '3rd Day of month',
    value: '03'
  },
  {
    label: '4th Day of month',
    value: '04'
  }, {
    label: '5th Day of month',
    value: '05'
  },
  {
    label: '6th Day of month',
    value: '06'
  }],
  payDate: [{
    label: '1',
    value: '01'
  }, {
    label: '2',
    value: '02'
  }, {
    label: '3',
    value: '03'
  },
  {
    label: '4',
    value: '04'
  }, {
    label: '5',
    value: '05'
  },
  {
    label: '6',
    value: '06'
  }],
  indvAddSummaryBillChecked: {
    id: 'ddlPayType31',
    name: 'addSummaryBillChecked',
    label: 'Summary Bill : ',
    trueValue: true,
    falseValue: false
  },
  indvEditSummaryBillChecked: {
    id: 'ddlPayType32',
    name: 'editSummaryBillChecked',
    label: 'Summary Bill : ',
    trueValue: true,
    falseValue: false
  },
  gbdAddSummaryBillChecked: {
    id: 'ddlPayType31',
    name: 'addSummaryBillChecked',
    label: '',
    trueValue: true,
    falseValue: false
  },
  gbdEditSummaryBillChecked: {
    id: 'ddlPayType32',
    name: 'editSummaryBillChecked',
    label: '',
    trueValue: true,
    falseValue: false
  },
  advSearchChecked: {
    id: 'ddlPayType33',
    name: 'advSearchChecked',
    label: 'Display Active Application',
    trueValue: true,
    falseValue: false
  },
  withdrawalDay: [{
    label: '1st',
    value: '1'
  }, {
    label: '2nd',
    value: '2'
  }, {
    label: '3rd',
    value: '3'
  }, {
    label: '4th',
    value: '4'
  }, {
    label: '5th',
    value: '5'
  }, {
    label: '6th',
    value: '6'
  }],
  sendConfirmationEmail: {
    id: 'ddlemail01',
    name: 'emailAddressChecked',
    label: 'Send confirmation email',
    trueValue: true,
    falseValue: false
  },
  radioObjectAchType: {
    label: 'ACH Payment Account',
    id: 'radioObjectAchType',
    name: 'ACH Payment Account',
    value: 'achType'
  },
   radioObjectCCType: {
    label: 'CC/Debit Payment Account',
    id: 'radioObjectCCType',
    name: 'CC/Debit Payment Account',
    value: 'ccType'
  },
  tooltipDescription: {
   "label.2.gtz.yes.no":"Our records indicate you have a pending payment in progress. If you need to make changes to this payment please go to <SECTION TO MODIFY PAYMENT>.",
   "label.a.gtz.no.yes":"Our records indicate you have a pending future payment. If you need to make changes to this payment please go to <SECTION TO MODIFY PAYMENT>.",
   "label.e.na.na.na":"Our records show you are currently on an automatic recurring payment option where your premiums are automatically debited from your chosen account. If you wish to make a one time payment, you will first need to cancel the automatic recurring payment option. Upon receiving  your first invoice,  you will then be able to make manual payments online.  If you need to make changes to the financial account associated with your automatic recurring payment option, please go to <Manage Automatic Payments> to make those changes." ,
   "label.u.na.na.na":"You have no payment due. Our records show your current coverage is 100% subsidized.",
   "label.2.gtz.no.no":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.2.eqz.na.na":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.2.gtz.yes.na":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.2.gtz.na.yes":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.3.gtz.no.no":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.3.eqz.na.na":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.3.gtz.yes.na":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.3.gtz.na.yes":"Our records indicate we have not received your full premium payment, please pay your premium in full in order to avoid cancellation. Any partial payment of the total amount due will not be sufficient to remove your coverage from the grace period, reinstate your coverage if your coverage has been suspended, or prevent cancellation.",
   "label.s.na.na.na":"We're sorry, this account is not eligible for this service at this time.",
   "label.x.na.na.na":"You will not be able to utilize the online payment service. All premium payments for your coverage are handled by the Nevada Exchange. Please contact the Nevada Exchange at 855-768-5465. If you have further questions for us, please contact Member Services at the number listed on your ID Card.",
   "label.r.na.na.no":"We're sorry, your account has been cancelled . If you have further questions for us, please contact Member Services at the number listed on your ID card.",
   "label.d.na.na.na":"We're sorry, this account is not eligible for this service at this time.",
   "label.w.na.na.na":"Our records show you are currently on an automatic recurring payment option where your premiums are automatically debited from your chosen account. You will not be able to utilize the online payment service to make your premium payments as payments will be automatically debited when they become due. To change your current premium payment option or if you have any questions, please call us at the number listed on your ID card. If you have recently cancelled your automatic premium payment option, please be aware you will not be able to utilize the online payment service until you receive your first premium notice.",
   "label.g.na.na.na":"Our records indicate we have not received your full premium payment for your prior coverage. You will not be able to make a payment for any new or renewing coverage until your prior coverage is paid in full.",
   "label.n.gtz.no.no":"Our records indicate we have not received your full premium payment for your prior coverage. You will not be able to make a payment for any new or renewing coverage until your prior coverage is paid in full.",
   "label.a.eqz.no.no":"Our records indicate you have no payment due at this time.",
   "label.w.gtz.no.no":"Our records show you are currently on an automatic recurring payment option where your premiums are automatically debited from your chosen account. If you wish to make a one time payment, you will first need to cancel the automatic recurring payment option. Upon receiving  your first invoice,  you will then be able to make manual payments online.  If you need to make changes to the financial account associated with your automatic recurring payment option, please go to <Manage Automatic Payments> to make those changes.",
   "label.n.eqz.no.no":"Our records indicate you have no payment due at this time.",
   "label.n.gtz.yes.no":"Our records indicate you have a pending payment in progress. If you need to make changes to this payment please go to Payment Processing section by clicking View Details link.",
   "label.n.gtz.no.yes":"Our records indicate you have a pending future payment. If you need to make changes to this payment please go to Payment Processing section by clicking View Details link."
  },
  chaseTDList: [{
    label: 'Select',
    value:'default'
  },{
    label: '355958',
    value: '355958'
  }, {
    label: '355959',
    value: '355959'
  },{
    label: '355960',
    value: '355960'
  }, {
    label: '355961',
    value: '355961'
  },{
    label: '355962',
    value: '355962'
  }, {
    label: '355964',
    value: '355964'
  },{
    label: '355965',
    value: '355965'
  }, {
    label: '355967',
    value: '355967'
  },{
    label: '355968',
    value: '355968'
  }, {
    label: '355969',
    value: '355969'
  },{
    label: '355970',
    value: '355970'
  }, {
    label: '355971',
    value: '355971'
  },{
    label: '355972',
    value: '355972'
  }, {
    label: '355973',
    value: '355973'
  },{
    label: '355974',
    value: '355974'
  }, {
    label: '355975',
    value: '355975'
  }],
  legalEntityList:[{
    label: 'Select',
    value:'default'
  },{
    label: '01',
    value: '01'
  },{
    label: '02',
    value: '02'
  },{
    label: '03',
    value: '03'
  },{
    label: '04',
    value: '04'
  },{
    label: '05',
    value: '05'
  },{
    label: '06',
    value: '06'
  },{
    label: '07',
    value: '07'
  },{
    label: '08',
    value: '08'
  },{
    label: '09',
    value: '09'
  },{
    label: '10',
    value: '10'
  },{
    label: '11',
    value: '11'
  },{
    label: '12',
    value: '12'
  },{
    label: '13',
    value: '13'
  },{
    label: '14',
    value: '14'
  },{
    label: '15',
    value: '15'
  },{
    label: '16',
    value: '16'
  },{
    label: '17',
    value: '17'
  },{
    label: '18',
    value: '18'
  },{
    label: '19',
    value: '19'
  },{
    label: '20',
    value: '20'
  },{
    label: '21',
    value: '21'
  },{
    label: '22',
    value: '22'
  },{
    label: '23',
    value: '23'
  },{
    label: '24',
    value: '24'
  },{
    label: '25',
    value: '25'
  },{
    label: '26',
    value: '26'
  },{
    label: '27',
    value: '27'
  },{
    label: '28',
    value: '28'
  },{
    label: '29',
    value: '29'
  },{
    label: '30',
    value: '30'
  },{
    label: '31',
    value: '31'
  },{
    label: '32',
    value: '32'
  },{
    label: '33',
    value: '33'
  },{
    label: '34',
    value: '34'
  },{
    label: '35',
    value: '35'
  },{
    label: '36',
    value: '36'
  },{
    label: '37',
    value: '37'
  },{
    label: '38',
    value: '38'
  },{
    label: '39',
    value: '39'
  },{
    label: '40',
    value: '40'
  },{
    label: '41',
    value: '41'
  },{
    label: '42',
    value: '42'
  },{
    label: '43',
    value: '43'
  },{
    label: '44',
    value: '44'
  },{
    label: '45',
    value: '45'
  },{
    label: '46',
    value: '46'
  },{
    label: '47',
    value: '47'
  },{
    label: '48',
    value: '48'
  },{
    label: '49',
    value: '49'
  },{
    label: '50',
    value: '50'
  },{
    label: '51',
    value: '51'
  },{
    label: '52',
    value: '52'
  },{
    label: '53',
    value: '53'
  },{
    label: '54',
    value: '54'
  },{
    label: '55',
    value: '55'
  },{
    label: '60',
    value: '60'
  }, {
    label: '61',
    value: '61'
  },{
    label: '62',
    value: '62'
  },{
    label: '63',
    value: '63'
  },{
    label: '64',
    value: '64'
  },{
    label: '65',
    value: '65'
  },{
    label: '66',
    value: '66'
  },{
    label: '68',
    value: '68'
  },{
    label: '69',
    value: '69'
  }],
  marketSegmentList: [{
    label: 'Select',
    value:'default'
  },{
    label: '001',
    value: '001'
  },{
    label: '003',
    value: '003'
  },{
    label: '004',
    value: '004'
  },{
    label: '005',
    value: '005'
  },{
    label: '007',
    value: '007'
  },{
    label: '011',
    value: '011'
  },{
    label: '013',
    value: '013'
  },{
    label: '014',
    value: '014'
  },{
    label: '015',
    value: '015'
  },{
    label: '016',
    value: '016'
  },{
    label: '017',
    value: '017'
  },{
    label: '018',
    value: '018'
  },{
    label: '019',
    value: '019'
  },{
    label: '020',
    value: '020'
  },{
    label: '021',
    value: '021'
  },{
    label: '022',
    value: '022'
  },{
    label: '023',
    value: '023'
  },{
    label: '100',
    value: '100'
  },{
    label: '101',
    value: '101'
  },{
    label: '102',
    value: '102'
  },{
    label: '103',
    value: '103'
  },{
    label: '104',
    value: '104'
  },{
    label: '105',
    value: '105'
  },{
    label: '106',
    value: '106'
  },{
    label: '107',
    value: '107'
  },{
    label: '108',
    value: '108'
  },{
    label: '111',
    value: '111'
  },{
    label: '112',
    value: '112'
  },{
    label: '113',
    value: '113'
  },{
    label: '114',
    value: '114'
  }],
  marketLevelList:[
    {"id":1,"itemName":"MS"},
    {"id":2,"itemName":"MA"},
    {"id":3,"itemName":"Medi"},
    {"id":4,"itemName":"IND"}
  ],
  transactionStatusList : [
    {"id":1,"itemName":"Pending"},
    {"id":2,"itemName":"Submitted"},
    {"id":3,"itemName":"Accepted"},
    {"id":4,"itemName":"Rejected"},
    {"id":5,"itemName":"Completed"},
    {"id":6,"itemName":"Returned"},
    {"id":8,"itemName":"NOC"},
    {"id":9, "itemName":"Cancelled"}
  ],
  transactionTypesList : [
    {"id":1,"itemName":"Payment"},
    {"id":2,"itemName":"Refund"},
    {"id":3,"itemName":"Return"},
    {"id":4,"itemName":"ChargeBack"},
    {"id":5,"itemName":"NOC"}
  ],
  ccPaymentTypeList : [
    {"id":1,"itemName":"Visa"},
    {"id":2,"itemName":"Master Card"}
  ],
  achPaymentTypeList : [
    {"id":1,"itemName":"Business Savings"},
    {"id":2,"itemName":"Business Checking"},
    {"id":3,"itemName":"Personal Savings"},
    {"id":4,"itemName":"Personal Checking"}
  ],
  paymentChannelList:[{
      label: 'Select',
      value:'default'
    },{
      label: 'IVR',
      value: 'IVR'
    },{
      label: 'CSR',
      value: 'CSR'
    },{
      label: 'WEB',
      value: 'WEB'
    },{
      label: 'MOB',
      value: 'MOB'
    },{
      label: 'STG',
      value: 'STG'
    },{
      label: 'AWD',
      value: 'AWD'
    },{
      label: 'TPP',
      value: 'TPP'
    },{
      label: 'OGB',
      value: 'OGB'
  }],
  anthemBankAccountList : [
    {"id":1,"itemName":"4307"},
    {"id":2,"itemName":"5552"},
  ],
  anthemBankList : [
    {"id":1,"itemName":"BC of CA"},
    {"id":2,"itemName":"Empire"},
  ],
  systemList: [
    {"id":1,"itemName":"01"},
    {"id":2,"itemName":"02"},
    {"id":4,"itemName":"05"},
    {"id":9,"itemName":"11"},
    {"id":10,"itemName":"12"},
    {"id":11,"itemName":"15"},
    {"id":19,"itemName":"27"}
  ],
  radioObjectPaidDt: {
    label: 'Paid date',
    id: 'dateType1',
    name: 'Paid date',
    value: 'paid_date'
  },
  radioObjectDepositDt: {
    label: 'Deposit date',
    id: 'dateType2',
    name: 'Deposit date',
    value: 'deposit_date'
  },
  radioObjectPrfDt: {
    label: 'PRF date',
    id: 'dateType3',
    name: 'PRF date',
    value: 'prf_date'
  },
  radioObjectJournalDt: {
    label: 'Journal date',
    id: 'dateType4',
    name: 'Journal date',
    value: 'journal_date'
  },
  radioObjectAdhocPaidDt: {
    label: 'Paid date',
    id: 'dateTypeAdhoc1',
    name: 'Paid date',
    value: 'paid_date'
  },
  radioObjectAdhocDepositDt: {
    label: 'Deposit date',
    id: 'dateTypeAdhoc2',
    name: 'Deposit date',
    value: 'deposit_date'
  },
  radioObjectAdhocPrfDt: {
    label: 'PRF date',
    id: 'dateTypeAdhoc3',
    name: 'PRF date',
    value: 'prf_date'
  },
  radioObjectAdhocJournalDt: {
    label: 'Journal date',
    id: 'dateTypeAdhoc4',
    name: 'Journal date',
    value: 'journal_date'
  },
  radioObjectQueryPaidDt: {
    label: 'Paid date',
    id: 'dateTypeQuery1',
    name: 'Paid date',
    value: 'paid_date'
  },
  radioObjectQueryDepositDt: {
    label: 'Deposit date',
    id: 'dateTypeQuery2',
    name: 'Deposit date',
    value: 'deposit_date'
  },
  radioObjectQueryPrfDt: {
    label: 'PRF date',
    id: 'dateTypeQuery3',
    name: 'PRF date',
    value: 'prf_date'
  },
  radioObjectQueryJournalDt: {
    label: 'Journal date',
    id: 'dateTypeQuery4',
    name: 'Journal date',
    value: 'journal_date'
  },
  superadminRule: {
    id: 'superadminRule',
    name: 'SUPERADMIN',
    label: 'Allow user to make any other user as a Super Admin or take away Super Admin option.',
    trueValue: true,
    falseValue: false
  },
  mslimitchangeRule: {
    id: 'mslimitchangeRule',
    name: 'MSLIMITCHANGE',
    label: 'Allow user to be able to pay any amount from $.01 - $99,999.99 for MS',
    trueValue: true,
    falseValue: false
  },
  malimitchangeRule: {
    id: 'malimitchangeRule',
    name: 'MALIMITCHANGE',
    label: 'Allow user to be able to pay any amount from $.01 - $99,999.99 for MA',
    trueValue: true,
    falseValue: false
  },
  viewfundinginfoRule: {
    id: 'viewfundinginfoRule',
    name: 'VIEWFUNDINGINFO',
    label: 'Allow user to view full funding information.',
    trueValue: true,
    falseValue: false
  },
};
