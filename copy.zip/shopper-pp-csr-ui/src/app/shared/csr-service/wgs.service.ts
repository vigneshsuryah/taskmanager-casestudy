import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Config } from '../index';
import { AuthenticationService } from './authentication.service';
import { RouterModule , Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { Subject } from 'rxjs/Subject';
import { ValidateRoutingNo } from '../models/indvmemberpay/validateRoutingNo.model';

@Injectable()
export class WgsService {
    
    constructor(private http: Http, private authenticationService: AuthenticationService, private currentUser: User) {
    }

    selectedMethod: string;
    hcid: string;
    selectedPlansForPayment : any [];

    getRecurring (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'WGS'});    
        let options = new RequestOptions({ headers: headers });    
        // return this.http.post(Config.API+"csr/secure/v1/gbd/payments/getrecurring", inputParam, options)
        // .map((res: Response) => res.json())
        // .catch(this.handleErrorNoChange.bind(this));
          return this.http.get('assets/recurring.json')
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
    }
  
    updateRecurring (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "gofundkyhp/secure/v1/gbd/payments/updaterecurring",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    getPaymentMethods (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username , 'csrId': this.currentUser.username,'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
       return this.http.post(Config.API+ "wgs/secure/v1/payments/getmethods",inputParam,options)
                       .map((res: Response) => res.json())
                       .catch(this.handleErrorNoChange.bind(this));
        // return this.http.get('assets/paymentmethods.json')
        //             .map((res: Response) => res.json())
        //             .catch(this.handleErrorNoChange.bind(this));
    }

    updatePaymentMethods (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username , 'csrId': this.currentUser.username, 'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "wgs/secure/v1/payments/updatemethods",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    } 

    validateRoutingNumber (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "wgs/secure/v1/payments/validateRoutingNumber",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    getdetailsforcsr(inputParam:{}, endpoint) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username, 'csrId': this.currentUser.username, 'meta-endpoint' : endpoint});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+"csr/secure/mwp/getdetailsforcsr", inputParam, options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

     getSummary (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username , 'csrId': this.currentUser.username, 'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "wgs/secure/v1/payments/getsummary",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    submitPayment (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username , 'csrId': this.currentUser.username, 'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "wgs/secure/v1/payments/submitpayment",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    cancelPayment (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username , 'csrId': this.currentUser.username, 'meta-senderapp': 'WGS'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "wgs/secure/v1/payments/cancelpayment",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }


    getValidationBankDetails(inputParam:{}, endpoint) :Observable<ValidateRoutingNo>{
      let headers = new Headers({ 'Authorization':'Bearer ' +
      this.currentUser.token , 'UserName': this.currentUser.username, 'csrId': this.currentUser.username, 'meta-endpoint' :endpoint});
      let options = new RequestOptions({headers: headers}); 
      return  this.http.post(Config.API +"csr/secure/v1/payments/validateRoutingNumber", inputParam, options)
                      .map((res:Response)=> res.json())
                      .catch(this.handleErrorNoChange.bind(this));
      
      }

    private handleErrorNoChange (error: any) {

      let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    
      this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
      return Observable.throw(errMsg);
    }

    public consoleLog(message : string){
      if(Config.loggingflag){
        console.log(message);
      }
    }

}