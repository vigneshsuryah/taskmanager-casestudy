import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Config } from '../index';
import { RouterModule , Router } from '@angular/router';
import { User } from '../models/user';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class AuthenticationService {
    public token: string;
    private _userData: BehaviorSubject<User> = new BehaviorSubject(new User());
    public readonly userDetails: Observable<User> = this._userData.asObservable();

    constructor(private http: Http, private router : Router, private currentUser: User) {
        this.token = "";
    }

    login(): Observable<boolean> {
        return this.http.post(Config.API + 'csr/secure/generateTokenCSR', JSON.stringify({ }))
            .map((response: Response) => {
                let token = response.json() && response.json().authToken;
                let userName = response.json() && response.json().userName;
                let userDn = response.json() && response.json().userDn;
                let userRole = response.json() && response.json().userRole;
                let firstName = response.json() && response.json().firstName;
                let lastName = response.json() && response.json().lastName;
                let rules = response.json() && response.json().rules;

                if (token) {

                    this.token = token;

                    this.currentUser.username = userName;
                    this.currentUser.userDn = userDn;
                    this.currentUser.token = token;
                    this.currentUser.userRole = userRole;
                    this.currentUser.firstName = firstName;
                    this.currentUser.lastName = lastName;
                    this.currentUser.rules = rules;

                    this._userData.next(Object.assign({}, this.currentUser));
                    
                    return true;
                } else {
                    return false;
                }
            }).catch(this.handleError);
    }

    logout(): void {
        this.token = null;
        this.currentUser = null;
    }

    private handleError (error: any) {
      window.location.href='/CSR/public/login.html';

      let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';

       return Observable.throw(errMsg);
    }

}
