import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Config } from '../index';
import { User } from '../../shared/models/user';
import { QueryModel } from '../../shared/models/reports/query.model';

@Injectable()
export class ReportsService {

    searchCriteria: QueryModel;
    isEdit: boolean = false;
    orderId: string;
    transactionStatus: string;

    constructor(private http: Http, private currentUser: User) {}

    getThirdPartyPayerDetails (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });    
        let options = new RequestOptions({ headers: headers });    
        return this.http.post(Config.API+"csr/secure/reports/getRegistrationDetail", inputParam, options)
        .map((res: Response) => res.json())
        .catch(this.handleErrorNoChange.bind(this));
    }

    getCashPaymentDetails (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });    
        let options = new RequestOptions({ headers: headers });    
        return this.http.post(Config.API+"csr/secure/reports/getCashPayDetails", inputParam, options)
        .map((res: Response) => res.json())
        .catch(this.handleErrorNoChange.bind(this));
    }

    getTransactionDetails (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });    
        let options = new RequestOptions({ headers: headers });    
        return this.http.post(Config.API+"csr/secure/reports/getRegistrationDetail", inputParam, options)
        .map((res: Response) => res.json())
        .catch(this.handleErrorNoChange.bind(this));
    }

    getReports(inputParam:{}): Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });
        let options = new RequestOptions({ headers: headers });  
        return this.http.post(Config.NodeAPI+"getreports", inputParam, options)
            .map((res: Response) => res.json())
            .catch(this.handleErrorNoChange.bind(this));
    }

    getQueryResults(inputParam: {}): Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(Config.NodeAPI+"getQueryResults", inputParam, options)
            .map((res: Response) => res.json())
            .catch(this.handleErrorNoChange.bind(this));
    }

    getConfirmationDetails(orderId: string, status: string) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });
        let queryParam = new URLSearchParams();
        queryParam.append('orderId', orderId);
        queryParam.append('status', status);
        return this.http.get(Config.NodeAPI+"getQueryDetailedResults", { search: queryParam, headers: headers  })
            .map((res: Response) => res.json())
            .catch(this.handleErrorNoChange.bind(this));
    }

    getAdhocReports(inputParam: {}): Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(Config.NodeAPI+"getAdhocReportList", inputParam, options)
            .map((res: Response) => res.json())
            .catch(this.handleErrorNoChange.bind(this));
    }

    private handleErrorNoChange (error: any) {
        let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';

        this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
        return Observable.throw(errMsg);
    }

    public consoleLog(message : string){
        if(Config.loggingflag){
            console.log(message);
        }
    }
}