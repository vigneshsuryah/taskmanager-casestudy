import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[expiry-date-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => ExpirationDateValidatorDirective), multi: true }
  ]
})
export class ExpirationDateValidatorDirective implements Validator {

  validate(c: FormControl) {
        if (!c.value || typeof c.value === 'undefined') {
            return null;
        }

    let result: any = {};

    if (this.validateDate(c)) {
      result.validateDate = true;
    }     
    
    return result;
    }



   private validateDate(c: FormControl): any {
    let val = c.value;
    var filter = new RegExp("(0[1-9]|10|11|12)/(201[5-9]|20[2-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})");
    if(filter.test(val))
    {
        var currentdate = new Date();
        let currentMonth = currentdate.getMonth();
        currentMonth = currentMonth + 1;
        let currentYear = currentdate.getFullYear();
        
        let split = val.split('/');
        var month = parseInt(split[0]);
        var year = parseInt(split[1]);
        
        if(year < currentYear){
            return true;
        }else if(year == currentYear && month < currentMonth){
            return true;
        }

        return false;
    }
    else
    {
        return true;
    }
  }

}
