import { PaymentMethod } from './paymentmethod.model';

export class UpdatePayResponse {
  bankAccountDetails: PaymentMethod;
  creditCardDetails: PaymentMethod;
  message: {
    messageCode: string,
    messageText: string
  };
}
