export class GetPayRequest {
  healthCardId: string;
}
