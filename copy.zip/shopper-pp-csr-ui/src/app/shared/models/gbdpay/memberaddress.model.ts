export class MemberAddress {
  addressLine1: string;
  city: string;
  state: string;
  postalCode: string;
}
