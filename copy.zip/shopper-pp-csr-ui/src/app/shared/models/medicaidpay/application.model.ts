import { PaymentSelection } from './paymentselection.model';

export class Application {
  acn: string;
  state: string;
  // applicationVersion: string;
  // formNo: string;
  // versionNo: string;
  // releaseNo: string;
  premiumAmt: number;
  brandName: string;
  applicationType = 'PAYMENT';
  reqEffDate: string;
  accessControlList = [
    {
      accessType: 'OWNER',
      user: {
        userId: 'OLS',
        shopperRole: 'CONSUMER'
      }
    }
  ];
  applicant = [];
  aptcAttestationPersons = [];
  paymentSelection: PaymentSelection;
  action: string;
  createPartnerId: string;
  exchTransactionId: string;
  // lastUpdatedId: string;
  // appSource: string;
  // ipAddress: string;
}
