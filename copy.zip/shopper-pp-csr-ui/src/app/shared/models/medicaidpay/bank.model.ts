export class Bank {
  id: number;
  action: string;
  accountNo: string;
  routingNo: string;
  accountType: string;
  accountHolderName: string;
  isRecurring: string;
}
