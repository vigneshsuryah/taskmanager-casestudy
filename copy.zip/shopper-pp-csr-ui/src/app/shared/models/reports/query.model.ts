export class QueryModel {

    fromdate: string;
    todate: string;
    orderId : string = '';
    memberBillingId: string = '';
    routingNo: string = '';
    accountNo: string = '';
    ccBinNo: string = '';
    ccLastFourDigits: string = '';
    fundingName: string = '';
    totDbtCdt: string = '';
    emailAddr: string = '';
    loginPayment: string = '';
    achType: string = '';
    ccType: string = '';
    dateType: string = '';
    
}