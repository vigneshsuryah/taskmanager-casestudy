export class AdhocModel {
    fromdate: string;
    todate: string;
    routingNo: string = '';
    accountNo: string = '';
    ccBinNo: string = '';
    ccLastFour: string = '';
    marketSegment: string = '';
    marketLevel: string = '';
    legalEntity: string = '';
    paymentChannel: string = '';
    system: string = '';
    chaseTD: string = ''; 
    dateType: string = '';
}