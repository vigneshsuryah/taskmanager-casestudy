export class Exception {
    type?: string;
    code?: string;
    message?: string;
    detail?: string;
}
export class ValidateRoutingNo {
    valid?: boolean;
    exceptions?: Array<Exception>
}