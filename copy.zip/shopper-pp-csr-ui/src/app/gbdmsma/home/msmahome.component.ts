import { MSMAServiceObject } from './../../shared/models/msma/msmaaccountsummary.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsmaCsrHttpService } from '../../shared/csr-service/msma.service';
import { User } from '../../shared/models/index';
declare var jQuery: any;
declare var PIE: any;

/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: "csr-msmahome",
  templateUrl: "msmahome.component.html"
})
export class MSMAHomeComponent implements OnInit {
  memberPaySearchModel = {
    hcid: "",
    id: "",
    firstname: "",
    lastname: "",
    dob: "",
    amt: ""
  };
  unableToLocateHcid: boolean = false;
  unauthorizedAccess: boolean =  false;
  isExactLength: boolean = true;
  hasHcid: boolean = true;
  screenLoader: boolean;
  techerror: boolean = false;

  constructor(public _user:User, public _router: Router, private _service: MsmaCsrHttpService) {
    if(this._user.userRole === undefined){
      this._router.navigate(['']);
    }
  }

  ngOnInit() {
    this._service.automaticPayments = null;
    this._service.hcid = null;
    this._service.selectedMethod = null;
    this._service.selectProductId = null;
    this._service.selectedPlansForPayment = null;
    this.unableToLocateHcid = false;
    this.unauthorizedAccess = false;
  }

  memberPaySearch(hcid: string) {
    if (hcid.length == 0) {
      this.hasHcid = false;
      this.isExactLength = true;
      this.techerror = false;
    } else if (hcid.length > 9 || hcid.length < 8) {
      this.isExactLength = false;
      this.hasHcid = true;
      this.techerror = false;
    } else {
      this.isExactLength = true;
      this.hasHcid = true;
      this.validateMember(hcid);
    }
  }

  validateMember(hcid: string) {
    this.screenLoader = true;
    this.techerror = false;
    let inputParam = {
      healthCardId: hcid
    };
    this._service.getdetailsforcsr(inputParam, "getAccountSummary").subscribe((data: any) => {
        if(null !== data.exceptions && undefined !== data.exceptions && data.exceptions.length > 0) {
          if(data.exceptions[0].code == 9000) {
            this.unableToLocateHcid = true;
          } else if(data.exceptions[0].code == 9011) {
            this.unauthorizedAccess = true;
          }
          this.screenLoader = false;
        } else {
          this.unableToLocateHcid = false;
          this.unauthorizedAccess = false;
          this._service.hcid = hcid;
          this._service.accountSummaryObject = data;
          this._service.selectedMethod = "AS";
          this.screenLoader = false;
          this._router.navigate(["/gbdmsma/paymentmethod"]);
        }
      },
      (err: any) => {
        this.screenLoader = false;
        this.techerror = true;
      }
    );
  }

  clearHcid() {
    jQuery("#hcid").val("");
    this.hasHcid = true;
    this.isExactLength = true;
    this.techerror = false;
  }
}
