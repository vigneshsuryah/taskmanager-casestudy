import { MsmaCsrHttpService } from './../shared/csr-service/msma.service';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';

import { MwpCsrHttpService } from '../shared/csr-service/mwp.csr.service';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { UxModule } from '../shared/ux.module';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { MSMAHomeComponent } from './home/msmahome.component';
import { MSMAManagePaymentComponent } from './managepayment/msmamanagepayment.component';
import { MSMAAccountSummaryComponent } from './managepayment/msmaaccountsummary/msmaaccountsummary.component';
import { MSMAOneTimePaymentComponent } from './managepayment/msmaaccountsummary/msmaonetimepayment/msmaonetimepayment.component';
import { routes } from './gbdmsma.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [
    DatePipe,
    MsmaCsrHttpService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [
    MSMAHomeComponent,
    MSMAManagePaymentComponent,
    MSMAAccountSummaryComponent,
    MSMAOneTimePaymentComponent
  ]
})
export class GbdMSMAModule {}
