import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLoadingComponent } from './apploading/apploading.component';
import { RootHomeLoadingComponent } from './roothome/roothome.component';
import { AuthGuard } from './shared/guards/index';

const approutes: Routes = [
  {
    path: '',
    component: AppLoadingComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'roothome',
    component: RootHomeLoadingComponent
  },
  {
    path: 'ipp',
    loadChildren: 'app/ipp/ipp.module#IPPModule'
  },
  {
    path: 'medicaidpay',
    loadChildren: 'app/medicaidpay/medicaidpay.module#MedicaidPayModule'
  },
  {
    path: 'memberpay',
    loadChildren: 'app/indvmemberpay/indvmemberpay.module#IndvMemberPayModule'
  },
  {
    path: 'gbdpay',
    loadChildren: 'app/gbdpay/gbdpay.module#GbdPayModule'
  },
  {
    path: 'dashboard',
    loadChildren: 'app/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'reports',
    loadChildren: 'app/reports/reports.module#ReportsModule'
  },
  {
    path: 'research',
    loadChildren: 'app/research/research.module#ResearchModule'
  },
   {
    path: 'wgs',
    loadChildren: 'app/wgs/wgs.module#WgsModule'
  },
  {
    path: 'gbdmsma',
    loadChildren: 'app/gbdmsma/gbdmsma.module#GbdMSMAModule'
  },
  {
    path: 'refund',
    loadChildren: 'app/refund/refund.module#RefundModule'
  },
  {
    path: 'feedback',
    loadChildren: 'app/feedback/feedback.module#FeedbackModule'
  },
  {
    path: 'superuser',
    loadChildren: 'app/superuser/superuser.module#SuperUserModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(approutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
