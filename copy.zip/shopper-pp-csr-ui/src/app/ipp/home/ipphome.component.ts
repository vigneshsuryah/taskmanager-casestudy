import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
import { IppHttpService } from  '../../shared/csr-service/ipphttp.service';
import { Ippcsr } from '../../shared/models/ipp/ippcsr';
import { CsrPaymentService } from '../../shared/csr-service/csrpayment.service';
declare var jQuery:any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-ipphome',
  templateUrl: 'ipphome.component.html'
})
export class IPPHomeComponent implements OnInit {

  searchModel = {
    'applicantId':'',
    'firstname':'',
    'lastname':'',
    'dob':'',
    'ssn':'',
    'state':''
  }

  applicationResponse: any;
  filteredSearchResults: any = [];
  filteredOnlineResults: any = [];
  inputParam: any = '';
  content : any ={};
  invalidSelection : boolean = false;
  screenLoader: boolean = false;
  hasResult: boolean = false;
  isOnlineFlow : boolean = false;
  totalAmountOwed : number = 0;
  searchAppResponse: any;
  displayInActiveApp: boolean = false;
  searchRsltErrMsg: string = '';
  inActiveApplicationFlag: boolean = false;
  billingAddress: any = {};
  isValidAcn: boolean = false;
  isAdvancedSearch: boolean = false;
  paymentTrackingInfo: any = {};
  pmtTrackingIdsforAcnflow : any = [];
  premiumAmt: string;

  constructor (public router : Router, private currentUser: User, private ippHttpService:IppHttpService, private ippcsr: Ippcsr, private csrPaymentService : CsrPaymentService) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit(){
    this.content = content;
    this.isAdvancedSearch = false;
    jQuery('#advSearch').hide(); 
    jQuery('.datepicker').datepicker({
      format: 'mm/dd/yyyy',
      startDate: '-3d',
      autoclose: true
    });  
  }

  simpleSearch(searchModel : any) {
    this.hasResult = false;
    this.ippcsr.premiumAmt = '';
    this.premiumAmt = '';
    this.ippcsr.applicantId = jQuery.trim(searchModel.applicantId);
    this.ippcsr.applicationResponse = {};
    let channel = this.resolveChannel(searchModel.applicantId);
    this.ippcsr.channel = channel;
    if (channel === '') {
      this.searchRsltErrMsg = 'Please enter a valid Applicant ID';
      jQuery('#searchResultErrModal').click();
    } else {
      this.screenLoader = true;
      if (channel === 'PAPER') {
        this.inputParam = {
          "hcid": jQuery.trim(searchModel.applicantId),
          "partnerId": "MAPS"
        }
        // call searchPayment
        this.searchMAPSPayment(this.inputParam);
      } else if (channel === 'ENROLL') {
        this.inputParam = {
          "wemId": jQuery.trim(searchModel.applicantId),
          "partnerId": "HCENTIVE"
        }
        this.searchApplication(this.inputParam);
      } else if (channel === 'ONLINE') {
        this.inputParam = {
          "acn": jQuery.trim(searchModel.applicantId),
          "partnerId": "OLS"
        }
        this.getApplication(this.inputParam);
      } 
    }
  }

  displaySearchResults() {
    this.hasResult = true;
    jQuery('html,body').animate({ scrollTop: jQuery("#advSearchResult").offset().top - jQuery("#advSearchResult").height() + 140 }, 'slow');
  }

  toggleAdvancedSearch(){
    if(jQuery('#advSearchIcon').hasClass('fa-caret-right')){
      this.isAdvancedSearch = true;
      this.searchModel.applicantId = '';
      jQuery('#show-adv-search').html('Hide Advanced Search');
      jQuery('#advSearchIcon').removeClass('fa-caret-right').addClass('fa-caret-down');
    } else {
      this.isAdvancedSearch = false;
      jQuery('#show-adv-search').html('Show Advanced Search');
      jQuery('#advSearchIcon').removeClass('fa-caret-down').addClass('fa-caret-right');
    }
    jQuery('#advSearch').slideToggle();
  }

  advancedSearch(searchModel: any) {
    if (!searchModel.ssn && (!searchModel.firstname || !searchModel.lastname || !searchModel.dob)) {
      this.invalidSelection = true;
    } else {
      this.invalidSelection = false;
      this.hasResult = true;
      this.toggleAdvancedSearch();
      jQuery('html,body').animate({ scrollTop: jQuery("#advSearchResult").offset().top - jQuery("#advSearchResult").height() - 30 }, 'slow');
    }
  }

  goToPaymentOptions(){
    this.router.navigate(['/ipp/paymentoptions']);
  }

  private resolveChannel(acn: any) {
    let alphaNumericRegex =  /^[0-9a-zA-Z]+$/;
      if (acn.length == 9 && acn.charAt(3)) {
        return 'PAPER';
      } else if (acn != '' && !isNaN(acn)) {
        return 'ENROLL';
      } else if (acn.length == 15 && acn.match(alphaNumericRegex)) {
        return 'ONLINE';
      } else {
        return '';
      }
  }

  getApplication(inputParam: any) {
    this.isOnlineFlow = true;
    this.inActiveApplicationFlag = false;
    this.filteredOnlineResults = [];
    this.billingAddress = {};
    this.ippHttpService.getApplication(inputParam).subscribe((data: any) => {
      this.applicationResponse = data.application;
      if (this.applicationResponse !== null && this.applicationResponse !== undefined) {
        this.ippcsr.applicationResponse = data.application;
        this.validateApplication(this.ippcsr.applicationResponse)
        if (this.isValidAcn) {
          this.premiumAmt = this.formatPremiumAmount(this.ippcsr.applicationResponse.premiumAmt);
          this.ippcsr.premiumAmt = this.premiumAmt;
          this.findDemographics(this.ippcsr.applicationResponse);
          this.findBillingAddress(this.ippcsr.applicationResponse);
          this.filterGetApplicationResponse(this.ippcsr.applicationResponse);
          if (!this.isEmptyObject(this.ippcsr.applicationResponse)) {
            this.populatePmtTrackingIdsForOnlineFlow(this.ippcsr.applicationResponse);
            this.filteredOnlineResults.push(this.ippcsr.applicationResponse);
            this.screenLoader = false;
            this.displaySearchResults();
          } else {
            this.displaySearchErrMsg();
          }
        } else {
          this.displaySearchErrMsg();
        }
      } else {
        this.displaySearchErrMsg();
      }
    },
      (err: any) => {
        this.displaySearchErrMsg();
      });
  }

  displaySearchErrMsg() {
    this.screenLoader = false;
    this.searchRsltErrMsg = 'Unable to locate an application. Please provide another Applicant Id or use the Advanced Search option to find an application.';
    jQuery('#searchResultErrModal').click();
  }

  searchApplication(inputParam: any) {
    this.isOnlineFlow = false;
    this.filteredSearchResults = [];
    this.inActiveApplicationFlag = false;
    this.searchRsltErrMsg = 'Unable to locate an application. Please provide another Applicant Id or use the Advanced Search option to find an application.';
    this.ippHttpService.searchPayment(this.inputParam).subscribe((data: any) => {
      this.searchAppResponse = data.payments;
      this.filterSearchResultResponse(this.searchAppResponse);
      if (this.filteredSearchResults.length > 0) {
        this.screenLoader = false;
        this.displaySearchResults();
      } else {
        this.screenLoader = false;
        jQuery('#searchResultErrModal').click();
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('#searchResultErrModal').click();
      });
  }

  validateApplication(application: any) {
    this.isValidAcn = false;
    let applicationTypeVal = application.applicationType;
    let applicationStatusVal = application.applicationStatus.applicationStatus;
    let onExchangeCheckDays: number = 2;
    let offExchangeCheckDays: number = 15;
    let days = Math.floor((new Date().getTime() - application.lastUpdatedTS) / (1000 * 60 * 60 * 24))
    if (applicationTypeVal != null && applicationStatusVal != null) {
      if ((applicationTypeVal == 'ONEXCHANGE' && days <= onExchangeCheckDays && applicationStatusVal == 'EXCHACCEPTED')
        || (applicationTypeVal == 'OFFEXCHANGE' && days <= offExchangeCheckDays && applicationStatusVal == 'PAYMENTFAILED')
        || applicationTypeVal == 'PAYMENT' || applicationTypeVal == 'TRANSPLAN') {
        this.isValidAcn = true;
      }
    }
  }
  
  findDemographics(application: any) {
    let listOfApplicants = application.applicant;
    if (listOfApplicants.length > 0) {
      application.applicant = [];
      for (let applicant of listOfApplicants) {
        if (this.isPrimaryApplicant(applicant)) {
          application.applicant = applicant;
          this.ippcsr.applicationResponse = application;
          return;
        }
      }
    }
  }

  isPrimaryApplicant(applicant: any) {
    return applicant.demographic != null && applicant.demographic.relationshipType == 'APPLICANT';
  }

  findBillingAddress(application: any) {
    if (application !== null) {
      let addressList: any = [];
      addressList = application.applicant.address;
      if (addressList.length > 0) {
        for (let address of addressList) {
          if (address.addressType == 'BILLING') {
            this.billingAddress = address;
            return;
          } else {
            this.billingAddress = address;
          }
        }
      }
    }
  }

  filterGetApplicationResponse(application: any) {
    if (application !== null) {
      let applicant = application.applicant;
      application.applicant = [];
      if (!this.isEmptyObject(applicant) && !this.isEmptyObject(applicant.demographic)) {
        let applicantInfo = applicant.demographic;
        if (applicantInfo != null && !applicantInfo.lastname && !applicantInfo.firstname
          && applicant.address.length > 0) {
          let enrollmentStatus = application.applicationStatus.applicationStatus;
          if (!this.displayInActiveApp) {
            if (!!enrollmentStatus && (enrollmentStatus == "APPROVED"
              || enrollmentStatus == "ACTIVE" || enrollmentStatus == "PAYMENTFAILED")) {
              application.applicant = applicant;
              this.ippcsr.applicationResponse = application;
            } else {
              this.searchRsltErrMsg = "There are no Active applications available to display. Please Un-check the \"Display Active Application only\" checkbox and click Find to view results.";
            }
          } else {
            if (!!enrollmentStatus && !(enrollmentStatus == "APPROVED"
              || enrollmentStatus == "ACTIVE" || enrollmentStatus == "PAYMENTFAILED")) {
              this.inActiveApplicationFlag = true;
              application.applicant = applicant;
              this.ippcsr.applicationResponse = application;
            } else {
              application.applicant = applicant;
              this.ippcsr.applicationResponse = application;
            }
          }
        } else {
          this.ippcsr.applicationResponse = {};
        }
      } 
    }
  }
  
  filterSearchResultResponse(searchAppResponse: any) {
    if (searchAppResponse.length > 0) {
      for (let searchPayment of searchAppResponse) {
        if (searchPayment != null && !searchPayment.lastname && !searchPayment.firstname
          && !this.isEmptyObject(searchPayment.address)) {
          if (!this.displayInActiveApp) {
            if (!!searchPayment.enrollmentStatus && (searchPayment.enrollmentStatus == "APPROVED"
              || searchPayment.enrollmentStatus == "ACTIVE" || searchPayment.enrollmentStatus == "PAYMENTFAILED")) {
              this.filteredSearchResults.push(searchPayment);
            } else {
              this.searchRsltErrMsg = "There are no Active applications available to display. Please Un-check the \"Display Active Application only\" checkbox and click Find to view results.";
            }
          } else {
            if(!!searchPayment.enrollmentStatus && !(searchPayment.enrollmentStatus == "APPROVED"
              || searchPayment.enrollmentStatus == "ACTIVE" || searchPayment.enrollmentStatus == "PAYMENTFAILED")) {
              this.inActiveApplicationFlag = true;
              this.filteredSearchResults.push(searchPayment);
            } else {
              this.filteredSearchResults.push(searchPayment);
            }
          }
          this.premiumAmt = this.formatPremiumAmount(searchPayment.paymentdue);
          this.ippcsr.premiumAmt = this.premiumAmt;
        }
      }
      this.ippcsr.searchPaymentResponse = this.filteredSearchResults;
    }
  }

  openPaymentTrackingModal(paymentTrackingID: any) {
    this.populatePmtTrackingInfo(paymentTrackingID);
    jQuery('#pmtTrackingModalOpener').click()
  }

  populatePmtTrackingInfo(paymentTrackingID: any) {
    this.totalAmountOwed = 0;
    let paymentTrackingInfoList = this.filteredSearchResults[0].paymentTrackingInfoList;
    if (paymentTrackingInfoList.length > 0) {
      this.checkTotAmountOwed(paymentTrackingInfoList);
      for (let payment of paymentTrackingInfoList) {
        if (payment.paymentTrackingID == paymentTrackingID) {
          this.paymentTrackingInfo = payment;
        }
      }
    }
  }

  checkTotAmountOwed(paymentTrackingInfoList: any) {
    let amountDue = this.filteredSearchResults.paymentdue;
    if (paymentTrackingInfoList.length > 0 && amountDue > 0) {
      let paidAmt = 0;
      for (let paymentInfo of paymentTrackingInfoList) {
        if (paymentInfo.length > 0 && !paymentInfo.paymentTrackingID
          && paymentInfo.paymentStatus === "PAID") {
          paidAmt += paymentInfo.paidAmount;
        }
        let totalAmtOwed = amountDue + paidAmt;
        for (let paymentInfo of paymentTrackingInfoList) {
          if (paymentInfo.length > 0 && !paymentInfo.paymentTrackingID) {
            this.totalAmountOwed = totalAmtOwed;
          }
        }
      }
    }
  }

  populatePmtTrackingIdsForOnlineFlow(application: any) {
    this.pmtTrackingIdsforAcnflow = [];
    if (!this.isEmptyObject(application.paymentSelection)) {
      let paymentList = application.paymentSelection.initialPayment;
      if (paymentList.length > 0) {
        for (let payment of paymentList) {
          if (payment.paymentTrackingId !== '' && payment.paymentTrackingId !== null) {
            this.pmtTrackingIdsforAcnflow.push(payment.paymentTrackingId);
          }
        }
      }
    }
  }

  isEmptyObject(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  disablePayNowButton() {
    if (parseInt(this.ippcsr.premiumAmt.substring(1)) <= 0) {
      return true;
    } else if (this.inActiveApplicationFlag) {
      return true;
    } else {
      return false;
    }
  }

  toggleActiveApplication() {
    this.displayInActiveApp = !this.displayInActiveApp;
  }

  formatPremiumAmount(premiumAmt: number){
    var premium = premiumAmt.toString();
    if(null !== premium && undefined !== premium && undefined !== premium.split('.')){
        if (premium.split('.').length === 1) {
          return '$ ' + premium+'.00';
        } else if(premium.split('.').length > 1 && premium.split('.')[1].length === 1){
          return '$ ' + premiumAmt+'0';
        } else if (premium.split('.').length > 1 && premium.split('.')[1].length > 2) {
          return '$ ' + premium.substring(0,5);
        } else {
          return '$ ' + premium;
        }
    } else {
        return '$ ' + premium;
    }
  }

  searchMAPSPayment(inputParam: any) {
      this.isOnlineFlow = false;
      this.inActiveApplicationFlag = false;
      this.filteredSearchResults = [];
      this.searchRsltErrMsg = 'Unable to locate an application. Please provide another Applicant Id or use the Advanced Search option to find an application.';
      this.csrPaymentService.searchPayment(inputParam).subscribe((data: any) => {
          if (data.payments !== null && data.payments !== undefined) {
              this.searchAppResponse = data.payments;
              this.filterSearchResultResponse(this.searchAppResponse);
              if (this.filteredSearchResults.length > 0) {
                  this.screenLoader = false;
                  this.displaySearchResults();
              } else {
                  this.screenLoader = false;
                  jQuery('#searchResultErrModal').click(); //no active
              }
          } else {
              this.screenLoader = false;
              jQuery('#searchResultErrModal').click(); //invalid hcid
          }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('#searchResultErrModal').click(); //service error
      });
  }
}
