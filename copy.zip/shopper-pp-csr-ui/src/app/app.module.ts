import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppLoadingComponent } from './apploading/apploading.component';
import { RootHomeLoadingComponent } from './roothome/roothome.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { CommonutilsModule } from './commonutils/commonutils.module';
import { AuthGuard } from './shared/guards/index';
import { AuthenticationService } from './shared/csr-service/index';
import { RequestOptions, RequestMethod, Headers } from '@angular/http';
import { User } from './shared/models/user';
import { PaginationService } from './shared/pagination-service/pagination-service';


export class MyOptions extends RequestOptions {
  constructor() {
    super({
      method: RequestMethod.Get,
      headers: new Headers({
        'Content-Type': 'application/json'
      })
    });
  }
}

@NgModule({
  declarations: [
    AppComponent,
    AppLoadingComponent,
    RootHomeLoadingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule, 
    HttpClientModule, 
    FormsModule, 
    NgIdleKeepaliveModule.forRoot(), 
    CommonutilsModule.forRoot()
  ],
  providers: [
    AuthGuard, 
    AuthenticationService,
    User,
    {
      provide: RequestOptions,
      useClass: MyOptions
    },
    PaginationService
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
