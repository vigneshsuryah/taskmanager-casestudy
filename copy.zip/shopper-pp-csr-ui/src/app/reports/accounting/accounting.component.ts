import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { User } from '../../shared/models/user';
import { ReportsService } from '../../shared/csr-service/reports.service';
import { DatePipe } from '@angular/common'; 
import { Http } from '@angular/http';
import { content } from '../../shared/constants/constants';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-accounting',
  templateUrl: 'accounting.component.html',
  styleUrls: ['accounting.component.css']
})
export class AccountingComponent implements OnInit {

  accounting = {  
    'fromdate': this.datePipe.transform(new Date(), 'MM/dd/yyyy'),
    'todate': this.datePipe.transform(new Date(), 'MM/dd/yyyy'),
    'reportTypeSelected': 'DEFAULT',
    'dateType': 'DEFAULT'
  }
  showResults : boolean = false;
  enableSubmitButton : boolean = false;
  dateError : boolean = false;

  completedOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Accounting Report',
    useBom: false,
    noDownload: false,
    headers: ['Member Billing ID','Member Billing Name','Date/Time Initiated','Payment Amount','Fee','Total','Payment Date', 'PRF Date', 'Chase Order #','Payment Type','Payment Sub Type','Login ID for CSR - Payment','Transaction Division','Invoice Number','Product ID','Payment Channel','Group ID','3rd Party ID','Last four digits-funding']
  };
  
  reimbursedOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Accounting Report',
    useBom: false,
    noDownload: false,
    headers: ['Member Billing ID','Member Billing Name','Date/Time Initiated','Payment Amount','Fee','Total','Payment Date', 'PRF Date', 'Chase Order #','Payment Type','Payment Sub Type','Login ID for CSR - Payment','Transaction Division','Invoice Number','Product ID','Payment Channel','Group ID','3rd Party ID','Last four digits-funding','Reimbursement Date','Reimbursement Reason','Login ID for CSR - Refund']
  };

  returnsOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Accounting Report',
    useBom: false,
    noDownload: false,
    headers: ['Member Billing ID','Member Billing Name','Date/Time Initiated','Payment Amount','Fee','Total','Payment Date', 'PRF Date', 'Chase Order #','Payment Type','Payment Sub Type','Login ID for CSR - Payment','Transaction Division','Invoice Number','Product ID','Payment Channel','Group ID','3rd Party ID','Last four digits-funding','Return Date','Return Reason Code','Return Reason Code Description']
  };

  nocOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Accounting Report',
    useBom: false,
    noDownload: false,
    headers: ['NOC Date','Chase Transaction #','Confirm#(orderID)','Revised Transaction type','Revised Routing #','Revised Account #','Original Routing #','Original Account #']
  };

  noResults: boolean = true;
  techerror: boolean = false; 
  screenLoader: boolean = false;
  showTable: boolean = true;
  inputParam : any = {};
  queryResult : any = [];
  content: any = {};
  csvHeaderCOMM = ['No.','TPP Unique ID', 'First Name', 'Last Name', 'Email ID', 'Phone Number', 'Registration Date', 'Relationship Name', 'Relationship Type'];
  csvHeaderGBD = ['No.','TPP Unique ID', 'First Name', 'Last Name', 'Email ID', 'Phone Number', 'Registration Date', 'Organization Name', 'Organization Type'];

  reportTypeList = [{
      label: 'Select Report Type',
      value: 'DEFAULT'
    },{
      label: 'Completed Report',
      value: 'COMPLETED'
    },{
      label: 'Returned Report',
      value: 'RETURNED'
    }
  ];
  reportDetails : any = [];

  constructor(public router: Router, private currentUser: User, private reportsService : ReportsService, private datePipe: DatePipe, private http: Http) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {  
      this.noResults = true;
      this.techerror = false;
      this.enableSubmitButton = false;
      this.content = content;

      this.reportDetails = [];
   }

    updateFromDate(date) {
      this.accounting.fromdate = this.datePipe.transform(date, 'MM/dd/yyyy');
      this.resetSearchResults();
    }

    updateToDate(date) {
      this.accounting.todate = this.datePipe.transform(date, 'MM/dd/yyyy');
      this.resetSearchResults();
    }
    
    onChangeReportType(){
      setTimeout(()=>{
        this.resetSearchResults();
      },100);
    }

    selectDateType(){
      setTimeout(()=>{
        this.resetSearchResults();
      },100);
    }

    resetSearchResults(){
      if(this.accounting.reportTypeSelected === 'DEFAULT' || this.accounting.dateType === 'DEFAULT' || new Date(this.accounting.todate) < new Date(this.accounting.fromdate)){
        this.enableSubmitButton = false;
      }else{
        this.enableSubmitButton = true;
      }
      if(new Date(this.accounting.todate) < new Date(this.accounting.fromdate)){
        this.dateError = true;
      }else{
        this.dateError = false;
      }
      this.showResults = false;
    }

    clearSearch(){
      this.showResults = false;
      this.accounting = {  
        'fromdate': this.datePipe.transform(new Date(), 'MM/dd/yyyy') ,
        'todate': this.datePipe.transform(new Date(), 'MM/dd/yyyy') ,
        'reportTypeSelected': 'DEFAULT',
        'dateType':'DEFAULT'
      }
      this.enableSubmitButton = false;
    }

   getReportDetails(accounting) {

    this.reportDetails = [];
    this.queryResult = [];
    this.screenLoader = true;

    let inputParam = {
      'type': accounting.reportTypeSelected.toLowerCase(),
      'startDate': this.datePipe.transform(accounting.fromdate,'yyyy-MM-dd'),
      'endDate': this.datePipe.transform(accounting.todate,'yyyy-MM-dd'),
      'dateType': accounting.dateType
    }

    this.reportsService.getReports(inputParam).subscribe((result:any) => {
      this.queryResult = result;
      var temp = {};
      if(result.success) {
        for (let transactions of result.data.transactionsList) {
          if(this.accounting.reportTypeSelected === 'NOC'){
            temp = {
              'nocDate': ("" !== transactions.nocDate && undefined !== transactions.nocDate) ? transactions.nocDate.substring(0,10) + ' ET' : "",
              'chaseOrderId': ("" !== transactions.chaseOrderId && undefined !== transactions.chaseOrderId) ? transactions.chaseOrderId : "",
              'orderId': ("" !== transactions.orderId && undefined !== transactions.orderId) ? transactions.orderId : "",
              'revisedTransactionType': ("" !== transactions.revisedTransactionType && undefined !== transactions.revisedTransactionType) ? transactions.revisedTransactionType : "",
              'revisedRouting': ("" !== transactions.revisedRouting && undefined !== transactions.revisedRouting) ? transactions.revisedRouting : "",
              'revisedAccount': ("" !== transactions.revisedAccount && undefined !== transactions.revisedAccount) ? transactions.revisedAccount : "",
              'originalRouting': ("" !== transactions.originalRouting && undefined !== transactions.originalRouting) ? transactions.originalRouting : "",
              'originalAccount': ("" !== transactions.originalAccount && undefined !== transactions.originalAccount) ? transactions.originalAccount : ""
            };
          } else if(this.accounting.reportTypeSelected === 'COMPLETED' || this.accounting.reportTypeSelected === 'PENDING' || this.accounting.reportTypeSelected === 'CANCELLED'){
              temp = {
                'account': ("" !== transactions.account && undefined !== transactions.account) ? transactions.account : "",
                'accountName': ("" !== transactions.accountName && undefined !== transactions.accountName) ? transactions.accountName : "",
                'dateTimeInitiated': ("" !== transactions.dateTimeInitiated && undefined !== transactions.dateTimeInitiated) ? transactions.dateTimeInitiated.substring(0,17) + ' ET' : "",
                'paymentAmount': ("" !== transactions.paymentAmount && undefined !== transactions.paymentAmount) ? this.formatAmount(transactions.paymentAmount) : "", 
                'fee': ("" !== transactions.fee && undefined !== transactions.fee) ? this.formatAmount(transactions.fee) : "", 
                'total': ("" !== transactions.total && undefined !== transactions.total) ? this.formatAmount(transactions.total) : "", 
                'paymentDate': ("" !== transactions.paymentDate && undefined !== transactions.paymentDate) ? transactions.paymentDate.substring(0,10) + ' ET' : "",
                'prfDate': ("" !== transactions.prfDate && undefined !== transactions.prfDate) ? transactions.prfDate.substring(0,10) + ' ET' : "",
                'chaseOrderId': ("" !== transactions.chaseOrderId && undefined !== transactions.chaseOrderId) ? transactions.chaseOrderId : "",
                'paymentType': ("" !== transactions.paymentType && undefined !== transactions.paymentType) ? transactions.paymentType : "",
                'paymentSubType': ("" !== transactions.paymentSubType && undefined !== transactions.paymentSubType) ? transactions.paymentSubType : "",
                'csrLoginId': ("" !== transactions.csrLoginId && undefined !== transactions.csrLoginId) ? transactions.csrLoginId : "",
                'system': ("" !== transactions.system && undefined !== transactions.system) ? transactions.system : "",
                'marketSegment': ("" !== transactions.marketSegment && undefined !== transactions.marketSegment) ? transactions.marketSegment : "",
                'legalEntity': ("" !== transactions.legalEntity && undefined !== transactions.legalEntity) ? transactions.legalEntity : "",
                'division': ("" !== transactions.transactionDivision && undefined !== transactions.transactionDivision) ? transactions.transactionDivision : "",
                'invoiceNo': ("" !== transactions.invoiceNo && undefined !== transactions.invoiceNo) ? transactions.invoiceNo : "",
                'productId': ("" !== transactions.productId && undefined !== transactions.productId) ? transactions.productId : "",
                'paymentChannel': ("" !== transactions.paymentChannel && undefined !== transactions.paymentChannel) ? transactions.paymentChannel : "",
                'groupId': ("" !== transactions.groupId && undefined !== transactions.groupId) ? transactions.groupId : "",
                'tppId': ("" !== transactions.tppId && undefined !== transactions.tppId) ? transactions.tppId : "",
                'lastDigitsFunding': ("" !== transactions.lastDigitsFunding && undefined !== transactions.lastDigitsFunding) ? transactions.lastDigitsFunding : "" 
              };
            } else if (this.accounting.reportTypeSelected === 'REIMBURSED'){
              temp = {
                'account': ("" !== transactions.account && undefined !== transactions.account) ? transactions.account : "",
                'accountName': ("" !== transactions.accountName && undefined !== transactions.accountName) ? transactions.accountName : "",
                'dateTimeInitiated': ("" !== transactions.dateTimeInitiated && undefined !== transactions.dateTimeInitiated) ? transactions.dateTimeInitiated.substring(0,17) + ' ET' : "",
                'paymentAmount': ("" !== transactions.paymentAmount && undefined !== transactions.paymentAmount) ? this.formatAmount(transactions.paymentAmount) : "", 
                'fee': ("" !== transactions.fee && undefined !== transactions.fee) ? this.formatAmount(transactions.fee) : "", 
                'total': ("" !== transactions.total && undefined !== transactions.total) ? this.formatAmount(transactions.total) : "", 
                'paymentDate': ("" !== transactions.paymentDate && undefined !== transactions.paymentDate) ? transactions.paymentDate.substring(0,10) + ' ET' : "",
                'prfDate': ("" !== transactions.prfDate && undefined !== transactions.prfDate) ? transactions.prfDate.substring(0,10) + ' ET' : "",
                'chaseOrderId': ("" !== transactions.chaseOrderId && undefined !== transactions.chaseOrderId) ? transactions.chaseOrderId : "",
                'paymentType': ("" !== transactions.paymentType && undefined !== transactions.paymentType) ? transactions.paymentType : "",
                'paymentSubType': ("" !== transactions.paymentSubType && undefined !== transactions.paymentSubType) ? transactions.paymentSubType : "",
                'csrLoginId': ("" !== transactions.csrLoginId && undefined !== transactions.csrLoginId) ? transactions.csrLoginId : "",
                'system': ("" !== transactions.system && undefined !== transactions.system) ? transactions.system : "",
                'marketSegment': ("" !== transactions.marketSegment && undefined !== transactions.marketSegment) ? transactions.marketSegment : "",
                'legalEntity': ("" !== transactions.legalEntity && undefined !== transactions.legalEntity) ? transactions.legalEntity : "",
                'division': ("" !== transactions.transactionDivision && undefined !== transactions.transactionDivision) ? transactions.transactionDivision : "",
                'invoiceNo': ("" !== transactions.invoiceNo && undefined !== transactions.invoiceNo) ? transactions.invoiceNo : "",
                'productId': ("" !== transactions.productId && undefined !== transactions.productId) ? transactions.productId : "",
                'paymentChannel': ("" !== transactions.paymentChannel && undefined !== transactions.paymentChannel) ? transactions.paymentChannel : "",
                'groupId': ("" !== transactions.groupId && undefined !== transactions.groupId) ? transactions.groupId : "",
                'tppId': ("" !== transactions.tppId && undefined !== transactions.tppId) ? transactions.tppId : "",
                'lastDigitsFunding': ("" !== transactions.lastDigitsFunding && undefined !== transactions.lastDigitsFunding) ? transactions.lastDigitsFunding : "",
                'reimbursedDate': ("" !== transactions.reimbursedDate && undefined !== transactions.reimbursedDate) ? transactions.reimbursedDate.substring(0,10) + ' ET' : "",
                'reimbursedReason': ("" !== transactions.reimbursedReason && undefined !== transactions.reimbursedReason) ? transactions.reimbursedReason : "",
                'csrLoginIdReimbursed': ("" !== transactions.csrLoginIdReimbursed && undefined !== transactions.csrLoginIdReimbursed) ? transactions.csrLoginIdReimbursed : ""
              };
            } else if (this.accounting.reportTypeSelected === 'RETURNED'){
              temp = {
                'account': ("" !== transactions.account && undefined !== transactions.account) ? transactions.account : "",
                'accountName': ("" !== transactions.accountName && undefined !== transactions.accountName) ? transactions.accountName : "",
                'dateTimeInitiated': ("" !== transactions.dateTimeInitiated && undefined !== transactions.dateTimeInitiated) ? transactions.dateTimeInitiated.substring(0,17) + ' ET' : "",
                'paymentAmount': ("" !== transactions.paymentAmount && undefined !== transactions.paymentAmount) ? this.formatAmount(transactions.paymentAmount) : "", 
                'fee': ("" !== transactions.fee && undefined !== transactions.fee) ? this.formatAmount(transactions.fee) : "", 
                'total': ("" !== transactions.total && undefined !== transactions.total) ? this.formatAmount(transactions.total) : "", 
                'paymentDate': ("" !== transactions.paymentDate && undefined !== transactions.paymentDate) ? transactions.paymentDate.substring(0,10) + ' ET' : "",
                'prfDate': ("" !== transactions.prfDate && undefined !== transactions.prfDate) ? transactions.prfDate.substring(0,10) + ' ET' : "",
                'chaseOrderId': ("" !== transactions.chaseOrderId && undefined !== transactions.chaseOrderId) ? transactions.chaseOrderId : "",
                'paymentType': ("" !== transactions.paymentType && undefined !== transactions.paymentType) ? transactions.paymentType : "",
                'paymentSubType': ("" !== transactions.paymentSubType && undefined !== transactions.paymentSubType) ? transactions.paymentSubType : "",
                'csrLoginId': ("" !== transactions.csrLoginId && undefined !== transactions.csrLoginId) ? transactions.csrLoginId : "",
                'system': ("" !== transactions.system && undefined !== transactions.system) ? transactions.system : "",
                'marketSegment': ("" !== transactions.marketSegment && undefined !== transactions.marketSegment) ? transactions.marketSegment : "",
                'legalEntity': ("" !== transactions.legalEntity && undefined !== transactions.legalEntity) ? transactions.legalEntity : "",
                'division': ("" !== transactions.transactionDivision && undefined !== transactions.transactionDivision) ? transactions.transactionDivision : "",
                'invoiceNo': ("" !== transactions.invoiceNo && undefined !== transactions.invoiceNo) ? transactions.invoiceNo : "",
                'productId': ("" !== transactions.productId && undefined !== transactions.productId) ? transactions.productId : "",
                'paymentChannel': ("" !== transactions.paymentChannel && undefined !== transactions.paymentChannel) ? transactions.paymentChannel : "",
                'groupId': ("" !== transactions.groupId && undefined !== transactions.groupId) ? transactions.groupId : "",
                'tppId': ("" !== transactions.tppId && undefined !== transactions.tppId) ? transactions.tppId : "",
                'lastDigitsFunding': ("" !== transactions.lastDigitsFunding && undefined !== transactions.lastDigitsFunding) ? transactions.lastDigitsFunding : "",
                'returnDate': ("" !== transactions.returnDate && undefined !== transactions.returnDate) ? transactions.returnDate.substring(0,10) + ' ET' : "",
                'returnReasonCode': ("" !== transactions.returnCode && undefined !== transactions.returnCode) ? transactions.returnCode.substring(0,3) : "",
                'returnReason': ("" !== transactions.returnDescription && undefined !== transactions.returnDescription) ? transactions.returnDescription : ""
              };
            }
          this.reportDetails.push(temp);
        }
      }

      this.screenLoader = false;
      this.showResults = true;

      setTimeout(()=>{
        if (jQuery.fn.dataTable.isDataTable('#reports-table')) {
          jQuery('#reports-table').DataTable();
        } else {
          jQuery('#reports-table').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [ 5, 10, 15, 20 ],
            "dom":'f<"table-div-wrapper"t><"clear"lip>',
            "language": {
              "search":"",
              "searchPlaceholder": "Search for a record",
              "paginate": {
                "previous": "Previous",
                "next": "Next",
                "first": "First",
                "last": "Last"
              }
            }
          });
        }
       
        // setting width internally
        var widthOfTable = jQuery("#reports-table_wrapper").width();
        jQuery(".table-div-wrapper").width(widthOfTable);
      },100);

      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
  }

   downloadReport(){
     if(this.reportDetails.length > 0){
        if (this.accounting.reportTypeSelected === 'COMPLETED'){
            new Angular5Csv(this.reportDetails, "completed-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.completedOptions);
        }else if (this.accounting.reportTypeSelected === 'PENDING'){
          new Angular5Csv(this.reportDetails, "pending-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.completedOptions); 
        }else if (this.accounting.reportTypeSelected === 'CANCELLED'){
          new Angular5Csv(this.reportDetails, "cancelled-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.completedOptions);
        }else if (this.accounting.reportTypeSelected === 'REIMBURSED'){
            new Angular5Csv(this.reportDetails, "reimbursed-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.reimbursedOptions);
        } else if (this.accounting.reportTypeSelected === 'RETURNED'){
            new Angular5Csv(this.reportDetails, "returned-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.returnsOptions);
        } else if (this.accounting.reportTypeSelected === 'NOC'){
            new Angular5Csv(this.reportDetails, "noc-payments-transaction-report-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.nocOptions);
        }
     }
   }

   formatAmount(amount: number){
     if(amount != undefined && amount.toString().indexOf('.') == -1){
        return '$' + amount + '.00';
     } else if (amount != undefined && amount.toString().indexOf('.') > 0){
        let amtArr = amount.toString().split('.');
        if(amtArr[1].length === 1){
          return '$' + amount + '0';
        } else if (amtArr[1].length === 2){
          return '$' + amount;
        }
     }
   }

}
