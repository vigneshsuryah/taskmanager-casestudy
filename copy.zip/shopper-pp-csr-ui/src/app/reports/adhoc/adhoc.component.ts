import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'; 
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
import { AdhocModel } from '../../shared/models/reports/adhoc.model';
import { ReportsService } from '../../shared/csr-service/reports.service';

declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-adhoc',
  templateUrl: 'adhoc.component.html',
  styleUrls: ['adhoc.component.css']
})
export class AdhocComponent implements OnInit {

  screenLoader: boolean = false;
  techerror: boolean = false;
  dateError: boolean = false;
  isNotInRange: boolean = false;
  showResults: boolean = false;
  hasDateType: boolean = false;
  selectedStatus: any = [];
  selectedTypes: any = [];
  selectedCCPayment: any = [];
  selectedACHPayment: any = [];
  selectedBank: any = [];
  selectedBankAccount: any = [];
  selectedMarketLevel: any = [];
  selectedSystem: any = [];
  adhocDetailsList: any = [];
  reportDetails: any = [];
  content: any = {};
  adhocDetails: any = {};
  dropdownSettings: any = {};
  systemDropdownSettings: any = {};
  adhocModel: AdhocModel;

  options = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Ad hoc Report',
    useBom: false,
    noDownload: false,
    headers: ['Member Billing name','Member Billing ID','Group Number','System','Legal Entity','Market Segment','Market Level(Summary)','Date / Time initiated','Payment Channel','US Domain of processor','Premium Amount','Fee Amount','Total Debit/Credit','Transaction Status','Product Identifier','Notification Indicator','Payment Type','Payment Sub type','Credit Card BIN Number','Credit Card last four digits','Interchange Qualification Code','Bank Routing Number','Bank Account Number','Name on Funding Account','Anthem Depositing Bank','Anthem Bank Account (last four digits)','Transaction Type','Chase TD','Anthem Divsion','Anthem Order ID (Chase identifier)','Pay Date','PRF Date','Deposit Date','Journal ID']
  };

  constructor(public router: Router, private currentUser: User, private datePipe: DatePipe, private reportsService : ReportsService,) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {  

      this.content = content;
      this.adhocModel = new AdhocModel();
      this.adhocModel.fromdate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      this.adhocModel.todate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      this.selectedStatus = [];
      this.selectedTypes = [];
      this.selectedACHPayment = [];
      this.selectedCCPayment = [];
      this.selectedBank = [];
      this.selectedBankAccount = [];
      this.selectedMarketLevel = [];
      this.selectedSystem = [];
      
      this.dropdownSettings = { 
        singleSelection: false, 
        text:"Select",
        selectAllText:'Select All',
        unSelectAllText:'Select None',
        enableSearchFilter: true,
        classes:"myclass custom-class"
      };   
      
      this.systemDropdownSettings = { 
        singleSelection: false, 
        text:"Select",
        enableSearchFilter: true,
        classes:"myclass custom-class",
        limitSelection: 2,
        disabled: false
      };

    }

    getAdhocDetails(adhocModel: AdhocModel){

      this.adhocDetailsList = [];
      this.techerror = false;
      this.showResults = false;
      this.dateError = false;
      this.isNotInRange = false;
      this.screenLoader = true;

      //let jsonpath = 'assets/data/adhocdetails.json'; 

      let inputParams = {
        "routingNo":adhocModel.routingNo,
        "accountNo":adhocModel.accountNo,
        "ccBinNo":adhocModel.ccBinNo,
        "ccLastFour":adhocModel.ccLastFour,
        "marketSegment": "" !== adhocModel.marketSegment && 'default' !== adhocModel.marketSegment ? adhocModel.marketSegment : "",
        "legalEntity": "" !== adhocModel.legalEntity && 'default' !== adhocModel.legalEntity ? adhocModel.legalEntity : "",
        "paymentChannel": "" !== adhocModel.paymentChannel && 'default' !== adhocModel.paymentChannel ? adhocModel.paymentChannel : "",
        "system":this.selectedSystem,
        "transactionDiv": "" !== adhocModel.chaseTD && 'default' !== adhocModel.chaseTD ? adhocModel.chaseTD : "",
        "fromdate":this.datePipe.transform(adhocModel.fromdate,'yyyy-MM-dd'),
        "todate":this.datePipe.transform(adhocModel.todate,'yyyy-MM-dd'),
        "selectedStatus":this.selectedStatus,
        "selectedTypes":this.selectedTypes,
        "selectedACHPayment":this.selectedACHPayment,
        "selectedCCPayment":this.selectedCCPayment,
        "selectedBank":this.selectedBank,
        "selectedBankAccount":this.selectedBankAccount,
        "selectedMarketLevel":this.selectedMarketLevel,
        "dateType":adhocModel.dateType
      }

      this.reportsService.getAdhocReports(inputParams).subscribe((result:any) => {
      //this.reportsService.getAdhocReportsMock(jsonpath).subscribe((result:any) => {
        this.screenLoader = false;
        if(result.success){
          this.showResults = true;
          this.adhocDetailsList = result.data;
          //this.adhocDetailsList = result.adhocDetailsList;
          this.reportDetails = this.formatReportResponse(this.adhocDetailsList);
  
          setTimeout(()=>{
            if (jQuery.fn.dataTable.isDataTable('#reports-table')) {
              jQuery('#reports-table').DataTable();
            } else {
              jQuery('#reports-table').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [ 5, 10, 15, 20 ],
                "dom":'f<"table-div-wrapper"t><"clear"lip>',
                "language": {
                  "search":"",
                  "searchPlaceholder": "Search for a record",
                  "paginate": {
                    "previous": "Previous",
                    "next": "Next",
                    "first": "First",
                    "last": "Last"
                  }
                }
              });
            }
            
            // setting width internally
            var widthOfTable = jQuery("#reports-table_wrapper").width();
            jQuery(".table-div-wrapper").width(widthOfTable);
          },100);
  
          jQuery('html,body').animate({ scrollTop: jQuery("#reports-div").offset().top - jQuery("#reports-div").height()}, 'slow');
        }else {
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
        }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
      
    }

    openDetails(orderId: any){
      this.adhocDetails = {};
      for(let adhocDetails of this.adhocDetailsList){
        if(adhocDetails.anthem_order_id === orderId){
          this.adhocDetails = adhocDetails;
          jQuery('#adhocDetailsModalOpener').click();
        }
      }
    }

    formatReportResponse(adhocDetailsList: any){
      let formattedDetailsList = [];
      
      for(let adhocDetails of adhocDetailsList){
        let formattedDetails = {
          "Member Billing name": "" !== adhocDetails.member_billing_name && undefined !== adhocDetails.member_billing_name ? adhocDetails.member_billing_name : "",
          "Member Billing ID": "" !== adhocDetails.member_billing_id && undefined !== adhocDetails.member_billing_id ? "'"+adhocDetails.member_billing_id+"'" : "",
          "Group Number": "" !== adhocDetails.group && undefined !== adhocDetails.group ? "'"+adhocDetails.group+"'" : "",
          "System": "" !== adhocDetails.system && undefined !== adhocDetails.system ? "'"+adhocDetails.system+"'" : "",
          "Legal Entity": "" !== adhocDetails.legal_entity && undefined !== adhocDetails.legal_entity ? "'"+adhocDetails.legal_entity+"'" : "",
          "Market Segment": "" !== adhocDetails.market_segment && undefined !== adhocDetails.market_segment ? "'"+adhocDetails.market_segment+"'" : "",
          "Market Level(Summary)": "" !== adhocDetails.market_level && undefined !== adhocDetails.market_level ? adhocDetails.market_level : "",
          "Date / Time initiated": "" !== adhocDetails.date_time_initiated && undefined !== adhocDetails.date_time_initiated ? adhocDetails.date_time_initiated.substring(0,17) + ' ET' : "",
          "Payment Channel": "" !== adhocDetails.payment_channel && undefined !== adhocDetails.payment_channel ? adhocDetails.payment_channel : "",
          "US Domain of processor": "" !== adhocDetails.login_id && undefined !== adhocDetails.login_id ? adhocDetails.login_id : "",
          "Premium Amount": "" !== adhocDetails.premimum && undefined !== adhocDetails.premimum ? this.formatAmount(adhocDetails.premimum) : "",
          "Fee Amount": "" !== adhocDetails.fee && undefined !== adhocDetails.fee ? this.formatAmount(adhocDetails.fee) : "",
          "Total Debit/Credit": "" !== adhocDetails.total && undefined !== adhocDetails.total ? this.formatAmount(adhocDetails.total) : "",
          "Transaction Status": "" !== adhocDetails.transaction_status && undefined !== adhocDetails.transaction_status ? adhocDetails.transaction_status : "",
          "Product Identifier": "" !== adhocDetails.product_identifier && undefined !== adhocDetails.product_identifier ? "'"+adhocDetails.product_identifier+"'" : "",
          "Notification Indicator": "" !== adhocDetails.notification_indicator && undefined !== adhocDetails.notification_indicator ? "'"+adhocDetails.notification_indicator+"'" : "",
          "Payment Type": "" !== adhocDetails.payment_type && undefined !== adhocDetails.payment_type ? adhocDetails.payment_type : "",
          "Payment Sub type": "" !== adhocDetails.payment_sub_type && undefined !== adhocDetails.payment_sub_type ? adhocDetails.payment_sub_type : "",
          "Credit Card BIN Number": "" !== adhocDetails.credit_card_bin && undefined !== adhocDetails.credit_card_bin && 'NA' !== adhocDetails.credit_card_bin ? "'"+adhocDetails.credit_card_bin+"'" : "NA",
          "Credit Card last four digits": "" !== adhocDetails.credit_card_last_four && undefined !== adhocDetails.credit_card_last_four && 'NA' !== adhocDetails.credit_card_last_four ? "'"+adhocDetails.credit_card_last_four+"'" : "NA",
          "Interchange Qualification Code": "" !== adhocDetails.qualification_code && undefined !== adhocDetails.qualification_code ? "'"+adhocDetails.qualification_code+"'" : "",
          "Bank Routing Number": "" !== adhocDetails.routing_number && undefined !== adhocDetails.routing_number && 'NA' !== adhocDetails.routing_number ? "'"+adhocDetails.routing_number+"'" : "NA",
          "Bank Account Number": "" !== adhocDetails.account_number && undefined !== adhocDetails.account_number && 'NA' !== adhocDetails.account_number ? "'"+adhocDetails.account_number+"'" : "NA",
          "Name on Funding Account": "" !== adhocDetails.name_on_funding_account && undefined !== adhocDetails.name_on_funding_account ? adhocDetails.name_on_funding_account : "",
          "Anthem Depositing Bank": "" !== adhocDetails.anthem_depositing_bank && undefined !== adhocDetails.anthem_depositing_bank ? adhocDetails.anthem_depositing_bank : "",
          "Anthem Bank Account (last four digits)": "" !== adhocDetails.anthem_bank_account && undefined !== adhocDetails.anthem_bank_account ? "'"+adhocDetails.anthem_bank_account+"'" : "",
          "Transaction Type": "" !== adhocDetails.transaction_type && undefined !== adhocDetails.transaction_type ? adhocDetails.transaction_type : "",
          "Chase TD": "" !== adhocDetails.chase_td && undefined !== adhocDetails.chase_td ? "'"+adhocDetails.chase_td+"'" : "",
          "Anthem Divsion": "" !== adhocDetails.anthem_division && undefined !== adhocDetails.anthem_division ? "'"+adhocDetails.anthem_division+"'" : "",
          "Anthem Order ID (Chase identifier)": "" !== adhocDetails.anthem_order_id && undefined !== adhocDetails.anthem_order_id ? "'"+adhocDetails.anthem_order_id+"'" : "",
          "Pay Date": "" !== adhocDetails.paid_date && undefined !== adhocDetails.paid_date ? adhocDetails.paid_date.substring(0,10) + ' ET' : "",
          "PRF Date": "" !== adhocDetails.prf_date && undefined !== adhocDetails.prf_date ? adhocDetails.prf_date.substring(0,10) + ' ET' : "",
          "Deposit Date": "" !== adhocDetails.deposit_date && undefined !== adhocDetails.deposit_date ? adhocDetails.deposit_date.substring(0,10) + ' ET' : "",
          "Journal ID": "" !== adhocDetails.journal_id && undefined !== adhocDetails.journal_id ? adhocDetails.journal_id : "",
        }
        formattedDetailsList.push(formattedDetails);
      } 
      return formattedDetailsList;
    }
    
    updateFromDate(date) {
      this.adhocModel.fromdate = this.datePipe.transform(date, 'MM/dd/yyyy');
      this.compareDates();
    }

    updateToDate(date) {
      this.adhocModel.todate = this.datePipe.transform(date, 'MM/dd/yyyy');
      this.compareDates();
    }

    compareDates(){
      this.dateError = false;
      this.isNotInRange = false;
      if(new Date(this.adhocModel.fromdate) > new Date(this.adhocModel.todate)){
        this.dateError = true;
      } else {
        let fromYear = this.adhocModel.fromdate.substring(6,10);
        let toYear = this.adhocModel.todate.substring(6,10);
        let fromMonth = this.adhocModel.fromdate.substring(0,2);
        let toMonth = this.adhocModel.todate.substring(0,2);
        let fromDay = this.adhocModel.fromdate.substring(3,5);
        let toDay = this.adhocModel.todate.substring(3,5);
      
        if(parseInt(toYear) > parseInt(fromYear)){
          if (((toMonth === '01' && (fromMonth === '12' || fromMonth === '11')) || (toMonth === '01' && fromMonth === '10' && toDay <= fromDay)) || 
          ((toMonth === '02' && (fromMonth === '01' || fromMonth === '12')) || (toMonth === '02' && fromMonth === '11' && toDay <= fromDay)) || 
          ((toMonth === '03' && (fromMonth === '01' || fromMonth === '02')) || (toMonth === '03' && fromMonth === '12' && toDay <= fromDay))){
            this.isNotInRange = false;
          } else {
            this.isNotInRange = true;
          }
        } else {
          if((parseInt(toMonth)-parseInt(fromMonth) < 3) || (parseInt(toMonth)-parseInt(fromMonth) === 3 && toDay <= fromDay)){
            this.isNotInRange = false;
          } else {
            this.isNotInRange = true;
          }
        } 
      }
    }

    downloadReport(){
      new Angular5Csv(this.reportDetails, "Adhoc-Reports-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.options);
    }

    clearFilter(){
      this.adhocModel = new AdhocModel();
      this.adhocModel.fromdate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      this.adhocModel.todate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      this.selectedStatus = [];
      this.selectedTypes = [];
      this.selectedACHPayment = [];
      this.selectedCCPayment = [];
      this.selectedBank = [];
      this.selectedBankAccount = [];
      this.selectedMarketLevel = [];
      this.selectedSystem = [];
      this.showResults = false;
      this.dateError = false;
      this.techerror = false;
      this.isNotInRange = false;
      this.hasDateType = false;
      this.systemDropdownSettings = { 
        disabled: false
      };
      jQuery("#legalEntity").find(".psButton").prop('disabled',false);  
      jQuery("#legalEntity").find(".psOption").prop('disabled',false);
      jQuery("#marketSegment").find(".psButton").prop('disabled',false);  
      jQuery("#marketSegment").find(".psOption").prop('disabled',false);
    }

    formatAmount(amount: number){
      if(amount != undefined && amount.toString().indexOf('.') == -1){
         return '$' + amount + '.00';
      } else if (amount != undefined && amount.toString().indexOf('.') > 0){
         let amtArr = amount.toString().split('.');
         if(amtArr[1].length === 1){
           return '$' + amount + '0';
         } else if (amtArr[1].length === 2){
           return '$' + amount;
         }
      }
    }

    selectChaseTD(chaseTD: string){
      if(chaseTD === 'default'){
        this.systemDropdownSettings = {
          disabled: false
        };
        jQuery("#legalEntity").find(".psButton").prop('disabled',false);  
        jQuery("#legalEntity").find(".psOption").prop('disabled',false);
        jQuery("#marketSegment").find(".psButton").prop('disabled',false);  
        jQuery("#marketSegment").find(".psOption").prop('disabled',false);
      } else {
        this.selectedSystem = [];
        this.systemDropdownSettings = {
          disabled: true
        };
        this.adhocModel.legalEntity = "";
        this.adhocModel.marketSegment = "";
        jQuery("#legalEntity").find(".psButton").prop('disabled',true);  
        jQuery("#legalEntity").find(".psOption").prop('disabled',true);
        jQuery("#marketSegment").find(".psButton").prop('disabled',true);  
        jQuery("#marketSegment").find(".psOption").prop('disabled',true);
      }
    }

    selectDateType(){
      this.hasDateType = true;
    }
}
