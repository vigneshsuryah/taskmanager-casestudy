import { Component, EventEmitter, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
import { MedicaidPayService } from '../../shared/csr-service/medicaidpay.service';
import { AuthenticationService } from '../../shared/csr-service';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-medicaidhome',
  templateUrl: 'medicaidhome.component.html',
  styleUrls: ['medicaidhome.component.css']
})
export class MedicaidHomeComponent implements OnInit {
  content: any = {};
  showKY = false;
  showIN = false;

  constructor (public router: Router, private medicaidPayService: MedicaidPayService,
    private user: User, public activeRoute: ActivatedRoute) {
      if(this.user.userRole === undefined){
        this.router.navigate(['']);
      }
      this.activeRoute.queryParams.subscribe(params => {
        this.redirectToState(params['state'])
      });
  }

  ngOnInit() {
    this.content = content;
    if (this.user && this.user.userRole) {
      let hasOption = false;
      if (this.user.userRole.indexOf('KYHCSRPAYMENT') > -1) {
        this.showKY = true;
        hasOption = true;
      }
      if (this.user.userRole.indexOf('HIPCSRPAYMENT') > -1) {
        this.showIN = true;
        hasOption = true;
      }
      if (!hasOption) {
        this.router.navigate(['']);
      }
    } else {
      this.router.navigate(['']);
    }
  }

  redirectToState(state: string) {
    if (state === 'KY') {
      this.medicaidPayService.state = 'KY';
      this.medicaidPayService.partnerId = 'KYHCSR';
      this.medicaidPayService.csrId = this.user.username;
      this.router.navigate(['/medicaidpay/makepayment']);
    } else {
      this.medicaidPayService.state = 'IN';
      this.medicaidPayService.partnerId = 'HIP';
      this.medicaidPayService.csrId = this.user.username;
      this.router.navigate(['/medicaidpay/makepayment']);
    }

    // jQuery('#medicaidSearchResult').show();
    // jQuery('#homeText').hide();
    // jQuery('html,body').animate({ scrollTop: jQuery("#medicaidSearchResult").offset().top - jQuery("#medicaidSearchResult").height() + 270 }, 'slow');
  }
}
