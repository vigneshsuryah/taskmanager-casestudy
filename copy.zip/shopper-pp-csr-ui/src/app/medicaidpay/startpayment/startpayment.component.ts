import { Component, OnInit } from '@angular/core';
import { PayEntry } from '../../shared/models/medicaidpay/payentry.model';
import { Router } from '@angular/router';
import { MedicaidPayService } from '../../shared/csr-service/medicaidpay.service';
import { PaymentSelection } from '../../shared/models/medicaidpay/paymentselection.model';
import { Application } from '../../shared/models/medicaidpay/application.model';
import { Applicant } from '../../shared/models/medicaidpay/applicant.model';
import { Demographic } from '../../shared/models/medicaidpay/demographic.model';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'csr-startpayment',
  templateUrl: './startpayment.component.html',
  styleUrls: ['./startpayment.component.css']
})
export class StartpaymentComponent implements OnInit {
  payEntry = new PayEntry();
  screenLoader: boolean = false;
  techerror: boolean = false;
  errorMsg = {
    requiredId: 'ID cannot be empty',
    invalidId: 'The ID can only contain alphabets and numbers',
    requiredFirst: 'Member First Name cannot be empty',
    invalidFirst: 'Invalid First Name',
    requiredLast: 'Member Last Name cannot be empty',
    invalidLast: 'Invalid Last Name',
    invalidDOB: 'Invalid DOB',
    invalidAmount: 'Invalid amount. Please enter a numeric value between $1 and $',
    requiredAmount: 'Amount cannot be empty. Please enter a value between $1 and $',
    invalidAmountBig: 'Please enter an amount between $1 and $',
    techError: 'Sorry, our system isn\'t working the way it should. Please try again later.'
  };
  formContent = {
    inputIdKY: 'Enter the Fast Track Tracking number or MAID or HCID or HOH ID or Call Log number',
    inputIdIN: 'Enter the member\'s RID or Application ID or HCID or Call log number'
  };
  placeholderId = this.formContent.inputIdKY;
  amountMax = 37.50;
  payError = this.errorMsg.techError;
  state = 'KY';

  constructor(private router: Router, private medicaidPayService: MedicaidPayService,
    private datePipe: DatePipe) { 
      
    }

  ngOnInit() {
    if (this.medicaidPayService.state === undefined) {
      this.router.navigate(['/medicaidpay']);
    } else if (this.medicaidPayService.state === 'KY') {
      this.placeholderId = this.formContent.inputIdKY;
      this.amountMax = 37.50;
      this.state = 'KY';
    } else if (this.medicaidPayService.state === 'IN') {
      this.placeholderId = this.formContent.inputIdIN;
      this.amountMax = 100;
      this.state = 'IN';
    }
  }

  checkPayId(newValue: string) {
    if (newValue !== '' && newValue.length > 21) {
      let updateId = this.insertDash(this.payEntry.paymentId, 8);
      updateId = this.insertDash(updateId, 13);
      updateId = this.insertDash(updateId, 18);
      updateId = this.insertDash(updateId, 23);
      this.payEntry.paymentId = updateId;
    }
  }

  insertDash(id: string, index: number) {
    if (id.charAt(index) !== '-') {
      id = id.substr(0, index) + '-' + id.substr(index);
    }
    return id;
  }

  updateDate(date) {
    this.payEntry.dob = date;
  }

  medicaidPayNow() {
    this.screenLoader = true;
    this.techerror = false;
    const paySelect = new PaymentSelection();
    paySelect.paymentIdentifier = this.payEntry.paymentId;
    paySelect.csrIdentifier = this.medicaidPayService.csrId;
    paySelect.action = 'UPDATE';

    const demo = new Demographic();
    demo.action = 'UPDATE';
    demo.firstName = this.payEntry.firstName;
    demo.lastName = this.payEntry.lastName;
    demo.dateOfBirth = this.payEntry.dob.substr(6, 4) + '-' + this.payEntry.dob.substr(0, 2) + '-' + this.payEntry.dob.substr(3, 2);

    const applicant = new Applicant();
    applicant.action = 'UPDATE';
    applicant.demographic = demo;

    const app = new Application();
    app.state = this.medicaidPayService.state;
    app.brandName = 'ANTHEM';
    app.applicationType = 'PAYMENT';
    app.createPartnerId = this.medicaidPayService.partnerId;
    app.action = 'UPDATE';
    app.exchTransactionId = this.payEntry.paymentId;
    app.premiumAmt = this.payEntry.amount;
    const effDate = new Date();
    effDate.setDate(1);
    effDate.setMonth(effDate.getMonth() + 1);
    app.reqEffDate = this.datePipe.transform(effDate, 'yyyy-MM-dd');
    app.paymentSelection = paySelect;
    app.applicant = [applicant];

    this.medicaidPayService.payEntry = this.payEntry;
    this.payError = this.errorMsg.techError;
    this.medicaidPayService.callSetApplication(app).subscribe((response) => {
      if (response && response.acn && !this.hasPaymentException(response.application)) {
        this.medicaidPayService.application = response.application;
        this.medicaidPayService.acn = response.acn;
        this.router.navigate(['/medicaidpay/paymentdetails']);
      } else {
        this.screenLoader = false;
        this.techerror = true;
      }
    }, (error) => {
      this.screenLoader = false;
      this.techerror = true;
    });
  }

  hasPaymentException(app: Application) {
    if (app && app.paymentSelection && app.paymentSelection.paymentExceptionMsg) {
      const message =  app.paymentSelection.paymentExceptionMsg;
      if (message.indexOf('DUPLICATE:') >= 0) {
        this.payError = message.split(':')[1];
        return true;
      }
    }
    return false;
  }
}
