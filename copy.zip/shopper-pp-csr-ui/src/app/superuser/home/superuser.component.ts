import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { SuperUserService } from '../../shared/csr-service/superuser.service';
import { Http } from '@angular/http';
import { content } from '../../shared/constants/constants';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-superuser',
  templateUrl: './superuser.component.html',
  styleUrls: ['./superuser.component.css']
})
export class SuperUserComponent implements OnInit {

  superUserModel = {
    "userId":"",
    "superadmin":false,
    "mslimitchange":false,
    "malimitchange":false,
    "viewfundinginfo":false
  }
  hasRules: boolean;
  showResults: boolean;
  enableButton: boolean;
  techerror: boolean;
  serviceError: boolean;
  screenLoader: boolean;
  userId: string = '';
  techErrorMsg: string = 'Oops ! There was an unexpected technical error.';
  serviceErrorMsg: string = '';
  rulesList: any = [];
  submitRulesList: any = [];
  content: any = {};

  constructor(public router: Router, private currentUser: User, private superUserService : SuperUserService, private http: Http) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.content = content;
  }

  searchUserId(userId: string){
    this.userId = userId;
    this.screenLoader = true;
    this.techerror = false;
    this.hasRules = false;
    this.showResults = false;
    this.serviceError = false;
    this.superUserModel.superadmin = false;
    this.superUserModel.mslimitchange = false;
    this.superUserModel.malimitchange = false;
    this.superUserModel.viewfundinginfo = false;

    this.superUserService.getUserRules(userId.toUpperCase()).subscribe((result: any) => {
      this.screenLoader = false;
      if (result.success) {
          this.rulesList = result.rules;
          this.showResults = true;
          if(this.rulesList.length > 0){
            this.hasRules = true;
            for(let roles of this.rulesList){
              if(roles === 'SUPERADMIN'){
                this.superUserModel.superadmin = true;
              } else if(roles === 'MSLIMITCHANGE'){
                this.superUserModel.mslimitchange = true;
              } else if(roles === 'MALIMITCHANGE'){
                this.superUserModel.malimitchange = true;
              } else if(roles === 'VIEWFUNDINGINFO'){
                this.superUserModel.viewfundinginfo = true;
              }
            }
          }
      } else {
        this.hasRules = false;
        this.showResults = true;
        this.serviceError=true;
        this.serviceErrorMsg = result.message;
      }
     
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }

  setUserRoles(superUserModel){
    this.screenLoader = true;
    this.submitRulesList=[];
    if(superUserModel.superadmin){
      this.submitRulesList.push("SUPERADMIN");
    }
    if(superUserModel.mslimitchange){
      this.submitRulesList.push("MSLIMITCHANGE");
    }
    if(superUserModel.malimitchange){
      this.submitRulesList.push("MALIMITCHANGE");
    } 
    if(superUserModel.viewfundinginfo){
      this.submitRulesList.push("VIEWFUNDINGINFO");
    } 

    let inputParams = {
      "userID": this.userId,
      "rules": this.submitRulesList,
      "isNewUser": this.hasRules ? false : true
    }
    this.superUserService.setUserRules(inputParams).subscribe((result: any) => {
      this.screenLoader = false;
      if(result.success){
        document.getElementById("rulesModalOpener").click();
      } else {
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      }
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    }); 
  }

  dismissModal(){
    document.getElementById("rulesModalOpener").click();
    this.superUserModel.userId = '';
    this.showResults = false;
  }

  checkSuperUser(superadmin){
    if(superadmin){
      this.superUserModel.mslimitchange = true;
      this.superUserModel.malimitchange = true;
      this.superUserModel.viewfundinginfo = true;
      jQuery("#mslimitchange").find(".pcOption").prop('disabled',true);
      jQuery("#malimitchange").find(".pcOption").prop('disabled',true);
      jQuery("#viewfundinginfo").find(".pcOption").prop('disabled',true);
      jQuery("#mslimitchange").find(".pcLabel").addClass('disabled-cursor');
      jQuery("#malimitchange").find(".pcLabel").addClass('disabled-cursor');
      jQuery("#viewfundinginfo").find(".pcLabel").addClass('disabled-cursor');
    } else {
      this.superUserModel.mslimitchange = false;
      this.superUserModel.malimitchange = false;
      this.superUserModel.viewfundinginfo = false;
      jQuery("#mslimitchange").find(".pcOption").prop('disabled',false);
      jQuery("#malimitchange").find(".pcOption").prop('disabled',false);
      jQuery("#viewfundinginfo").find(".pcOption").prop('disabled',false);
      jQuery("#mslimitchange").find(".pcLabel").removeClass('disabled-cursor');
      jQuery("#malimitchange").find(".pcLabel").removeClass('disabled-cursor');
      jQuery("#viewfundinginfo").find(".pcLabel").removeClass('disabled-cursor');
    }
  }
  
}
