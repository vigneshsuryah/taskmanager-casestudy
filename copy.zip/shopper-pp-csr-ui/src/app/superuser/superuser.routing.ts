import { Routes } from '@angular/router';

import { TechnicalErrorComponent } from '../commonutils/technicalerror/technicalerror.component';
import { SuperUserComponent } from './home/superuser.component';

export const routes: Routes = [ 
    { path: 'home', component: SuperUserComponent },
    { path: 'error', component: TechnicalErrorComponent}
];