import { SuperUserService } from '../shared/csr-service/superuser.service';
import { NgModule } from '@angular/core';
import { CommonModule} from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';

import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { UxModule } from '../shared/ux.module';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { SuperUserComponent } from './home/superuser.component';
import { routes } from './superuser.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [
    SuperUserService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [
    SuperUserComponent
  ]
})
export class SuperUserModule {}
