import { Routes } from '@angular/router';

import { DashboardComponent } from './home/dashboard.component';

export const routes: Routes = [
    { path: 'home', component: DashboardComponent }
];