import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../../shared/models/user';
import { RefundService } from '../../shared/csr-service/refund.service';

@Component({
  templateUrl: './refundhome.component.html',
  styleUrls: ['./refundhome.component.css']
})
export class RefundHomeComponent implements OnInit {
  
  constructor(private router: Router, private currentUser: User, private refundService: RefundService) { 
    if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.refundService.backToList = false;   
  }

  redirectToHCIDSearch(lob: string){
    this.router.navigate(['/refund/search'], { queryParams: { 'lob': lob } });
  }
  

}
