import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { routes } from './refund.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { RefundService } from '../shared/csr-service/refund.service';
import { HttpClientModule } from '@angular/common/http';
import { RefundHomeComponent } from './home/refundhome.component';
import { RefundSearchComponent } from './search/refundsearch.component';
import { RefundPaymentDetailsComponent } from './paymentdetails/refundpaymentdetails.component';
import { RefundRequestComponent } from './request/refundrequest.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    HttpClientModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [
      RefundService, DatePipe
  ],
  declarations: [RefundHomeComponent, RefundSearchComponent, RefundPaymentDetailsComponent, RefundRequestComponent]
})
export class RefundModule {

}
