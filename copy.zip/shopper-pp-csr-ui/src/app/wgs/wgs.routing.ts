import { Routes } from '@angular/router';

import { WgsHomeComponent } from './home/wgshome.component';
import { WgsSearchComponent } from './wgssearch/wgssearch.component';
import { WgsAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgsautopayment.component';
import { WgsAddAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgsaddautopayment/wgsaddautopayment.component';
import { WgsEditAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgseditautopayment/wgseditautopayment.component';
import { WgsEditPaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgspaymentmethod/wgseditpaymentmethod/wgseditpaymentmethod.component';
import { WgsAddPaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgspaymentmethod/wgsaddpaymentmethod/wgsaddpaymentmethod.component';
import { WgsManagePaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgsmanagepaymentmethod.component';
import { WgsAccountSummaryComponent } from './wgssearch/wgsmanagepaymentmethod/wgsaccountsummary/wgsaccountsummary.component';
import { WgsOneTimePaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsaccountsummary/wgsonetimepayment/wgsonetimepayment.component';

export const routes: Routes = [
    { path: 'home', component: WgsHomeComponent },
    { path: 'wgssearch', component: WgsSearchComponent },
    { path: 'wgsaddautopayment', component: WgsAddAutoPaymentComponent },
    { path: 'wgsmanageautopayment', component: WgsAutoPaymentComponent },
    { path: 'wgseditautopayment', component: WgsEditAutoPaymentComponent },
    { path: 'wgsmanagepaymentmethod', component: WgsManagePaymentMethodComponent },
    { path: 'wgseditpaymentmethod', component: WgsEditPaymentMethodComponent },
    { path: 'wgsaddpaymentmethod', component: WgsAddPaymentMethodComponent },
    { path: 'wgsonetimepayment', component: WgsOneTimePaymentComponent},
    { path: 'wgsaccountsummary', component: WgsAccountSummaryComponent}
];