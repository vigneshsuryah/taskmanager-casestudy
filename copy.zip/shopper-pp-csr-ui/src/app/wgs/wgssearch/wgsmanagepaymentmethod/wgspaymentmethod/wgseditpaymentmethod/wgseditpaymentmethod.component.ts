import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { content } from '../../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../../shared/models/paymentmethod.model';
import { SubscriberAddressModel } from '../../../../../shared/models/wgs/subscriberaddress.model';
import { WgsService } from '../../../../../shared/csr-service/wgs.service';
import { Wgscsr } from '../../../../../shared/models/wgs/wgscsr';
import { NgForm } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-wgseditpaymentmethod',
  templateUrl: 'wgseditpaymentmethod.component.html',
  styleUrls: ['wgseditpaymentmethod.component.css']
})
export class WgsEditPaymentMethodComponent implements OnInit {

  nickNameError:boolean=false;

  paymentMethodModel = {
    'paymentMethod': '',
    'nickName': '',
    'accountType': '',
    'bankRoutingNbr': '',
    'bankAccountNbr': '',
    'reEnterbankAccountNbr': '',
    'accountHolderName': '',
    'addressOnAccount': '',
    'address1': '',
    'address2': '',
    'city': '',
    'state': '',
    'zipCode': '',
    'expiryDate': ''
  }
  subscriberAddressModel = {
    'address1': 'SubscriberAddr One',
    'address2': 'SubscriberAddr Two',
    'city': 'Subscriber City',
    'state': 'KY',
    'zipcode': '90001'
  }
  content : any ={};
  accountTypeList: any;
  screenLoader: boolean = false;
  techerror: boolean = false;
  updatePaymentMethodResponse: any = {};
  editPaymentMethodResponse: any = {};
  updateError: boolean = false;
  usedNickNames: string[] = [];
  
    
  constructor(public router: Router, public wgsService : WgsService, public wgscsr : Wgscsr){}

  ngOnInit() {
    this.content = content;
    this.accountTypeList = [{
      label: 'Personal Checking',
      value: 'PERSONALCHECKING'
    }, {
      label: 'Personal Savings',
      value: 'PERSONALSAVINGS'
    }, {
      label: 'Business Checking',
      value: 'BUSCHECKING'
    }, {
      label: 'Business Savings',
      value: 'BUSSAVINGS'
    }];
    this.editPaymentMethodResponse = this.wgscsr.editPaymentMethodResponse;
    this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
    this.paymentMethodModel.nickName = this.editPaymentMethodResponse.accNickName;
    this.paymentMethodModel.accountType = this.editPaymentMethodResponse.bankAccountType;
    this.paymentMethodModel.bankRoutingNbr = this.editPaymentMethodResponse.routingNumber;
    this.paymentMethodModel.accountHolderName = this.editPaymentMethodResponse.accountName;
    this.paymentMethodModel.address1 = this.editPaymentMethodResponse.billingAddress.addressLine1;
    this.paymentMethodModel.address2 = this.editPaymentMethodResponse.billingAddress.addressLine2;
    this.paymentMethodModel.city = this.editPaymentMethodResponse.billingAddress.city;
    this.paymentMethodModel.state = this.editPaymentMethodResponse.billingAddress.state;
    this.paymentMethodModel.zipCode = this.editPaymentMethodResponse.billingAddress.postalCode;
    this.paymentMethodModel.reEnterbankAccountNbr = this.editPaymentMethodResponse.confirmAccountNo;
    this.paymentMethodModel.bankAccountNbr = this.editPaymentMethodResponse.confirmAccountNo;

    jQuery("#bankRoutingNbr").prop('disabled',true);
    jQuery("#bankAccountNbr").prop('disabled',true);
    jQuery("#reEnterbankAccountNbr").prop('disabled',true);
    jQuery("#accountType").find(".psButton").prop('disabled',true);  
    jQuery("#accountType").find(".psOption").prop('disabled',true);
    jQuery("#paymentMethod").find(".psButton").prop('disabled',true);  
    jQuery("#paymentMethod").find(".psOption").prop('disabled',true);

    let editPaymentNickName = this.editPaymentMethodResponse.accNickName;
    if(null !== this.wgscsr.existingNickNames && undefined !== this.wgscsr.existingNickNames){
      for(let nick of this.wgscsr.existingNickNames)
      {
        if(nick !== null && nick !== undefined && editPaymentNickName !== null && editPaymentNickName != undefined &&
          editPaymentNickName !== nick){
          this.usedNickNames.push(nick)
        }
      }
    }
    
 }

   editPaymentMethod (paymentMethodModel: PaymentMethodModel){
      this.screenLoader = true;
      this.techerror = false;
      this.updateError = false;
      this.nickNameError = false;
      
      if(this.usedNickNames.indexOf(paymentMethodModel.nickName) > -1){
        this.nickNameError = true;
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
      } else {
              var inputParams = {
                "hcid": this.wgscsr.healthCardId,
                "action": "MODIFY",
                "paymentMethod": {
                  "accNickName": paymentMethodModel.nickName,
                  "routingNumber":paymentMethodModel.bankRoutingNbr,
                  "accountName": paymentMethodModel.accountHolderName,
                  "paymentType": "BANKINGACCOUNT",
                  "billingAddress": {
                      "addressLine1": paymentMethodModel.address1,
                      "addressLine2": paymentMethodModel.address2,
                      "city": paymentMethodModel.city,
                      "state": paymentMethodModel.state,
                      "postalCode": paymentMethodModel.zipCode
                  },
                  "bankAccountType": paymentMethodModel.accountType,
                  "confirmAccountNo": paymentMethodModel.bankAccountNbr,
                  "maskedAccountNumber": paymentMethodModel.bankAccountNbr,
                  "tokenId": this.editPaymentMethodResponse.tokenId
                }
              }  

              this.wgsService.updatePaymentMethods(inputParams).subscribe((data: any) => {
                this.screenLoader = false;
                this.updatePaymentMethodResponse = data;
                if (this.updatePaymentMethodResponse.message !== undefined && this.updatePaymentMethodResponse.message.messageText !== undefined &&
                  this.updatePaymentMethodResponse.message.messageText === 'Success') {
                  jQuery("#confirmationModalOpener").click();
                } else {
                  jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                  this.updateError = true;
                }
              },
              (err: any) => {
                jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                this.techerror = true;
                this.screenLoader = false;
              });
      }   
   }

   redirectToHome(selected: string) {
     this.wgscsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   cancel(selected: string){
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   changeAddressOnAccount(addressType: string){
     if(addressType === 'SubscriberAddr'){
        this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        this.paymentMethodModel.address1 = this.subscriberAddressModel.address1;
        this.paymentMethodModel.address2 = this.subscriberAddressModel.address2;
        this.paymentMethodModel.city = this.subscriberAddressModel.city;
        this.paymentMethodModel.state = this.subscriberAddressModel.state;
        this.paymentMethodModel.zipCode = this.subscriberAddressModel.zipcode;
     } else {
        this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
        this.paymentMethodModel.address1 = this.editPaymentMethodResponse.accountAddress1;
        this.paymentMethodModel.address2 = this.editPaymentMethodResponse.accountAddress2;
        this.paymentMethodModel.city = this.editPaymentMethodResponse.accountCity;
        this.paymentMethodModel.state = this.editPaymentMethodResponse.accountState;
        this.paymentMethodModel.zipCode = this.editPaymentMethodResponse.accountPostalCode;
     }
   }

  getMaskedAccountNumber(bankAccountNumber: string){
    let maskedNumber = '';
    let indexVal = bankAccountNumber.length - 4;
    let accountNumber = bankAccountNumber.substring(indexVal);
    for(let i=0; i < indexVal; i++){
      maskedNumber = maskedNumber + '*';
    }
    return maskedNumber + accountNumber;
  }
}
