import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../../shared/models/user';
import { Wgscsr } from '../../../shared/models/wgs/wgscsr';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-wgsmanagepaymentmethod',
  templateUrl: 'wgsmanagepaymentmethod.component.html',
  styleUrls: ['wgsmanagepaymentmethod.component.css']
})
export class WgsManagePaymentMethodComponent implements OnInit {

  content : any ={};
  selectedMethod: string;

  hasWGSCSRSUBMIT: boolean = false;
  hasWGSCSRPAYMENT: boolean = false;

  constructor(public router: Router, public wgscsr : Wgscsr, private user: User){
    if (this.user && this.user.userRole) {
      if (this.user.userRole.indexOf('WGSCSRSUBMIT') > -1) {
        this.hasWGSCSRSUBMIT = true;
      }
      if (this.user.userRole.indexOf('WGSCSRPAYMENT') > -1) {
        this.hasWGSCSRPAYMENT = true;
      }
    } else {
      this.router.navigate(['/roothome']);
    }
  }

   ngOnInit() {
     if(this.hasWGSCSRSUBMIT){
      this.selectedMethod = 'AS';
     }else if (this.wgscsr.paymentOption !== undefined) {
       this.selectedMethod = this.wgscsr.paymentOption;
     } else {
       this.selectedMethod = 'MAM'
     }
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      } else if (selectedMethod === 'PH'){
        this.selectedMethod = 'PH';
      } else if (selectedMethod === 'PDF'){
        this.selectedMethod = 'PDF';
      }else if (selectedMethod === 'AS'){
        this.selectedMethod = 'AS';
      }
   }

}
