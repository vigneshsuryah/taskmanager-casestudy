const wgsPaymentsDBFixedValues = {

    "payment_type": "ACH",
    "created_id": "WGSMIGRATED",
    "updated_id": "WGSMIGRATED",
    "status": "ACTIVE",
    "iscsr": false


}
const wgsHeaderValues = {
    "HCID": "hcid",
    "Bill Entity": "bill",
    "AWD Effective Date": "created_dt",
    "AWD Term Date": "term_dt",
    "Token ID": "token_id",
    "Collection Day": "collection_day",
    "Authorization ID": "authorization_id",
    "Authorization Mode": "authorization_mode",

}
const wgsInvalidHeaderValues = [
    "HCID",
    "Name on funcing account",
    "Bank Account Number",
    "Bank Routing Number",
    "AWD Effective Date",
    "AWD Term Date",
    "Collection",
    "Payment Type",
    "Address",
    "City",
    "State",
    "Zip",
    "Bill",
    "Authorization ID",
    "Authorization Mode"

]

module.exports = {
    wgsPaymentsDBFixedValues: wgsPaymentsDBFixedValues,
    wgsInvalidHeaderValues: wgsInvalidHeaderValues,
    wgsHeaderValues: wgsHeaderValues
}