const wgsPayments = {
    "Subscriber": "hcid",
    "First Name": "name_on_funding_account",
    "Last Name": "name_on_funding_account",
    "Bank account": "bankaccount.bank_account_number",
    "Routing data": "bankaccount.bank_routing_number",
    "AWD effective date": "created_dt",
    "AWD term date": "term_dt",
    "Collection day": "collection_day",
    "Type of account": "payment_sub_type",
    "Address": "fund_account_owner_full_address.address1",
    "City": "fund_account_owner_full_address.city",
    "State": "fund_account_owner_full_address.state",
    "Zip": "fund_account_owner_full_address.zipcode",
    "Bill Entity": "bill",
    "Authorization ID": "authorization_id",
    "Authorization Mode": "authorization_mode"

}

module.exports = wgsPayments;