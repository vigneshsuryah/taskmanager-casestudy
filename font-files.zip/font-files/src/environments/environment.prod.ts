export const environment = {
  production: true,
  API:'https://payment.anthem.com/paymentgateway/',
  loggingflag: false,
  environment: 'PROD'
};
