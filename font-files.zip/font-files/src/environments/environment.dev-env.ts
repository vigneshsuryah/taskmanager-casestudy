export const environment = {
  production: true,
  API:'https://shop.dev1.va.anthem.com/paymentgateway/',
  loggingflag: false,
  environment: 'DEV'
};
