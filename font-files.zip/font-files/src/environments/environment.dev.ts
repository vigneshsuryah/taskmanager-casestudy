export const environment = {
  production: true,
  API:'http://va10duvwbs038.wellpoint.com:19080/paymentgateway/',
  loggingflag: false,
  environment: 'DEV'
};
