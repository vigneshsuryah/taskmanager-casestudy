export const environment = {
  production: true,
  API:'https://shop.perf1.va.anthem.com/paymentgateway/',
  loggingflag: false,
  environment: 'PERF'
};
