export const environment = {
  production: true,
  API:'https://uat1.payment.anthem.com/paymentgateway/',
  loggingflag: false,
  environment: 'UAT'
};
