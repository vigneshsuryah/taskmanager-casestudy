export const environment = {
  production: true,
  API:'https://shop.sit1.va.anthem.com/paymentgateway/',
  loggingflag: false,
  environment: 'SIT'
};
