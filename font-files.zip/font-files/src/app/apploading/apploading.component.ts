import { Component, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../shared/models/user';
import { AuthenticationService } from '../shared/csr-service/authentication.service';
declare var jQuery:any;

@Component({
  selector: 'csr-apploading',
  templateUrl: './apploading.component.html',
  styleUrls: ['./apploading.component.css']
})
export class AppLoadingComponent implements OnInit{

    constructor (public router : Router, private authenticationService: AuthenticationService){

    }

    ngOnInit(){
      jQuery(".nav-menu-item").hide();
      jQuery("#menuBarId").hide();
      setTimeout(()=>{
        this.afterAppLoadingGenerateToken();
      },4000);
    }

    afterAppLoadingGenerateToken(){

        this.authenticationService.userDetails.subscribe((data: User) => {

          if (data.firstName) {
            jQuery("#headerUserName").text(data.firstName + " " + data.lastName);
          }

          // set logged in user name in the user
          var userRoles = data.userRole;
          
          userRoles.push('REPORTSROLE'); // hard coded - to remove
          //userRoles.push('CSRPayment'); // hard coded - to remove

          /*  GBDPPORTCSR - GBD IN
              PPORTCSR - MWP CSR
              CSRPayment - IPP CSR
              HIPCSRPayment - IPP HIP CSR
              KYHCSRPayment - KYH IPP CSR Portal
              KYHPPORTCSR - GBD KY 
              PPCSRADMIN - All other menus   */
          
          // check for users role if it contains any of the CSR portal we have
          if (userRoles && (userRoles.indexOf('KYHPPORTCSR') > -1 || userRoles.indexOf('HIPCSRPayment') > -1 || 
                            userRoles.indexOf('KYHCSRPayment') > -1 || userRoles.indexOf('REPORTSROLE') > -1 || 
                            userRoles.indexOf('PPORTCSR') > -1 || userRoles.indexOf('GBDPPORTCSR') > -1)) {
                //|| userRoles.indexOf('WGSCSRPayment') > -1 ) || userRoles.indexOf('CSRPayment') > -1)) {

            // to show and enable MWP CSR (MWP)
            if(userRoles.indexOf('PPORTCSR') > -1){
              jQuery("#memberCsrPaymentMenuItem").show();
            }

            // to show and enable AWD PAYMENT SETUP (GBD)
            if(userRoles.indexOf('KYHPPORTCSR') > -1 || userRoles.indexOf('GBDPPORTCSR') > -1){
              jQuery("#medicaidRecurringPaymentMenuItem").show();
            }

            // to show and enable CSR INITIAL PAYMENTS (GBD)
            if(userRoles.indexOf('HIPCSRPayment') > -1 || userRoles.indexOf('KYHCSRPayment') > -1){
              jQuery("#medicaidInitialPaymentMenuItem").show();
            }

            // to show and enable REPORTS tab
            if(userRoles.indexOf('REPORTSROLE') > -1){
              jQuery("#reportsMenuItem").show();
            }

            /*if(userRoles.indexOf('WGSCSRPayment') > -1){
              jQuery("#wgsMenuItem").show();
            }
            
            if(userRoles.indexOf('CSRPayment') > -1){
              jQuery("#initialPaymentCSRMenuItem").show();
            }*/

            jQuery("#menuBarId").show();
            
            //console.log(JSON.stringify( jQuery('#menuBarId').find('.nav-menu-item:visible:first')));

            // click the first menu and load the respective page
            jQuery('#menuBarId').find('.nav-menu-item:visible:first').click();
          } else {
            // show user not having privilage to access portal
            jQuery("#loaderMainContentId").html("<p class='text-align-center bold'> User does not have privilage to access the portal !!! </p>");
          }

        });
    }

    includes(container, value) {
      var returnValue = false;
      var pos = container.indexOf(value);
      if (pos >= 0) {
          returnValue = true;
      }
      return returnValue;
    }
}

