import { Component,ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'csr-screenfreeze',
  templateUrl: 'screenfreeze.component.html'
})

export class ScreenFreezeComponent implements OnInit { 
  
  ngOnInit() {
    
  }
  
} 

