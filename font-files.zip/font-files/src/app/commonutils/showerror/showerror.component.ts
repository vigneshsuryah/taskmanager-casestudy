import { Component, OnInit, Input } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'show-error',
  templateUrl: './showerror.component.html',
  styleUrls: ['./showerror.component.css']
})
export class ShowerrorComponent implements OnInit {
  @Input() field: NgModel;
  @Input() invalidMsg: string = '';
  @Input() requiredMsg: string = 'Required field';
  @Input() isOptional: boolean = false;

  constructor() { }

  ngOnInit() {
  }

}
