import { Validator, FormControl, NG_VALIDATORS } from '@angular/forms';
import { Input, Directive } from '@angular/core';

@Directive({
  selector: '[amountValidator]',
  providers: [
    {provide: NG_VALIDATORS, useExisting: AmountValidator, multi: true}
  ]
})
export class AmountValidator implements Validator {
  @Input() minValue = 0;
  @Input() maxValue = 0;

  validate(val: FormControl) {

    if (val && val.value && val.value !== '') {
      const fieldValue = val.value;
      if ( (fieldValue > this.minValue || fieldValue == this.minValue)
        && (fieldValue < this.maxValue || fieldValue == this.maxValue) ) {
        return null;
      }
      return {
        invalidAmount : {
          value: val.value
        }
      };
    }
    return null;
  }

}
