import { Validator, AbstractControl, NG_VALIDATORS } from '@angular/forms';
import { Input, Directive } from '@angular/core';

@Directive({
  selector: '[nickNameValidator]',
  providers: [
      { provide: NG_VALIDATORS, useExisting: NickNameValidator, multi: true }
  ]
})
export class NickNameValidator implements Validator {
  @Input() existingNames: string[] = [];

  validate(c: AbstractControl) {
    if (c !== undefined) {
      const val = c.value;
      if (val !== undefined && val !== '' && this.existingNames !== undefined) {
        for (const entry of this.existingNames) {
          if (val === entry) {
            return {
              'nicknametaken' : {
                value : c.value
              }
            };
          }
        }
      }
    }
    return null;
  }

}
