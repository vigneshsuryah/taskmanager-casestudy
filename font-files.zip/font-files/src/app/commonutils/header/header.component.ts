import { Component,ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { AuthenticationService } from '../../shared/csr-service/authentication.service';

@Component({
  moduleId: module.id,
  selector: 'csr-header',
  templateUrl: 'header.component.html' ,
  styleUrls: ['header.component.css']
})

export class HeaderComponent implements OnInit {

  selectedApp: string;

  constructor(public router: Router,  @Inject(DOCUMENT) private document: any, private currentUser: User, private authenticationService: AuthenticationService) {

  }

  ngOnInit() {
    this.selectedApp = 'IPP';
    jQuery("#hide-wgs-footer").show();
  }

  changePaymentApp(payAppType: string){
    if(payAppType === 'IPP'){
      this.selectedApp = 'IPP';
    } else if(payAppType === 'MEDP'){
      this.selectedApp = 'MEDP';
    } else if(payAppType === 'INDVMP'){
      this.selectedApp = 'INDVMP';
    } else if(payAppType === 'GBDMP'){
      this.selectedApp = 'GBDMP';
    } else if(payAppType === 'DASHBOARD'){
      this.selectedApp = 'DASHBOARD';
    } else if(payAppType === 'REPORTS'){
      this.selectedApp = 'REPORTS';
    } else if(payAppType === 'WGS'){
      this.selectedApp = 'WGS';
    }
    if(this.selectedApp === 'WGS' || this.selectedApp === 'IPP'){
      jQuery("#hide-wgs-footer").show();
    }else{
      jQuery("#hide-wgs-footer").hide();
    }
  }

  toLogOut(){
    jQuery("#logout-submit").click();
  }
}

