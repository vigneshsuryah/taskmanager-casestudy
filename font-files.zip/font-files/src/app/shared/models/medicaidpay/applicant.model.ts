import { Demographic } from './demographic.model';

export class Applicant {
  id: number;
  action: string;
  demographic = new Demographic();
}
