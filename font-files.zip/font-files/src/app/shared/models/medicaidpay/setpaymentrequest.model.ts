import { PaymentSelection } from './paymentselection.model';

export class SetPaymentRequest {
  partnerId: string;
  userId: string;
  acn: string;
  paymentselection = new PaymentSelection();
}
