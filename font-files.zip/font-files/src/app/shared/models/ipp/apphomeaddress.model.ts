export class AppHomeAddressModel {

    addressLine1: string;
    addressLine2: string;
    city: string;
    state: string;
    county: string;
    postalCode: string;
    
}