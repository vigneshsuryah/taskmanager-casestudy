export class PaymentMethodModel {

    paymentMethod?: string;
    nickName?: string;
    accountType?: string;
    bankRoutingNbr?: string;
    bankAccountNbr?: string;
    reEnterbankAccountNbr?: string;
    accountHolderName?: string;
    addressOnAccount?: string;
    address1?: string;
    address2?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    expiryDate?: string;
    cardName?: string;
    cardNumber?: string;
    tokenId?: string;
    accNickName?: string;
    accountName?: string;
    routingNumber?: string;
    confirmAccountNo?: string;
    billingAddress?: any;
    expiration?: string;
}