export class KyhpportcsrModel {
    authorization: string;
    paymentMethod: string;
    dayOfMonth: string;
    isChecked: boolean;
}