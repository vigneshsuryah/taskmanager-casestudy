export class PaymentMethod {
  bankAccountType: string;
  routingNumber: string;
  bankAccountNumber: string;
  accountHolderName: string;
  accountAddress1: string;
  accountAddress2: string;
  accountCity: string;
  accountState: string;
  accountPostalCode: string;
  accountNickname: string;
  tokenId: string;

  creditCardNumber: string;
  creditCardType: string;
  expirationMonth: string;
  expirationYear: string;
  securityCode: string;
  
}
