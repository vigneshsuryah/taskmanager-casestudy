export class Wgscsr {
   healthCardId: string;
   paymentOption: string;
   editRecurringPayment: string;
   billEntityNumbers : any;
   editPaymentMethodResponse: any;
   existingNickNames: string[];
}