export const content = {
  radioObjectVisa: {
    label: '<img src="assets/images/visa.png" width="50px" height="32px">Visa',
    id: 'ddlPayType15',
    name: 'Visa Card',
    value: 'VISA'
  },
  radioObjectMC: {
    label: '<img src="assets/images/mc.png" width="50px" height="32px">MasterCard',
    id: 'ddlPayType16',
    name: 'Master Card',
    value: 'MASTERCARD'
  },
  creditCardChecked: {
    id: 'ddlPayType17',
    name: 'creditCardChecked',
    label: 'I want to use this credit/debit card account for automatic monthly payments for my coverage.',
    trueValue: true,
    falseValue: false
  },
  radioObjectCardHolderAddr: {
    label: 'Enter Cardholder Address',
    id: 'ddlPayType18',
    name: 'Enter Cardholder Address',
    value: 'CardHolderAddr'
  },
  radioObjectHomeAddr: {
    label: 'Use my Applicant Home Address',
    id: 'ddlPayType19',
    name: 'Use my Applicant Home Address',
    value: 'AppHomeAddr'
  },
  radioObjectBillAddr: {
    label: 'Use my Applicant Billing Address',
    id: 'ddlPayType20',
    name: 'Use my Applicant Billing Address',
    value: 'AppBillAddr'
  },
  radioObjectYes: {
    label: 'Yes',
    id: 'ddlPayType21',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectNo: {
    label: 'No',
    id: 'ddlPayType22',
    name: 'No',
    value: 'No'
  },
  radioObjectPersonalChecking: {
    label: 'Personal Checking',
    id: 'ddlPayType23',
    name: 'Personal Checking',
    value: 'PERSONALCHECKING'
  },
  radioObjectBusinessChecking: {
    label: 'Business Checking',
    id: 'ddlPayType24',
    name: 'Business Checking',
    value: 'BUSCHECKING'
  },
  radioObjectPersonalSaving: {
    label: 'Personal Savings',
    id: 'ddlPayType25',
    name: 'Personal Saving',
    value: 'PERSONALSAVINGS'
  },
  radioObjectBusinessSaving: {
    label: 'Business Savings',
    id: 'ddlPayType26',
    name: 'Business Saving',
    value: 'BUSSAVINGS'
  },
  autoPayChecked: {
    id: 'ddlPayType27',
    name: 'autoPayChecked',
    label: 'I want to use this bank account for automatic monthly payments for my coverage.',
    trueValue: true,
    falseValue: false
  },
  radioObjectEbillYes: {
    label: 'Yes',
    id: 'ddlPayType28',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectEbillNo: {
    label: 'No',
    id: 'ddlPayType29',
    name: 'No',
    value: 'No'
  },
  radioObjectPolicyInfoYes: {
    label: 'Yes',
    id: 'ddlPayType30',
    name: 'Yes',
    value: 'Yes'
  },
  radioObjectPolicyInfoNo: {
    label: 'No',
    id: 'ddlPayType31',
    name: 'No',
    value: 'No'
  },
  stateList: [{
    label: 'Alabama',
    value: 'AL'
  },
  {
    label: 'Alaska',
    value: 'AK'
  },
  {
    label: '	Arizona',
    value: 'AZ'
  },
  {
    label: 'Arkansas',
    value: 'AR'
  },
  {
    label: 'California',
    value: 'CA'
  },
  {
    label: 'Colorado',
    value: 'CO'
  },
  {
    label: 'Connecticut',
    value: 'CT'
  },
  {
    label: 'Delaware',
    value: 'DE'
  },
  {
    label: 'Florida',
    value: 'FL'
  },
  {
    label: 'Georgia',
    value: 'GA'
  },
  {
    label: 'Hawaii',
    value: 'HI'
  },
  {
    label: 'Idaho',
    value: 'ID'
  },
  {
    label: 'Illinois',
    value: 'IL'
  },
  {
    label: 'Indiana',
    value: 'IN'
  },
  {
    label: 'Iowa',
    value: 'IA'
  },
  {
    label: 'Kansas',
    value: 'KS'
  },
  {
    label: 'Kentucky',
    value: 'KY'
  },
  {
    label: 'Louisiana',
    value: 'LA'
  },
  {
    label: 'Maine',
    value: 'ME'
  },
  {
    label: 'Maryland',
    value: 'MD'
  },
  {
    label: 'Massachusetts',
    value: 'MA'
  },
  {
    label: 'Michigan',
    value: 'MI'
  },
  {
    label: 'Minnesota',
    value: 'MN'
  },
  {
    label: 'Mississippi',
    value: 'MS'
  },
  {
    label: 'Missouri',
    value: 'MO'
  },
  {
    label: 'Montana',
    value: 'MT'
  },
  {
    label: 'Nebraska',
    value: 'NE'
  },
  {
    label: 'Nevada',
    value: 'NV'
  },
  {
    label: 'New Hampshire',
    value: 'NH'
  },
  {
    label: 'New Jersey',
    value: 'NJ'
  },
  {
    label: 'New Mexico',
    value: 'NM'
  },
  {
    label: 'New York',
    value: 'NY'
  },
  {
    label: 'North Carolina',
    value: 'NC'
  },
  {
    label: 'North Dakota',
    value: 'ND'
  },
  {
    label: 'Ohio',
    value: 'OH'
  },
  {
    label: 'Oklahoma',
    value: 'OK'
  },
  {
    label: 'Oregon',
    value: 'OR'
  },
  {
    label: 'Pennsylvania',
    value: 'PA'
  },
  {
    label: 'Rhode Island',
    value: 'RI'
  },
  {
    label: 'South Carolina',
    value: 'SC'
  },
  {
    label: 'South Dakota',
    value: 'SD'
  },
  {
    label: 'Tennessee',
    value: 'TN'
  },
  {
    label: 'Texas',
    value: 'TX'
  },
  {
    label: 'Utah',
    value: 'UT'
  },
  {
    label: 'Vermont',
    value: 'VT'
  },
  {
    label: 'Virginia',
    value: 'VA'
  },
  {
    label: 'Washington',
    value: 'WA'
  },
  {
    label: 'West Virginia',
    value: 'WV'
  },
  {
    label: 'Wisconsin',
    value: 'WI'
  },
  {
    label: 'Wyoming',
    value: 'WY'
  }],
  radioObjectSubscriberAddr: {
    label: 'Use Subscriber\'s Address',
    id: 'ddlPayType29',
    name: 'Use Subscriber\'s Address',
    value: 'SubscriberAddr'
  },
  radioObjectAlternativeAddr: {
    label: 'Use an Alternative Address',
    id: 'ddlPayType30',
    name: 'Use an Alternative Address',
    value: 'AlternativeAddr'
  },
  accountType: [{
    label: 'Personal Checking',
    value: 'PERSONAL_CHECKING'
  }, {
    label: 'Personal Savings',
    value: 'PERSONAL_SAVINGS'
  }, {
    label: 'Business Checking',
    value: 'BUSINESS_CHECKING'
  }, {
    label: 'Business Savings',
    value: 'BUSINESS_SAVINGS'
  }],
  creditCardType: [{
    label: 'VISA',
    value: 'VISA'
  }, {
    label: 'Mastercard',
    value: 'MC'
  }],
  paymentMethod: [{
    label: 'Credit/Debit Card',
    value: 'CreditDebit'
  }, {
    label: 'Banking Account',
    value: 'Banking'
  }],
  authorization: [{
    label: 'Telephone',
    value: 'Telephone'
  },
  {
    label: 'Paper',
    value: 'Paper'
  }],
  dayOfMonth: [{
    label: '1st Day of month',
    value: '01'
  }, {
    label: '2nd Day of month',
    value: '02'
  }, {
    label: '3rd Day of month',
    value: '03'
  },
  {
    label: '4th Day of month',
    value: '04'
  }, {
    label: '5th Day of month',
    value: '05'
  },
  {
    label: '6th Day of month',
    value: '06'
  }],
  indvAddSummaryBillChecked: {
    id: 'ddlPayType31',
    name: 'addSummaryBillChecked',
    label: 'Summary Bill : ',
    trueValue: true,
    falseValue: false
  },
  indvEditSummaryBillChecked: {
    id: 'ddlPayType32',
    name: 'editSummaryBillChecked',
    label: 'Summary Bill : ',
    trueValue: true,
    falseValue: false
  },
  gbdAddSummaryBillChecked: {
    id: 'ddlPayType31',
    name: 'addSummaryBillChecked',
    label: '',
    trueValue: true,
    falseValue: false
  },
  gbdEditSummaryBillChecked: {
    id: 'ddlPayType32',
    name: 'editSummaryBillChecked',
    label: '',
    trueValue: true,
    falseValue: false
  },
  advSearchChecked: {
    id: 'ddlPayType33',
    name: 'advSearchChecked',
    label: 'Display Active Application',
    trueValue: true,
    falseValue: false
  },
  withdrawalDay: [{
    label: '1st',
    value: '1'
  }, {
    label: '2nd',
    value: '2'
  }, {
    label: '3rd',
    value: '3'
  }, {
    label: '4th',
    value: '4'
  }, {
    label: '5th',
    value: '5'
  }, {
    label: '6th',
    value: '6'
  }],
  sendConfirmationEmail: {
    id: 'ddlemail01',
    name: 'emailAddressChecked',
    label: 'Send confirmation email',
    trueValue: true,
    falseValue: false
  },
};
