import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { Headers, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { GetPayRequest } from '../models/gbdpay/getpayrequest.model';
import { GetPayMethodResponse } from '../models/gbdpay/getpayresponse.model';
import { PaymentMethod } from '../models/gbdpay/paymentmethod.model';
import { UpdatePayRequest } from '../models/gbdpay/updatepayrequest.model';
import { UpdatePayResponse } from '../models/gbdpay/updatepayresponse.model';
import { Config } from '..';

@Injectable()
export class GbdPayService {
  constructor(private http: HttpClient) {}

  getPayMethodList(getPaymentRequest: GetPayRequest) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'meta-senderapp': 'KYPPCSR'
    });
    return this.http.post<GetPayMethodResponse>(Config.API + 'csr/secure/v1/gbd/payments/getmethods',
      getPaymentRequest,
      {headers: headers});
  }

  updatePaymentMethods(request: UpdatePayRequest) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'meta-senderapp': 'KYPPCSR'
    });
    return this.http.post<UpdatePayResponse>(Config.API + 'csr/secure/v1/gbd/payments/updatemethods',
      request,
      {headers: headers});
  }
}
