import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { Headers, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { GetPayRequest } from '../models/gbdpay/getpayrequest.model';
import { GetPayMethodResponse } from '../models/gbdpay/getpayresponse.model';
import { PaymentMethod } from '../models/gbdpay/paymentmethod.model';
import { UpdatePayRequest } from '../models/gbdpay/updatepayrequest.model';
import { UpdatePayResponse } from '../models/gbdpay/updatepayresponse.model';
import { Config } from '..';
import { User } from '../../shared/models/user';
import { MemberAddress } from '../../shared/models/gbdpay/memberaddress.model';

@Injectable()
export class GbdINPayService {

  hcid: string;
  memberPayAddress: MemberAddress;
  paymentMethodEdit: PaymentMethod;
  memberPaymentOptions: string;
  existingNickNames: string[] = [];
  editRecurringPayment: string;

  constructor(private http: Http, private currentUser: User) {
  }

  getSummary(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/bills/getsummary", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  getPaymentMethods(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username,
      'meta-senderapp' : 'GBDMBR'
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/payments/getmethods", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  updatePaymentMethods(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username,
      'meta-senderapp' : 'GBDMBR'
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/payments/updatemethods", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  getRecurring(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/payments/getrecurring", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  updateRecurring(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/payments/updaterecurring", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  getPaymentHistory(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/bills/history", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  validateMember(inputParam: {}): Observable<string[]> {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API + "csr/secure/v1/gbd/bills/checkhohmember", inputParam, options)
      .map((res: Response) => res.json())
      .catch(this.handleErrorNoChange.bind(this));
  }

  private handleErrorNoChange(error: any) {

    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';

    this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
    return Observable.throw(errMsg);
  }

  public consoleLog(message: string) {
    if (Config.loggingflag) {
      console.log(message);
    }
  }
}
