import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SetApplicationRequest } from '../models/medicaidpay/setapplicationrequest.model';
import { SetApplicationResponse } from '../models/medicaidpay/setapplicationresponse.model';
import { Config } from '..';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { AuthenticationService } from './authentication.service';
import { User } from '../../shared/models/user';
import { Observable } from 'rxjs';

@Injectable()
export class IppHttpService {

  constructor(private httpClient: HttpClient, private http: Http, private authenticationService: AuthenticationService, private currentUser: User) {}

  setApplication(setApplicationRequest: SetApplicationRequest) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'meta-senderapp': 'KYPPCSR'
    });
    return this.httpClient.post<SetApplicationResponse>(Config.API + 'csr/secure/v1/ipp/setApplication',
      setApplicationRequest,
      {headers: headers});
  }

  getApplication(inputParam:{}) : Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.currentUser.token, 'UserName': this.currentUser.username});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+"csr/secure/v1/enroll/getApplication", inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  searchPayment(inputParam:{}) : Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.currentUser.token, 'UserName': this.currentUser.username});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+"csr/secure/v1/ipp/searchPayment", inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  validateZip(request) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'meta-senderapp': 'KYPPCSR'
    });
    return this.httpClient.post(Config.API + 'csr/secure/v1/ipp/validateZipCode',
      request,
      {headers: headers});
  }


setPayment (inputParam:{}) : Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+"csr/secure/v1/ipp/setPayment", inputParam, options)
    .map((res: Response) => res.json())
    .catch(this.handleErrorNoChange.bind(this));
}

submitPayment (inputParam:{}) : Observable<string[]> {
  let headers = new Headers({ 'Authorization': 'Bearer ' +
  this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
  let options = new RequestOptions({ headers: headers });
  return this.http.post(Config.API+"csr/secure/v1/ipp/submitApplication", inputParam, options)
  .map((res: Response) => res.json())
  .catch(this.handleErrorNoChange.bind(this));
}


private handleErrorNoChange (error: any) {
  let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';

  this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
  return Observable.throw(errMsg);
}

public consoleLog(message : string){
  if(Config.loggingflag){
    console.log(message);
  }
}

}
