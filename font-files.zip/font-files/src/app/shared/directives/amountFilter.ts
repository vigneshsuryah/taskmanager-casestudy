import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe  } from "@angular/common";

@Pipe({ name: 'amountPipe'})
export class AmountPipe implements PipeTransform{

constructor(private currencyPipe:CurrencyPipe) {}
  transform(value : any) {
   let returnVal = this.currencyPipe.transform(value).replace('$','');
   return returnVal;
  } 
}