import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe  } from "@angular/common";

@Pipe({ name: 'iterateMap'})
export class IterateMapPipe implements PipeTransform{
  transform(value : any, args:string[]) : any {
    let keys = [];
    for (let key in value) {
      //alert("key" + key);
      //alert("value" + value[key]);
      keys.push({key: key, value: value[key]});
    }
    return keys;
  }
}