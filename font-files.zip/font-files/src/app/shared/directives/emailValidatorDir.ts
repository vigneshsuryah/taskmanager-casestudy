import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[emailaddress-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => EmailValidatorDirective), multi: true }
  ]
})
export class EmailValidatorDirective implements Validator {

  validate(c: FormControl) {
        if (!c.value || typeof c.value === 'undefined') {
            return null;
        }

    let result: any = {};
    
    if (this.validateNoSpaces(c)) {
      result.validNoSpace = true;
    }

    if (this.validateNoSpecialChar(c)) {
      result.validNoSpecialChar = true;
    }

     if (this.validateAtOrDotFollowedByDot(c)) {
      result.validAtDot = true;
    }  

    if (this.validateStartsOrEndsWithAtOrDot(c)) {
      result.validStartEndAt = true;
    }  

    if (this.validateAtOnceFn(c)) {
      result.validateAtOnce = true;
    }
    if (this.validateAtFn(c)) {
      result.validateAt = true;
    }  
    if (this.validateDotFn(c)) {
      result.validateDot = true;
    }  
  
    return result;
    }

    private validateEmail(c: FormControl): any {
        return (/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z, A-Z]{2,63}(?:\.[a-z,A-Z]{2})?)$/i).test(c.value) ? false : true;
    }
   private validateNoSpaces(c: FormControl): any {
    return /\s/g.test(c.value) ? true : false;
   }

   private validateNoSpecialChar(c: FormControl): any {
    return /[|&;$%'\"<>()+,]/g.test(c.value) ? true : false;
  }

  private validateAtOrDotFollowedByDot(c: FormControl): any {
    return /(\@|\.)\./g.test(c.value) ? true : false;
  }

   private validateStartsOrEndsWithAtOrDot(c: FormControl): any {
    return /^(\@|\.)+|(\@|\.)+$/g.test(c.value) ? true : false;
  }

    private validateAtOnceFn(c: FormControl): any {
    return /([\@]).*?\1/g.test(c.value) ? true : false;
  }

   private validateAtFn(c: FormControl): any {

       if (c.value.indexOf('@') > 0) {
         return false;
      }else{
         return true;
      }
  }

   private validateDotFn(c: FormControl): any {

       if (c.value.indexOf('.') > 0) {
         return false;
      }else{
         return true;
      }
  }


}
