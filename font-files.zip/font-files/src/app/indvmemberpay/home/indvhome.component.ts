import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
import { MwpCsrHttpService } from '../../shared/csr-service/mwp.csr.service';
declare var jQuery: any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-indvhome',
  templateUrl: 'indvhome.component.html'
})
export class IndvHomeComponent implements OnInit {

  memberPaySearchModel = {
    'hcid': '',
    'id': '',
    'firstname': '',
    'lastname': '',
    'dob': '',
    'amt': ''
  }


  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService) { }

  ngOnInit() {
    this.mwpCsrHttpService.automaticPayments = null;
    this.mwpCsrHttpService.hcid = null;
    this.mwpCsrHttpService.selectedMethod = null;
    this.mwpCsrHttpService.selectProductId = null;
  }

  memberPaySearch(hcid: string) {
    this.mwpCsrHttpService.hcid = hcid;
    this.router.navigate(['/memberpay/paymentmethod']);
  }

}
