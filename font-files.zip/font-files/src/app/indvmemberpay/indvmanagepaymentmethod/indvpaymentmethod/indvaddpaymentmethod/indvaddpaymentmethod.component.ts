import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../shared/models/paymentmethod.model'
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvaddpaymentmethod',
  templateUrl: 'indvaddpaymentmethod.component.html',
  styleUrls: ['indvaddpaymentmethod.component.css']
})
export class IndvAddPaymentMethodComponent implements OnInit {

  paymentMethodModel: any = {};
  content : any ={};
  value : string;
  hcidEntered : string = '';
  selectedMethod: string;
  screenLoader: boolean = false;
  techerror: boolean  = false;
  inputParam : any;
  errorMessage: string = '';
  serviceerror: boolean  = false;
  nickNameList: any;
  nickNameError: boolean = false;
  billAddr : any = {};

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService : MwpCsrHttpService){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.inputParam = {};
    this.content = content;
    this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
    this.paymentMethodModel.paymentMethod = 'CreditDebit';
    this.value="CreditDebit";
    this.hcidEntered = this.mwpCsrHttpService.hcid;
    this.serviceerror = false;
    this.techerror = false;
    this.nickNameError = false;
    this.billAddr = {};

    var addrInputParam = {
        "hcid" : this.hcidEntered
    }

    this.mwpCsrHttpService.getdetailsforcsr(addrInputParam, 'getBillingAddress ').subscribe((data:any) => {
        if(null !== data && undefined !== data && null !== data.billingAddress && undefined !== data.billingAddress){
            this.billAddr = data.billingAddress;
            this.changeAddr('SubscriberAddr');
            this.screenLoader = false;
        }
    },
    (err: any) => {
        this.screenLoader = false;
    });    
  }

   savePaymentMethod (paymentMethodModel: PaymentMethodModel){
     this.screenLoader = true;
     this.serviceerror = false;
     this.techerror = false;
     this.nickNameError = false;
     this.nickNameList = this.nickNameCheck();
     if(null !== this.nickNameList && undefined !== this.nickNameList && this.nickNameList !== "" 
                && this.nickNameList .indexOf(paymentMethodModel.accNickName) >= 0){
          this.nickNameError = true;
          this.screenLoader = false;
          return;
     }

     if(paymentMethodModel.paymentMethod === 'Banking') {
          this.inputParam = this.constructBankingReq(paymentMethodModel);
     } else if(paymentMethodModel.paymentMethod === 'CreditDebit') {
          this.inputParam = this.constructCreditDebitReq(paymentMethodModel);
     }
     this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'updatePaymentMethod').subscribe((data:any) => {
        if(null !== data && undefined !== data && null !== data.message && undefined !== data.message 
                      && null !== data.message.messageText && undefined !== data.message.messageText
                      &&  0 === data.message.messageCode) {
            this.screenLoader = false;
            document.getElementById('confirmationModalOpener').click();
        } else {
            this.screenLoader = false;
            this.serviceerror = true;
            this.errorMessage = data.message.messageText;
        }
     },
     (err: any) => {
       this.screenLoader = false;
       //jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
       this.techerror = true;
     });
     this.selectedMethod = 'MPM';
   }

   redirectToHome(selected: string) {
     //this.indvMemberPaymentService.memberPaymentOptions = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   cancel(selected: string){
     //this.indvMemberPaymentService.memberPaymentOptions = selected;
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   changePaymentMethod(paymentMethod: string){
     if(paymentMethod == 'CreditDebit') {
          this.value = "CreditDebit";
          this.paymentMethodModel.paymentMethod = 'CreditDebit';
      } else {
          this.value = "Banking";
          this.paymentMethodModel.paymentMethod = 'Banking';
      }
   }

   constructBankingReq(paymentMethodModel: PaymentMethodModel) {
      return {
        "action" : 'CREATE',
        "hcid" : this.hcidEntered,
        "paymentMethod" : {
            "accNickName" : paymentMethodModel.accNickName,
            "accountName" : paymentMethodModel.accountName,
            "routingNumber" : paymentMethodModel.routingNumber,
            "paymentType" : 'BANKINGACCOUNT',
            "billingAddress" : {
                "addressLine1" : paymentMethodModel.address1,
                "addressLine2" : paymentMethodModel.address2,
                "city" : paymentMethodModel.city,
                "state" : paymentMethodModel.state,
                "postalCode" : paymentMethodModel.zipCode,
                "addressType" : this.getAddressTypeNode(paymentMethodModel.addressOnAccount)
            },
            "bankAccountType" : this.constructBankAccTypeNode(paymentMethodModel.accountType),
            "confirmAccountNo" : paymentMethodModel.confirmAccountNo,
            "maskedAccountNumber" : paymentMethodModel.confirmAccountNo
        }
     };
   }

   constructBankAccTypeNode(accType : string) {
      if(null !== accType && undefined !== accType) {
          if(accType === 'PERSONAL_CHECKING') {
              return 'PERSONALCHECKING';
          } else if(accType === 'PERSONAL_SAVINGS') {
              return 'PERSONALSAVINGS';
          } else if(accType === 'BUSINESS_CHECKING') {
              return 'BUSCHECKING';
          } else if(accType === 'BUSINESS_SAVINGS') {
              return 'BUSSAVINGS';
          }
      }
   }
   
   constructCreditDebitReq(paymentMethodModel: PaymentMethodModel) {
        return {
        "action" : 'CREATE',
        "hcid" : this.hcidEntered,
        "paymentMethod" : {
            "accNickName" : paymentMethodModel.accNickName,
            "accountName" : paymentMethodModel.accountName,
            "paymentType" : 'CREDITDEBITCARD',
            "billingAddress" : {
                "addressLine1" : paymentMethodModel.address1,
                "addressLine2" : paymentMethodModel.address2,
                "city" : paymentMethodModel.city,
                "state" : paymentMethodModel.state,
                "postalCode" : paymentMethodModel.zipCode,
                "addressType" : this.getAddressTypeNode(paymentMethodModel.addressOnAccount)
            },
            "bankAccountType" : (null !== paymentMethodModel.accountType && undefined !== paymentMethodModel.accountType && 'MC' === paymentMethodModel.accountType) ? 'MASTERCARD' : 'VISA',
            "expiration" : paymentMethodModel.expiration,
            "maskedAccountNumber" : paymentMethodModel.confirmAccountNo
        }
     };
   }

   getAddressTypeNode(addrType : string) {
      if(null !== addrType && undefined !== addrType) {
          if(addrType === 'SubscriberAddr') {
              return 'self';
          } else if(addrType === 'AlternativeAddr') {
              return 'alternate';
          }
      } else {
          return 'self';
      }
   }

   nickNameCheck(...args:any[]):any{
    var temp:any = [];
    let response = this.mwpCsrHttpService.payMethodsList;
    if(null != response && undefined !== response && args.length>0){
      for(var i=0;i<=response.length-1; i++){
        if((response[i].accNickName != args[0]) && response[i].accNickName !== "" && args[0] !== undefined && args[0] !== "" && response[i].accNickName !== undefined){
          temp.push(response[i].accNickName);
        }
      }
    }else{
      if(null !== response && undefined !== response){
        for(var i=0;i<=response.length-1; i++){
          if(response[i].accNickName !== "")
          temp.push(response[i].accNickName);
        }
      }
    }
    return temp;
  }

  changeAddr(addrType: string) {
      if(addrType === 'SubscriberAddr') {
          this.paymentMethodModel.address1 = this.billAddr.addressLine1;
          this.paymentMethodModel.address2 = this.billAddr.addressLine2;
          this.paymentMethodModel.city = this.billAddr.city;
          this.paymentMethodModel.state = this.billAddr.state;
          this.paymentMethodModel.zipCode = this.billAddr.postalCode;
      } else {
          this.paymentMethodModel.address1 = '';
          this.paymentMethodModel.address2 = '';
          this.paymentMethodModel.city = '';
          this.paymentMethodModel.state = '';
          this.paymentMethodModel.zipCode = '';
      }
  }
}
