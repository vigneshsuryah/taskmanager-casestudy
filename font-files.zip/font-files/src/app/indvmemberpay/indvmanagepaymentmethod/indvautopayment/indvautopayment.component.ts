import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery: any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { MwpCsrHttpService } from '../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvautopayment',
  templateUrl: 'indvautopayment.component.html',
  styleUrls: ['indvautopayment.component.css']
})
export class IndvAutoPaymentComponent implements OnInit {

  content: any = {};
  selectedMethod: string;
  hcidEntered: string = '';
  screenLoader: boolean = false;
  techerror: boolean = false;
  automaticPayments: any = [];
  recurringSubGroupIdList: any = [];

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService) {
    if (this.currentUser.userRole === undefined) {
      this.router.navigate(['']);
    }
    this.hcidEntered = mwpCsrHttpService.hcid;
  }

  ngOnInit() {
    this.screenLoader = false;
    var inputParam = {
      "hcids": [
        this.hcidEntered
      ]
    }
    this.selectedMethod = 'MAM';
    this.mwpCsrHttpService.selectedMethod = 'MAM';
    this.screenLoader = true;
    this.automaticPayments = [];
    this.recurringSubGroupIdList = [];
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'v2/getRecurringPaymentDetails').subscribe((data: any) => {
      this.screenLoader = false;
      if (null !== data && undefined !== data && null !== data.memberpayRecurringPaymentsMap && undefined !== data.memberpayRecurringPaymentsMap &&
        Object.keys(data.memberpayRecurringPaymentsMap).length > 0) {
        this.automaticPayments = data.memberpayRecurringPaymentsMap[this.hcidEntered];
        this.mwpCsrHttpService.automaticPayments = this.automaticPayments;
        if(this.automaticPayments.length > 0){
          for(let memberpayRecurringPayments of this.automaticPayments){
            if(memberpayRecurringPayments.recurringPayStatus.toUpperCase() === 'ACTIVE'){
              this.recurringSubGroupIdList.push(memberpayRecurringPayments.productId);
            }
          }
        }
        this.mwpCsrHttpService.recurringSubGroupIdList = this.recurringSubGroupIdList;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
  }

  addAutoPayments() {
    this.router.navigate(['/memberpay/addnewautopayment']);
  }

  delete(productId) {
    this.mwpCsrHttpService.selectProductId = productId;
    this.router.navigate(['/memberpay/deleteautopayment']);
  }

  edit(automaticPayment: any) {
    this.mwpCsrHttpService.dayOfMonth = automaticPayment.payDate;
    this.mwpCsrHttpService.selectProductId = automaticPayment.productId;
    this.router.navigate(['/memberpay/editautopayment']);
  }

  redirectToHome(selected: string) {
    this.mwpCsrHttpService.selectedMethod = selected;
    this.router.navigate(['/memberpay/paymentmethod']);
  }

  changePaymentMethod(selectedMethod: string) {
    if (selectedMethod === 'MPM') {
      this.selectedMethod = 'MPM';
    } else if (selectedMethod === 'MAM') {
      this.selectedMethod = 'MAM';
    } else if (selectedMethod === 'EM') {
      this.selectedMethod = 'EM';
    }
  }

}
