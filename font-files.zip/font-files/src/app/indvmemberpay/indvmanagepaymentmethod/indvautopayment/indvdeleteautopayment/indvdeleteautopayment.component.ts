import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery: any;
import { User } from '../../../../shared/models/user';
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';
import { content } from '../../../../shared/constants/constants';

@Component({
  moduleId: module.id,
  selector: 'csr-indvdeleteautopayment',
  templateUrl: 'indvdeleteautopayment.component.html',
  styleUrls: ['indvdeleteautopayment.component.css']
})
export class IndvDeleteAutoPaymentComponent implements OnInit {

  userName: string = '';
  hcidEntered: string = '';
  techerror: boolean = false;
  automaticPayments: any = [];
  screenLoader: boolean = false;
  selectedProductId: string = '';
  selectedBill: any;
  deletedFlag: boolean = true;
  errorMessage: string = '';
  authorizationText: string = '';
  content: any = {};
  emailAddressChecked: boolean = false;

  emailAddressTxt: string = '';
  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService) {
    if (this.currentUser.userRole === undefined) {
      this.router.navigate(['']);
    }
    this.userName = this.currentUser.username;

  }

  ngOnInit() {
    this.content = content;
    this.hcidEntered = this.mwpCsrHttpService.hcid;
    this.automaticPayments = this.mwpCsrHttpService.automaticPayments;
    this.selectedProductId = this.mwpCsrHttpService.selectProductId;

    for (let automaticPayment of this.automaticPayments) {
      if (automaticPayment.productId == this.selectedProductId) {
        for (let linkedBill of automaticPayment.memberDetails.linkedBills) {
          for (let billAccount of linkedBill.billAccounts) {
            if (this.selectedProductId == billAccount.subGroupId) {
              let hcidOrSummaryNo = linkedBill.contractIndicators == 'SUMMARY_BILLED_MEMBER' ? linkedBill.groupId : this.hcidEntered;
              this.selectedBill = {
                "subGroupName": billAccount.subGroupName,
                "productId": billAccount.subGroupId,
                "hcidOrSummaryNo": hcidOrSummaryNo,
                "planName": billAccount.planName,
                "subscriberName": automaticPayment.memberDetails.firstName + " " + automaticPayment.memberDetails.lastName,
                "billDate": billAccount.billDate,
                "minDue": billAccount.minDue,
                "totalDue": billAccount.totalDue,
                "dueDate": billAccount.dueDate
              }
              break;
            }
          }
        }
      }
    }
  }

  redirectToHome(selected: string) {
    jQuery("#confirmationModalOpener").click();
    this.mwpCsrHttpService.selectedMethod = selected;
    this.router.navigate(['/memberpay/paymentmethod']);
  }

  cancelAutoPay(selected: string) {
    this.mwpCsrHttpService.selectedMethod = selected;
    this.router.navigate(['/memberpay/paymentmethod']);
  }

  redirectToAutoPay(selected: string) {
    let recurringList = [];
    let recurringPaymentDetails: any = {};
    let autoPay: any = {};
    for (let automaticPayment of this.automaticPayments) {
      if (automaticPayment.productId == this.selectedProductId) {
        for (let linkedBill of automaticPayment.memberDetails.linkedBills) {
          for (let billAccount of linkedBill.billAccounts) {
            if (this.selectedProductId == billAccount.subGroupId) {
              recurringPaymentDetails.productId = this.selectedProductId;
              if (null !== automaticPayment.paymentMethods) {
                let paymentMethods = {
                  "paymentType": automaticPayment.paymentMethods.paymentType,
                  "bankAccountType": automaticPayment.paymentMethods.bankAccountType,
                  "tokenId": automaticPayment.paymentMethods.tokenId
                }
                recurringPaymentDetails.paymentMethods = paymentMethods;
              }
              let billAccounts = [];
              let billAccDet = {
                "paidToDate": billAccount.paidToDate,
                "subGroupId": billAccount.subGroupId
              }
              billAccounts.push(billAccDet);
              let linkedBills = [];
              let linkedBillDet = {
                "linkRelationship": linkedBill.linkRelationship,
                "personDetails": {
                  "hcid": this.hcidEntered,
                  "brand": automaticPayment.memberDetails.brand
                },
                "billAccounts": billAccounts
              }
              linkedBills.push(linkedBillDet);
              var memberDetails = {
                "hcid": this.hcidEntered,
                "linkedBills": linkedBills
              }
              recurringPaymentDetails.memberDetails = memberDetails;
              recurringPaymentDetails.payDate = automaticPayment.payDate;
              recurringPaymentDetails.createdBy = this.userName;
              recurringPaymentDetails.authMode = this.authorizationText;
              if (this.emailAddressChecked && null != this.emailAddressTxt && this.emailAddressTxt !== '') {
                recurringPaymentDetails.emailId = this.emailAddressTxt;
              }
              recurringList.push(recurringPaymentDetails);
            }
          }
        }
      }
    }
    var inputParam = {
      "hcid": this.hcidEntered,
      "action": "DEL",
      "recurringPaymentDetails": recurringList
    }
    this.screenLoader = true;
    this.automaticPayments = [];
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'updateRecurringPayment').subscribe((data: any) => {

      if (null != data.recurringPaymentDetails && undefined !== data.recurringPaymentDetails && data.recurringPaymentDetails.length > 0) {
        for (let autoPay of data.recurringPaymentDetails) {
          if (autoPay.productId == this.selectedProductId) {
            this.deletedFlag = autoPay.confirmStatus == 'Failed' ? false : true;
            this.errorMessage = autoPay.errorMessage;
          }
        }
      }
      if (this.deletedFlag) {
        this.screenLoader = false;
        jQuery("#confirmationModalOpener").click();
      }
      else {
        this.screenLoader = false;
        return;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
  }

}
