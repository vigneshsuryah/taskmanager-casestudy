import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';

@Component({
  moduleId: module.id,
  selector: 'csr-indvpaymenthistory',
  templateUrl: 'indvpaymenthistory.component.html',
  styleUrls: ['indvpaymenthistory.component.css']
})
export class IndvpaymentHistoryComponent  {

}
