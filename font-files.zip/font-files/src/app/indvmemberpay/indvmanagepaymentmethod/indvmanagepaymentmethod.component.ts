import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
import { MwpCsrHttpService } from '../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvmanagepaymentmethod',
  templateUrl: 'indvmanagepaymentmethod.component.html',
  styleUrls: ['indvmanagepaymentmethod.component.css']
})
export class IndvManagePaymentMethodComponent implements OnInit {

  content : any ={};
  selectedMethod: string;

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService){}

   ngOnInit() {
     this.selectedMethod = 'MPM';
     if(null != this.mwpCsrHttpService.selectedMethod  && undefined !== this.mwpCsrHttpService.selectedMethod && this.mwpCsrHttpService.selectedMethod !== ''){
       this.selectedMethod = this.mwpCsrHttpService.selectedMethod;
     }
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      } else if (selectedMethod === 'PH'){
        this.selectedMethod = 'PH';
      } else if (selectedMethod === 'PDF'){
        this.selectedMethod = 'PDF';
      }
   }

}
