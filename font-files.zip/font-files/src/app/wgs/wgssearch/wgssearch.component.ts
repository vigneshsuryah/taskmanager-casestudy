import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { Wgscsr } from '../../shared/models/wgs/wgscsr';
import { WgsService } from '../../shared/csr-service/wgs.service';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-wgssearch',
  templateUrl: 'wgssearch.component.html',
  styleUrls: ['wgssearch.component.css']
})
export class WgsSearchComponent {

  hcid: string;
  screenLoader: boolean = false;
  responseCode: string;
  showContent: string;
  isExactLength: boolean = true;
  isValidHcid: boolean = true;
  hasHcid: boolean = true;
  wgsSearchModel = {
    'hcid':'',
  }

  constructor (public router: Router, public wgscsr : Wgscsr, public wgsService: WgsService, private currentUser: User ) {
      //console.log('this.currentUser.userRole: ' + this.currentUser.userRole);
      if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
      }
  }

  searchPayDetails(searchHcid : string){
     if(searchHcid.length == 0){
      this.hasHcid = false;
      this.isExactLength = true;
      this.isValidHcid = true;
    } else if(searchHcid.length < 9 || searchHcid.length > 20){
      this.isExactLength = false;
      this.hasHcid = true;
      this.isValidHcid = true;
    } else {
      this.isValidMember(searchHcid);
    }
  }

  isValidMember(hcid: string){
    this.wgscsr.billEntityNumbers = [];
    this.wgscsr.paymentOption = 'MPM';
    this.screenLoader = true
    var inputParams = {
      "healthCardId" : hcid
    }
    this.wgscsr.healthCardId = hcid;
    this.wgscsr.billEntityNumbers = ['BEN001','BEN002','BEN003'];
    this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
    this.isValidHcid = true;
    this.hasHcid = true;
    this.isExactLength = true;   
    this.screenLoader = false;
  }

  clearHcid(){
    jQuery("#hcid").val("");
    this.isValidHcid = true;
    this.hasHcid = true;
    this.isExactLength = true;
  }
}
