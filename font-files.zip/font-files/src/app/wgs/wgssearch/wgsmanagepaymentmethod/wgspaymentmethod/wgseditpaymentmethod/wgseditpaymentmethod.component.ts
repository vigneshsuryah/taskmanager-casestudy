import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { content } from '../../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../../shared/models/paymentmethod.model';
import { SubscriberAddressModel } from '../../../../../shared/models/wgs/subscriberaddress.model';
import { WgsService } from '../../../../../shared/csr-service/wgs.service';
import { Wgscsr } from '../../../../../shared/models/wgs/wgscsr';
import { NgForm } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-wgseditpaymentmethod',
  templateUrl: 'wgseditpaymentmethod.component.html',
  styleUrls: ['wgseditpaymentmethod.component.css']
})
export class WgsEditPaymentMethodComponent implements OnInit {

  nickNameError:boolean=false;

  paymentMethodModel = {
    'paymentMethod': '',
    'nickName': '',
    'accountType': '',
    'bankRoutingNbr': '',
    'bankAccountNbr': '',
    'reEnterbankAccountNbr': '',
    'accountHolderName': '',
    'addressOnAccount': '',
    'address1': '',
    'address2': '',
    'city': '',
    'state': '',
    'zipCode': '',
    'expiryDate': ''
  }
  subscriberAddressModel = {
    'address1': 'SubscriberAddr One',
    'address2': 'SubscriberAddr Two',
    'city': 'Subscriber City',
    'state': 'KY',
    'zipcode': '90001'
  }
  content : any ={};
  screenLoader: boolean = false;
  techerror: boolean = false;
  updatePaymentMethodResponse: any = {};
  editPaymentMethodResponse: any = {};
  updateError: boolean = false;
  usedNickNames: string[] = [];
  nicknameChanged: boolean = false;
    
  constructor(public router: Router, public wgsService : WgsService, public wgscsr : Wgscsr){}

  ngOnInit() {
    this.content = content;
    this.editPaymentMethodResponse = this.wgscsr.editPaymentMethodResponse;
    this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
    this.paymentMethodModel.nickName = this.editPaymentMethodResponse.accountNickname;
    this.paymentMethodModel.accountType = this.editPaymentMethodResponse.bankAccountType;
    this.paymentMethodModel.bankRoutingNbr = this.editPaymentMethodResponse.routingNumber;
    this.paymentMethodModel.accountHolderName = this.editPaymentMethodResponse.accountHolderName;
    this.paymentMethodModel.address1 = this.editPaymentMethodResponse.accountAddress1;
    this.paymentMethodModel.address2 = this.editPaymentMethodResponse.accountAddress2;
    this.paymentMethodModel.city = this.editPaymentMethodResponse.accountCity;
    this.paymentMethodModel.state = this.editPaymentMethodResponse.accountState;
    this.paymentMethodModel.zipCode = this.editPaymentMethodResponse.accountPostalCode;
    this.paymentMethodModel.reEnterbankAccountNbr = this.getMaskedAccountNumber(this.editPaymentMethodResponse.bankAccountNumber);
    this.paymentMethodModel.bankAccountNbr = this.getMaskedAccountNumber(this.editPaymentMethodResponse.bankAccountNumber);

    jQuery("#bankRoutingNbr").prop('disabled',true);
    jQuery("#bankAccountNbr").prop('disabled',true);
    jQuery("#reEnterbankAccountNbr").prop('disabled',true);
    jQuery("#accountType").find(".psButton").prop('disabled',true);  
    jQuery("#accountType").find(".psOption").prop('disabled',true);
    jQuery("#paymentMethod").find(".psButton").prop('disabled',true);  
    jQuery("#paymentMethod").find(".psOption").prop('disabled',true);

    this.usedNickNames = this.wgscsr.existingNickNames;
  }

   editPaymentMethod (paymentMethodModel: PaymentMethodModel){
      this.screenLoader = true;
      this.techerror = false;
      this.updateError = false;
      this.nickNameError = false;
      this.nicknameChanged = false;
      if(this.editPaymentMethodResponse.accountNickname !== paymentMethodModel.nickName){
        this.nicknameChanged = true;
      }
      if(this.usedNickNames.indexOf(paymentMethodModel.nickName) > -1 && this.nicknameChanged){
        this.nickNameError = true;
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
      } else {
        var inputParams = {
                "action" : "EDIT",
                "memberId" : this.wgscsr.healthCardId,
                "bankAccountDetails" : {
                  "bankAccountType" : paymentMethodModel.accountType,
                  "routingNumber" : paymentMethodModel.bankRoutingNbr,
                  "bankAccountNumber" : paymentMethodModel.bankAccountNbr,
                  "accountHolderName" : paymentMethodModel.accountHolderName,
                  "accountAddress1" : paymentMethodModel.address1,
                  "accountAddress2" : paymentMethodModel.address2,
                  "accountCity" : paymentMethodModel.city,
                  "accountState" : paymentMethodModel.state,
                  "accountPostalCode" : paymentMethodModel.zipCode,
                  "accountNickname" : paymentMethodModel.nickName,
                  "tokenId": this.editPaymentMethodResponse.tokenId
                }
              }
              this.wgsService.updatePaymentMethods(inputParams).subscribe((data: any) => {
                this.screenLoader = false;
                this.updatePaymentMethodResponse = data;
                if (this.updatePaymentMethodResponse.status === 'SUCCESS') {
                  jQuery("#confirmationModalOpener").click();
                } else {
                  jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                  this.updateError = true;
                }
              },
              (err: any) => {
                jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                this.techerror = true;
                this.screenLoader = false;
              });
      }   
   }

   redirectToHome(selected: string) {
     this.wgscsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   cancel(selected: string){
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   changeAddressOnAccount(addressType: string){
     if(addressType === 'SubscriberAddr'){
        this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        this.paymentMethodModel.address1 = this.subscriberAddressModel.address1;
        this.paymentMethodModel.address2 = this.subscriberAddressModel.address2;
        this.paymentMethodModel.city = this.subscriberAddressModel.city;
        this.paymentMethodModel.state = this.subscriberAddressModel.state;
        this.paymentMethodModel.zipCode = this.subscriberAddressModel.zipcode;
     } else {
        this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
        this.paymentMethodModel.address1 = this.editPaymentMethodResponse.accountAddress1;
        this.paymentMethodModel.address2 = this.editPaymentMethodResponse.accountAddress2;
        this.paymentMethodModel.city = this.editPaymentMethodResponse.accountCity;
        this.paymentMethodModel.state = this.editPaymentMethodResponse.accountState;
        this.paymentMethodModel.zipCode = this.editPaymentMethodResponse.accountPostalCode;
     }
   }

  getMaskedAccountNumber(bankAccountNumber: string){
    let maskedNumber = '';
    let indexVal = bankAccountNumber.length - 4;
    let accountNumber = bankAccountNumber.substring(indexVal);
    for(let i=0; i < indexVal; i++){
      maskedNumber = maskedNumber + '*';
    }
    return maskedNumber + accountNumber;
  }
}
