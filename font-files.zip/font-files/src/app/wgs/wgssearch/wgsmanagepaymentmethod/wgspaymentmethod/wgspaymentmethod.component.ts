import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { WgsService } from '../../../../shared/csr-service/wgs.service';
import { Wgscsr } from '../../../../shared/models/wgs/wgscsr';
import { PaymentMethod } from '../../../../shared/models/gbdpay/paymentmethod.model';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-wgspaymentmethod',
  templateUrl: 'wgspaymentmethod.component.html',
  styleUrls: ['wgspaymentmethod.component.css']
})
export class WgsPaymentMethodComponent implements OnInit {

  content : any ={};
  hcid: string;
  selectedMethod: string;
  screenLoader: boolean = false;
  techerror: boolean = false;
  getPaymentMethodResponse: any = {};
  countPay = 0;
  bankPayList: PaymentMethod[];
  tokenDelete: string;


  constructor(public router: Router, public wgscsr : Wgscsr, public wgsService : WgsService){
     
  }

   ngOnInit() {
     if ( this.wgscsr.healthCardId === undefined) {
      this.router.navigate(['/wgs/wgssearch']);
     }
     this.hcid = this.wgscsr.healthCardId;
     this.techerror = false;
     this.getPaymentMethods();
   }

   redirectToaddNewPaymentMethod (){
    this.router.navigate(['/wgs/wgsaddpaymentmethod']);
   }

   redirectToHome() {
       this.router.navigate(['/wgs/wgssearch']);
   }
   
   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      }
   } 

   cancelDelete(selected: string){
      this.wgscsr.paymentOption = selected;
      jQuery("#confirmationModalOpener").click();
      this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   confirmDelete(selected: string){
      this.screenLoader = true;
      var bankAccountDetail = {
        "tokenId" : this.tokenDelete
      };
      var inputParams = {
        "action" : "DELETE",
	      "memberId" : this.wgscsr.healthCardId,
        "bankAccountDetails" : bankAccountDetail
      };  
     this.wgsService.updatePaymentMethods(inputParams).subscribe(
      (data: any) => {
        this.screenLoader = false;
        jQuery("#confirmationModalOpener").click();
        jQuery("#deleteConfirmationModalOpener").click();
        this.getPaymentMethods();
      },
      (error) => {
        jQuery("#confirmationModalOpener").click();
        this.screenLoader = false;
        this.techerror = true;
        jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      }
    );
    this.wgscsr.paymentOption = selected;
   }

   delete(index: string){
     this.tokenDelete = this.bankPayList[index].tokenId;
     jQuery("#confirmationModalOpener").click();    
   }

   edit(paymentMethod: any){
     this.wgscsr.editPaymentMethodResponse = paymentMethod;
     this.router.navigate(['/wgs/wgseditpaymentmethod']);   
   }

   success(selected:string){
     this.wgscsr.paymentOption = selected;
     jQuery("#deleteConfirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

    getPaymentMethods(){
      this.techerror = false;
      this.screenLoader = true;
      this.countPay = 0;
      var inputParams = {
          "memberId" : this.wgscsr.healthCardId
      }
   
      this.wgsService.getPaymentMethods(inputParams).subscribe((data: any) => {
      this.screenLoader = false;
      const nicknames: string[] = [];
      this.getPaymentMethodResponse = data;
      if (this.getPaymentMethodResponse.bankAccountDetails !== undefined) {
         this.bankPayList = this.getPaymentMethodResponse.bankAccountDetails;
         this.countPay +=  this.getPaymentMethodResponse.bankAccountDetails.length;
         for (const entryPay of this.bankPayList) {
           const accountNickname = entryPay.accountNickname;
           if (accountNickname !== undefined && accountNickname !== '') {
             nicknames.push(accountNickname);
           }
         }
     }
     this.wgscsr.existingNickNames = nicknames;   
    },
    (err: any) => {
      this.techerror = true;
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      });
    }

    getMaskedAccountNumber(bankAccountNumber: string){
      let maskedNumber = '';
      let indexVal = bankAccountNumber.length - 4;
      let accountNumber = bankAccountNumber.substring(indexVal);
      for(let i=0; i < indexVal; i++){
        maskedNumber = maskedNumber + '*';
      }
      return maskedNumber + accountNumber;
    }
}
