import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Wgscsr } from '../../../shared/models/wgs/wgscsr';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-wgsmanagepaymentmethod',
  templateUrl: 'wgsmanagepaymentmethod.component.html',
  styleUrls: ['wgsmanagepaymentmethod.component.css']
})
export class WgsManagePaymentMethodComponent implements OnInit {

  content : any ={};
  selectedMethod: string;

  constructor(public router: Router, public wgscsr : Wgscsr){}

   ngOnInit() {
      if (this.wgscsr.paymentOption !== undefined) {
       this.selectedMethod = this.wgscsr.paymentOption;
     } else {
       this.selectedMethod = 'MAM'
     }
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      } else if (selectedMethod === 'PH'){
        this.selectedMethod = 'PH';
      } else if (selectedMethod === 'PDF'){
        this.selectedMethod = 'PDF';
      }
   }

}
