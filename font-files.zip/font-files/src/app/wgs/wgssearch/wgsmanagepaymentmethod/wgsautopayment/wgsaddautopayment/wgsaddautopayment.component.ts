import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../../../../shared/models/user';
import { content } from '../../../../../shared/constants/constants';
import { Wgscsr } from '../../../../../shared/models/wgs/wgscsr';
import { WgsService } from '../../../../../shared/csr-service/wgs.service';
declare var jQuery:any;
import { DatePipe } from '@angular/common'; 

@Component({
  moduleId: module.id,
  selector: 'csr-wgsaddautopayment',
  templateUrl: 'wgsaddautopayment.component.html',
  styleUrls: ['wgsaddautopayment.component.css']
})
export class WgsAddAutoPaymentComponent implements OnInit {

  wgscsrModel = {  
    'authorization': '',
    'paymentMethod': '',
    'dayOfMonth': '',
    'isChecked': false
  }
  addAutoModel : any = [];
  content: any ={};
  screenLoader: boolean = false;
  getPaymentMethodResponse: any = {};
  responseLength: any = 0;
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  ccResponse: any = {};
  baResponse: any = {};
  isCC: boolean = false;
  isBA: boolean = false;
  paymentType: string;
  getSummaryResponse: any = {};
  getLinkedBillsList: any = [];
  techerror: boolean = false;
  billEntityNumbers : any = [];
  paymentmethodReqError : boolean = false;
  planError : boolean = false;

  constructor(public router: Router, public wgsService: WgsService, private currentUser: User, private wgscsr : Wgscsr, private datePipe: DatePipe){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.content = content;
    this.content.billEntityNoCheckBoxList = [];
    this.paymentmethodReqError = false;
    this.planError = false;
    this.screenLoader = true;
    // setTimeout(()=>{
    //     jQuery("#dayOfMonth").find(".psButton").prop('disabled',true);  
    //     jQuery("#dayOfMonth").find(".psOption").prop('disabled',true);
    //     jQuery(".sb-checkbox-font").find(".pcLabel").addClass('pcLabelFontOverride');
    // },100);
    jQuery.fn.datepicker.defaults.autoclose = true;
    jQuery.fn.datepicker.defaults.format = "mm/dd/yyyy";
    jQuery.fn.datepicker.defaults.orientation = "bottom auto";    
    this.wgscsrModel.dayOfMonth = '03';
    this.billEntityNumbers = this.wgscsr.billEntityNumbers;
    if(undefined != this.billEntityNumbers && null != this.billEntityNumbers && this.billEntityNumbers.length > 0){
          for(let billEntityNo of this.billEntityNumbers){
                 var dynamicCheckBoxName = {
                    id: 'billEntityNo' + billEntityNo,
                    name: 'billEntityNo' + billEntityNo,
                    label: billEntityNo,
                    trueValue: true,
                    falseValue: false
                  };
                 this.content.billEntityNoCheckBoxList.push(dynamicCheckBoxName);
                 var addautotext = {
                      'autopayStDt':this.datePipe.transform(new Date(), 'MM/dd/yyyy'),
                      'autopayEndDt':this.datePipe.transform(new Date(), 'MM/dd/yyyy'),
                      'isChecked':false,
                      'billEntityNo':billEntityNo,
                      'planName':'KY HEALTH (MEMBER PREMIUM)'
                 };
                 this.addAutoModel.push(addautotext);
          }
    }

    //this.getSummary();
    this.getPaymentMethods();

  }

  getSummary(){
      this.getSummaryResponse = {};
      this.getLinkedBillsList = [];
      var inputParams = {
        "healthCardId" : this.wgscsr.healthCardId
      }
      this.screenLoader = true;
      this.screenLoader = false;
    //   this.wgsService.getSummary(inputParams).subscribe((data: any) => {    
    //     this.getSummaryResponse = data;
    //     this.getLinkedBillsList = this.getSummaryResponse.linkedBills;
    //     this.screenLoader = false;
    //   },
    //   (err: any) => {
    //     jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
    //     this.techerror = true;
    //     this.screenLoader = false;
    //   } 
    // );
  }
  
  getPaymentMethods(){
      var paymentMethodsListComposed: any = [];
      var inputParams = {
        "memberId" : this.wgscsr.healthCardId
      }
      this.screenLoader = true;
      this.wgsService.getPaymentMethods(inputParams).subscribe((data: any) => {
      this.getPaymentMethodResponse = data;
      if ((this.getPaymentMethodResponse.creditCardDetails !== undefined && this.getPaymentMethodResponse.creditCardDetails.length == 0)
          || (this.getPaymentMethodResponse.bankAccountDetails !== undefined && this.getPaymentMethodResponse.bankAccountDetails.length == 0)) {
            this.responseLength = 0;
            let tempBnkItem = {
                  label : 'No Saved Payment method',
                  value : 'No Saved Payment method'
            }
           paymentMethodsListComposed.push(tempBnkItem);
      } else {
        if (this.getPaymentMethodResponse.creditCardDetails !== undefined){
          var ccList = this.getPaymentMethodResponse.creditCardDetails;
          this.responseLength += ccList.length;
          for(var i = 0; i <= ccList.length-1; i++){
            var labelString = '';
            this.creditCardBankAccNbrMap[ccList[i].tokenId] = ccList[i].creditCardNumber;
            this.paymentTypeMap[ccList[i].tokenId] = 'CreditDebitCard';

            if(ccList[i].creditCardType == "MC"){
              labelString = "Mastercard ending in ";
            }else if(ccList[i].creditCardType == "VISA"){
              labelString = "VISA ending in ";
            }
            labelString = labelString + ccList[i].creditCardNumber.slice(-4);
            var tempCCItem = {
              label : labelString,
              value : ccList[i].tokenId
            }
            paymentMethodsListComposed.push(tempCCItem);
            }
        }

        if (this.getPaymentMethodResponse.bankAccountDetails !== undefined) {
          var bnkList = this.getPaymentMethodResponse.bankAccountDetails;
          this.responseLength += bnkList.length;
          for(var i = 0; i <= bnkList.length-1; i++){
            var labelString = '';
            this.creditCardBankAccNbrMap[bnkList[i].tokenId] = bnkList[i].bankAccountNumber;
            this.paymentTypeMap[bnkList[i].tokenId] = 'Banking';
            this.bankAccountTypeMap[bnkList[i].tokenId] = bnkList[i].bankAccountType;

            if(bnkList[i].bankAccountType == "BUSINESS_SAVINGS" || bnkList[i].bankAccountType == "PERSONAL_SAVINGS"){
              labelString = "Savings ending in ";
            }else if(bnkList[i].bankAccountType == "BUSINESS_CHECKING" || bnkList[i].bankAccountType == "PERSONAL_CHECKING"){
              labelString = "Checking ending in ";
            }
            labelString = labelString + bnkList[i].bankAccountNumber.slice(-4);
            var tempBnkItem = {
              label : labelString,
              value : bnkList[i].tokenId
            }
            paymentMethodsListComposed.push(tempBnkItem);
            }            
        }
      }
      this.screenLoader = false; 
    },
    (err: any) => {
      this.screenLoader = false;
      this.techerror = true;
      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      });
    this.content.paymentMethodsList = paymentMethodsListComposed;
  }

   saveAutoPaymentMethod (wgscsrModel: any){
      this.planError = false;
      this.paymentmethodReqError = false;
       let chkedCount = 0;
      for(let addautopay of this.addAutoModel){
        if(addautopay.isChecked){
          chkedCount++;
        }
      }
      if(chkedCount == 0){
        this.planError = true;
        jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      }
      if(wgscsrModel.paymentMethod === ''){
          this.paymentmethodReqError = true;
      }
      if( this.planError || this.paymentmethodReqError){
        return;
      }
      this.screenLoader = true;
      for(let recurringPayments of this.getLinkedBillsList){
          var inputParams = {
            "healthCardId": this.wgscsr.healthCardId,
            "recurringPaymentDetails": [{
              "planID": recurringPayments.billAccounts[0].planId,
              "productID": recurringPayments.billAccounts[0].productId,
              "payDate": wgscsrModel.dayOfMonth,
              "createdBy": this.wgscsr.healthCardId,
              "authMode": "PPD",
              "tokenID": wgscsrModel.paymentMethod,
              "paymentType": this.paymentType
            }],
            "action": "ADD",
            "csrFlag": true,
            "csrUserId": this.currentUser.username
          }   
        }  

        this.wgsService.updateRecurring(inputParams).subscribe((data: any) => {
            this.screenLoader = false;
            if(data.message.messageCode === "0"){
            jQuery("#confirmationModalOpener").click();
            } 
        },
        (err: any) => {
            this.screenLoader = false;
            this.techerror = true;
            jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
        }
        );
   }

   cancel(selected: string){
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   redirectToAutoPay(selected: string){
     this.wgscsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   formatDate(inputDate: string){
     var dateArr  = [];
     if(null !== inputDate && undefined !== inputDate){
        dateArr = inputDate.split("-");
        if(dateArr.length === 3){
          inputDate = dateArr[1] + "/" + dateArr[2] + "/" + dateArr[0];
        }
     }
     return inputDate;
   }

   formatAmount(inputAmt: string){
     if(null !== inputAmt && inputAmt.length > 0 && undefined !== inputAmt){
       inputAmt = "$" + inputAmt;
     }
     return inputAmt;
   }

   selectedPaymentMethod(selectedPayment: string){
     if(this.paymentTypeMap[selectedPayment] === 'CreditDebitCard'){
       this.isCC = true;
       this.isBA = false;
       for(let creditCardDetails of this.getPaymentMethodResponse.creditCardDetails){
         if(creditCardDetails.tokenId === selectedPayment){
            this.ccResponse = creditCardDetails;
            break;
         }
       }
       this.paymentType = "CREDITCARD"; 
     } else if(this.paymentTypeMap[selectedPayment] === 'Banking'){
       this.isBA = true;
       this.isCC = false;
        for(let bankAccountDetails of this.getPaymentMethodResponse.bankAccountDetails){
           if(bankAccountDetails.tokenId === selectedPayment){
            this.baResponse = bankAccountDetails;
            break;
         }
        }
        this.paymentType = "BANKACCOUNT";
     }
   }

   formatType(accountType: string){
     if(accountType === 'BUSINESS_SAVINGS'){
       return accountType = 'Business Savings';
     }else if(accountType === 'PERSONAL_SAVINGS'){
       return accountType = 'Personal Savings';
     }else if(accountType === 'BUSINESS_CHECKING'){
       return accountType = 'Business Checking';
     }else if(accountType === 'PERSONAL_CHECKING'){
       return accountType = 'Personal Checking';
     }else if(accountType === 'MC'){
        return accountType = 'Master Card';
     }else if(accountType === 'VISA'){
        return accountType = 'VISA';
     }
   }

   removePayMethodError(){
     this.paymentmethodReqError = false;
   }

   getMaskedAccountNumber(bankAccountNumber: string){
      let maskedNumber = '';
      let indexVal = bankAccountNumber.length - 4;
      let accountNumber = bankAccountNumber.substring(indexVal);
      for(let i=0; i < indexVal; i++){
        maskedNumber = maskedNumber + '*';
      }
      return maskedNumber + accountNumber;
    }
      
}
