import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: '',
  templateUrl: 'wgshome.component.html',
  styleUrls: ['wgshome.component.css']
})
export class WgsHomeComponent implements OnInit {

  constructor (public router : Router, private currentUser: User) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit(){
    
  }

  redirectToSystem(system : string){
    this.router.navigate(['/wgs/wgssearch']);
  }

}