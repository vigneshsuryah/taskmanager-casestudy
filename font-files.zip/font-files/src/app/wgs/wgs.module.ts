import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WgsHomeComponent } from './home/wgshome.component';
import { WgsSearchComponent } from './wgssearch/wgssearch.component';
import { routes } from './wgs.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DatePipe } from '@angular/common'; 
import { WgsAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgsautopayment.component';
import { WgsAddAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgsaddautopayment/wgsaddautopayment.component';
import { WgsEditAutoPaymentComponent } from './wgssearch/wgsmanagepaymentmethod/wgsautopayment/wgseditautopayment/wgseditautopayment.component';
import { WgsPaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgspaymentmethod/wgspaymentmethod.component';
import { WgsEditPaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgspaymentmethod/wgseditpaymentmethod/wgseditpaymentmethod.component';
import { WgsAddPaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgspaymentmethod/wgsaddpaymentmethod/wgsaddpaymentmethod.component';
import { WgsManagePaymentMethodComponent } from './wgssearch/wgsmanagepaymentmethod/wgsmanagepaymentmethod.component';
import { Wgscsr } from '../shared/models/wgs/wgscsr';
import { WgsService } from '../shared/csr-service/wgs.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),    
    RouterModule.forChild(routes)
  ],
   providers: [
    Wgscsr,
    WgsService,
    DatePipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [WgsHomeComponent,
    WgsSearchComponent,
    WgsAutoPaymentComponent,
    WgsAddAutoPaymentComponent,
    WgsEditAutoPaymentComponent,
    WgsPaymentMethodComponent,
    WgsEditPaymentMethodComponent,
    WgsAddPaymentMethodComponent,
    WgsManagePaymentMethodComponent]
})
export class WgsModule { 

}
