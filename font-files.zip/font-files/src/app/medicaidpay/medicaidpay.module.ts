import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MedicaidHomeComponent } from './home/medicaidhome.component';
import { PaymentDetailsComponent } from './paymentdetails/paymentdetails.component';
import { routes } from './medicaidpay.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { StartpaymentComponent } from './startpayment/startpayment.component';
import { IppHttpService } from '../shared/csr-service/ipphttp.service';
import { MedicaidPayService } from '../shared/csr-service/medicaidpay.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    HttpClientModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [
    IppHttpService, MedicaidPayService,MedicaidHomeComponent,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    DatePipe
  ],
  declarations: [MedicaidHomeComponent, PaymentDetailsComponent, StartpaymentComponent]
})
export class MedicaidPayModule {

}
