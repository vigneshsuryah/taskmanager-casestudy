import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { content } from '../../shared/constants/constants';
declare var jQuery:any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-reportshome',
  templateUrl: 'reportshome.component.html',
  styleUrls: ['reportshome.component.css']
})
export class ReportsHomeComponent implements OnInit {

  selectedMethod: string;
  
  constructor (public router : Router, private currentUser: User) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit(){
    this.selectedMethod = 'TPTS';
  }

  changePaymentMethod(selectedMethod: string){
    if(selectedMethod === 'CASHPAY'){
      this.selectedMethod = 'CASHPAY';
    } else if(selectedMethod === 'TPTS'){
      this.selectedMethod = 'TPTS';
    } else if(selectedMethod === 'ACCOUNTING'){
      this.selectedMethod = 'ACCOUNTING';
    }
 }

}