import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { User } from '../../shared/models/user';
import { ReportsService } from '../../shared/csr-service/reports.service';
import { DatePipe } from '@angular/common'; 

@Component({
  moduleId: module.id,
  selector: 'csr-accounting',
  templateUrl: 'accounting.component.html',
  styleUrls: ['accounting.component.css']
})
export class AccountingComponent implements OnInit {

  accounting = {  
    'fromdate': this.datePipe.transform(new Date(), 'MM-dd-yyyy') ,
    'todate': this.datePipe.transform(new Date(), 'MM-dd-yyyy') ,
    'reportTypeSelected': ''
  }

  options = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Transactions List',
    useBom: false,
    noDownload: false,
    headers: []
  };
  
  noResults: boolean = true;
  techerror: boolean = false; 
  screenLoader: boolean = false;
  showTable: boolean = false;
  inputParam : any = {};
  transactionDetails : any = [];
  

  reportType = [{
    label: 'Completed Transactions',
    value: 'Completed'
  },{
    label: 'Returned Transaction',
    value: 'Returned'
  },{
    label: 'Reimbursed Transaction',
    value: 'Reimbursed'
  },{
    label: 'NOC Transaction',
    value: 'NOC'
  }];

  
  constructor(public router: Router, private currentUser: User, private reportsService : ReportsService, private datePipe: DatePipe ) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
        this.noResults = true;
        this.techerror = false;
        this.transactionDetails = [];
        this.accounting.reportTypeSelected = 'Completed';
        jQuery.fn.datepicker.defaults.autoclose = true;
        jQuery.fn.datepicker.defaults.format = "mm-dd-yyyy";
        jQuery.fn.datepicker.defaults.endDate = "0d";
        jQuery.fn.datepicker.defaults.orientation = "bottom auto";       
   }
 
   getTransactionDetails(){
     
      this.transactionDetails = [];
      this.noResults = true;
      this.screenLoader = true;
      this.techerror = false;
      this.inputParam = {
        "fromDate": this.datePipe.transform(jQuery('#fromDate').val(), 'yyyy-MM-dd'),
        "toDate":this.datePipe.transform(jQuery('#toDate').val(), 'yyyy-MM-dd'),
        "reportType": this.accounting.reportTypeSelected
      }
      
      this.transactionDetails = [];

    this.reportsService.getTransactionDetails(this.inputParam).subscribe((data:any) => {
      this.screenLoader = false;
      this.showTable = true;
      let sNo =  1;
      if(null !== data && undefined !== data && null !== data.transactionDetail && undefined !== data.transactionDetail && data.transactionDetail.length > 0){
      
        data.transactionDetail.sort(function(a: any,b: any){ 
          return new Date(b.createdDate.substring(0,10)).getTime() - new Date(a.createdDate.substring(0,10)).getTime();
        });

        for (let transaction of data.transactionDetail) {
          /*var temp = {
            'sNo': sNo++,
            'uniqueId': tppPayer.uniqueId,
            'firstName': tppPayer.firstName,
            'lastName': tppPayer.lastName,
            'emailId': tppPayer.emailId,
            'phoneNumber': tppPayer.phoneNumber,
            'createdDate': this.datePipe.transform(tppPayer.createdDate.substring(0,10),'MM/dd/yyyy'),
            'relName': tppPayer.relName,
            'relType': this.relTypeMap[tppPayer.relType]
          };
          this.transactionDetails.push(temp);*/
        }
          this.noResults = false;
       }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });

   }

   downloadTransactionDetails(){
    new Angular5Csv(this.transactionDetails, "transactions-list-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.options);
   }

  show(elementId) { 
    document.getElementById("tempTransactionList1").style.display="none";
    document.getElementById("tempTransactionList2").style.display="none";
    document.getElementById("tempTransactionList3").style.display="none";
    document.getElementById(elementId).style.display="block";
}

}
