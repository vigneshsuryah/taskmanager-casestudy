import { Routes } from '@angular/router';

import { ReportsHomeComponent } from './home/reportshome.component';

export const routes: Routes = [
    { path: 'home', component: ReportsHomeComponent }
];