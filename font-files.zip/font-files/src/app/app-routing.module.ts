import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppLoadingComponent } from './apploading/apploading.component';
import { AuthGuard } from './shared/guards/index';

const approutes: Routes = [
  {
    path: '',
    component: AppLoadingComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'ipp',
    loadChildren: 'app/ipp/ipp.module#IPPModule'
  },
  {
    path: 'medicaidpay',
    loadChildren: 'app/medicaidpay/medicaidpay.module#MedicaidPayModule'
  },
  {
    path: 'memberpay',
    loadChildren: 'app/indvmemberpay/indvmemberpay.module#IndvMemberPayModule'
  },
  {
    path: 'gbdpay',
    loadChildren: 'app/gbdpay/gbdpay.module#GbdPayModule'
  },
  {
    path: 'dashboard',
    loadChildren: 'app/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'reports',
    loadChildren: 'app/reports/reports.module#ReportsModule'
  },
   {
    path: 'wgs',
    loadChildren: 'app/wgs/wgs.module#WgsModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(approutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
