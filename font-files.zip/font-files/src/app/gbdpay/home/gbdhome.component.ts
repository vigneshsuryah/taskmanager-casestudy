import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { AuthenticationService } from '../../shared/csr-service/authentication.service';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdhome',
  templateUrl: 'gbdhome.component.html'
})
export class GBDHomeComponent implements OnInit {

  content : any ={};
  hasKYRole: boolean = false;
  hasINRole: boolean = false;

  constructor (public router : Router, private authenticationService: AuthenticationService, private currentUser: User) {  
    //console.log('this.currentUser.userRole: ' + this.currentUser.userRole);  
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit(){
    var userRoles = this.currentUser.userRole;
    
    if(this.includes(userRoles,'KYHPPORTCSR')){
      this.hasKYRole = true;
    }
    if(this.includes(userRoles,'GBDPPORTCSR')){
      this.hasINRole = true;
    }
  }

  redirectToState(state: string){
    if(state === 'KY') {
        this.router.navigate(['/gbdpay/gbdsearch']);
    } else if(state === 'IN'){
        this.router.navigate(['/gbdpay/gbdinsearch']);
    }
    
  }

  includes(container, value) {
    var returnValue = false;
    var pos = container.indexOf(value);
    if (pos >= 0) {
        returnValue = true;
    }
    return returnValue;
  }

}
