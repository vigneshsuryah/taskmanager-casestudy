import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { KyhpportcsrService } from '../../../shared/csr-service/kyhpportcsr-service';
import { PaginationService } from '../../../shared/pagination-service/pagination-service';
import { Kyhpportcsr } from '../../../shared/models/gbdpay/kyhpportcsr';


@Component({
  moduleId: module.id,
  selector: 'csr-gbdpaymenthistory',
  templateUrl: 'gbdpaymenthistory.component.html',
  styleUrls: ['gbdpaymenthistory.component.css']
})
export class GBDPaymentHistoryComponent implements OnInit {

  allItems: any[];
  pager: any = {};
  pagedItems: any[];
  getHistoryResponse : any = null;
  responsePaymentFlag: boolean = false;
  inputParam : any = '';
  loader : boolean = false;
  hcid: string = '';
  screenLoader: boolean = false;
  techerror: boolean = false;

  constructor(public router: Router, private route: ActivatedRoute, private paginationService: PaginationService, public kyhpportcsrService : KyhpportcsrService,
    public kyhpportcsr : Kyhpportcsr, private currentUser: User){
      if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
      }
    }

  ngOnInit() {
    this.hcid = this.kyhpportcsr.healthCardId;
    this.loadPaymentHistory();
  }

   redirectToHome() {
     this.router.navigate(['/gbdpay/gbdsearch']);
   }

   private loadPaymentHistory() {
    this.screenLoader = true;
    this.inputParam = {
      "healthCardId": this.hcid
    }
    this.kyhpportcsrService.getPaymentHistory(this.inputParam).subscribe((data:any) => {
      this.screenLoader = false;
      this.getHistoryResponse = data;
      this.allItems = this.getHistoryResponse.linkedBills[0].memberPayBillHstAccount;
      if(undefined !== this.allItems && this.allItems.length > 0){
        this.allItems.sort(function(a: any,b: any){ 
          return new Date(b.memberPaymentHistory.paymentDate).getTime() - new Date(a.memberPaymentHistory.paymentDate).getTime();
        });
      }
//      console.log("this.getHistoryResponseList:::"+JSON.stringify(this.getHistoryResponseList));
      if(Object.keys(data).length == 0) {
        this.responsePaymentFlag = true;
        this.setPage(0);
      }
      else if(data.linkedBills[0].memberPayBillHstAccount == null
                    || data.linkedBills[0].memberPayBillHstAccount == undefined) {
        this.responsePaymentFlag = true;
        this.setPage(0);
      } else {
        this.setPage(1);
      }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });

   }

   setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
        return;
    }
    // get pager object from service
    this.pager = this.paginationService.getPager(this.allItems.length, page);
    // get current page of items
    this.pagedItems = this.allItems.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
}
 