import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { GbdINPayService } from '../../shared/csr-service/gbdinpay.service';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'csr-gbdinsearch',
  templateUrl: 'gbdinsearch.component.html',
  styleUrls: ['gbdinsearch.component.css']
})
export class GBDINSearchComponent {

  content : any ={};
  hcid: string;
  screenLoader: boolean = false;
  responseCode: string;
  showContent: string;
  isExactLength: boolean = true;
  isValidHcid: boolean = true;
  hasHcid: boolean = true;

  gbdSearchModel = {
    'hcid':'',
  }

  constructor (public router: Router, public gbdINPayService: GbdINPayService, private currentUser: User ) {
      //console.log('this.currentUser.userRole: ' + this.currentUser.userRole);
      if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
      }
  }

  validateHcid(hcid: string, selectedApp: string) {
    if(hcid.length == 0){
      this.hasHcid = false;
      this.isExactLength = true;
      this.isValidHcid = true;
    } else if(hcid.length > 9 || hcid.length < 9){
      this.isExactLength = false;
      this.hasHcid = true;
      this.isValidHcid = true;
    } else {
      this.isValidINMember(hcid, selectedApp);
    }
  }

  isValidINMember(hcid: string, selectedApp: string){
    this.screenLoader = true
    var inputParams = {
      "healthCardId" : hcid
    }
    this.gbdINPayService.getPaymentMethods(inputParams).subscribe((data: any) => {
      this.screenLoader = false;
      if(null !== data && undefined !== data) {
        this.isValidHcid = true;
        this.hasHcid = true;
        this.isExactLength = true;    
        if(selectedApp === 'PD'){
          this.getPaymentMethods(hcid);
        } else if (selectedApp === 'PH'){
          this.getPaymentHistory(hcid);
        }
      }
    },
    (err: any) => {
      this.screenLoader = false;
      this.isValidHcid = false;
      this.hasHcid = true;
      this.isExactLength = true;
      this.showContent = 'techerror';
    });
  }

 /* isValidMember(hcid: string, selectedApp: string){
    this.screenLoader = true
    var inputParams = {
      "healthCardId" : hcid
    }
    this.gbdINPayService.validateMember(inputParams).subscribe((data: any) => {
      this.screenLoader = false;
      this.responseCode = data.messageCode;
      if(this.responseCode === "0"){   
        this.isHOH = true;
        this.isValidHcid = true;
        this.hasHcid = true;
        this.isExactLength = true;    
        if(selectedApp === 'PD'){
          this.getPaymentMethods(hcid);
        } else if (selectedApp === 'PH'){
          this.getPaymentHistory(hcid);
        }
      } else if(this.responseCode === "8"){        
        this.isHOH = false;
        this.isValidHcid = true;
        this.hasHcid = true;
        this.isExactLength = true;
      } else {        
        this.isHOH = false;
        this.isValidHcid = false;
        this.hasHcid = true;
        this.isExactLength = true;
      }
    },
    (err: any) => {
      this.screenLoader = false;
      this.isValidHcid = false;
      this.isHOH = true;
      this.hasHcid = true;
      this.isExactLength = true;
      this.showContent = 'techerror';
    });

} */

  getPaymentMethods(hcid: string){
    this.gbdINPayService.memberPaymentOptions = 'MPM';
    this.gbdINPayService.hcid = hcid;
    //this.kyhpportcsr.healthCardId = hcid;
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  getPaymentHistory(hcid: string) {
    //this.kyhpportcsr.healthCardId = hcid;
    this.gbdINPayService.hcid = hcid;
    this.router.navigate(['/gbdpay/gbdinpaymenthistory']);
  }

}
