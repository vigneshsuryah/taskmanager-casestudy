import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../../shared/models/user';
import { content } from '../../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../../shared/models/paymentmethod.model';
import { GbdINPayService } from '../../../../../shared/csr-service/gbdinpay.service';
import { PaymentMethod } from '../../../../../shared/models/gbdpay/paymentmethod.model';
import { UpdatePayResponse } from '../../../../../shared/models/gbdpay/updatepayresponse.model';
import { NgForm } from '@angular/forms';


@Component({
  moduleId: module.id,
  selector: 'csr-gbdineditpaymentmethod',
  templateUrl: 'gbdineditpaymentmethod.component.html',
  styleUrls: ['gbdineditpaymentmethod.component.css']
})
export class GBDINEditPaymentMethodComponent implements OnInit {
  @ViewChild('editPaymentForm') editForm: NgForm;
  editPay: PaymentMethod;
  screenLoader: boolean = false;
  techerror: boolean = false;
  editError = '';
  paymentMethodModel = {
    'paymentMethod': '',
    'expiryDate': '',
    'nickName': '',
    'accountType': '',
    'bankRoutingNbr': '',
    'bankAccountNbr': '',
    'reEnterbankAccountNbr': '',
    'accountHolderName': '',
    'addressOnAccount': '',
    'address1': '',
    'address2': '',
    'city': '',
    'state': '',
    'zipCode': '',
    'cardNumber':'',
    'cvvCode':'',
    'cardName':''
  }
  content : any ={};
  value : string;
  usedNickNames: string[] = [];
  errorMsg = {
    'invalidNickName': 'Please only use letters when entering a nickname (no numbers or special characters).',
    'invalidExpiry': 'The expiry date for this credit/debit card is invalid. Please verify the expiry date on your card.',
    'invalidCardHolderName': 'Please only use letters when entering a name (no numbers or special characters).',
    'invalidBankAccountHolder': 'Please enter a valid account holder name (no numbers or special characters).',
    'invalidAdd1': 'Please enter the address without any special characters',
    'invalidCity': 'Please enter a valid city name (no numbers or special characters).',
    'invalidState': 'Please enter a valid state name (no numbers or special characters).',
    'duplicateNickName': 'Sorry, you already have a payment method with that nickname in the system.',
    'invalidZip': 'Please enter the correct 5-digit ZIP code',
    'techError': 'Sorry, our system isn\'t working the way it should. Please try again later.'
  };

  constructor(public router: Router, private gbdINPayService: GbdINPayService,private currentUser: User) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    if (this.gbdINPayService.paymentMethodEdit === undefined) {
      this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
    }
    this.editPay = this.gbdINPayService.paymentMethodEdit;
    this.usedNickNames = [];
    const nickNameList = this.gbdINPayService.existingNickNames;
    for (let entryNick of nickNameList) {
      if (this.editPay.accountNickname !== entryNick) {
        this.usedNickNames.push(entryNick);
      }
    }
    this.content = content;
    if (this.editPay.bankAccountNumber === undefined) {
      this.paymentMethodModel.paymentMethod = 'CreditDebit';
      this.paymentMethodModel.expiryDate = this.editPay.expirationMonth + '/' + this.editPay.expirationYear;
    } else {
      this.paymentMethodModel.paymentMethod = 'Banking';
      this.paymentMethodModel.reEnterbankAccountNbr = this.editPay.bankAccountNumber;
    }
    if (this.isSubcriberAddress(this.editPay)) {
      this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        setTimeout(() => {
          this.changeAddressOnAccount('SubscriberAddr');
        }, 100);
    } else {
      this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
    }
  }

   savePaymentMethod (paymentMethodModel: PaymentMethodModel) {
    this.screenLoader = true;
    this.techerror = false;
    this.editError = this.errorMsg.techError;
    if (this.paymentMethodModel.paymentMethod === 'CreditDebit') {
      const datestr = this.paymentMethodModel.expiryDate.split('/');
      this.editPay.expirationMonth = datestr[0];
      this.editPay.expirationYear = datestr[1];
      this.editPay.creditCardType = 'VISA';
    }

    var inputParams = {
        "healthCardId" : this.gbdINPayService.hcid,
        "action" : 'MODIFY',
        "csrUserId" : this.currentUser.username,
        "bankAccountDetails" : this.getBankingReq(),
        "creditCardDetails" : this.getCCReq()
    };
    this.gbdINPayService.updatePaymentMethods(inputParams).subscribe(
       (data: any) => {
        if (data.message !== undefined && data.message.messageCode === '0') {
           document.getElementById('confirmationModalOpener').click();
        } else {
          if (data.message && data.message.messageText && data.message.messageText !== '') {
            this.editError = data.message.messageText;
          }
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
        }
         this.screenLoader = false;
       },
       (error) => {
         jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
         this.screenLoader = false;
         this.techerror = true;
       }
    );
   }

   redirectToHome(selected: string) {
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
   }

   cancel(selected: string) {
     this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
   }

   changeAddressOnAccount(newValue) {
    this.paymentMethodModel.addressOnAccount = newValue;
    if (newValue === 'SubscriberAddr') {
      const memberAdd = this.gbdINPayService.memberPayAddress;
      if (memberAdd !== undefined) {
        this.editPay.accountAddress1 = memberAdd.addressLine1;
        this.editPay.accountAddress2 = '';
        this.editPay.accountCity = memberAdd.city;
        this.editPay.accountState = memberAdd.state;
        if (memberAdd.postalCode && memberAdd.postalCode.length > 5) {
          this.editPay.accountPostalCode = memberAdd.postalCode.substr(0, 5);
        } else {
        this.editPay.accountPostalCode = memberAdd.postalCode;
        }
        this.editForm.controls['address1'].markAsTouched();
        this.editForm.controls['city'].markAsTouched();
        this.editForm.controls['state'].markAsTouched();
        this.editForm.controls['zipCode'].markAsTouched();
      }
    } else {
     this.editPay.accountAddress1 = '';
     this.editPay.accountAddress2 = '';
     this.editPay.accountCity = '';
     this.editPay.accountState = '';
     this.editPay.accountPostalCode = '';
    }
  }

  isSubcriberAddress(inputAdd: PaymentMethod) {
    if (inputAdd !== undefined && this.gbdINPayService.memberPayAddress !== undefined) {
      if (inputAdd.accountAddress1 === this.gbdINPayService.memberPayAddress.addressLine1
        && inputAdd.accountCity === this.gbdINPayService.memberPayAddress.city
        && inputAdd.accountPostalCode === this.gbdINPayService.memberPayAddress.postalCode
        && inputAdd.accountState === this.gbdINPayService.memberPayAddress.state) {
        return true;
      }
    }
    return false;
  }

  getBankingReq() {
      if (this.paymentMethodModel.paymentMethod === 'Banking') {
          return {
              "bankAccountType": this.editPay.bankAccountType,
              "routingNumber": this.editPay.routingNumber,
              "bankAccountNumber": this.editPay.bankAccountNumber,
              "accountHolderName": this.editPay.accountHolderName,
              "accountAddress1": this.editPay.accountAddress1,
              "accountAddress2": this.editPay.accountAddress2 ? this.editPay.accountAddress2 : null,
              "accountCity": this.editPay.accountCity,
              "accountState": this.editPay.accountState,
              "accountPostalCode": this.editPay.accountPostalCode,
              "accountNickname": this.editPay.accountNickname,
              "tokenId": this.editPay.tokenId
          }
      } else {
          return null;
      }
   }

   getCCReq() {
      if (this.paymentMethodModel.paymentMethod === 'CreditDebit') {
          return {
              "accountNickname": this.editPay.accountNickname ?  this.editPay.accountNickname : null,
              "creditCardType": this.editPay.creditCardType,
              "creditCardNumber": this.editPay.creditCardNumber,
              "accountHolderName": this.editPay.accountHolderName,
              "accountAddress1": this.editPay.accountAddress1,
              "accountAddress2": this.editPay.accountAddress2 ? this.editPay.accountAddress2 : null,
              "accountCity": this.editPay.accountCity,
              "accountState": this.editPay.accountState,
              "accountPostalCode": this.editPay.accountPostalCode,
              "expirationMonth": this.editPay.expirationMonth,
              "expirationYear" : this.editPay.expirationYear,
              "tokenId": this.editPay.tokenId
          }
      } else {
          return null;
      }
   }
}
