import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { GbdINPayService } from '../../../../shared/csr-service/gbdinpay.service';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdinautopayment',
  templateUrl: 'gbdinautopayment.component.html',
  styleUrls: ['gbdinautopayment.component.css']
})
export class GBDINAutoPaymentComponent implements OnInit {

  content: any ={};
  selectedMethod: string;
  hcid: string;
  getRecurringResponse: any = {};
  getRecurringPaymentsList: any = [];
  updatedRecurringPaymentsList: any = [];
  screenLoader = false;
  responseCode: string;
  updateRecurringResponse: any = {};
  deleteRecurringPayment: any = {};
  hasRecurring: boolean = true;
  getPaymentMethodResponse: any = {};
  hasPaymentMethods: boolean = true;
  responseLength: any = 0;
  isDeleted: boolean = true;
  techerror: boolean = false;
  hasThirdParty: boolean = false;

  constructor(public router: Router, public gbdINPayService : GbdINPayService, private currentUser: User){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
     this.hcid = this.gbdINPayService.hcid;
     this.getPaymentMethods();
     this.getRecurringDetails();
   }

   redirectToHome() {
     this.router.navigate(['/gbdpay/gbdinsearch']);
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      }
   }

   addAutoPayments(){
     this.router.navigate(['/gbdpay/gbdinaddautopayment']);
   }

   edit(recurringPayments: any){
     this.gbdINPayService.editRecurringPayment = recurringPayments;
     this.router.navigate(['/gbdpay/gbdineditautopayment']);
   }

   delete(recurringPayments: any){
    this.deleteRecurringPayment = recurringPayments;
    jQuery("#confirmationModalOpener").click();
   }

   cancelDelete(selected: string){
      this.gbdINPayService.memberPaymentOptions = selected;
      jQuery("#confirmationModalOpener").click();
      this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
   }

   confirmDelete(){
    this.deleteRecurringDetails();
   }

   success(selected: string){
     jQuery("#deleteConfirmationModalOpener").click();
     this.gbdINPayService.memberPaymentOptions = selected;
     this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
   }

   formatPayDate(payDate: string){
     if (payDate == "01") {
           return payDate = "1st";
        } else if (payDate == "02") {
            return payDate = "2nd";
        } else if (payDate == "03") {
            return payDate = "3rd";
        } else {
            return payDate = payDate.slice(-1) + "th";
        }
   }

    getRecurringDetails(){
      this.getRecurringResponse = {};
      this.getRecurringPaymentsList = [];
      var inputParams = {
        "healthCardId" : this.gbdINPayService.hcid
      }
      this.screenLoader = true;
      this.gbdINPayService.getRecurring(inputParams).subscribe((data: any) => {

        this.getRecurringResponse = data;
        this.getRecurringPaymentsList = this.getRecurringResponse.memberpayRecurringPayments;
        if(null !== this.getRecurringPaymentsList && undefined !== this.getRecurringPaymentsList){
          this.hasRecurring = true;
          for (let recurringPayments of this.getRecurringPaymentsList) {
            if ( recurringPayments && recurringPayments.createdBy && recurringPayments.createdBy !== '') {
              this.hasThirdParty = true;
            }
          }
        } else {
          this.hasRecurring = false;
        }
        this.screenLoader = false;
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      }
    );
    }

    deleteRecurringDetails(){
      this.screenLoader = true;
      var inputParams = {
        "healthCardId": this.gbdINPayService.hcid,
        "recurringPaymentDetails": [{
        "planID": this.deleteRecurringPayment.memberPayBillAcount.planId,
        "productID": this.deleteRecurringPayment.memberPayBillAcount.productId,
        "payDate": this.deleteRecurringPayment.payDate,
        "createdBy": this.deleteRecurringPayment.createdBy,
        "authMode": "PPD",
        "tokenID": this.deleteRecurringPayment.tokenID,
        "paymentType": this.deleteRecurringPayment.paymentType.toUpperCase()
      }],
      "action": "DELETE",
      "csrFlag": true,
      "csrUserId": this.currentUser.username
      }
      this.gbdINPayService.updateRecurring(inputParams).subscribe((data: any) => {
          this.screenLoader = false;
          if(data.message.messageCode === "0"){
            this.isDeleted = true;
            jQuery("#confirmationModalOpener").click();
            jQuery("#deleteConfirmationModalOpener").click();
            this.getRecurringDetails();
          }
      },
      (err: any) => {
          this.screenLoader = false;
          jQuery("#confirmationModalOpener").click();
          this.isDeleted = false;
          jQuery('html,body').animate({ scrollTop: jQuery("#manageAutoPayments").offset().top - jQuery("#manageAutoPayments").height() + 100 }, 'slow');
      }
      );
      this.deleteRecurringPayment = {};
    }

    formatType(paymentType: string){
      if(paymentType === 'BankAccount'){
        return paymentType = 'Bank Account';
      } else if (paymentType === 'CreditCard'){
        return paymentType = 'Credit Card';
      }
    }

    getPaymentMethods(){
      var inputParams = {
        "healthCardId" : this.gbdINPayService.hcid
      }
      this.screenLoader = true;
      this.gbdINPayService.getPaymentMethods(inputParams).subscribe((data: any) => {

      this.getPaymentMethodResponse = data;
      if (!this.getPaymentMethodResponse.creditCardDetails && !this.getPaymentMethodResponse.bankAccountDetails) {
        this.responseLength = 0;
        this.hasPaymentMethods = false;
      } else {
        this.hasPaymentMethods = true;
      }
       this.screenLoader = false;
    },
    (err: any) => {
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
      this.screenLoader = false;
      });
    }
}
