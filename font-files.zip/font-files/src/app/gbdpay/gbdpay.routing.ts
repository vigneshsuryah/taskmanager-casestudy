import { Routes } from '@angular/router';

import { GBDHomeComponent } from './home/gbdhome.component';
import { GBDManagePaymentComponent } from './gbdsearch/gbdmanagepayment/gbdmanagepayment.component';
import { GBDPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdpaymentmethod.component';
import { GBDAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdautopayment.component';
import { GBDAddPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdaddpaymentmethod/gbdaddpaymentmethod.component';
import { GBDEditPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdeditpaymentmethod/gbdeditpaymentmethod.component';
import { GBDAddAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdaddautopayment/gbdaddautopayment.component';
import { GBDEditAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdeditautopayment/gbdeditautopayment.component';
import { GBDSearchComponent } from './gbdsearch/gbdsearch.component';   
import { GBDPaymentHistoryComponent } from './gbdsearch/gbdpaymenthistory/gbdpaymenthistory.component';

import { GBDINManagePaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinmanagepayment.component';
import { GBDINPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdinpaymentmethod.component';
import { GBDINAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdinautopayment.component';
import { GBDINAddPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdinaddpaymentmethod/gbdinaddpaymentmethod.component';
import { GBDINEditPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdineditpaymentmethod/gbdineditpaymentmethod.component';
import { GBDINAddAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdinaddautopayment/gbdinaddautopayment.component';
import { GBDINEditAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdineditautopayment/gbdineditautopayment.component';
import { GBDINSearchComponent } from './gbdinsearch/gbdinsearch.component';   
import { GBDINPaymentHistoryComponent } from './gbdinsearch/gbdinpaymenthistory/gbdinpaymenthistory.component';

export const routes: Routes = [
    { path: '', component: GBDHomeComponent },
    { path: 'gbdpaymentmethod', component: GBDPaymentMethodComponent },
    { path: 'gbdmanagepaymentmethod', component: GBDManagePaymentComponent },
    { path: 'gbdaddpaymentmethod', component: GBDAddPaymentMethodComponent },
    { path: 'gbdeditpaymentmethod', component: GBDEditPaymentMethodComponent },
    { path: 'gbdaddautopayment', component: GBDAddAutoPaymentComponent },
    { path: 'gbdmanageautopayment', component: GBDAutoPaymentComponent },
    { path: 'gbdeditautopayment', component: GBDEditAutoPaymentComponent },
    { path: 'gbdsearch', component: GBDSearchComponent },
    { path: 'gbdpaymenthistory', component: GBDPaymentHistoryComponent },
    
    { path: 'gbdinpaymentmethod', component: GBDINPaymentMethodComponent },
    { path: 'gbdinmanagepaymentmethod', component: GBDINManagePaymentComponent },
    { path: 'gbdinaddpaymentmethod', component: GBDINAddPaymentMethodComponent },
    { path: 'gbdineditpaymentmethod', component: GBDINEditPaymentMethodComponent },
    { path: 'gbdinaddautopayment', component: GBDINAddAutoPaymentComponent },
    { path: 'gbdinmanageautopayment', component: GBDINAutoPaymentComponent },
    { path: 'gbdineditautopayment', component: GBDINEditAutoPaymentComponent },
    { path: 'gbdinsearch', component: GBDINSearchComponent },
    { path: 'gbdinpaymenthistory', component: GBDINPaymentHistoryComponent }
];