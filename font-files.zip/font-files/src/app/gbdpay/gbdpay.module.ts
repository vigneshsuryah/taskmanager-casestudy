import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { GBDHomeComponent } from './home/gbdhome.component';
import { GBDManagePaymentComponent } from './gbdsearch/gbdmanagepayment/gbdmanagepayment.component';
import { GBDPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdpaymentmethod.component';
import { GBDAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdautopayment.component';
import { GBDAddPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdaddpaymentmethod/gbdaddpaymentmethod.component';
import { GBDEditPaymentMethodComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdeditpaymentmethod/gbdeditpaymentmethod.component';
import { GBDAddAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdaddautopayment/gbdaddautopayment.component';
import { GBDEditAutoPaymentComponent } from './gbdsearch/gbdmanagepayment/gbdautopayment/gbdeditautopayment/gbdeditautopayment.component';
import { GBDSearchComponent } from './gbdsearch/gbdsearch.component';
import { GBDPaymentHistoryComponent } from './gbdsearch/gbdpaymenthistory/gbdpaymenthistory.component';
import { routes } from './gbdpay.routing';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { GbdPayMethodService } from './gbdsearch/gbdmanagepayment/gbdpaymethod.service';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { Kyhpportcsr } from '../shared/models/gbdpay/kyhpportcsr';
import { KyhpportcsrService } from '../shared/csr-service/kyhpportcsr-service';
import { GbdFieldValidationComponent } from './gbdsearch/gbdmanagepayment/gbdpaymentmethod/gbdfieldvalidation/gbdfieldvalidation.component';
import { GbdINFieldValidationComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdinfieldvalidation/gbdinfieldvalidation.component';
import { GbdPayService } from '../shared/csr-service/gbdpay.service';

import { GBDINManagePaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinmanagepayment.component';
import { GBDINPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdinpaymentmethod.component';
import { GBDINAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdinautopayment.component';
import { GBDINAddPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdinaddpaymentmethod/gbdinaddpaymentmethod.component';
import { GBDINEditPaymentMethodComponent } from './gbdinsearch/gbdinmanagepayment/gbdinpaymentmethod/gbdineditpaymentmethod/gbdineditpaymentmethod.component';
import { GBDINAddAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdinaddautopayment/gbdinaddautopayment.component';
import { GBDINEditAutoPaymentComponent } from './gbdinsearch/gbdinmanagepayment/gbdinautopayment/gbdineditautopayment/gbdineditautopayment.component';
import { GBDINSearchComponent } from './gbdinsearch/gbdinsearch.component';   
import { GBDINPaymentHistoryComponent } from './gbdinsearch/gbdinpaymenthistory/gbdinpaymenthistory.component';
import { GbdINPayService } from '../shared/csr-service/gbdinpay.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    HttpClientModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [GbdPayService,
    GbdPayMethodService,
    Kyhpportcsr,
    KyhpportcsrService,
    GbdINPayService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [GBDHomeComponent,
    GBDManagePaymentComponent,
    GBDPaymentMethodComponent,
    GBDAutoPaymentComponent,
    GBDAddPaymentMethodComponent,
    GBDEditPaymentMethodComponent,
    GBDAddAutoPaymentComponent,
    GBDEditAutoPaymentComponent,
    GBDSearchComponent,
    GbdFieldValidationComponent,
    GbdINFieldValidationComponent,
    GBDPaymentHistoryComponent,
    
    GBDINManagePaymentComponent,
    GBDINPaymentMethodComponent,
    GBDINAutoPaymentComponent,
    GBDINAddPaymentMethodComponent,
    GBDINEditPaymentMethodComponent,
    GBDINAddAutoPaymentComponent,
    GBDINEditAutoPaymentComponent,
    GBDINSearchComponent,
    GBDINPaymentHistoryComponent]
})
export class GbdPayModule {

}
