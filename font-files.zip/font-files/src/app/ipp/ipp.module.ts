import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';

import { IPPHomeComponent } from './home/ipphome.component';
import { PaymentOptionsComponent } from './paymentoptions/paymentoptions.component';
import { ApplicationPdfComponent } from './applicationpdf/applicationpdf.component';
import { routes } from './ipp.routing';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { IppHttpService } from '../shared/csr-service/ipphttp.service';
import { Ippcsr } from '../shared/models/ipp/ippcsr';
import { CsrPaymentService } from '../shared/csr-service/csrpayment.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),    
    RouterModule.forChild(routes)
  ],
  providers: [
    CsrPaymentService,
    IppHttpService, 
    Ippcsr,
    DatePipe
  ],
  declarations: [IPPHomeComponent, PaymentOptionsComponent, ApplicationPdfComponent]
})
export class IPPModule { 

}
