import { Component, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
declare var jQuery:any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-applicationpdf',
  templateUrl: 'applicationpdf.component.html',
  styleUrls: ['applicationpdf.component.css']
})
export class ApplicationPdfComponent {

   constructor(public router: Router){}

   redirectToHome() {
     this.router.navigate(['/ipp/home']);
   }
 
}
