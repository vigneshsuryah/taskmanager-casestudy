package com.anthem.ols.middletier.paymentservice.aspect;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;

import com.anthem.ols.middletier.paymentservice.rest.bo.BusinessError;
import com.anthem.ols.middletier.paymentservice.rest.bo.BusinessErrorLine;
import com.anthem.ols.middletier.paymentservice.rest.request.CancelPaymentsRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GeneratePDFRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SearchPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SubmitApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.ValidateZipCodeRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.BaseResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.CancelPaymentsResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GeneratePDFResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SearchPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SubmitApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.ValidateZipCodeResponseRS;
import com.anthem.ols.middletier.paymentservice.utils.ServiceUtils;
import com.thoughtworks.xstream.XStream;

@Aspect
public class PaymentAspect {

	XStream xstream = new XStream();
	
	@Autowired
	private ServiceUtils serviceUtils;
	
	@Around("allMethodsPointcut()")
	public Object trackReqRes(ProceedingJoinPoint joinPoint) throws Throwable {
		Object response = null;
		String acn = "";
		String partnerId = "";
		boolean isValid = false;
		Object requestObjType = null;
		String operationName = joinPoint.getSignature().getName() == null ? " " : joinPoint.getSignature().getName();
		Object request = null;
		Timestamp requestTS = new Timestamp(System.currentTimeMillis());
		Timestamp responseTS = null;
		try {
			Object[] objs = joinPoint.getArgs();

			for (Object obj : objs) {
				if (obj instanceof GetPaymentRequestRS) {
					GetPaymentRequestRS getPayReq = (GetPaymentRequestRS) obj;
					acn = getPayReq.getAcn();
					partnerId = getPayReq.getPartnerId();
					request = getPayReq;
					requestObjType = obj;
				} else if (obj instanceof SetPaymentRequestRS) {
					SetPaymentRequestRS setPayReq = (SetPaymentRequestRS) obj;
					acn = setPayReq.getAcn();
					partnerId = setPayReq.getPartnerId();
					request = setPayReq;
					requestObjType = obj;
				} else if (obj instanceof SearchPaymentRequestRS) {
					SearchPaymentRequestRS searchPayReq = (SearchPaymentRequestRS) obj;
					acn = searchPayReq.getAcn();
					partnerId = searchPayReq.getPartnerId();
					request = searchPayReq;
					requestObjType = obj;
				} else if (obj instanceof CancelPaymentsRequestRS) {
					CancelPaymentsRequestRS cancelPayReq = (CancelPaymentsRequestRS) obj;
					acn = cancelPayReq.getAcn();
					partnerId = cancelPayReq.getPartnerId();
					request = cancelPayReq;
					requestObjType = obj;
				} else if (obj instanceof GeneratePDFRequestRS) {
					GeneratePDFRequestRS generatePdfReq = (GeneratePDFRequestRS) obj;
					acn = generatePdfReq.getAcn();
					partnerId = generatePdfReq.getPartnerId();
					request = generatePdfReq;
					requestObjType = obj;
				} else if (obj instanceof SetApplicationRequestRS) {
					SetApplicationRequestRS setAppReq = (SetApplicationRequestRS) obj;
					if (null != setAppReq.getApplication()) {
						acn = setAppReq.getApplication().getAcn();
					}
					partnerId = setAppReq.getPartnerId();
					request = setAppReq;
					requestObjType = obj;
				} else if (obj instanceof GetApplicationRequestRS) {
					GetApplicationRequestRS getAppReq = (GetApplicationRequestRS) obj;
					if (null != getAppReq.getAcn()) {
						acn = getAppReq.getAcn();
					}
					partnerId = getAppReq.getPartnerId();
					request = getAppReq;
					requestObjType = obj;
				} else if (obj instanceof SubmitApplicationRequestRS) {
					SubmitApplicationRequestRS submitAppReq = (SubmitApplicationRequestRS) obj;
					acn = submitAppReq.getAcn();
					partnerId = submitAppReq.getPartnerId();
					request = submitAppReq;
					requestObjType = obj;
				} else if (obj instanceof ValidateZipCodeRequestRS) {
					ValidateZipCodeRequestRS validateZipRequestRS = (ValidateZipCodeRequestRS) obj;
					acn = "NO_ACN";
					partnerId = "FFM";
					request = validateZipRequestRS;
					requestObjType = obj;
					isValid = true;
				}
			}

			/*
			 * if(null != partnerId && !partnerId.isEmpty()){ RequestingSystemDataBean
			 * requestingSystemDataBean = new RequestingSystemDataBean();
			 * requestingSystemDataBean.setRequestingSystem(partnerId); RequestingSystemDAO
			 * requestingSystemDAO = (RequestingSystemDAO)
			 * ApplicationContextProvider.getApplicationContext().getBean(
			 * "requestingSystemDAO"); isValid =
			 * requestingSystemDAO.checkRequestingSystem(requestingSystemDataBean); }
			 */

			if (isValid) {
				response = joinPoint.proceed();
			} else {
				response = returnBaseResponseRSObj("Invalid Requesting System", "IPP001", requestObjType);
			}

			responseTS = new Timestamp(System.currentTimeMillis());

			persistRestLogging(response, acn, partnerId, operationName, request, requestTS, responseTS);

		} catch (Exception e) {
			response = returnBaseResponseRSObj(e.getMessage(), "IPP002", requestObjType);
			responseTS = new Timestamp(System.currentTimeMillis());
			persistRestLogging(response, acn, partnerId, operationName, request, requestTS, responseTS);
		}
		return response;

	}

	public void persistRestLogging(Object response, String acn, String partnerId, String operationName, Object request,
			Timestamp requestTS, Timestamp responseTS) throws InterruptedException {

		serviceUtils.persistRestLogging(response, acn, partnerId, operationName, request, requestTS, responseTS);
		
	}

	/*
	 * public static String getEncodedText(String value) { String encoded = ""; try
	 * { byte[] message = value.getBytes("UTF-8"); encoded =
	 * DatatypeConverter.printBase64Binary(message); } catch (Exception e) {
	 * //LOGGER.debug("ServiceUtil getEncryptedText error"); } return encoded; }
	 */

	public Object returnBaseResponseRSObj(String errorMessage, String errorCode, Object requestObjType) {
		BaseResponseRS baseResponseRS = new BaseResponseRS();
		BusinessError businessError = new BusinessError();
		List<BusinessErrorLine> error = new ArrayList<BusinessErrorLine>();
		BusinessErrorLine businessErrorLine = new BusinessErrorLine();

		businessErrorLine.setCode(errorCode);
		businessErrorLine.setDescription(errorMessage);
		error.add(businessErrorLine);
		businessError.setError(error);

		if (requestObjType instanceof GetPaymentRequestRS) {
			GetPaymentResponseRS getPaymentResponseRS = new GetPaymentResponseRS();
			getPaymentResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("getPaymentResponseRS end :" +
			 * xstream.toXML(getPaymentResponseRS));
			 */
			return getPaymentResponseRS;
		} else if (requestObjType instanceof SetPaymentRequestRS) {
			SetPaymentResponseRS setPaymentResponseRS = new SetPaymentResponseRS();
			setPaymentResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("setPaymentResponseRS end :" +
			 * xstream.toXML(setPaymentResponseRS));
			 */
			return setPaymentResponseRS;
		} else if (requestObjType instanceof SearchPaymentRequestRS) {
			SearchPaymentResponseRS searchPaymentResponseRS = new SearchPaymentResponseRS();
			searchPaymentResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("searchPaymentResponseRS end :" +
			 * xstream.toXML(searchPaymentResponseRS));
			 */
			return searchPaymentResponseRS;
		} else if (requestObjType instanceof CancelPaymentsRequestRS) {
			CancelPaymentsResponseRS cancelPaymentsResponseRS = new CancelPaymentsResponseRS();
			cancelPaymentsResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("cancelPaymentsResponseRS end :" +
			 * xstream.toXML(cancelPaymentsResponseRS));
			 */
			return cancelPaymentsResponseRS;
		} else if (requestObjType instanceof GeneratePDFRequestRS) {
			GeneratePDFResponseRS generatePDFResponseRS = new GeneratePDFResponseRS();
			generatePDFResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("generatePDFResponseRS end :" +
			 * xstream.toXML(generatePDFResponseRS));
			 */
			return generatePDFResponseRS;
		} else if (requestObjType instanceof SetApplicationRequestRS) {
			SetApplicationResponseRS setApplicationResponseRS = new SetApplicationResponseRS();
			setApplicationResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("setApplicationResponseRS end :" +
			 * xstream.toXML(setApplicationResponseRS));
			 */
			return setApplicationResponseRS;
		} else if (requestObjType instanceof GetApplicationRequestRS) {
			GetApplicationResponseRS getApplicationResponseRS = new GetApplicationResponseRS();
			getApplicationResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("getApplicationResponseRS end :" +
			 * xstream.toXML(getApplicationResponseRS));
			 */
			return getApplicationResponseRS;
		} else if (requestObjType instanceof SubmitApplicationRequestRS) {
			SubmitApplicationResponseRS submitApplicationResponseRS = new SubmitApplicationResponseRS();
			submitApplicationResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("submitApplicationResponseRS end :" +
			 * xstream.toXML(submitApplicationResponseRS));
			 */
			return submitApplicationResponseRS;
		} else if (requestObjType instanceof ValidateZipCodeRequestRS) {
			ValidateZipCodeResponseRS validateZipCodeResponseRS = new ValidateZipCodeResponseRS();
			validateZipCodeResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("submitApplicationResponseRS end :" +
			 * xstream.toXML(submitApplicationResponseRS));
			 */
			return validateZipCodeResponseRS;
		} else {
			baseResponseRS.setBusinessError(businessError);
			/*
			 * System.out.println("baseResponseRS end :" + xstream.toXML(baseResponseRS));
			 */
			return baseResponseRS;
		}

	}
	
	@Pointcut("execution(* ccom.anthem.ols.middletier.paymentservice.controller.PaymentRestController.*(..))")
	public void allMethodsPointcut()
	{
		//do nothing
	}

}
