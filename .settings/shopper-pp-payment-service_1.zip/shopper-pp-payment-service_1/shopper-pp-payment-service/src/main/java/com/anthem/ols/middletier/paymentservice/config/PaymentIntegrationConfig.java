package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.MessageChannel;

import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRARequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRAResponse;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsRequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsResponse;
import com.anthem.ols.middletier.paymentservice.utils.HcentiveWebServiceClient;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableIntegration
@Slf4j
public class PaymentIntegrationConfig {
	
	@Autowired
	private HcentiveWebServiceClient hcentiveWebServiceClient;

	@Bean
	public MessageChannel getComputedMRARequestChannel() {
		return new DirectChannel();
	}

	@Bean
	public MessageChannel getComputedMRAResponseChannel() {
		return new DirectChannel();
	}
	
	@Bean
	public MessageChannel getEnrollmentDetailsRequestChannel() {
		return new DirectChannel();
	}

	@Bean
	public MessageChannel getEnrollmentDetailsResponseChannel() {
		return new DirectChannel();
	}

	@ServiceActivator(inputChannel = "getComputedMRARequestChannel",outputChannel="getComputedMRAResponseChannel")
    public GetComputedMRAResponse getComputedMRA(GetComputedMRARequest request) {
		GetComputedMRAResponse response = new GetComputedMRAResponse();
		try {
			response = hcentiveWebServiceClient.getComputedMRA(request);
		} catch (Exception e) {
			log.error("Exception in calling getComputedMRA Service : "+e);
		}
        return response;
    }
	
	@ServiceActivator(inputChannel = "getEnrollmentDetailsRequestChannel",outputChannel="getEnrollmentDetailsResponseChannel")
    public GetEnrollmentDetailsResponse getEnrollmentDetails(GetEnrollmentDetailsRequest request) {
		GetEnrollmentDetailsResponse response = new GetEnrollmentDetailsResponse();
		try {
			response = hcentiveWebServiceClient.getEnrollmentDetails(request);
		} catch (Exception e) {
			log.error("Exception in calling getEnrollmentDetails Service : "+e);
		}
        return response;
    }
	
}
