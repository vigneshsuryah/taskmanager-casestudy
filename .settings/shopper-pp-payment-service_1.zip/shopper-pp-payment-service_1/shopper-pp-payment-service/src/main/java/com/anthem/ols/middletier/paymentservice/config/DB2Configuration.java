/**
 * DB2Configuration.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 01/08/2020  1.0       Cognizant      Initial Version
 */
package com.anthem.ols.middletier.paymentservice.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


@Configuration
public class DB2Configuration {

	@Bean(name = "dataSourceHixius")
	public DataSource walletDb(@Value("${db.driverClassName}") String walletDbDriver,
			@Value("${db.hixius.url}") String walletDbUrl,
			@Value("${db.hixius.username}") String walletDbUsername,
			@Value("${db.hixius.password}") String walletDbPassword)
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(walletDbDriver);
		dataSource.setUrl(walletDbUrl);
		dataSource.setUsername(walletDbUsername);
		dataSource.setPassword(walletDbPassword);
		return dataSource;
	}
	
	@Bean(name = "dataSourceOlsProduct")
	public DataSource olsProductDb(@Value("${db.driverClassName}") String olsProductDbDriver,
			@Value("${db.olsproduct.url}") String olsProductDbUrl,
			@Value("${db.olsproduct.username}") String olsProductDbUsername,
			@Value("${db.olsproduct.password}") String olsProductDbPassword)
	{
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(olsProductDbDriver);
		dataSource.setUrl(olsProductDbUrl);
		dataSource.setUsername(olsProductDbUsername);
		dataSource.setPassword(olsProductDbPassword);
		return dataSource;
	}
	
}
