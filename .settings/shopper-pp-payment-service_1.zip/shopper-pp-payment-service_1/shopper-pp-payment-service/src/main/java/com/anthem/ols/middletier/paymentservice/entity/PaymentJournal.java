package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentJournal {

	@Field("journal_id")
	private String journal_id;
	@Field("journal_date")
	private Date journalDate;

}
