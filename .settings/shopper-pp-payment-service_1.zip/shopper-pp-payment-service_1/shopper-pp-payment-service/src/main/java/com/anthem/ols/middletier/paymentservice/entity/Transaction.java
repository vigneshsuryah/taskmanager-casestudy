package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Transaction {

	@Field("anthem_orderid")
	private String anthemOrderId;
	@Field("payment_identifier")
	private String paymentIdentifier;
	@Field("planId")
	private String planId;
	@Field("planType")
	private String planType;
	@Field("productType")
	private String productType;
	@Field("contractCode")
	private String contractCode;
	@Field("planName")
	private String planName;
	@Field("qhpid")
	private String qhpid;
	@Field("qhpvariation")
	private String qhpvariation;
	@Field("ebhflag")
	private String ebhflag;
	@Field("ratingServiceArea")
	private String ratingServiceArea;
	@Field("companyDescr")
	private String companyDescr;
	@Field("ereAppliedAPTC")
	private double ereAppliedAPTC;
	@Field("created_dt")
	private Date createdDt;
	@Field("created_id")
	private String createdId;
	@Field("updated_dt")
	private Date updatedDt;
	@Field("updated_id")
	private String updatedId;
	@Field("iscsr")
	private boolean isCsr;
	@Field("payment_channel")
	private String paymentChannel;
	@Field("premium_amount")
	private double premiumAmount;
	@Field("computedMRAAmount")
	private String computedMRAAmount;
	@Field("paid_date")
	private Date paidDate;
	@Field("transaction_status")
	private String transactionStatus;
	@Field("with_draw_day")
	private String withDrawDay;
	@Field("billing_frequency")
	private String billingFrequency;
	@Field("recv_paperless_billing_flag")
	private String recvPaperlessBillingFlag;
	@Field("recv_electronic_coc_flag")
	private String recvElectronicCocFlag;
	@Field("recv_payment_conf_flag")
	private String recvPaymentConfFlag;
	@Field("recurring_flag")
	private String recurringFlag;
	@Field("retro_indc")
	private String retroIndc;
	@Field("retro_pay_to_date")
	private Date retroPayToDate;
	@Field("payment_confirmation_email_address")
	private String paymentConfirmationEmailAddress;
	@Field("notification_indicator")
	private String notificationIndicator;
	@Field("notes")
	private List<Note> notes;
	@Field("transaction_type")
	private String transactionType;
	@Field("anthem_bank_details")
	private AnthemBankDetails anthemBankDetails;
	@Field("status")
	private PaymentTransactionStatus status;
	@Field("journal")
	private PaymentJournal journal;
	@Field("submission_date")
	private Date submissionDt;
	@Field("bkndst_ts")
	private Date prfDt;
	@Field("cancel_details")
	private CancelDetails cancelDetails;
	
	@Field("credit_card_number")
	private String creditCardNumber;
	@Field("response_reason_code")
	private String responseReasonCode;
	@Field("action_code")
	private String actionCode;
	@Field("is_level3")
	private String isLevelThree;
	@Field("cc_authorization_number")
	private String ccAuthorizationNumber;
	@Field("token_response_date")
	private String tokenDate;
	@Field("AVSAAV")
	private String aVSAAV;
	@Field("messageType")
	private String messageType;
	@Field("submittedTransactionID")
	private String submittedTransactionID;
	@Field("responseTransactionID")
	private String responseTransactionID;
	@Field("storedCredentialFlag")
	private String storedCredentialFlag;
}
