/**
* PaymentRestController.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 01/10/2020   1.0       Cognizant      Initial
*/
package com.anthem.ols.middletier.paymentservice.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.ols.middletier.paymentservice.config.PaymentIntegrationGateway;
import com.anthem.ols.middletier.paymentservice.exception.BusinessException;
import com.anthem.ols.middletier.paymentservice.hcentive.Code;
import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRARequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRAResponse;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsRequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsResponse;
import com.anthem.ols.middletier.paymentservice.hcentive.StateCode;
import com.anthem.ols.middletier.paymentservice.rest.request.CancelPaymentsRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogRequest;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogResponse;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.ValidateZipCodeRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.CancelPaymentsResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.ValidateZipCodeResponseRS;
import com.anthem.ols.middletier.paymentservice.service.ApplicationPaymentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PaymentRestController {

	@Autowired
	private PaymentIntegrationGateway paymentIntegrationGateway;

	@Autowired
	private ApplicationPaymentService paymentServiceImpl;

	@PostMapping(value = "getApplication", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetApplicationResponseRS getApplication(@RequestBody GetApplicationRequestRS request,
			HttpServletRequest httpRequest) {
		GetApplicationResponseRS response = new GetApplicationResponseRS();
		try {
			response = paymentServiceImpl.getApplication(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "setApplication", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetApplicationResponseRS setApplication(@RequestBody SetApplicationRequestRS request,
			HttpServletRequest httpRequest) {
		SetApplicationResponseRS response = new SetApplicationResponseRS();
		try {
			response = paymentServiceImpl.setApplication(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "getPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetPaymentResponseRS getPayment(@RequestBody GetPaymentRequestRS request,
			HttpServletRequest httpRequest) {
		GetPaymentResponseRS response = new GetPaymentResponseRS();
		try {
			response = paymentServiceImpl.getPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "setPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetPaymentResponseRS setPayment(@RequestBody SetPaymentRequestRS request,
			HttpServletRequest httpRequest) {
		SetPaymentResponseRS response = new SetPaymentResponseRS();
		try {
			response = paymentServiceImpl.setPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "cancelPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody CancelPaymentsResponseRS cancelPayment(@RequestBody CancelPaymentsRequestRS request,
			HttpServletRequest httpRequest) {
		CancelPaymentsResponseRS response = new CancelPaymentsResponseRS();
		try {
			response = paymentServiceImpl.cancelPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "validateZipCode", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateZipCodeResponseRS validateZipCode(@RequestBody ValidateZipCodeRequestRS request,
			HttpServletRequest httpRequest) {
		ValidateZipCodeResponseRS response = new ValidateZipCodeResponseRS();
		try {
			response = paymentServiceImpl.validateZipCode(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "setExchangeTransLog", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetExchangeTransLogResponse setExchangeTransLog(
			@RequestBody SetExchangeTransLogRequest request, HttpServletRequest httpRequest) throws BusinessException {
		SetExchangeTransLogResponse response = null;
		try {
			response = paymentServiceImpl.setExchangeTransLog(request);
		} catch (Exception e) {
			BusinessException bex = new BusinessException("Invalid Input");
			throw bex;
		}
		return response;
	}

	@GetMapping(value = "getComputedMRA", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetComputedMRAResponse getComputedMRA() {
		GetComputedMRARequest request = new GetComputedMRARequest();
		request.setExchangeSubId("001171036");
		request.setAptcAmount(BigDecimal.valueOf(0.00));
		request.setOtherSubsidyAmount(BigDecimal.valueOf(0.00));
		request.setPartnerID("Shopperportal");
		request.setPaymentTransactionId("OH89689995222F92");
		request.setQhpPlanId("49046GA041001501");
		request.setTotalPremiumAmount(BigDecimal.valueOf(225.00));
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = df.parse("2018-10-01");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		XMLGregorianCalendar xmlDate;
		try {
			xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
					cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
			request.setProposedCoverageEffectiveDate(xmlDate);
		} catch (DatatypeConfigurationException e) {
			log.error("Exception in getComputedMRA" + e.getMessage());
		}

		StateCode stateCode = new StateCode();
		Code code = new Code();
		code.setRDI("");
		code.setValue("OH");
		stateCode.setCode(code);
		request.setStateCode(stateCode);

		GetComputedMRAResponse response = paymentIntegrationGateway.getComputedMRADetails(request);

		return response;
	}

	@GetMapping(value = "getEnrollmentDetails", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetEnrollmentDetailsResponse getEnrollmentDetails() {

		GetEnrollmentDetailsRequest request = new GetEnrollmentDetailsRequest();
		request.setApplicationControlNumber("92823401");
		request.setPartnerID("shopperportal");
		GetEnrollmentDetailsResponse response = paymentIntegrationGateway.getEnrollmentDetails(request);

		return response;
	}

}
