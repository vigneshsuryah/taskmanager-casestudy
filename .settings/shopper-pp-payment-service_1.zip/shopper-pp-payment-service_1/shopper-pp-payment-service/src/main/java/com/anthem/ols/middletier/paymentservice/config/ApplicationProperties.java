/**
 * ApplicationProperties.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 01/08/2020  1.0       Cognizant      Initial Version
 */
package com.anthem.ols.middletier.paymentservice.config;

import java.util.Properties;

import org.apache.commons.configuration.AbstractConfiguration;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.netflix.config.ConcurrentCompositeConfiguration;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicPropertyUpdater;
import com.netflix.config.DynamicStringProperty;
import com.netflix.config.FixedDelayPollingScheduler;
import com.netflix.config.PollResult;
import com.netflix.config.sources.URLConfigurationSource;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ApplicationProperties {

	public static final String DEFAULT_RESOURCE_LOCATION = "classpath:application.properties";
	private ConcurrentCompositeConfiguration finalConfig = new ConcurrentCompositeConfiguration();
	private DynamicPropertyUpdater dynamicPropertyUpdater = new DynamicPropertyUpdater();

	/*
	 * @Autowired private ResourceLoader resourceLoader;
	 */
	
	private void initializeProperties() {
		try {
			ResourceLoader resourceLoader = new DefaultResourceLoader();
			Resource resource = resourceLoader.getResource(DEFAULT_RESOURCE_LOCATION);
			URLConfigurationSource src = new URLConfigurationSource(resource.getURL());
			DynamicConfiguration configuration = new DynamicConfiguration(src,
					new FixedDelayPollingScheduler(0, 5000, true));
			configuration.stopLoading();
			finalConfig.addConfiguration(configuration);
			ConfigurationManager.install(finalConfig);
		} catch (Exception e) {
			log.error("Exception in initializeProperties() of IPP ApplicationProperties: " + e);
		}
	}

	public ApplicationProperties() {
		initializeProperties();
	}

	public String getStringProperty(String key, String defaultValue) {
		final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key,
				defaultValue);
		return property.get();
	}

	public void updateProperty(String key, String value) {
		finalConfig.setOverrideProperty(key, value);
	}

	public Properties listAll() {
		return finalConfig.getProperties();
	}

	public void updatePropertiesFile() {
		try {
			for (AbstractConfiguration config : finalConfig.getConfigurations()) {
				if (config instanceof DynamicConfiguration) {
					PollResult result = ((DynamicConfiguration) config).getSource().poll(false, null);
					dynamicPropertyUpdater.updateProperties(result, config, false);
				}
			}
		} catch (Exception e) {
			log.error("Exception in updatePropertiesFile() of IPP ApplicationProperties: " + e);
		}
	}
	
	@Bean(name = "org.dozer.Mapper")
	public DozerBeanMapper dozerBean()
	{
		DozerBeanMapper dozerBean = new DozerBeanMapper();
		return dozerBean;
	}
}
