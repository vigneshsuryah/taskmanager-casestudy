
package com.anthem.ols.middletier.paymentservice.exception;

import com.anthem.ols.middletier.paymentservice.rest.bo.BusinessError;

public class BusinessException extends Exception {

	private static final long serialVersionUID = 1L;
	private BusinessError businessError;

	public BusinessError getBusinessError() {
		return businessError;
	}

	public void setBusinessError(BusinessError businessError) {
		this.businessError = businessError;
	}

	public BusinessException(String message) {
		super(message);
	}
}