package com.anthem.ols.middletier.paymentservice.db2.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.anthem.ols.middletier.paymentservice.db2.dao.OlsProductDAO;
import com.anthem.ols.middletier.paymentservice.rest.bo.ProductDataBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OlsProductDAOImpl implements OlsProductDAO {

	static final String SELECT_PRODUCT_BY_CONTRACT_CODE = "IPRODUCT.Select_Product_By_ContractCode";

	@Autowired
	private DataSource dataSourceOlsProduct;

	protected abstract class OlsProductStoredProcedure extends StoredProcedure {

		protected OlsProductStoredProcedure(DataSource ds, String sp) {
			setDataSource(ds);
			setFunction(false);
			setSql(sp);
		}
	}
	
	@Override
	public ProductDataBean getProductByContractCode(String contractCode, String planYear)
			throws DataAccessException {
		log.info("Inside ProductDAOImpl.getProductByContractCode() --- Start");
		ProductByProductContractCodeQuery query = new ProductByProductContractCodeQuery(dataSourceOlsProduct);
		List<ProductDataBean> productList = query
		.executeProductByProductContractCodeSp(contractCode, planYear);
		ProductDataBean productDataBean = null;
		if (null != productList && productList.size() > 0) {

			productDataBean = (ProductDataBean) productList.get(0);
		}
		log.info("Inside ProductDAOImpl.getProductByContractCode() --- End");
		return productDataBean;
	}

	public class ProductByProductContractCodeQuery extends OlsProductStoredProcedure{

		protected ProductByProductContractCodeQuery(DataSource ds) {

			super(ds, SELECT_PRODUCT_BY_CONTRACT_CODE);
			// Input
			declareParameter(new SqlParameter("@ContractCode", Types.VARCHAR));
			declareParameter(new SqlParameter("@PlanYear", Types.VARCHAR));
			// Output
			declareParameter(new SqlReturnResultSet("rs",
					new OLSProductRowMapper()));

			compile();
		}

		@SuppressWarnings("unchecked")
		public List<ProductDataBean> executeProductByProductContractCodeSp(
				String productRateKey, String planYear) {

			// Set inParams
			Map inParams = new HashMap();
			inParams.put("@ContractCode", productRateKey);
			inParams.put("@PlanYear", planYear);
			// Get outParams

			Map<String, Object> outParams = execute(inParams);

			return (List<ProductDataBean>) outParams.get("rs");
		}
	}
	
	private class OLSProductRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

			ProductDataBean product = new ProductDataBean();

			product.setAction("NONE");
			product.setBusinessEntity(rs.getString("BusinessEntity"));
			product.setContractCode(rs.getString("ContractCode"));

			product.setProductId(rs.getString("PlanId"));
			product.setProductType(rs.getString("PlanType"));
			product.setMarketSegment(rs.getString("MarketSegment"));
			product.setProductEffectiveDate(rs.getDate("PlanEffectiveDate"));
			product.setProductEndDate(rs.getDate("PlanEndDate"));
			product.setProductDisplayName(rs.getString("PlanDisplayName"));
			product.setProductFamily(rs.getString("ProductFamilyType"));
			product.setCreateDate(rs.getDate("CreateDt"));
			product.setUpdateDate(rs.getDate("UpdateDt"));
			 
			return product;
		}
	}

}
