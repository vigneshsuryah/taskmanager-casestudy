const wgsPaymentMethodsSchema = {
    "hcid": String,
    "lob": String,
    "tokens": [{
        _id: false,
        "payment_type": String,
        "payment_sub_type": String,
        "bankaccount": {
            "bank_routing_number": String,
            "bank_account_number": String,
        },
        "token_id": String,
        "name_on_funding_account": String,
        "account_nickname": String,
        "fund_account_owner_full_address": {
            "address1": String,
            "address2": String,
            "city": String,
            "state": String,
            "zipcode": String
        },
        "status": String,
        "created_dt": Date,
        "updated_dt": Date,
        "created_id": String,
        "updated_id": String,
        "iscsr": Boolean

    }]
}



module.exports = wgsPaymentMethodsSchema;