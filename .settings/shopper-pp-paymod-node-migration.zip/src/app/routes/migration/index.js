const services = require("../../services");
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const createError = require('http-errors');
var migrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field startDate"));
    } else {
        startWGSMigration(payload, res, next);
    }

}

function startWGSMigration(payload, res, next) {

    //-------To migrate from xlsx to mongo DB-------
    try {
        logger.info("Migration process started..");
        services.readXLSXService(payload["filename"], next).then((inputData) => {
            if (inputData) {

                services.tokenizeService(inputData, next).then((tokenizedData) => {
                    logger.info("Tokenization of WGS payment methods completed");
                    var wgsDBData = services.formatToWGSSchema(tokenizedData);
                    services.saveToDBService(wgsDBData).then((response) => {
                        if (response) {
                            logger.info("WGS payment methods stored successfully in db");
                            services.exportToWGS(tokenizedData).then((isFileCreated) => {
                                if (isFileCreated) {
                                    logger.info("Pipe delimited flat file created");
                                    logger.info("Migration process completed..");
                                    res.send({ success: true, message: "Migration process completed" });
                                } else {
                                    logger.error("Could not create Pipe delimited flat file");
                                }
                                //   process.exit(0);
                            }).catch((error) => {
                                logger.error(error);
                                next(error);
                            })
                        } else {
                            logger.info("WGS payment methods storing unsuccessfull in db");
                        }

                    }).catch((error) => {
                        logger.error(error);
                        next(error);
                    })

                }).catch((error) => {
                    logger.error(error);
                    next(error);
                })
            } else {
                logger.error("Read error");
                next("File read error");
            }

        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = migrationController;