const services = require("../../services");
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const createError = require('http-errors');
var aciachmigrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field filename"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        startACIACHMigration(payload, res, next);
    }

}

function startACIACHMigration(payload, res, next) {

    //-------To migrate from flat file aci ach to mongo DB-------
    try {
        logger.info("Migration process started..");
        services.readAciAchFlatFile(payload["filename"], next).then((inputData) => {
            console.log('**************************************** inputData : ' + inputData);
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = aciachmigrationController;