const services = require("../../services");
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const createError = require('http-errors');
var aciachmigrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field filename"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        startACIACHMigration(payload, res, next);
    }

}

function startACIACHMigration(payload, res, next) {

    //-------To migrate from flat file aci ach to mongo DB-------
    try {
        logger.info("Migration process started..");
        services.readAciAchFlatFile(payload["filename"], payload["lob"], next).then((inputData) => {
            logger.info("reading ach aci payment methods, validation and writing invalid records completed");
            services.saveAciToPods(inputData, payload["lob"], 'ach').then((response) => {
                console.log('after db operation');
                res.send({ success: true, message: "Migration process completed" });
                /*if (response) {
                    logger.info("WGS payment methods stored successfully in db");
                    services.exportToWGS(tokenizedData).then((isFileCreated) => {
                        if (isFileCreated) {
                            logger.info("Pipe delimited flat file created");
                            logger.info("Migration process completed..");
                            res.send({ success: true, message: "Migration process completed" });
                        } else {
                            logger.error("Could not create Pipe delimited flat file");
                        }
                        //   process.exit(0);
                    }).catch((error) => {
                        logger.error(error);
                        next(error);
                    })
                } else {
                    logger.info("WGS payment methods storing unsuccessfull in db");
                }*/
            }).catch((error) => {
                logger.error(error);
                next(error);
            })
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = aciachmigrationController;