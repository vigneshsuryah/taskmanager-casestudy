var express = require('express');
var router = express.Router();
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const versionController = require("./version");
const migrationController = require("./migration");
const aciachmigrationController = require("./aci-ach");
const uploadController = require("./fileUpload");
var multer = require('multer');

try {
    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, './src/files/');
        },
        filename: function (req, file, cb) {
            cb(null, file.originalname)
        }
    });
    var upload = multer({
        storage: storage
    });
    var uploadmulter = upload.single('file');

    router.get('/getVersion', versionController);
    router.post('/wgsMigration', migrationController);
    router.post('/aciachMigration', aciachmigrationController);
    router.post('/upload', uploadmulter, uploadController);


} catch (err) {
    logger.error(err);
    throw new Error("Error in routing");
}
module.exports = router;