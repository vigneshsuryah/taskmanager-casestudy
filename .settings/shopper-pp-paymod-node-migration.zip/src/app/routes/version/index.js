
var versionController = (req, res, next) => {
    res.send({
        verison: "paymod-migration-service-v1.0"
    });
}

module.exports = versionController;