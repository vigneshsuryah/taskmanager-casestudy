const fs = require('fs');
const _ = require("underscore");
const wgs_configurations = require("../../../configuration/config")["wgsPaymentMethods"];
const configurations = require("../../../configuration/config")[wgs_configurations["dest"]];
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");




/* ----- Function to get records from xlsx ----- */
var validateWGSPaymentMethods = (inputRecord) => {
    var isValid = true;
    var bank_account_pattern = /^\d{4,17}$/;
    //var address_pattern=/^\w{0,40}$/i;
    var city_pattern = /^\w{0,20}$/i;
    var state_pattern = /^\w{0,2}$/i;
    var zip_pattern = /^\d{0,9}$/;
    var invalid_message = "";
    if (!inputRecord["hcid"] || String(inputRecord["hcid"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Missing Subscriber ";
    }
    if (!inputRecord["name_on_funding_account"] || String(inputRecord["name_on_funding_account"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Missing First Name/ Last Name ";
    }
    if (inputRecord["bankaccount"]["bank_account_number"].length === 0 || !bank_account_pattern.test(inputRecord["bankaccount"]["bank_account_number"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Bank Account ";
    }
    if (inputRecord["fund_account_owner_full_address"]["address1"].length === 0 || inputRecord["fund_account_owner_full_address"]["address1"].length >= 40) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Address";
    }
    if (inputRecord["fund_account_owner_full_address"]["city"].length === 0 || !city_pattern.test(String(inputRecord["fund_account_owner_full_address"]["city"]).replace(/ /g, "").trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid City";
    }
    if (inputRecord["fund_account_owner_full_address"]["state"].length === 0 || !state_pattern.test(String(inputRecord["fund_account_owner_full_address"]["state"]).trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid State";
    }
    if (inputRecord["fund_account_owner_full_address"]["zipcode"].length === 0 || !zip_pattern.test(String(inputRecord["fund_account_owner_full_address"]["zipcode"]).replace("-", ""))) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Zip";
    }
    if (inputRecord["authorization_id"].length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Authorization ID Missing";
    }
    if (inputRecord["authorization_mode"].length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Authorization Mode Missing";
    }
    if (!isValidRoutingNo(inputRecord["bankaccount"]["bank_routing_number"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Routing Data";
    }
    return { isValid: isValid, msg: invalid_message };
}

/* -------------------------------------------------- */

function isValidRoutingNo(routingNo) {
    const FIRST_MULTIPLER = 3;
    const SECOND_MULTIPLER = 7;
    const THIRD_MULTIPLER = 1;
    var routing_digits = String(routingNo).split("");

    if (routing_digits.length != 9) {
        return false;
    }
    var productsSumOrg = (Number(routing_digits[0]) * FIRST_MULTIPLER) + (Number(routing_digits[3]) * FIRST_MULTIPLER) + (Number(routing_digits[6]) * FIRST_MULTIPLER)
        + (Number(routing_digits[1]) * SECOND_MULTIPLER) + (Number(routing_digits[4]) * SECOND_MULTIPLER) + (Number(routing_digits[7]) * SECOND_MULTIPLER)
        + (Number(routing_digits[2]) * THIRD_MULTIPLER) + (Number(routing_digits[5]) * THIRD_MULTIPLER);
    var productsSumArr = productsSumOrg;
    if (productsSumOrg % 10 > 0) {
        productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
    }
    if (productsSumArr - productsSumOrg == Number(routing_digits[8])) {
        return true;
    }
    else {
        return false;
    }

}


module.exports = {
    validateWGSPaymentMethods: validateWGSPaymentMethods

};




