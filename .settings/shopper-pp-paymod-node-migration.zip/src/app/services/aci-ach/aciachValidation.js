const fs = require('fs');
const _ = require("underscore");
const logger = require('logger').createLogger("/apps/node/eox/aci-ach-migration/logs/paymod-migration-service.log");

/* ----- Function to get records from xlsx ----- */
var aciachValidation = (inputRecord) => {
    
    var isValid = true;
    var bank_account_pattern = /^\d{4,17}$/;
    //var address_pattern=/^\w{0,40}$/i;
    var city_pattern = /^\w{0,20}$/i;
    var state_pattern = /^\w{0,2}$/i;
    var zip_pattern = /^\d{0,9}$/;
    var invalid_message = "";

    if (!inputRecord["hcid"] || String(inputRecord["hcid"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Invalid HCID ";
    }
    if (!inputRecord["token"]["payment_sub_type"] || String(inputRecord["token"]["payment_sub_type"]).trim().length === 0 || 
        !isValidPaymentSubType(inputRecord["token"]["payment_sub_type"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Payment SubType ";
    }
    if (!inputRecord["token"]["name_on_funding_account"] || String(inputRecord["token"]["name_on_funding_account"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Missing Funding Account Name ";
    }
    if (inputRecord["token"]["bankaccount"]["bank_account_number"].length === 0 || !bank_account_pattern.test(inputRecord["token"]["bankaccount"]["bank_account_number"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Bank Account ";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["address1"].length === 0 || inputRecord["token"]["fund_account_owner_full_address"]["address1"].length >= 40) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Address";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["city"].length === 0 || !city_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["city"]).replace(/ /g, "").trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid City";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["state"].length === 0 || !state_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["state"]).trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid State";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["zipcode"].length === 0 || !zip_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["zipcode"]).replace("-", ""))) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Zip";
    }
    if (!isValidRoutingNo(inputRecord["token"]["bankaccount"]["bank_routing_number"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Routing Data";
    }
    return { isValid: isValid, msg: invalid_message };
}

/* -------------------------------------------------- */

function isValidPaymentSubType(paymentSubType){
    if(paymentSubType === 'PERSONAL CHECKING' || paymentSubType === 'PERSONAL SAVINGS' || paymentSubType === 'BUSINESS CHECKING' || paymentSubType === 'BUSINESS SAVINGS'){
        return true;
    }else{
        return false;
    }
}

function isValidRoutingNo(routingNo) {
    const FIRST_MULTIPLER = 3;
    const SECOND_MULTIPLER = 7;
    const THIRD_MULTIPLER = 1;
    var routing_digits = String(routingNo).split("");

    if (routing_digits.length != 9) {
        return false;
    }
    var productsSumOrg = (Number(routing_digits[0]) * FIRST_MULTIPLER) + (Number(routing_digits[3]) * FIRST_MULTIPLER) + (Number(routing_digits[6]) * FIRST_MULTIPLER)
        + (Number(routing_digits[1]) * SECOND_MULTIPLER) + (Number(routing_digits[4]) * SECOND_MULTIPLER) + (Number(routing_digits[7]) * SECOND_MULTIPLER)
        + (Number(routing_digits[2]) * THIRD_MULTIPLER) + (Number(routing_digits[5]) * THIRD_MULTIPLER);
    var productsSumArr = productsSumOrg;
    if (productsSumOrg % 10 > 0) {
        productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
    }
    if (productsSumArr - productsSumOrg == Number(routing_digits[8])) {
        return true;
    }
    else {
        return false;
    }

}

module.exports = {
    aciachValidation: aciachValidation
};