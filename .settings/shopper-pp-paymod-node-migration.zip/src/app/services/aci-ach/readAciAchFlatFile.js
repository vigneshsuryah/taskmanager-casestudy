const fs = require('fs');
const readline = require('readline');

const _ = require("underscore");
const wgs_configurations = require("../../../configuration/config")["wgsPaymentMethods"];
const environment = process.argv[2];
const configurations = require("../../../configuration/config")[environment];
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
var { wgsPaymentsDBFixedValues, wgsInvalidHeaderValues } = require("../dataSchemas/wgsPaymentsFixedValues");
var { validateWGSPaymentMethods } = require("../validations/wgsValidations");
var { writeXLSXService } = require("../WGS/writeFile");

/* ----- Function to get records from xlsx ----- */
var readAciAchFlatFile = (filename) => {

    return new Promise((resolve, reject) => {
        readAciAchFile(filename, resolve, reject);
    })
}

function readAciAchFile(filename, resolve, reject) {

    try {
        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/ACH.txt')
        });

        let line_no = 0;

        rl.on('line', function(line) {
            line_no++;
            //console.log(line);
            if(line_no !== 1){
                
            }
        });

        rl.on('close', function(line) {
            console.log('Total lines : ' + line_no);
        });
    } catch (e) {
        console.log("Error", e);
        logger.error(e);
        reject(e);
    }
}

/* -------------------------------------------------- */



module.exports = {
    readAciAchFlatFile: readAciAchFlatFile

};




