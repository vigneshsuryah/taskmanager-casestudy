const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("/apps/node/eox/aci-ach-migration/logs/paymod-migration-service.log");
var { aciachValidation } = require("../aci-ach/aciachValidation");
var { writeInvalidRecords } = require("../aci-ach/writeInvalidRecords");

/* ----- Function to get records from xlsx ----- */
var readAciAchFlatFile = (filename, lob) => {
    return new Promise((resolve, reject) => {
        readAciAchFile(filename, lob, resolve, reject);
    })  
}

function readAciAchFile(filename, lob, resolve, reject) {

    try {
        var valid_records = [];
        var invalid_records = [];

        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/' + filename)
        });

        let line_no = 0;
        let invalid_count = 0;
        let valid_count = 0;

        rl.on('line', function(line) {
            //console.log(line);
            line_no++;
            if(line_no === 1){
                invalid_records.push(line);
            }
            if(line_no !== 1){
                var inputRecordSplits = line.split(",");
                if(inputRecordSplits.length !== 11){
                    invalid_records.push(line + ", Invalid Record");
                    invalid_count++;
                } else {
                    var formattedRecord = {};
                    formattedRecord = {
                    "hcid" : inputRecordSplits[0],
                    "lob" : lob,
                    "token" : {
                            "payment_type" : "ACH",
                            "payment_sub_type" : inputRecordSplits[2].toUpperCase(),
                            "bankaccount" : {
                                "bank_routing_number" : inputRecordSplits[3],
                                "bank_account_number" : inputRecordSplits[4]
                            },
                            "token_id" : inputRecordSplits[1],
                            "name_on_funding_account" : inputRecordSplits[5],
                            "fund_account_owner_full_address" : {
                                "address1" : inputRecordSplits[6],
                                "address2" : inputRecordSplits[7],
                                "city" : inputRecordSplits[8],
                                "state" : inputRecordSplits[9],
                                "zipcode" : inputRecordSplits[10]
                            },
                            "status" : "ACTIVE",
                            "created_dt" : new Date(),
                            "created_id" : "ACIMIGRATED",
                            "updated_dt" : new Date(),
                            "updated_id" : "ACIMIGRATED",
                            "iscsr" : false
                        }
                    }

                    // check the record is valid or not
                    var validationResult = aciachValidation(formattedRecord);
                    if(validationResult["isValid"]){
                        valid_records.push(formattedRecord);
                        valid_count++;
                    }else{
                        invalid_records.push(line + ", " + validationResult["msg"]);
                        invalid_count++;
                    }
                }
            }
        });

        rl.on('close', function(line) {
            console.log('Total Valid lines : ' + valid_count);
            console.log('Total Invalid lines : ' + invalid_count);
            console.log('Total lines : ' + (line_no - 1));

            // write invalid records
            var writeFlag = writeInvalidRecords(invalid_records);

            console.log('Invalid File Write Status : ' + writeFlag);

            resolve(valid_records);
        });
    } catch (e) {
        console.log("Error", e);
        logger.error(e);
        reject(e);
    }
}

/* -------------------------------------------------- */



module.exports = {
    readAciAchFlatFile: readAciAchFlatFile

};




