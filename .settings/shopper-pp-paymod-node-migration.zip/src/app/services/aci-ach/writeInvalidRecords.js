const fs = require('fs');
const _ = require("underscore");
const logger = require('logger').createLogger("/apps/node/eox/aci-ach-migration/logs/paymod-migration-service.log");

var writeInvalidRecords = (data) => {
    
    var fs = require('fs');

    try{

        var file = fs.createWriteStream('./output/ACH-invalid-records.txt');
        
        file.on('error', function(err) {
            logger.error('Invalid Record file error');
            return false;
        });

        data.forEach(function(linecontent) {
            file.write(linecontent + '\n'); 
        });

        file.end();
        return true;

    } catch (e) {
        console.log("Error", e);
        logger.error(e);
        return false;
    }

    
}

module.exports = {
    writeInvalidRecords: writeInvalidRecords
};