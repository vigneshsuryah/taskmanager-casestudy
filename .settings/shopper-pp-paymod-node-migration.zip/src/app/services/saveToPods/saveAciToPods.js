const mongoose = require("mongoose");
const fs = require('fs');
const environment = process.argv[2];
const uuidv4 = require('uuid/v4');
const configurations = require("../../../configuration/config")[environment];
const logger = require('logger').createLogger("/apps/node/eox/aci-ach-migration/logs/paymod-migration-service.log");
const paymentMethodsSchema = require('../../persistance/models/paymentMethodsSchema');
const aciAuditSchema = require('../../persistance/models/aciAuditSchema');
var paymentsWalletModel = mongoose.model('payment_wallet', new mongoose.Schema(paymentMethodsSchema, {
    collection: 'payment_wallet',
    versionKey: false,
    _id: false
}));
var aciAuditModel = mongoose.model('audit_aci_tokenid', new mongoose.Schema(aciAuditSchema, {
    collection: 'audit_aci_tokenid',
    versionKey: false,
    _id: false
}));

var ca = fs.readFileSync(configurations.mongo_cert_path);

var saveAciToPods = (input, lob, type) => {

    return new Promise((resolve, reject) => {

        persistToDB(input, lob, type, resolve, reject);

    })

}

function persistToDB(input, lob, type, resolve, reject) {


    mongoose.connect(configurations.mongo_url, {
        user: configurations.mongo_user,
        pass: configurations.mongo_password,
        sslCA: ca,
        useNewUrlParser: true
    });


    const db = mongoose.connection;
    mongoose.set('useFindAndModify', false);

    db.once("open", function(callback) {
        console.log("Connection succeeded.");
    });

    db.on('error', () => {
        logger.error('MongoDB connection error');
        reject("Mongoose connection error");
    });

    if(type === 'ach'){
        achMethod(mongoose, input, lob, resolve, reject)
    }else{
        reject(false);
    }

}

function achMethod(mongoose, input, lob, resolve, reject){
    paymentsWalletModel = mongoose.model('payment_wallet');

    input.forEach(function(item) {
        //console.log(JSON.stringify(item));

        var aci_token = item.token.token_id;
        var pods_token = uuidv4().replace(/-/g, "");
        item.token.token_id = pods_token;
        var auditRecord = {
            "hcid": item.hcid, 
            "lob": item.lob,
            "aci_token": aci_token,
            "pods_token": pods_token,
            "payment_type" : "ACH"
        }
        var query = { "hcid": item.hcid, "lob": item.lob };
        console.log('query : ' + JSON.stringify(query));
        paymentsWalletModel.findOne(query, function(err, wallet_info) {
            if (err) {
                console.log(err);
                logger.error(err);
                reject(err);
            }else{
                console.log(JSON.stringify(wallet_info));
                if(wallet_info !== undefined && wallet_info !== null && wallet_info.hcid !== ''){
                    //console.log('existing document');
                    //console.log('addition item : ' + JSON.stringify(item.token));

                    var update = {
                        $push: {tokens: item.token}
                    }
                    var options = {upsert: true};
                    paymentsWalletModel.findOneAndUpdate(query, update, options, function (err, data) {
                        if (err) {
                            console.log(err);
                            logger.error(err);
                            reject(err);
                        }else{
                            console.log(item.hcid + " ach payment method updated ******");
                            aciAuditModel.insertMany(auditRecord, (err, docs) => {
                                if (err) {
                                    console.log(err);
                                    logger.error(err);
                                    reject(err);
                                } else {
                                    console.log(auditRecord.hcid + " audit aci tokenid inserted ******");
                                    db.close((error) => {
                                        logger.error("Error closing DB connection");
                                    });
                                }
                            });
                        }
                    });
                } else{
                    //console.log('new document');
                    var temp_insert_document = {};
                    temp_insert_document.hcid = item.hcid;
                    temp_insert_document.lob = item.lob;
                    var tokens = [];
                    tokens.push(item.token);
                    temp_insert_document.tokens = tokens;
                    //console.log(JSON.stringify(temp_insert_document));
                    paymentsWalletModel.insertMany(temp_insert_document, (err, docs) => {
                        if (err) {
                            console.log(err);
                            logger.error(err);
                            reject(err);
                        } else {
                            console.log(item.hcid + " ach payment method inserted ******");
                            aciAuditModel.insertMany(auditRecord, (err, docs) => {
                                if (err) {
                                    console.log(err);
                                    logger.error(err);
                                    reject(err);
                                } else {
                                    console.log(auditRecord.hcid + " audit aci tokenid inserted ******");
                                    db.close((error) => {
                                        logger.error("Error closing DB connection");
                                    });
                                }
                            });
                        }
                    });
                }
                //resolve(wallet_info);
            }
        });

    });

    console.log('after for each');
    
    resolve(true);

    
   
}

module.exports = {
    saveAciToPods: saveAciToPods
};




