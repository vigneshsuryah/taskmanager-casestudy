const _ = require("underscore");
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
var { wgsHeaderValues } = require("../dataSchemas/wgsPaymentsFixedValues");
var { writePipeDelimitedService } = require("../WGS/writeFile");

/* ----- Function to get records from xlsx ----- */
var exportService = (inputRecords) => {

    // return new Promise((resolve,reject)=>{
    //             getxlsxRecords(wgs_configurations.src,wgs_configurations.mappings_file,wgs_configurations.src_index,wgs_configurations.col_count,resolve,reject);
    // })
    return new Promise((resolve, reject) => {

        formatRecordsForWGS(inputRecords, resolve, reject);

        // setTimeout(() => {
        //     formatRecordsForWGS(inputRecords, resolve, reject);
        // }, 10000);
    })
}
function formatRecordsForWGS(inputRecords, resolve, reject) {

    var headers = Object.keys(wgsHeaderValues);
    var output_records = [];
    try {
        _.each(inputRecords, (record) => {
            var temp_record = {};
            _.each(headers, (header) => {
                temp_record[header] = (wgsHeaderValues[header] === "") ? "" : record[wgsHeaderValues[header]];
            })
            output_records.push(temp_record);

        })
        writePipeDelimitedService(output_records, headers, false, "WGS_records.txt");
        resolve("success");
    } catch (e) {
        console.log("Error", e);
        reject(e);
    }


}
/* -------------------------------------------------- */



module.exports = {
    exportWGSService: exportService

};




