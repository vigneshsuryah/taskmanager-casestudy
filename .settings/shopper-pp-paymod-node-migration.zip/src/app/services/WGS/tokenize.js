const uuidv4 = require('uuid/v4');
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const _ = require("underscore");


/* ----- Function to tokenize WGS payment methods ----- */
var tokenizeService = (input) => {

  return new Promise((resolve, reject) => {

    tokenize(input, resolve, reject);

    // setTimeout(()=>{
    //     tokenize(input,resolve,reject);
    // },10000);
  })

}
function tokenize(input, resolve, reject) {
  try {
    logger.info("Tokenization of WGS payment methods started");
    _.each(input, (record => {
      record["token_id"] = uuidv4().replace(/-/g, "");
    }))
    resolve(input);
  } catch (e) {
    reject(e);
  }
}
/* -------------------------------------------------- */



module.exports = {
  tokenizeService: tokenizeService

};




