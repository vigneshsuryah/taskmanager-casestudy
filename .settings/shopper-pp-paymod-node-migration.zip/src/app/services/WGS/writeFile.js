const fs = require('fs');
const _ = require("underscore");
const wgs_configurations = require("../../../configuration/config")["wgsPaymentMethods"];
const configurations = require("../../../configuration/config")[wgs_configurations["dest"]];
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const XLSX = require('xlsx');
var { wgsInvalidHeaderValues } = require("../dataSchemas/wgsPaymentsFixedValues");


/* ----- Function to write records to xlsx ----- */
var writePipeDelimitedService = (records, headers, isCommentsHeader, filename) => {

    // writeXlsxRecords(records, headers, isCommentsHeader, filename);
    writePipeRecords(records, headers, isCommentsHeader, filename);

}
var writeXLSXService = (records, headers, isCommentsHeader, filename) => {

    // writeXlsxRecords(records, headers, isCommentsHeader, filename);
    writeXlsxRecords(records, headers, isCommentsHeader, filename);

}

function writePipeRecords(records, headers, isCommentsHeader, filename) {
    var data = "";
    _.each(headers, (header, index) => {
        if (index === headers.length - 1)
            data = data + header + "\n";
        else
            data = data + header + "|";
    })
    _.each(records, (record) => {
        var counter = 1;
        _.each(record, (objValue) => {

            if (typeof (objValue) == "object") {
                _.each(objValue, (subObjValue) => {
                    data = data + subObjValue + "|";
                })
            } else {
                if (counter === Object.keys(record).length)
                    data = data + objValue + "\n";
                else
                    data = data + objValue + "|";
            }
            counter++;
        })


    })
    fs.writeFileSync("output/" + filename, data, (err) => {
        if (err) {
            logger.error(err);
        }

    });
}
function writeXlsxRecords(records, headers, isCommentsHeader, filename) {


    try {
        var wb = new Workbook();
        if (isCommentsHeader) {
            headers = wgsInvalidHeaderValues;
            headers.push("Comments");
        }

        var write_data = [headers];
        _.each(records, (data) => {
            var temp_data = [];
            _.each(data, (objValue) => {
                if (typeof (objValue) == "object") {
                    _.each(objValue, (subObjValue) => {
                        temp_data.push(subObjValue);
                    })
                } else {
                    temp_data.push(objValue);
                }
            })
            write_data.push(temp_data);

        })
        var ws = sheet_from_array_of_arrays(write_data);
        var worksheet_name = "Sheet1";
        /* add worksheet to workbook */
        wb.SheetNames.push(worksheet_name);
        wb.Sheets[worksheet_name] = ws;
        /* write workbook to file */
        XLSX.writeFile(wb, "output/" + filename);
        logger.info("Invalid records written to " + filename);
    } catch (e) {
        console.log("Error", e);
        logger.error(e);

    }


}

function sheet_from_array_of_arrays(data, opts) {
    var ws = {};
    var range = { s: { c: 10000000, r: 10000000 }, e: { c: 0, r: 0 } };
    for (var R = 0; R != data.length; ++R) {
        for (var C = 0; C != data[R].length; ++C) {
            if (range.s.r > R) range.s.r = R;
            if (range.s.c > C) range.s.c = C;
            if (range.e.r < R) range.e.r = R;
            if (range.e.c < C) range.e.c = C;
            var cell = { v: data[R][C] };
            if (cell.v == null) continue;
            var cell_ref = XLSX.utils.encode_cell({ c: C, r: R });

            if (typeof cell.v === 'number') cell.t = 'n';
            else if (typeof cell.v === 'boolean') cell.t = 'b';
            else if (cell.v instanceof Date) {
                cell.t = 'n'; cell.z = XLSX.SSF._table[14];
                cell.v = datenum(cell.v);
            }
            else cell.t = 's';

            ws[cell_ref] = cell;
        }
    }
    if (range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
    return ws;
}

function Workbook() {
    if (!(this instanceof Workbook)) return new Workbook();
    this.SheetNames = [];
    this.Sheets = {};
}


/* -------------------------------------------------- */



module.exports = {
    writeXLSXService: writeXLSXService,
    writePipeDelimitedService: writePipeDelimitedService

};




