const _ = require("underscore");
const logger = require('logger').createLogger("/apps/node/eox/payment-report/logs/paymod-migration-service.log");
const moment = require("moment");
var { wgsPaymentsDBFixedValues } = require("../dataSchemas/wgsPaymentsFixedValues");


/* ----- Function to get records from xlsx ----- */
var formatToWGSSchema = (inputRecords) => {
    var grouped_records = _.groupBy(inputRecords, (record) => {
        return record["hcid"];
    })
    var output_records = [];
    try {
        _.each(grouped_records, (record) => {
            var temp_record = { tokens: [] };
            temp_record["hcid"] = record[0]["hcid"];
            temp_record["lob"] = "WGS";
            var temp_tokens = [];
            _.each(record, (tokens_record) => {
                var temp_token_record = JSON.parse(JSON.stringify(tokens_record));
                temp_token_record["payment_sub_type"] = (temp_token_record["payment_sub_type"] === "C" ? "PERSONAL CHECKING" : "PERSONAL SAVINGS");
                temp_token_record["created_dt"] = new Date(moment(temp_token_record["created_dt"], "MM/DD/YYYY").format("YYYY-MM-DD")).toISOString();
                temp_token_record["term_dt"] = new Date(moment(temp_token_record["term_dt"], "MM/DD/YYYY").format("YYYY-MM-DD")).toISOString();
                delete temp_token_record["hcid"];
                temp_token_record = Object.assign(temp_token_record, wgsPaymentsDBFixedValues);
                temp_tokens.push(temp_token_record);
            })
            temp_record["tokens"] = temp_tokens;
            output_records.push(temp_record);
        })
        return output_records;
    } catch (e) {
        console.error(e);
    }
}

/* -------------------------------------------------- */



module.exports = {
    formatToWGSSchema: formatToWGSSchema

};




