# WGS Migration

## Build Steps
This is a one time migration process and needs to be run with the required configurations.
⦁ Extract the code base to a new folder.
⦁ Open a Terminal at the specified location and hit " npm install".
⦁ Place the input file in the "files" folder under "src".
⦁ Once the dependencies are downloaded please edit the configurations with the required values in the "config.json" file at the root directory of the project.Following are the configurations required :

- mongo_url = mongodb://localhost:27017/local // Destination Mongo URL
- mongo_user= XXXX // Mongo Username
- mongo_password= XXXX // Mongo Password
- Under wgsPaymentMethods":
                "src": Path to Source file of migration,
                "src_index":Sheet number,
                "mappings_file": Path to Column mappings file
        
⦁ Hit "npm run start-dev" to successfully start the application in DEV environment.
⦁ Hit "npm run start-sit" to successfully start the application in SIT environment.
⦁ Hit "npm run start-uat" to successfully start the application in UAT environment.
⦁ Hit "npm run start-perf" to successfully start the application in PERF environment.
⦁ Hit "npm run start-prod" to successfully start the application in PROD environment.
⦁ Hit "CTRL + C" to terminate the application.

The output files are stored in the output folder.

