const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const createError = require('http-errors');
const express = require('express');
const migrationRouter = require("./routes");
const cors = require('cors');
const environment = process.argv[2];
const configurations = require("../../src/configuration/config")[environment];
const csrf = require('csurf');
const csrfProtection = csrf();
const app = express();

var corsOptions = {
  origin: '*',
  methods: ['POST'],
  allowedHeaders: ['Origin', 'X-Requested-With', 'x-forwarded-for', 'Content-Type',
    'Content-Length', 'Accept-Encoding', 'Accept', 'Authorization', 'UserName', 'meta-senderapp',
    'meta-orgType']
}

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({
  extended: false
}));

app.use('/migration', migrationRouter);

// Catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// Custom Error Handler
app.use(function (err, req, res, next) {
  //After authentication is added
  //if (!req.user) return next(createError(401, 'Please login to access the API'));
  //next()
  logger.info("Error:", err.status);
  logger.info("Error:", JSON.stringify(err));
  if (!err.message && err.name === "UnauthorizedError") {
    err.status = 401;
    err.message = "Authorization failed";
  }


  res.send({
    success: false,
    status: (err.status || 500),
    message: (err.message) || "Internal server error"
  });
  logger.error(err.stack);
});

app.use(csrfProtection);

module.exports = app;

