const mongoose = require("mongoose");
const fs = require('fs');
const wgs_configurations = require("../../../configuration/config")["wgsPaymentMethods"];
const environment = process.argv[2];
const configurations = require("../../../configuration/config")[environment];
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const wgsPaymentMethodsSchema = require('../../persistance/models/wgsPaymentMethods');
var paymentsModel = mongoose.model('payment_wallet1', new mongoose.Schema(wgsPaymentMethodsSchema, {
    collection: 'payment_wallet',
    versionKey: false,
    _id: false
}));


var ca = fs.readFileSync(configurations.mongo_cert_path);


/* ----- Function to save in Mongo DB ----- */
var saveToDBService = (input) => {

    return new Promise((resolve, reject) => {

        persistToDB(input, resolve, reject);

        // setTimeout(() => {
        //     persistToDB(input, resolve, reject);
        // }, 10000);
    })

}

function persistToDB(input, resolve, reject) {


    mongoose.connect(configurations.mongo_url, {
        user: configurations.mongo_user,
        pass: configurations.mongo_password,
        sslCA: ca,
        useNewUrlParser: true
    });


    const db = mongoose.connection;

    db.on('error', () => {
        logger.error('MongoDB connection error');
        reject("Mongoose connection error");
    });
    var query_input = input;
    paymentsModel = mongoose.model('payment_wallet');
    paymentsModel.insertMany(query_input, (err, docs) => {
        db.close((error) => {
            logger.error("Error closing DB connection");
        });
        if (err) {
            logger.error(err);
            reject(err);
        } else {
            resolve(true);
        }
    })



}
/* -------------------------------------------------- */



module.exports = {
    saveToDBService: saveToDBService

};




