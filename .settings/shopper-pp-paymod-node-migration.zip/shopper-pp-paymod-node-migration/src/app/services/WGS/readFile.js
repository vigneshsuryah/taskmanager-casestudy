const fs = require('fs');
const _ = require("underscore");
const wgs_configurations = require("../../../configuration/config")["wgsPaymentMethods"];
const environment = process.argv[2];
const configurations = require("../../../configuration/config")[environment];
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
var { wgsPaymentsDBFixedValues, wgsInvalidHeaderValues } = require("../dataSchemas/wgsPaymentsFixedValues");
var { validateWGSPaymentMethods } = require("../validations/wgsValidations");
var { writeXLSXService } = require("../WGS/writeFile");

/* ----- Function to get records from xlsx ----- */
var readXLSXService = (filename) => {

    // return new Promise((resolve,reject)=>{
    //             getxlsxRecords(wgs_configurations.src,wgs_configurations.mappings_file,wgs_configurations.src_index,wgs_configurations.col_count,resolve,reject);
    // })
    return new Promise((resolve, reject) => {

        getxlsxRecords(filename, wgs_configurations.src, wgs_configurations.mappings_file, wgs_configurations.src_index, resolve, reject);

        // setTimeout(() => {
        //     getxlsxRecords(wgs_configurations.src, wgs_configurations.mappings_file, wgs_configurations.src_index, resolve, reject);
        // }, 10000);
    })
}
function getxlsxRecords(filename, src, mappings_file, index, resolve, reject) {
    const XLSX = require('xlsx');
    var workbook = XLSX.readFile(src + filename);
    const mappings = require(mappings_file);
    var temp_record = {};
    var col_mappings = {};
    var col_headers = [];
    var list_iterator = 0;
    var temp_iterator = 0;
    var final_records = [];
    var invalid_records = [];
    var isInvalid = false;
    var input_data = workbook["Sheets"]["Sheet" + index];
    var worksheet = workbook["Sheets"]["Sheet" + index];
    //delete input_data["!ref"];
    var headers = wgsInvalidHeaderValues;

    try {
        logger.info("Reading records from XSLX file");
        var records_length = XLSX.utils.sheet_to_json(input_data);
        var range = XLSX.utils.decode_range(worksheet['!ref']);
        for (var row = range.s.r; row <= range.e.r; ++row) {
            for (var column = range.s.c; column <= range.e.c; ++column) {
                var coord = XLSX.utils.encode_cell({ r: row, c: column });
                if (!worksheet[coord]) {

                    if (String(col_headers[column]).indexOf(".") != -1) {
                        var column_obj = String(col_headers[column]).split(".");
                        if (!temp_record[column_obj[0]])
                            temp_record[column_obj[0]] = {};
                        temp_record[column_obj[0]][column_obj[1]] = "";
                    } else
                        temp_record[col_headers[column]] = "";
                    /* The cell is not specified in the worksheet */
                } else {

                    /* worksheet[coord] is a valid cell */
                    if (row === 0) {
                        col_headers.push(mappings[String(worksheet[coord]["v"]).trim()]);
                    } else {

                        if (!temp_record[col_headers[column]]) {
                            if (String(col_headers[column]).indexOf(".") != -1) {
                                var column_obj = String(col_headers[column]).split(".");
                                if (!temp_record[column_obj[0]])
                                    temp_record[column_obj[0]] = {};
                                temp_record[column_obj[0]][column_obj[1]] = String(worksheet[coord]["v"]).trim();
                            } else
                                temp_record[col_headers[column]] = String(worksheet[coord]["v"]).trim();
                        }
                        else {
                            temp_record[col_headers[column]] = temp_record[col_headers[column]] + " " + String(worksheet[coord]["v"]).trim();
                        }
                    }
                }
            }
            if (row !== 0) {

                if (validateWGSPaymentMethods(temp_record)["isValid"]) {
                    //var final_object = Object.assign(temp_record, wgsPaymentsDBFixedValues);
                    final_records.push(JSON.parse(JSON.stringify(temp_record)));
                } else {
                    temp_record["error"] = validateWGSPaymentMethods(temp_record)["msg"];
                    invalid_records.push(JSON.parse(JSON.stringify(temp_record)));

                }
                temp_record = {};
                if (row === records_length.length) {
                    writeXLSXService(invalid_records, headers, true, "invalid_records.xlsx");
                    logger.info("Reading records from XSLX file complete");
                    resolve(final_records);
                    break;
                }
            }
        }
    } catch (e) {
        console.log("Error", e);
        logger.error(e);
        reject(e);
    }


}
/* -------------------------------------------------- */



module.exports = {
    readXLSXService: readXLSXService

};




