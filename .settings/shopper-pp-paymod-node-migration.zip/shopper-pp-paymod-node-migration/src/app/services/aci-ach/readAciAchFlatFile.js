const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { aciachValidation } = require("../aci-ach/aciachValidation");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

var readAciAchFlatFile = (filename, lob) => {
    return new Promise((resolve, reject) => {
        readAciAchFile(filename, lob, resolve, reject);
    })  
}

function readAciAchFile(filename, lob, resolve, reject) {

    try {
        var valid_records = [];
        var invalid_records = [];

        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/' + filename)
        });

        let line_no = 0;
        let invalid_count = 0;
        let valid_count = 0;
        let tokenid_array = [];
        var nickname_pattern = /^\w{0,45}$/i;

        rl.on('line', function(line) {

            line_no++;
                var inputRecordSplits = line.split("|");
                if(inputRecordSplits.length !== 15){
                    invalid_records.push(line + ", Invalid Record");
                    invalid_count++;
                } 
                else if(tokenid_array.includes(inputRecordSplits[0])){
                    invalid_records.push(line + ", Duplicate Token Id Record");
                    invalid_count++;
                }
                else {
                    var formattedRecord = {};
                    var lobCalc = lob;
                    if(inputRecordSplits[1].trim().length > 9 && lob === 'GBDIN'){
                        lobCalc = 'GOFUNDHIP';
                    }
                    var account_number = '';
                    var routing_number = '';
                    if(inputRecordSplits[4] !== '' && inputRecordSplits[5] !== ''){
                        routing_number = inputRecordSplits[5];
                    }else if(inputRecordSplits[4] !== ''){
                        routing_number = inputRecordSplits[4];
                    }else if(inputRecordSplits[5] !== ''){
                        routing_number = inputRecordSplits[5];
                    }

                    if(inputRecordSplits[6] !== '' && inputRecordSplits[7] !== ''){
                        account_number = inputRecordSplits[7];
                    }else if(inputRecordSplits[6] !== ''){
                        account_number = inputRecordSplits[6];
                    }else if(inputRecordSplits[7] !== ''){
                        account_number = inputRecordSplits[7];
                    }
                    
                    tokenid_array.push(inputRecordSplits[0]);
                    let nickname = inputRecordSplits[3] === 'N/A' ? "" : inputRecordSplits[3];
                    if (nickname && nickname.length > 0 && !nickname_pattern.test(nickname.trim())) {
                        nickname = "";
                    }

                    formattedRecord = {
                    "hcid" : inputRecordSplits[1],
                    "lob" : lobCalc,
                    "token" : {
                            "payment_type" : "ACH",
                            "payment_sub_type" : inputRecordSplits[8].toUpperCase(),
                            "bankaccount" : {
                                "bank_routing_number" : routing_number,
                                "bank_account_number" : account_number
                            },
                            "token_id" : inputRecordSplits[0],
                            "name_on_funding_account" : inputRecordSplits[9],
                            "account_nickname" : nickname,
                            "fund_account_owner_full_address" : {
                                "address1" : inputRecordSplits[10],
                                "address2" : inputRecordSplits[11],
                                "city" : inputRecordSplits[12],
                                "state" : inputRecordSplits[13],
                                "zipcode" : inputRecordSplits[14]
                            },
                            "status" : "ACTIVE",
                            "created_dt" : new Date(),
                            "created_id" : "ACIMIGRATED",
                            "updated_dt" : new Date(),
                            "updated_id" : "ACIMIGRATED",
                            "iscsr" : false
                        }
                    }

                    // check the record is valid or not
                    var validationResult = aciachValidation(formattedRecord);
                    if(validationResult["isValid"]){
                        valid_records.push(formattedRecord);
                        valid_count++;
                    }else{
                        invalid_records.push(line + ", " + validationResult["msg"]);
                        invalid_count++;
                    }
                }
        });

        rl.on('close', function(line) {
            logger.info('Total Valid lines : ' + valid_count);
            logger.info('Total Invalid lines : ' + invalid_count);
            logger.info('Total lines : ' + (line_no));

            // write invalid records
            var writeFlag = writeFileWithRecords(invalid_records,"ACH-invalid-records.txt");

            logger.info('Invalid File Write Status : ' + writeFlag);

            resolve(valid_records);
        });
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

/* -------------------------------------------------- */



module.exports = {
    readAciAchFlatFile: readAciAchFlatFile

};




