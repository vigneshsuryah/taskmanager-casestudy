const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

/* ----- Function to get records from xlsx ----- */
var readAciCc2FlatFile = (filename, lob) => {
    return new Promise((resolve, reject) => {
        readAciCC2File(filename, lob, resolve, reject);
    })  
}

function readAciCC2File(filename, lob, resolve, reject) {

    try {
        var valid_records = [];
        var invalid_records = [];

        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/' + filename)
        });

        let line_no = 0;
        let invalid_count = 0;
        let valid_count = 0;
        let tokenid_array = [];

        rl.on('line', function(line) {
            line_no++;
                var inputRecordSplits = line.split(",");
                if(inputRecordSplits.length !== 6){
                    invalid_records.push(line + ", Invalid Record");
                    invalid_count++;
                } 
                else if(tokenid_array.includes(inputRecordSplits[5])){
                    invalid_records.push(line + ", Duplicate Token Id Record");
                    invalid_count++;
                }
                else {
                    var formattedRecord = {};
                    var ccnum = inputRecordSplits[3];
                    if(ccnum !== ''){
                        ccnum = ccnum.trim();
                    }
                    var first_six = "";
                    var last_four = "";
                    if(ccnum.length === 16){
                        first_six = ccnum.substring(0, 6);
                        last_four = ccnum.substr(ccnum.length - 4);
                    }
                    tokenid_array.push(inputRecordSplits[5]);
                    formattedRecord = {
                        "token_id" : inputRecordSplits[5],
                        "credit_card_number" : ccnum,
                        "credit_card_first_six" : first_six,
                        "credit_card_last_four" : last_four,
                        "payment_sub_type" : inputRecordSplits[2]
                    }
                    var valid_flag = true;
                    var error_msg = "";
                    if(formattedRecord.payment_sub_type === 'VI'){
                        formattedRecord.payment_sub_type = 'VISA';
                        valid_flag = true;
                    }else if(formattedRecord.payment_sub_type === 'MC'){ // TODO include CR CZ
                        valid_flag = true;
                    }else{
                        valid_flag = false;
                        error_msg = ", Invalid Payment Sub Type";
                    }
                    if(formattedRecord.credit_card_number.length !== 16){
                        valid_flag = false;
                        error_msg = error_msg + ", Invalid Card Number";
                    }
                    if(valid_flag){
                        valid_records.push(formattedRecord);
                        valid_count++;
                    }else{
                        invalid_records.push(line + error_msg);
                        invalid_count++;
                    }
                }
        });

        rl.on('close', function(line) {
            logger.info('Total Valid lines : ' + valid_count);
            logger.info('Total Invalid lines : ' + invalid_count);
            logger.info('Total lines : ' + (line_no));

            // write invalid records
            var writeFlag = writeFileWithRecords(invalid_records,"CC2-echo-invalid-records.txt");

            logger.info('Invalid File Write Status : ' + writeFlag);

            resolve(valid_records);
        });
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

module.exports = {
    readAciCc2FlatFile: readAciCc2FlatFile
};