const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

/* ----- Function to get records from xlsx ----- */
var cc3RecordsWrite = (data, filename) => {
    return new Promise((resolve, reject) => {
        cc3RecordsWrite(data, filename, resolve, reject);
    })  
}

function cc3RecordsWrite(data, filename, resolve, reject) {

    try {
        var inputRecords = [];
        var tilde_operator = "|";

        for (var item of data) {
            for(var token of item.tokens){
                if(token.payment_type === 'CC' && token.credit_card_number !== '' && token.credit_card_number.length === 16){
                    let temp_value = "";
                    temp_value = temp_value + token.credit_card_number + tilde_operator;
                    temp_value = temp_value + token.expiration_month + token.expiration_year + tilde_operator;
                    temp_value = temp_value + token.fund_account_owner_full_address.zipcode + tilde_operator;
                    let sub_type = "";
                    if(token.payment_sub_type === 'VISA'){
                        sub_type = "VI";
                    }else if(token.payment_sub_type === 'MC'){
                        sub_type = "MC";
                    }
                    temp_value = temp_value + sub_type + tilde_operator;
                    temp_value = temp_value + generate_order_id + tilde_operator;
                    temp_value = temp_value + token.token_id + tilde_operator;
                    temp_value = temp_value + item.hcid + tilde_operator + tilde_operator + tilde_operator + tilde_operator + tilde_operator;
                    inputRecords.push(temp_value);
                }
            }
            
        }
        var writeFlag = writeFileWithRecords(inputRecords, filename);
        resolve(writeFlag);
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

module.exports = {
    cc3RecordsWrite: cc3RecordsWrite
};