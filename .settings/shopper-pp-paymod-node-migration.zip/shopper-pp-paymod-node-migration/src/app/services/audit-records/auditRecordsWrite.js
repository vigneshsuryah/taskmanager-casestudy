const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

/* ----- Function to get records from xlsx ----- */
var auditRecordsWrite = (data, filename) => {
    return new Promise((resolve, reject) => {
        auditRecordsWriteMethod(data, filename, resolve, reject);
    })  
}

function auditRecordsWriteMethod(data, filename, resolve, reject) {

    try {
        var inputRecords = [];
        inputRecords.push("SBSB_ID,OLD_TOKENID,TOKENID");
        for (var item of data) {
            inputRecords.push(item.hcid + "," + item.aci_token + "," + item.pods_token);
        }
        var writeFlag = writeFileWithRecords(inputRecords, filename);
        resolve(writeFlag);
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

module.exports = {
    auditRecordsWrite: auditRecordsWrite
};