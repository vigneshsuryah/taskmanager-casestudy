const insertTransaction={
    "schema_data":{
        "_class" : "com.anthem.payment.paymod.entity.PaymentDetails",
        "anthem_orderid" : "csr190416z51242553",
        "acn" : "",
        "member_billing_name" : "Aberle, Laura",
        "member_billing_id" : "541M82211",
        "subscr_name" : "Aberle, Laura",
        "product_identifier" : "INHIPPL0",
        "summary_bill" : "",
        "group_name" : "IN Medicaid - Healthy Indiana Plan",
        "group_number" : "INMCDWP0",
        "subgroup_name" : "IN HIP Plus- Copay (Power Account)",
        "subgroup_number" : "INHIPPL2",
        "system" : "15",
        "legal_entity" : "18",
        "market_segment" : "011",
        "market" : "Medi",
        "division_code" : "FHIP",
        "transaction_division_code" : "355970",
        "settle_amount" : 42.0,
        "lob" : "GBDIN",
        "hcid" : "541M82211",
        "third_party_id" : "",
        "third_party_name" : "",
        "payer_id" : {
            "type" : "CSR",
            "id" : "AG03012"
        },
        "payment_method" : {
            "payment_type" : "CC",
            "payment_sub_type" : "VISA",
            "credit_card_number" : "444444ZHFZGZ4448",
            "credit_card_number_ui" : "4444446333764448",
            "credit_card_first_six" : "444444",
            "credit_card_last_four" : "4448",
            "cc_authorization_number" : "tst095",
            "interchange_qualification_code" : "",
            "name_on_funding_account" : "Tesola",
            "fund_account_owner_full_address" : {
                "address1" : "7480 W 800 N",
                "city" : "Orland",
                "state" : "IN",
                "zipcode" : "46776"
            },
            "action_code" : "AU",
            "cc_exp_date" : "03/2023",
            "response_reason_code" : "100",
            "token_response_date" : "190416",
            "is_level3" : "N",
            "AVSAAV" : "I4",
            "messageType" : "CSTO",
            "responseTransactionID" : "019106692165784",
            "storedCredentialFlag" : "N"
        },
        "transactions" : [ 
            {
                "created_dt" : new Date("2019-04-16T05:39:04.004Z"),
                "created_id" : "AG03012",
                "updated_dt" : new Date("2019-04-16T21:43:23.060Z"),
                "updated_id" : "AG03012",
                "iscsr" : true,
                "payment_channel" : "CSR",
                "premium_amount" : 42.0,
                "paid_date" : new Date("2019-04-16T00:00:00.000Z"),
                "fee_amount" : 0.0,
                "transaction_status" : "COMPLETED",
                "frequency" : "",
                "invoice_number" : "",
                "payment_confirmation_email_address" : "",
                "notification_indicator" : "EMAIL",
                "updated_to_psd" : "N",
                "communication_details" : {
                    "email_id" : "srikanth.kavuri@anthem.com"
                },
                "notes" : [ 
                    {
                        "csrId" : "AG03012",
                        "note_desc" : "ola",
                        "action" : "submit"
                    }
                ],
                "transaction_type" : "PAYMENT",
                "noc_received" : false,
                "anthem_bank_details" : {
                    "anthem_deposting_bank" : "chase",
                    "business_unit" : "1147543",
                    "anthem_bank_account" : "5552",
                    "transaction_division" : "355970"
                },
                "check_id" : "PBP_190416",
                "journal": {
                    "journal_id":"1211",
                    "journal_date":new Date("2019-04-16T22:05:32.883Z"),
                    "legal_entity_code":"12"
                    } ,
                "status" : {
                    "ediaccepted" : {
                        "status_code" : "TA",
                        "updated_dt" : new Date("2019-04-16T22:05:32.883Z")
                    },
                    "submitted" : {
                        "updated_dt" : new Date("2019-04-16T22:18:43.711Z")
                    },
                    "accepted" : {
                        "status_code" : "100",
                        "status_description" : "Invalid purchase level III",
                        "updated_dt" : new Date("2019-04-16T22:23:57.520Z")
                    },
                    "completed" : {
                        "auth_code" : "AUTHCODE",
                        "auth_resp_code" : "244",
                        "report_date" : "20190221-20190225",
                        "submission_date" : new Date("2019-02-24T05:00:00.000Z"),
                        "trace_no" : "20190225",
                        "updated_dt" : new Date("2019-04-16T22:34:10.186Z")
                    }
                },
                "submission_date" : new Date("2019-02-24T05:00:00.000Z")
            }
        ],
        "state" : "IN"
    }
};
const paymentMethod={
    "ach": {
        "payment_type" : "ACH",
        "payment_sub_type" : "BUSINESS CHECKING",
        "bank_routing_number" : "071102830",
        "bank_account_number" : "71102830",
        "name_on_funding_account" : "sgsg",
        "fund_account_owner_full_address" : {
            "address1" : "6892223 Do Not Mail",
            "address2" : "",
            "city" : "Arapahoe",
            "state" : "NE",
            "zipcode" : "68922"
        }
    },
    "cc":
        {
            "payment_type" : "CC",
            "payment_sub_type" : "VISA",
            "credit_card_number" : "444444ZHFZGZ4448",
            "credit_card_number_ui" : "4444446333764448",
            "credit_card_first_six" : "444444",
            "credit_card_last_four" : "4448",
            "cc_authorization_number" : "tst095",
            "interchange_qualification_code" : "",
            "name_on_funding_account" : "Tesola",
            "fund_account_owner_full_address" : {
                "address1" : "7480 W 800 N",
                "city" : "Orland",
                "state" : "IN",
                "zipcode" : "46776"
            },
            "action_code" : "AU",
            "cc_exp_date" : "03/2023",
            "response_reason_code" : "100",
            "token_response_date" : "190416",
            "is_level3" : "N",
            "AVSAAV" : "I4",
            "messageType" : "CSTO",
            "responseTransactionID" : "019106692165784",
            "storedCredentialFlag" : "N"
        }
    
}
const pendingTransaction=
    {
        "created_dt" : new Date("2019-04-29T04:55:31.031Z"),
        "created_id" : "ortizcr",
        "updated_dt" : new Date("2019-04-29T04:55:31.031Z"),
        "updated_id" : "ortizcr",
        "iscsr" : true,
        "payment_channel" : "CSR",
        "premium_amount" : 288.77,
        "paid_date" : new Date("2019-04-29T00:00:00.000Z"),
        "fee_amount" : 0.0,
        "transaction_status" : "PENDING",
        "frequency" : "",
        "invoice_number" : "",
        "payment_confirmation_email_address" : "",
        "notification_indicator" : "EMAIL",
        "updated_to_psd" : "N",
        "communication_details" : {
            "email_id" : "CARRIE.ORTIZ@ANTHEM.COM"
        },
        "notes" : [ 
            {
                "csrId" : "ortizcr",
                "note_desc" : "TEST",
                "action" : "submit"
            }
        ],
        "transaction_type" : "PAYMENT",
        "noc_received" : false,
        "anthem_bank_details" : {
            "anthem_deposting_bank" : "chase",
            "business_unit" : "1147430",
            "anthem_bank_account" : "4307",
            "transaction_division" : "355958"
        },
        "check_id" : "PBP_190429"
    };
    const rejectedTransactionStatus={
        "ediaccepted" : {
            "status_code" : "TA",
            "updated_dt" : new Date("2019-04-16T22:05:32.883Z")
        },
        "submitted" : {
            "updated_dt" : new Date("2019-04-16T22:18:43.711Z")
        },
        "rejected" : {
            "status_code" : "100",
            "status_description" : "Invalid purchase level III",
            "updated_dt" : new Date("2019-04-16T22:23:57.520Z")
        }
    };

module.exports.queries = {
    insertTransaction: insertTransaction,
    paymentMethod:paymentMethod,
    pendingTransaction:pendingTransaction,
    rejectedTransactionStatus:rejectedTransactionStatus
};


