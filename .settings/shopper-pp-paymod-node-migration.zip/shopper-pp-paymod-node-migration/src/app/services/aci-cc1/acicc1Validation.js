const fs = require('fs');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");

/* ----- Function to get records from xlsx ----- */
var acicc1Validation = (inputRecord) => {
    
    var isValid = true;
    //var address_pattern=/^\w{0,40}$/i;
    var city_pattern = /^\w{0,20}$/i;
    var state_pattern = /^\w{0,2}$/i;
    var zip_pattern = /^\d{0,9}$/;
    var nickname_pattern = /^\w{0,45}$/i;
    var invalid_message = "";

    if (!inputRecord["hcid"] || String(inputRecord["hcid"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Invalid HCID ";
    }
    /*if (inputRecord["token"]["account_nickname"] && inputRecord["token"]["account_nickname"].length > 0 && !nickname_pattern.test(String(inputRecord["token"]["account_nickname"]).trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Nickname ";
    }*/
    if (!inputRecord["token"]["creditcard"]["expiration_month"] ||  
        String(inputRecord["token"]["creditcard"]["expiration_month"]).trim().length !== 2 || isNaN(inputRecord["token"]["creditcard"]["expiration_month"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Expiration Month ";
    }
    if (!inputRecord["token"]["creditcard"]["expiration_year"] ||  
        String(inputRecord["token"]["creditcard"]["expiration_year"]).trim().length !== 4 || isNaN(inputRecord["token"]["creditcard"]["expiration_year"])) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Expiration Year ";
    }
    if (!inputRecord["token"]["name_on_funding_account"] || String(inputRecord["token"]["name_on_funding_account"]).trim().length === 0) {
        isValid = false;
        invalid_message = invalid_message + "Missing Funding Account Name ";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["address1"].length === 0 || inputRecord["token"]["fund_account_owner_full_address"]["address1"].length >= 40) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Address";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["city"].length === 0 || !city_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["city"]).replace(/ /g, "").trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid City";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["state"].length === 0 || !state_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["state"]).trim())) {
        isValid = false;
        invalid_message = invalid_message + "Invalid State";
    }
    if (inputRecord["token"]["fund_account_owner_full_address"]["zipcode"].length === 0 || !zip_pattern.test(String(inputRecord["token"]["fund_account_owner_full_address"]["zipcode"]).replace("-", ""))) {
        isValid = false;
        invalid_message = invalid_message + "Invalid Zip";
    }
    return { isValid: isValid, msg: invalid_message };
}

module.exports = {
    acicc1Validation: acicc1Validation
};