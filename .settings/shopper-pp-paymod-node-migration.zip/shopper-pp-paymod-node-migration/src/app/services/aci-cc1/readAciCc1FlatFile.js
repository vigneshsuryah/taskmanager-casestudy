const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { acicc1Validation } = require("../aci-cc1/acicc1Validation");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

/* ----- Function to get records from xlsx ----- */
var readAciCc1FlatFile = (filename, lob) => {
    return new Promise((resolve, reject) => {
        readAciCC1File(filename, lob, resolve, reject);
    })  
}

function readAciCC1File(filename, lob, resolve, reject) {

    try {
        var valid_records = [];
        var invalid_records = [];

        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/' + filename)
        });

        let line_no = 0;
        let invalid_count = 0;
        let valid_count = 0;
        let tokenid_array = [];
        var nickname_pattern = /^\w{0,45}$/i;

        rl.on('line', function(line) {
            line_no++;
                var inputRecordSplits = line.split("|");
                if(inputRecordSplits.length !== 12){
                    invalid_records.push(line + ", Invalid Record");
                    invalid_count++;
                } 
                else if(tokenid_array.includes(inputRecordSplits[0])){
                    invalid_records.push(line + ", Duplicate Token Id Record");
                    invalid_count++;
                }
                else {
                    var expiration_month = '0';
                    var expiration_year = '0';
                    var expiration_string = inputRecordSplits[11]
                    if(expiration_string.length === 8 || expiration_string.length === 6){
                        expiration_month = expiration_string.substring(0, 2);
                        expiration_year = expiration_string.substr(expiration_string.length - 4);
                    }
                    var formattedRecord = {};
                    var lobCalc = lob;
                    if(inputRecordSplits[1].trim().length > 9 && lob === 'GBDIN'){
                        lobCalc = 'GOFUNDHIP';
                    }

                    tokenid_array.push(inputRecordSplits[0]);
                    let nickname = inputRecordSplits[4] === 'N/A' ? "" : inputRecordSplits[4];
                    if (nickname && nickname.length > 0 && !nickname_pattern.test(nickname.trim())) {
                        nickname = "";
                    }

                    formattedRecord = {
                    "hcid" : inputRecordSplits[1],
                    "lob" : lobCalc,
                    "token" : {
                            "payment_type" : "CC",
                            "creditcard" : {
                                "expiration_month" : expiration_month,
                                "expiration_year" : expiration_year
                            },
                            "token_id" : inputRecordSplits[0],
                            "name_on_funding_account" : inputRecordSplits[5],
                            "account_nickname" : nickname,
                            "fund_account_owner_full_address" : {
                                "address1" : inputRecordSplits[6],
                                "address2" : inputRecordSplits[7],
                                "city" : inputRecordSplits[8],
                                "state" : inputRecordSplits[9],
                                "zipcode" : inputRecordSplits[10]
                            },
                            "status" : "INACTIVE",
                            "created_dt" : new Date(),
                            "created_id" : "ACIMIGRATED",
                            "updated_dt" : new Date(),
                            "updated_id" : "ACIMIGRATED",
                            "iscsr" : false
                        }
                    }

                    // check the record is valid or not
                    var validationResult = acicc1Validation(formattedRecord);
                    if(validationResult["isValid"]){
                        valid_records.push(formattedRecord);
                        valid_count++;
                    }else{
                        invalid_records.push(line + ", " + validationResult["msg"]);
                        invalid_count++;
                    }
                }
        });

        rl.on('close', function(line) {
            logger.info('Total Valid lines : ' + valid_count);
            logger.info('Total Invalid lines : ' + invalid_count);
            logger.info('Total lines : ' + (line_no));

            // write invalid records
            var writeFlag = writeFileWithRecords(invalid_records, "CC-invalid-records.txt");

            logger.info('Invalid File Write Status : ' + writeFlag);

            resolve(valid_records);
        });
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

module.exports = {
    readAciCc1FlatFile: readAciCc1FlatFile
};




