const fs = require('fs');
const readline = require('readline');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");
var { writeFileWithRecords } = require("../writeFileWithRecords/writeFileWithRecords");

/* ----- Function to get records from xlsx ----- */
var readAciCc3EchoFlatFile = (filename, lob) => {
    return new Promise((resolve, reject) => {
        readAciCc3EchoFlatFile(filename, lob, resolve, reject);
    })  
}

function readAciCc3EchoFlatFile(filename, lob, resolve, reject) {

    try {
        var valid_records = [];
        var invalid_records = [];

        logger.info("Reading records from flat file");
        let rl = readline.createInterface({
            input: fs.createReadStream('./src/files/' + filename)
        });

        let line_no = 0;
        let invalid_count = 0;
        let valid_count = 0;

        rl.on('line', function(line) {
            line_no++;
                var inputRecordSplits = line.split(",");
                if(inputRecordSplits.length !== 12){
                    invalid_records.push(line + ", Invalid Record");
                    invalid_count++;
                } 
                else {
                    var valid_flag = true;
                    var error_msg = "";
                    var formattedRecord = {};

                    if(inputRecordSplits[3] === 'VI'){
                        if(inputRecordSplits[8] === null || inputRecordSplits[8] === undefined || inputRecordSplits[8] === '' || inputRecordSplits[8].length === 0){
                            valid_flag = false;
                        }
                        if(inputRecordSplits[9] === null || inputRecordSplits[9] === undefined || inputRecordSplits[9] === '' || inputRecordSplits[9].length === 0){
                            valid_flag = false;
                        }
                        if(inputRecordSplits[10] === null || inputRecordSplits[10] === undefined || inputRecordSplits[10] === '' || inputRecordSplits[10].length === 0){
                            valid_flag = false;
                        }
                        if(inputRecordSplits[11] === null || inputRecordSplits[11] === undefined || inputRecordSplits[11] === '' || inputRecordSplits[11].length === 0){
                            valid_flag = false;
                        }
                        formattedRecord = {
                            "hcid" : inputRecordSplits[6],
                            "pods_token" : inputRecordSplits[5],
                            "is_level3" : inputRecordSplits[8],
                            "AVSAAV" : inputRecordSplits[11],
                            "cc_authorization_number" : inputRecordSplits[10],
                            "response_transaction_id" : inputRecordSplits[9]
                        }
                    }else if(inputRecordSplits[3] === 'MC'){
                        if(inputRecordSplits[8] === null || inputRecordSplits[8] === undefined || inputRecordSplits[8] === '' || inputRecordSplits[8].length === 0){
                            valid_flag = false;
                        }
                        if(inputRecordSplits[10] === null || inputRecordSplits[10] === undefined || inputRecordSplits[10] === '' || inputRecordSplits[10].length === 0){
                            valid_flag = false;
                        }
                        if(inputRecordSplits[11] === null || inputRecordSplits[11] === undefined || inputRecordSplits[11] === '' || inputRecordSplits[11].length === 0){
                            valid_flag = false;
                        }
                        formattedRecord = {
                            "hcid" : inputRecordSplits[6],
                            "pods_token" : inputRecordSplits[5],
                            "is_level3" : inputRecordSplits[8],
                            "AVSAAV" : inputRecordSplits[11],
                            "cc_authorization_number" : inputRecordSplits[10]
                        }
                    }
                    
                    if(valid_flag){
                        valid_records.push(formattedRecord);
                        valid_count++;
                    }else{
                        invalid_records.push(line + error_msg);
                        invalid_count++;
                    }
                }
        });

        rl.on('close', function(line) {
            logger.info('Total Valid lines : ' + valid_count);
            logger.info('Total Invalid lines : ' + invalid_count);
            logger.info('Total lines : ' + (line_no));

            // write invalid records
            var writeFlag = writeFileWithRecords(invalid_records,"CC3-echo-invalid-records.txt");

            logger.info('Invalid File Write Status : ' + writeFlag);

            resolve(valid_records);
        });
    } catch (e) {
        logger.info("Error", e);
        logger.info(e);
        reject(e);
    }
}

module.exports = {
    readAciCc3EchoFlatFile: readAciCc3EchoFlatFile
};