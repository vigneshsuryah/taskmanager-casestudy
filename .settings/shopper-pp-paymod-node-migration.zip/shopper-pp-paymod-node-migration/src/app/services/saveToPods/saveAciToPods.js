const mongoose = require("mongoose");
const fs = require('fs');
const environment = process.argv[2];
const uuidv4 = require('uuid/v4');
const configurations = require("../../../configuration/config")[environment];
const logger = require('logger').createLogger("./output/aci-migration.log");
const paymentMethodsSchema = require('../../persistance/models/paymentMethodsSchema');
const aciAuditSchema = require('../../persistance/models/aciAuditSchema');
var paymentsWalletModel = mongoose.model('payment_wallet', new mongoose.Schema(paymentMethodsSchema, {
    collection: 'payment_wallet',
    versionKey: false,
    _id: false
}));
var aciAuditModel = mongoose.model('audit_aci_tokenid', new mongoose.Schema(aciAuditSchema, {
    collection: 'audit_aci_tokenid',
    versionKey: false,
    _id: false
}));

var ca = fs.readFileSync(configurations.mongo_cert_path);

var saveAciToPods = (input, lob, type) => {

    return new Promise((resolve, reject) => {

        persistToDB(input, lob, type, resolve, reject);

    })

}

function persistToDB(input, lob, type, resolve, reject) {


    mongoose.connect(configurations.mongo_url, {
        user: configurations.mongo_user,
        pass: configurations.mongo_password,
        sslCA: ca,
        useNewUrlParser: true
    });


    const db = mongoose.connection;
    mongoose.set('useFindAndModify', false);

    db.once("open", function(callback) {
        logger.info("Connection succeeded.");
    });

    db.on('error', () => {
        logger.error('MongoDB connection error');
        reject("Mongoose connection error");
    });

    if(type === 'ACH' || type === 'CC'){
        const aciInsert = async () => {
            logger.info('before iterating all valid records');
            for (var item of input) {
              logger.info('#################################### inside hcid : ' + item.hcid);
              var aci_token = item.token.token_id;
              var pods_token = uuidv4().replace(/-/g, "");
              item.token.token_id = pods_token;
              var auditRecord = {
                "hcid": item.hcid, 
                "lob": item.lob,
                "aci_token": aci_token,
                "pods_token": pods_token,
                "payment_type" : type,
                "status" : type === 'CC' ? "INACTIVE" : "ACTIVE"
              }
              const wallet_document = await getWalletDetailsForHcid(item);
              
              if(null === wallet_document){
                const insert_data = await insertNewDocumentForHcid(item);
                logger.info('after the insert');
                if(null !== insert_data){
                    logger.info('before the insert of audit record');
                    const auditinsertflag = await auditInsertMethod(auditRecord);
                    if(auditinsertflag){
                    logger.info(auditRecord.hcid + " audit aci tokenid inserted ******");
                    }
                }
              }else{
                const update_data = await updateExistingDocumentForHcid(item);
                logger.info('after the update');
                if(null !== update_data){
                    logger.info('before the update of audit record');
                      const auditinsertflag = await auditInsertMethod(auditRecord);
                      if(auditinsertflag){
                        logger.info(auditRecord.hcid + " audit aci tokenid inserted ******");
                      }
                  }
              }
            }
            logger.info('after iterating all valid records');
        };
        aciInsert().then(() =>{
            logger.info('DB operations done for data');
            db.close((error) => {
                logger.error("Error closing DB connection");
            });
            resolve(true);
        });
    } else if(type === 'CC2'){
        const aciUpdate = async () => {
            logger.info('before iterating all valid records of cc2 file');
            for (var item of input) {
              logger.info('#################################### inside token id : ' + item.token_id);

              const audit_document = await getAuditDocumentForHCIDTokenId(lob, item.token_id);
              
              if(null !== audit_document){
                const update_data = await updateCCDocumentWithTokenId(audit_document.hcid, audit_document.pods_token, item.credit_card_number, item.payment_sub_type, audit_document.lob, item.credit_card_first_six, item.credit_card_last_four)
                //logger.info('after the update of cc record : ' + JSON.stringify(update_data));
              }else{
                logger.info('audit document null for token id : ' + item.token_id);
              }
            }
            logger.info('after iterating all valid records of cc2 file');
        };
        aciUpdate().then(() =>{
            logger.info('DB operations done for data of cc2 file');
            db.close((error) => {
                logger.error("Error closing DB connection");
            });
            resolve(true);
        });
    } 
    else if(type === 'CC3GENERATE'){
        var audit_records = [];
        var cc_all_documents = [];
        var pods_tokens = [];
        const auditRecordsAll = async () => {
            logger.info('before getting cc records of audit for a lob');
            audit_records = await getAuditRecordsForLobForCC(lob);
            for (var item of audit_records) {
                pods_tokens.push(item.pods_token);
            }
            cc_all_documents = await getWalletDetailsForPodsTokens(pods_tokens);
            logger.info('after getting cc records of audit for a lob');
        };
        auditRecordsAll().then(() =>{
            logger.info('DB get operations done for CC3GENERATE records');
            db.close((error) => {
                logger.error("Error closing DB connection");
            });
            resolve(cc_all_documents);
        });
    }
    else if(type === 'CC3ECHO'){
        const aciUpdate = async () => {
            logger.info('before iterating all valid records of cc3 echo file');
            for (var item of input) {
              logger.info('#################################### inside token id : ' + item.token_id);
              
              const update_data = await updateCC3EchoDocumentWithTokenId(item.hcid, item.pods_token, lob, item.is_level3, item.AVSAAV, item.cc_authorization_number, item.response_transaction_id);
              const update_audit = await updateCC3EchoAuditDocumentWithPods(pods_token);
              
              logger.info('#################################### updated for token id : ' + item.token_id + ' --> ' + update_data + ' --> ' + update_audit);
            }
            logger.info('after iterating all valid records of cc3 echo file');
        };
        aciUpdate().then(() =>{
            logger.info('DB operations done for data of cc3 echo file');
            db.close((error) => {
                logger.error("Error closing DB connection");
            });
            resolve(true);
        });
    }
    else if(type === 'AUDIT'){
        var audit_records = [];
        const auditRecordsAll = async () => {
            logger.info('before getting all the records of audit for a lob');
            audit_records = await getAuditRecordsForLob(lob);
            logger.info('after getting all the records of audit for a lob');
        };
        auditRecordsAll().then(() =>{
            logger.info('DB get operations done for audit records');
            db.close((error) => {
                logger.error("Error closing DB connection");
            });
            resolve(audit_records);
        });
    } else{
        reject(false);
    }
}

function getAuditRecordsForLobForCC(lob){
    return new Promise(function(resolve_audit_get, reject_audit_get) {
        var query = null;
        if(lob === 'GBDIN'){
            query = { "lob": { $in: ['GBDIN', 'GOFUNDHIP']}, "payment_type" : "CC", "status" : "INACTIVE" };
        }else{
            query = { "lob": lob, "payment_type" : "CC", "status" : "INACTIVE" };
        }
        
        logger.info('getAuditRecordsForLobForCC : ' + JSON.stringify(query));
        aciAuditModel.find(query, function(err, audit_records_data) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_audit_get(err);
            }else{
                resolve_audit_get(audit_records_data);
            }
        });
    })
}

function getWalletDetailsForPodsTokens(list){
    return new Promise(function(resolve_get, reject_get) {
        var query = { "tokens.tokenid": { $in: list } };
        logger.info('getWalletDetailsForPodsTokens : ' + JSON.stringify(query));
        paymentsWalletModel.find(query, function(err, wallet_info) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_get(err);
            }else{
                resolve_get(wallet_info);
            }
        });
    })
}

function getAuditRecordsForLob(lob){
    return new Promise(function(resolve_audit_get, reject_audit_get) {
        var query = null;
        if(lob === 'GBDIN'){
            query = { "lob": { $in: ['GBDIN', 'GOFUNDHIP']} , "status" : "ACTIVE" };
        }else{
            query = { "lob": lob , "status" : "ACTIVE" };
        }
        
        logger.info('getAuditRecordsForLob : ' + JSON.stringify(query));
        aciAuditModel.find(query, function(err, audit_records_data) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_audit_get(err);
            }else{
                resolve_audit_get(audit_records_data);
            }
        });
    })
}

function getWalletDetailsForHcid(item){
    return new Promise(function(resolve_get, reject_get) {
        var query = { "hcid": item.hcid, "lob": item.lob };
        logger.info('getWalletDetailsForHcid : ' + query.hcid);
        paymentsWalletModel.findOne(query, function(err, wallet_info) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_get(err);
            }else{
                resolve_get(wallet_info);
            }
        });
    })
}

function insertNewDocumentForHcid(item){
    return new Promise(function(resolve_insert, reject_insert) {
        logger.info('new item : ' + JSON.stringify(item.hcid));
        var temp_insert_document = {};
        temp_insert_document.hcid = item.hcid;
        temp_insert_document.lob = item.lob;
        var tokens = [];
        tokens.push(item.token);
        temp_insert_document.tokens = tokens;
        paymentsWalletModel.insertMany(temp_insert_document, (err, data) => {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_insert(err);
            } else {
                logger.info(item.hcid + " payment method inserted ****** ");
                resolve_insert(data);
            }
        });
    })
}

function updateExistingDocumentForHcid(item){
    return new Promise(function(resolve_update, reject_update) {
        logger.info('addition item : ' + JSON.stringify(item.hcid));
        var query = { "hcid": item.hcid, "lob": item.lob };
        var update = {
            $push: {tokens: item.token}
        }
        var options = {upsert: true};
        paymentsWalletModel.findOneAndUpdate(query, update, options, function (err, data) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_update(err);
            }else{
                logger.info(item.hcid + " payment method updated ****** ");
                resolve_update(data);
            }
        });
    })
}

function auditInsertMethod(record){
    return new Promise(function(resolve_audit, reject_audit) {
        logger.info('audit record insert : ' + JSON.stringify(record.hcid));
        aciAuditModel.insertMany(record, (err, data) => {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_audit(err);
            } else {
                resolve_audit(data);
            }
        });
    })
}

function getAuditDocumentForHCIDTokenId(lob, aci_token){
    return new Promise(function(resolve_get_hcid, reject_get_hcid) {
        var query = null;
        if(lob === 'GBDIN'){
            query = { "aci_token": aci_token, "lob": { $in: ['GBDIN', 'GOFUNDHIP']}};
        }else{
            query = { "aci_token": aci_token, "lob": lob };
        }
        logger.info('getAuditDocumentForHCIDTokenId : ' + JSON.stringify(query));
        aciAuditModel.findOne(query, function(err, audit_info) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_get_hcid(err);
            }else{
                resolve_get_hcid(audit_info);
            }
        });
    })
}

function updateCCDocumentWithTokenId(hcid, pods_token, ccno, payment_sub_type, lob, fsix, lfour){
    return new Promise(function(resolve_update_cc, reject_update_cc) {
        logger.info('updateCCDocumentWithTokenId hcid, new token id : ' + hcid + " , " + pods_token);
        var query = { "hcid": hcid, "lob": lob, "tokens.token_id": pods_token };
        var update = {
            "$set": {
                "tokens.$.payment_sub_type": payment_sub_type,
                "tokens.$.status": "INACTIVE",
                "tokens.$.creditcard.credit_card_number": ccno,
                "tokens.$.creditcard.credit_card_first_six": fsix,
                "tokens.$.creditcard.credit_card_last_four": lfour
            }
        }
        var options = {upsert: true};
        paymentsWalletModel.findOneAndUpdate(query, update, options, function (err, data) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_update_cc(err);
            }else{
                logger.info(hcid + " cc payment method updated with cc no ****** ");
                resolve_update_cc(data);
            }
        });
    })
}


function updateCC3EchoDocumentWithTokenId(hcid, pods_token, lob, is_level3, AVSAAV, cc_authorization_number, response_transaction_id){
    return new Promise(function(resolve_update_cc, reject_update_cc) {
        logger.info('updateCC3EchoDocumentWithTokenId hcid, new token id : ' + hcid + " , " + pods_token);
        var query = { "hcid": hcid, "lob": lob, "tokens.token_id": pods_token };
        var update = {
            "$set": {
                "tokens.$.status": "ACTIVE",
                "tokens.$.is_level3": is_level3,
                "tokens.$.AVSAAV": AVSAAV,
                "tokens.$.cc_authorization_number": cc_authorization_number,
                "tokens.$.response_transaction_id": response_transaction_id
            }
        }

        var query_audit = { "pods_token" : pods_token };
        var update_audit = {
            "$set": {
                "status": "ACTIVE"
            }
        }

        var options = {upsert: true};
        paymentsWalletModel.findOneAndUpdate(query, update, options, function (err, data) {
            if (err) {
                logger.info(err);
                logger.error(err);
                reject_update_cc(err);
            }else{
                logger.info(hcid + " cc payment method updated with cc 3 echo details no ****** ");
                aciAuditModel.findOneAndUpdate(query_audit, update_audit, options, function (err_audit, data_audit) {
                    if (err_audit) {
                        logger.info(err_audit);
                        logger.error(err_audit);
                        reject_update_cc(err_audit);
                    }else{
                        logger.info(hcid + " cc payment method updated with cc 3 echo details no ****** ");
                        resolve_update_cc(data);
                    }
                });
                resolve_update_cc(data);
            }
        });
    })
}

function updateCC3EchoAuditDocumentWithPods(pods_token){
    return new Promise(function(resolve_update_cc, reject_update_cc) {
        logger.info('updateCC3EchoAuditDocumentWithPods pods_token : ' + pods_token);

        var query_audit = { "pods_token" : pods_token };
        var update_audit = {
            "$set": {
                "status": "ACTIVE"
            }
        }

        var options = {upsert: true};
        aciAuditModel.findOneAndUpdate(query_audit, update_audit, options, function (err_audit, data_audit) {
            if (err_audit) {
                logger.info(err_audit);
                logger.error(err_audit);
                reject_update_cc(err_audit);
            }else{
                logger.info(pods_token + " cc payment method audit status update ****** ");
                resolve_update_cc(data_audit);
            }
        });
    })
}


module.exports = {
    saveAciToPods: saveAciToPods
};




