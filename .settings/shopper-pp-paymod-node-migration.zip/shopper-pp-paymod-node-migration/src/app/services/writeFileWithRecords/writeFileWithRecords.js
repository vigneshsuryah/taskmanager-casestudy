const fs = require('fs');
const _ = require("underscore");
const logger = require('logger').createLogger("./output/aci-migration.log");

var writeFileWithRecords = (data, filename) => {
    
    var fs = require('fs');

    try{

        var file = fs.createWriteStream('./output/' + filename);
        
        file.on('error', function(err) {
            logger.error('Invalid Record file error');
            return false;
        });

        data.forEach(function(linecontent) {
            file.write(linecontent + '\n'); 
        });

        file.end();
        return true;

    } catch (e) {
        logger.error("Error", e);
        logger.error(e);
        return false;
    }

    
}

module.exports = {
    writeFileWithRecords: writeFileWithRecords
};