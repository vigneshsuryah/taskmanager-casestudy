const services = require("../../services");
const logger = require('logger').createLogger("./output/aci-migration.log");
const createError = require('http-errors');
var acicc3GenerateMigrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        generateFileForLob(payload, res, next);
    }

}

function generateFileForLob(payload, res, next) {

    try {
        logger.info("File generation process started..");
        services.saveAciToPods({}, payload["lob"], 'CC3GENERATE').then((response) => {
            logger.info("after fetching the payment method documents to generate file");
            var fileName = payload["lob"] + '-820-cc3-file-to-edi.txt';
            services.cc3RecordsWrite(response, fileName).then((flag) => {
                logger.info("after writing the output file with records : " + JSON.stringify(flag));
                logger.info('File generation process completed..');
                res.send({ success: true, message: "File generation process completed" });
            }).catch((error) => {
                logger.error(error);
                next(error);
            })
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = acicc3GenerateMigrationController;