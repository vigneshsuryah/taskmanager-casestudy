const services = require("../../services");
const logger = require('logger').createLogger("./output/aci-migration.log");
const createError = require('http-errors');
var acicc3EchoMigrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field filename"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        startACICC3Migration(payload, res, next);
    }

}

function startACICC3Migration(payload, res, next) {

    try {
        logger.info("Migration process started..");
        services.readAciCc3EchoFlatFile(payload["filename"], payload["lob"], next).then((inputData) => {
            logger.info("reading ach cc 3 echo file, validation and updating the wallet records completed");
            services.saveAciToPods(inputData, payload["lob"], 'CC3ECHO').then((response) => {
                logger.info("updating cc aci payment methods with aditional information is completed");
                logger.info('Migration process completed..');
                res.send({ success: true, message: "Migration process completed" });
            }).catch((error) => {
                logger.error(error);
                next(error);
            })
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = acicc3EchoMigrationController;