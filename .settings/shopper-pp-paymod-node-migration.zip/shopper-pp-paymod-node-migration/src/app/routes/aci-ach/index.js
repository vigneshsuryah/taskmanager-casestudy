const services = require("../../services");
const logger = require('logger').createLogger("./output/aci-migration.log");
const createError = require('http-errors');
var aciachmigrationController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field filename"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        startACIACHMigration(payload, res, next);
    }

}

function startACIACHMigration(payload, res, next) {

    try {
        logger.info("Migration process started..");
        services.readAciAchFlatFile(payload["filename"], payload["lob"], next).then((inputData) => {
            logger.info("reading ach aci payment methods, validation and writing invalid records completed");
            services.saveAciToPods(inputData, payload["lob"], 'ACH').then((response) => {
                logger.info("storing ach aci payment methods, audit records completed");
                logger.info('Migration process completed..');
                res.send({ success: true, message: "Migration process completed" });
            }).catch((error) => {
                logger.error(error);
                next(error);
            })
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = aciachmigrationController;