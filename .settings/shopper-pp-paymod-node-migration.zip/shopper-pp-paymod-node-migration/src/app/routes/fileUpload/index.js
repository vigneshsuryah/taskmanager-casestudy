var uploadController = (req, res, next) => {
    res.send({ "msg": "File received" });
}

module.exports = uploadController;