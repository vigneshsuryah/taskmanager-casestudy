
var versionController = (req, res, next) => {
    res.send({
        verison: "paymod-migration-service-v2.0"
    });
}

module.exports = versionController;