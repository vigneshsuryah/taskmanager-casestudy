const services = require("../../services");
const logger = require('logger').createLogger("./output/aci-migration.log");
const createError = require('http-errors');
var auditRecordsPopulateController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("lob")) {
        next(createError(400, "Missing mandatory field lob"));
    } else {
        generateFileForLob(payload, res, next);
    }

}

function generateFileForLob(payload, res, next) {

    try {
        logger.info("File generation process started..");
        services.saveAciToPods({}, payload["lob"], 'AUDIT').then((response) => {
            logger.info("after fetching the audit collection records to generate file");
            var fileName = payload["lob"] + '-output-tokenids-file.txt';
            services.auditRecordsWrite(response, fileName).then((flag) => {
                logger.info("after writing the output file with records : " + JSON.stringify(flag));
                logger.info('File generation process completed..');
                res.send({ success: true, message: "File generation process completed" });
            }).catch((error) => {
                logger.error(error);
                next(error);
            })
        }).catch((error) => {
            logger.error(error);
            next(error);
        });
    } catch (e) {
        logger.error(e);
    }
    //--------------------------------------------

}

module.exports = auditRecordsPopulateController;