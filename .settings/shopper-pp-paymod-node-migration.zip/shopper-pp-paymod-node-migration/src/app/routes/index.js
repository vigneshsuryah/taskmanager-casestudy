var express = require('express');
var router = express.Router();
const logger = require('logger').createLogger("/apps/node/eox/wgs-migration/logs/paymod-migration-service.log");
const versionController = require("./version");
const migrationController = require("./migration");
const aciachmigrationController = require("./aci-ach");
const acicc1migrationController = require("./aci-cc1");
const acicc2migrationController = require("./aci-cc2");
const acicc3EchoMigrationController = require("./aci-cc3-echo");
const acicc3GenerateMigrationController = require("./aci-cc3-generate");
const auditRecordsPopulateController = require("./audit-records");

const uploadController = require("./fileUpload");
const downloadController = require("./fileDownload");
var multer = require('multer');

try {
    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, './src/files/');
        },
        filename: function (req, file, cb) {
            cb(null, file.originalname)
        }
    });
    var upload = multer({
        storage: storage
    });
    var uploadmulter = upload.single('file');

    router.get('/getVersion', versionController);
    router.post('/wgsMigration', migrationController);
    router.post('/aciachMigration', aciachmigrationController);
    router.post('/acicc1Migration', acicc1migrationController);
    router.post('/acicc2Migration', acicc2migrationController);
    router.post('/acicc3GenerateMigration', acicc3GenerateMigrationController);
    router.post('/acicc3EchoMigration', acicc3EchoMigrationController);
    router.post('/generateOutputFileForLob', auditRecordsPopulateController);
    router.post('/upload', uploadmulter, uploadController);
    router.post('/download', downloadController);

} catch (err) {
    logger.error(err);
    throw new Error("Error in routing");
}
module.exports = router;