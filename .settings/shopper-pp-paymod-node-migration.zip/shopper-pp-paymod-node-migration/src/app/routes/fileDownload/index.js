var path = require('path');
var mime = require('mime');
var fs = require('fs');
const logger = require('logger').createLogger("./output/aci-migration.log");
const createError = require('http-errors');
var downloadController = (req, res, next) => {

    const payload = req["body"];

    if (Object.keys(payload).length == 0) {
        next(createError(400, "Missing payload"));
    } else if (!payload.hasOwnProperty("filename")) {
        next(createError(400, "Missing mandatory field filename"));
    } else {
        var file = './output/' + payload["filename"];
        
        var filename = path.basename(file);
        var mimetype = mime.lookup(file);
        
        res.setHeader('Content-disposition', 'attachment; filename=' + filename);
        res.setHeader('Content-type', mimetype);
        
        var filestream = fs.createReadStream(file);
        filestream.pipe(res);
    }

}

module.exports = downloadController;