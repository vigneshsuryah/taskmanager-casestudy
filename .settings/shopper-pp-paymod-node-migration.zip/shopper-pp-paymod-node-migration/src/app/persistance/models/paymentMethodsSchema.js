const paymentMethodsSchema = {
    "hcid": String,
    "lob": String,
    "tokens": [{
        _id: false,
        "payment_type": String,
        "payment_sub_type": String,
        "bankaccount": {
            "bank_routing_number": String,
            "bank_account_number": String,
        },
        "creditcard" : {
            "credit_card_number" : String,
            "expiration_month" : String,
            "expiration_year" : String,
            "credit_card_first_six" : String,
            "credit_card_last_four" : String,
            "integrity_check" : String,
            "key_id" : String,
            "phase_id" : String,
            "credit_card_number_ui" : String,
            "action_code" : String,
            "response_reason_code" : String,
            "token_response_date" : String,
            "cc_authorization_number" : String,
            "interchange_qualification_code" : String         
        },
        "token_id": String,
        "name_on_funding_account": String,
        "account_nickname": String,
        "fund_account_owner_full_address": {
            "address1": String,
            "address2": String,
            "city": String,
            "state": String,
            "zipcode": String
        },
        "status": String,
        "created_dt": Date,
        "updated_dt": Date,
        "created_id": String,
        "updated_id": String,
        "iscsr": Boolean
    }]
}

module.exports = paymentMethodsSchema;