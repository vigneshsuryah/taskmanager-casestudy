const aciAuditSchema = {
    "hcid": String,
    "lob": String,
    "aci_token": String,
    "pods_token": String,
    "payment_type" : String
}

module.exports = aciAuditSchema;