package com.anthem.payment.paymod.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Token {

	private String paymentType;
	
	private String paymentSubType;

	private CreditCard creditCard;

	private BankAccount bankAccount;

	private String tokenId;

	private String nameOnFundingAcc;

	private String accNickName;

	private FundAccountOwnerFullAddress fundAccOwnerFullAddress;

	private String status;

	private Date createdDt;

	private String createdId;

	private Date updatedDt;

	private String updatedId;
	
	private boolean isCsr;

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentSubType() {
		return paymentSubType;
	}

	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public BankAccount getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getNameOnFundingAcc() {
		return nameOnFundingAcc;
	}

	public void setNameOnFundingAcc(String nameOnFundingAcc) {
		this.nameOnFundingAcc = nameOnFundingAcc;
	}

	public String getAccNickName() {
		return accNickName;
	}

	public void setAccNickName(String accNickName) {
		this.accNickName = accNickName;
	}

	public FundAccountOwnerFullAddress getFundAccOwnerFullAddress() {
		return fundAccOwnerFullAddress;
	}

	public void setFundAccOwnerFullAddress(FundAccountOwnerFullAddress fundAccOwnerFullAddress) {
		this.fundAccOwnerFullAddress = fundAccOwnerFullAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedId() {
		return createdId;
	}

	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

	public boolean isCsr() {
		return isCsr;
	}

	public void setCsr(boolean isCsr) {
		this.isCsr = isCsr;
	}

}
