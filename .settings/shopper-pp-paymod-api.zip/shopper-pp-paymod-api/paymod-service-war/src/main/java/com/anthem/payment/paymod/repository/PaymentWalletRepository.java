package com.anthem.payment.paymod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.payment.paymod.entity.PaymentWallet;

@Repository
public interface PaymentWalletRepository extends MongoRepository<PaymentWallet, String>{
	
	@Query(value = "{'hcid' : ?0, 'lob' : ?1}")
	PaymentWallet getPaymentWalletByHcidLob(String hcid, String lob);
	
	@Query(value = "{'hcid' : ?0, 'lob' : ?1,  'tokens.tokenId' : ?2}")
	PaymentWallet getPaymentWalletWithTokenID(String hcid, String lob, String tokenId);
}
