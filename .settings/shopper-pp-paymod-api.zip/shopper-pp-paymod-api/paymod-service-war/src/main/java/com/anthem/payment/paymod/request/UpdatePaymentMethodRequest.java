package com.anthem.payment.paymod.request;

import java.io.Serializable;

import com.anthem.payment.paymod.model.Token;

public class UpdatePaymentMethodRequest extends BaseRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String hcid;
	
	private String lob;
	
	private String action;

	private Token token;
	
	private String transactionDivisionCode;
	
	private String acn;
	
	private String thirdPartyId;

	/**
	 * @return the hcid
	 */
	public String getHcid() {
		return hcid;
	}

	/**
	 * @param hcid the hcid to set
	 */
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the token
	 */
	public Token getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(Token token) {
		this.token = token;
	}

	/**
	 * @return the transactionDivisionCode
	 */
	public String getTransactionDivisionCode() {
		return transactionDivisionCode;
	}

	/**
	 * @param transactionDivisionCode the transactionDivisionCode to set
	 */
	public void setTransactionDivisionCode(String transactionDivisionCode) {
		this.transactionDivisionCode = transactionDivisionCode;
	}

	/**
	 * @return the acn
	 */
	public String getAcn() {
		return acn;
	}

	/**
	 * @param acn the acn to set
	 */
	public void setAcn(String acn) {
		this.acn = acn;
	}

	/**
	 * @return the thirdPartyId
	 */
	public String getThirdPartyId() {
		return thirdPartyId;
	}

	/**
	 * @param thirdPartyId the thirdPartyId to set
	 */
	public void setThirdPartyId(String thirdPartyId) {
		this.thirdPartyId = thirdPartyId;
	}
	
}
