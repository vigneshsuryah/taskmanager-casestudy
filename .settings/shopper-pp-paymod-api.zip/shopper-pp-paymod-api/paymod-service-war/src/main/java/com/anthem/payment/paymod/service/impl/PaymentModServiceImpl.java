package com.anthem.payment.paymod.service.impl;


import com.anthem.payment.paymod.entity.*;

import com.anthem.payment.paymod.handler.PaymentModException;
import com.anthem.payment.paymod.model.PaymentDetailsVO;
import com.anthem.payment.paymod.repository.PaymentDetailsRepository;
import com.anthem.payment.paymod.repository.PaymentWalletRepository;
import com.anthem.payment.paymod.repository.TransactionDivisionRepository;

import com.anthem.payment.paymod.request.*;

import com.anthem.payment.paymod.response.CancelPaymentResponse;
import com.anthem.payment.paymod.response.GetPaymentMethodResponse;
import com.anthem.payment.paymod.response.GetTokenResponse;
import com.anthem.payment.paymod.response.RefundPaymentResponse;
import com.anthem.payment.paymod.response.SearchPaymentResponse;
import com.anthem.payment.paymod.response.SearchRefundResponse;
import com.anthem.payment.paymod.response.SubmitPaymentResponse;
import com.anthem.payment.paymod.response.UpdatePaymentMethodResponse;
import com.anthem.payment.paymod.service.PaymentModService;
import com.anthem.payment.paymod.util.PaymentModConstants;
import com.anthem.payment.paymod.util.PaymentModUtil;
import com.google.gson.Gson;
import com.jpmc.cms.sdk.configurator.ConfiguratorException;
import com.jpmc.cms.sdk.framework.Dispatcher;
import com.jpmc.cms.sdk.framework.SLM.NewTransaction;
import com.jpmc.cms.sdk.framework.SLMResp;
import com.jpmc.cms.sdk.framework.SLMResp.Online.TokenIDResponse;
import com.jpmc.cms.sdk.framework.exceptions.RequestException;
import com.jpmc.cms.sdk.framework.interfaces.DispatcherIF;
import com.jpmc.cms.sdk.framework.interfaces.RequestIF;
import com.jpmc.cms.sdk.framework.interfaces.ResponseIF;
import com.mongodb.WriteResult;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

@Service
public class PaymentModServiceImpl implements PaymentModService, PaymentModConstants {

	private final static Logger LOGGER = LoggerFactory.getLogger(PaymentModServiceImpl.class);

	@Value("${paymod.chase.sdk.config.username}")
	private String config_userName;

	@Value("${paymod.chase.sdk.config.userpwd}")
	private String config_userPassword;

	@Value("${paymod.chase.sdk.config.proxyusername}")
	private String config_proxyUserName;

	@Value("${paymod.chase.sdk.config.proxyuserpwd}")
	private String config_ProxyUserPassword;

	@Value("${paymod.chase.sdk.config.MSDK.currencyCode}")
	private String currencyCode;

    @Value("${paymod.chase.sdk.config.MSDK.transactionType}")
    private String transactionType;

    @Value("${paymod.chase.sdk.config.MSDK.actionCode}")
    private String actionCode;

    @Value("${paymod.chase.sdk.config.MSDK.subscriberID}")
    private String subscriberID;

    @Value("${paymod.chase.sdk.config.MSDK.cardSecurityPresence}")
    private String cardSecurityPresence;

    @Value("${paymod.chase.sdk.config.MSDK.divisionNumber}")
    private String divisionNumber;

    @Value("${paymod.chase.sdk.config.MSDK.formatID}")
    private String formatID;

    @Value("${paymod.chase.sdk.config.MSDK.encryptionFlag}")
    private String encryptionFlag;
    
    @Value("${paymod.chase.sdk.config.MSDK.merchantOrderNumber}")
    private String merchantOrderNumber;
    
    @Value("${paymod.setting.payment.ui.restconsumer.service.allowed.lob}")
    private String allowedLobList;

	@Autowired
	private DozerBeanMapper dozerMapper;
	
	@Autowired
	private PaymentModUtil paymentModUtil;
	
	/*@Autowired
    private MessageSource messageSource;*/
	
	@Autowired
	private PaymentDetailsRepository paymentDetailsRepository;
	
	@Autowired
	private TransactionDivisionRepository transactionDivisionRepository;
	
	@Autowired
	private MongoOperations mongoOperations; 

	@Autowired
	private PaymentWalletRepository paymentWalletRepository;

	@Override
	public GetTokenResponse getTokenInformation(GetTokenRequest getTokenRequest, String action) {

		DispatcherIF dispatcher = null;
		Gson gson = new Gson();
		LOGGER.info("Request details " + gson.toJson(getTokenRequest));
		GetTokenResponse response = new GetTokenResponse();
		response.setEncryptedToken("");
		try {
			dispatcher = new Dispatcher();
			RequestIF request = dispatcher.createRequest("NewTransaction", "HTTPSConnectSLM");
			request = buildIncomingRequest(request, getTokenRequest,action);

			LOGGER.info("Request data from SDK " + request.dumpFieldValues());

			ResponseIF resp = dispatcher.processRequest(request);
			//System.out.println(resp.getFieldArray(TokenIDResponse.TokenID));
			// Check for any conversion error
			if (resp.isConversionError()) {
				LOGGER.error("There is data that the SDK didn't expect. These must have been added after"
						+ resp.getLeftoverData());
			}

			int respCode = resp.getIntField(SLMResp.Online.Response.ResponseReasonCode);
			LOGGER.info("Reponse dumpFieldValues : " + resp.dumpFieldValues());
			LOGGER.info("Reponse dumpFieldIdentifiers : " + resp.dumpFieldIdentifiers());
			LOGGER.info("Reponse dumpMaskedFieldValues : " + resp.dumpMaskedFieldValues());
			
			String acceptCodesStringList = paymentModUtil.getMessageBundleValue("chase.accept.codes.list");
			List<String> acceptCodesList = Arrays.asList(acceptCodesStringList.split(","));
			//PP-16301, PP-16303 - Start
			if("VF".equalsIgnoreCase(action) && respCode == 203){
				response.setEncryptedToken(resp.getField(TokenIDResponse.TokenID));
			}
			//PP-16301, PP-16303 - End
			response.setConvError(resp.isConversionError());
			//if (respCode >= 100 && respCode<=199) {
			if(acceptCodesList.contains(Integer.toString(respCode))) {

			//Chase certification changes
			response.setMessageType(resp.getField(SLMResp.Online.MessageType.MessageType));
			response.setRecordType(resp.getField(SLMResp.Online.MessageType.RecordType));
			response.setOriginalTransactionAmount(resp.getField(SLMResp.Online.MessageType.OriginalTransactionAmount));
			response.setResponseTransactionID(resp.getField(SLMResp.Online.MessageType.ResponseTransactionID));
			response.setStoredCredentialFlag(resp.getField(SLMResp.Online.MessageType.StoredCredentialFlag));
			response.setSubmittedTransactionID(resp.getField(SLMResp.Online.MessageType.SubmittedTransactionID));

				if("AR".equalsIgnoreCase(action)){
					response.setAccountNumber(resp.getField(SLMResp.Online.Response.AccountNumber));
					response.setExpirationDate(resp.getField(SLMResp.Online.Response.ExpirationDate));
					response.setActionCode("AR");
					response.setAvsaav(resp.getField(SLMResp.Online.Response.AVSAAV));
					response.setCavv(resp.getField(SLMResp.Online.Response.CAVV));
					response.setReasonCode(Integer.toString(respCode));
					response.setAuthorizationCode(resp.getField(SLMResp.Online.Response.AuthVerificationCode));
					response.setResponseDate(resp.getField(SLMResp.Online.Response.ResponseDate));
					response.setMOP(resp.getField(SLMResp.Online.Response.MOP));
					response.setRecurringPaymentAdviceCode(resp.getField(SLMResp.Online.Response.RecurringPaymentAdviceCode));
				}

				if("AU".equalsIgnoreCase(action)){
					response.setEncryptedToken(resp.getField(TokenIDResponse.TokenID));
					//PP-15623 changes
					response.setAvsaav(resp.getField(SLMResp.Online.Response.AVSAAV));
					response.setAuthorizationCode(resp.getField(SLMResp.Online.Response.AuthVerificationCode));
					response.setReasonCode(Integer.toString(respCode));
					response.setActionCode(action); //hardcoded has to change the value dynamically
					response.setTokenPaidDate(resp.getField(SLMResp.Online.Response.ResponseDate));
					response.setLevelTInd(resp.getField(SLMResp.Online.CardTypeIndicatorResponse2.Level3Eligible));
				}
				
				if("VF".equalsIgnoreCase(action)){
					response.setEncryptedToken(resp.getField(TokenIDResponse.TokenID));
					response.setAuthorizationCode(resp.getField(SLMResp.Online.Response.AuthVerificationCode));
					response.setReasonCode(Integer.toString(respCode));
					response.setActionCode(action); //hardcoded has to change the value dynamically
					response.setTokenPaidDate(resp.getField(SLMResp.Online.Response.ResponseDate));
				}

			} 

			if(response.getEncryptedToken() == null || response.getEncryptedToken().isEmpty())
			{
				if("AR".equalsIgnoreCase(actionCode) && 100!=respCode){
					String messageString = paymentModUtil.getMessageBundleValue("chase.error.code."+Integer.toString(respCode));
					if(null == messageString || messageString.isEmpty()) {
						LOGGER.debug("\n*********** error code mapping not available for response code " + respCode);
						messageString = paymentModUtil.getMessageBundleValue("chase.error.code.");
					}
					String[] messageStringArray = messageString.split("\\|");
					com.anthem.payment.paymod.response.Exception exceptionDetails = new com.anthem.payment.paymod.response.Exception();
					exceptionDetails.setCode(messageStringArray[0]);
					exceptionDetails.setMessage(messageStringArray[1]);
					response.setExceptionDetails(exceptionDetails);
					LOGGER.info("\n************************Failed to process the request****************************");
				}
			}

			LOGGER.info("Response code =>" + resp.getField(SLMResp.Online.Response.ResponseReasonCode));
			LOGGER.info("Auth verification code =>" + resp.getField(SLMResp.Online.Response.AuthVerificationCode));
			
		} catch (Exception e) {
			/*e.printStackTrace();*/
			String messageString = paymentModUtil.getMessageBundleValue("chase.error.code.");
			String[] messageStringArray = messageString.split("\\|");
			com.anthem.payment.paymod.response.Exception exceptionDetails = new com.anthem.payment.paymod.response.Exception();
			exceptionDetails.setCode(messageStringArray[0]);
			exceptionDetails.setMessage(messageStringArray[1]);
			response.setExceptionDetails(exceptionDetails);
			LOGGER.error("Exception -- while creating Dispatcher request" + e.toString());
		}

		return response;
	}
	
	private RequestIF buildIncomingRequest(RequestIF request, GetTokenRequest getTokenRequest, String action)
			throws RequestException, ConfiguratorException {

		request.getConfig().setField("UserName", config_userName);
		request.getConfig().setField("UserPassword", config_userPassword);
		request.getConfig().setField("ProxyUserName", config_proxyUserName);
		request.getConfig().setField("ProxyUserPassword", config_ProxyUserPassword);

		request.setField(NewTransaction.CurrencyCode, currencyCode);
		request.setField(NewTransaction.TransactionType, transactionType);

		request.setField(NewTransaction.DivisionNumber, getTokenRequest.getDivisionCode());
		request.setField(NewTransaction.MerchantOrderNumber, getTokenRequest.getAnthemOrderId());
        request.setField(NewTransaction.MethodOfPayment, getTokenRequest.getMethodOfPayment());
		request.setField(NewTransaction.AccountNumber, getTokenRequest.getAccountNumber());
		request.setField(NewTransaction.ExpirationDate, getTokenRequest.getExpirationDate());
		request.setField(NewTransaction.Amount, getTokenRequest.getAmount());
		//MessageType request to be passed for both
		request.setField(NewTransaction.MessageType.MessageType,getTokenRequest.getMessageType());
		request.setField(NewTransaction.MessageType.StoredCredentialFlag,getTokenRequest.getStoredCredentialFlag());
		request.setField(NewTransaction.MessageType.OriginalTransactionAmount,"            ");
		if(StringUtils.isNotEmpty(getTokenRequest.getSubmittedTransactionID())){
			request.setField(NewTransaction.MessageType.SubmittedTransactionID, getTokenRequest.getSubmittedTransactionID());
		}

		if("AU".equalsIgnoreCase(action)){
			request.setField(NewTransaction.ActionCode, "AU");
			request.setField(NewTransaction.SafetechPageEncryption.SubscriberID, subscriberID);
			request.setField(NewTransaction.SafetechPageEncryption.FormatID, formatID);
			
			if(null != getTokenRequest.getIntegrityCheck() && null != getTokenRequest.getKeyID() && null != getTokenRequest.getPhaseID()){
				request.setField(NewTransaction.EncryptionFlag, encryptionFlag);
				request.setField(NewTransaction.SafetechPageEncryption.IntegrityCheck, getTokenRequest.getIntegrityCheck());
				request.setField(NewTransaction.SafetechPageEncryption.KeyID, getTokenRequest.getKeyID());
				request.setField(NewTransaction.SafetechPageEncryption.PhaseID, getTokenRequest.getPhaseID());
			} else {
				request.setField(NewTransaction.EncryptionFlag, "203");
			}
			
			request.setField(NewTransaction.PaymentIndicator,"Y");
			//PostalCodeVerification Only, AZ record
			request.setField(NewTransaction.PostalCodeOnlyAddress.PostalCode,getTokenRequest.getPostalCode());

      request.setField(NewTransaction.Fraud.CardSecurityPresence, cardSecurityPresence);
			//BillToAddressVerification, AB record
//			request.setField(NewTransaction.BillToAddress.NameText, getTokenRequest.getCardHolderName());
//			request.setField(NewTransaction.BillToAddress.AddressLine1, getTokenRequest.getAddressLine1());
//			request.setField(NewTransaction.BillToAddress.City, getTokenRequest.getCity());
//			request.setField(NewTransaction.BillToAddress.State, getTokenRequest.getState());
//			request.setField(NewTransaction.BillToAddress.PostalCode, getTokenRequest.getPostalCode());

			//L3 card type indicator
			request.setField(NewTransaction.CardTypeIndicator.FormatVersion,"02");
		} else if("AR".equalsIgnoreCase(action)){
			request.setField(NewTransaction.ActionCode, "AR");
			request.setField(NewTransaction.EncryptionFlag, "204");
			request.setField(NewTransaction.PriorAuthorization.ResponseDate, getTokenRequest.getTokenizedDate());
			request.setField(NewTransaction.PriorAuthorization.AuthorizationCode, getTokenRequest.getResponseCode());
		//PP-16301, PP-16303 - Start
		} else if("VF".equalsIgnoreCase(action)){
			request.setField(NewTransaction.ActionCode, "VF");
			request.setField(NewTransaction.Amount, "0");
			request.setField(NewTransaction.Fraud.CardSecurityPresence, cardSecurityPresence);
			request.setField(NewTransaction.SafetechPageEncryption.SubscriberID, subscriberID);
			request.setField(NewTransaction.SafetechPageEncryption.FormatID, formatID);
			if("203".equalsIgnoreCase(getTokenRequest.getEncryptionFlag())){
				request.setField(NewTransaction.EncryptionFlag, getTokenRequest.getEncryptionFlag());
			}else{
				request.setField(NewTransaction.EncryptionFlag, "201");
				request.setField(NewTransaction.SafetechPageEncryption.IntegrityCheck, getTokenRequest.getIntegrityCheck());
				request.setField(NewTransaction.SafetechPageEncryption.KeyID, getTokenRequest.getKeyID());
				request.setField(NewTransaction.SafetechPageEncryption.PhaseID, getTokenRequest.getPhaseID());
			}

			request.setField(NewTransaction.PostalCodeOnlyAddress.PostalCode, getTokenRequest.getPostalCode());
		}
		//PP-16301, PP-16303 - End
		return request;
	}

	@Override
	public SubmitPaymentResponse submitPayment(SubmitPaymentRequest submitPaymentRequest) throws PaymentModException{
		SubmitPaymentResponse response = new SubmitPaymentResponse();
		try {
			PaymentDetails payDetails = dozerMapper.map(submitPaymentRequest, PaymentDetails.class);
			
			if(null != payDetails && null != payDetails.getTransactions() && payDetails.getTransactions().length > 0){
				String orderId = payDetails.getAnthemOrderId();
				String matchId = submitPaymentRequest.getMatchId();
				paymentDetailsRepository.save(payDetails);
				
				response.setStatus(PAYMENT_STATUS_SUBMITTED);
				response.setOrderId(orderId);
				response.setMatchId(matchId);
				return response;
			}else {
				throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
			}

		} catch (Exception e) {
            throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
	}
	
	@Override
	public CancelPaymentResponse cancelPayment(CancelPaymentRequest cancelPaymentRequest) throws PaymentModException{
		CancelPaymentResponse response = new CancelPaymentResponse();
		boolean isPaymentCancelled = false;
		
		String errorMessage = "This payment has already been canceled or not available to be canceled at this stage.";
		String errorCode = "9175";
		String emailIdAvailable = null;
		try {
				String orderId = cancelPaymentRequest.getOrderId();
				List<PaymentDetails> paymentDetailsByOrderId = paymentDetailsRepository.getPaymentDetailsByOrderId(orderId);
			if (null != paymentDetailsByOrderId && !paymentDetailsByOrderId.isEmpty()) {
					for(PaymentDetails payDetailByOrderId : paymentDetailsByOrderId)
					{
						if(null != payDetailByOrderId.getTransactions() && payDetailByOrderId.getTransactions().length > 0) 
						{
							int count=0;
							for(Transaction transaction : payDetailByOrderId.getTransactions())
							{
								String transactionStatus = transaction.getTransactionStatus();
								String transactionType = transaction.getTransactionType();
								if(null != transactionStatus && null != transactionType && 
										"PAYMENT".equalsIgnoreCase(transactionType) && "PENDING".equalsIgnoreCase(transactionStatus)){
									
									GetTokenResponse getTokenResponse = new GetTokenResponse();
									if(null!=payDetailByOrderId.getPaymentMethod() && "CC".equalsIgnoreCase(payDetailByOrderId.getPaymentMethod().getPaymentType())){
										getTokenResponse = doAuthReversal(payDetailByOrderId, transaction.getPremiumAmount());
										if(null != getTokenResponse.getExceptionDetails()) {
											errorMessage = getTokenResponse.getExceptionDetails().getMessage();
											errorCode = getTokenResponse.getExceptionDetails().getCode();
											throw new PaymentModException(getTokenResponse.getExceptionDetails().getCode(),
													getTokenResponse.getExceptionDetails().getMessage());
										}
									}
									transaction.setTransactionStatus("CANCELLED");
									
									Query query = new Query();
									query.addCriteria(Criteria.where("anthem_orderid").is(orderId));
									
									Update update = new Update();
									update.set("transactions."+count+".transaction_status", transaction.getTransactionStatus());
									
									// update notes for cancel payment from CSR.
									if(null != cancelPaymentRequest.getNotes()) {
										Note cancelNote = dozerMapper.map(cancelPaymentRequest.getNotes(), Note.class);
										if(cancelNote.getCsrId() != null && !cancelNote.getCsrId().isEmpty()) {
											List<Note> notes = transaction.getNotes(); 
											if(null == notes) {
												notes = new ArrayList<Note>();
											}
											notes.add(cancelNote); 
											update.set("transactions."+count+".notes", notes);
										}
									}
									
									// update cancel details node with CSR/member/TPC.
									CancelDetails cancelDetails = new CancelDetails();
									if(cancelPaymentRequest.isCsrFlag()) {
										cancelDetails.setCsr(true);
									}else {
										cancelDetails.setCsr(false);
									}
									cancelDetails.setCancelledBy(cancelPaymentRequest.getCancelledBy());
									cancelDetails.setPaymentChannel(cancelPaymentRequest.getPaymentChannel());
									if(cancelPaymentRequest.getPaymentChannel() != null && cancelPaymentRequest.getPaymentChannel().equalsIgnoreCase("WEB") && 
											(cancelPaymentRequest.getCancelledBy() == null || cancelPaymentRequest.getCancelledBy().isEmpty()) ) {
										cancelDetails.setCancelledBy(payDetailByOrderId.getMemberBillingId());
									}
									
									if(null!=payDetailByOrderId.getPaymentMethod() && "CC".equalsIgnoreCase(payDetailByOrderId.getPaymentMethod().getPaymentType())){
										cancelDetails.setAccountNumber(getTokenResponse.getAccountNumber());
										cancelDetails.setExpirationDate(getTokenResponse.getExpirationDate());
										cancelDetails.setAvsaav(getTokenResponse.getAvsaav());
										cancelDetails.setCardSecurityValue(getTokenResponse.getCardSecurityValue());
										cancelDetails.setCavv(getTokenResponse.getCavv());
										cancelDetails.setMOP(getTokenResponse.getMOP());
										cancelDetails.setPaymentAdviceCode(getTokenResponse.getPaymentAdviceCode());
										cancelDetails.setRecurringPaymentAdviceCode(getTokenResponse.getRecurringPaymentAdviceCode());
										cancelDetails.setResponseDate(getTokenResponse.getResponseDate());
										cancelDetails.setTokenNumber(getTokenResponse.getEncryptedToken());
									}

									if(null != transaction.getNotificationIndicator() && transaction.getNotificationIndicator().equalsIgnoreCase("EMAIL") && null != transaction.getCommunicationDetails()) {
										emailIdAvailable = transaction.getCommunicationDetails().getEmailId();
									}
									
									update.set("transactions."+count+".cancelDetails", cancelDetails);
									mongoOperations.findAndModify(query, update, PaymentDetails.class); 
									isPaymentCancelled = true;
								}
							count++;
							}	
						}
					}
				}else {
					errorMessage = "A payment with this Order ID can not be located in the system.";
					errorCode = "9174";
				}
		} catch (Exception e) {
			isPaymentCancelled = false;
		}
		
		response.setCancelled(isPaymentCancelled);
		response.setEmailId(emailIdAvailable);
		if(!isPaymentCancelled) {
			response.setErrorMessage(errorMessage);
			response.setErrorCode(errorCode);
		}
		return response;
	}

	public static String roundUp(String receivedValue, int digits) {
		Double receivedDoubleValue = Double.parseDouble(receivedValue);
		StringBuffer sb = new StringBuffer();
		sb.append("#");
		if(digits != 0){
			sb.append(".");
			for(int i=0;i<digits;i++){
				sb.append("0");
			}
		}
		DecimalFormat df = new DecimalFormat(sb.toString());
		df.setRoundingMode(RoundingMode.DOWN);
		String formattedValue = df.format(receivedDoubleValue);
		return formattedValue;
	}

	private GetTokenResponse doAuthReversal(PaymentDetails paymentObj, Double amount) {
		GetTokenResponse getTokenResponse = null;

		GetTokenRequest getTokenRequest = new GetTokenRequest();
		PaymentMethod paymentMethod = paymentObj.getPaymentMethod();
		getTokenRequest.setAccountNumber(paymentMethod.getCreditCardNumber());
		getTokenRequest.setTokenizedDate(paymentMethod.getTokenDate());
		getTokenRequest.setResponseCode(paymentMethod.getCcAuthorizationNumber());
		String expDte[] = paymentMethod.getCcExpDate().split("/");
		String expDate = expDte[0]+expDte[1].substring(expDte[1].length()-2, expDte[1].length());
		getTokenRequest.setExpirationDate(expDate);
		getTokenRequest.setAnthemOrderId(paymentObj.getAnthemOrderId());
		String amt = roundUp(amount.toString(),2);
		getTokenRequest.setAmount(amt.replaceAll("\\.",""));
		getTokenRequest.setDivisionCode(paymentObj.getTransactionDivisionCode());
		getTokenRequest.setStoredCredentialFlag(paymentMethod.getStoredCredentialFlag());
		getTokenRequest.setMessageType(paymentMethod.getMessageType());
		String ccType = paymentMethod.getPaymentSubType();
		getTokenRequest.setMethodOfPayment((null != ccType && !ccType.isEmpty() && "VISA".equalsIgnoreCase(ccType)) ? "VI" : ccType);

		getTokenResponse = getTokenInformation(getTokenRequest,"AR");

		return getTokenResponse;
	}

	public static String generateOrderId(String payChannel) {
		String orderId = "";
		try {
			Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
            SecureRandom secureRandom = new SecureRandom();
            String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
            String numbers = "0123456789";
            int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
            int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
            String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
            String shortId = RandomStringUtils.random(7, "0123456789");
            orderId = payChannel + dateFormat.format(date) + randomChar + shortId;
		} catch (Exception e) {
			System.out.println("Exception -- while generateOrderId " + e.toString());
		}
		if(orderId != null && StringUtils.isNotBlank(orderId) && StringUtils.isNotEmpty(orderId)) {
			orderId = orderId.toLowerCase();
		}
		return orderId;
	}
	
	
	@Override
	public MamDetailsBO getTransactionDivision(MamDetailsBO request) throws PaymentModException{
		try {
			List<TransactionDivision> transactionDivisions = transactionDivisionRepository.getTransactionDivision(request.getSystem(), request.getLegalEntity(), request.getMarketSegment());
			MamDetailsBO mamDetailsBO = new MamDetailsBO();
			if(null != transactionDivisions && transactionDivisions.size() > 0){
				TransactionDivision transactionDivision = new TransactionDivision();
				transactionDivision = transactionDivisions.get(0);
				mamDetailsBO.setSystemDescription(transactionDivision.getSystemDescription());
				mamDetailsBO.setLeState(transactionDivision.getLeState());
				mamDetailsBO.setLegalDescription(transactionDivision.getLegalDescription());
				mamDetailsBO.setMarketSegmentDescription(transactionDivision.getMarketSegmentDescription());
				mamDetailsBO.setMarket(transactionDivision.getMarket());
				mamDetailsBO.setBranding(transactionDivision.getBranding());
				mamDetailsBO.setSystem(transactionDivision.getSystemCode());
				mamDetailsBO.setLegalEntity(transactionDivision.getLegalCode());
				mamDetailsBO.setMarketSegment(transactionDivision.getMarketSegment());
				mamDetailsBO.setDivisionCode(transactionDivision.getTransactionDivision());
				mamDetailsBO.setCompanyId(transactionDivision.getCompanyId());
				mamDetailsBO.setBuId(transactionDivision.getBuId());
				mamDetailsBO.setBankAccountLastDigits(transactionDivision.getBankAccountLastDigits());
				return mamDetailsBO;
			}else {
				throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
			}

		} catch (Exception e) {
            throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
	}

  @Override
	public SearchPaymentResponse searchPayment(SearchPaymentRequest searchPaymentRequest) throws PaymentModException {
		SearchPaymentResponse searchPaymentResponse = new SearchPaymentResponse();
		List<PaymentDetailsVO> paymentDetailsVOs = null;
		try {
			List<PaymentDetails> paymentDetails = paymentDetailsRepository.searchPaymentDetails(searchPaymentRequest.getHcid(), searchPaymentRequest.getLob(), searchPaymentRequest.getTransactionStatus(), searchPaymentRequest.getTransactionType());
			if(null != paymentDetails && paymentDetails.size() > 0){
				paymentDetailsVOs = new ArrayList<PaymentDetailsVO>();
				for(PaymentDetails payDet : paymentDetails){
					paymentDetailsVOs.add(dozerMapper.map(payDet, PaymentDetailsVO.class));
				}
			}
		} catch (Exception e) {
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		searchPaymentResponse.setPaymentDetailsVOs(paymentDetailsVOs);
		return searchPaymentResponse;
	}

  	@Override
	public SearchRefundResponse refundSearch(SearchRefundRequest searchRefundRequest) throws PaymentModException {

  		LOGGER.info("PaymentModServiceImpl: Inside refundSearch - start");
  		SearchRefundResponse searchRefundResponse = new SearchRefundResponse();
  		String inputLob = searchRefundRequest.getLob();
  		List<String> allowableLobs = new ArrayList<String>();
  		if(allowedLobList != null && !allowedLobList.isEmpty()) {
			String[] allowedLobArray = allowedLobList.split(",");
			allowableLobs = Arrays.asList(allowedLobArray);
		}
  		
  		if(!inputLob.isEmpty() && allowableLobs.contains(inputLob)){
  			try {
  	  	  		List<PaymentDetailsVO> paymentDetailsVOList = new ArrayList<PaymentDetailsVO>();
  	  	  		List<PaymentDetails> paymentDetailsList = new ArrayList<PaymentDetails>();
  	  	  		
  		  		if(null != searchRefundRequest.getHcid() && !searchRefundRequest.getHcid().isEmpty()){
  		  			
  		  			Query query = new Query();
  		  			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
  		  			Date startDate = null;
  		  			Date endDate = null;
    					try {
    						startDate = simpleDateFormat.parse(searchRefundRequest.getDepositFromDt());
    						endDate = simpleDateFormat.parse(searchRefundRequest.getDepositToDt());
    					} catch (ParseException e) {
    						LOGGER.error("Parse Exception in PaymentModServiceImpl - refundSearch "+e.getMessage());
    					}
    				
    				Date paidStartDate = mongoDateConverter(startDate);
      		  		Date paidEndDate = mongoDateConverter(endDate);
      		  		
					Criteria searchByHcid = Criteria.where("hcid").is(searchRefundRequest.getHcid())
							.and("transactions").elemMatch(Criteria.where("paid_date").gte(paidStartDate).lte(paidEndDate));
					
  		  			query.addCriteria(searchByHcid);
  					paymentDetailsList = mongoOperations.find(query,PaymentDetails.class);
  					
  				} else if (null != searchRefundRequest.getOrderId() && !searchRefundRequest.getOrderId().isEmpty()){
  					paymentDetailsList = paymentDetailsRepository.getPaymentDetailsByOrderId(searchRefundRequest.getOrderId());
  				}
  		  		
  		  		paymentDetailsList = filterTransactions(paymentDetailsList, inputLob, searchRefundRequest.getIsMasked());
  		  		
  		  		if(paymentDetailsList.size()>0){
  					for (PaymentDetails paymentDetails : paymentDetailsList) {
  						if(paymentDetails.getLob().equalsIgnoreCase(searchRefundRequest.getLob())){
  							PaymentDetailsVO payDetailsVO = dozerMapper.map(paymentDetails, PaymentDetailsVO.class);
  	  						paymentDetailsVOList.add(payDetailsVO);
  						} else {
  							throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
  						}
  					}
  				} else {
  					throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
  				}
  		  		searchRefundResponse.setPaymentDetails(paymentDetailsVOList);
  		  		
  	  		}catch (PaymentModException e) {
  	  			LOGGER.error("Exception in PaymentModServiceImpl refundSearch::"+ e.getErrorMessage());
  	            throw new PaymentModException(e.getErrorCode(),e.getErrorMessage());
  			} catch (Exception ex) {
  				LOGGER.error("Exception in PaymentModServiceImpl: Mongo Exception during refund Payment");
  				throw new PaymentModException(PAYMENT_MOD_ERR_9207_MONGO_EXP,PAYMENT_MOD_ERR_9207_MONGO_EXP_DESC);
  			}
  		} else {
  			throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
  		}
  		
  		LOGGER.info("PaymentModServiceImpl: Inside refundSearch - end");
		return searchRefundResponse;
	}
  
	private List<PaymentDetails> filterTransactions(List<PaymentDetails> paymentDetailsList, String inputLob, String isMasked) throws PaymentModException {
		if(paymentDetailsList.size() > 0) {
			List<PaymentDetails> filteredList = new ArrayList<>();
			for(PaymentDetails payment : paymentDetailsList) {
				if(!inputLob.equalsIgnoreCase(payment.getLob())) {
						throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
				}
				for(Transaction transaction : payment.getTransactions()) {
					if (("COMPLETED").equalsIgnoreCase(transaction.getTransactionStatus())
							|| ("RETURNED").equalsIgnoreCase(transaction.getTransactionStatus())) {
						if(null != payment.getPaymentMethod() && payment.getPaymentMethod().getPaymentType().equalsIgnoreCase("ACH") && ("Yes").equalsIgnoreCase(isMasked)){
							String maskedAccNbr = paymentModUtil.maskString(payment.getPaymentMethod().getBankAccountNumber(), 0, payment.getPaymentMethod().getBankAccountNumber().length() - 4, 'X');
							payment.getPaymentMethod().setBankAccountNumber(maskedAccNbr);
						}
						filteredList.add(payment);
					}
				}
			}
			return filteredList;
		} else {
			return paymentDetailsList;
		}
	}

	@Override
	public RefundPaymentResponse refundPayment(RefundPaymentRequest refundPaymentRequest) throws PaymentModException {
		LOGGER.info("PaymentModServiceImpl: Inside refundPayment - start");
		RefundPaymentResponse refundPaymentResponse = new RefundPaymentResponse();
		String inputLob = refundPaymentRequest.getLob();
		List<String> allowableLobs = new ArrayList<String>();
  		if(allowedLobList != null && !allowedLobList.isEmpty()) {
			String[] allowedLobArray = allowedLobList.split(",");
			allowableLobs = Arrays.asList(allowedLobArray);
		}
  		
  		if(!inputLob.isEmpty() && allowableLobs.contains(inputLob)){
			try {
				Transaction refundTransaction = new Transaction();
	  			List<PaymentDetails> paymentDetailsByOrderId = paymentDetailsRepository.getPaymentDetailsByOrderId(refundPaymentRequest.getOrderId());
				if(null != paymentDetailsByOrderId && paymentDetailsByOrderId.size() > 0) {
					for(PaymentDetails payDetailByOrderId : paymentDetailsByOrderId) {
						if(!payDetailByOrderId.getLob().equalsIgnoreCase(refundPaymentRequest.getLob())){
  							throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
						}
						if(null != payDetailByOrderId.getTransactions() && payDetailByOrderId.getTransactions().length > 0) {
							if(isValidRefund(payDetailByOrderId, refundPaymentRequest.getRefundAmount())){
								for(Transaction transaction : payDetailByOrderId.getTransactions()) {
									String transactionStatus = transaction.getTransactionStatus();
									String transactionType = transaction.getTransactionType();
									if(null != transactionStatus && null != transactionType && "PAYMENT".equalsIgnoreCase(transactionType) && "COMPLETED".equalsIgnoreCase(transactionStatus)){
										List<Note> refundNotesList = new ArrayList<Note>();
										Refund refund = new Refund();
										Date today = mongoDateConverter(new Date());
										refundTransaction.setCreatedDt(today);
										refundTransaction.setUpdatedDt(today);
										if(("ISG").equalsIgnoreCase(refundPaymentRequest.getLob())){
											refundTransaction.setCreatedId(payDetailByOrderId.getHcid());
											refundTransaction.setUpdatedId(payDetailByOrderId.getHcid());
										} else {
											refundTransaction.setCreatedId(refundPaymentRequest.getCsrId());
											refundTransaction.setUpdatedId(refundPaymentRequest.getCsrId());
										}
										refundTransaction.setCsr(transaction.isCsr());
										refundTransaction.setPaymentChannel(transaction.getPaymentChannel());
										refundTransaction.setPremiumAmount(Double.parseDouble(refundPaymentRequest.getRefundAmount()));
										refundTransaction.setPaidDate(today);
										refundTransaction.setFeeAmount(transaction.getFeeAmount());
										refundTransaction.setTransactionStatus("PENDING");
										refundTransaction.setFrequency(transaction.getFrequency());
										refundTransaction.setInvoiceNumber(transaction.getInvoiceNumber());
										if(null != transaction.getCommunicationDetails()){
											refundTransaction.setPaymentConfirmationEmailAddress(transaction.getCommunicationDetails().getEmailId());
										}
										refund.setRefundReasonCode(refundPaymentRequest.getRefundReason());
										refund.setRefundReasondescription(REFUND_CODE_MAPPING.get(refundPaymentRequest.getRefundReason()));
										refundTransaction.setRefund(refund);
										refundTransaction.setNotes(refundNotesList);
										refundTransaction.setTransactionType("REFUND");
										refundTransaction.setNocReceived(transaction.isNocReceived());
										refundTransaction.setCheckId(transaction.getCheckId());
										Transaction[] transactions = populateTransactionArray(payDetailByOrderId.getTransactions(), refundTransaction);
										payDetailByOrderId.setTransactions(transactions);
										paymentDetailsRepository.save(payDetailByOrderId);
										refundPaymentResponse.setStatus("SUCCESS");
										break;
									}
								}
							} 
						}
					}
				} else {
					LOGGER.error("Exception in PaymentModServiceImpl: No data found for the order Id");
					throw new PaymentModException(PAYMENT_MOD_ERR_9206_NO_DATA, PAYMENT_MOD_ERR_9206_NO_DATA_DESC);
				}
			} catch (PaymentModException e) {
  	  			LOGGER.error("Exception in PaymentModServiceImpl: Save PaymentDetails with refund details");
  	            throw new PaymentModException(e.getErrorCode(),e.getErrorMessage());
  			} catch (Exception ex) {
  				LOGGER.error("Exception in PaymentModServiceImpl: Mongo Exception during refund Payment");
  				throw new PaymentModException(PAYMENT_MOD_ERR_9207_MONGO_EXP,PAYMENT_MOD_ERR_9207_MONGO_EXP_DESC);
  			}
  		} else {
  			LOGGER.error("Exception in PaymentModServiceImpl: LOB Missing");
  			throw new PaymentModException(PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS,PAYMENT_MOD_ERR_9203_NO_TRANSACTIONS_DESC);
  		}
		LOGGER.info("PaymentModServiceImpl: Inside refundPayment - end");
		return refundPaymentResponse;
	}
	
	public Transaction[] populateTransactionArray(Transaction[] originalTransations, Transaction refundTransaction) {
	    int currentSize = originalTransations.length;
	    int newSize = currentSize + 1;
	    Transaction[] tempArray = new Transaction[newSize];
	    for (int i=0; i < currentSize; i++) {
	        tempArray[i] = originalTransations [i];
	    }
	    tempArray[newSize-1] = refundTransaction;
	    return tempArray;
	}
	
	private boolean isValidRefund(PaymentDetails paymentDetails, String refundAmt) throws PaymentModException{
		boolean hasAmount = false;
		double paymentAmount = 0.0;
		double refundAmount = 0.0;
		int transactionCount = 0;
		double inputRefund = 0.0;
		
		if(null != refundAmt && !refundAmt.isEmpty()){
			inputRefund = Double.parseDouble(refundAmt);
		}
		
		if(!(inputRefund > 0.0)){
			throw new PaymentModException(PAYMENT_MOD_ERR_9201_AMOUNT,PAYMENT_MOD_ERR_9201_AMOUNT_DESC);
		}
		
		for (Transaction transaction : paymentDetails.getTransactions()) {
			if(transaction.getTransactionStatus().equalsIgnoreCase("COMPLETED")) {
				if(null != paymentDetails.getPaymentMethod()){
					if(paymentDetails.getPaymentMethod().getPaymentType().equalsIgnoreCase("ACH")){
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
						Date today = new Date();
						try {
							today = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
						} catch (ParseException e) {
							LOGGER.error("ParseException in formatting today's date in isValidRefund");
						}
						if(null != transaction.getSubmissionDt()){
							Date submissionDate = mongoDateConverter(transaction.getSubmissionDt());
							long dateDifference = today.getTime() - submissionDate.getTime();
							float days = (dateDifference / (1000*60*60*24));
							if(days <= 7){
								throw new PaymentModException(PAYMENT_MOD_ERR_9205_INVALID_DATE,PAYMENT_MOD_ERR_9205_INVALID_DATE_DESC);
							}
						}
					}
				}
			}
			if(transaction.getTransactionStatus().equalsIgnoreCase("COMPLETED")){
				transactionCount++;
			} 
			if (transaction.getTransactionStatus().equalsIgnoreCase("RETURNED")){
				throw new PaymentModException(PAYMENT_MOD_ERR_9202_RETURNED,PAYMENT_MOD_ERR_9202_RETURNED_DESC);		
			}
			if(transaction.getTransactionType().equalsIgnoreCase("PAYMENT")){
				paymentAmount = paymentAmount + transaction.getPremiumAmount(); 
			}
			if(transaction.getTransactionType().equalsIgnoreCase("REFUND")){
				refundAmount = refundAmount + transaction.getPremiumAmount();
			}
		}
		refundAmount = refundAmount + inputRefund;
		if(refundAmount <= paymentAmount){
			hasAmount = true;
		}
		if(transactionCount != paymentDetails.getTransactions().length){
			throw new PaymentModException(PAYMENT_MOD_ERR_9204_NOT_COMPLETED,PAYMENT_MOD_ERR_9204_NOT_COMPLETED_DESC);
		} else if(!hasAmount){
			throw new PaymentModException(PAYMENT_MOD_ERR_9201_AMOUNT,PAYMENT_MOD_ERR_9201_AMOUNT_DESC);
		}
		return true;
	}
	
	//PP-16301, PP-16303 - Start
	@Override
	public GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws PaymentModException {
		LOGGER.info("Inside PaymentModServiceImpl - getPaymentMethods - start");
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		String maskedNbr = null;
		try {
			PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletByHcidLob(getPaymentMethodRequest.getHcid(), getPaymentMethodRequest.getLob());
			if(null != paymentWallet) {
				response = dozerMapper.map(paymentWallet, GetPaymentMethodResponse.class);
				if(null != response && null != response.getTokens()) {
					List<com.anthem.payment.paymod.model.Token> activeTokenList = new ArrayList<>();
					for(com.anthem.payment.paymod.model.Token token : response.getTokens()) {
						if(null != token && null != token.getStatus() && ACTIVE_STR.equalsIgnoreCase(token.getStatus())) {
							if(null != token && null != token.getPaymentType() && PAYMENT_TYPE_CC.equalsIgnoreCase(token.getPaymentType())) {
								maskedNbr = paymentModUtil.maskString(token.getCreditCard().getCreditCardNumber(), 0, token.getCreditCard().getCreditCardNumber().length() - 4, '*');
								token.getCreditCard().setCreditCardNumber(maskedNbr);
							} else if(null != token && null != token.getPaymentType() && PAYMENT_TYPE_ACH.equalsIgnoreCase(token.getPaymentType())) {
								maskedNbr = paymentModUtil.maskString(token.getBankAccount().getBankAccountNumber(), 0, token.getBankAccount().getBankAccountNumber().length() - 4, '*');
								token.getBankAccount().setBankAccountNumber(maskedNbr);
							}
							activeTokenList.add(token);
						}
					}
					com.anthem.payment.paymod.model.Token[] tokens = activeTokenList.toArray(new com.anthem.payment.paymod.model.Token[activeTokenList.size()]);
					response.setTokens(tokens);
				}
			}
			response.setErrorCode("0");
			response.setErrorMessage("Success");
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl getPaymentMethods " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		LOGGER.info("Inside PaymentModServiceImpl - getPaymentMethods - End");
		return response;
	}
	
	@Override
	public GetPaymentMethodResponse getWalletInformation(GetPaymentMethodRequest getPaymentMethodRequest) throws PaymentModException {
		LOGGER.info("Inside PaymentModServiceImpl - getWalletInformation - start");
		GetPaymentMethodResponse response = new GetPaymentMethodResponse();
		try {
			PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(getPaymentMethodRequest.getHcid(), getPaymentMethodRequest.getLob(), getPaymentMethodRequest.getTokenId());
			if(null != paymentWallet) {
				response = dozerMapper.map(paymentWallet, GetPaymentMethodResponse.class);
				if(null != response && null != response.getTokens()) {
					List<com.anthem.payment.paymod.model.Token> activeTokenList = new ArrayList<>();
					for(com.anthem.payment.paymod.model.Token token : response.getTokens()) {
						if(null != token && null != token.getStatus() && ACTIVE_STR.equalsIgnoreCase(token.getStatus()) && getPaymentMethodRequest.getTokenId().equalsIgnoreCase(token.getTokenId())) {
							activeTokenList.add(token);
						}
					}
					com.anthem.payment.paymod.model.Token[] tokens = activeTokenList.toArray(new com.anthem.payment.paymod.model.Token[activeTokenList.size()]);
					response.setTokens(tokens);
				}
			}
			response.setErrorCode("0");
			response.setErrorMessage("Success");
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl getWalletInformation " + e);
			throw new PaymentModException("PP9033", PAYMENT_MOD_ERR_FETCH_PAYMENT_METHOD);
		}
		LOGGER.info("Inside PaymentModServiceImpl - getWalletInformation - End");
		return response;
	}
	
	@Override
	public UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException {
		LOGGER.info("Inside PaymentModServiceImpl - updatePaymentMethod - Start");
		
		validateUpdatePaymentRequest(updatePaymentMethodRequest);
		
		UpdatePaymentMethodResponse paymentMethodResponse = null;
		try {
			if ("CREATE".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
				paymentMethodResponse = createPayMethod(updatePaymentMethodRequest);
			} else if ("MODIFY".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
				paymentMethodResponse = updatePayMethod(updatePaymentMethodRequest);
			} else if ("DELETE".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
				paymentMethodResponse = deletePayMethod(updatePaymentMethodRequest);
			}
		} catch (PaymentModException e) {
			LOGGER.error("PaymentModException in PaymentModServiceImpl updatePaymentMethod " + e);
			throw e;
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl updatePaymentMethod " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		return paymentMethodResponse;
	}
	
	private void validateUpdatePaymentRequest(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException {
		if (null == updatePaymentMethodRequest.getHcid() || updatePaymentMethodRequest.getHcid().isEmpty()) {
			throw new PaymentModException("PP9022", MISSING_PARAMETERS);
		}
		if (null == updatePaymentMethodRequest.getAction() || updatePaymentMethodRequest.getAction().isEmpty() || 
				!Arrays.asList(ALLOWED_ACTION).contains(updatePaymentMethodRequest.getAction())) {
			throw new PaymentModException("PP9022", MISSING_PARAMETERS);
		}
		if (null == updatePaymentMethodRequest.getLob() || updatePaymentMethodRequest.getLob().isEmpty() || 
				!Arrays.asList(ALLOWED_LOB).contains(updatePaymentMethodRequest.getLob())) {
			throw new PaymentModException("PP9022", MISSING_PARAMETERS);
		}
		
		com.anthem.payment.paymod.model.Token paymentMethod = updatePaymentMethodRequest.getToken();
		
		if (null == paymentMethod) {
			throw new PaymentModException("PP9022", MISSING_PARAMETERS);
		}
		
		if ("CREATE".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			if(null == paymentMethod.getPaymentSubType() || paymentMethod.getPaymentSubType().isEmpty() ||
					!Arrays.asList(ALLOWED_PAY_SUB_TYPE).contains(paymentMethod.getPaymentSubType())) {
				throw new PaymentModException("PP9022", MISSING_PARAMETERS);
			}
			if (null == paymentMethod || null == paymentMethod.getFundAccOwnerFullAddress() ||
					(null == paymentMethod.getBankAccount() && null == paymentMethod.getCreditCard())) {
				throw new PaymentModException("PP9022", MISSING_PARAMETERS);
			}
			if(null != paymentMethod.getBankAccount()) {
				if(null == paymentMethod.getBankAccount().getBankRoutingNumber() || paymentMethod.getBankAccount().getBankRoutingNumber().isEmpty() || 
						!paymentModUtil.isRoutingNoValid(paymentMethod.getBankAccount().getBankRoutingNumber())) {
					throw new PaymentModException("9301", "The Routing Number is not valid.");
				}
				if(null == paymentMethod.getBankAccount().getBankAccountNumber() || paymentMethod.getBankAccount().getBankAccountNumber().isEmpty() || 
	                    !Pattern.matches("^[0-9]{4,17}$", paymentMethod.getBankAccount().getBankAccountNumber())) {
					throw new PaymentModException("9302", "The Bank Account Number is not valid.");
				}
			}
			if(null != paymentMethod.getCreditCard()) {
				if(null == paymentMethod.getCreditCard().getCreditCardNumber() || paymentMethod.getCreditCard().getCreditCardNumber().isEmpty() ||
						!Pattern.matches("^[0-9]{0,16}$", paymentMethod.getCreditCard().getCreditCardNumber())) {
					throw new PaymentModException("9310", "The Credit card Number is not valid.");
				}
			}
		}
		if ("CREATE".equalsIgnoreCase(updatePaymentMethodRequest.getAction()) || "MODIFY".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			if(null == paymentMethod.getPaymentType() || paymentMethod.getPaymentType().isEmpty() ||
					!Arrays.asList(ALLOWED_PAY_TYPE).contains(paymentMethod.getPaymentType())) {
				throw new PaymentModException("PP9022", MISSING_PARAMETERS);
			}
			if (null == paymentMethod || null == paymentMethod.getFundAccOwnerFullAddress()) {
				throw new PaymentModException("PP9022", MISSING_PARAMETERS);
			}
			if(paymentMethod.getNameOnFundingAcc() == null || paymentMethod.getNameOnFundingAcc().isEmpty() || 
					!Pattern.matches("^[a-zA-Z\\s]{0,40}$", paymentMethod.getNameOnFundingAcc())) {
				throw new PaymentModException("9303", "The name is not valid. Please check the Account Holder name field and try again.");
			}
			if(null != paymentMethod.getAccNickName() && (paymentMethod.getAccNickName().isEmpty() || 
					!Pattern.matches("^[a-zA-Z\\s]{0,40}$", paymentMethod.getAccNickName()))) {
				throw new PaymentModException("9309", "The nick name is not valid. Please check the Account Nick name field and try again.");
			}
			if(null != paymentMethod.getCreditCard()) {
				if(null == paymentMethod.getCreditCard().getExpirationMonth() || paymentMethod.getCreditCard().getExpirationMonth().isEmpty()) {
					throw new PaymentModException("9311", "The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.");
				}
				if(null == paymentMethod.getCreditCard().getExpirationYear() || paymentMethod.getCreditCard().getExpirationYear().isEmpty()) {
					throw new PaymentModException("9312", "The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.");
				}
				if(!paymentModUtil.validateCCExpirationString(paymentMethod.getCreditCard().getExpirationMonth() + "/" + paymentMethod.getCreditCard().getExpirationYear())) {
					throw new PaymentModException("9313", "The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.");
				}
			}
			com.anthem.payment.paymod.model.FundAccountOwnerFullAddress address = paymentMethod.getFundAccOwnerFullAddress();
			if(address.getAddress1() == null || address.getAddress1().isEmpty() || 
					!Pattern.matches("^[a-zA-Z0-9\\s]{0,40}$", address.getAddress1())) {
				throw new PaymentModException("9304", "Invalid Address Information.");
			}
			if(null != address.getAddress2() && !address.getAddress2().isEmpty() && 
					!Pattern.matches("^[a-zA-Z0-9\\s]{0,40}$", address.getAddress2())) {
				throw new PaymentModException("9305", "Invalid Address Information.");
			}
			if(address.getCity() == null || address.getCity().isEmpty() || 
					!Pattern.matches("^[a-zA-Z\\s]{0,20}$", address.getCity())) {
				throw new PaymentModException("9306", "The city is not valid. Please check the city and try again.");
			}
			if(address.getState() == null || address.getState().isEmpty() || 
					!Pattern.matches("^[a-zA-Z]{2}$", address.getState())) {
				throw new PaymentModException("9307", "The state is not a valid. Please check the state and try again.");
			}
			if(address.getZipcode() == null || address.getZipcode().isEmpty() || 
					!Pattern.matches("^[0-9]{5}$", address.getZipcode())) {
				throw new PaymentModException("9308", "The zip code is not valid. Please check the field and try again.");
			}
		}
		if ("MODIFY".equalsIgnoreCase(updatePaymentMethodRequest.getAction()) || "DELETE".equalsIgnoreCase(updatePaymentMethodRequest.getAction())) {
			if (null == paymentMethod.getTokenId() || paymentMethod.getTokenId().isEmpty()) {
				throw new PaymentModException("9314", "TokenId cannot have null or empty values.");
			}
		}
	}
	
	private UpdatePaymentMethodResponse createPayMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException {
		String paymentType = null;
		GetTokenResponse getTokenResponse = null;
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		String encryptionFlag = null;
		try {
			paymentType = updatePaymentMethodRequest.getToken().getPaymentType();
			//getToken service call
			if(PAYMENT_TYPE_CC.equalsIgnoreCase(paymentType)) {
				if(null != updatePaymentMethodRequest.getToken().getCreditCard().getIntegrityCheck() && null != updatePaymentMethodRequest.getToken().getCreditCard().getKeyID() &&
						null != updatePaymentMethodRequest.getToken().getCreditCard().getPhaseID()) {
					encryptionFlag = "201";
					getTokenResponse = getEncryptedCCToken(updatePaymentMethodRequest, "201");
				} else {
					encryptionFlag = "203";
					getTokenResponse = getEncryptedCCToken(updatePaymentMethodRequest, "203");
				}
			}
						
			PaymentWallet wallet = paymentWalletRepository.getPaymentWalletByHcidLob(updatePaymentMethodRequest.getHcid(), updatePaymentMethodRequest.getLob());
			
			if (null != wallet) {
				if (null != wallet && null != wallet.getTokens() && wallet.getTokens().length > 0) {
					Token newToken = dozerMapper.map(updatePaymentMethodRequest.getToken(), Token.class);
					if(PAYMENT_TYPE_CC.equalsIgnoreCase(paymentType) && null != getTokenResponse) {
						newToken.getCreditCard().setCreditCardNumber(getTokenResponse.getEncryptedToken());
						if(null != encryptionFlag && "201".equalsIgnoreCase(encryptionFlag)) {
							newToken.getCreditCard().setCreditCardNumberUI(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber());
						} else {
							newToken.getCreditCard().setCreditCardNumberUI(null);
						}
						newToken.getCreditCard().setCcAuthorizationNumber(getTokenResponse.getAuthorizationCode());
						newToken.getCreditCard().setResponseReasonCode(getTokenResponse.getReasonCode());
						newToken.getCreditCard().setTokenDate(getTokenResponse.getTokenPaidDate());
						newToken.getCreditCard().setActionCode(getTokenResponse.getActionCode());
						newToken.getCreditCard().setIsLevelThree(getTokenResponse.getLevelTInd());
						newToken.getCreditCard().setInterchangeQualificationCode("");
						newToken.getCreditCard().setaVSAAV(getTokenResponse.getAvsaav());
						
						if (null != updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber() && updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().length() == 16) {
							newToken.getCreditCard().setCreditCardFirstSix(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().substring(0, 6));
							newToken.getCreditCard().setCreditCardLastFour(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().substring(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().length() - 4));
						}
					}
					newToken.setStatus(ACTIVE_STR);
					newToken.setCreatedDt(Calendar.getInstance(Locale.US).getTime());
					newToken.setCreatedId(updatePaymentMethodRequest.getToken().getCreatedId());
					newToken.setIsCsr(updatePaymentMethodRequest.getToken().isCsr());
					newToken.setTokenId(paymentModUtil.generateTokenId());
					paymentMethodResponse.setTokenId(newToken.getTokenId());
					Query query = new Query();
					query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()));
					Update update = new Update();
					update.set("tokens." + wallet.getTokens().length, newToken);
					mongoOperations.findAndModify(query, update, PaymentWallet.class);
				}
			} else {
				PaymentWallet payWallet = new PaymentWallet();
				payWallet.setHcid(updatePaymentMethodRequest.getHcid());
				payWallet.setLob(updatePaymentMethodRequest.getLob());
				
				Token[] tokens = new Token[1];
				tokens[0] = dozerMapper.map(updatePaymentMethodRequest.getToken(), Token.class);
				tokens[0].setStatus(ACTIVE_STR);
				tokens[0].setCreatedDt(Calendar.getInstance(Locale.US).getTime());
				tokens[0].setCreatedId(updatePaymentMethodRequest.getHcid());
				tokens[0].setTokenId(paymentModUtil.generateTokenId());
				
				if(PAYMENT_TYPE_CC.equalsIgnoreCase(paymentType) && null != getTokenResponse) {
					tokens[0].getCreditCard().setCreditCardNumber(getTokenResponse.getEncryptedToken());
					if(null != encryptionFlag && "201".equalsIgnoreCase(encryptionFlag)) {
						tokens[0].getCreditCard().setCreditCardNumberUI(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber());
					} else {
						tokens[0].getCreditCard().setCreditCardNumberUI(null);
					}
					tokens[0].getCreditCard().setCcAuthorizationNumber(getTokenResponse.getAuthorizationCode());
					tokens[0].getCreditCard().setResponseReasonCode(getTokenResponse.getReasonCode());
					tokens[0].getCreditCard().setTokenDate(getTokenResponse.getTokenPaidDate());
					tokens[0].getCreditCard().setActionCode(getTokenResponse.getActionCode());
					tokens[0].getCreditCard().setIsLevelThree(getTokenResponse.getLevelTInd());
					tokens[0].getCreditCard().setInterchangeQualificationCode("");
					tokens[0].getCreditCard().setaVSAAV(getTokenResponse.getAvsaav());
					
					if (null != updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber() && updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().length() == 16) {
						tokens[0].getCreditCard().setCreditCardFirstSix(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().substring(0, 6));
						tokens[0].getCreditCard().setCreditCardLastFour(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().substring(updatePaymentMethodRequest.getToken().getCreditCard().getCreditCardNumber().length() - 4));
					}
				}
				
				paymentMethodResponse.setTokenId(tokens[0].getTokenId());
				payWallet.setTokens(tokens);
				mongoOperations.save(payWallet);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl createPayMethod " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		paymentMethodResponse.setErrorCode("0");
		paymentMethodResponse.setErrorMessage("Success");
		return paymentMethodResponse;
	}
	
	private UpdatePaymentMethodResponse updatePayMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException {
		String paymentType = null;
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		try {
			paymentType = updatePaymentMethodRequest.getToken().getPaymentType();
			
			FundAccountOwnerFullAddress accAddr = new FundAccountOwnerFullAddress();
			accAddr.setAddress1(updatePaymentMethodRequest.getToken().getFundAccOwnerFullAddress().getAddress1());
			accAddr.setAddress2(updatePaymentMethodRequest.getToken().getFundAccOwnerFullAddress().getAddress2());
			accAddr.setCity(updatePaymentMethodRequest.getToken().getFundAccOwnerFullAddress().getCity());
			accAddr.setState(updatePaymentMethodRequest.getToken().getFundAccOwnerFullAddress().getState());
			accAddr.setZipcode(updatePaymentMethodRequest.getToken().getFundAccOwnerFullAddress().getZipcode());
			
			Query query = new Query();
			query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()).
					and("lob").is(updatePaymentMethodRequest.getLob()).and("tokens.token_id").is(updatePaymentMethodRequest.getToken().getTokenId()));
			
		    Update update = new Update();
		    update.set("tokens.$.name_on_funding_account", updatePaymentMethodRequest.getToken().getNameOnFundingAcc());
		    update.set("tokens.$.account_nickname", updatePaymentMethodRequest.getToken().getAccNickName());
		    
		    update.set("tokens.$.fund_account_owner_full_address", accAddr);
		    
		    update.set("tokens.$.updated_dt", Calendar.getInstance(Locale.US).getTime());
		    update.set("tokens.$.updated_id", updatePaymentMethodRequest.getToken().getUpdatedId());
		    update.set("tokens.$.status", ACTIVE_STR);
		    
		    if(PAYMENT_TYPE_CC.equalsIgnoreCase(paymentType)) {
		    	update.set("tokens.$.creditcard.expiration_month", updatePaymentMethodRequest.getToken().getCreditCard().getExpirationMonth());
		    	update.set("tokens.$.creditcard.expiration_year", updatePaymentMethodRequest.getToken().getCreditCard().getExpirationYear());
			}
		    
		    WriteResult wr = mongoOperations.updateFirst(query, update, PaymentWallet.class);
		    if(null != wr && 0 != wr.getN()) {
		    	paymentMethodResponse.setErrorCode("0");
				paymentMethodResponse.setErrorMessage("Success");
		    } else {
		    	paymentMethodResponse.setErrorCode("9315");
				paymentMethodResponse.setErrorMessage("The TokenId is not found.");
		    }
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl updatePayMethod " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		return paymentMethodResponse;
	}
	
	private UpdatePaymentMethodResponse deletePayMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException {
		UpdatePaymentMethodResponse paymentMethodResponse = new UpdatePaymentMethodResponse();
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("hcid").is(updatePaymentMethodRequest.getHcid()).
					and("lob").is(updatePaymentMethodRequest.getLob()).and("tokens.token_id").is(updatePaymentMethodRequest.getToken().getTokenId()));
			
		    Update update = new Update();
		    update.set("tokens.$.updated_dt", Calendar.getInstance(Locale.US).getTime());
		    update.set("tokens.$.updated_id", updatePaymentMethodRequest.getToken().getUpdatedId());
		    update.set("tokens.$.status", INACTIVE_STR);
		    
			WriteResult wr = mongoOperations.updateFirst(query, update, PaymentWallet.class);
			if(null != wr && 0 != wr.getN()) {
				paymentMethodResponse.setErrorCode("0");
				paymentMethodResponse.setErrorMessage("Success");
			} else {
				paymentMethodResponse.setErrorCode("9315");
				paymentMethodResponse.setErrorMessage("The TokenId is not found.");
			}
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl deletePayMethod " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		return paymentMethodResponse;
	}
	
	private AuditTrail[] generateAuditTrailForPaymentMethodUpdate(String hcid, String lob, String tokenId) {
	
		PaymentWallet paymentWallet = paymentWalletRepository.getPaymentWalletWithTokenID(hcid, lob, tokenId);
		int auditTrailSize = 0;
		if(null != paymentWallet && null != paymentWallet.getTokens() && paymentWallet.getTokens().length > 0) {
			for(com.anthem.payment.paymod.entity.Token token: paymentWallet.getTokens()) {
				
			}
		}
		
	}
	
	private GetTokenResponse getEncryptedCCToken(UpdatePaymentMethodRequest req, String encryptionFlag) throws PaymentModException {
		GetTokenRequest getTokenRequest = new GetTokenRequest();
		GetTokenResponse getTokenResponse = new GetTokenResponse();
		try {
			if (req.getToken().getPaymentSubType().equals("VISA")) {
				getTokenRequest.setMethodOfPayment("VI");
			} else if (req.getToken().getPaymentSubType().equals("MC")) {
				getTokenRequest.setMethodOfPayment("MC");
			}
			getTokenRequest.setCardHolderName(req.getToken().getNameOnFundingAcc());
			getTokenRequest.setAccountNumber(req.getToken().getCreditCard().getCreditCardNumber());
			getTokenRequest.setExpirationDate(req.getToken().getCreditCard().getExpirationMonth() 
					+ req.getToken().getCreditCard().getExpirationYear().substring(req.getToken().getCreditCard().getExpirationYear().length() - 2));
			
			if(null != encryptionFlag && "201".equalsIgnoreCase(encryptionFlag)) {
				getTokenRequest.setIntegrityCheck(req.getToken().getCreditCard().getIntegrityCheck());
				getTokenRequest.setKeyID(req.getToken().getCreditCard().getKeyID());
				getTokenRequest.setPhaseID(req.getToken().getCreditCard().getPhaseID());
			}
			
			getTokenRequest.setMessageType("CSTO");
			getTokenRequest.setStoredCredentialFlag("N");

			getTokenRequest.setAnthemOrderId(paymentModUtil.generateOrderId("PPORT"));
			getTokenRequest.setEncryptionFlag(encryptionFlag);
			getTokenRequest.setAmount("0");
			
			getTokenRequest.setPostalCode(req.getToken().getFundAccOwnerFullAddress().getZipcode());
			getTokenRequest.setDivisionCode(req.getTransactionDivisionCode());
			
			getTokenResponse = getTokenInformation(getTokenRequest, "VF");
			if(null == getTokenResponse || null == getTokenResponse.getEncryptedToken() || getTokenResponse.getEncryptedToken().isEmpty()) {
				LOGGER.error("Error in PaymentModServiceImpl getEncryptedCCToken - getTokenResponse or getEncryptedToken is null");
				if(null != getTokenResponse && null != getTokenResponse.getExceptionDetails()) {
					throw new PaymentModException(getTokenResponse.getExceptionDetails().getCode(), getTokenResponse.getExceptionDetails().getMessage());
				} else {
					throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl getEncryptedCCToken " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		return getTokenResponse;
	}
	//PP-16301, PP-16303 - End
	
	private Date mongoDateConverter(Date inputDate){
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date returnDate = null;
		SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
		try {
			returnDate = dateFormatLocal.parse(dateFormatGmt.format(inputDate));
		} catch (ParseException e) {
			LOGGER.error("Parse Exception occured while converting date to string" + e.getMessage());
		}
		return returnDate;
	}

	@Override
	public SearchRefundResponse getPaymentDetails(SearchRefundRequest searchRefundRequest) throws PaymentModException {
		
		LOGGER.info("Inside PaymentModServiceImpl - getPaymentDetails - Start");
		List<PaymentDetails> paymentDetailsList = new ArrayList<PaymentDetails>();
		SearchRefundResponse searchRefundResponse = new SearchRefundResponse();
		List<PaymentDetailsVO> paymentDetailsVOs = null;
		try {
			paymentDetailsList = paymentDetailsRepository.getPaymentDetailsByHcidLob(searchRefundRequest.getHcid(), searchRefundRequest.getLob());
			if(null != paymentDetailsList && paymentDetailsList.size() > 0){
				paymentDetailsVOs = new ArrayList<PaymentDetailsVO>();
				for(PaymentDetails paymentDetails : paymentDetailsList){
					paymentDetailsVOs.add(dozerMapper.map(paymentDetails, PaymentDetailsVO.class));
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModServiceImpl getPaymentDetails " + e);
			throw new PaymentModException(PAYMENT_MOD_ERR_005,PAYMENT_MOD_ERR_MSG_005);
		}
		LOGGER.info("Inside PaymentModServiceImpl - getPaymentDetails - End");
		searchRefundResponse.setPaymentDetails(paymentDetailsVOs);
		return searchRefundResponse;
		
	}

}