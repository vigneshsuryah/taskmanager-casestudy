package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "payment_wallet")
public class PaymentWallet {

	@Field("hcid")
	private String hcid;
	
	@Field("lob")
	private String lob;

	@Field("tokens")
	private Token[] tokens;
	
	@Field("acn")
	private String acn;
	
	@Field("third_party_id")
	private String thirdPartyId;

	/**
	 * @return the hcid
	 */
	public String getHcid() {
		return hcid;
	}

	/**
	 * @param hcid the hcid to set
	 */
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the tokens
	 */
	public Token[] getTokens() {
		return tokens;
	}

	/**
	 * @param tokens the tokens to set
	 */
	public void setTokens(Token[] tokens) {
		this.tokens = tokens;
	}

	/**
	 * @return the acn
	 */
	public String getAcn() {
		return acn;
	}

	/**
	 * @param acn the acn to set
	 */
	public void setAcn(String acn) {
		this.acn = acn;
	}

	/**
	 * @return the thirdPartyId
	 */
	public String getThirdPartyId() {
		return thirdPartyId;
	}

	/**
	 * @param thirdPartyId the thirdPartyId to set
	 */
	public void setThirdPartyId(String thirdPartyId) {
		this.thirdPartyId = thirdPartyId;
	}
	
}
