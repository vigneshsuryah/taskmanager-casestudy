package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class PaymentMethod {

	@Field("payment_type")
	private String paymentType;
	@Field("payment_sub_type")
	private String paymentSubType;
	@Field("credit_card_number")
	private String creditCardNumber;
	@Field("credit_card_number_ui")
	private String creditCardNumberUI;
	@Field("credit_card_first_six")
	private String creditCardFirstSix;
	@Field("credit_card_last_four")
	private String creditCardLastFour;
	@Field("token_id")
	private String tokenId;
	@Field("cc_authorization_number")
	private String ccAuthorizationNumber;
	@Field("interchange_qualification_code")
	private String interchangeQualificationCode;
	@Field("bank_routing_number")
	private String bankRoutingnumber;
	@Field("bank_account_number")
	private String bankAccountNumber;
	@Field("name_on_funding_account")
	private String nameOnFundingAccount;
	@Field("fund_account_owner_full_address")
	private FundAccountOwnerFullAddress fundAccountOwnerFullAddress;
	@Field("action_code")
	private String actionCode;
	@Field("cc_exp_date")
	private String ccExpDate;
	@Field("response_reason_code")
	private String responseReasonCode;
	@Field("token_response_date")
	private String tokenDate;
	@Field("is_level3")
	private String isLevelThree;
	@Field("AVSAAV")
	private String aVSAAV;
	//chase certification changes
	@Field("messageType")
	private String messageType;
	@Field("originalTransactionAmount")
	private String originalTransactionAmount;
	@Field("recordType")
	private String recordType;
	@Field("submittedTransactionID")
	private String submittedTransactionID;
	@Field("responseTransactionID")
	private String responseTransactionID;
	@Field("storedCredentialFlag")
	private String storedCredentialFlag;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getOriginalTransactionAmount() {
		return originalTransactionAmount;
	}

	public void setOriginalTransactionAmount(String originalTransactionAmount) {
		this.originalTransactionAmount = originalTransactionAmount;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getSubmittedTransactionID() {
		return submittedTransactionID;
	}

	public void setSubmittedTransactionID(String submittedTransactionID) {
		this.submittedTransactionID = submittedTransactionID;
	}

	public String getResponseTransactionID() {
		return responseTransactionID;
	}

	public void setResponseTransactionID(String responseTransactionID) {
		this.responseTransactionID = responseTransactionID;
	}

	public String getStoredCredentialFlag() {
		return storedCredentialFlag;
	}

	public void setStoredCredentialFlag(String storedCredentialFlag) {
		this.storedCredentialFlag = storedCredentialFlag;
	}

	public String getTokenDate() {
		return tokenDate;
	}

	public void setTokenDate(String tokenDate) {
		this.tokenDate = tokenDate;
	}

	public String getIsLevelThree() {
		return isLevelThree;
	}

	public void setIsLevelThree(String isLevelThree) {
		this.isLevelThree = isLevelThree;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getCcExpDate() {
		return ccExpDate;
	}

	public void setCcExpDate(String ccExpDate) {
		this.ccExpDate = ccExpDate;
	}

	public String getResponseReasonCode() {
		return responseReasonCode;
	}

	public void setResponseReasonCode(String responseReasonCode) {
		this.responseReasonCode = responseReasonCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentSubType() {
		return paymentSubType;
	}

	public void setPaymentSubType(String paymentSubType) {
		this.paymentSubType = paymentSubType;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getCcAuthorizationNumber() {
		return ccAuthorizationNumber;
	}

	public void setCcAuthorizationNumber(String ccAuthorizationNumber) {
		this.ccAuthorizationNumber = ccAuthorizationNumber;
	}

	public String getInterchangeQualificationCode() {
		return interchangeQualificationCode;
	}

	public void setInterchangeQualificationCode(String interchangeQualificationCode) {
		this.interchangeQualificationCode = interchangeQualificationCode;
	}

	public String getBankRoutingnumber() {
		return bankRoutingnumber;
	}

	public void setBankRoutingnumber(String bankRoutingnumber) {
		this.bankRoutingnumber = bankRoutingnumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getNameOnFundingAccount() {
		return nameOnFundingAccount;
	}

	public void setNameOnFundingAccount(String nameOnFundingAccount) {
		this.nameOnFundingAccount = nameOnFundingAccount;
	}

	public FundAccountOwnerFullAddress getFundAccountOwnerFullAddress() {
		return fundAccountOwnerFullAddress;
	}

	public void setFundAccountOwnerFullAddress(FundAccountOwnerFullAddress fundAccountOwnerFullAddress) {
		this.fundAccountOwnerFullAddress = fundAccountOwnerFullAddress;
	}

	public String getCreditCardNumberUI() {
		return creditCardNumberUI;
	}

	public void setCreditCardNumberUI(String creditCardNumberUI) {
		this.creditCardNumberUI = creditCardNumberUI;
	}

	public String getaVSAAV() {
		return aVSAAV;
	}

	public void setaVSAAV(String aVSAAV) {
		this.aVSAAV = aVSAAV;
	}

}
