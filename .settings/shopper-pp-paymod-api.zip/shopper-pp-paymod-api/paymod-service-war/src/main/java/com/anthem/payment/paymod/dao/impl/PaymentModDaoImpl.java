package com.anthem.payment.paymod.dao.impl;

import org.springframework.stereotype.Repository;

@Repository
public class PaymentModDaoImpl {

}
