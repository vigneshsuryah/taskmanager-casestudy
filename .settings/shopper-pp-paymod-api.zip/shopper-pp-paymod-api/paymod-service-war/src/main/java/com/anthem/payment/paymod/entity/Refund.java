package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Refund {

	@Field("refund_reason_code")
	private String refundReasonCode;
	@Field("refund_reason_description")
	private String refundReasondescription;

	public String getRefundReasonCode() {
		return refundReasonCode;
	}

	public void setRefundReasonCode(String refundReasonCode) {
		this.refundReasonCode = refundReasonCode;
	}

	public String getRefundReasondescription() {
		return refundReasondescription;
	}

	public void setRefundReasondescription(String refundReasondescription) {
		this.refundReasondescription = refundReasondescription;
	}

}
