package com.anthem.payment.paymod.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BaseResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String SUCCESS = "Success";
	public static final String FAILED = "Failed";
}
