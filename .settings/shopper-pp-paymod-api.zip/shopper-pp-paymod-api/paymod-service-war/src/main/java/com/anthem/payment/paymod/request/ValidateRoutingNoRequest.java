/**
 * ValidateRoutingNoRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.request;

import io.swagger.annotations.ApiModel;
import org.hibernate.validator.constraints.NotBlank;

@ApiModel(value="ValidateRoutingNumberRequest")
public class ValidateRoutingNoRequest extends BaseRequest {

	private static final long serialVersionUID = 1L;
	@NotBlank
	private String routingNumber;

	private String accountNumber;

	private String confirmAccountNumber;

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getConfirmAccountNumber() {
		return confirmAccountNumber;
	}

	public void setConfirmAccountNumber(String confirmAccountNumber) {
		this.confirmAccountNumber = confirmAccountNumber;
	}
}
