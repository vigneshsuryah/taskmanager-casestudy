package com.anthem.payment.paymod.util;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PaymentModBase64EncodeUtils implements PaymentModConstants {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentModBase64EncodeUtils.class);
	
	private PaymentModBase64EncodeUtils() {
	}

	public static String getEncodedText(String value) {
		String encoded = "";
		try {
			byte[] message = value.getBytes("UTF-8");
			encoded = DatatypeConverter.printBase64Binary(message);
		} catch (Exception e) {
			LOGGER.error("PaymentChaseBase64EncodeUtils getEncodedText error : "+e);
		}
		return encoded;
	}
	
	public static String getDecodedText(String encoded) {
		String decoded = "";
		try {
			byte[] decodedByte = DatatypeConverter.parseBase64Binary(encoded);
			decoded = new String(decodedByte, "UTF-8");
		} catch (Exception e) {
			LOGGER.error("PaymentChaseBase64EncodeUtils getDecodedText error : "+e);
		}
		return decoded;
	}

}
