package com.anthem.payment.paymod.request;


public class SearchRefundRequest extends BaseRequest {
    
	private static final long serialVersionUID = 1L;
	private String lob;
	private String hcid;
	private String orderId;
	private String depositFromDt;
	private String depositToDt;
	private String isMasked;
	
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getHcid() {
		return hcid;
	}
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getDepositFromDt() {
		return depositFromDt;
	}
	public void setDepositFromDt(String depositFromDt) {
		this.depositFromDt = depositFromDt;
	}
	public String getDepositToDt() {
		return depositToDt;
	}
	public void setDepositToDt(String depositToDt) {
		this.depositToDt = depositToDt;
	}
	public String getIsMasked() {
		return isMasked;
	}
	public void setIsMasked(String isMasked) {
		this.isMasked = isMasked;
	}
	
}
