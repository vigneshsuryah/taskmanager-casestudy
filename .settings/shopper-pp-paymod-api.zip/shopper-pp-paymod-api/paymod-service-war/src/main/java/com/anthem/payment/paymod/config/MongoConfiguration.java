package com.anthem.payment.paymod.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;

import com.mongodb.MongoClientOptions;

@Configuration
public class MongoConfiguration {

	@Value("${spring.data.mongodb.uri}")
	private String mongoUri;
	
	@Bean(name = "mongoTemplate")
	public MongoTemplate getMongoTemplate() throws Exception {
		return new MongoTemplate(payModMongoDbFactory());
	}

	public MongoDbFactory payModMongoDbFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClientURI(mongoUri, customMongoBuilder()));
	}

	public Builder customMongoBuilder() {
		// Mongo database client options to override the default behavior 
		MongoClientOptions.Builder builder = MongoClientOptions.builder();
		return builder;
	}
}
