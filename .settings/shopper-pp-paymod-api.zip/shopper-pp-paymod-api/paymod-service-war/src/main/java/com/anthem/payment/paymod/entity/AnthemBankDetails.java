package com.anthem.payment.paymod.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class AnthemBankDetails {

	@Field("anthem_deposting_bank")
	private String anthemDepostingBank;
	@Field("business_unit")
	private String businessUnit;
	@Field("anthem_bank_account")
	private String anthemBankAccount;
	@Field("transaction_division")
	private String transactionDivision;
	@Field("chase_batch_submission")
	private String chaseBatchSubmission;
	@Field("chase_record_Reference")
	private String chaseRecordReference;
	@Field("pay_date")
	private Date payDate;
	@Field("other_chase_fields")
	private String otherChaseFields;

	public String getAnthemDepostingBank() {
		return anthemDepostingBank;
	}

	public void setAnthemDepostingBank(String anthemDepostingBank) {
		this.anthemDepostingBank = anthemDepostingBank;
	}

	public String getAnthemBankAccount() {
		return anthemBankAccount;
	}

	public void setAnthemBankAccount(String anthemBankAccount) {
		this.anthemBankAccount = anthemBankAccount;
	}

	public String getTransactionDivision() {
		return transactionDivision;
	}

	public void setTransactionDivision(String transactionDivision) {
		this.transactionDivision = transactionDivision;
	}

	public String getChaseBatchSubmission() {
		return chaseBatchSubmission;
	}

	public void setChaseBatchSubmission(String chaseBatchSubmission) {
		this.chaseBatchSubmission = chaseBatchSubmission;
	}

	public String getChaseRecordReference() {
		return chaseRecordReference;
	}

	public void setChaseRecordReference(String chaseRecordReference) {
		this.chaseRecordReference = chaseRecordReference;
	}

	public Date getPayDate() {
		return payDate;
	}

	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}

	public String getOtherChaseFields() {
		return otherChaseFields;
	}

	public void setOtherChaseFields(String otherChaseFields) {
		this.otherChaseFields = otherChaseFields;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
}
