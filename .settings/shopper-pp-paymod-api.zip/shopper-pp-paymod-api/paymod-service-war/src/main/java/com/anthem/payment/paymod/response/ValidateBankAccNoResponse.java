/**
 * ValidateBankAccNoResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.response;

public class ValidateBankAccNoResponse extends BaseResponse{

	private static final long serialVersionUID = -4528884158536438873L;

	private boolean isValid;

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
}
