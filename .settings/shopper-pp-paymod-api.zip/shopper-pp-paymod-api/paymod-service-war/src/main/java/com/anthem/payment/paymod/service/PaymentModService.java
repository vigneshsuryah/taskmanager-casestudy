package com.anthem.payment.paymod.service;

import com.anthem.payment.paymod.handler.PaymentModException;
import com.anthem.payment.paymod.request.CancelPaymentRequest;
import com.anthem.payment.paymod.request.GetPaymentMethodRequest;
import com.anthem.payment.paymod.request.GetTokenRequest;
import com.anthem.payment.paymod.request.MamDetailsBO;
import com.anthem.payment.paymod.request.RefundPaymentRequest;
import com.anthem.payment.paymod.request.SearchPaymentRequest;
import com.anthem.payment.paymod.request.SearchRefundRequest;
import com.anthem.payment.paymod.request.SubmitPaymentRequest;
import com.anthem.payment.paymod.request.UpdatePaymentMethodRequest;
import com.anthem.payment.paymod.response.CancelPaymentResponse;
import com.anthem.payment.paymod.response.GetPaymentMethodResponse;
import com.anthem.payment.paymod.response.GetTokenResponse;
import com.anthem.payment.paymod.response.RefundPaymentResponse;
import com.anthem.payment.paymod.response.SearchPaymentResponse;
import com.anthem.payment.paymod.response.SearchRefundResponse;
import com.anthem.payment.paymod.response.SubmitPaymentResponse;
import com.anthem.payment.paymod.response.UpdatePaymentMethodResponse;

public interface PaymentModService {

	GetTokenResponse getTokenInformation(GetTokenRequest getTokenRequest, String action);

	MamDetailsBO getTransactionDivision(MamDetailsBO getTokenRequest) throws PaymentModException;

	SubmitPaymentResponse submitPayment(SubmitPaymentRequest submitPaymentRequest) throws PaymentModException;

	SearchPaymentResponse searchPayment(SearchPaymentRequest searchPaymentRequest) throws PaymentModException;

    CancelPaymentResponse cancelPayment(CancelPaymentRequest cancelPaymentRequest) throws PaymentModException;
    
    SearchRefundResponse refundSearch(SearchRefundRequest searchRefundRequest) throws PaymentModException;
    
    RefundPaymentResponse refundPayment(RefundPaymentRequest refundPaymentRequest) throws PaymentModException;
    
    //PP-16301, PP-16303 - Start
    GetPaymentMethodResponse getPaymentMethods(GetPaymentMethodRequest getPaymentMethodRequest) throws PaymentModException;

    UpdatePaymentMethodResponse updatePaymentMethod(UpdatePaymentMethodRequest updatePaymentMethodRequest) throws PaymentModException;
	//PP-16301, PP-16303 - End
    
    GetPaymentMethodResponse getWalletInformation(GetPaymentMethodRequest getPaymentMethodRequest) throws PaymentModException; 
    
    SearchRefundResponse getPaymentDetails(SearchRefundRequest searchRefundRequest) throws PaymentModException; 
}
