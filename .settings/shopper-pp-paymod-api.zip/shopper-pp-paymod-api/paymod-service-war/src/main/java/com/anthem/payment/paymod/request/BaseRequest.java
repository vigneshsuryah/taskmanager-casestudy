package com.anthem.payment.paymod.request;

import java.io.Serializable;

import com.anthem.payment.paymod.model.RequestHeader;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BaseRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@JsonIgnore
	private RequestHeader requestHeader;

	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}
}
