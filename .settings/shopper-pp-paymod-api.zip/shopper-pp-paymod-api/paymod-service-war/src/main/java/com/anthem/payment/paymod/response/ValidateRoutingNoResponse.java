/**
 * ValidateRoutingNoResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.response;

public class ValidateRoutingNoResponse extends BaseResponse {
	
	private static final long serialVersionUID = 1L;
	private boolean isValid;

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
}
