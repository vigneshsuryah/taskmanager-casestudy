/**
 * PaymentModExceptionHandler.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0       Cognizant      Initial Version
 */
package com.anthem.payment.paymod.handler;

import java.util.*;

import com.anthem.payment.paymod.request.GetTokenRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.anthem.payment.paymod.response.PaymentModExceptionResponse;
import com.anthem.payment.paymod.util.PaymentModConstants;
import com.anthem.payment.paymod.response.Exception;

import static org.apache.http.client.methods.RequestBuilder.put;

@ControllerAdvice
public class PaymentModExceptionHandler extends ResponseEntityExceptionHandler implements PaymentModConstants {

	@ExceptionHandler(PaymentModException.class)
	public @ResponseBody
	ResponseEntity<Object> handleCustomException(PaymentModException ex) {
		PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		Exception apiError = new Exception();
		if (null != ex) {
			if(ex.getException() != null && ex.getException() instanceof IllegalAccessException) {
				status = HttpStatus.FORBIDDEN;
			} else {
				status = HttpStatus.BAD_REQUEST;
			}
			apiError.setCode(ex.getErrorCode());
			apiError.setMessage(ex.getErrorMessage());
		} else {
			apiError.setCode(PAYMENT_MOD_TECH_ERROR_CODE);
			apiError.setMessage(PAYMENT_MOD_TECH_ERROR_MSG);
		}
		exResponse.setExceptions(Arrays.asList(apiError));
		return new ResponseEntity<Object>(exResponse, new HttpHeaders(), status);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		List<Exception> exceptionList= new ArrayList<Exception>();
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			Exception apiError = new Exception();
			StringBuilder msg = new StringBuilder();
			if(StringUtils.isNotBlank(error.getField())){
				msg.append(error.getField());
				apiError.setCode(error.getDefaultMessage());
				if(ERROR_MAPPING.containsKey(error.getDefaultMessage())){
					apiError.setMessage(ERROR_MAPPING.get(error.getDefaultMessage()));
				} else continue;

				exceptionList.add(apiError);
			}else{
				msg.append(error.getField());
				msg.append(" ");
				msg.append(error.getDefaultMessage());
				apiError.setCode(PAYMENT_MOD_ERR_004);
				apiError.setMessage(msg.toString());
				exceptionList.add(apiError);
			}
		}
		for (ObjectError error : ex.getBindingResult().getGlobalErrors()) {
			StringBuilder msg = new StringBuilder();
			msg.append(error.getObjectName());
			msg.append(" ");
			msg.append(error.getDefaultMessage());
			Exception apiError = new Exception();
			apiError.setCode(PAYMENT_MOD_ERR_004);
			apiError.setMessage(msg.toString());
			exceptionList.add(apiError);
		}
		
		PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
		exResponse.setExceptions(exceptionList);
		
		return handleExceptionInternal(ex, exResponse, headers, HttpStatus.BAD_REQUEST, request);
	}
	
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<Exception> exceptionList= new ArrayList<Exception>();
		Exception apiError = new Exception();
		apiError.setCode(PAYMENT_MOD_ERR_004);
		apiError.setMessage(PAYMENT_MOD_MISSING_PARAMETERS);
		exceptionList.add(apiError);
		
		PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
		exResponse.setExceptions(exceptionList);
		
		return handleExceptionInternal(ex, exResponse, headers, HttpStatus.BAD_REQUEST, request);
	}

}
