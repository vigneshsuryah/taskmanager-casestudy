package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class CommunicationDetails {

	@Field("email_id")
	private String emailId;
	@Field("mailing_address")
	private MailingAddress mailingAddress;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public MailingAddress getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(MailingAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

}
