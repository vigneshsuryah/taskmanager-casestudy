package com.anthem.payment.paymod.model;

public class CancelDetails {

	private boolean isCsr;
	private String paymentChannel;
	private String cancelledBy;
	
	public boolean isCsr() {
		return isCsr;
	}
	public void setCsr(boolean isCsr) {
		this.isCsr = isCsr;
	}
	public String getCancelledBy() {
		return cancelledBy;
	}
	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}
	public String getPaymentChannel() {
		return paymentChannel;
	}
	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}
	
}
