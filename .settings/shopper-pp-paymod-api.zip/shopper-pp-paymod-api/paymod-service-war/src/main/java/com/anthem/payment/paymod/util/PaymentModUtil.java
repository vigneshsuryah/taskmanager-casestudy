package com.anthem.payment.paymod.util;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.anthem.payment.paymod.handler.PaymentModException;
import com.fasterxml.uuid.Generators;

@Component
public class PaymentModUtil implements PaymentModConstants {
	
	private static ResourceBundle resourceBundle = ResourceBundle.getBundle("chase_errorcode_mapping",Locale.ENGLISH);
	
	private final static Logger LOGGER = LoggerFactory.getLogger(PaymentModUtil.class);

	public String getOrderIdForPayModSubmit(){
		try {
			SecureRandom random = new SecureRandom();
			return new BigInteger(130, random).toString(32);
		} catch (Exception e) {
			return "213987282a";
		}
	}
	
	public String getMessageBundleValue(String key)
	{
		String displayStatusString = "";
		try
		{
			displayStatusString = resourceBundle.getString(key);
		}catch(Exception e)
		{
			LOGGER.debug("getMessageBundleValue error for key : " + key);
		}
		return displayStatusString;
	}
	
	public List<com.anthem.payment.paymod.response.Exception> buildExceptionsList(String errroDesc,Map<String,String> errorMap,String type){	
		List<com.anthem.payment.paymod.response.Exception> exceptionList= new ArrayList<>(errorMap.size());
		for(Map.Entry<String,String> entry:errorMap.entrySet()){
			com.anthem.payment.paymod.response.Exception exceptions= new com.anthem.payment.paymod.response.Exception();
			exceptions.setCode(entry.getKey());
			exceptions.setMessage(entry.getValue());
			exceptionList.add(exceptions);
		}				
		return exceptionList;
	}
	
	public boolean isRoutingNoValid(String routingNo)
	{
		final int FIRST_MULTIPLER = 3;
		final int SECOND_MULTIPLER = 7;
		final int THIRD_MULTIPLER = 1;
		if (!StringUtils.isNumeric(routingNo) || routingNo.length() != 9)
		{
			return false;
		}
		char[] routingArray = routingNo.toCharArray();
		int firstNumber = Integer.parseInt(String.valueOf(routingArray[0]));
		int secondNumber = Integer.parseInt(String.valueOf(routingArray[1]));
		int thridNumber = Integer.parseInt(String.valueOf(routingArray[2]));
		int fourthNumber = Integer.parseInt(String.valueOf(routingArray[3]));
		int fifthNumber = Integer.parseInt(String.valueOf(routingArray[4]));
		int sixthNumber = Integer.parseInt(String.valueOf(routingArray[5]));
		int seventhNumber = Integer.parseInt(String.valueOf(routingArray[6]));
		int eighthNumber = Integer.parseInt(String.valueOf(routingArray[7]));
		int checkDigit = Integer.parseInt(String.valueOf(routingArray[8]));
		int productsSumOrg = (firstNumber * FIRST_MULTIPLER) + (fourthNumber * FIRST_MULTIPLER) + (seventhNumber * FIRST_MULTIPLER)
				+ (secondNumber * SECOND_MULTIPLER) + (fifthNumber * SECOND_MULTIPLER) + (eighthNumber * SECOND_MULTIPLER)
				+ (thridNumber * THIRD_MULTIPLER) + (sixthNumber * THIRD_MULTIPLER);
		int productsSumArr = productsSumOrg;
		if (productsSumOrg % 10 > 0)
		{
			productsSumArr = productsSumOrg + (10 - productsSumOrg % 10);
		}
		if (productsSumArr - productsSumOrg == checkDigit)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public String getRandomString(int length) {	
		String randomString = "";
		try {
			SecureRandom secureRandom = new SecureRandom();
			String letters = "ABCDEFGHJKMNPQRSTUVWXYZ";
			String numbers = "0123456789";
			int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
			int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
			String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
			String shortId = RandomStringUtils.random(10, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			randomString = randomChar + shortId;
		}catch(Exception e) {
			LOGGER.error("Error occured in getRandomString : " + e);
		}
		return randomString;
	}
	
	public String generateTokenId() {	
		UUID uuid1 = Generators.timeBasedGenerator().generate();
		return uuid1.toString().replace("-", "");
	}
	
	//PP-16301, PP-16303 - Start
	public String generateOrderId(String payChannel) {
		String orderId = "";
		try {
			Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
            SecureRandom secureRandom = new SecureRandom();
            String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
            String numbers = "0123456789";
            int letterIndex = (int)(secureRandom.nextDouble()*letters.length());
            int numberIndex = (int)(secureRandom.nextDouble()*numbers.length());
            String randomChar = letters.substring(letterIndex, letterIndex+1) + numbers.substring(numberIndex, numberIndex+1);
            String shortId = RandomStringUtils.random(7, "0123456789");
            orderId = payChannel + dateFormat.format(date) + randomChar + shortId;
		} catch (Exception e) {
			LOGGER.error("Exception in PaymentModUtil generateOrderId " + e);
		}
		if(orderId != null && StringUtils.isNotBlank(orderId) && StringUtils.isNotEmpty(orderId)) {
			orderId = orderId.toLowerCase();
		}
		return orderId;
	}
	
	public String maskString(String strText, int start, int end, char maskChar) throws PaymentModException {
		String maskedStr = "";
		try{
			if(strText == null || strText.equals(""))
				return "";

			if(start < 0)
				start = 0;

			if( end > strText.length() )
				end = strText.length();

			if(start > end){
				LOGGER.error("End index cannot be greater than start index");
				throw new PaymentModException("PP9000", TECHINICAL_ERROR_MSG);
			}

			int maskLength = end - start;

			if(maskLength == 0)
				return strText;

			String strMaskString = org.apache.commons.lang3.StringUtils.repeat(maskChar, maskLength);
			maskedStr = org.apache.commons.lang3.StringUtils.overlay(strText, strMaskString, start, end);
		}catch(Exception e){
			LOGGER.error("Exception in maskString"+e);
		}
		return maskedStr;
	}
	
	public boolean validateCCExpirationString(String expString) {
		boolean flag = true;
		DateFormat dateFormatYear = new SimpleDateFormat("yyyy");
		DateFormat dateFormatMonth = new SimpleDateFormat("MM");
		String currentYearString = dateFormatYear.format(Calendar.getInstance().getTime());
		int currentYear = Integer.parseInt(currentYearString);
		String currentMonthString = dateFormatMonth.format(Calendar.getInstance().getTime());
		int currentMonth = Integer.parseInt(currentMonthString);
		if (expString != null && !expString.isEmpty())
		{
			String[] expArr = {};
			expArr = expString.split("/");
			if(expArr.length == 2 && expArr[0].length() == 2 && expArr[1].length() == 4) {
				int month = 0;
				int year = 0;
				try {
					month = Integer.parseInt(expArr[0]);
					year = Integer.parseInt(expArr[1]);
				}catch(Exception e) {
					LOGGER.error("Error in validateCCExpirationString");
				}
				if(year > currentYear) {
                    if(month < 1 || month > 12) {
                           flag = false;
                    }else {
                           flag = true;
                    }
		         }else if(year == currentYear) {
	                if(month < currentMonth || month > 12) {
	                       flag = false;
	                }else {
	                       flag = true;
	                }
		         }else {
		            flag = false;
		         }
			}else {
				flag = false;
			}
		}else {
			flag = false;
		}
		return flag;
	}
	//PP-16301, PP-16303 - End
}
