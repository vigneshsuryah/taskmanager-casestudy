package com.anthem.payment.paymod.handler;

import java.io.Serializable;

public class PaymentModException extends Exception implements Serializable {	
	
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String errorMessage;
	private Throwable exception;

	public PaymentModException(String errorCode, String errorMessage)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public PaymentModException() {

	}

	public PaymentModException(String message) {
		this.errorMessage = message;
	}

	public PaymentModException(Throwable exception, String message) {
		this.errorMessage = message;
		this.exception =exception;
	}
	
	public PaymentModException(String errorCode, String errorMessage, Throwable exception) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.exception = exception;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Throwable getException() {
		return exception;
	}

	public void setException(Throwable exception) {
		this.exception = exception;
	}
	
}