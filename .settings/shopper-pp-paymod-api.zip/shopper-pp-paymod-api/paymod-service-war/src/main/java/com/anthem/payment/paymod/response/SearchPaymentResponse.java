package com.anthem.payment.paymod.response;

import java.util.List;

import com.anthem.payment.paymod.model.PaymentDetailsVO;

public class SearchPaymentResponse extends BaseResponse {

	private static final long serialVersionUID = 1843992260675624013L;

	private List<PaymentDetailsVO> paymentDetailsVOs;

	public List<PaymentDetailsVO> getPaymentDetailsVOs() {
		return paymentDetailsVOs;
	}

	public void setPaymentDetailsVOs(List<PaymentDetailsVO> paymentDetailsVOs) {
		this.paymentDetailsVOs = paymentDetailsVOs;
	}

}

