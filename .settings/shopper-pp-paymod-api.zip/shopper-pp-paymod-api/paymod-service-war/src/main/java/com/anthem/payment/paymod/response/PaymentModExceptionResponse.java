package com.anthem.payment.paymod.response;

import java.util.List;

public class PaymentModExceptionResponse extends BaseResponse {

	private static final long serialVersionUID = 1L;
	private List<Exception> exceptions;

	public List<Exception> getExceptions() {
		return exceptions;
	}

	public void setExceptions(List<Exception> asList) {
		this.exceptions = asList;
	}
}
