/**
 * ValidateBankAccNoRequest.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.request;
import org.hibernate.validator.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="ValidateBankAccNoRequest")
public class ValidateBankAccNoRequest extends BaseRequest{

	private static final long serialVersionUID = 8184258874643852945L;

	@NotBlank
	private String bankAccNo;
	
	@NotBlank
	private String confirmBankAccNo;
	
	@ApiModelProperty(required=true)
	public String getBankAccNo() {
		return bankAccNo;
	}

	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}

	@ApiModelProperty(required=true)
	public String getConfirmBankAccNo() {
		return confirmBankAccNo;
	}

	public void setConfirmBankAccNo(String confirmBankAccNo) {
		this.confirmBankAccNo = confirmBankAccNo;
	}

}
