package com.anthem.payment.paymod.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.payment.paymod.entity.TransactionDivision;

@Repository
public interface TransactionDivisionRepository extends MongoRepository<TransactionDivision, String>{

	@Query(value = "{ 'sys_code' : ?0, 'legal_code' : ?1, 'mrkt_sgmt' : ?2}")
	List<TransactionDivision> getTransactionDivision(String systemCode, String legalCode, String marketSegment);

}
