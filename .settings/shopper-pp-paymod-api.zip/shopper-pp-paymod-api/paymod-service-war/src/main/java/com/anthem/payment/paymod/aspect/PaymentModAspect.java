package com.anthem.payment.paymod.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.anthem.payment.paymod.config.ApplicationProperties;
import com.anthem.payment.paymod.handler.PaymentModException;
import com.anthem.payment.paymod.util.PaymentModConstants;
import com.anthem.payment.paymod.util.PaymentModProviderUtils;

@Aspect
@Component
@Order(1)
public class PaymentModAspect implements PaymentModConstants {
	
	@Autowired
	ApplicationProperties applicationProperties;
	
	final static Logger LOGGER = LoggerFactory.getLogger(PaymentModAspect.class);

	@Before("execution(* com.anthem.payment.paymod.controller.PaymentModServiceController.*(..))")
	public void logBefore(JoinPoint joinPoint) throws PaymentModException {
		Object[] objs = joinPoint.getArgs();
		LOGGER.info("PaymentChaseAspect : About to intercept request - start");
		boolean hasHttpHeaders = false;
		for (Object obj : objs)
		{
			if (obj instanceof HttpHeaders)
			{
				hasHttpHeaders = true;
				String metaSenderAppCheckFlag = applicationProperties.getStringProperty("paymod.setting.check.metasenderapp.value", "N");
				HttpHeaders headers = (HttpHeaders) obj;
				String requestingApplication = headers.getFirst(PAYMENT_MOD_REQ_APPLICATION);
				String headerUsername = headers.getFirst(PAYMENT_MOD_USERNAME);
				String headerPassword = headers.getFirst(PAYMENT_MOD_AUTH_KEY);
				
				if (requestingApplication == null || headerUsername == null || headerPassword == null) {
					LOGGER.error("Access Denied....Request header missing");
					throw new PaymentModException(PAYMENT_MOD_ERR_9001_REQ_MISSING, PAYMENT_MOD_ERR_9001_REQ_MISSING_DESC, new IllegalAccessException());
				}
				
				String allowedApplication =  applicationProperties.getStringProperty("paymod.setting.payment.ui.restconsumer.service.allowed.applications", "");
				String secureUserName = applicationProperties.getStringProperty("paymod.setting.payment.ui.restconsumer.service.username."+requestingApplication, "");
				String securePassword = applicationProperties.getStringProperty("paymod.setting.payment.ui.restconsumer.service.password."+requestingApplication, "");
				String secureAlgorithm = applicationProperties.getStringProperty("paymod.setting.payment.ui.restconsumer.service.algorithm."+requestingApplication, "");
				String secureKey = applicationProperties.getStringProperty("paymod.setting.payment.ui.restconsumer.service.key."+requestingApplication, "");
				
				if(metaSenderAppCheckFlag != null && metaSenderAppCheckFlag.equalsIgnoreCase("Y"))
				{  
					if(null == allowedApplication || allowedApplication.isEmpty() || null == requestingApplication || requestingApplication.isEmpty() || 
							!PaymentModProviderUtils.authenticateRequestingApplication(requestingApplication, allowedApplication))
					{
						LOGGER.error("Access Denied. In-Valid Requesting Application");
						throw new PaymentModException(PAYMENT_MOD_ERR_9004, PAYMENT_MOD_ERR_9004_DESC, new IllegalAccessException());
					}
				}   
				
				if (headerUsername != null
						&& !PaymentModProviderUtils.authenticateUserName(headerUsername, secureUserName))
				{
					LOGGER.error("Access denied In-Valid User Name");
					throw new PaymentModException(PAYMENT_MOD_ERR_9002, PAYMENT_MOD_ERR_9002_DESC, new IllegalAccessException());
				}
				
				
				if (headerPassword != null
						&& !PaymentModProviderUtils.authenticatePassword(headerPassword, secureKey,
								secureAlgorithm, securePassword))
				{
					LOGGER.error("Access denied In-Valid Password");
					throw new PaymentModException(PAYMENT_MOD_ERR_9003, PAYMENT_MOD_ERR_9003_DESC, new IllegalAccessException());
				}
			}
		}
		
		if(!hasHttpHeaders) {
			LOGGER.error("Access denied illegal request");
			throw new PaymentModException(PAYMENT_MOD_ERR_9001_ILLEGAL_REQ, PAYMENT_MOD_ERR_9001_ILLEGAL_REQ_DESC, new IllegalAccessException());
		}
		LOGGER.info("PaymentChaseAspect : About to intercept request - end");
	}

	/*@AfterThrowing(pointcut = "execution(* com.wellpoint.payment.chase.datasvc.service.*.*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
		LOGGER.error("Suspected error in the request::" + error);
	}*/

}