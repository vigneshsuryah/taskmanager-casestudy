package com.anthem.payment.paymod.request;

import java.io.Serializable;

import com.anthem.payment.paymod.model.CommunicationDetails;
import com.anthem.payment.paymod.model.Note;

public class CancelPaymentRequest extends BaseRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String orderId;
	private Note notes;
	private String cancelledBy;
	private String paymentChannel;
	private boolean csrFlag;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public Note getNotes() {
		return notes;
	}

	public void setNotes(Note notes) {
		this.notes = notes;
	}

	public boolean isCsrFlag() {
		return csrFlag;
	}

	public void setCsrFlag(boolean csrFlag) {
		this.csrFlag = csrFlag;
	}

	public String getPaymentChannel() {
		return paymentChannel;
	}

	public void setPaymentChannel(String paymentChannel) {
		this.paymentChannel = paymentChannel;
	}

}
