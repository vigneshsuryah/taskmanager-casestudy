package com.anthem.payment.paymod.response;

import java.io.Serializable;

public class SubmitPaymentResponse extends BaseResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String status;
	private String orderId;
	private String matchId;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getMatchId() {
		return matchId;
	}

	public void setMatchId(String matchId) {
		this.matchId = matchId;
	}

}
