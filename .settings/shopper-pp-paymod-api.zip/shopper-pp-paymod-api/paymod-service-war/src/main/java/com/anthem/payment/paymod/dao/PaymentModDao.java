package com.anthem.payment.paymod.dao;

public interface PaymentModDao {

}
