package com.anthem.payment.paymod.controller;

import com.anthem.payment.paymod.response.*;
import com.anthem.payment.paymod.response.Exception;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.payment.paymod.handler.PaymentModException;
import com.anthem.payment.paymod.request.CancelPaymentRequest;
import com.anthem.payment.paymod.request.GetPaymentMethodRequest;
import com.anthem.payment.paymod.response.CancelPaymentResponse;
import com.anthem.payment.paymod.request.GetTokenRequest;
import com.anthem.payment.paymod.request.MamDetailsBO;
import com.anthem.payment.paymod.request.RefundPaymentRequest;
import com.anthem.payment.paymod.request.SearchRefundRequest;
import com.anthem.payment.paymod.request.SearchPaymentRequest;
import com.anthem.payment.paymod.request.SubmitPaymentRequest;
import com.anthem.payment.paymod.request.UpdatePaymentMethodRequest;
import com.anthem.payment.paymod.request.ValidateRoutingNoRequest;
import com.anthem.payment.paymod.service.PaymentModService;
import com.anthem.payment.paymod.util.PaymentModConstants;
import com.anthem.payment.paymod.validator.ValidationUtils;

@RestController
@SuppressWarnings({ "rawtypes", "unchecked" })
public class PaymentModServiceController implements PaymentModConstants {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(PaymentModServiceController.class);
	
	@Autowired
	private PaymentModService paymentModService;

	@RequestMapping(value = "/v1/searchPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Search Payment Information", notes = "The api call is used to search the payment information")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = SearchPaymentResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> searchPayment(@RequestBody @Valid SearchPaymentRequest searchPaymentRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside search payment - start");
		
		SearchPaymentResponse searchPaymentResponse = paymentModService.searchPayment(searchPaymentRequest);
		
		LOGGER.info("PaymentModServiceController: Inside search payment - end");

		return new ResponseEntity(searchPaymentResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/submitPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Submit Payment", notes = "The api call is used to Submit the payment")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = SubmitPaymentResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> submitPayment(@RequestBody @Valid SubmitPaymentRequest submitPaymentRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside submit payment - start");
		
		SubmitPaymentResponse submitPaymentResponse = paymentModService.submitPayment(submitPaymentRequest);
		
		LOGGER.info("PaymentModServiceController: Inside submit payment - end");

		return new ResponseEntity(submitPaymentResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/cancelPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Cancel Payment", notes = "The api call is used to cancel the payment")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = CancelPaymentResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> cancelPayment(@RequestBody @Valid CancelPaymentRequest cancelPaymentRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside cancel payment - start");
		
		CancelPaymentResponse cancelPaymentResponse = paymentModService.cancelPayment(cancelPaymentRequest);
		
		LOGGER.info("PaymentModServiceController: Inside cancel payment - end");

		return new ResponseEntity(cancelPaymentResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/refundSearch", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Refund Payment", notes = "The api call is used to fetch the refund results based on the HCID or Order ID")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = ValidateRoutingNoResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })

	public ResponseEntity<SearchRefundResponse> refundSearch(@RequestBody SearchRefundRequest searchRefundRequest, @RequestHeader HttpHeaders headers) throws PaymentModException {
		
		LOGGER.info("PaymentModServiceController: Inside refundSearch - start");
		if(null != headers.getFirst("lob") && !headers.getFirst("lob").isEmpty()){
			searchRefundRequest.setLob(headers.getFirst("lob"));
		}else{
			searchRefundRequest.setLob("");
		}
		if(null != headers.getFirst("isMasked") && !headers.getFirst("isMasked").isEmpty()){
			searchRefundRequest.setIsMasked(headers.getFirst("isMasked"));
		}else{
			searchRefundRequest.setIsMasked("");
		}
		
		SearchRefundResponse searchRefundResponse = paymentModService.refundSearch(searchRefundRequest);
		LOGGER.info("PaymentModServiceController: Inside refundSearch - end");
		return new ResponseEntity(searchRefundResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/refundPayment", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Refund Payment", notes = "The api call is used to refund the payment")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = ValidateRoutingNoResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })

	public ResponseEntity<RefundPaymentResponse> refundPayment(@RequestBody RefundPaymentRequest refundPaymentRequest, @RequestHeader HttpHeaders headers) throws PaymentModException {
		
		LOGGER.info("PaymentModServiceController: Inside refundPayment - start");
		if(headers.getFirst("lob") != null && !headers.getFirst("lob").isEmpty()){
			refundPaymentRequest.setLob(headers.getFirst("lob"));
		}else{
			refundPaymentRequest.setLob("");
		}
		if(headers.getFirst("csrId") != null && !headers.getFirst("csrId").isEmpty()){
			refundPaymentRequest.setCsrId(headers.getFirst("csrId"));
		}
		RefundPaymentResponse refundResponse = paymentModService.refundPayment(refundPaymentRequest);
		LOGGER.info("PaymentModServiceController: Inside refundPayment - end");
		return new ResponseEntity(refundResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/getToken", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Token", notes = "The api call is used to token for the paymnent method")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = GetTokenResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })

	public ResponseEntity<RefundPaymentResponse> getToken(@RequestBody GetTokenRequest getTokenRequest, @RequestHeader HttpHeaders headers) throws PaymentModException {
		
		LOGGER.info("PaymentModServiceController: Inside getToken - start");

		GetTokenResponse getTokenResponse = paymentModService.getTokenInformation(getTokenRequest, "AU");
		
		if(StringUtils.isEmpty(getTokenResponse.getEncryptedToken())) {
			PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
			Map<String, String> errorMap = new HashMap<>();
			if(getTokenResponse.getExceptionDetails() != null && getTokenResponse.getExceptionDetails().getCode() != null && !getTokenResponse.getExceptionDetails().getCode().isEmpty()) {
				errorMap.put(getTokenResponse.getExceptionDetails().getCode(), getTokenResponse.getExceptionDetails().getMessage());
			}else {
				errorMap.put(PAYMENT_MOD_ERR_9123, PAYMENT_MOD_CHASE_ERR_MSG);
			}
			exResponse.setExceptions(buildExceptionsList(PAYMENT_MOD_REQ_PROC_ERROR, errorMap, PAYMENT_MOD_TECH_ERROR_CODE));
			return new ResponseEntity(exResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		LOGGER.info("PaymentModServiceController: Inside getToken - end");
		
		return new ResponseEntity(getTokenResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/getTransactionDivision", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Token", notes = "The api call is used to get the transaction division for the market segment, legal code and system code")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = MamDetailsBO.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })

	public ResponseEntity<MamDetailsBO> getTransactionDivision(@RequestBody @Valid MamDetailsBO request, @RequestHeader HttpHeaders headers) throws PaymentModException {
		
		LOGGER.info("PaymentModServiceController: Inside getTransactionDivision - start");

		MamDetailsBO mamDetailsBO = paymentModService.getTransactionDivision(request);
		
		if(StringUtils.isEmpty(mamDetailsBO.getDivisionCode())) {
			PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
			Map<String, String> errorMap = new HashMap<>();
			errorMap.put(PAYMENT_MOD_ERR_9123, PAYMENT_MOD_CHASE_ERR_MSG);
			exResponse.setExceptions(buildExceptionsList(PAYMENT_MOD_REQ_PROC_ERROR, errorMap, PAYMENT_MOD_TECH_ERROR_CODE));
			return new ResponseEntity(exResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		LOGGER.info("PaymentModServiceController: Inside getTransactionDivision - end");
		
		return new ResponseEntity(mamDetailsBO, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/validateRoutingNumber", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Validate routing number", notes = "The api call is used to validate the routing number")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = ValidateRoutingNoResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> validateRoutingNumber(@RequestBody ValidateRoutingNoRequest validateRoutingNoRequest, @RequestHeader HttpHeaders headers) throws PaymentModException {

		LOGGER.info("ChaseController: Inside validateRoutingNo - start");
		PaymentModExceptionResponse exResponse = new PaymentModExceptionResponse();
		Map<String, String> errorMap = new HashMap<>();
		if (!ValidationUtils.checkNull(validateRoutingNoRequest)) {
			errorMap.put(PAYMENT_MOD_ERR_9108, PAYMENT_MOD_REQUIRED);
			exResponse.setExceptions(buildExceptionsList(PAYMENT_MOD_VALIDATION_ERROR, errorMap, PAYMENT_MOD_ERR_TYPE_ERROR));
			return new ResponseEntity<>(exResponse, HttpStatus.BAD_REQUEST);
		}

		ValidateRoutingNoResponse validateRoutingNoResponse = new ValidateRoutingNoResponse();

		errorMap = ValidationUtils.validateBankDetails(validateRoutingNoRequest);
		if (!errorMap.isEmpty()) {

			exResponse.setExceptions(buildExceptionsList(PAYMENT_MOD_VALIDATION_ERROR, errorMap, PAYMENT_MOD_ERR_TYPE_ERROR));
			return new ResponseEntity(exResponse, HttpStatus.BAD_REQUEST);
		}
		boolean isValid = false;
		if (validateRoutingNoRequest != null) {
			isValid = ValidationUtils.isValidRoutingNo(validateRoutingNoRequest.getRoutingNumber());
		}
		validateRoutingNoResponse.setValid(isValid);
		LOGGER.info("ChaseController: Inside validateRoutingNo - end");
		return new ResponseEntity(validateRoutingNoResponse, HttpStatus.OK);
	}
	
	//PP-16301, PP-16303 - Start
	@RequestMapping(value = "/v1/getPaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Method", notes = "The api call is used to get payment method information")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = GetPaymentMethodResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getPaymentMethods(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside getPaymentMethods - start");
		
		GetPaymentMethodResponse getPaymentMethodResponse = paymentModService.getPaymentMethods(getPaymentMethodRequest);
		
		LOGGER.info("PaymentModServiceController: Inside getPaymentMethods - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/v1/updatePaymentMethods", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Update Payment Method", notes = "The api call is used to update payment method")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = UpdatePaymentMethodResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> updatePaymentMethods(@RequestBody @Valid UpdatePaymentMethodRequest updatePaymentMethodRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside updatePaymentMethods - start");
		
		UpdatePaymentMethodResponse updatePaymentMethodResponse = paymentModService.updatePaymentMethod(updatePaymentMethodRequest);
		
		LOGGER.info("PaymentModServiceController: Inside updatePaymentMethods - end");

		return new ResponseEntity(updatePaymentMethodResponse, HttpStatus.OK);
	}
	//PP-16301, PP-16303 - End
	
	@RequestMapping(value = "/v1/getWalletInformation", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Wallet Information", notes = "The api call is used to get the wallet information based on the token id")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = GetPaymentMethodResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getWalletInformation(@RequestBody @Valid GetPaymentMethodRequest getPaymentMethodRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside getWalletInformation - start");
		
		GetPaymentMethodResponse getPaymentMethodResponse = paymentModService.getWalletInformation(getPaymentMethodRequest);
		
		LOGGER.info("PaymentModServiceController: Inside getWalletInformation - end");

		return new ResponseEntity(getPaymentMethodResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/getPaymentDetails", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = { APPLICATION_TYPE_JSON }, produces = {
			APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	@ApiOperation(value = "Get Payment Details", notes = "The api call is used to get the payment details based on the hcid and lob")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = GetPaymentMethodResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })
	public ResponseEntity<BaseResponse> getPaymentDetails(@RequestBody @Valid SearchRefundRequest searchRefundRequest, @RequestHeader HttpHeaders headers) throws PaymentModException  {
		
		LOGGER.info("PaymentModServiceController: Inside getPaymentDetails - start");
		SearchRefundResponse searchRefundResponse = paymentModService.getPaymentDetails(searchRefundRequest);
		LOGGER.info("PaymentModServiceController: Inside getPaymentDetails - end");
		return new ResponseEntity(searchRefundResponse, HttpStatus.OK);
	}
	
	private List<Exception> buildExceptionsList(String errroDesc,Map<String,String> errorMap,String type){	
		List<Exception> exceptionList= new ArrayList<>(errorMap.size());
		for(Map.Entry<String,String> entry:errorMap.entrySet()){
			Exception exceptions= new Exception();
			exceptions.setCode(entry.getKey());
			exceptions.setMessage(entry.getValue());
			exceptionList.add(exceptions);
		}				
		return exceptionList;
	}
}
