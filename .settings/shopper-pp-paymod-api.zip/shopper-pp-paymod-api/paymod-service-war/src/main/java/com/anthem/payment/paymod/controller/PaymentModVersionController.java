package com.anthem.payment.paymod.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.payment.paymod.request.GetTokenRequest;
import com.anthem.payment.paymod.response.GetTokenResponse;
import com.anthem.payment.paymod.response.PaymentModExceptionResponse;
import com.anthem.payment.paymod.response.PaymentModVersionResponse;
import com.anthem.payment.paymod.service.PaymentModService;
import com.anthem.payment.paymod.util.PaymentModConstants;

@RestController
public class PaymentModVersionController implements PaymentModConstants {

	private final static Logger LOGGER = LoggerFactory.getLogger(PaymentModVersionController.class);
	
	@Value("${paymod.application.version}")
	private String version;

	@Autowired
	private PaymentModService paymentModService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(path = "/version", method= RequestMethod.GET)
	@ApiOperation(value = "Get Application version", notes = "The api call is used to check the application version")
	@ApiResponses({
			@ApiResponse(code = 200, message = PAYMENT_MOD_SUCCESS_STATUS, response = PaymentModVersionResponse.class),
			@ApiResponse(code = 400, message = PAYMENT_MOD_BAD_REQUEST, response = PaymentModExceptionResponse.class),
			@ApiResponse(code = 500, message = PAYMENT_MOD_SERVICE_NOT_AVAILABLE, response = PaymentModExceptionResponse.class) })

	public ResponseEntity<PaymentModVersionResponse> getVersion() {
		LOGGER.info("PaymentModVersionController: Inside show version - start");
		
		GetTokenRequest getTokenRequest = new GetTokenRequest();
		getTokenRequest.setAccountNumber("31432ytrwq");
		
		GetTokenResponse rsp = paymentModService.getTokenInformation(getTokenRequest, "AU");
		
		System.out.println("############### RSP *********** " + rsp.getEncryptedToken());

		PaymentModVersionResponse response = new PaymentModVersionResponse();
		response.setApplicationVersion(version);
		
		LOGGER.info("PaymentModVersionController: Inside show version - end");
		
		return new ResponseEntity(response, HttpStatus.OK);
	}

}