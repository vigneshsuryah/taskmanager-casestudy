package com.anthem.payment.paymod.response;

import org.springframework.stereotype.Component;

@Component
public class PaymentModVersionResponse {

	private String applicationVersion;

	public String getApplicationVersion() {
		return applicationVersion;
	}

	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}

}
