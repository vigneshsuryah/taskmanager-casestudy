/**
 * ValidationUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 12/28/2018  1.0      Cognizant       Initial Version
 */
package com.anthem.payment.paymod.validator;

import java.util.HashMap;
import java.util.Map;

import com.anthem.payment.paymod.request.GetTokenRequest;
import org.apache.commons.lang3.StringUtils;

import com.anthem.payment.paymod.request.ValidateBankAccNoRequest;
import com.anthem.payment.paymod.request.ValidateRoutingNoRequest;
import com.anthem.payment.paymod.util.PaymentModConstants;
import com.anthem.payment.paymod.util.RoutingNoValidatorUtils;

public class ValidationUtils implements PaymentModConstants {
	
	private static final int ACCOUNT_NO_MIN = 4;
	private static final int ACCOUNT_NO_MAX = 17;
	private static final int ROUTING_NO_LEN = 9;
    private static final int CC_LENGTH = 16;

    public static boolean isValidRoutingNo(String routingNo) {
		if (!RoutingNoValidatorUtils.isRoutingNoValid(routingNo)) {
			return false;
		} else {
			return true;
		}
	}

	public static Map<String, String> validate(ValidateBankAccNoRequest request) {
		Map<String, String> errorMap = new HashMap<>();
		if (!isValidAccountNo(request.getBankAccNo()) || !isValidAccountNo(request.getConfirmBankAccNo())) {
			errorMap.put(PAYMENT_MOD_ERR_001, PAYMENT_MOD_ERR_MSG_001);
		}

		if (null != request.getBankAccNo() && !request.getBankAccNo().equalsIgnoreCase(request.getConfirmBankAccNo())) {
			errorMap.put(PAYMENT_MOD_ERR_002,PAYMENT_MOD_ERR_MSG_002);
		}

		return errorMap;
	}

	public static boolean isValidAccountNo(String accountNo) {
		if(!StringUtils.isNumeric(accountNo) || accountNo.length() < ACCOUNT_NO_MIN
				|| accountNo.length() > ACCOUNT_NO_MAX) {
			return false;
		} else {
			return true;
		}
	}
	
	public static boolean checkRoutingNo(String routingNo) {
		if(!StringUtils.isNumeric(routingNo) || routingNo.length() != ROUTING_NO_LEN) {
			return false;
		} else {
			return true;
		}
	}

	public static Map<String, String> validateBankDetails(ValidateRoutingNoRequest request) {
		Map<String, String> errorMap = new HashMap<>();
		if (!checkRoutingNo(request.getRoutingNumber())) {
			errorMap.put(PAYMENT_MOD_ERR_9111, PAYMENT_MOD_ERR_MSG_9111);
		}if(!StringUtils.isNumeric(request.getRoutingNumber())){
			errorMap.put(PAYMENT_MOD_ERR_9116, PAYMENT_MOD_ERR_MSG_9116);
		}
		errorMap.putAll(checkAcntNo(request.getAccountNumber(), request.getConfirmAccountNumber()));

		return errorMap;
	}

	private static Map<String, String> checkAcntNo(String bankAccNo, String confirmBankAccNo) {
		Map<String, String> errorMap = new HashMap<>();

		if (StringUtils.isNotEmpty(bankAccNo) && StringUtils.isNotBlank(bankAccNo)
				&& StringUtils.isNotBlank(confirmBankAccNo) && StringUtils.isNotEmpty(confirmBankAccNo)) {

			if (!isValidAccountNo(bankAccNo) || !isValidAccountNo(confirmBankAccNo)) {
				errorMap.put(PAYMENT_MOD_ERR_9112, PAYMENT_MOD_ERR_MSG_9112);
			}
			if (!bankAccNo.equalsIgnoreCase(confirmBankAccNo)) {
				errorMap.put(PAYMENT_MOD_ERR_9125, PAYMENT_MOD_ERR_MSG_9125);
			}
		}
		return errorMap;
	}

	public static boolean checkNull(ValidateRoutingNoRequest validateRoutingNoRequest) {

		String routingNumber = validateRoutingNoRequest.getRoutingNumber();
		String accNum = validateRoutingNoRequest.getAccountNumber();
		String confirmAccNum = validateRoutingNoRequest.getConfirmAccountNumber();

		if (StringUtils.isNotBlank(routingNumber) && StringUtils.isNotEmpty(routingNumber)) {
			if (!((StringUtils.isBlank(accNum) || StringUtils.isEmpty(accNum))
					^ (StringUtils.isBlank(confirmAccNum) || StringUtils.isEmpty(confirmAccNum)))) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		} else {
			return Boolean.FALSE;
		}
	}
}
