package com.anthem.payment.paymod.response;

import java.util.List;

import com.anthem.payment.paymod.model.PaymentDetailsVO;

public class SearchRefundResponse extends BaseResponse {

	private static final long serialVersionUID = 1843992260675624013L;

	private List<PaymentDetailsVO> paymentDetails;

	public List<PaymentDetailsVO> getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(List<PaymentDetailsVO> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	
}
