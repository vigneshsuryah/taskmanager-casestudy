package com.anthem.payment.paymod.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

public class AuditTrail {

	@Field("name_on_funding_account")
	private String nameOnFundingAcc;
	
	@Field("account_nickname")
	private String accNickName;
	
	@Field("fund_account_owner_full_address")
	private FundAccountOwnerFullAddress fundAccOwnerFullAddress;
	
	@Field("updated_dt")
	private Date updatedDt;

	@Field("updated_id")
	private String updatedId;
	
	@Field("status")
	private String status;
	
	@Field("expiration_month")
	private String expirationMonth;
	
	@Field("expiration_year")
	private String expirationYear;
	
	public String getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public String getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}
	
	public String getNameOnFundingAcc() {
		return nameOnFundingAcc;
	}

	public void setNameOnFundingAcc(String nameOnFundingAcc) {
		this.nameOnFundingAcc = nameOnFundingAcc;
	}

	public String getAccNickName() {
		return accNickName;
	}

	public void setAccNickName(String accNickName) {
		this.accNickName = accNickName;
	}

	public FundAccountOwnerFullAddress getFundAccOwnerFullAddress() {
		return fundAccOwnerFullAddress;
	}

	public void setFundAccOwnerFullAddress(FundAccountOwnerFullAddress fundAccOwnerFullAddress) {
		this.fundAccOwnerFullAddress = fundAccOwnerFullAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}

}
