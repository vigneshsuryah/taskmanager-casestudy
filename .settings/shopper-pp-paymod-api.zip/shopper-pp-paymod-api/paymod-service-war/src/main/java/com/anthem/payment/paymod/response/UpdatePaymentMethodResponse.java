package com.anthem.payment.paymod.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdatePaymentMethodResponse extends BaseResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String hcid;
	
	private String tokenId;

	private String errorMessage;
	
	private String errorCode;

	/**
	 * @return the hcid
	 */
	public String getHcid() {
		return hcid;
	}

	/**
	 * @param hcid the hcid to set
	 */
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	/**
	 * @return the tokenId
	 */
	public String getTokenId() {
		return tokenId;
	}

	/**
	 * @param tokenId the tokenId to set
	 */
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
