package com.anthem.payment.paymod.entity;

import org.springframework.data.mongodb.core.mapping.Field;

public class Note {

	
	@Field("csrId")
	private String csrId;
	@Field("note_desc")
	private String noteDesc;
	@Field("action")
	private String action;

	public String getCsrId() {
		return csrId;
	}
	public void setCsrId(String csrId) {
		this.csrId = csrId;
	}
	public String getNoteDesc() {
		return noteDesc;
	}
	public void setNoteDesc(String noteDesc) {
		this.noteDesc = noteDesc;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

}
