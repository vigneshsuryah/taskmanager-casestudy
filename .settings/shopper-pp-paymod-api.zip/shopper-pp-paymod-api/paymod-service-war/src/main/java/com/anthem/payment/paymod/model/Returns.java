package com.anthem.payment.paymod.model;

public class Returns {

	private String returnReasonCode;
	private String returnReasonDescription;
	private String nullificationDate;

	public String getReturnReasonCode() {
		return returnReasonCode;
	}

	public void setReturnReasonCode(String returnReasonCode) {
		this.returnReasonCode = returnReasonCode;
	}

	public String getReturnReasonDescription() {
		return returnReasonDescription;
	}

	public void setReturnReasonDescription(String returnReasonDescription) {
		this.returnReasonDescription = returnReasonDescription;
	}

	public String getNullificationDate() {
		return nullificationDate;
	}

	public void setNullificationDate(String nullificationDate) {
		this.nullificationDate = nullificationDate;
	}

}
