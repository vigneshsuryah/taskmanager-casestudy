package com.anthem.payment.paymod.util;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.payment.paymod.handler.PaymentModException;

public final class PaymentModEncryptionUtils implements PaymentModConstants {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentModEncryptionUtils.class);
	
	private PaymentModEncryptionUtils() {
	}

	/**
	 * 
	 * @param key
	 * @param algorithm
	 * @param encryptedText
	 * @return the decrypted string
	 * @throws PaymentChaseException
	 */
	public static String getDecryptedText(String key, String algorithm,
			String encryptedText) throws PaymentModException {
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String decryptedText = "";
		try {
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			decryptedText = standardPBEStringEncryptor.decrypt(encryptedText);
		} catch (Exception e) {
			LOGGER.error("PaymentChaseEncryptionUtils getDecryptedText error : "+e);
			throw new PaymentModException(PAYMENT_MOD_TECH_ERROR_CODE, PAYMENT_MOD_TECH_ERROR_MSG);
		}
		return decryptedText;
	}

	/**
	 * 
	 * @param key
	 * @param algorithm
	 * @param clearText
	 * @return the encrypted text
	 * @throws PaymentChaseException
	 */
	public static String getEncryptedText(String key, String algorithm,
			String clearText) throws PaymentModException {
		StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
		String encryptedText = "";
		try {
			standardPBEStringEncryptor.setPassword(key);
			standardPBEStringEncryptor.setAlgorithm(algorithm);
			encryptedText = standardPBEStringEncryptor.encrypt(clearText);
		} catch (Exception e) {
			LOGGER.error("PaymentChaseEncryptionUtils getEncryptedText error : "+e);
			throw new PaymentModException(PAYMENT_MOD_TECH_ERROR_CODE, PAYMENT_MOD_TECH_ERROR_MSG);
		}
		return encryptedText;
	}

}
