package com.anthem.payment.paymod.model;

import java.io.Serializable;

public class RequestHeader implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String userName;
	private String password;
	private String requestApplication;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequestApplication() {
		return requestApplication;
	}

	public void setRequestApplication(String requestApplication) {
		this.requestApplication = requestApplication;
	}
}