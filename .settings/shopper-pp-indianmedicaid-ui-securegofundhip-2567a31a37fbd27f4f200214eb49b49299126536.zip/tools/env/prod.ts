import { EnvConfig } from './env-config.interface';

const ProdConfig: EnvConfig = {
  ENV: 'PROD',
  API:'https://payment.anthem.com/paymentgateway/',
  loggingflag: false,
  encryptionurl: 'https://safetechpageencryption.chasepaymentech.com/pie/v1/encryption.js',
  keyjsurl:'https://safetechpageencryption.chasepaymentech.com/pie/v1/64100000000181/getkey.js'
};

export = ProdConfig;


