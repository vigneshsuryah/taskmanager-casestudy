import { EnvConfig } from './env-config.interface';

const PerfConfig: EnvConfig = {
  ENV: 'PERF',
  API:'https://shop.perf1.va.anthem.com/paymentgateway/',
  loggingflag: true,
  encryptionurl: 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/encryption.js',
  keyjsurl:'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/64100000000181/getkey.js'
};

export = PerfConfig;