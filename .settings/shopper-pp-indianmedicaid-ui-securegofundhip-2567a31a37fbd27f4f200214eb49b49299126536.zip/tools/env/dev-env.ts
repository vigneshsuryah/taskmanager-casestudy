import { EnvConfig } from './env-config.interface';

const DevConfig: EnvConfig = {
  ENV: 'DEV',
  API:'https://shop.dev2.va.anthem.com/paymentgateway/',
  loggingflag: false,
  encryptionurl: 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/encryption.js',
  keyjsurl:'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/64100000000181/getkey.js'
};

export = DevConfig;