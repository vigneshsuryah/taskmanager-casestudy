import { EnvConfig } from './env-config.interface';

const UatConfig: EnvConfig = {
  ENV: 'UAT',
  API:'https://payment.uat2.va.anthem.com/paymentgateway/',
  loggingflag: true,
  encryptionurl: 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/encryption.js',
  keyjsurl:'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/64100000000181/getkey.js'
};

export = UatConfig;