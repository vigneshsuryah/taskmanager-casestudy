import { EnvConfig } from './env-config.interface';

const DevConfig: EnvConfig = {
  ENV: 'LOCAL',
  API:'http://va10n10114.wellpoint.com:9080/paymentgateway/',
  loggingflag: true,
  encryptionurl: 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/encryption.js',
  keyjsurl:'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/64100000000181/getkey.js'
};

export = DevConfig;