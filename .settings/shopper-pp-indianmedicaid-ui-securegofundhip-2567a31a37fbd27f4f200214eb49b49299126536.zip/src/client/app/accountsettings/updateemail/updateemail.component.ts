import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/gbd-service/index';
declare var jQuery:any;
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-updateemail',
  templateUrl: 'updateemail.component.html',
  styleUrls: ['updateemail.component.css']
})
export class UpdateEmailComponent implements OnInit {
  emailData : any = {};
  screenLoader: boolean = false;
  showErrorMessage: boolean = false;
  inputParam: any = {};
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.emailData = {
      "newEmailAddress":"",
      "retypeNewEmailAddress":""
    };
  }

  cancelToAccountSettings(){
    this.router.navigate(['/accountSettings']);
  }

  updateEmailAddress(emailData : any){
    this.screenLoader = true;
    this.showErrorMessage = false;
    
     this.inputParam = {
       //"userName":this.currentUser.username,
       //"dn":this.currentUser.userDn,
       //"iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"EMAIL_ADDRESS",
         "attributeValue": emailData.newEmailAddress
       }]
     }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
            this.router.navigate(['/accountSettings']);
          }else{
            if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'EMAILIDALREADYEXISTS'){
                  jQuery("#update-email-error-msg").text("There is already an account for the Email ID you provided. Please provide a different Email ID or login with your existing account.");
                  this.showErrorMessage = true;
              }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
                }
          }
          this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

}