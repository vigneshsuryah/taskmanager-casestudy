import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ChangePasswordComponent } from './changepassword.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'changePassword', component: ChangePasswordComponent}
    ])
  ],
  exports: [RouterModule]
})
export class ChangePasswordRoutingModule { }
