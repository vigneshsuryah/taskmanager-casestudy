import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
//import { ChangePasswordService } from './changepassword.service';
import { soaServiceList } from '../../shared/gbd-service/index';
declare var jQuery:any;
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-changepassword',
  templateUrl: 'changepassword.component.html',
  styleUrls: ['changepassword.component.css']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordData : any ={};
  screenLoader: boolean;
  showErrorMessage: boolean = false;
  inputParam: any = {};
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.screenLoader = false;
    this.showErrorMessage = false;
    this.changePasswordData = {
      "currentPassword":"",
      "newPassword":"",
      "retypeNewPassword":"",
      "userName":this.currentUser.username
    }
  }

  cancelToAccountSettings(){
    this.router.navigate(['/accountSettings']);
  }

  updatePassword(changePasswordData : any){
    this.screenLoader = true;
    this.showErrorMessage = false;
    
     this.inputParam = {
       //"userName":this.currentUser.username,
       //"dn":this.currentUser.userDn,
       //"iamGuid":this.currentUser.iamGuid,
       "currentPassword":changePasswordData.currentPassword,
       "newPassword":changePasswordData.newPassword
     }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.changePassword(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.changeStatus){
                this.router.navigate(['/accountSettings']);
          }else{
                if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'PWDALREADYUSED'){
                   jQuery("#change-password-error-msg").text("New Password entered is same as the current password.");
                   this.showErrorMessage = true;
                }else if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && (data.errorMessage == 'UNKNOWN' || data.errorMessage == 'WRONGCURRPASSWORD')){
                  jQuery("#change-password-error-msg").text("The password provided is incorrect. Please verify and try again.");
                  this.showErrorMessage = true;
                }
                else if(data != null && data.errorMessage !== undefined && data.errorMessage !==null && data.errorMessage == 'NOATTEMPTSREMAINING'){
                  jQuery("#logout-submit").click();
                }
                else{
                      this.soaServiceList.consoleLog(data);
                      this.screenLoader = false;
                      this.router.navigate(['/technicalError']);
                }
          }
      
      this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

}