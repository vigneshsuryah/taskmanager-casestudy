import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountSettingsComponent } from './accountsettings.component';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { AccountSettingsRoutingModule } from './accountsettings-routing.module';
import { ChangePasswordRoutingModule } from './changepassword/changepassword-routing.module';
import { ChangePasswordModule } from './changepassword/changepassword.module';
import { UpdateEmailRoutingModule } from './updateemail/updateemail-routing.module';
import { UpdateEmailModule } from './updateemail/updateemail.module';
import { UpdatePhonenoRoutingModule } from './updatephoneno/updatephoneno-routing.module';
import { UpdatePhonenoModule } from './updatephoneno/updatephoneno.module';
import { UpdateOrgrepRoutingModule } from './updateorgrep/updateorgrep-routing.module';
import { UpdateOrgrepModule } from './updateorgrep/updateorgrep.module';
import { DeleteAccountRoutingModule } from './deleteaccount/deleteaccount-routing.module';
import { DeleteAccountModule } from './deleteaccount/deleteaccount.module';
import { soaServiceList } from '../shared/gbd-service/index';
import { User } from '../shared/models/user';

@NgModule({
  imports: [CommonModule, AccountSettingsRoutingModule, ChangePasswordModule,ChangePasswordRoutingModule, 
  UpdateEmailModule,UpdateEmailRoutingModule, 
  UpdatePhonenoModule,UpdatePhonenoRoutingModule, 
  UpdateOrgrepModule,UpdateOrgrepRoutingModule, 
  DeleteAccountModule,DeleteAccountRoutingModule, 
  CommonutilsModule.forRoot()],
  declarations: [AccountSettingsComponent],
  providers:[soaServiceList, User],
  exports: [AccountSettingsComponent]
})
export class AccountSettingsModule { }
