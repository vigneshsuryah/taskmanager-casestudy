import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Router } from '@angular/router';
import { DeleteAccountComponent } from './deleteaccount.component';
import { soaServiceList } from '../../shared/gbd-service/index';
import { CommonutilsModule } from '../../commonutils/commonutils.module';
import { User } from '../../shared/models/user';

@NgModule({
  imports: [CommonModule,CommonutilsModule.forRoot()],
  declarations: [DeleteAccountComponent],
  exports: [DeleteAccountComponent],
  providers:[soaServiceList, User]  
})
export class DeleteAccountModule {}