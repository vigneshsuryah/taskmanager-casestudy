import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/gbd-service/index';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-deleteaccount',
  templateUrl: 'deleteaccount.component.html',
  styleUrls: ['deleteaccount.component.css']
})
export class DeleteAccountComponent implements OnInit {

  screenLoader: boolean;
  inputParam: any = '';
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.screenLoader = false;
  }

  cancelToMyAccount(){
    this.router.navigate(['/myAccount']);
  }

  openDeleteConfirmPopup(){
    jQuery("#deleteConfirmPopupDataTarget").click();
  }

  confirmDeleteAccount(){
    this.screenLoader = true;
     this.inputParam = {
       //"userName":this.currentUser.username,
       //"dn":this.currentUser.userDn
    }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.deleteUser(this.inputParam).subscribe(
      (data: any) => {
        this.soaServiceList.consoleLog(data);
          this.screenLoader = false;
          if(data !== undefined && data.deleteUserStatus){
               window.location.href='/sgofundhip/logout.html'; 
          }else{
             this.router.navigate(['/technicalError']);
          }
      
    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
  }

}