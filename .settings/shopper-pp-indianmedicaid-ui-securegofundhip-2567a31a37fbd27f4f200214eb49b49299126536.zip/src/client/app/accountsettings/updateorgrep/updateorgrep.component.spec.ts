import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { soaServiceList } from '../../shared/gbd-service/index';
import { AuthenticationService } from '../../shared/gbd-service/index';

import { UpdateOrgrepModule } from './updateorgrep.module';

import { Observable } from 'rxjs/Observable';

import { User } from '../../shared/models/user';
import { AccountSettingsComponent } from '../../accountsettings/accountsettings.component';
import { BackdropComponent } from '../../commonutils/backdrop/backdrop.component';
import { CommonutilsModule } from '../../commonutils/commonutils.module';

import { TechnicalErrorModule } from '../../commonutils/technicalerror/technicalerror.module';
import { TechnicalErrorComponent } from '../../commonutils/technicalerror/technicalerror.component';

export function main() {
  
  describe('Update Org Group component', () => {
    let config: Route[] = [
      { path: 'accountSettings', component: AccountSettingsComponent },
      { path: 'technicalError', component: TechnicalErrorComponent }
    ];

    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, UpdateOrgrepModule, TechnicalErrorModule, CommonutilsModule, RouterTestingModule.withRoutes(config)],
        declarations: [UpdateOrgGroupTestComponent, AccountSettingsComponent],
        providers: [
          soaServiceList,
          AuthenticationService,
          User,
          BaseRequestOptions,
          MockBackend,
          BackdropComponent,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

   it('updateorgrep should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(UpdateOrgGroupTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      it('updateorgrep updateOrgRep should return false when called', async(() => {
        TestBed
          .compileComponents()
          .then(() => {
          let mockBackend = TestBed.get(MockBackend);

          let user = TestBed.get(User);
          user.username = 'vsuser101';
          user.orgType = 'Test';
          user.orgName = 'Cognizant';
          user.userDn = 'CN=vsuser038,OU=eMembers,OU=webUsers,OU=usersAndGroups,DC=webdevad,DC=wellpoint,DC=com';
          user.iamGuid = 'f5e94997-4e8c-4e3f-bcb2-91afa6daac75';

          let actualRes : any;
          actualRes = {
            "errorMessage": null,
            "modified": true
          };
          
          let authenticationService = TestBed.get(AuthenticationService);
          authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

          mockBackend.connections.subscribe((c: any) => {
            c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
          });

          let orgRepData = {
            "firstName":"firstname",
            "lastName":"lastName"
          };
          
          let fixture = TestBed.createComponent(UpdateOrgGroupTestComponent);
          let instance = fixture.debugElement.children[0].componentInstance;
          fixture.detectChanges();

          instance.updateOrgRep(orgRepData);
          expect(instance.screenLoader).toBe(false);
        });
    }));


    it('updateorgrep updateOrgRep should return true when called', async(() => {
        TestBed
          .compileComponents()
          .then(() => {
          let mockBackend = TestBed.get(MockBackend);

          let user = TestBed.get(User);
          user.username = 'vsuser101';
          user.orgType = 'Test';
          user.orgName = 'Cognizant';
          user.userDn = 'CN=vsuser038,OU=eMembers,OU=webUsers,OU=usersAndGroups,DC=webdevad,DC=wellpoint,DC=com';
          user.iamGuid = 'f5e94997-4e8c-4e3f-bcb2-91afa6daac75';

          let actualRes : any;
          actualRes = {
            "errorMessage": 'Error',
            "modified": false
          };
          
          let authenticationService = TestBed.get(AuthenticationService);
          authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

          mockBackend.connections.subscribe((c: any) => {
            c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
          });

          let orgRepData = {
            "firstName":"firstname",
            "lastName":"lastName"
          };
          
          let fixture = TestBed.createComponent(UpdateOrgGroupTestComponent);
          let instance = fixture.debugElement.children[0].componentInstance;
          fixture.detectChanges();

          instance.updateOrgRep(orgRepData);
          expect(instance.screenLoader).toBe(false);
        });
    }));
      
  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-updateorgrep></gbdtpp-updateorgrep>'
})
class UpdateOrgGroupTestComponent { }
