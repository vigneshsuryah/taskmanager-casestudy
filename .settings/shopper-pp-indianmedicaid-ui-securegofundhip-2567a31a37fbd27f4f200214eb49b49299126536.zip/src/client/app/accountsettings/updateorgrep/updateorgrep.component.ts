import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/gbd-service/index';
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-updateorgrep',
  templateUrl: 'updateorgrep.component.html',
  styleUrls: ['updateorgrep.component.css']
})
export class UpdateOrgrepComponent implements OnInit {
  orgRepData : any = {};
  screenLoader: boolean = false;
  showErrorMessage: boolean = false;
  inputParam: any = {};
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.orgRepData = {
      "firstName":"",
      "lastName":""
    }
  }

  cancelToAccountSettings(){
    this.router.navigate(['/accountSettings']);
  }

  updateOrgRep(orgRepData : any){
    this.screenLoader = true;
    this.showErrorMessage = false;
    
     this.inputParam = {
       //"userName":this.currentUser.username,
       //"dn":this.currentUser.userDn,
       //"iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"FIRST_NAME",
         "attributeValue": orgRepData.firstName
         },
         {
         "attributeName":"LAST_NAME",
         "attributeValue": orgRepData.lastName
         }]
     }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
                this.router.navigate(['/accountSettings']);
          }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
          }
          this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

}