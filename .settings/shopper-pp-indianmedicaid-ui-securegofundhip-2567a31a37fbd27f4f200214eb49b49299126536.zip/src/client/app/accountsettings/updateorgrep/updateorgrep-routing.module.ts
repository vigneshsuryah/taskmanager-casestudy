import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UpdateOrgrepComponent } from './updateorgrep.component';

import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'updateOrgrep', component: UpdateOrgrepComponent }
    ])
  ],
  exports: [RouterModule]
})
export class UpdateOrgrepRoutingModule { }
