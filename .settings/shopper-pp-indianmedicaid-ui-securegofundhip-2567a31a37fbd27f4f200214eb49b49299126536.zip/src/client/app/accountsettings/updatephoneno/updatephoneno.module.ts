import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Router } from '@angular/router';
import { UpdatePhonenoComponent } from './updatephoneno.component';
import { CommonutilsModule } from '../../commonutils/commonutils.module';
import { soaServiceList } from '../../shared/gbd-service/index';
import { User } from '../../shared/models/user';

@NgModule({
  imports: [CommonModule,CommonutilsModule.forRoot()],
  declarations: [UpdatePhonenoComponent],
  exports: [UpdatePhonenoComponent],
  providers:[soaServiceList, User]  
})
export class UpdatePhonenoModule {}