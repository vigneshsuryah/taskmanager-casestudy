import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { soaServiceList } from '../../shared/gbd-service/index';
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-updatePhoneno',
  templateUrl: 'updatephoneno.component.html',
  styleUrls: ['updatephoneno.component.css']
})
export class UpdatePhonenoComponent implements OnInit {
  phoneData : any = {};
  screenLoader: boolean = false;
  showErrorMessage: boolean = false;
  inputParam: any = {};
  constructor (public router : Router, private soaServiceList : soaServiceList, private currentUser: User){

  }
  ngOnInit() {
    this.phoneData = {
      "newPhoneNo":""
    }
  }

  cancelToAccountSettings(){
    this.router.navigate(['/accountSettings']);
  }

 updatePhoneNo(phoneData : any){
    this.screenLoader = true;
    this.showErrorMessage = false;
    
     this.inputParam = {
       //"userName":this.currentUser.username,
       //"dn":this.currentUser.userDn,
       //"iamGuid":this.currentUser.iamGuid,
       "attributes": [{
         "attributeName":"PHONE_NUMBER",
         "attributeValue": phoneData.newPhoneNo
         }]
     }
      this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.modifyUser(this.inputParam).subscribe(
      (data: any) => {
          if(data !== undefined && data.modified){
            this.router.navigate(['/accountSettings']);
          }else{
                this.soaServiceList.consoleLog(data);
                this.screenLoader = false;
                this.router.navigate(['/technicalError']);
          }
          this.screenLoader = false;

    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
   
  }

}