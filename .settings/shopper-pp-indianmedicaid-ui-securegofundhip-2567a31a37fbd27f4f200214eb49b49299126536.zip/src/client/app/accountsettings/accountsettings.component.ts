import { Component, EventEmitter,OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { soaServiceList } from '../shared/gbd-service/index';
import { User } from '../shared/models/user';
declare var jQuery:any;
@Component({
  moduleId: module.id,
  selector: 'gbd-accountsettings',
  templateUrl: 'accountsettings.component.html',
  styleUrls: ['accountsettings.component.css']
})
export class AccountSettingsComponent implements OnInit{ 
  accountDetails : any = {};
  screenLoader: boolean = false;
  inputParam: any = '';
  constructor(public router: Router,private soaServiceList : soaServiceList, private currentUser: User) {
    
  }
  ngOnInit(){
    this.screenLoader = true;
     this.inputParam = {
       //"userName":this.currentUser.username
     }
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.searchUser(this.inputParam).subscribe(
      (data: any) => {
        if(data.user !== undefined && data.user !== null){
              this.currentUser.iamGuid = data.user.iamGuid;
              this.soaServiceList.consoleLog("Current User :"+JSON.stringify(this.currentUser));
              this.accountDetails = {
                          "userName":this.currentUser.username,
                          "pswdalias":"*******",
                          "email":data.user.emailAddress,
                          "orgName":data.user.orgName,
                          "repName":data.user.firstName+" "+data.user.lastName,
                          "phoneNo":data.user.phoneNumber
              };
        }else{
           this.soaServiceList.consoleLog(data.errorMessage);
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
        }
      this.screenLoader = false;
    },
    (err: any) => {
       this.soaServiceList.consoleLog(err);
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
    if(!this.currentUser.authFlag){
      jQuery("#emailPopUp").click();
    }
  }
  returnToMyAccount (): any{
    this.router.navigate(['/myAccount']);
  }
  changePasswordRoute (): any{
    this.router.navigate(['/changePassword']);
  }
  updateAuthFlag(){
    
    //this.currentUser.authFlag=true;
    this.screenLoader = true;
    this.inputParam = {
       //"userName":this.currentUser.username
     }
     this.soaServiceList.consoleLog(this.inputParam);
     this.soaServiceList.updateAuthFlag(this.inputParam).subscribe(
      (data: any) => {
          this.screenLoader = false;
           if(data !== undefined && data !== null){
            if(data.updateStatus){
              this.currentUser.authFlag = true;
              //this.router.navigate(['/myAccount']);
            } else {
              this.currentUser.authFlag = false;
              //this.router.navigate(['/accountSettings']);
            }
          } else {
            this.soaServiceList.consoleLog(data);
            this.screenLoader = false;
            this.router.navigate(['/technicalError']);
          }
    },
    (err: any) => {
           this.screenLoader = false;
           this.router.navigate(['/technicalError']);
      } 
    );
  }

  updateAuthFlagCall (): any {
    if(!this.currentUser.authFlag){
      this.updateAuthFlag();
    }  
  }

}