export let CONFIG = {
  baseUrls: {
    members: 'api/members.json',
    payments: 'api/payments.json',
    wallet: 'api/wallet.json'
  }
};