import { Component,NgModule } from '@angular/core';
import { Config } from './shared/config/env.config';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import {Keepalive} from '@ng-idle/keepalive';
import './operators';
declare var jQuery:any;

/**
 * This class represents the main application component.
 */
@Component({
  moduleId: module.id,
  selector: 'gbdtpp-app',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.css'],
})
export class AppComponent {
  
  screenLoader: boolean = false;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;

  onActivate(e:any, outlet:any){
    window.scrollTo(0,0);
  }
  
  constructor(private idle: Idle, private keepalive: Keepalive) {
    /*console.log('Environment config', Config);*/
    jQuery(window).on('shown.bs.modal', function(){
        jQuery(".modal-header").find(".close").focus();
    });
    // sets an idle timeout of 5 seconds, for testing purposes.
    idle.setIdle(900);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    idle.onIdleEnd.subscribe(
      () => this.idleState = 'No longer idle.'
      );
    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      jQuery("#logout-submit").click();
    });
    idle.onIdleStart.subscribe(() => this.idleState = 'You\'ve gone idle!');
    idle.onTimeoutWarning.subscribe((countdown:any) => this.idleState = 'You will time out in ' + countdown + ' seconds!');

    // sets the ping interval to 15 seconds
    keepalive.interval(15);

    keepalive.onPing.subscribe(() => this.lastPing = new Date());

    this.reset();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
}
