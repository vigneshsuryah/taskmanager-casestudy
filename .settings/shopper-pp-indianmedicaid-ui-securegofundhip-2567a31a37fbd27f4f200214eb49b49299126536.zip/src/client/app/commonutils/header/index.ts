/**
 * This barrel file provides the export for the shared ToolbarComponent.
 */
export * from './header.component';
