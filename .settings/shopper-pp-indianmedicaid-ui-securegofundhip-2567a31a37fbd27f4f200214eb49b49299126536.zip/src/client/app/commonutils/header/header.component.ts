import { Component,ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../shared/gbd-service/authentication.service';
import { DOCUMENT } from '@angular/platform-browser';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-header',
  templateUrl: 'header.component.html' ,
  styleUrls: ['header.component.css']
})

export class HeaderComponent implements OnInit { 

   constructor(public router: Router, private authserv : AuthenticationService, @Inject(DOCUMENT) private document: any) {
    
   }

  ngOnInit() {
    
  }

  toLogOut(){
    jQuery("#logout-submit").click();
  }
} 

