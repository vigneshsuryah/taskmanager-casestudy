import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TechnicalErrorComponent } from './technicalerror.component';
import { TechnicalErrorRoutingModule } from './technicalerror-routing.module';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { CommonutilsModule } from '../../commonutils/commonutils.module';


@NgModule({
  imports: [CommonModule, TechnicalErrorRoutingModule, ReactiveFormsModule, FormsModule, CommonutilsModule.forRoot()],
  declarations: [TechnicalErrorComponent],
  exports: [TechnicalErrorComponent],
  providers :[ gbdServiceList ]
})
export class TechnicalErrorModule { }
