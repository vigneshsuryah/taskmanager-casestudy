import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TechnicalErrorComponent } from './technicalerror.component';
import { AuthGuard } from '../../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'technicalError', component: TechnicalErrorComponent }
    ])
  ],
  exports: [RouterModule]
})
export class TechnicalErrorRoutingModule { }
