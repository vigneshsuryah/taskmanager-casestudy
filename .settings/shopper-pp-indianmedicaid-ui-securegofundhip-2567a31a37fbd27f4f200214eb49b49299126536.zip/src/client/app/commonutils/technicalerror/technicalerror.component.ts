import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { gbdServiceList } from '../../shared/gbd-service/index';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-technicaleerror',
  templateUrl: 'technicalerror.component.html',
  styleUrls: ['technicalerror.component.css']
})
export class TechnicalErrorComponent implements OnInit {

  
  constructor(public router: Router, private gbdServiceList: gbdServiceList) {
  }

  ngOnInit() {
    
  }

  redirectToMyAccount(){
      this.router.navigate(['/myAccount']);
  }

 }



