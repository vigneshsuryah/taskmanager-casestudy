import { NgModule, ModuleWithProviders } from '@angular/core';

import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BackdropComponent } from './backdrop/backdrop.component';
import { LoaderComponent } from './loader/loader.component';
import { ScreenFreezeComponent } from './screenfreeze/screenfreeze.component';
import { TechErrSectionComponent } from './techerrsection/techerrsection.component';
import { PasswordValidatorDirective } from '../shared/directives/passwordValidatorDir';
import { ConfirmPasswordValidatorDirective } from '../shared/directives/confirmPasswordValidatorDir';
import { EmailValidatorDirective } from '../shared/directives/emailValidatorDir';
import { ConfirmEmailAddressValidatorDirective } from '../shared/directives/confirmEmailValidatorDir';
import { AuthenticationService } from '../shared/gbd-service/authentication.service';
import { PaymentServiceErrorComponent } from './paymentserviceerror/paymentserviceerror.component';

@NgModule({
  imports: [CommonModule, RouterModule, FormsModule],
  declarations: [HeaderComponent, FooterComponent,BackdropComponent,LoaderComponent,ScreenFreezeComponent, TechErrSectionComponent,PasswordValidatorDirective,ConfirmPasswordValidatorDirective,EmailValidatorDirective,ConfirmEmailAddressValidatorDirective, PaymentServiceErrorComponent],
  exports: [HeaderComponent, FooterComponent, LoaderComponent, ScreenFreezeComponent, TechErrSectionComponent, PaymentServiceErrorComponent,
    CommonModule, FormsModule, RouterModule, BackdropComponent,PasswordValidatorDirective,ConfirmPasswordValidatorDirective,EmailValidatorDirective,ConfirmEmailAddressValidatorDirective],
    providers: [AuthenticationService]
})
export class CommonutilsModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CommonutilsModule,      
    };
  }

  
}
