import { Component,ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-techerrsection',
  templateUrl: 'techerrsection.component.html' ,
  styleUrls: ['techerrsection.component.css']
})

export class TechErrSectionComponent implements OnInit { 
  
  ngOnInit() {
    
  }
  
} 

