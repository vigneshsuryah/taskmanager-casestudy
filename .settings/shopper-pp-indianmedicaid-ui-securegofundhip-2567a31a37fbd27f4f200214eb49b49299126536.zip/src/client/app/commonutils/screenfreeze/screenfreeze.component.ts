import { Component,ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-screenfreeze',
  templateUrl: 'screenfreeze.component.html' ,
  styleUrls: ['screenfreeze.component.css']
})

export class ScreenFreezeComponent implements OnInit { 
  
  ngOnInit() {
    
  }
  
} 

