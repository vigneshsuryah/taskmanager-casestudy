import { Component ,Input } from '@angular/core';

/**
 * This class represents the toolbar component.
 */
@Component({
  moduleId: module.id,
  selector: 'gbdtpp-backdrop',
  templateUrl: 'backdrop.component.html',
  styleUrls: ['backdrop.component.css']
})
export class BackdropComponent {
  @Input()titleValue:String;
  title:String="";
  
  ngOnInit() {
    this.title=this.titleValue;
  }
}

