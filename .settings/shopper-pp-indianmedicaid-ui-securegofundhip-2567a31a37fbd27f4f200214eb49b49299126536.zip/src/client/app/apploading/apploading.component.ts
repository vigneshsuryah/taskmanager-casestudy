import { Component, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { gbdServiceList } from '../shared/gbd-service/index';
import { User } from '../shared/models/user';
import { Config } from '../shared/config/env.config';

@Component({
  moduleId: module.id,
  selector: 'gbd-apploading',
  templateUrl: 'apploading.component.html',
  styleUrls: ['apploading.component.css']
})
export class AppLoadingComponent { 
 
    constructor (public gbdServiceList: gbdServiceList, public fb: FormBuilder, public router : Router, private currentUser: User){
      
    }
    
    ngOnInit(){
      setTimeout(()=>{
        if(!this.currentUser.authFlag){
          this.router.navigate(['/accountSettings']);
        } else {
          this.router.navigate(['/myAccount']);
        } 
      },2000);
      this.loadScript(Config.encryptionurl);
      this.loadScript(Config.keyjsurl);
    }


    loadScript(url: string) {
      let node = document.createElement('script');
      node.src = url;
      node.type = 'text/javascript';
      document.getElementById('script-load-div').appendChild(node);       
     }


}
