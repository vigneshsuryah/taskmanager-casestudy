import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppLoadingComponent } from './apploading.component';
import { AppLoadingRoutingModule } from './apploading-routing.module';
import { gbdServiceList } from '../shared/gbd-service/index';
import { CommonutilsModule } from '../commonutils/commonutils.module';


@NgModule({
  imports: [CommonModule, AppLoadingRoutingModule, ReactiveFormsModule, FormsModule, CommonutilsModule.forRoot()],
  declarations: [AppLoadingComponent],
  exports: [AppLoadingComponent],
  providers :[ gbdServiceList ]
})
export class AppLoadingModule { }
