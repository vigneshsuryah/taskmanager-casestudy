import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppLoadingComponent } from './apploading.component';
import { AuthGuard } from '../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: '', component: AppLoadingComponent, canActivate: [AuthGuard] }
    ])
  ],
  exports: [RouterModule]
})
export class AppLoadingRoutingModule { }
