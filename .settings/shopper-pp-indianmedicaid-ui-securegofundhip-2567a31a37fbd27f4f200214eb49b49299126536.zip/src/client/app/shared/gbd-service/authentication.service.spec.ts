import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions } from '@angular/http';
import { TestBed, async } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { RouterModule , Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { User } from '../models/user';

export function main() {
  describe('authentication Service', () => {

    let mockBackend: MockBackend;

    beforeEach(() => {

      TestBed.configureTestingModule({
        imports: [RouterModule, RouterTestingModule ],
        providers: [
          User,
          MockBackend,
          AuthenticationService,
          BaseRequestOptions,
          {
            provide: Http,
            useFactory: (backend: ConnectionBackend, options: BaseRequestOptions) => new Http(backend, options),
            deps: [MockBackend, BaseRequestOptions]
          }
        ]
      });
    });

 it('authentication service login() should return an Observable when called', async(() => {
    
      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      expect(TestBed.get(AuthenticationService).login()).toEqual(jasmine.any(Observable));
    }));

  it('authentication service login() data', async(() => {
      let authenticationService = TestBed.get(AuthenticationService);
      let mockBackend = TestBed.get(MockBackend);

      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';
      user.userDn ='vsuser101';

      let actualRes : any;
      actualRes = {
        "authToken":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8",
        "userName":"vsuser101",
        "userDn":"vsuser101",
        "orgType":"Test",
        "orgName":"Cognizant"
      };
      
      mockBackend.connections.subscribe((c: any) => {
        c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
      });

    
      authenticationService.login().subscribe((data: any) => {
        expect(data).toEqual(true);
      });
  }));

  it('authentication service logout()', async(() => {

      let authenticationService = TestBed.get(AuthenticationService);
    
      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';
      authenticationService.logout();
      expect(authenticationService.token).toEqual(null);
    }));
  

  });
}
