import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Headers, RequestOptions } from '@angular/http';
import { Config } from '../index';
import { AuthenticationService } from './authentication.service';
import { RouterModule , Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { ValidateRoutingNo } from '../../shared/models/validateRoutingNo.model';

@Injectable()
export class gbdServiceList {
  
  constructor(private http: Http,
  private authenticationService: AuthenticationService, private router : Router, private currentUser: User) {}

  getMethod(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.authenticationService.token, 'meta-senderapp': 'TPP','meta-orgType':this.currentUser.orgType});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/getmethods",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  updateMethods(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' + this.authenticationService.token, 'meta-senderapp': 'TPP','meta-orgType':this.currentUser.orgType});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/updatemethods",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleError.bind(this));
  }

  getMembers(inputParam:{}):Observable<string[]>{
    let headers = new Headers({'Authorization':'Bearer '+this.authenticationService.token,'Accept':'*/*','Content-Type':'application/json','meta-senderapp':'TPP','meta-orgType':this.currentUser.orgType});
    let options = new RequestOptions({headers:headers});
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/getMembers",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  } 

  updateMembers(inputParam:{}):Observable<string[]>{
    let headers = new Headers({'Authorization':'Bearer '+this.authenticationService.token,'Accept':'*/*','Content-Type':'application/json','meta-senderapp':'TPP','meta-orgType':this.currentUser.orgType});
    let options = new RequestOptions({headers:headers});
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/updateMember",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  } 

  submitPayment(inputParam:{}):Observable<string[]>{
    let headers = new Headers({'Authorization':'Bearer '+this.authenticationService.token,'Accept':'*/*','Content-Type':'application/json','meta-senderapp':'TPP',"meta-orgType":this.currentUser.orgType});
    let options = new RequestOptions({headers:headers});
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/submittransaction",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleError.bind(this));
  }

  getValidationBankDetails(inputParam:{}):Observable<ValidateRoutingNo>{
    let headers = new Headers({'Authorization':'Bearer '+this.authenticationService.token,'Accept':'*/*','Content-Type':'application/json','meta-senderapp':'TPP',"meta-orgType":this.currentUser.orgType});
    let options = new RequestOptions({headers:headers});
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/payments/validateRoutingNumber",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleError.bind(this));
  }

    /**
    * Handle HTTP error
    */
  private handleError (error: any) {
    var techErrorRoute = false;
    if(error.status==500 || error.status==400 || error.status==404){
       techErrorRoute = true;
    }

    if(techErrorRoute){
      this.router.navigate(['/technicalError']);
    }

    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
   
    this.consoleLog('Error handleError gbd-service: ' + error);
    return Observable.throw(errMsg);
  }

  private handleErrorNoChange (error: any) {

    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
   
    this.consoleLog('Error handleErrorNoChange gbd-service: ' + error);
    return Observable.throw(errMsg);
  }

  public consoleLog(message : string){
    if(Config.loggingflag){
      console.log(message);
    }
  }
}
