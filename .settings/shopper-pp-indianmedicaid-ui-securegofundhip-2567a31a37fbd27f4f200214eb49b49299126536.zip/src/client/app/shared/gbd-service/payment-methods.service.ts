import { PaymentMethodModel } from '../models/paymentmethod.model';

export class PaymentMethodsService {
  public paymentMethod: PaymentMethodModel;
  public getMethodResponse: any;
}