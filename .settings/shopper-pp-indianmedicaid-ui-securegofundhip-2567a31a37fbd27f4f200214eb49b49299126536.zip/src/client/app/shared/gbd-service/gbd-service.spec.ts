import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions } from '@angular/http';
import { TestBed, async } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { Observable } from 'rxjs/Observable';
import { gbdServiceList } from './gbd-service';

import { AuthenticationService } from './authentication.service';
import { RouterModule , Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { User } from '../models/user';

export function main() {
  describe('gbdServiceList Service', () => {
    let gbdService: gbdServiceList;
    let mockBackend: MockBackend;

    beforeEach(() => {

      TestBed.configureTestingModule({
        imports: [RouterModule, RouterTestingModule ],
        providers: [
          User,
          gbdServiceList,
          AuthenticationService,
          MockBackend,
          BaseRequestOptions,
          {
            provide: Http,
            useFactory: (backend: ConnectionBackend, options: BaseRequestOptions) => new Http(backend, options),
            deps: [MockBackend, BaseRequestOptions]
          }
        ]
      });
    });

    it('gbdServiceList getMethod should return an Observable when called', async(() => {
      let authenticationService = TestBed.get(AuthenticationService);
      authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
      
      let inputParam = {
        "healthCardId": 'vsuser101'
      };
      
      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      expect(TestBed.get(gbdServiceList).getMethod(inputParam)).toEqual(jasmine.any(Observable));
    }));

    it('gbdServiceList getMethod should resolve to list of payment methods when called', async(() => {
      let gbdService = TestBed.get(gbdServiceList);
      let mockBackend = TestBed.get(MockBackend);

      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      let actualRes : any;
      actualRes = {
          "creditCardDetails": [
              {
                  "creditCardNumber": "************2687",
                  "creditCardType": "VISA",
                  "expirationMonth": "02",
                  "expirationYear": "2018",
                  "accountHolderName": "Name",
                  "accountAddress1": "Address",
                  "accountCity": "CA",
                  "accountState": "CA",
                  "accountPostalCode": "90001",
                  "accountNickname": "NewlyAddedEdit",
                  "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
              },
              {
                  "creditCardNumber": "************2537",
                  "creditCardType": "MC",
                  "expirationMonth": "03",
                  "expirationYear": "2018",
                  "accountHolderName": "test",
                  "accountAddress1": "test",
                  "accountCity": "California",
                  "accountState": "CA",
                  "accountPostalCode": "90001",
                  "accountNickname": "SDfasdfa",
                  "tokenId": "591EAED9218DA1685093D17AA4396863"
              },
              {
                  "creditCardNumber": "************2537",
                  "creditCardType": "MC",
                  "expirationMonth": "02",
                  "expirationYear": "2018",
                  "accountHolderName": "SD",
                  "accountAddress1": "SDf",
                  "accountCity": "SDf",
                  "accountState": "CA",
                  "accountPostalCode": "90001",
                  "accountNickname": "SDfasdfas",
                  "tokenId": "4BF17DE91EE3E3948C2A4C3AD45B817F"
              }
          ],
          "paymentsPaginationCount": 7
      };
      
      let authenticationService = TestBed.get(AuthenticationService);
      authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

      mockBackend.connections.subscribe((c: any) => {
        c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
      });

      let inputParam = {
        "healthCardId": 'vsuser101'
      };
        
      gbdService.getMethod(inputParam).subscribe((data: any) => {
        expect(data).toEqual(actualRes);
      });
  }));

  it('gbdServiceList updateMethods should return an Observable when called', async(() => {
    let authenticationService = TestBed.get(AuthenticationService);
    authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

    let inputParam = {
        "healthCardId": 'vsuser101'
      };
        
      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      expect(TestBed.get(gbdServiceList).updateMethods(inputParam)).toEqual(jasmine.any(Observable));
  }));

  it('gbdServiceList getMembers should return an Observable when called', async(() => {
    let authenticationService = TestBed.get(AuthenticationService);
    authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

    let inputParam = {
        "healthCardId": 'vsuser101'
      };
        
      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      expect(TestBed.get(gbdServiceList).getMembers(inputParam)).toEqual(jasmine.any(Observable));
  }));

  it('gbdServiceList getMembers should resolve to list of members when called', async(() => {
      let gbdService = TestBed.get(gbdServiceList);
      let mockBackend = TestBed.get(MockBackend);

      let user = TestBed.get(User);
      user.username = 'vsuser101';
      user.orgType = 'Test';
      user.orgName = 'Cognizant';

      let actualRes : any;
      actualRes = {
          "message": {
              "messageCode": "01",
              "messageText": "No Active Members"
          },
          "memberPaginationCount": 0
      };
      
      let authenticationService = TestBed.get(AuthenticationService);
      authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

      mockBackend.connections.subscribe((c: any) => {
        c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
      });

      let inputParam = {
        "healthCardId": 'vsuser101'
      };
        
      gbdService.getMembers(inputParam).subscribe((data: any) => {
        expect(data).toEqual(actualRes);
      });
  }));

  it('gbdServiceList updateMembers should return an Observable when called', async(() => {
    let authenticationService = TestBed.get(AuthenticationService);
    authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';

    let inputParam = {
      "healthCardId": 'vsuser101'
    };
      
    let user = TestBed.get(User);
    user.username = 'vsuser101';
    user.orgType = 'Test';
    user.orgName = 'Cognizant';
      
    expect(TestBed.get(gbdServiceList).updateMembers(inputParam)).toEqual(jasmine.any(Observable));
  }));


  });
}
