import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Headers, RequestOptions } from '@angular/http';
import { Config } from '../index';
import { AuthenticationService } from './authentication.service';
import { RouterModule , Router } from '@angular/router';
import { User } from '../../shared/models/user';

@Injectable()
export class soaServiceList {
  
  constructor(private http: Http,
  private authenticationService: AuthenticationService, private router : Router, private currentUser: User) {}
  
  deleteUser(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.authenticationService.token, 'meta-senderapp': 'TPP'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/account/deleteUser",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
   }

    changePassword(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.authenticationService.token, 'meta-senderapp': 'TPP'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/account/changePassword",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
   }

   searchUser(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.authenticationService.token, 'meta-senderapp': 'TPP'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/account/searchUser",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  modifyUser(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization': 'Bearer ' +
    this.authenticationService.token, 'meta-senderapp': 'TPP'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/account/modifyUser",inputParam,options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  updateAuthFlag(inputParam : {}): Observable<string[]> {
    let headers = new Headers({ 'Authorization':'Bearer '+
    this.authenticationService.token,'meta-senderapp':'TPP'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(Config.API+ "gofundhip/secure/v1/gbd/account/updateAuthFlag",inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }
    /**
    * Handle HTTP error
    */
  private handleError (error: any) {
    var techErrorRoute = false;
    if(error.status==500 || error.status==404){
       techErrorRoute = true;
    }

    if(techErrorRoute){
      this.router.navigate(['/technicalError']);
    }

    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
   
    this.consoleLog('Error handleError gbd-service: ' + error);
    return Observable.throw(errMsg);
  }

  private handleErrorNoChange (error: any) {

    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
   
    this.consoleLog('Error handleErrorNoChange gbd-service: ' + error);
    return Observable.throw(errMsg);
  }

  public consoleLog(message : string){
    if(Config.loggingflag){
      console.log(message);
    }
  }
}