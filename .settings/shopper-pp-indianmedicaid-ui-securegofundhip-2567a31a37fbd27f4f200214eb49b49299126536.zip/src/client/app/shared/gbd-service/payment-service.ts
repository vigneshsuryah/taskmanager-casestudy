import { PaymentModel } from '../models/payment.model';

export class PaymentService {
  public payments: PaymentModel[];
  public selectedPaymentMethod: string;
  public selectedPaymentMethodTokenId: string;
  public confirmPaymentResponse: any = [];
  public memberNameMap:any = {};
  public selectedPaymentMethodNumber: string;
  public maskedNumber: string;
  public bankAccountType: string;
}