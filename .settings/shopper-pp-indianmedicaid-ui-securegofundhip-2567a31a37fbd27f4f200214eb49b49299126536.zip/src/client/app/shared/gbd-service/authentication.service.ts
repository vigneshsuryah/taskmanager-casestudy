import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Config } from '../index';
import { RouterModule , Router } from '@angular/router';
import { User } from '../models/user';

@Injectable()
export class AuthenticationService {
    public token: string;
    public userDetails: any = {};

    constructor(private http: Http, private router : Router, private currentUser: User) {
        this.token = "";
        this.userDetails = {};
    }

    login(): Observable<boolean> {
        return this.http.post(Config.API + 'login/generateTokenWithSMHeaders', JSON.stringify({ }))
            .map((response: Response) => {
                let token = response.json() && response.json().authToken;
                let userName = response.json() && response.json().userName;
                let userDn = response.json() && response.json().userDn;
                let orgType = response.json() && response.json().orgType;
                let orgName = response.json() && response.json().orgName;
                let aciEnableFlag = response.json() && response.json().aciFlag;
                let authFlag = response.json() && response.json().authFlag;
                if (token) {
                    
                    this.token = token;
                    this.userDetails = {
                        "username" : userName,
                        "userDn" : userDn,
                        "orgType" : orgType,
                        "orgName" : orgName
                    }

                    this.currentUser.username = userName;
                    this.currentUser.userDn = userDn;
                    this.currentUser.orgType = orgType;
                    this.currentUser.orgName = orgName;
                    this.currentUser.aciEnableFlag = aciEnableFlag;
                    this.currentUser.authFlag = authFlag;
                    /*console.log("JSON.stringify(this.userDetails) : " + JSON.stringify(this.userDetails));*/
    
                    return true;
                } else {
                    return false;
                }
            }).catch(this.handleError);
    }

    logout(): void {
        this.token = null;
        this.currentUser = null;
    }

    private handleError (error: any) {
      window.location.href='/gofundhip/index.html';
    
      let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
   
       return Observable.throw(errMsg);
    }
    
}