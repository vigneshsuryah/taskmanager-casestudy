import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[confirm-password-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => ConfirmPasswordValidatorDirective), multi: true }
  ]
})
export class ConfirmPasswordValidatorDirective implements Validator {
  @Input('passwordEntered') passwordEntered: string;

  constructor() { }

  validate(c: FormControl) {
    if (typeof c.value === 'undefined') {
      return null;
    }

    let result: any = {};
    if (this.validatePasswordMatch(c)) {
      result.validatePasswordMatch = true;
    }

    return result;
  }

  private validatePasswordMatch(c: FormControl): any {
    let result = false;
    if((typeof this.passwordEntered === 'undefined') || (typeof c.value === 'undefined') ||
       (this.passwordEntered === null) || (c.value === null)){
      return result;
    }else{
      let value = c.value; 
      if ((this.passwordEntered || '') === value) {
        result = false;
      }else{
        result = true;
      }
    }
  
    return result;
  }

}
