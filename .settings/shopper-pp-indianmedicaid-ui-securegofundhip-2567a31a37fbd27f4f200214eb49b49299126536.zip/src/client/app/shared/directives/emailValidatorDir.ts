import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[emailaddress-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => EmailValidatorDirective), multi: true }
  ]
})
export class EmailValidatorDirective implements Validator {

  validate(c: FormControl) {
        if ((c.errors && !c.errors['validEmail']) || !c.value) {
            return null;
        }

        return this.validateEmail(c);
    }

    private validateEmail(c: FormControl): any {
        return (/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z, A-Z]{2,63}(?:\.[a-z,A-Z]{2})?)$/i).test(c.value) ? null : {
            validEmail: true
        };
    }

}
