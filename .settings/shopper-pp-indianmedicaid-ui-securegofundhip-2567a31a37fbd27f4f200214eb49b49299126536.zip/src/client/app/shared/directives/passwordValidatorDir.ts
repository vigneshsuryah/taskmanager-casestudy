import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[password-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => PasswordValidatorDirective), multi: true }
  ]
})
export class PasswordValidatorDirective implements Validator {
  @Input('checkUserNameInPassword') checkUserNameInPassword: string;

  constructor() { }

  validate(c: FormControl) {
    if (typeof c.value === 'undefined') {
      return null;
    }

    let result: any = {};
    if (this.validateLetterNumbers(c)) {
      result.validLetterNumbers = true;
    }

    if (this.validateNoSpaces(c)) {
      result.validNoSpace = true;
    }

    if (this.validateNoSpecialChar(c)) {
      result.validNoSpecialChar = true;
    }

    if (this.validateNoRepeatChar(c)) {
      result.validNoRepeatChar = true;
    }

    if (this.validateNoUsernameParts(c)) {
      result.validNoUsernamePart = true;
    }

    return result;
  }

  private validateLetterNumbers(c: FormControl): any {
    return (/[a-zA-Z]/g.test(c.value) && /\d/g.test(c.value)) ? false : true;
  }

  private validateNoSpaces(c: FormControl): any {
    return /\s/g.test(c.value) ? true : false;
  }

  private validateNoSpecialChar(c: FormControl): any {
    return /[&"'><]+/g.test(c.value) ? true : false;
  }

  private validateNoRepeatChar(c: FormControl): any {
    return /(.)\1{2,}/g.test(c.value) ? true : false;
  }

  private validateNoUsernameParts(c: FormControl): any {
    let matchLength = 3;
    let result = false;
    if((typeof this.checkUserNameInPassword === 'undefined') || (typeof c.value === 'undefined') ||
       (this.checkUserNameInPassword === null) || (c.value === null)){
      return result;
    }else{
      let value = c.value.toLowerCase(); 
      if ((this.checkUserNameInPassword || '').toLowerCase().indexOf(value.toLowerCase()) >= 0) {
        result = true;
      }
      for (let index = 0; index < value.length; index++) {
        if (value.length >= (index + matchLength) &&
          (this.checkUserNameInPassword || '').toLowerCase().indexOf(value.toLowerCase().substr(index, matchLength)) >= 0) {
          result = true;
        }
      }
    }
  
    return result;
  }

}
