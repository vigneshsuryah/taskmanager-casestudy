import { Injectable } from '@angular/core';
declare var jQuery:any;

@Injectable()
export class PaginationService {

    constructor() {}
    totalPagesCount : number;

    getPaginationAttributes(totalItemsCount: number, showItemsCount: number){

        this.totalPagesCount = Math.ceil(totalItemsCount / showItemsCount);
        let currentPageSelection = 1;
        let pageI : number = 1;
        let pageNumberArray:Array<any>=[];

        for(pageI = 1; pageI<=this.totalPagesCount; pageI++){
            let pageObj = {
                page : pageI
            }
            pageNumberArray.push(pageObj);
        }
        return{
            totalItemsCount: totalItemsCount,
            totalPagesCount: this.totalPagesCount,
            showItemsCount: showItemsCount,
            currentPageSelection: currentPageSelection,
            pageNumberArray : pageNumberArray
        }
    }

    setPage(selectionNumber: number, classNameStartWith: string){
        /* table dom show/hide starts */
        let className = classNameStartWith + 'TableTrGrp_' + selectionNumber.toString();
        jQuery('#' + classNameStartWith + 'Tbody' + ' tr').hide();
        jQuery('.'+className).show();
        /* table dom show/hide ends */

        /* pager dom show/hide starts */
        let prevSelectionNumber: number = (selectionNumber-1);
        let nextSelectionNumber: number = (selectionNumber+1);
        
        if(selectionNumber == 1){
            prevSelectionNumber = nextSelectionNumber + 1;
        }
        if(selectionNumber == this.totalPagesCount){
            nextSelectionNumber = prevSelectionNumber - 1;
        }

        let prevEle = classNameStartWith + 'PagerGrp_' + prevSelectionNumber.toString();
        let selectEle = classNameStartWith + 'PagerGrp_' + selectionNumber.toString();
        let nextEle = classNameStartWith + 'PagerGrp_' + nextSelectionNumber.toString();
        jQuery("li[class*='"+classNameStartWith + 'PagerGrp_'+"']").hide();
        jQuery("li[class*='"+classNameStartWith + 'PagerGrp_'+"']").removeClass('active');
        jQuery('.'+selectEle).addClass('active');
        jQuery('.'+selectEle).show();
        jQuery('.'+prevEle).show();
        jQuery('.'+nextEle).show();
        /* pager dom show/hide ends */

    }

}