export class User {
    username: string;
    userDn: string;
    orgType: string;
    orgName: string;
    iamGuid: string;
    nickName: any = [];
    deleteToken: string;
    setModelDataforEdit: string;
    aciEnableFlag: boolean;
    authFlag:boolean;
}