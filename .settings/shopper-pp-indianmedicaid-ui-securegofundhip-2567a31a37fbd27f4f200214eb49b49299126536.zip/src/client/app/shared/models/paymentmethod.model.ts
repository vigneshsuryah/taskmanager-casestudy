
export class PaymentMethodModel{

         accountAddress1: string; 
         accountAddress2: string; 
         accountCity: string; 
         accountHolderName: string;
         accountNickname: string;
         accountPostalCode: string; 
         accountState: string; 
         bankAccountNumber: string; 
         bankAccountType: string;
         routingNumber: string; 
         tokenId: string;
         accountType: string;
         isBusiness:string;
         creditCardNumber:string;
         creditCardType:string;
         expirationMonth:string;
         expirationYear:string;
         paymentType:string;
         cardType:string

}