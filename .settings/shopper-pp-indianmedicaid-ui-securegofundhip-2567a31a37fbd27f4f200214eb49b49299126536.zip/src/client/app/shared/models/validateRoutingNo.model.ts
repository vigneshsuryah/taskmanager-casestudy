export class Exception {
    type?: string;
    code?: string;
    message?: string;
    detail?: string;
}
export class RoutingNoDetails {
    newRoutingNumber?: string;
    customerName?: string;
}
export class ValidateRoutingNo {
    valid?: boolean;
    exceptions?: Array<Exception>
    routingNoDetails?: RoutingNoDetails;
}