export class AddMemberModel{

    constructor(
        public firstName: string, 
        public lastName: string, 
        public dob: string, 
        public memberIdNumber: string){

    }
}