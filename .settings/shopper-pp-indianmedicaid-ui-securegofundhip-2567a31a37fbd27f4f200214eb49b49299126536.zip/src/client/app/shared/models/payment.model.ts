export class PaymentModel {
    memberId: string; 
    memberName: string; 
    amount: string; 
    isChecked: boolean;
    paymentDate : string;
    confirmationNumber : string;
}