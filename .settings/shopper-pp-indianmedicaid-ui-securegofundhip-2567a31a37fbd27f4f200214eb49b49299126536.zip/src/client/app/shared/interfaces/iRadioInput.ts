export interface IRadioInput {
  label: string;
  id: string;
  name: string;
  value: string;
  ariaLabelledBy?: string;
}
