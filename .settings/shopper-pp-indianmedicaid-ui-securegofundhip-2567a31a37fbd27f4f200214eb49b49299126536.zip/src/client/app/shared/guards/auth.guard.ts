import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthenticationService } from '../gbd-service/authentication.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router, private authserv : AuthenticationService) { }

    canActivate() {
      this.authserv.login().subscribe();
      return true;
    }
}