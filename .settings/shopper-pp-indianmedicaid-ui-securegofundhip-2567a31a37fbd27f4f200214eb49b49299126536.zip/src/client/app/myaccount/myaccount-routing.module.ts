import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MyaccountComponent } from './myaccount.component';

import { AuthGuard } from '../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'myAccount', component: MyaccountComponent }
    ])
  ],
  exports: [RouterModule]
})
export class MyaccountRoutingModule { }
