import { Component, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../shared/models/user';
declare var jQuery:any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'gbd-myaccount',
  templateUrl: 'myaccount.component.html',
  styleUrls: ['myaccount.component.css']
})
export class MyaccountComponent { 
  constructor(private router: Router,private currentUser: User) {

  }
  response : any[] = [];
  aciToggleFlag: boolean;

  ngOnInit(){
    jQuery(".dropdown-custom").show();
    this.aciToggleFlag = this.currentUser.aciEnableFlag;
    /*if(!this.currentUser.authFlag){
      this.router.navigate(['/accountSettings']);
    }*/
  }
}