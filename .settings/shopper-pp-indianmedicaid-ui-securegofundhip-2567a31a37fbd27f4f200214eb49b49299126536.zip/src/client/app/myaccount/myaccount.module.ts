import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyaccountComponent } from './myaccount.component';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { MyaccountRoutingModule } from './myaccount-routing.module';
import { PaymentMethodModule } from './paymentmethod/paymentmethod.module';
import { MemberDetailsModule } from './memberdetails/memberdetails.module';
import { PaymentsModule } from './payments/payments.module';

import { PaymentService } from '../shared/gbd-service/payment-service';

@NgModule({
  imports: [CommonModule, MyaccountRoutingModule, CommonutilsModule.forRoot(),
  PaymentMethodModule,MemberDetailsModule,PaymentsModule],
  declarations: [MyaccountComponent],
  providers:[PaymentService],
  exports: [MyaccountComponent]
})
export class MyaccountModule { }
