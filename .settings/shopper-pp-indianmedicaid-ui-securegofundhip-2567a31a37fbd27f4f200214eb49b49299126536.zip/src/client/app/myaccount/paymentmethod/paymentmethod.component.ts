import { Component } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { PaymentMethodsService } from '../../shared/gbd-service/index';
import { PaymentMethodModel } from '../../shared/models/paymentmethod.model';
import { User } from '../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-paymentmethod',
  templateUrl: 'paymentmethod.component.html',
  styleUrls: ['paymentmethod.component.css']
})
export class PaymentMethodComponent {
  inputParam: any = '';
  getMethodResponse: any = {};
  showContent: any;
  responseLength: any = 0;
  showAddNewPaymentMethod: boolean = true;
  screenLoader:boolean = false;
  constructor(public router: Router, private gbdServiceList: gbdServiceList,private paymentMethodsService: PaymentMethodsService, private currentUser: User) {
  }

  ngOnInit() {
    this.showContent = 'loader';
    this.responseLength = 0;
    this.inputParam = {
      //"healthCardId": this.currentUser.username
    }
    
    this.gbdServiceList.getMethod(this.inputParam).subscribe(
      (data: any) => {
        
        this.getMethodResponse = data;
        this.showAddNewPaymentMethod = true;
      
        if (!this.getMethodResponse.creditCardDetails && !this.getMethodResponse.bankAccountDetails) {
          this.responseLength = 0;
        } else {
          if (this.getMethodResponse.creditCardDetails !== undefined){
            this.responseLength += this.getMethodResponse.creditCardDetails.length;
          }
          if (this.getMethodResponse.bankAccountDetails !== undefined){
            this.responseLength += this.getMethodResponse.bankAccountDetails.length;     
          }
        }
        
        this.showContent = 'content';
        
        if(this.responseLength >= 5){
          this.showAddNewPaymentMethod = false;
        }
        
      },
      (err: any) => {
        this.showContent = 'techerror';
      }    
    );
  }
  
  sendDataToPayment(paymentData: any) {
    this.currentUser.setModelDataforEdit = JSON.stringify(paymentData);
    this.router.navigate(['/paymentmethods']);
  }

  redirectToEditAccountInformation(paymentData: any) {
    this.currentUser.nickName = this.nickNameCheck(paymentData.accountNickname);
    this.paymentMethodsService.paymentMethod = paymentData;
    this.router.navigate(['/editPaymentMethod/']); 
  }

 redirectToAddNewPayment(){
    this.paymentMethodsService.getMethodResponse = this.getMethodResponse;
    this.router.navigate(['/addNewPayment']);
  }
 setDataForDelete(tokenID:string){  
   this.currentUser.deleteToken = tokenID;
   jQuery("#deletePopupOpener").click();
  }
  clickOnDropDown(tokenID:string){
    setTimeout(()=>{
      jQuery("#dropDownClick"+tokenID).click();
    },100);
  }
 deleteTransaction():any{  
      this.screenLoader = true;
      this.inputParam = {
                "endPointName":null,
                //"healthCardId":this.currentUser.username,
                "action":"DELETE",
                "bankAccountDetails":null,                
                "creditCardDetails":{
                    "tokenId": this.currentUser.deleteToken                          
                },
                //"csrUserId":this.currentUser.username,
                "csrFlag":true
                }
    this.currentUser.deleteToken = null;
    this.gbdServiceList.updateMethods(this.inputParam).subscribe((data:any) => {
        document.getElementById('deleteTransaction').click();
        document.getElementById('modalOpener').click();
        this.screenLoader = false;
        this.ngOnInit();
      });
  }

  nickNameCheck(...args:any[]):any{
    var temp:any = [];
    let response = this.getMethodResponse;
    if(response.creditCardDetails !== undefined && args.length>0){
    for(var i=0;i<=response.creditCardDetails.length-1; i++){
      if((response.creditCardDetails[i].accountNickname != args[0]) && response.creditCardDetails[i].accountNickname !== "" && args[0] !== undefined && args[0] !== "" && response.creditCardDetails[i].accountNickname !== undefined){
        temp.push(response.creditCardDetails[i].accountNickname);
      }
    }
    }else{
      if(response.creditCardDetails !== undefined){
      for(var i=0;i<=response.creditCardDetails.length-1; i++){
        if(response.creditCardDetails[i].accountNickname !== "")
        temp.push(response.creditCardDetails[i].accountNickname);
     }
      }
    }
    if(response.bankAccountDetails!== undefined && args.length >0){
      for(var j=0;j<=response.bankAccountDetails.length-1; j++){
        if((response.bankAccountDetails[j].accountNickname != args[0]) &&  response.bankAccountDetails[j].accountNickname !== "" && args[0] !== undefined && args[0] !== "" &&  response.bankAccountDetails[j].accountNickname !== undefined)
        temp.push(response.bankAccountDetails[j].accountNickname);
      }
    }else{
      if(response.bankAccountDetails!== undefined){
      for(var j=0;j<=response.bankAccountDetails.length-1; j++){
        if(response.bankAccountDetails[j].accountNickname !== "")
        temp.push(response.bankAccountDetails[j].accountNickname);
     }
      }
    }
    return temp;
  }
}