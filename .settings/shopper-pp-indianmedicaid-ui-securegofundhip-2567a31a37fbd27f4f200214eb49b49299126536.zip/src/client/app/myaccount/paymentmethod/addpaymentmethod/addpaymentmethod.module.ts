import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonutilsModule } from '../../../commonutils/commonutils.module';
import { UxModule } from '../../../shared/ux.module';
import { AddPaymentMethodComponent } from './addpaymentmethod.component';
import { User } from '../../../shared/models/user';

@NgModule({
  imports: [CommonModule, CommonutilsModule,UxModule,CommonutilsModule.forRoot()],
  declarations: [AddPaymentMethodComponent],
  exports: [AddPaymentMethodComponent],
  providers: [User]
})
export class AddPaymentMethodModule { }