import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { PaymentMethodModel } from '../../../shared/models/paymentmethod.model';
import { gbdServiceList } from './../../../../app/shared/gbd-service/gbd-service';
import { PaymentMethodsService } from '../../../shared/gbd-service/index';
import { content } from '../../../shared/constants/constants';
import { User } from '../../../shared/models/user';
import { ValidateRoutingNo } from '../../../shared/models/validateRoutingNo.model';
declare var jQuery:any;
declare var PIE:any;
declare var ProtectPANandCVV:Function; 

@Component({
  moduleId: module.id,
  selector: 'add-paymentmethod',
  templateUrl: 'addpaymentmethod.component.html',
  styleUrls: ['addpaymentmethod.component.css']
})
export class AddPaymentMethodComponent implements OnInit{

  paymentMethodNew : any ={};
  content : any ={};
  constructor (public router : Router, private gbdServiceList: gbdServiceList, private paymentMethodsService: PaymentMethodsService, private currentUser: User){
    this.paymentMethodNew = paymentMethodsService.getMethodResponse;
  }
  showBank : boolean = false;
  public routingNoValidations:Array<string>=[];
  bankName: string = '';
  backEndErrorMsg: string;
  screenLoader: boolean = false;
  backEndError: boolean = false;
  inputParam: any = '';
  businessAccountTypeVal: string;
  getMethodResponse: any = {};
  responseLength: any = 0;
  value: String = "";
  nickNameError:boolean=false;
  validationError:boolean=false;
  paymentMethodSelected:string = '';
  encryptionData : any = {};
  model = {
         "accountAddress1":"",
         "accountAddress2":"",
         "accountCity":"",
         "accountHolderName":"",
         "accountNickname":"",
         "accountPostalCode":"", 
         "accountState":"", 
         "bankAccountNumber":"", 
         "bankAccountType":"",
         "routingNumber":"", 
         "tokenId":"",
         "accountType":"",
         "isBusiness":"",
         "creditCardNumber":"",
         "creditCardType":"",
         "expirationMonth":"",
         "expirationYear":"",
         "paymentType":"CreditDebitCard",
         "cardType":""
  };
  

  addPaymentTypeDropdown(paymentMethod: any){ 
    
        if(paymentMethod == 'CreditDebitCard'){
            this.value = "creditDebitCard";
            this.setTabIndexOfLabels();
        }else if (paymentMethod == 'Banking'){
            this.value = "bankAccount";
            this.model.bankAccountType = 'Checking';
            this.setTabIndexOfLabels();
        }
     
  }

  redirectToMyAccount(){
    this.router.navigate(['/myAccount']);
  } 

   validateBankDetails(routingNo: string){
        this.showBank = false;
        if(null !== routingNo && undefined !== routingNo && routingNo !== '' && routingNo.length == 9){
            this.screenLoader = true;
            this.inputParam = {
                "routingNumber": routingNo
            }
            this.gbdServiceList.getValidationBankDetails(this.inputParam).subscribe((data: ValidateRoutingNo) => {
                this.routingNoValidations = [];
                
                if (data && data.exceptions) {
                    data.exceptions.forEach(x => {
                        this.routingNoValidations.push(x.message);
                    });
                } else if (data && data.valid === false) {
                    this.routingNoValidations.push('Please enter a valid bank routing number');
                    console.log(JSON.stringify(this.routingNoValidations));
                } else if (data && data.valid === true) {
                    this.bankName = data.routingNoDetails.customerName;
                    this.showBank = true;
                }
                 this.screenLoader = false;
            });
        }
    }

  AddNewPaymentMethod(paymentMethod: PaymentMethodModel){
    this.gbdServiceList.consoleLog("paymentMethod"+JSON.stringify(paymentMethod));
    this.screenLoader = true;
    this.currentUser.nickName = this.nickNameCheck();
    
    if(this.currentUser.nickName!== null && this.currentUser.nickName!== "" && this.currentUser.nickName.indexOf(paymentMethod.accountNickname) >= 0){
          this.nickNameError = true;
          this.screenLoader = false;
          return;
     }
     
    if(paymentMethod.bankAccountType == 'Savings' && paymentMethod.isBusiness){
      this.businessAccountTypeVal = 'BUSINESS_SAVINGS';
    }
    if(paymentMethod.bankAccountType == 'Savings' && !paymentMethod.isBusiness){
      this.businessAccountTypeVal = 'PERSONAL_SAVINGS';
    }
    if(paymentMethod.bankAccountType == 'Checking' && paymentMethod.isBusiness){
      this.businessAccountTypeVal = 'BUSINESS_CHECKING';
    }
    if(paymentMethod.bankAccountType == 'Checking' && !paymentMethod.isBusiness){
      this.businessAccountTypeVal = 'PERSONAL_CHECKING';
    }
    
    if(paymentMethod != null && paymentMethod.creditCardType != ""){
          this.encryptionData = this.doEncryption(paymentMethod.creditCardNumber);
          this.inputParam = {
            "endPointName":null,
            //"healthCardId": this.currentUser.username,
            "action": "CREATE",
            "bankAccountDetails":null,
            "creditCardDetails": { 
                      "accountNickname": paymentMethod.accountNickname ?  paymentMethod.accountNickname: null,
                      "creditCardType":paymentMethod.creditCardType,
                      "creditCardNumber":this.encryptionData.encryptccno,
                      "accountHolderName":paymentMethod.accountHolderName,
                      "accountAddress1":paymentMethod.accountAddress1,
                      "accountAddress2":paymentMethod.accountAddress2 ? paymentMethod.accountAddress2:null,
                      "accountCity":paymentMethod.accountCity,
                      "accountState":paymentMethod.accountState,
                      "accountPostalCode":paymentMethod.accountPostalCode,
                      "expirationMonth": paymentMethod.expirationMonth,
                      "expirationYear" : paymentMethod.expirationYear,
                      "securityCode": null,
                      "tokenId": null,
                      "formatID":"64",
                      "integrityCheck" : this.encryptionData.integritycheck,
                      "keyID" : this.encryptionData.keyid,
                      "phaseID" : this.encryptionData.phase+''
            },
            "csrUserId":null
          }  
    }

    else if(paymentMethod != null && paymentMethod.bankAccountType != ""){
          this.inputParam = {
            "endPointName":null,
            //"healthCardId": this.currentUser.username,
            "action": "CREATE",
            "creditCardDetails":null,
            "bankAccountDetails": { 
                      "bankAccountType": this.businessAccountTypeVal,
                      "routingNumber": paymentMethod.routingNumber,
                      "bankAccountNumber": paymentMethod.bankAccountNumber,
                      "accountHolderName": paymentMethod.accountHolderName,
                      "accountAddress1": paymentMethod.accountAddress1,
                      "accountAddress2": paymentMethod.accountAddress2 ? paymentMethod.accountAddress2 : null,
                      "accountCity": paymentMethod.accountCity,
                      "accountState": paymentMethod.accountState,
                      "accountPostalCode": paymentMethod.accountPostalCode,
                      "accountNickname": paymentMethod.accountNickname,
                      "tokenId":null
            },
            "csrUserId":null
          }       
    }
   this.gbdServiceList.consoleLog("input"+this.inputParam);
        this.gbdServiceList.updateMethods(this.inputParam).subscribe((data: any) => {
     
          if(data.message.messageCode == 0){
                   document.getElementById('successErrorModal').click();
          }else{
                  this.backEndErrorMsg = data.message.messageText;
                  this.backEndError=true;
                  this.validationError=true;
                  this.screenLoader = false;
                  return;
            }
            this.screenLoader = false;
     },	  
      (error: Error) => {
           this.backEndErrorMsg = JSON.stringify(error);
           this.backEndError=true;
          this.screenLoader = false;
        });
        

    
  }


    nickNameCheck(...args:any[]):any{
      
    var temp:any = [];
    let response = this.paymentMethodNew;
    this.gbdServiceList.consoleLog(response);
    if(response.creditCardDetails !== undefined && args.length>0){
    for(var i=0;i<=response.creditCardDetails.length-1; i++){
      if((response.creditCardDetails[i].accountNickname != args[0]) && response.creditCardDetails[i].accountNickname !== "" && response.creditCardDetails[i].accountNickname !== undefined){
        temp.push(response.creditCardDetails[i].accountNickname);
      }
    }
    }else{
      if(response.creditCardDetails !== undefined){
      for(var i=0;i<=response.creditCardDetails.length-1; i++){
        if(response.creditCardDetails[i].accountNickname !== undefined && response.creditCardDetails[i].accountNickname !== "")
        temp.push(response.creditCardDetails[i].accountNickname);
     }
      }
    }
    if(response.bankAccountDetails!== undefined && args.length >0){
      for(var j=0;j<=response.bankAccountDetails.length-1; j++){
        if((response.bankAccountDetails[j].accountNickname != args[0]) &&  response.bankAccountDetails[j].accountNickname !== "" && response.bankAccountDetails[j].accountNickname !== undefined)
        temp.push(response.bankAccountDetails[j].accountNickname);
      }
    }else{
      if(response.bankAccountDetails!== undefined){
      for(var j=0;j<=response.bankAccountDetails.length-1; j++){
        if(response.bankAccountDetails[j].accountNickname !== undefined && response.bankAccountDetails[j].accountNickname !== "")
        temp.push(response.bankAccountDetails[j].accountNickname);
     }
      }
    }
    
    return temp;
  }

  ngOnInit() {
  //  this.value = "creditDebitCard";
   // this.model.paymentType = "CreditDebitCard";
    this.content = content;
    this.value = "creditDebitCard";
    this.setTabIndexOfLabels();
    this.showBank = false;
    this.routingNoValidations = [];
    this.bankName = '';
  }

  setTabIndexOfLabels(){
    setTimeout(()=>{
      jQuery(".dropdown-label").attr("tabindex","0");
    },100); 
  }

  doEncryption(ccno: any) {
        this.encryptionData={};
        this.encryptionData.ccno=ccno;
        var result=ProtectPANandCVV(ccno,"",true);
        //console.log('result : ' + JSON.stringify(result));
        if(result!=null && result!= undefined) {
            this.encryptionData.encryptccno=result[0];
            if(result.length >2){
                this.encryptionData.integritycheck = result[2];
            } 
        }else{
            alert("Error: ProtectPANandCVV call returned null. You may have entered an invalid card number.");
        }
        this.encryptionData.keyid = PIE.key_id;
        this.encryptionData.phase = PIE.phase;
        return this.encryptionData;
    } 

}