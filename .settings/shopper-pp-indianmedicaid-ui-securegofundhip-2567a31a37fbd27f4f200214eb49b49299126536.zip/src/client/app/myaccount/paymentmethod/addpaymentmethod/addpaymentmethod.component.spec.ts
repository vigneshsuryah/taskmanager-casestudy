import { Component, ChangeDetectionStrategy  } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { gbdServiceList } from '../../../shared/gbd-service/index';
import { AuthenticationService } from '../../../shared/gbd-service/index';
import { PaginationService } from '../../../shared/pagination-service/pagination-service';
import { MyaccountComponent } from '../../../myaccount/myaccount.component';
import { AddPaymentMethodModule } from '../../../myaccount/paymentmethod/addpaymentmethod/addpaymentmethod.module';
import { MyaccountModule } from '../../../myaccount/myaccount.module';
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';

import { Observable } from 'rxjs/Observable';

export function main() {
  
  let dummyObj = {
                    "accountAddress1":"",
                    "accountAddress2":"",
                    "accountCity":"",
                    "accountHolderName":"",
                    "accountNickname":"",
                    "accountPostalCode":"", 
                    "accountState":"", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };

    let actualResBank : any;
    actualResBank = {
        "message": {
            "messageCode": "0",
            "messageText": "Success"
        },
        "bankAccountDetails": {
            "bankAccountType": "BUSINESS_CHECKING",
            "routingNumber": "111000025",
            "bankAccountNumber": "******3525",
            "accountHolderName": "Portal1QA",
            "accountAddress1": "2015 Staples Mill Rd",
            "accountAddress2": "Apt5871",
            "accountCity": "Indianapolis",
            "accountState": "CA",
            "accountPostalCode": "91360",
            "accountNickname": "PCheckingTester",
            "tokenId": "2FB32F6476DD044CBDEA19A945333CEC"
        }
    };

    let actualResError : any;
    actualResError = {
        "message": {
            "messageCode": "100",
            "messageText": "Failure"
        },
        "bankAccountDetails": null
    };

    let creditcardArrObj = [
            {
                "creditCardNumber": "************2687",
                "creditCardType": "VISA",
                "expirationMonth": "02",
                "expirationYear": "2019",
                "accountHolderName": "Name",
                "accountAddress1": "Address",
                "accountCity": "OH",
                "accountState": "CA",
                "accountPostalCode": "90001",
                "accountNickname": "myNicknames",
                "tokenId": "5C365B3BB69C321F16E5819DBCE67D1F"
            },
            {
                "creditCardNumber": "************1443",
                "creditCardType": "VISA",
                "expirationMonth": "03",
                "expirationYear": "2019",
                "accountHolderName": "rffggg",
                "accountAddress1": "gggg",
                "accountCity": "California",
                "accountState": "CA",
                "accountPostalCode": "90001",
                "accountNickname": "rtyuyu",
                "tokenId": "D57F04E30CCCC5E9660D42E24D63809B"
            },
            {
                "creditCardNumber": "************1443",
                "creditCardType": "VISA",
                "expirationMonth": "01",
                "expirationYear": "2019",
                "accountHolderName": "test",
                "accountAddress1": "address",
                "accountCity": "California",
                "accountState": "CA",
                "accountPostalCode": "90001",
                "accountNickname": "checkitem",
                "tokenId": "4FF035DA9E6AA68FA3EA8CBE87DFB7C0"
            }
        ];

        var bankAccArrObj = [
            {"bankAccountDetails": {
                        "bankAccountType": "BUSINESS_CHECKING",
                        "routingNumber": "111000025",
                        "bankAccountNumber": "******3525",
                        "accountHolderName": "Portal1QA",
                        "accountAddress1": "2015 Staples Mill Rd",
                        "accountAddress2": "Apt5871",
                        "accountCity": "Indianapolis",
                        "accountState": "CA",
                        "accountPostalCode": "91360",
                        "accountNickname": "PCheckingTester",
                        "tokenId": "2FB32F6476DD044CBDEA19A945333CEC"
                }}];

    
describe('Add Payment Method component', () => {

        let config: Route[] = [
        { path: 'myAccount', component: MyaccountComponent }
        ];
        // setting module for testing
        // Disable old forms
        beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [FormsModule, RouterModule, HttpModule, AddPaymentMethodModule,MyaccountModule, RouterTestingModule.withRoutes(config) ],
            declarations: [AddPaymentMethodTestComponent],
            providers: [
            gbdServiceList,
            PaginationService,
            AuthenticationService,
            User,
            BaseRequestOptions,
            MockBackend,
            {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
                return new Http(backend, defaultOptions);
                },
                deps: [MockBackend, BaseRequestOptions]
            },
            ]
        });
        });

        
    it('add payment method banking account success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "creditDebitCard";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Savings",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(false);
                
            });

        }));

         it('add payment method banking account success business savings',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "bankAccount";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Savings",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":true,
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(false);
                
            });

        }));

        it('add payment method banking account success business checking',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "bankAccount";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Checking",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":true,
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(false);
                
            });

        }));

         it('add payment method banking account Failure',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResError })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "bankAccount";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Savings",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(true);
                
            });

        }));

          it('add payment method banking account success personal checking',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "bankAccount";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Checking",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":false,
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(false);
                
            });

        }));


        it('add payment method credit card account success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "creditDebitCard";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"4111111114362521  ",
                    "creditCardType":"VISA",
                    "expirationMonth":"05",
                    "expirationYear":"2020",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };

                paymentsInstance.AddNewPaymentMethod(inputParam);
                
                let compiled = fixture.nativeElement;

            expect(paymentsInstance.backEndError).toBe(false);
                
            });

        }));

         it('add payment method nick name check success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "creditDebitCard";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"4111111114362521",
                    "creditCardType":"VISA",
                    "expirationMonth":"05",
                    "expirationYear":"2020",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.nickNameError).toBe(false);
                
            });

        }));

         it('add payment method nick name check failure',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let gbdService = TestBed.get(gbdServiceList);
                let mockBackend = TestBed.get(MockBackend);

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
                mockBackend.connections.subscribe((c: any) => {
                c.mockRespond(new Response(new ResponseOptions({ body: actualResBank })));
                });

                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.content = content;
                paymentsInstance.value = "creditDebitCard";
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };
                paymentsInstance.model = dummyObj;
                fixture.detectChanges();
                let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"myNicknames",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"4111111114362521",
                    "creditCardType":"VISA",
                    "expirationMonth":"05",
                    "expirationYear":"2020",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };

            paymentsInstance.AddNewPaymentMethod(inputParam);
                
            let compiled = fixture.nativeElement;

            expect(paymentsInstance.nickNameError).toBe(true);
                
            });

        }));


         it('add payment method dropdown creditcard',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
         
                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
               
                fixture.detectChanges();
             
                paymentsInstance.addPaymentTypeDropdown('CreditDebitCard');
                    
                let compiled = fixture.nativeElement;

                expect(paymentsInstance.value).toBe('creditDebitCard');
                
            });

        }));

          it('add payment method dropdown banking account dropdown',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
         
                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
               
                fixture.detectChanges();
             
                paymentsInstance.addPaymentTypeDropdown('Banking');
                    
                let compiled = fixture.nativeElement;

                expect(paymentsInstance.value).toBe('bankAccount');
                
            });

        }));

           it('add payment method myAccount Routing',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
         
                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
               
                fixture.detectChanges();
             
                paymentsInstance.redirectToMyAccount();
                    
                let compiled = fixture.nativeElement;

                expect(compiled).toBeTruthy();
                
            });

        }));


         it('add payment method nick name method success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
              
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                           
                let fixture = TestBed.createComponent(AddPaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
                paymentsInstance.paymentMethodNew = {
                    "creditCardDetails": creditcardArrObj,
                    "bankAccountDetails": bankAccArrObj
                };

                fixture.detectChanges();
              
                paymentsInstance.nickNameCheck('test');
                
                let compiled = fixture.nativeElement;

               expect(compiled).toBeTruthy();
                
            });

        })); 

        


        
    });
    }

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'test-cmp',
  template: '<add-paymentmethod></add-paymentmethod>'
})
class AddPaymentMethodTestComponent { }
