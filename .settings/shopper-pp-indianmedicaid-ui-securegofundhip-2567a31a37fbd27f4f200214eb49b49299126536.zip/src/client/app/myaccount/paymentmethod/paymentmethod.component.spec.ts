import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterModule, Route } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { AuthenticationService } from '../../shared/gbd-service/index';
import { PaginationService } from '../../shared/pagination-service/pagination-service';

import { PaymentMethodModule } from '../../myaccount/paymentmethod/paymentmethod.module';
import { Observable } from 'rxjs/Observable';
import { User } from '../../shared/models/user';
import { PaymentMethodsService } from '../../shared/gbd-service/index';
import { EditPaymentMethodComponent } from './editpaymentmethod/editpaymentmethod.component';
import { AddPaymentMethodComponent } from './addpaymentmethod/addpaymentmethod.component';

export function main() {
  
 
  let actualRes : any;
  actualRes = {
      "creditCardDetails": [
          {
              "creditCardNumber": "************2687",
              "creditCardType": "VISA",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "Name",
              "accountAddress1": "Address",
              "accountCity": "CA",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "NewlyAddedEdit",
              "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "03",
              "expirationYear": "2018",
              "accountHolderName": "test",
              "accountAddress1": "test",
              "accountCity": "California",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfa",
              "tokenId": "591EAED9218DA1685093D17AA4396863"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "SD",
              "accountAddress1": "SDf",
              "accountCity": "SDf",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfas",
              "tokenId": "4BF17DE91EE3E3948C2A4C3AD45B817F"
          }
      ],
       "bankAccountDetails": [
              {
                        "bankAccountType": "BUSINESS_CHECKING",
                        "routingNumber": "111000025",
                        "bankAccountNumber": "******3525",
                        "accountHolderName": "Portal1QA",
                        "accountAddress1": "2015 Staples Mill Rd",
                        "accountAddress2": "Apt5871",
                        "accountCity": "Indianapolis",
                        "accountState": "CA",
                        "accountPostalCode": "91360",
                        "accountNickname": "PCheckingTester",
                        "tokenId": "2FB32F6476DD044CBDEA19A945333CEC"
                },
                  {
                        "bankAccountType": "BUSINESS_CHECKING",
                        "routingNumber": "111000025",
                        "bankAccountNumber": "******3525",
                        "accountHolderName": "Portal1QA",
                        "accountAddress1": "2015 Staples Mill Rd",
                        "accountAddress2": "Apt5871",
                        "accountCity": "Indianapolis",
                        "accountState": "CA",
                        "accountPostalCode": "91360",
                        "accountNickname": "PCheckingTester",
                        "tokenId": "2FB32F6476DD044CBDEA19A949333CYC"
                }
       ],
      "paymentsPaginationCount": 7
  };

  let actualResEmpty : any;
  actualResEmpty = {
     "creditCardDetails": null,
      "bankAccountDetails": null

  }

  describe('Payment Method component', () => {

       let config: Route[] = [
        { path: 'addNewPayment', component: AddPaymentMethodComponent  },
        { path: 'editPaymentMethod', component: EditPaymentMethodComponent }
        ];
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, PaymentMethodModule, RouterTestingModule.withRoutes(config) ],
        declarations: [PaymentMethodTestComponent],
        providers: [
          gbdServiceList,
          PaginationService,
          AuthenticationService,
          User,
          PaymentMethodsService,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      }).overrideComponent(PaymentMethodTestComponent, {
        set: {
            providers: [
            {provide: PaymentMethodsService, useClass: MockPaymentMethodsService}
            ]
        }
        });
    });

    
   it('paymentmethod should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      it('paymentmethod should build without a problem for empty list',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualResEmpty })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      
      it('paymentmethod should  route to edit payment method',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            let paymentsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
              let inputParam =   {
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Savings",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"bankAccount",
                    "cardType":""
            };

            paymentsInstance.redirectToEditAccountInformation(inputParam);
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      it('paymentmethod should  route to add payment method',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            let paymentsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            paymentsInstance.redirectToAddNewPayment();
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

       it('paymentmethod for delete token',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            user.deleteToken = null;

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            let paymentsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            paymentsInstance.setDataForDelete('67D75B21D0EB33A7A8EE010E23880B41');
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

       it('paymentmethod for delete token click on drop down',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            user.deleteToken = '67D75B21D0EB33A7A8EE010E23880B41';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            let paymentsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            paymentsInstance.clickOnDropDown('67D75B21D0EB33A7A8EE010E23880B41');
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

       it('paymentmethod for delete transaction',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            user.deleteToken = '67D75B21D0EB33A7A8EE010E23880B41';

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentMethodTestComponent);
            let paymentsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            paymentsInstance.deleteTransaction();
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

      
         it('payment method nick name method success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
              
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                           
                let fixture = TestBed.createComponent(PaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
              
                fixture.detectChanges();
              
                paymentsInstance.nickNameCheck('test');
                
                let compiled = fixture.nativeElement;

               expect(compiled).toBeTruthy();
                
            });

        })); 

        
         it('payment method nick name method empty success',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
              
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                           
                let fixture = TestBed.createComponent(PaymentMethodTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
              
                fixture.detectChanges();
              
                paymentsInstance.nickNameCheck();
                
                let compiled = fixture.nativeElement;

                expect(compiled).toBeTruthy();
                
            });

        })); 


      
  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-paymentmethod></gbdtpp-paymentmethod>'
})
class PaymentMethodTestComponent { }
class MockPaymentMethodsService {
 paymentMethod ={
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"Test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"7894568521", 
                    "bankAccountType":"Savings",
                    "routingNumber":"071103473", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"Banking",
                    "cardType":""
            };
              getMethodResponse   = {
      "creditCardDetails": [
          {
              "creditCardNumber": "************2687",
              "creditCardType": "VISA",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "Name",
              "accountAddress1": "Address",
              "accountCity": "CA",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "NewlyAddedEdit",
              "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "03",
              "expirationYear": "2018",
              "accountHolderName": "test",
              "accountAddress1": "test",
              "accountCity": "California",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfa",
              "tokenId": "591EAED9218DA1685093D17AA4396863"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "SD",
              "accountAddress1": "SDf",
              "accountCity": "SDf",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfas",
              "tokenId": "4BF17DE91EE3E3948C2A4C3AD45B817F"
          }
      ],
      "paymentsPaginationCount": 7
  };
};