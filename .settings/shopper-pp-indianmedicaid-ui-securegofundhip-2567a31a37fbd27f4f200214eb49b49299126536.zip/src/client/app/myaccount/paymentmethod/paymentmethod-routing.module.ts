import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PaymentMethodComponent } from './paymentmethod.component';
import { AuthGuard } from '../../shared/guards/index';
import { EditPaymentMethodComponent } from './editpaymentmethod/editpaymentmethod.component';
import { AddPaymentMethodComponent } from './addpaymentmethod/addpaymentmethod.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'addNewPayment', component: AddPaymentMethodComponent  },
      { path: 'editPaymentMethod', component: EditPaymentMethodComponent }
    ])
  ],
  exports: [RouterModule]
})
export class PaymentMethodRoutingModule { }