import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { gbdServiceList } from '../../../shared/gbd-service/index';
import { PaymentMethodsService } from '../../../shared/gbd-service/index';
import { PaymentMethodModel } from '../../../shared/models/paymentmethod.model';
import { content } from '../../../shared/constants/constants';
import { User } from '../../../shared/models/user';

declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'edit-paymentmethod',
  templateUrl: 'editpaymentmethod.component.html',
  styleUrls: ['editpaymentmethod.component.css']
})
export class EditPaymentMethodComponent implements OnInit{ 
  screenLoader:boolean = false;
  expiryDateFlag:boolean = false;
  paymentDataToEdit : PaymentMethodModel;
  private sub: any;
  inputParam : any = '';
  backEndErrorMsg : string = '';
  backEndError:boolean=false;
  validationError:boolean=false;
  nickNameError:boolean=false;
  content:any = {};
  years : any = ['2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027','2028','2029','2030','2031','2032','2033','2034','2035','2036','2037','2038','2039','2040','2041','2042','2043','2044','2045','2046','2047','2048','2049','2050'];
  constructor (public router : Router, public route: ActivatedRoute, private gbdServiceList: gbdServiceList,private paymentMethodsService: PaymentMethodsService, private currentUser: User){
  
  }
  /*radioObj ={
                  label: 'Savings',
                  id: 'ddlPayType11',
                  name: 'rbtnval',
                  value: 'Savings'
};*/
   
   value: String;
   
   ngOnInit() {
      this.paymentDataToEdit = this.paymentMethodsService.paymentMethod;
       this.content = content;
       jQuery("#paymentType").find(".psButton").prop('disabled',true);
       setTimeout(()=>{
          jQuery("#paymentType").find(".psOption").prop('disabled',true);
          jQuery(".dropdown-label").attr("tabindex","0");
       },100);   
       if(this.paymentDataToEdit != null && this.paymentDataToEdit.bankAccountNumber != '' && this.paymentDataToEdit.bankAccountNumber != null && this.paymentDataToEdit.bankAccountNumber != undefined) {
         this.paymentDataToEdit.paymentType = 'Banking';
         this.value = "bankAccount";
         this.gbdServiceList.consoleLog("Payment type is Bank Account");
         setTimeout(()=>{
                jQuery("#radioObjectSavings").find(".prOption").prop('disabled',true);
                jQuery("#radioObjectSavings").find(".prLabel").addClass('prLabelDisabled');
                jQuery("#radioObjectChecking").find(".prOption").prop('disabled',true);
                jQuery("#radioObjectChecking").find(".prLabel").addClass('prLabelDisabled');
                jQuery("#checkboxBusiness").find(".pcOption").prop('disabled',true);
                jQuery("#checkboxBusiness").find(".pcLabel").addClass('pcOptionDisabled');
          },100);        
         if(this.paymentDataToEdit.bankAccountType != null && (this.paymentDataToEdit.bankAccountType=='PERSONAL_CHECKING' || this.paymentDataToEdit.bankAccountType=='BUSINESS_CHECKING')) {
           this.paymentDataToEdit.accountType = 'Checking';
         } else {
           this.paymentDataToEdit.accountType = 'Savings';
         }
         if(this.paymentDataToEdit.bankAccountType != null && (this.paymentDataToEdit.bankAccountType=='BUSINESS_CHECKING' ||this.paymentDataToEdit.bankAccountType=='BUSINESS_SAVINGS')) {
           this.paymentDataToEdit.isBusiness = 'true';   
         } else {
           this.paymentDataToEdit.isBusiness = 'false';
         }
       } else {
         this.paymentDataToEdit.paymentType = 'CreditDebitCard';
         this.value = "creditDebitCard";
          setTimeout(()=>{
             jQuery("#cardType").find(".psButton").prop('disabled',true);  
             jQuery("#cardType").find(".psOption").prop('disabled',true);
          },100);
        
         this.gbdServiceList.consoleLog("Payment type is Credit/Debit Card");
       }
 
     
  }
  
  redirectToMyAccount(){
    this.router.navigate(['/myAccount']);
  } 


  editPayment(paymentData : PaymentMethodModel){
    this.screenLoader = true;
    if(this.currentUser.nickName!== null && this.currentUser.nickName !== "" && this.currentUser.nickName.indexOf(paymentData.accountNickname) >= 0){
          this.nickNameError = true;
         this.screenLoader = false;
          return;
     }

     var currentdate = new Date();
     let currentMonth = currentdate.getMonth();
     currentMonth = currentMonth + 1;
     let currentYear = currentdate.getFullYear();
     var month = parseInt(paymentData.expirationMonth);
     var year = parseInt(paymentData.expirationYear);   

     if(year < currentYear){
        this.expiryDateFlag = true;
      }else if(year == currentYear && month < currentMonth){
        this.expiryDateFlag = true;
     }       


    if(paymentData != null && paymentData.bankAccountType != null){
      this.inputParam = {
                "endPointName":null,
                //"healthCardId":this.currentUser.username,
                "action":"MODIFY",
                "creditCardDetails":null,
                "bankAccountDetails":{
                    "bankAccountType":paymentData.bankAccountType,
                    "routingNumber":paymentData.routingNumber,
                    "bankAccountNumber":paymentData.bankAccountNumber,
                    "accountHolderName":paymentData.accountHolderName,
                    "accountAddress1":paymentData.accountAddress1,
                    "accountAddress2":paymentData.accountAddress2,
                    "accountCity":paymentData.accountCity,
                    "accountState":paymentData.accountState,
                    "accountPostalCode":paymentData.accountPostalCode,
                    "accountNickname":paymentData.accountNickname ?paymentData.accountNickname : null,
                    "tokenId":paymentData.tokenId
                },
                    //"csrUserId":this.currentUser.username,
                    "csrFlag":false
                }
             
    }else if(paymentData != null && paymentData.creditCardType != null){
              this.inputParam = {
                "endPointName":null,
                //"healthCardId":this.currentUser.username,
                "action":"MODIFY",
                "bankAccountDetails":null,
                "creditCardDetails":{
                    "creditCardType":paymentData.creditCardType,
                    "creditCardNumber":paymentData.creditCardNumber,
                    "accountHolderName":paymentData.accountHolderName,
                    "accountAddress1":paymentData.accountAddress1,
                    "accountAddress2":paymentData.accountAddress2,
                    "accountCity":paymentData.accountCity,
                    "accountState":paymentData.accountState,
                    "accountPostalCode":paymentData.accountPostalCode,
                    "accountNickname":paymentData.accountNickname ? paymentData.accountNickname : null,
                    "expirationMonth": paymentData.expirationMonth,
                    "expirationYear" :paymentData.expirationYear,
                    "securityCode": null,
                    "tokenId": paymentData.tokenId
                },
                    //"csrUserId":this.currentUser.username,
                    "csrFlag":false
                }
    }
     this.gbdServiceList.updateMethods(this.inputParam).subscribe((data: any) => {
               this.gbdServiceList.consoleLog("Response:"+JSON.stringify(data));
              if(paymentData != null && paymentData.creditCardType != null 
              && this.expiryDateFlag === true )
              {
                    this.backEndErrorMsg = "The expiration date for this credit/debit card is invalid. Please verify the expiration date on your card.";
                    this.backEndError=true;
                    this.validationError=true;
                    this.screenLoader = false;
                    return;
              }
               else if(data.message.messageCode == 0){
                   document.getElementById('editModalOpener').click();
                   this.screenLoader = false;
                }else{
                    this.backEndErrorMsg = data.message.messageText;
                    this.backEndError=true;
                    this.validationError=true;
                    this.screenLoader = false;
                    return;
                }
      },	  
      (error: Error) => {
           this.backEndErrorMsg = JSON.stringify(error);
           this.backEndError=true;
           this.screenLoader = false;
        });
  }

 

}