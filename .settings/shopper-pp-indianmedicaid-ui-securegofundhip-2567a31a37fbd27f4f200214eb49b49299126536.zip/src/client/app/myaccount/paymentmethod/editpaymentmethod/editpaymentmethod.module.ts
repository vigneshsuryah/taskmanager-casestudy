import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module'; 
import { UxModule } from '../../../shared/ux.module';
import { EditPaymentMethodComponent } from './editpaymentmethod.component';
import { CommonutilsModule } from '../../../commonutils/commonutils.module';
import { User } from '../../../shared/models/user';

@NgModule({
  imports: [CommonModule, SharedModule, UxModule, CommonutilsModule.forRoot()],
  declarations: [EditPaymentMethodComponent],
  exports: [EditPaymentMethodComponent],
  providers: [User]
})
export class EditPaymentMethodModule { }