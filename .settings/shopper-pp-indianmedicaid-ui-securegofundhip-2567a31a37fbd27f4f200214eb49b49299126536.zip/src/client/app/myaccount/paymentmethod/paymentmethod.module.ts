import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { RouterModule, Router } from '@angular/router';
import { PaymentMethodComponent } from './paymentmethod.component';
import { PaymentMethodRoutingModule } from './paymentmethod-routing.module';
import { EditPaymentMethodModule } from './editpaymentmethod/editpaymentmethod.module';
import { CommonutilsModule } from '../../commonutils/commonutils.module'; 
import { AddPaymentMethodModule } from './addpaymentmethod/addpaymentmethod.module';
import { PaymentMethodsService } from '../../shared/gbd-service/payment-methods.service';
import { UxModule } from '../../shared/ux.module';
import { User } from '../../shared/models/user';

@NgModule({
  imports: [CommonModule,AddPaymentMethodModule,EditPaymentMethodModule,PaymentMethodRoutingModule, CommonutilsModule, UxModule, CommonutilsModule.forRoot()],
  declarations: [PaymentMethodComponent],
  exports: [PaymentMethodComponent],
  providers: [gbdServiceList,PaymentMethodsService,User]
})
export class PaymentMethodModule {}