import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthGuard } from '../../shared/guards/index';
import { OneTimePaymentComponent } from './makepayment/onetimepayment/onetimepayment.component';
import { PaymentsComponent } from './payments.component';
import { ConfirmPaymentComponent } from './makepayment/confirmpayment/confirmpayment.component';
import { PaymentRecordComponent } from './makepayment/paymentrecord/paymentrecord.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'oneTimePayment', component: OneTimePaymentComponent },
      { path: 'confirmPayment', component: ConfirmPaymentComponent },
      { path: 'paymentRecord', component: PaymentRecordComponent }
    ])
  ],
  exports: [RouterModule]
})
export class PaymentsRoutingModule { }