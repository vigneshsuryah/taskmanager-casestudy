import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { PaymentService } from '../../shared/gbd-service/payment-service';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { PaymentModel } from '../../shared/models/payment.model';
import { PaginationService } from '../../shared/pagination-service/pagination-service';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { PaymentMethodsService } from '../../shared/gbd-service/index';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-payments',
  templateUrl: 'payments.component.html',
  styleUrls: ['payments.component.css']
})
export class PaymentsComponent implements OnInit {

  paymentsPaginationCount: number = 5;
  getMemberResponse: any = {};
  responseMessageCode: any = '';
  paymentList: PaymentModel[] = [];
  paymentListFlag: boolean = false;
  payment: any = {};
  enteredAmount: number;
  ispaymentAmountError: boolean;
  paymentAmountErrorMsg: string = 'You can make a payment of $1 to $1200.';
  selectedMember: string;
  isChecked : boolean;
  inputEnable : boolean = true;
  content: any;
  showContent: any;
  paymentsModel: any = {};
  inputParam: any = '';
  getMethodResponse: any = {};
  responseLength: any = 0;
  selectedMemberCount: number;
  disableAllCheckBox: boolean;
  selectedMemberPaymentsList: any = [];
  selectedPaymentMethod:string;
  paginationAttributes : any;
  isDisabled: boolean = false;
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  memberCountError: boolean;
  memberCountErrorMsg: string;
  memberMethodError: boolean;
  memberMethodErrorMsg: string;
  showAmountNotEnteredErrorMessage: boolean;
  showPagination: boolean = false;
  amountNotEnteredErrorMessage: string = 'You must enter an amount.';
  screenLoader:boolean = false;
  paymentAmountError : boolean = false;
  ispaymentAmountPatternError: boolean;
  paymentAmountPatternErrorMsg: string = 'Please enter amount with 2 decimal digits.';
  amountArray: any = [];

  constructor(
    public router: Router, 
    private gbdServiceList: gbdServiceList, 
    public paymentService : PaymentService,
    private paginationService : PaginationService,
    private paymentMethodsService: PaymentMethodsService,
    private currentUser: User) {
  }

  ngOnInit() {
    this.resetPaymentServiceObject();

    this.showPagination = false;
    this.showContent = 'loader';
    this.selectedMemberCount = 0;
    this.paymentListFlag = false;
    
    this.screenLoader = true;
    var paymentMethodsListComposed: any = [];
    /*this.paymentsModel = {
      "paymentMethodSelected":""
    } */
    this.content = {
        paymentMethodsList: [],
        memberCheckBoxList: [],
        disabled: false
    };

    var oneTimePaymentItem = {
        label : "One Time Payment",
        value : "oneTimePayment"
      }

    var defaultPaymentMethod = {
        label : "Select Payment Method",
        value : "default"
    }
    paymentMethodsListComposed.push(defaultPaymentMethod);
    this.selectedPaymentMethod = 'default';

    this.inputParam = {
      //"healthCardId": this.currentUser.username
    }

    this.gbdServiceList.getMethod(this.inputParam).subscribe(
      (data: any) => {

      this.getMethodResponse = data;
      if (!this.getMethodResponse.creditCardDetails && !this.getMethodResponse.bankAccountDetails) {
        this.responseLength = 0;
      } else {
        if (this.getMethodResponse.creditCardDetails !== undefined){
          var ccList = this.getMethodResponse.creditCardDetails;
          this.responseLength += ccList.length;
          for(var i = 0; i <= ccList.length-1; i++){
            var labelString = '';
            this.creditCardBankAccNbrMap[ccList[i].tokenId] = ccList[i].creditCardNumber;
            this.paymentTypeMap[ccList[i].tokenId] = 'CreditDebitCard';

            if(ccList[i].creditCardType == "MC"){
              labelString = "Mastercard ending in ";
            }else if(ccList[i].creditCardType == "VISA"){
              labelString = "VISA ending in ";
            }
            labelString = labelString + ccList[i].creditCardNumber.slice(-4);
            var tempCCItem = {
              label : labelString,
              value : ccList[i].tokenId
            }
            paymentMethodsListComposed.push(tempCCItem);
            }
        }
        if (this.getMethodResponse.bankAccountDetails !== undefined) {
          var bnkList = this.getMethodResponse.bankAccountDetails;
          this.responseLength += bnkList.length;
          for(var i = 0; i <= bnkList.length-1; i++){
            var labelString = '';
            this.creditCardBankAccNbrMap[bnkList[i].tokenId] = bnkList[i].bankAccountNumber;
            this.paymentTypeMap[bnkList[i].tokenId] = 'Banking';
            this.bankAccountTypeMap[bnkList[i].tokenId] = bnkList[i].bankAccountType;

            if(bnkList[i].bankAccountType == "BUSINESS_SAVINGS" || bnkList[i].bankAccountType == "PERSONAL_SAVINGS"){
              labelString = "Savings ending in ";
            }else if(bnkList[i].bankAccountType == "BUSINESS_CHECKING" || bnkList[i].bankAccountType == "PERSONAL_CHECKING"){
              labelString = "Checking ending in ";
            }
            labelString = labelString + bnkList[i].bankAccountNumber.slice(-4);
            var tempBnkItem = {
              label : labelString,
              value : bnkList[i].tokenId
            }
            paymentMethodsListComposed.push(tempBnkItem);
            }
        }
      }
      this.showContent = 'content';
      paymentMethodsListComposed.push(oneTimePaymentItem);
    },
    (err: any) => {
        paymentMethodsListComposed.push(oneTimePaymentItem);
      } 
    );

    this.content.paymentMethodsList = paymentMethodsListComposed;

    this.inputParam = {
      //"userId": this.currentUser.username
    }

    this.gbdServiceList.getMembers(this.inputParam).subscribe((data: any) => {
      this.getMemberResponse = data;
      this.paymentsPaginationCount = data.paymentsPaginationCount;
      if (this.getMemberResponse.message.messageCode !== undefined && this.getMemberResponse.message.messageCode === '00') {
        this.responseMessageCode = '00';
      } else {
        this.responseMessageCode = '99';
      }
     var memberCheckBoxList: any [];
     if(this.getMemberResponse != undefined && this.getMemberResponse.tppMemberDetails != undefined){
      for (let member of this.getMemberResponse.tppMemberDetails) {
        var dynamicCheckBoxName = {
            id: 'checkboxMemberPayments' + member.memberId,
            name: 'checkboxMemberPayments' + member.memberId,
            label: member.fullName,
            trueValue: true,
            falseValue: false
          };
          this.content.memberCheckBoxList.push(dynamicCheckBoxName);
          this.payment = { "memberId": member.memberId, "memberName": member.fullName, "amount" :'', "isChecked" : false, "paymentDate" :'', "confirmationNumber" : ''};
          this.paymentList.push(this.payment);
        } 
        this.gbdServiceList.consoleLog("this.paymentList : " + JSON.stringify(this.paymentList));
        if(this.paymentList.length > 0){
          this.paymentListFlag = true;
        }
        this.gbdServiceList.consoleLog("this.getMemberResponse : " + JSON.stringify(this.getMemberResponse));
        
        if(this.getMemberResponse.tppMemberDetails.length > this.paymentsPaginationCount){
          this.showPagination = true;
        }
        this.paginationAttributes = this.paginationService.getPaginationAttributes(this.paymentList.length, this.paymentsPaginationCount);
        setTimeout(()=>{
          this.setPage(1,'paymentDetails');
          jQuery(".paymentsSectionNameClass").find(".pcLabel").addClass('pcLabelFontOverride');
        },100); 
      }
        this.showContent = 'content';
        this.screenLoader = false;
    },
    (err: any) => {
       this.screenLoader = false;
       setTimeout(()=>{
          this.showContent = 'techerror';
        },100); 
      } 
    );

  }

  getPageGroup(currentGroup: number): number{
    return Math.ceil((currentGroup+1)/this.paginationAttributes.showItemsCount);
  }

  setPage(selectionNumber:number, className:string){
    this.paginationAttributes.currentPageSelection = selectionNumber;
    this.paginationService.setPage(selectionNumber, className);
    this.clearCheckBox();
  }
  
  clearCheckBox() {
    for(var i=0; i<this.paymentList.length; i++) {
      this.paymentList[i].isChecked = false;
      this.paymentList[i].amount = ''
      jQuery("#checkboxMemberPayments"+this.paymentList[i].memberId).prop('disabled',false);
      jQuery("#lbl_checkboxMemberPayments"+this.paymentList[i].memberId).removeClass('pcOptionDisabled');
    }
  }

  validateAmountEntered(payment: PaymentModel) {
    
    this.selectedMember = payment.memberId;
    if(!this.validateNoSpaces(payment.amount) && !this.validateNoSpecialChar(payment.amount) && !this.validateNoLetter(payment.amount)) {
        if(payment.amount != undefined && payment.amount != '') {
          if(payment.amount.indexOf('$') == -1 && payment.amount.indexOf('.') == -1) {
            payment.amount = '$'+payment.amount;
          } else if(payment.amount.length == 1 && (payment.amount == '$' || payment.amount ==".")) {
            payment.amount = '';
          }
          if(payment.amount.indexOf('$') >= 0) {
            this.enteredAmount = +payment.amount.slice(1);
          } else {
            this.enteredAmount = +payment.amount;
          }
          
          if(this.enteredAmount < 1 || this.enteredAmount > 1200.00) {
            this.ispaymentAmountError = true;
          } else {
            this.ispaymentAmountError = false;
          }
      } else {
          this.ispaymentAmountError = false;
      }
    }
        
  }

  validatePaymentMethod() {
    if('default' != this.selectedPaymentMethod) {
     this.memberMethodError = false;
   }
  }

  validateCheckBox(){
    this.selectedMemberCount = 0;
    for(var i=0; i<this.paymentList.length; i++) {
      if(this.paymentList[i].isChecked) {
        this.selectedMemberCount += 1;
      } else {
        this.paymentList[i].amount = '';
        this.ispaymentAmountError = false;
        this.resetErrorFlag();
      }
   }

   if(this.selectedMemberCount >= 5 ) {
     this.gbdServiceList.consoleLog('inside selected members > 5');
     for(var i=0; i<this.paymentList.length; i++) {
      if(!this.paymentList[i].isChecked) {
        jQuery("#checkboxMemberPayments"+this.paymentList[i].memberId).prop('disabled',true);
        jQuery("#lbl_checkboxMemberPayments"+this.paymentList[i].memberId).addClass('pcOptionDisabled');
      }
     }
   }else{
     this.gbdServiceList.consoleLog('inside selected members < 5');
     for(var i=0; i<this.paymentList.length; i++) {
      if(!this.paymentList[i].isChecked) {
        jQuery("#checkboxMemberPayments"+this.paymentList[i].memberId).prop('disabled',false);
        jQuery("#lbl_checkboxMemberPayments"+this.paymentList[i].memberId).removeClass('pcOptionDisabled');
      }
     }
   }
    
  }
  
  private validateNoSpaces(amt: string) {
    return /\s/g.test(amt) ? true : false;
  }

  private validateNoSpecialChar(amt: string) {
    return /[-~{}!#%&*()+[\]^_`\\":;'@?>=<,/|]+/g.test(amt) ? true : false;
  }

  private validateNoLetter(amt: string) {
    return (/[a-zA-Z]/g.test(amt) ) ? true : false;
  }

 private validatePattern(amt: string) {
     return (/^[\$]?(\d)+(\.\d{1,2})?$/g).test(amt) ? true : false;
 }
   
 resetErrorFlag() {
    this.showAmountNotEnteredErrorMessage = false;
    this.memberCountError = false;
    this.memberMethodError = false;
    this.paymentAmountError = false;
    this.ispaymentAmountPatternError = false;
 }

 submitPayment() {
   this.gbdServiceList.consoleLog("submitPayment");
   this.resetErrorFlag();
   
   var memberNameMap : any = {}; 
   this.selectedMemberPaymentsList = [];
   this.selectedMemberCount = 0;

   for(var i=0; i<this.paymentList.length; i++) {
      if(this.paymentList[i].isChecked) {
        this.selectedMemberCount += 1;
        if(this.paymentList[i].amount == '') {
          this.showAmountNotEnteredErrorMessage = true;
        } else if (this.paymentList[i].amount.indexOf('$') == -1) {
          this.paymentAmountError = true;
        } else {
          if(!this.validatePattern(this.paymentList[i].amount)) {
            this.ispaymentAmountPatternError = true;
            this.gbdServiceList.consoleLog("Pattern error if : "+this.ispaymentAmountPatternError);
          } else {
            this.gbdServiceList.consoleLog("Pattern error else : "+this.ispaymentAmountPatternError);
            memberNameMap[this.paymentList[i].memberId] = this.paymentList[i].memberName;
            this.gbdServiceList.consoleLog("this.paymentList[i].amount.indexOf('.'): "+this.paymentList[i].amount.indexOf('.'));
            if(this.paymentList[i].amount != undefined && this.paymentList[i].amount.indexOf('.') == -1){        
              this.paymentList[i].amount = this.paymentList[i].amount + '.00';
            }
            if(this.paymentList[i].amount != undefined && this.paymentList[i].amount.indexOf('.') > 0){        
              this.amountArray = this.paymentList[i].amount.split('.');
              if(this.amountArray[1].length == 1){
                this.paymentList[i].amount = this.paymentList[i].amount + '0';
              }
            }
            this.selectedMemberPaymentsList.push(this.paymentList[i]);
        }
        }
        
      }
   }
   
   if(this.selectedMemberCount <= 0) {
     this.memberCountError = true;
     this.memberCountErrorMsg = 'Please select a member to make payment.';
     //return;
   } else if('default' == this.selectedPaymentMethod) {
     this.memberMethodError = true;
     this.memberMethodErrorMsg = 'Please select a payment method.';
     //return;
   } else if(!this.showAmountNotEnteredErrorMessage && !this.paymentAmountError && !this.ispaymentAmountPatternError) {
      this.paymentService.payments = this.selectedMemberPaymentsList;
      this.paymentService.memberNameMap = memberNameMap;

      this.paymentService.selectedPaymentMethodTokenId = this.selectedPaymentMethod; //tokenId
      this.paymentService.selectedPaymentMethodNumber = this.creditCardBankAccNbrMap[this.selectedPaymentMethod];
      this.paymentService.bankAccountType = this.bankAccountTypeMap[this.selectedPaymentMethod];
      
      if(this.selectedPaymentMethod == 'oneTimePayment'){
        this.paymentService.selectedPaymentMethod = this.selectedPaymentMethod;
        this.router.navigate(['/oneTimePayment']);
      } else {
        this.paymentService.selectedPaymentMethod = this.paymentTypeMap[this.selectedPaymentMethod];
        this.router.navigate(['/confirmPayment']);
      }
   }
   
}

  resetPaymentServiceObject() {
    this.paymentService.bankAccountType = '';
    this.paymentService.confirmPaymentResponse = '';
    this.paymentService.maskedNumber = '';
    this.paymentService.memberNameMap = '';
    this.paymentService.payments = [];
    this.paymentService.selectedPaymentMethod = '';
    this.paymentService.selectedPaymentMethodNumber = '';
    this.paymentService.selectedPaymentMethodTokenId = '';

    this.paymentMethodsService.paymentMethod = null;
  }

}

