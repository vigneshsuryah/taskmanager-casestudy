import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { OneTimePaymentModule } from './makepayment/onetimepayment/onetimepayment.module';
import { ConfirmPaymentModule } from './makepayment/confirmpayment/confirmpayment.module';
import { CommonutilsModule } from '../../commonutils/commonutils.module';

import { PaymentsComponent } from './payments.component';
import { PaymentsRoutingModule } from './payments-routing.module';
import { UxModule } from '../../shared/ux.module'; 
import { PaymentRecordComponent } from './makepayment/paymentrecord/paymentrecord.component';

import { PaginationService } from '../../shared/pagination-service/pagination-service';
import { User } from '../../shared/models/user';



@NgModule({
  imports: [CommonModule, OneTimePaymentModule, ConfirmPaymentModule, UxModule, PaymentsRoutingModule, CommonutilsModule.forRoot()],
  declarations: [PaymentsComponent, PaymentRecordComponent],
  exports: [PaymentsComponent],
  providers: [gbdServiceList, PaginationService,User]
})
export class PaymentsModule { }