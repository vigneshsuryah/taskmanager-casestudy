import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { PaymentService } from '../../../../shared/gbd-service/payment-service';
import { PaymentMethodsService } from '../../../../shared/gbd-service/index';
import { gbdServiceList } from '../../../../shared/gbd-service/gbd-service';

import { Observable } from 'rxjs/Observable';
import { ConfirmPaymentModule } from './confirmpayment.module';
import { User } from '../../../../shared/models/user';
import { PaymentMethodModel } from '../../../../shared/models/paymentmethod.model';
import { PaymentRecordComponent } from '../../makepayment/paymentrecord/paymentrecord.component';
import { PaymentRecordModule } from '../../makepayment/paymentrecord/paymentrecord.module';

export function main() {
  let config: Route[] = [
    { path: 'paymentRecord', component: PaymentRecordComponent }
  ];

  let actualRes : any;
  actualRes = {
      "bankAccountType": "BUSINESS_CHECKING",
      "routingNumber": "111000025",
      "bankAccountNumber": "***2627",
      "accountHolderName": "Test QA",
      "accountAddress1": "314 INpolis Dr",
      "accountCity": "Indiaanapolis",
      "accountState": "IN",
      "accountPostalCode": "43020",
      "accountNickname": "HelloTest",
      "paymentType" : 'Banking'
    };


    let actualRes1 : any;
    actualRes1 = {
        "creditCardNumber": "************2687",
        "creditCardType": "VISA",
        "expirationMonth": "02",
        "expirationYear": "2018",
        "accountHolderName": "Name",
        "accountAddress1": "Address",
        "accountCity": "CA",
        "accountState": "CA",
        "accountPostalCode": "90001",
        "accountNickname": "NewlyAddedEdit",
        "paymentType" : 'CreditDebitCard'
    };


    let actualRes2 : any;
    actualRes2 = {
        
    };

    let actualRes3 : any;
    actualRes3 = {
        "bankAccountType": "Savings",
        "routingNumber": "111000025",
        "bankAccountNumber": "***2627",
        "accountHolderName": "Test QA",
        "accountAddress1": "314 INpolis Dr",
        "accountCity": "Indiaanapolis",
        "accountState": "IN",
        "accountPostalCode": "43020",
        "accountNickname": "HelloTest",
        "paymentType" : 'Banking',
        "isBusiness" : true
      };

      let actualRes4 : any;
      actualRes4 = {
          "bankAccountType": "Savings",
          "routingNumber": "111000025",
          "bankAccountNumber": "***2627",
          "accountHolderName": "Test QA",
          "accountAddress1": "314 INpolis Dr",
          "accountCity": "Indiaanapolis",
          "accountState": "IN",
          "accountPostalCode": "43020",
          "accountNickname": "HelloTest",
          "paymentType" : 'Banking',
          "isBusiness" : false
        };

      let actualRes5 : any;
      actualRes5 = {
        "bankAccountType": "Checking",
        "routingNumber": "111000025",
        "bankAccountNumber": "***2627",
        "accountHolderName": "Test QA",
        "accountAddress1": "314 INpolis Dr",
        "accountCity": "Indiaanapolis",
        "accountState": "IN",
        "accountPostalCode": "43020",
        "accountNickname": "HelloTest",
        "paymentType" : 'Banking',
        "isBusiness" : true
      };

      let actualRes6 : any;
      actualRes6 = {
        "bankAccountType": "Checking",
        "routingNumber": "111000025",
        "bankAccountNumber": "***2627",
        "accountHolderName": "Test QA",
        "accountAddress1": "314 INpolis Dr",
        "accountCity": "Indiaanapolis",
        "accountState": "IN",
        "accountPostalCode": "43020",
        "accountNickname": "HelloTest",
        "paymentType" : 'Banking',
        "isBusiness" : false
      };

  describe('Confirm Payment component', () => {
    
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, ConfirmPaymentModule, PaymentRecordModule, RouterTestingModule.withRoutes(config) ],
        declarations: [ConfirmPaymentTestComponent],
        providers: [
          PaymentService,
          PaymentMethodsService,
          gbdServiceList,
          User,
          PaymentMethodModel,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });


    it('confirmpayment should build without a problem - savedPayment',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentService.selectedPaymentMethodNumber = '****** 1234';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });


            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));



      it('confirmpayment should build without a problem - oneTimePayment - Banking',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'oneTimePayment';
            paymentMethodsService.paymentMethod = actualRes;

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));


      it('confirmpayment should build without a problem - oneTimePayment - CreditDebitCard',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);

            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes1 })));
            });
            
            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'oneTimePayment';
            paymentMethodsService.paymentMethod = actualRes1;

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));
      
      

      it('confirmpayment redirectToPaymentRecord - CreditDebitCard',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes1 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'oneTimePayment';
            paymentMethodsService.paymentMethod = actualRes1;

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));



      it('confirmpayment redirectToPaymentRecord - Banking',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'oneTimePayment';
            paymentMethodsService.paymentMethod = actualRes;

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));




      it('confirmpayment redirectToPaymentRecord - saved card',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes2 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentMethodsService.paymentMethod = null;
            paymentService.bankAccountType = 'BUSINESS_CHECKING';
            paymentService.selectedPaymentMethodTokenId = 'test';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));



      it('confirmpayment redirectToPaymentRecord Savings & Business',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes3 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentMethodsService.paymentMethod = null;
            paymentService.bankAccountType = 'BUSINESS_CHECKING';
            paymentService.selectedPaymentMethodTokenId = 'test';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));


      it('confirmpayment redirectToPaymentRecord Savings & not Business',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes4 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentMethodsService.paymentMethod = null;
            paymentService.bankAccountType = 'BUSINESS_CHECKING';
            paymentService.selectedPaymentMethodTokenId = 'test';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));



      it('confirmpayment redirectToPaymentRecord Checkings & Business',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes5 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentMethodsService.paymentMethod = null;
            paymentService.bankAccountType = 'BUSINESS_CHECKING';
            paymentService.selectedPaymentMethodTokenId = 'test';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));


      it('confirmpayment redirectToPaymentRecord Checkings & not Business',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let paymentMethodsService = TestBed.get(PaymentMethodsService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes6 })));
            });

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            paymentService.payments = paymentList;
            paymentService.selectedPaymentMethod = 'Banking';
            paymentMethodsService.paymentMethod = null;
            paymentService.bankAccountType = 'BUSINESS_CHECKING';
            paymentService.selectedPaymentMethodTokenId = 'test';

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let paymentMethodModel = TestBed.get(PaymentMethodModel);
            

            let fixture = TestBed.createComponent(ConfirmPaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.redirectToPaymentRecord();
            expect(instance.screenLoader).toBe(false);
  
          });

      }));

  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-confirmpayment></gbdtpp-confirmpayment>'
})
class ConfirmPaymentTestComponent { }
