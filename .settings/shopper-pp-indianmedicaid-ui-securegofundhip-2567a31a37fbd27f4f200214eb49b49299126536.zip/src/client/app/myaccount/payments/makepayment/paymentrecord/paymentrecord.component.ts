import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { PaymentModel } from '../../../../shared/models/payment.model';
import { PaymentService } from '../../../../shared/gbd-service/payment-service';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-paymentrecord',
  templateUrl: 'paymentrecord.component.html',
  styleUrls: ['paymentrecord.component.css']
  
})
export class PaymentRecordComponent implements OnInit {

  submitPaymentResponseList: any = [];
  showLoader: boolean;
  paymentFailed : boolean;
  paymentFailedMsg: number;
  //paymentFailedErrorMsg : string;
  //memberNameMap: any = {};
  selectedMemberPaymentsList: any = [];
  paymentMethod : any = [];
  submitPaymentResponse: any = {};
  modifiedsubmitPaymentResponseList : any = [];
  isPaymentError: boolean;
  isAciServiceError: boolean = false;

  constructor(public router: Router,private paymentService : PaymentService) {
  }

  ngOnInit() {
    this.showLoader = true;
    this.isAciServiceError = false;
    this.paymentFailedMsg = 16;
    this.submitPaymentResponseList = this.paymentService.confirmPaymentResponse;
    this.paymentMethod = this.paymentService.maskedNumber;  
    /*this.memberNameMap = this.paymentService.memberNameMap;
    var memberFullName = '';*/
    if(this.submitPaymentResponseList !=null && this.submitPaymentResponseList !=undefined){	
      for(let submitPaymentRes of this.submitPaymentResponseList) {
        this.submitPaymentResponse = {};
        this.isPaymentError = false;
        if(submitPaymentRes.resMessageCode == '3002' || submitPaymentRes.resMessageCode == '3003') {
            this.showLoader = true;
            this.isAciServiceError = true;
        } else {
          this.submitPaymentResponse.memberId = submitPaymentRes.memberId;
          /*memberFullName = this.memberNameMap[submitPaymentRes.memberId];
          if((undefined == memberFullName || '' == memberFullName) && submitPaymentRes.memberId.length == 12) {
              memberFullName = this.memberNameMap[submitPaymentRes.memberId.slice(3)];
              this.submitPaymentResponse.memberId = submitPaymentRes.memberId.slice(3);
          }
          this.submitPaymentResponse.memberName = memberFullName;*/
          if(submitPaymentRes.paymentAmount.indexOf(".") > -1) {
              this.submitPaymentResponse.paymentAmount = '$' + submitPaymentRes.paymentAmount;
          } else {
              this.submitPaymentResponse.paymentAmount = '$' + submitPaymentRes.paymentAmount + ".00";
          }
          this.submitPaymentResponse.paymentDate = submitPaymentRes.paymentDate;
          this.submitPaymentResponse.confirmationNumber = submitPaymentRes.confirmationNumber;
                  
          if(submitPaymentRes.resMessageCode != '0') {
            this.isPaymentError = true;
            this.paymentFailed = true;
            //this.paymentFailedErrorMsg = "Hmmm...Looks like there's a problem with one of your payments. Try again with a different payment method.";
          }
          this.submitPaymentResponse.isPaymentError = this.isPaymentError;
          this.modifiedsubmitPaymentResponseList.push(this.submitPaymentResponse);
        }       
      }    
    }
    if( !this.isAciServiceError){
    this.showLoader = false;
    }
     
  }  

  redirectToMyAccount() {
      this.router.navigate(['/myAccount']);
  }
}