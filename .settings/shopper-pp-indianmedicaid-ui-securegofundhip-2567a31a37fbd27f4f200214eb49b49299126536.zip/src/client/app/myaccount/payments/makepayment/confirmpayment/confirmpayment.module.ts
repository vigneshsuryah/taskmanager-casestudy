import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { CommonutilsModule } from '../../../../commonutils/commonutils.module'; 
import { ConfirmPaymentComponent } from './confirmpayment.component';
import { User } from '../../../../shared/models/user';

@NgModule({
  imports: [CommonModule, CommonutilsModule],
  declarations: [ConfirmPaymentComponent],
  exports: [ConfirmPaymentComponent],
  providers: [DatePipe,User]
})
export class ConfirmPaymentModule { }