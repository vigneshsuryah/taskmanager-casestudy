import { Component, ChangeDetectionStrategy } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { gbdServiceList } from '../../../../shared/gbd-service/index';
import { AuthenticationService } from '../../../../shared/gbd-service/index';
import { PaymentMethodsService } from '../../../../shared/gbd-service/index';

import { Observable } from 'rxjs/Observable';
import { OneTimePaymentModule } from './onetimepayment.module';
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';

import { MyaccountModule } from '../../../../myaccount/myaccount.module';
import { MyaccountComponent } from '../../../../myaccount/myaccount.component';
import { ConfirmPaymentComponent } from '../../makepayment/confirmpayment/confirmpayment.component';
import { ConfirmPaymentModule } from '../../makepayment/confirmpayment/confirmpayment.module';

export function main() {
  
    let dummyObj = {
                    "accountAddress1":"",
                    "accountAddress2":"",
                    "accountCity":"",
                    "accountHolderName":"",
                    "accountNickname":"",
                    "accountPostalCode":"", 
                    "accountState":"", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"",
                    "creditCardType":"",
                    "expirationMonth":"",
                    "expirationYear":"",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };

 


  describe('One Time Payment component', () => {

         let config: Route[] = [
        { path: 'confirmPayment', component: ConfirmPaymentComponent },
        { path: 'myAccount', component: MyaccountComponent }
        ];
    
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, MyaccountModule,ConfirmPaymentModule,HttpModule, OneTimePaymentModule, RouterTestingModule.withRoutes(config)  ],
        declarations: [OneTimePaymentTestComponent],
        providers: [
          gbdServiceList,
          AuthenticationService,
          PaymentMethodsService,
          User,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      }).overrideComponent(OneTimePaymentTestComponent, {
        set: {
            providers: [
            {provide: PaymentMethodsService, useClass: MockPaymentMethodsService}
            ]
        }
        });
    });

     
      it('onetimepayment oneTimePaymentTypeDropdown value to be CreditDebitCard',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
              

                let fixture = TestBed.createComponent(OneTimePaymentTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
    
                fixture.detectChanges();
     

                paymentsInstance.oneTimePaymentTypeDropdown('CreditDebitCard');
                expect(paymentsInstance.value).toBe('creditDebitCard');
                
            
          });

      }));

      
      it('onetimepayment oneTimePaymentTypeDropdown value to be bank account',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {

                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
              

                let fixture = TestBed.createComponent(OneTimePaymentTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
    
                fixture.detectChanges();
     

                paymentsInstance.oneTimePaymentTypeDropdown('Banking');
                expect(paymentsInstance.value).toBe('bankAccount');
                
            
          });

      }));

       it('onetimepayment myAccount Routing',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
         
                let fixture = TestBed.createComponent(OneTimePaymentTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
               
                fixture.detectChanges();
             
                paymentsInstance.redirectToMyAccount();
                    
                let compiled = fixture.nativeElement;

                expect(compiled).toBeTruthy();
                
            });

        }));

         it('onetimepayment confirmPayment Routing',
        async(() => {
            TestBed
            .compileComponents()
            .then(() => {
                let user = TestBed.get(User);
                user.username = 'vsuser101';
                user.orgType = 'Test';
                user.orgName = 'Cognizant';
                
                let authenticationService = TestBed.get(AuthenticationService);
                authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
                
         
                let fixture = TestBed.createComponent(OneTimePaymentTestComponent);
                let paymentsInstance = fixture.debugElement.children[0].componentInstance;
               
                fixture.detectChanges();
             
                let paymentObj = {
                        "accountAddress1":"Address",
                        "accountAddress2":"",
                        "accountCity":"California",
                        "accountHolderName":"Test",
                        "accountNickname":"test",
                        "accountPostalCode":"90001", 
                        "accountState":"CA", 
                        "bankAccountNumber":"", 
                        "bankAccountType":"",
                        "routingNumber":"", 
                        "tokenId":"",
                        "accountType":"",
                        "isBusiness":"",
                        "creditCardNumber":"4111111114362521",
                        "creditCardType":"VISA",
                        "expirationMonth":"05",
                        "expirationYear":"2020",
                        "paymentType":"CreditDebitCard",
                        "cardType":""
                };
                paymentsInstance.confirmPayment(paymentObj);
                    
                let compiled = fixture.nativeElement;

                expect(compiled).toBeTruthy();
                
            });

        }));



  });
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'test-cmp',
  template: '<gbdtpp-onetimepayment></gbdtpp-onetimepayment>'
})
class OneTimePaymentTestComponent { }
class MockPaymentMethodsService {
 paymentMethod ={
                    "accountAddress1":"Address",
                    "accountAddress2":"",
                    "accountCity":"California",
                    "accountHolderName":"Test",
                    "accountNickname":"test",
                    "accountPostalCode":"90001", 
                    "accountState":"CA", 
                    "bankAccountNumber":"", 
                    "bankAccountType":"",
                    "routingNumber":"", 
                    "tokenId":"",
                    "accountType":"",
                    "isBusiness":"",
                    "creditCardNumber":"4111111114362521",
                    "creditCardType":"VISA",
                    "expirationMonth":"05",
                    "expirationYear":"2020",
                    "paymentType":"CreditDebitCard",
                    "cardType":""
            };
      getMethodResponse   = {
      "creditCardDetails": [
          {
              "creditCardNumber": "************2687",
              "creditCardType": "VISA",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "Name",
              "accountAddress1": "Address",
              "accountCity": "CA",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "NewlyAddedEdit",
              "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "03",
              "expirationYear": "2018",
              "accountHolderName": "test",
              "accountAddress1": "test",
              "accountCity": "California",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfa",
              "tokenId": "591EAED9218DA1685093D17AA4396863"
          },
          {
              "creditCardNumber": "************2537",
              "creditCardType": "MC",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "SD",
              "accountAddress1": "SDf",
              "accountCity": "SDf",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "SDfasdfas",
              "tokenId": "4BF17DE91EE3E3948C2A4C3AD45B817F"
          }
      ],
      "paymentsPaginationCount": 7
  };
};