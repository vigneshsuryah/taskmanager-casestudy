import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

import { PaymentMethodsService } from '../../../../shared/gbd-service/index';
import { gbdServiceList } from '../../../../shared/gbd-service/gbd-service';
import { PaymentService } from '../../../../shared/gbd-service/payment-service';
import { User } from '../../../../shared/models/user';

declare var PIE:any;
declare var ProtectPANandCVV:Function;

@Component({
    moduleId: module.id,
    selector: 'gbdtpp-confirmpayment',
    templateUrl: 'confirmpayment.component.html',
    styleUrls: ['confirmpayment.component.css']
})
export class ConfirmPaymentComponent implements OnInit {

    paymentMethod: any={};
    paymentsModel: any={};
    today: number = Date.now();
    maskedNumber : string;
    inputParam: any = '';
    screenLoader: boolean = false;
    paymentDate: any;
    businessAccountTypeVal: string;
    selectedMemberPaymentsList: any = [];
    memberpaySubmitPayments: any = [];
    memberpaySubmitPaymentsList: any = [];
    paymentMethodType: string;
    memberNameMap: any = {};
    showContent: string;
    makePaymentType: string;
    encryptionData : any = {};

    constructor (public router : Router, private gbdServiceList: gbdServiceList, 
        private datepipe: DatePipe, private paymentService : PaymentService, 
        private paymentMethodsService: PaymentMethodsService, private currentUser: User){  
    }

    ngOnInit(){

        this.paymentDate = this.datepipe.transform(this.today, 'yyyy-MM-dd');
        this.selectedMemberPaymentsList = this.paymentService.payments;
        this.memberNameMap = this.paymentService.memberNameMap;

        this.gbdServiceList.consoleLog(JSON.stringify(this.selectedMemberPaymentsList));
        this.paymentMethod = this.paymentMethodsService.paymentMethod;
        this.makePaymentType = this.paymentService.selectedPaymentMethod;

        if(this.paymentService.selectedPaymentMethod == 'oneTimePayment'){ 
            this.paymentMethodType = this.paymentMethod.paymentType;
            this.makePaymentType = "oneTimePayment";
        }else{
            this.paymentMethodType = this.paymentService.selectedPaymentMethod;  
            this.makePaymentType = "savedPayment";      
        }
        this.gbdServiceList.consoleLog(this.paymentMethodType+" Method type and method "+this.paymentService.selectedPaymentMethod);
        if(this.paymentMethodType =='Banking' && this.paymentService.selectedPaymentMethod == 'oneTimePayment'){
            var bankAccountlength = this.paymentMethod.bankAccountNumber.length;
            var i;
            var maskedString = "";
            for(i=0;i<bankAccountlength-4;i++){
                maskedString += 'x';
            }
            this.maskedNumber = maskedString+this.paymentMethod.bankAccountNumber.slice(-4);
        }else if (this.paymentMethodType == 'CreditDebitCard' && this.paymentService.selectedPaymentMethod == 'oneTimePayment'){
            var cardNumberlength = this.paymentMethod.creditCardNumber.length;
            var i;
            var maskedString = "";
            for(i=0;i<cardNumberlength-4;i++){
                maskedString += 'x';
            }
            this.maskedNumber = maskedString+this.paymentMethod.creditCardNumber.slice(-4);
        } else {
            this.maskedNumber = this.paymentService.selectedPaymentMethodNumber ? this.paymentService.selectedPaymentMethodNumber : "";
        }
        this.paymentService.maskedNumber = this.maskedNumber;
    }

    redirectToMyAccount(){
        this.router.navigate(['/myAccount']);
    } 

    redirectToPaymentRecord() {
        var selectedPaymentType = '';
        var selectedBankAccountType = '';
        this.screenLoader = true;

        this.paymentService.memberNameMap = this.memberNameMap;
        //alert("confirm"+JSON.stringify(this.paymentService.memberNameMap));
        this.constructMemberpaySubmitPayments(this.selectedMemberPaymentsList);
        this.gbdServiceList.consoleLog("ConfirmPaymentScreen "+JSON.stringify(this.paymentMethod));
        if(this.paymentMethod != null && this.paymentMethod !=undefined){
            if(this.paymentMethod.bankAccountType == 'Savings' && this.paymentMethod.isBusiness){
            this.businessAccountTypeVal = 'BUSINESS_SAVINGS';
            }
            if(this.paymentMethod.bankAccountType == 'Savings' && !this.paymentMethod.isBusiness){
            this.businessAccountTypeVal = 'PERSONAL_SAVINGS';
            }
            if(this.paymentMethod.bankAccountType == 'Checking' && this.paymentMethod.isBusiness){
            this.businessAccountTypeVal = 'BUSINESS_CHECKING';
            }
            if(this.paymentMethod.bankAccountType == 'Checking' && !this.paymentMethod.isBusiness){
            this.businessAccountTypeVal = 'PERSONAL_CHECKING';
            }
        }

        if(this.paymentMethod != null && this.paymentMethod !=undefined  && this.paymentMethod.paymentType == 'CreditDebitCard'){
            this.encryptionData = this.doEncryption(this.paymentMethod.creditCardNumber);
            this.inputParam = {
                //"healthCardId": this.currentUser.username,
                "memberpaySubmitPayments" : this.memberpaySubmitPaymentsList,
                "newPaymentMethod" : true,
                "payMetFutureUse" : false,
                "paymentType" : "CREDITDEBITCARD",
                "creditCardDetails":{  
                    "creditCardNumber":this.encryptionData.encryptccno,
                    "creditCardType":this.paymentMethod.creditCardType,
                    "expirationMonth":this.paymentMethod.expirationMonth,
                    "expirationYear":this.paymentMethod.expirationYear,
                    "accountHolderName":this.paymentMethod.accountHolderName,
                    "accountAddress1":this.paymentMethod.accountAddress1,
                    "accountAddress2":this.paymentMethod.accountAddress2,
                    "accountCity":this.paymentMethod.accountCity,
                    "accountState":this.paymentMethod.accountState,
                    "accountPostalCode":this.paymentMethod.accountPostalCode,
                    "tokenId": null,
                    "formatID":"64",
                    "integrityCheck" : this.encryptionData.integritycheck,
                    "keyID" : this.encryptionData.keyid,
                    "phaseID" : this.encryptionData.phase+''
                },
                "orgName":this.currentUser.orgName,
                "paymentDate" : this.paymentDate
        }
        }

        else if(this.paymentMethod != null  && this.paymentMethod !=undefined && this.paymentMethod.paymentType =='Banking'){
            this.inputParam = {
                //"healthCardId": this.currentUser.username,
                "memberpaySubmitPayments" : this.memberpaySubmitPaymentsList,
                "newPaymentMethod" : true,
                "payMetFutureUse" : false,
                "paymentType" : "BANKINGACCOUNT",
                "bankAccountDetails":{  
                    "bankAccountType":this.businessAccountTypeVal,
                    "routingNumber":this.paymentMethod.routingNumber,
                    "bankAccountNumber":this.paymentMethod.bankAccountNumber,
                    "accountHolderName":this.paymentMethod.accountHolderName,
                    "accountAddress1":this.paymentMethod.accountAddress1,
                    "accountAddress2":this.paymentMethod.accountAddress2,
                    "accountCity":this.paymentMethod.accountCity,
                    "accountState":this.paymentMethod.accountState,
                    "accountPostalCode":this.paymentMethod.accountPostalCode
                },
                "orgName":this.currentUser.orgName,
                "paymentDate" : this.paymentDate
            }
        }

        else{
            if(this.paymentService.selectedPaymentMethod != undefined && this.paymentService.selectedPaymentMethod == 'Banking') {
                selectedPaymentType = 'BANKINGACCOUNT';
            } else {
                selectedPaymentType = 'CREDITDEBITCARD';
            }

            if(this.paymentService.bankAccountType != undefined && this.paymentService.bankAccountType != '') {
                selectedBankAccountType = this.paymentService.bankAccountType;
            } else {
                selectedBankAccountType = 'NONE';
            }

            this.inputParam = {
                //"healthCardId" : this.currentUser.username,
                "memberpaySubmitPayments" : this.memberpaySubmitPaymentsList,
                "newPaymentMethod" : false,
                "payMetFutureUse" : false,
                "paymentType" : selectedPaymentType,
                "bankAccountType" : selectedBankAccountType,
                "orgName":this.currentUser.orgName,
                "tokenId" : this.paymentService.selectedPaymentMethodTokenId,
                "paymentDate" : this.paymentDate
            }
        } 
          this.gbdServiceList.consoleLog("In confirm payment service call " +JSON.stringify(this.inputParam));
     this.gbdServiceList.submitPayment(this.inputParam).subscribe((data: any) => {   
          this.paymentService.confirmPaymentResponse = data;
          this.gbdServiceList.consoleLog(data);
          this.router.navigate(['/paymentRecord']);
          this.screenLoader = false;
     },
     (err: any) => {
       this.showContent = 'paymentServiceError';
       this.screenLoader = false;
      }
     );
    }

    constructMemberpaySubmitPayments(selectedMemberPaymentsList : any) {
        for(var i=0; i<selectedMemberPaymentsList.length ; i++) {
            var memberpaySubmitPayments = {
                        "childHealthCardId" : selectedMemberPaymentsList[i].memberId,
                        "planID" : "",
                        "paymentAmount" : selectedMemberPaymentsList[i].amount
            };
            this.memberpaySubmitPayments.push(memberpaySubmitPayments);
        }
        this.memberpaySubmitPaymentsList = this.memberpaySubmitPayments;
    }

    doEncryption(ccno: any) {
        this.encryptionData={};
        this.encryptionData.ccno=ccno;
        var result=ProtectPANandCVV(ccno,"",true);
        //console.log('result : ' + JSON.stringify(result));
        if(result!=null && result!= undefined) {
            this.encryptionData.encryptccno=result[0];
            if(result.length >2){
                this.encryptionData.integritycheck = result[2];
            } 
        }else{
            alert("Error: ProtectPANandCVV call returned null. You may have entered an invalid card number.");
        }
        this.encryptionData.keyid = PIE.key_id;
        this.encryptionData.phase = PIE.phase;
        return this.encryptionData;
    } 
   

}