import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonutilsModule } from '../../../../commonutils/commonutils.module'; 
import { UxModule } from '../../../../shared/ux.module';

import { OneTimePaymentComponent } from './onetimepayment.component';

@NgModule({
  imports: [CommonModule, CommonutilsModule, UxModule, CommonutilsModule.forRoot()],
  declarations: [OneTimePaymentComponent],
  exports: [OneTimePaymentComponent]
})
export class OneTimePaymentModule { }
