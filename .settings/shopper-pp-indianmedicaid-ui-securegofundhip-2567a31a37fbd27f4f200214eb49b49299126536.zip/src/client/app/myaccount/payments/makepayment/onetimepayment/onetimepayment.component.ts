import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentMethodModel } from '../../../../shared/models/paymentmethod.model';
import { gbdServiceList } from './../../../../../app/shared/gbd-service/gbd-service';
import { PaymentMethodsService } from '../../../../shared/gbd-service/index';
import { content } from '../../../../shared/constants/constants';
import { ValidateRoutingNo } from '../../../../shared/models/validateRoutingNo.model';

declare var jQuery:any;

@Component({
    moduleId: module.id,
    selector: 'gbdtpp-onetimepayment',
    templateUrl: 'onetimepayment.component.html',
    styleUrls: ['onetimepayment.component.css']
})
export class OneTimePaymentComponent implements OnInit{

    paymentMethodNew : any = {};
    content : any = {};
    maskedAccountNumber : string;
    maskedCardNumber : string;

    constructor (public router : Router, private gbdServiceList: gbdServiceList, private paymentMethodsService: PaymentMethodsService){
        this.paymentMethodNew = paymentMethodsService.getMethodResponse;
    }

    backEndErrorMsg: string;
    backEndError: boolean = false;
    inputParam: any = '';
    businessAccountTypeVal: string;
    getMethodResponse: any = {};
    responseLength: any = 0;
    value: String = "creditDebitCard";
    validationError:boolean=false;
    paymentMethodSelected:string = '';
    showBank : boolean = false;
    public routingNoValidations:Array<string>=[];
    bankName: string = '';
    model = {
            "accountAddress1":"",
            "accountAddress2":"",
            "accountCity":"",
            "accountHolderName":"",
            "accountPostalCode":"", 
            "accountState":"", 
            "bankAccountNumber":"", 
            "bankAccountType":"",
            "routingNumber":"", 
            "tokenId":"",
            "accountType":"",
            "isBusiness":"",
            "creditCardNumber":"",
            "creditCardType":"",
            "expirationMonth":"",
            "expirationYear":"",
            "paymentType":"",
            "cardType":""
        };
   

    oneTimePaymentTypeDropdown(paymentMethod: any){ 
        console.log('inside paymentMethod :' + paymentMethod);
        if(paymentMethod == 'CreditDebitCard'){
            this.value = "creditDebitCard";
            this.setTabIndexOfLabels();
        }else if (paymentMethod == 'Banking'){
            this.value = "bankAccount";
            this.model.bankAccountType = 'Checking';
            this.setTabIndexOfLabels();
        }
     
    }

    redirectToMyAccount(){
        this.router.navigate(['/myAccount']);
    } 

  confirmPayment(paymentMethod: PaymentMethodModel){
        this.gbdServiceList.consoleLog("paymentMethod"+JSON.stringify(paymentMethod));
        this.paymentMethodsService.paymentMethod = paymentMethod;
        this.router.navigate(['/confirmPayment']);
   }

  ngOnInit() {
    this.value = "creditDebitCard";
    this.model.paymentType = "CreditDebitCard";
    this.content = content;
    this.setTabIndexOfLabels();
    this.showBank = false;
    this.routingNoValidations = [];
    this.bankName = '';
  }

  setTabIndexOfLabels(){
      console.log('inside setTabIndexOfLabels');
    setTimeout(()=>{
      jQuery(".dropdown-label").attr("tabindex","0");
    },100); 
   }

   validateBankDetails(routingNo: string){
        this.showBank = false;
        if(null !== routingNo && undefined !== routingNo && routingNo !== '' && routingNo.length === 9){
            this.inputParam = {
                "routingNumber": routingNo
            }
            this.gbdServiceList.getValidationBankDetails(this.inputParam).subscribe((data: ValidateRoutingNo) => {
                this.routingNoValidations = [];
                console.log("data: "+data);
                if (data && data.exceptions) {
                    data.exceptions.forEach(x => {
                        this.routingNoValidations.push(x.message);
                    });
                } else if (data && data.valid === false) {
                    this.routingNoValidations.push('Please enter a valid bank routing number');
                } else if (data && data.valid === true) {
                    this.bankName = data.routingNoDetails.customerName;
                    this.showBank = true;
                }
            });
        }
    }

}