import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { PaymentService } from '../../../../shared/gbd-service/payment-service';

import { Observable } from 'rxjs/Observable';
import { PaymentRecordModule } from './paymentrecord.module';
export function main() {
  
  
  describe('PaymentRecord component', () => {
    
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, PaymentRecordModule, RouterTestingModule ],
        declarations: [PaymentRecordTestComponent],
        providers: [
          PaymentService,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

   it('validate for ACI service unavailable to return false - payment failed',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;
            
            let fixture = TestBed.createComponent(PaymentRecordTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            expect(instance.isAciServiceError).toBe(false);
            
          });

    }));
      
    it('validate for ACI service error to return true - payment failed',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            paymentService.confirmPaymentResponse = [{memberId: 'YRK751M56029',paymentAmount: '321.81',confirmationNumber: 'There is a problem processing your payment with this credit/debitcard. Please try again.',paymentDate: '2017-06-14',resMessageCode: '1002'}];
            paymentService.memberNameMap = memberNameMap;

            let fixture = TestBed.createComponent(PaymentRecordTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            expect(instance.paymentFailed).toBe(true);
            
          });

      }));

      it('validate for ACI service error to return false - payment success',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let paymentService = TestBed.get(PaymentService);
            let memberNameMap : any = {};
            memberNameMap['YRK751M56029']='Test test';

            paymentService.confirmPaymentResponse = [{memberId: 'YRK382M56770', paymentAmount:'321.15', confirmationNumber: '201722454542', paymentDate:'2017-06-24', resMessageCode: '0'}];
            paymentService.memberNameMap = memberNameMap;

            let fixture = TestBed.createComponent(PaymentRecordTestComponent);
            let payemntsInstance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            expect(payemntsInstance.paymentFailed).toBe(undefined);
            
          });

      }));
  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-paymentrecord></gbdtpp-paymentrecord>'
})
class PaymentRecordTestComponent { }
