import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonutilsModule } from '../../../../commonutils/commonutils.module';
import { SharedModule } from '../../../../shared/shared.module'; 
import { PaymentRecordComponent } from './paymentrecord.component';

@NgModule({
  imports: [CommonModule, SharedModule, CommonutilsModule.forRoot()],
  declarations: [PaymentRecordComponent],
  exports: [PaymentRecordComponent],
})
export class PaymentRecordModule { }