import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { PaymentService } from '../../shared/gbd-service/payment-service';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { AuthenticationService } from '../../shared/gbd-service/index';
import { PaginationService } from '../../shared/pagination-service/pagination-service';
import { PaymentMethodsService } from '../../shared/gbd-service/index';
import { PaymentsModule } from '../../myaccount/payments/payments.module';

import { Observable } from 'rxjs/Observable';

import { User } from '../../shared/models/user';
import { PaymentModel } from '../../shared/models/payment.model';

import { OneTimePaymentComponent } from './makepayment/onetimepayment/onetimepayment.component';
import { ConfirmPaymentComponent } from './makepayment/confirmpayment/confirmpayment.component';

//import { MyaccountComponent } from '../../myaccount/myaccount.component';

export function main() {
  
  let config: Route[] = [
    { path: 'oneTimePayment', component: OneTimePaymentComponent },
    { path: 'confirmPayment', component: ConfirmPaymentComponent },
  ];

  let actualRes : any;
  actualRes = {
      "bankAccountDetails": [
        {
            "bankAccountType": "BUSINESS_CHECKING",
            "routingNumber": "111000025",
            "bankAccountNumber": "***2627",
            "accountHolderName": "Test QA",
            "accountAddress1": "314 INpolis Dr",
            "accountCity": "Indiaanapolis",
            "accountState": "IN",
            "accountPostalCode": "43020",
            "accountNickname": "HelloTest",
            "tokenId": "4062E329C1E636C0EFD063EAEEE5A843"
        },
        {
            "bankAccountType": "BUSINESS_SAVINGS",
            "routingNumber": "111000025",
            "bankAccountNumber": "***2627",
            "accountHolderName": "Test QA",
            "accountAddress1": "314 INpolis Dr",
            "accountCity": "Indiaanapolis",
            "accountState": "IN",
            "accountPostalCode": "43020",
            "accountNickname": "HelloTest",
            "tokenId": "4062E329C1E636C0EFD063EAEEE5A843"
        }
      ],
      "creditCardDetails": [
          {
              "creditCardNumber": "************2687",
              "creditCardType": "VISA",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "Name",
              "accountAddress1": "Address",
              "accountCity": "CA",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "NewlyAddedEdit",
              "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
          },
          {
              "creditCardNumber": "************2687",
              "creditCardType": "MC",
              "expirationMonth": "02",
              "expirationYear": "2018",
              "accountHolderName": "Name",
              "accountAddress1": "Address",
              "accountCity": "CA",
              "accountState": "CA",
              "accountPostalCode": "90001",
              "accountNickname": "NewlyAddedEdit",
              "tokenId": "67D75B21D0EB33A7A8EE010E23880B41"
          }
      ],
      "message": {
        "messageCode": "00",
        "messageText": "Members retrieved"
      },
      "tppMemberDetails": [
          {
              "fullName": "Donna Howell",
              "memberId": "341M63686",
              "dateOfBirth": "06/09/1954",
              "checked": false
          },
          {
              "fullName": "Jared Kempton",
              "memberId": "223M79156",
              "dateOfBirth": "05/20/1979",
              "checked": false
          },
          {
              "fullName": "Jared Test",
              "memberId": "223M79158",
              "dateOfBirth": "05/29/1969",
              "checked": false
          },
          {
              "fullName": "Test Test",
              "memberId": "229M79158",
              "dateOfBirth": "09/29/1989",
              "checked": false
          }
      ],
      "memberPaginationCount": 3,
      "paymentsPaginationCount": 3
    };

  
  let actualRes1 : any;
  actualRes1 = {
      "message": {
        "messageCode": "99",
        "messageText": "Members not retrieved"
      },
      "tppMemberDetails": [
      ],
      "memberPaginationCount": 3,
      "paymentsPaginationCount": 3
    };

  
  describe('Payments component', () => {
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        //imports: [FormsModule, RouterModule, HttpModule, PaymentsModule, RouterTestingModule.withRoutes(config) ],
        //declarations: [PaymentTestComponent, MyaccountComponent],
        imports: [FormsModule, RouterModule, HttpModule, PaymentsModule, RouterTestingModule.withRoutes(config)],
        declarations: [PaymentTestComponent],
        providers: [
          PaymentService,
          gbdServiceList,
          PaginationService,
          AuthenticationService,
          PaymentMethodsService,
          User,
          PaymentModel,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

   /*it('payments should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(PaymentTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));*/

   it('validate for valid amount range',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = TestBed.get(PaymentModel);
            payment.memberId = '1';
            payment.memberName = 'Member1';
            payment.amount = '$120.00';
            payment.isChecked = false;
            payment.paymentDate = '';
            payment.confirmationNumber = '';
            
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(false);
            
          });

      }));


    it('validate for invalid amount range',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = { memberId: '1', memberName: 'Member1', amount :'$1234.00', isChecked : false, paymentDate :'', confirmationNumber : ''};

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
            

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(true);
            
          });

      }));


      it('validate for invalid amount range1',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = { memberId: '1', memberName: 'Member1', amount :'$', isChecked : false, paymentDate :'', confirmationNumber : ''};

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
            

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(true);
            
          });

      }));


      it('validate for invalid amount range2',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = { memberId: '1', memberName: 'Member1', amount :'1', isChecked : false, paymentDate :'', confirmationNumber : ''};

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
            

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(false);
            
          });

      }));



      it('validate for invalid amount range3',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = { memberId: '1', memberName: 'Member1', amount :'$123', isChecked : false, paymentDate :'', confirmationNumber : ''};

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
            

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(false);
            
          });

      }));


      it('validate for invalid amount range4',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = { memberId: '1', memberName: 'Member1', amount :'', isChecked : false, paymentDate :'', confirmationNumber : ''};

            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });
            

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            instance.validateAmountEntered(payment);
            expect(instance.ispaymentAmountError).toBe(false);
            
          });

      }));


      it('validate for space',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();

            expect(instance.validateNoSpaces(' ')).toBe(true);
            
          });

  }));
      


      it('validateCheckBox selectedMemberCount to be 6',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.validateCheckBox();
            expect(instance.selectedMemberCount).toBe(6);
            
          });

      }));


      it('validateCheckBox selectedMemberCount to be 3',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : true, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.validateCheckBox();
            expect(instance.selectedMemberCount).toBe(3);
            
          });

      }));



      it('submitPayment selectedMemberCount == 0',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''},
                              { memberId: '2', memberName: 'Member2', amount :'$1205.00', isChecked : false, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.submitPayment();
            expect(instance.selectedMemberCount).toBe(0);
            
          });

      }));


      it('submitPayment payment method error',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'default';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.memberMethodError).toBe(true);
            
          });

      }));



      it('submitPayment validatePaymentMethod payment method error',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'112', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'test';
            fixture.detectChanges();
            instance.validatePaymentMethod();
            expect(instance.memberMethodError).toBe(false);
            
          });

      }));


      it('submitPayment showAmountNotEnteredErrorMessage',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$112', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'default';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.memberMethodError).toBe(true);
            
          });

      }));


      it('submitPayment paymentAmountError',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'123', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'test';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.paymentAmountError).toBe(true);
            
          });

      }));



      it('submitPayment ispaymentAmountPatternError',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$120.123', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'test';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.ispaymentAmountPatternError).toBe(true);
            
          });

      }));


      it('submitPayment success saved payment method',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$789', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'test';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.paymentAmountError).toBe(false);
            
          });

      }));


      it('submitPayment success one time payment',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let paymentList = [{ memberId: '1', memberName: 'Member1', amount :'$789', isChecked : true, paymentDate :'', confirmationNumber : ''}];

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.paymentList = paymentList;
            instance.selectedPaymentMethod = 'oneTimePayment';
            fixture.detectChanges();
            instance.submitPayment();
            expect(instance.paymentAmountError).toBe(false);
            
          });

      }));

      it('validate for no payment method response',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = TestBed.get(PaymentModel);
            payment.memberId = '1';
            payment.memberName = 'Member1';
            payment.amount = '$120.00';
            payment.isChecked = false;
            payment.paymentDate = '';
            payment.confirmationNumber = '';
            
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes1 })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            expect(instance.responseLength).toBe(0);
            
          });

      }));
      
      
      it('clearCheckBox',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let payment = TestBed.get(PaymentModel);
            payment.memberId = '1';
            payment.memberName = 'Member1';
            payment.amount = '$120.00';
            payment.isChecked = false;
            payment.paymentDate = '';
            payment.confirmationNumber = '';
            
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';

            let fixture = TestBed.createComponent(PaymentTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.clearCheckBox();
            expect(instance.responseLength).toBe(4);
            
          });

      }));

  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-payments></gbdtpp-payments>'
})
class PaymentTestComponent { }
