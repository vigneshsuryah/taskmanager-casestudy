import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule , Router } from '@angular/router';
import { AddMemberModule } from './addmember/addmember.module';
import { MemberDetailsComponent } from './memberdetails.component';
import { MemberDetailsService } from './memberdetails.service';
import { UxModule } from '../../shared/ux.module';
import { CommonutilsModule } from '../../commonutils/commonutils.module'; 
import { PaginationService } from '../../shared/pagination-service/pagination-service';
import { MemberDetailRoutingModule } from './memberdetails-routing.module';
import { DatePipe } from '@angular/common';
import { User } from '../../shared/models/user';

@NgModule({
  imports: [CommonModule, AddMemberModule,MemberDetailRoutingModule, CommonutilsModule, UxModule, CommonutilsModule.forRoot()],
  declarations: [MemberDetailsComponent],
  exports: [MemberDetailsComponent],
  providers:[MemberDetailsService, PaginationService,DatePipe,User]  
})
export class MemberDetailsModule {}