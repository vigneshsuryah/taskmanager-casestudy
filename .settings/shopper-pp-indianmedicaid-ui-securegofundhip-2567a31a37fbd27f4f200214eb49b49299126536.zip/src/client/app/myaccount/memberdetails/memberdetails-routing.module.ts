import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthGuard } from '../../shared/guards/index';
import {AddMemberComponent} from './addmember/addmember.component';


@NgModule({
imports:[
    RouterModule.forChild([
        {path: 'addMember', component: AddMemberComponent,canActivate: [AuthGuard] }        
        ])
],
exports:[RouterModule]
})

export class MemberDetailRoutingModule{

}