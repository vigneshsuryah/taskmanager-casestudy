import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';

import { CONFIG } from '../../config';

//let membersUrl = CONFIG.baseUrls.members;

export class Member {
  name: string;
  id: string;
  dob: string;
}

@Injectable()
export class MemberDetailsService {
//  constructor(private http: Http) { }

 // getMember(id: string) {
 //   return this.getMembers()
 //     .map(members => members.find(member => member.id === id));
//  }

 // getMembers() {
  //  return this.http.get(membersUrl)
  //    .map((response: Response) => <Member[]>response.json().data);
 // }
}
