import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { MemberDetailsService } from '../../myaccount/memberdetails/memberdetails.service';
import { gbdServiceList } from '../../shared/gbd-service/index';
import { AuthenticationService } from '../../shared/gbd-service/index';
import { PaginationService } from '../../shared/pagination-service/pagination-service';

import { MemberDetailsModule } from '../../myaccount/memberdetails/memberdetails.module';
import { User } from '../../shared/models/user';

import { Observable } from 'rxjs/Observable';

export function main() {
  
  let inputParam = {
        "healthCardId": 'vsuser101'
  };
    
  let actualRes : any;
  actualRes = {
       "message": {
        "messageCode": "00",
        "messageText": "Members retrieved"
      },
      "tppMemberDetails": [
          {
              "fullName": "Donna Howell",
              "memberId": "341M63686",
              "dateOfBirth": "06/09/1954",
              "checked": false
          },
          {
              "fullName": "Jared Kempton",
              "memberId": "223M79156",
              "dateOfBirth": "05/20/1979",
              "checked": false
          }
      ],
      "memberPaginationCount": 3,
      "paymentsPaginationCount": 3
  };


  let actualRes1 : any;
  actualRes1 = {
       "message": {
        "messageCode": "00",
        "messageText": "Members retrieved"
      },
      "tppMemberDetails": [
          {
              "fullName": "Donna Howell",
              "memberId": "341M63686",
              "dateOfBirth": "06/09/1954",
              "checked": true
          },
          {
              "fullName": "Jared Kempton",
              "memberId": "223M79156",
              "dateOfBirth": "05/20/1979",
              "checked": false
          }
      ],
      "memberPaginationCount": 3,
      "paymentsPaginationCount": 3
  };


  let actualRes2 : any;
  actualRes2 = {
       "message": {
        "messageCode": "00",
        "messageText": "Members Deleted Successfully"
      },
      "tppMemberDetails": [
          {
              "fullName": "Donna Howell",
              "memberId": "341M63686",
              "dateOfBirth": "06/09/1954",
              "checked": true
          },
          {
              "fullName": "Jared Kempton",
              "memberId": "223M79156",
              "dateOfBirth": "05/20/1979",
              "checked": false
          }
      ],
      "memberPaginationCount": 3,
      "paymentsPaginationCount": 3
  };

  
  describe('Member Details component', () => {
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, MemberDetailsModule, RouterTestingModule ],
        declarations: [MemberDetailTestComponent],
        providers: [
          MemberDetailsService,
          gbdServiceList,
          PaginationService,
          AuthenticationService,
          User,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

    
   it('memberdetails should build without a problem',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(MemberDetailTestComponent);
            fixture.detectChanges();
            
            let compiled = fixture.nativeElement;

            expect(compiled).toBeTruthy();
            
          });

      }));

    
    it('memberdetails openDeletePopup memberNotSelectedError to be true',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
            
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(MemberDetailTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.getMemberResponse = actualRes;
            
            fixture.detectChanges();
            instance.openDeletePopup();
            expect(instance.memberNotSelectedError).toBe(true);
            
          });

      }));

      it('memberdetails openDeletePopup memberNotSelectedError to be false',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes1 })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
              
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(MemberDetailTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.getMemberResponse = actualRes1;
            
            fixture.detectChanges();
            instance.openDeletePopup();
            expect(instance.memberNotSelectedError).toBe(false);
            
          });

      }));


      it('memberdetails redirectdelMember success',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes2 })));
            });

            let inputParam = {
                  "healthCardId": 'vsuser101'
            };
            
            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let fixture = TestBed.createComponent(MemberDetailTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            
            instance.getMemberResponse = actualRes2;
            
            fixture.detectChanges();
            instance.redirectdelMember();
            expect(instance.screenLoader).toBe(false);
            
          });

      }));

  });
}

@Component({
  selector: 'test-cmp',
  template: '<gbdtpp-memberdetails></gbdtpp-memberdetails>'
})
class MemberDetailTestComponent { }
