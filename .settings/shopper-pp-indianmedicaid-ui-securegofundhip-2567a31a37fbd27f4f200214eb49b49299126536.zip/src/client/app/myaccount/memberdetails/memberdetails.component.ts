import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { MemberDetailsService, Member } from './memberdetails.service';
import { PaginationService } from '../../shared/pagination-service/pagination-service';
import { gbdServiceList } from '../../shared/gbd-service/index';
declare var jQuery:any;
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'gbdtpp-memberdetails',
  templateUrl: 'memberdetails.component.html',
  styleUrls: ['memberdetails.component.css']
})
export class MemberDetailsComponent implements OnInit {
  memberPaginationCount: number = 5;
  showLoader: boolean;
  inputParam: any = '';
  getMemberResponse: any = {};
  responseMessageCode: any = '';
  showPagination: boolean = false;
  content: any;
  screenLoader: boolean;
  memberNotSelectedError:boolean = false;
  constructor (public router : Router, private memberDetailsService : MemberDetailsService,
    private paginationService : PaginationService,private gbdServiceList: gbdServiceList, private currentUser: User){
  } 

  paginationAttributes : any;
  members: Observable<Member[]>;

  ngOnInit() {
    this.showLoader = false;
    this.screenLoader = false;
    this.showPagination = false;
    this.memberNotSelectedError = false;
    this.getMemberResponse = [];
    this.inputParam = {
      //"userId": this.currentUser.username
    }
    var memberCheckBoxList: any = [];
    var checkBoxListComposed: any = [];
    this.content = { memberCheckBoxList: [] };
    this.showLoader = true;
    this.gbdServiceList.getMembers(this.inputParam).subscribe((data: any) => {
      //alert(JSON.stringify(data))
      this.getMemberResponse = data;
      this.memberPaginationCount = data.memberPaginationCount;
      if (this.getMemberResponse.message.messageCode !== undefined && this.getMemberResponse.message.messageCode === '00') {
        this.responseMessageCode = '00';
      } else {
        this.responseMessageCode = '99';
      }
      if(this.getMemberResponse != undefined && this.getMemberResponse.tppMemberDetails != undefined){
        for (let member of this.getMemberResponse.tppMemberDetails) {
            var dynamicCheckBoxName = {
              id: 'checkboxMemberPayment' + member.memberId,
              name: 'checkboxMemberPayment' + member.memberId,
              label: member.fullName,
              trueValue: true,
              falseValue: false
            };
            this.content.memberCheckBoxList.push(dynamicCheckBoxName);
          }   
          this.gbdServiceList.consoleLog("this.getMemberResponse : " + JSON.stringify(this.getMemberResponse));
      
        if(this.getMemberResponse.tppMemberDetails.length > this.memberPaginationCount){
          this.showPagination = true;
        }
        
        this.paginationAttributes = this.paginationService.getPaginationAttributes(this.getMemberResponse.tppMemberDetails.length,this.memberPaginationCount);
        setTimeout(()=>{
           this.setPage(1,'memberDetails');
           jQuery(".memberDetailsNameClass").find(".pcLabel").addClass('pcLabelFontOverride');
        },100);
      }
       
      this.showLoader = false;

    });
     
  }

  redirectToMember(){
    this.router.navigate(['/addMember']);
  }

  getPageGroup(currentGroup: number): number{
    return Math.ceil((currentGroup+1)/this.paginationAttributes.showItemsCount);
  }

  setPage(selectionNumber:number, className:string){
    this.paginationAttributes.currentPageSelection = selectionNumber;
    this.paginationService.setPage(selectionNumber, className);
  }

  openDeletePopup(){
    let tppMemberDetailsTemp: number = 0;
    this.memberNotSelectedError = false;
      for (var i = 0; i < this.getMemberResponse.tppMemberDetails.length; i++) {
        if (this.getMemberResponse.tppMemberDetails[i].checked) {
          tppMemberDetailsTemp = tppMemberDetailsTemp + 1;
        }
      }
      if(tppMemberDetailsTemp > 0){
        document.getElementById('deleteMembersModalOpener').click();
      }else{
        this.memberNotSelectedError = true;
      }
  }

  redirectdelMember() {

        this.gbdServiceList.consoleLog("getMemberResponse:" + JSON.stringify(this.getMemberResponse.tppMemberDetails));
        let tppMemberDetailsTemp: any = [];
        
        for (var i = 0; i < this.getMemberResponse.tppMemberDetails.length; i++) {
          if (this.getMemberResponse.tppMemberDetails[i].checked) {
            let memberIdTemp = {
              'memberId' : this.getMemberResponse.tppMemberDetails[i].memberId
            }
            tppMemberDetailsTemp.push(memberIdTemp);
          }
        }

        this.gbdServiceList.consoleLog("DELETE members list :" + JSON.stringify(tppMemberDetailsTemp));
        this.screenLoader = true;
        this.inputParam = {
          'tppMemberDetails': tppMemberDetailsTemp,
          //"userId": this.currentUser.username,
          "action": "DELETE"
        }
        this.gbdServiceList.consoleLog("DELETE members request:" + JSON.stringify(this.inputParam));

        this.gbdServiceList.consoleLog(this.inputParam);
        this.gbdServiceList.updateMembers(this.inputParam).subscribe((data: any) => {
          this.gbdServiceList.consoleLog("DELETE members response:" + JSON.stringify(data));
            document.getElementById('deleteTransactionMembers').click();
            this.screenLoader = false;    
            document.getElementById('deleteMembersConfirmationModalOpener').click();
        },
        (error: Error) => {
          this.gbdServiceList.consoleLog("DELETE members service ERROR:" + JSON.stringify(error));
          document.getElementById('deleteTransactionMembers').click();
          this.screenLoader = false;
        });
   }

   closeDeletePopup(){
    this.router.navigate(['']); 
   }

}