import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AddMemberModel } from '../../../shared/models/addmember.model';
import { Member } from '../../memberdetails/memberdetails.service';
import { gbdServiceList } from '../../../shared/gbd-service/index';
import { User } from '../../../shared/models/user';
declare var jQuery:any;

@Component({
    moduleId: module.id,
    selector: 'add-member',
    templateUrl: 'addmember.component.html',
    styleUrls: ['addmember.component.css'],
})
export class AddMemberComponent {

    screenLoader: boolean = false;

    inputParam: any = '';
    validationError: boolean = false;
    newMember: AddMemberModel;
    value: string;
    technicalError: string = "";
    model = new AddMemberModel('', '', '', '');

    constructor(public router: Router, private gbdServiceList: gbdServiceList, private currentUser: User) { }

    ngOnInit() {
        jQuery('#errorDiv').hide();
    }

    saveMember(model: AddMemberModel) {

        if (model != null) {
            this.newMember = model;
            this.screenLoader = true;

            this.inputParam = {
                "healthCardId": jQuery.trim((model.memberIdNumber)).toUpperCase(),
                //"userId": jQuery.trim(this.currentUser.username),
                "firstName": jQuery.trim(model.firstName),
                "lastName": jQuery.trim(model.lastName),
                "dateOfBirth": jQuery.trim(model.dob),
                "action": "ADD"
            }
            this.gbdServiceList.consoleLog("NewMember " + this.newMember);

            this.gbdServiceList.consoleLog("healthCardId /n" + (model.memberIdNumber).toUpperCase());
            //this.gbdServiceList.consoleLog("userId /n" + this.currentUser.username);
            this.gbdServiceList.consoleLog("firstName /n" + model.firstName);
            this.gbdServiceList.consoleLog("lastName /n" + model.lastName);
            this.gbdServiceList.consoleLog("dateOfBirth /n" + model.dob);

            this.gbdServiceList.updateMembers(this.inputParam).subscribe((data: any) => {
                this.gbdServiceList.consoleLog("Response:" + JSON.stringify(data));
                this.gbdServiceList.consoleLog("inputParam:" + JSON.stringify(this.inputParam));
                if (data.message.messageCode == 0) {
                    this.screenLoader = false;
                    this.router.navigate(['/myAccount']);

                } else {
                    jQuery("#backEndErrorMsg").html("Please try again. We are unable to add the member due to one or more of the following reasons: <ul><li>First Name did not match</li><li>Last Name did not match</li><li>Date of Birth did not match</li></ul>");
                    jQuery('#errorDiv').show();
                    this.validationError = true;
                    this.screenLoader = false;
                    return;
                }
            },
                (error: Error) => {
                    jQuery("#backEndErrorMsg").text("We’re having some technical issues – please try again.");
                    jQuery('#errorDiv').show();
                    this.gbdServiceList.consoleLog("Response ERROR:" + JSON.stringify(error));
                    this.screenLoader = false;
                    //  var someElement = jQuery("#some-id");
                    //  jQuery('html,body').animate({scrollTop: someElement.offset().top},'fast');
                });
        }

    }

    redirectToMyAccount(){
        this.router.navigate(['/myAccount']);
    }

}