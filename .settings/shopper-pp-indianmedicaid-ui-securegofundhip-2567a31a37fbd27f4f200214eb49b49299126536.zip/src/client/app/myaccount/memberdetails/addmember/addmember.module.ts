import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonutilsModule } from '../../../commonutils/commonutils.module'; 
import { AddMemberComponent } from './addmember.component';
import { User } from '../../../shared/models/user';

@NgModule({
  imports: [CommonModule, CommonutilsModule.forRoot()],
  declarations: [AddMemberComponent],
  exports: [AddMemberComponent],
  providers: [User]
})
export class AddMemberModule { }