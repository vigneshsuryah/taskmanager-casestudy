import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Route, RouterModule } from '@angular/router';
import { async } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { MemberDetailsService } from '../../../myaccount/memberdetails/memberdetails.service';
import { gbdServiceList } from '../../../shared/gbd-service/index';
import { AuthenticationService } from '../../../shared/gbd-service/index';
import { PaginationService } from '../../../shared/pagination-service/pagination-service';
import { MyaccountComponent } from '../../../myaccount/myaccount.component';
import { AddMemberModule } from '../../../myaccount/memberdetails/addmember/addmember.module';
import { MyaccountModule } from '../../../myaccount/myaccount.module';
import { AddMemberModel } from '../../../shared/models/addmember.model';
import { User } from '../../../shared/models/user';

import { Observable } from 'rxjs/Observable';

export function main() {
  
  let inputParam = {
        "healthCardId": 'vsuser101'
  };
    
  let actualRes : any;
  actualRes = {
    "message": {
        "messageCode": "00",
        "messageText": "Member is added successfully"
    },
    "ackStatus": "Success"
 }; 

 let failureRes : any;
 failureRes = {
    "message": {
        "messageCode": "PP9006",
        "messageText": "Sorry, we couldn’t find that member. The information you entered is either unavailable in our system or incorrect. Please try again."
    },
    "ackStatus": "Failed"
}; 
  
  describe('Member Details component', () => {

       let config: Route[] = [
      { path: 'myAccount', component: MyaccountComponent }
    ];
    // setting module for testing
    // Disable old forms
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterModule, HttpModule, AddMemberModule,MyaccountModule, RouterTestingModule.withRoutes(config) ],
        declarations: [AddMemberTestComponent],
        providers: [
          MemberDetailsService,
          gbdServiceList,
          PaginationService,
          AuthenticationService,
          User,
          BaseRequestOptions,
          MockBackend,
          {provide: Http, useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
              return new Http(backend, defaultOptions);
            },
            deps: [MockBackend, BaseRequestOptions]
          },
        ]
      });
    });

    
   it('add member success',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: actualRes })));
            });

            let fixture = TestBed.createComponent(AddMemberTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            let inputParam = new AddMemberModel('Dione', 'Robinson', '10/12/1975', '020M74589');

            instance.saveMember(inputParam);
            
            let compiled = fixture.nativeElement;

           expect(instance.backEndError).toBe(false);
            
          });

      }));

       it('add member failure',
      async(() => {
        TestBed
          .compileComponents()
          .then(() => {
            let gbdService = TestBed.get(gbdServiceList);
            let mockBackend = TestBed.get(MockBackend);

            let user = TestBed.get(User);
            user.username = 'vsuser101';
            user.orgType = 'Test';
            user.orgName = 'Cognizant';
            
            let authenticationService = TestBed.get(AuthenticationService);
            authenticationService.token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI0NTcyMDMiLCJpYXQiOjE0OTQ5OTM4ODJ9.HpEZLTnceCG7aooqVXhXBEmgsAKoJZZAG8KsSG5Y_k8';
            
            mockBackend.connections.subscribe((c: any) => {
              c.mockRespond(new Response(new ResponseOptions({ body: failureRes })));
            });

            let fixture = TestBed.createComponent(AddMemberTestComponent);
            let instance = fixture.debugElement.children[0].componentInstance;
            fixture.detectChanges();
            let inputParam = new AddMemberModel('Dione', 'Robinson', '10/12/1975', '020M74589');

            instance.saveMember(inputParam);
            
            let compiled = fixture.nativeElement;

           expect(instance.backEndError).toBe(true);
            
          });

      }));

      
  });
}

@Component({
  selector: 'test-cmp',
  template: '<add-member></add-member>'
})
class AddMemberTestComponent { }
