import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF } from '@angular/common';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { MyaccountModule } from './myaccount/myaccount.module';
import { TechnicalErrorModule } from './commonutils/technicalerror/technicalerror.module';
import { LandingModule } from './landing/landing.module';
import { AppLoadingModule } from './apploading/apploading.module';
import { AccountSettingsModule } from './accountsettings/accountsettings.module';
import { ChangePasswordModule } from './accountsettings/changepassword/changepassword.module';
import { CommonutilsModule } from './commonutils/commonutils.module';
import { AuthGuard } from './shared/guards/index';
import { AuthenticationService, UserService } from './shared/gbd-service/index';
import { RequestOptions, RequestMethod, Headers } from '@angular/http';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { CustomLocationStrategy} from './shared/hashlocation/index';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { MomentModule } from 'angular2-moment';
import { User } from './shared/models/user';

class MyOptions extends RequestOptions {
  constructor() {
    super({
      method: RequestMethod.Get,
      headers: new Headers({
        'Content-Type': 'application/json'
      })
    });
  }
}


@NgModule({   
  imports: [BrowserModule, HttpClientModule, HttpModule, FormsModule, AppRoutingModule, LandingModule, MyaccountModule, AccountSettingsModule, 
  ChangePasswordModule, 
  AppLoadingModule, TechnicalErrorModule, NgIdleKeepaliveModule.forRoot(), CommonutilsModule.forRoot()],
  declarations: [AppComponent],
  providers: [{
    provide: APP_BASE_HREF,
    useValue: '<%= APP_BASE %>'
  },AuthGuard, AuthenticationService, UserService , {
    provide: RequestOptions,
    useClass: MyOptions
  },
  {
      provide: LocationStrategy, 
      useClass: CustomLocationStrategy
  },
  User
  ],
  bootstrap: [AppComponent]

})
export class AppModule { }
