import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LandingComponent } from './landing.component';
import { AuthGuard } from '../shared/guards/index';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'landing', component: LandingComponent  }
    ])
  ],
  exports: [RouterModule]
})
export class LandingRoutingModule { }
