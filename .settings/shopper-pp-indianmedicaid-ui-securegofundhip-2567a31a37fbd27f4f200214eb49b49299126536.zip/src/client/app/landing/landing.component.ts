import { Component, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { gbdServiceList } from '../shared/gbd-service/index';
import { Router } from '@angular/router';
declare var jQuery:any;

/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'gbd-landing',
  templateUrl: 'landing.component.html',
  styleUrls: ['landing.component.css']
})
export class LandingComponent { 
  response : any[] = [];
  model : any = {};
  hcIdError: Boolean = false;
  inputParam : {} = {};
  getResponse : any = '';
  hcIdError9Char: boolean = false;
  techError : boolean = false; 
  loader : boolean = false;
  list1Event: EventEmitter<any> = new EventEmitter();

    constructor (public gbdServiceList: gbdServiceList, public fb: FormBuilder,public router : Router){
      this.hcIdError = false;
      this.hcIdError9Char = false;
      //this.techError = (localStorage.getItem('techChallenge')=='true') ? true : false;
    }

  ngOnInit(){
    jQuery(".dropdown-custom").hide();
    this.techError = (localStorage.getItem('techChallenge')=='true') ? true : false;
    localStorage.setItem('currentUser',"AC82798");
    localStorage.setItem('techChallenge','false');
    localStorage.setItem('hcidChallenge','no');
    this.loader = false;
    this.model = {
      "hcid" :"",
      "orgType":"WHIP_TPG"
    }
  }

  getDetailsusingHCID (data : any){
        localStorage.setItem('currentUser', JSON.stringify({ username: data.hcid.toUpperCase()}));
        localStorage.setItem('orgType', JSON.stringify({ orgType: data.orgType}));
        this.router.navigate(['/appLoading']);
    }

}
