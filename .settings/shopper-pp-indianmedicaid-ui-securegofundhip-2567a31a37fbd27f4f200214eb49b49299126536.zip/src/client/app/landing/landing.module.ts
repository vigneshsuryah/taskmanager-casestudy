import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LandingComponent } from './landing.component';
import { LandingRoutingModule } from './landing-routing.module';
import { gbdServiceList } from '../shared/gbd-service/index';
import { CommonutilsModule } from '../commonutils/commonutils.module';


@NgModule({
  imports: [CommonModule, LandingRoutingModule, ReactiveFormsModule, FormsModule, CommonutilsModule.forRoot()],
  declarations: [LandingComponent],
  exports: [LandingComponent],
  providers :[ gbdServiceList ]
})
export class LandingModule { }
