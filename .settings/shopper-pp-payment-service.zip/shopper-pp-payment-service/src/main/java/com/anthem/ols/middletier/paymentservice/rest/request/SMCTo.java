package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;

public class SMCTo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6307974761541451388L;
	
	private String Address;
	private String SubscriberKey;
	private ContactAttributes ContactAttributes;
	
	public String getSubscriberKey() {
		return SubscriberKey;
	}
	public void setSubscriberKey(String subscriberKey) {
		SubscriberKey = subscriberKey;
	}
	public ContactAttributes getContactAttributes() {
		return ContactAttributes;
	}
	public void setContactAttributes(ContactAttributes contactAttributes) {
		ContactAttributes = contactAttributes;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
}
