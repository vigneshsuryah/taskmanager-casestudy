package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum SystemErrorCodeEnum {
	  SYS_001("SYS001"), 

	  SYS_002("SYS002"), 

	  SYS_003("SYS003");

	  private final String value;

	  private SystemErrorCodeEnum(String v) { this.value = v; }

	  public String value()
	  {
	    return this.value;
	  }

	  public static SystemErrorCodeEnum fromValue(String v) {
	    for (SystemErrorCodeEnum c : values()) {
	      if (c.value.equals(v)) {
	        return c;
	      }
	    }
	    throw new IllegalArgumentException(v);
	  }
}
