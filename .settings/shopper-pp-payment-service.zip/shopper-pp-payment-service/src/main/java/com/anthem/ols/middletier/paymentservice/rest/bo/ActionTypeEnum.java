
package com.anthem.ols.middletier.paymentservice.rest.bo;


public enum ActionTypeEnum {
	
	NONE,
	UPDATE,
	DELETE,
	UPDATE_VALIDATE,
	VALIDATE;
	
	public String value() {
		return name();
	}

	public static ActionTypeEnum fromValue(String v) {
		return valueOf(v);
	}
}