package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.math.BigInteger;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class StatementOfAccountability implements Serializable{   	/**	 * 	 */	private static final long serialVersionUID = -2840716057264107740L;	private  BigInteger id;
    private  ActionTypeEnum action;
    private  AnswerTypeEnum isAgentAssisted;
    private  AnswerTypeEnum isNotReadEnglish;
    private  AnswerTypeEnum isNotSpeakEnglish;
    private  AnswerTypeEnum isNotWriteEnglish;
    private  AnswerTypeEnum isOtherFlag;
    private  String otherReason;
    private  AnswerTypeEnum isDisclosedByApplicant;
    private  String disclosedPerson;
    private  AnswerTypeEnum isLimitedEnglish;
    private  String interpretedLanguage;
    private  String translatedFName;
    private  String translatedMI;
    private  String translatedLName;
    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }

    /**
     * Gets the value of the isAgentAssisted property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsAgentAssisted() {
        return isAgentAssisted;
    }

    /**
     * Sets the value of the isAgentAssisted property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsAgentAssisted(AnswerTypeEnum value) {
        this.isAgentAssisted = value;
    }

    /**
     * Gets the value of the isNotReadEnglish property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsNotReadEnglish() {
        return isNotReadEnglish;
    }

    /**
     * Sets the value of the isNotReadEnglish property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsNotReadEnglish(AnswerTypeEnum value) {
        this.isNotReadEnglish = value;
    }

    /**
     * Gets the value of the isNotSpeakEnglish property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsNotSpeakEnglish() {
        return isNotSpeakEnglish;
    }

    /**
     * Sets the value of the isNotSpeakEnglish property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsNotSpeakEnglish(AnswerTypeEnum value) {
        this.isNotSpeakEnglish = value;
    }

    /**
     * Gets the value of the isNotWriteEnglish property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsNotWriteEnglish() {
        return isNotWriteEnglish;
    }

    /**
     * Sets the value of the isNotWriteEnglish property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsNotWriteEnglish(AnswerTypeEnum value) {
        this.isNotWriteEnglish = value;
    }

    /**
     * Gets the value of the isOtherFlag property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsOtherFlag() {
        return isOtherFlag;
    }

    /**
     * Sets the value of the isOtherFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsOtherFlag(AnswerTypeEnum value) {
        this.isOtherFlag = value;
    }

    /**
     * Gets the value of the otherReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherReason() {
        return otherReason;
    }

    /**
     * Sets the value of the otherReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherReason(String value) {
        this.otherReason = value;
    }

    /**
     * Gets the value of the isDisclosedByApplicant property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsDisclosedByApplicant() {
        return isDisclosedByApplicant;
    }

    /**
     * Sets the value of the isDisclosedByApplicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsDisclosedByApplicant(AnswerTypeEnum value) {
        this.isDisclosedByApplicant = value;
    }

    /**
     * Gets the value of the disclosedPerson property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisclosedPerson() {
        return disclosedPerson;
    }

    /**
     * Sets the value of the disclosedPerson property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisclosedPerson(String value) {
        this.disclosedPerson = value;
    }

    /**
     * Gets the value of the isLimitedEnglish property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsLimitedEnglish() {
        return isLimitedEnglish;
    }

    /**
     * Sets the value of the isLimitedEnglish property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsLimitedEnglish(AnswerTypeEnum value) {
        this.isLimitedEnglish = value;
    }

    /**
     * Gets the value of the interpretedLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterpretedLanguage() {
        return interpretedLanguage;
    }

    /**
     * Sets the value of the interpretedLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterpretedLanguage(String value) {
        this.interpretedLanguage = value;
    }

    /**
     * Gets the value of the translatedFName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslatedFName() {
        return translatedFName;
    }

    /**
     * Sets the value of the translatedFName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslatedFName(String value) {
        this.translatedFName = value;
    }

    /**
     * Gets the value of the translatedMI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslatedMI() {
        return translatedMI;
    }

    /**
     * Sets the value of the translatedMI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslatedMI(String value) {
        this.translatedMI = value;
    }

    /**
     * Gets the value of the translatedLName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslatedLName() {
        return translatedLName;
    }

    /**
     * Sets the value of the translatedLName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslatedLName(String value) {
        this.translatedLName = value;
    }

}
