package com.anthem.ols.middletier.paymentservice.utils;

import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anthem.ols.middletier.paymentservice.config.ApplicationProperties;
import com.anthem.ols.middletier.paymentservice.entity.PaymentDetails;
import com.anthem.ols.middletier.paymentservice.entity.Transaction;
import com.anthem.ols.middletier.paymentservice.entity.ZipCodeDetails;
import com.anthem.ols.middletier.paymentservice.rest.bo.BankAcctTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.County;
import com.anthem.ols.middletier.paymentservice.rest.bo.CountyList;
import com.anthem.ols.middletier.paymentservice.rest.bo.CreditCardTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.ResponseMessage;
import com.anthem.ols.middletier.paymentservice.rest.bo.ZipCode;

@Component
public class ServiceUtils implements IppServiceConstants{

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceUtils.class);

	@Autowired
	private ApplicationProperties applicationProperties;

	public boolean checkApplicationOwner(PaymentDetails payment, String userId) {

		boolean flag = true;

		if (payment == null) {
			flag = false;
		} else {
			if (payment.getAccessType().equalsIgnoreCase("OWNER")) {
				if (payment.getUserId() == null) {
					flag = false;
				}
				if (payment.getUserId() != null && !payment.getUserId().equalsIgnoreCase(userId)) {
					flag = false;
				}
			}
		}

		return flag;
	}

	public boolean checkApplicationStatus(PaymentDetails payDetails) {

		boolean flag = false;

		if (null != payDetails && null != payDetails.getTransactions()) {
			Transaction[] transactions = payDetails.getTransactions();

			String applicationStatus = transactions[0].getTransactionStatus();
			if (applicationStatus != null && !applicationStatus.equals("INPROGRESS")
					&& !applicationStatus.equals("SUBMITREJECT") && !applicationStatus.equals("PAYMTPENDING")
					&& !applicationStatus.equals("ELIGRECV") && !applicationStatus.equals("SUBMITTING")
					&& !applicationStatus.equals("INELIGIBLE") && !applicationStatus.equals("EXCHACCEPTED")
					&& !applicationStatus.equals("CONTINUEONFFM") && !applicationStatus.equals("PAYMENTFAILED")) {
				flag = true;
			}
		}

		return flag;
	}

	public String generateACN() {

		// Veracode fix - April 2017 release - Start
		SecureRandom secureRandom = new SecureRandom();

		String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
		String numbers = "0123456789";

		int letterIndex = (int) (secureRandom.nextDouble() * letters.length());
		int numberIndex = (int) (secureRandom.nextDouble() * numbers.length());

		String randomChar = letters.substring(letterIndex, letterIndex + 1)
				+ numbers.substring(numberIndex, numberIndex + 1);
		// String randomChar =
		// RandomStringUtils.randomAlphabetic(1)+RandomStringUtils.randomNumeric(1);
		// Veracode fix - April 2017 release - End
		randomChar = randomChar.toUpperCase() + Long.toString(System.currentTimeMillis());
		return randomChar;
	}

	public int getDateOfBirth(Date dateOfBirth) {
		// TODO Auto-generated method stub
		GregorianCalendar today = new GregorianCalendar();
		GregorianCalendar bday = new GregorianCalendar();
		GregorianCalendar bdayThisYear = new GregorianCalendar();

		bday.setTime(dateOfBirth);
		bdayThisYear.setTime(dateOfBirth);
		bdayThisYear.set(Calendar.YEAR, today.get(Calendar.YEAR));

		int age = today.get(Calendar.YEAR) - bday.get(Calendar.YEAR);

		if (today.getTimeInMillis() < bdayThisYear.getTimeInMillis()) {
			age--;
		}
		return age;
	}

	public Date convertStringToDate(String strDate, String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
		formatter.setLenient(false);
		Date date = null;
		try {
			date = formatter.parse(strDate);
		} catch (ParseException e) {
			LOGGER.error("Parse Exception occured while converting string to date" + e);
		}
		return date;
	}

	public String convertDateToString(Date date, String format) {
		String strDate = "";
		DateFormat dateFormat = new SimpleDateFormat(format);
		if (null != date) {
			strDate = dateFormat.format(date);
		}
		return strDate;
	}

	public BankAcctTypeEnum convertBankAccType(String bankAccType) {
		BankAcctTypeEnum type = BankAcctTypeEnum.NONE;
		if ("PERSONAL CHECKING".equalsIgnoreCase(bankAccType)) {
			type = BankAcctTypeEnum.PERSONALCHECKING;
		} else if ("PERSONAL SAVINGS".equalsIgnoreCase(bankAccType)) {
			type = BankAcctTypeEnum.PERSONALSAVINGS;
		} else if ("BUSINESS CHECKING".equalsIgnoreCase(bankAccType)) {
			type = BankAcctTypeEnum.BUSCHECKING;
		} else if ("BUSINESS SAVINGS".equalsIgnoreCase(bankAccType)) {
			type = BankAcctTypeEnum.BUSSAVINGS;
		}
		return type;
	}

	public CreditCardTypeEnum convertCardType(String cardType) {
		CreditCardTypeEnum type = CreditCardTypeEnum.NONE;
		if ("MC".equalsIgnoreCase(cardType)) {
			type = CreditCardTypeEnum.MASTERCARD;
		} else if ("VISA".equalsIgnoreCase(cardType) || "VI".equalsIgnoreCase(cardType)) {
			type = CreditCardTypeEnum.VISA;
		}
		return type;
	}

	public String generateOrderId(String payChannel) {
		String orderId = "";
		try {
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyMMdd");
			SecureRandom secureRandom = new SecureRandom();
			String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
			String numbers = "0123456789";
			int letterIndex = (int) (secureRandom.nextDouble() * letters.length());
			int numberIndex = (int) (secureRandom.nextDouble() * numbers.length());
			String randomChar = letters.substring(letterIndex, letterIndex + 1)
					+ numbers.substring(numberIndex, numberIndex + 1);
			String shortId = RandomStringUtils.random(7, "0123456789");
			orderId = payChannel + dateFormat.format(date) + randomChar + shortId;
		} catch (Exception e) {
			// LOGGER.error("Exception -- while generateOrderId " + e);
		}
		if (orderId != null && StringUtils.isNotBlank(orderId) && StringUtils.isNotEmpty(orderId)) {
			orderId = orderId.toLowerCase();
		}
		return orderId;
	}

	public Date mongoDateConverter(Date inputDate) {
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date returnDate = null;
		SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
		try {
			returnDate = dateFormatGmt.parse(dateFormatLocal.format(inputDate));
		} catch (ParseException e) {
			LOGGER.error("Parse Exception occured while converting date to string" + e);
		}
		return returnDate;
	}

	public boolean validatePartnerId(String partnerId) {
		boolean valid = false;
		try {
			String partnerIds = applicationProperties.getStringProperty("PARTNER_IDS", "");
			String[] partnerIdArr = partnerIds.split(",");
			if (null != partnerIdArr && Arrays.asList(partnerIdArr).contains(partnerId)) {
				valid = true;
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured in validatePartnerId: " + e);
			valid = false;
		}
		return valid;
	}

	public ResponseMessage getZipCodeAckMessage(List<ZipCodeDetails> zipCodeDetailsList){
		ResponseMessage message = new ResponseMessage();
		if(null!=zipCodeDetailsList && !zipCodeDetailsList.isEmpty()){
			message.setMessage(ZIPCODE_TRUE_MSG);
			message.setResponseCode(ZIPCODE_TRUE);
		}else{
			message.setMessage(ZIPCODE_FALSE_MSG);
			message.setResponseCode(ZIPCODE_FALSE);
		}
		return message;
	}
	
	public ZipCode getZipCodeInformation(List<ZipCodeDetails> zipCodeDetailsList){
		
		ZipCode zipCode = new ZipCode();
		CountyList countyList = new CountyList();		
		try {
			if (null != zipCodeDetailsList && !zipCodeDetailsList.isEmpty()) {
				County[] counties = new County[zipCodeDetailsList.size()];
				ZipCodeDetails zipCodeDetails = zipCodeDetailsList.iterator().next();
				zipCode.setZipCode(zipCodeDetails.getZipCode());
				zipCode.setStateCode(zipCodeDetails.getStateCode());
				if (zipCodeDetails.getLatitude() != null
						&& !zipCodeDetails.getLatitude().isEmpty()) {
					zipCode.setLatitude(Double.valueOf(zipCodeDetails.getLatitude()));
				}
				if (zipCodeDetails.getLongitude() != null
						&& !zipCodeDetails.getLongitude().isEmpty()) {
					zipCode.setLongitude(Double.valueOf(zipCodeDetails.getLongitude()));
				}
				int count = 0;
				for (ZipCodeDetails zipCodeDetail : zipCodeDetailsList) {
					County county = new County();
					county.setCountyName(zipCodeDetail.getCountyName());
					county.setCountyCode(zipCodeDetail.getCountyCode());
					county.setStateCode(zipCodeDetail.getStateCode());				
					counties[count] = county;
					count++;
				}
				countyList.setCounty(counties);
				zipCode.setCountyList(countyList);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ServiceUtils getZipCodeInformation()" + e.getMessage());
		}
		return zipCode;
		
	}
	
	public String getEncodedText(String value)
	{
		String encoded = "";
		try{
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(PPORT);
			encoded = encryptor.encrypt(value);
		}catch(Exception e){
			try {
				byte[] message = value.getBytes("UTF-8");
				encoded = DatatypeConverter.printBase64Binary(message);
			} catch (Exception exception) {
				LOGGER.error("Exception in getEncodedText::"+ exception.getMessage());
				encoded = value;
			}
		}
		return encoded;
	}
	
	

}
