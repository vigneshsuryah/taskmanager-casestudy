/**
* EoxPaymentServiceApplication.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 01/08/2020  1.0      Cognizant       Initial Version
*/
package com.anthem.ols.middletier.paymentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableAsync;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;


@SpringBootApplication
@EnableAsync
@EnableEncryptableProperties
public class EoxPaymentServiceApplication extends SpringBootServletInitializer{

	public static void main(String[] args) {
		SpringApplication.run(EoxPaymentServiceApplication.class, args);
	}

}
