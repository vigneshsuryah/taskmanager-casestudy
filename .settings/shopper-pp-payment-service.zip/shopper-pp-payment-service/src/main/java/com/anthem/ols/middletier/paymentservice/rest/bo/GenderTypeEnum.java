package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum GenderTypeEnum {
    NONE,
    MALE,
    FEMALE;
    public String value() {        return name();    }
    public static GenderTypeEnum fromValue(String v) {        return valueOf(v);    }}
