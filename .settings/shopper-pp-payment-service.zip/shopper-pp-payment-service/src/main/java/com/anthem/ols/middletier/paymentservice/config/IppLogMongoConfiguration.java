/**
 * IppLogMongoConfiguration.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 01/08/2020  1.0       Cognizant      Initial Version
 */
package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackages = "com.anthem.ols.middletier.paymentservice.repository.ipplog",
        mongoTemplateRef = "ippLogTemplate")
public class IppLogMongoConfiguration {

}
