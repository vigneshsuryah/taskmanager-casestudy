package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class HealthInsCoverage implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 7814864207795137587L;	private  int id;
    private  String covPolicyNo;
    private  String covName;
    private  String covGroupNo;
    private  String covCompName;
    private  Address covCompAddress;
    private  Date covStartDate;
    private  Date covEndDate;
    private  ActionTypeEnum action;
    private  String covState;
    private  String covPolicyType;
    private  Date covPaidThruDate;
    private  ApplicantMemberCode[] covApplicants;
    private  String covPhoneNo;        private int covApplicantsLength;
	/**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the covPolicyNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovPolicyNo() {
        return covPolicyNo;
    }

    /**
     * Sets the value of the covPolicyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovPolicyNo(String value) {
        this.covPolicyNo = value;
    }

    /**
     * Gets the value of the covName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovName() {
        return covName;
    }

    /**
     * Sets the value of the covName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovName(String value) {
        this.covName = value;
    }

    /**
     * Gets the value of the covGroupNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovGroupNo() {
        return covGroupNo;
    }

    /**
     * Sets the value of the covGroupNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovGroupNo(String value) {
        this.covGroupNo = value;
    }

    /**
     * Gets the value of the covCompName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovCompName() {
        return covCompName;
    }

    /**
     * Sets the value of the covCompName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovCompName(String value) {
        this.covCompName = value;
    }

    /**
     * Gets the value of the covCompAddress property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getCovCompAddress() {
        return covCompAddress;
    }

    /**
     * Sets the value of the covCompAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setCovCompAddress(Address value) {
        this.covCompAddress = value;
    }

    /**
     * Gets the value of the covStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getCovStartDate() {
        return covStartDate;
    }

    /**
     * Sets the value of the covStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setCovStartDate(Date value) {
        this.covStartDate = value;
    }

    /**
     * Gets the value of the covEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getCovEndDate() {
        return covEndDate;
    }

    /**
     * Sets the value of the covEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setCovEndDate(Date value) {
        this.covEndDate = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }

    /**
     * Gets the value of the covState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovState() {
        return covState;
    }

    /**
     * Sets the value of the covState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovState(String value) {
        this.covState = value;
    }

    /**
     * Gets the value of the covPolicyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovPolicyType() {
        return covPolicyType;
    }

    /**
     * Sets the value of the covPolicyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovPolicyType(String value) {
        this.covPolicyType = value;
    }

    /**
     * Gets the value of the covPaidThruDate property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getCovPaidThruDate() {
        return covPaidThruDate;
    }

    /**
     * Sets the value of the covPaidThruDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setCovPaidThruDate(Date value) {
        this.covPaidThruDate = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link ApplicantMemberCode }
     *     
     */
    public ApplicantMemberCode[] getCovApplicants() {
        if (this.covApplicants == null) {
            return new ApplicantMemberCode[ 0 ] ;
        }
        ApplicantMemberCode[] retVal = new ApplicantMemberCode[this.covApplicants.length] ;
        System.arraycopy(this.covApplicants, 0, retVal, 0, this.covApplicants.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link ApplicantMemberCode }
     *     
     */
    public ApplicantMemberCode getCovApplicants(int idx) {
        if (this.covApplicants == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.covApplicants[idx];
    }

    public int getCovApplicantsLength() {
        if (this.covApplicants == null) {
            return  0;
        }
        return this.covApplicants.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link ApplicantMemberCode }
     *     
     */
    public void setCovApplicants(ApplicantMemberCode[] values) {
        if(values!=null){        	int len = values.length;            this.covApplicants = ((ApplicantMemberCode[]) new ApplicantMemberCode[len] );            for (int i = 0; (i<len); i ++) {                this.covApplicants[i] = values[i];            }        }else{        	this.covApplicants=null;        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicantMemberCode }
     *     
     */
    public ApplicantMemberCode setCovApplicants(int idx, ApplicantMemberCode value) {
        return this.covApplicants[idx] = value;
    }        public String getCovPhoneNo() {		return covPhoneNo;	}	public void setCovPhoneNo(String covPhoneNo) {		this.covPhoneNo = covPhoneNo;	}	public void setCovApplicantsLength(int covApplicantsLength) {		this.covApplicantsLength = covApplicantsLength;	}

}
