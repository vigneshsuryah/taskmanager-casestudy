package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class Agent implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 240478537032118518L;	private  int id;
    private  String agentId;
    private  String agentTIN;
    private  String agentUserId;
    private  String adeAgentId;
    private  String firstName;
    private  String lastName;
    private  String mi;
    private  AnswerTypeEnum isMGA;
    private  String agencyName;
    private  String phoneNo;
    private  String faxNo;
    private  String emailAddress;
    private  Agent parentAgent;
    private  AnswerTypeEnum isAssistApplicant;
    private  Address address;
    private  ESignature eSignature;
    private  AgentTypeEnum agentType;
    private  HealthInsCoverage[] issuedPolicies;
    private  AnswerTypeEnum isIndvFaceToFaceAppt;
    private  String voiceVaultConfirmationNo;
    private  ActionTypeEnum action;
    private  AnswerTypeEnum isNotDisclosed;
    private  String reasonNotSeeApplicant;
    private  String notDisclosedExplanation;
    private  String faceToFaceApptExplanation;        private  String npn;        private  String licenseNumber;        private  String certificateNumber;        private  String fFEUserId;        private  String phoneExt;        private  String faxExt;
    private  String agentCode;    private  Agent paidAgent;        private int issuedPoliciesLength;		/**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the agentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentId() {
        return agentId;
    }

    /**
     * Sets the value of the agentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentId(String value) {
        this.agentId = value;
    }

    /**
     * Gets the value of the agentTIN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentTIN() {
        return agentTIN;
    }

    /**
     * Sets the value of the agentTIN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentTIN(String value) {
        this.agentTIN = value;
    }

    /**
     * Gets the value of the agentUserId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentUserId() {
        return agentUserId;
    }

    /**
     * Sets the value of the agentUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentUserId(String value) {
        this.agentUserId = value;
    }

    /**
     * Gets the value of the adeAgentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdeAgentId() {
        return adeAgentId;
    }

    /**
     * Sets the value of the adeAgentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdeAgentId(String value) {
        this.adeAgentId = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the mi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMi() {
        return mi;
    }

    /**
     * Sets the value of the mi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMi(String value) {
        this.mi = value;
    }

    /**
     * Gets the value of the isMGA property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsMGA() {
        return isMGA;
    }

    /**
     * Sets the value of the isMGA property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsMGA(AnswerTypeEnum value) {
        this.isMGA = value;
    }

    /**
     * Gets the value of the agencyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgencyName() {
        return agencyName;
    }

    /**
     * Sets the value of the agencyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgencyName(String value) {
        this.agencyName = value;
    }

    /**
     * Gets the value of the phoneNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneNo() {
        return phoneNo;
    }

    /**
     * Sets the value of the phoneNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneNo(String value) {
        this.phoneNo = value;
    }

    /**
     * Gets the value of the faxNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * Sets the value of the faxNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaxNo(String value) {
        this.faxNo = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the parentAgent property.
     * 
     * @return
     *     possible object is
     *     {@link Agent }
     *     
     */
    public Agent getParentAgent() {
        return parentAgent;
    }

    /**
     * Sets the value of the parentAgent property.
     * 
     * @param value
     *     allowed object is
     *     {@link Agent }
     *     
     */
    public void setParentAgent(Agent value) {
        this.parentAgent = value;
    }

    /**
     * Gets the value of the isAssistApplicant property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsAssistApplicant() {
        return isAssistApplicant;
    }

    /**
     * Sets the value of the isAssistApplicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsAssistApplicant(AnswerTypeEnum value) {
        this.isAssistApplicant = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the eSignature property.
     * 
     * @return
     *     possible object is
     *     {@link ESignature }
     *     
     */
    public ESignature getESignature() {
        return eSignature;
    }

    /**
     * Sets the value of the eSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link ESignature }
     *     
     */
    public void setESignature(ESignature value) {
        this.eSignature = value;
    }

    /**
     * Gets the value of the agentType property.
     * 
     * @return
     *     possible object is
     *     {@link AgentTypeEnum }
     *     
     */
    public AgentTypeEnum getAgentType() {
        return agentType;
    }

    /**
     * Sets the value of the agentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AgentTypeEnum }
     *     
     */
    public void setAgentType(AgentTypeEnum value) {
        this.agentType = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link HealthInsCoverage }
     *     
     */
    public HealthInsCoverage[] getIssuedPolicies() {
        if (this.issuedPolicies == null) {
            return new HealthInsCoverage[ 0 ] ;
        }
        HealthInsCoverage[] retVal = new HealthInsCoverage[this.issuedPolicies.length] ;
        System.arraycopy(this.issuedPolicies, 0, retVal, 0, this.issuedPolicies.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link HealthInsCoverage }
     *     
     */
    public HealthInsCoverage getIssuedPolicies(int idx) {
        if (this.issuedPolicies == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.issuedPolicies[idx];
    }

    public int getIssuedPoliciesLength() {
        if (this.issuedPolicies == null) {
            return  0;
        }
        return this.issuedPolicies.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link HealthInsCoverage }
     *     
     */
    public void setIssuedPolicies(HealthInsCoverage[] values) {       if(values!=null){    	   int len = values.length;           this.issuedPolicies = ((HealthInsCoverage[]) new HealthInsCoverage[len] );           for (int i = 0; (i<len); i ++) {               this.issuedPolicies[i] = values[i];           }       }else{    	   this.issuedPolicies=null;       }
        
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link HealthInsCoverage }
     *     
     */
    public HealthInsCoverage setIssuedPolicies(int idx, HealthInsCoverage value) {
        return this.issuedPolicies[idx] = value;
    }

    /**
     * Gets the value of the isIndvFaceToFaceAppt property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsIndvFaceToFaceAppt() {
        return isIndvFaceToFaceAppt;
    }

    /**
     * Sets the value of the isIndvFaceToFaceAppt property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsIndvFaceToFaceAppt(AnswerTypeEnum value) {
        this.isIndvFaceToFaceAppt = value;
    }
    /**
     * Gets the value of the voiceVaultConfirmationNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoiceVaultConfirmationNo() {
        return voiceVaultConfirmationNo;
    }

    /**
     * Sets the value of the voiceVaultConfirmationNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoiceVaultConfirmationNo(String value) {
        this.voiceVaultConfirmationNo = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }

    /**
     * Gets the value of the isNotDisclosed property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsNotDisclosed() {
        return isNotDisclosed;
    }

    /**
     * Sets the value of the isNotDisclosed property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsNotDisclosed(AnswerTypeEnum value) {
        this.isNotDisclosed = value;
    }

    /**
     * Gets the value of the reasonNotSeeApplicant property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonNotSeeApplicant() {
        return reasonNotSeeApplicant;
    }

    /**
     * Sets the value of the reasonNotSeeApplicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonNotSeeApplicant(String value) {
        this.reasonNotSeeApplicant = value;
    }

    /**
     * Gets the value of the notDisclosedExplanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotDisclosedExplanation() {
        return notDisclosedExplanation;
    }

    /**
     * Sets the value of the notDisclosedExplanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotDisclosedExplanation(String value) {
        this.notDisclosedExplanation = value;
    }

    /**
     * Gets the value of the faceToFaceApptExplanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaceToFaceApptExplanation() {
        return faceToFaceApptExplanation;
    }

    /**
     * Sets the value of the faceToFaceApptExplanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaceToFaceApptExplanation(String value) {
        this.faceToFaceApptExplanation = value;
    }        public String getNpn() {		return npn;	}	public void setNpn(String npn) {		this.npn = npn;	}	public String getLicenseNumber() {		return licenseNumber;	}	public void setLicenseNumber(String licenseNumber) {		this.licenseNumber = licenseNumber;	}	public String getCertificateNumber() {		return certificateNumber;	}	public void setCertificateNumber(String certificateNumber) {		this.certificateNumber = certificateNumber;	}	public String getfFEUserId() {		return fFEUserId;	}	public void setfFEUserId(String fFEUserId) {		this.fFEUserId = fFEUserId;	}		public String getPhoneExt() {		return phoneExt;	}	public void setPhoneExt(String phoneExt) {		this.phoneExt = phoneExt;	}	public String getFaxExt() {		return faxExt;	}	public void setFaxExt(String faxExt) {		this.faxExt = faxExt;	}	public String getAgentCode() {		return agentCode;	}	public void setAgentCode(String agentCode) {		this.agentCode = agentCode;	}	public Agent getPaidAgent() {		return paidAgent;	}	public void setPaidAgent(Agent paidAgent) {		this.paidAgent = paidAgent;	}	public void setIssuedPoliciesLength(int issuedPoliciesLength) {		this.issuedPoliciesLength = issuedPoliciesLength;	}}