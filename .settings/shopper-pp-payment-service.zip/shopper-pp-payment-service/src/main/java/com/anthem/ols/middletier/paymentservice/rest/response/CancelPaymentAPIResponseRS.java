/**
* CancelPaymentAPIResponseRS.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 03/08/2017   1.0       Cognizant      Initial Version
*/
package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.anthem.ols.middletier.paymentservice.message.Exceptions;

@JsonInclude(Include.NON_NULL)
public class CancelPaymentAPIResponseRS implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 751855426584825729L;

	@JsonIgnore
    private boolean paymentCancelStatus;
    
    private String paymentStatus;
    
    private Exceptions[] exceptions;
    

	/**
	 * @return the paymentCancelStatus
	 */
	public boolean isPaymentCancelStatus() {
		return paymentCancelStatus;
	}

	/**
	 * @param paymentCancelStatus the paymentCancelStatus to set
	 */
	public void setPaymentCancelStatus(boolean paymentCancelStatus) {
		this.paymentCancelStatus = paymentCancelStatus;
	}

	/**
	 * @return the paymentStatus
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * @param paymentStatus the paymentStatus to set
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Exceptions[] getExceptions() {
		return exceptions;
	}

	public void setExceptions(Exceptions[] exceptions) {
		this.exceptions = exceptions;
	}

}
