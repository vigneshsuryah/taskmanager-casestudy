package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PolicyMember implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 5615030030493350044L;

	private  int id;

    private  ActionTypeEnum action;

	private  String exchMemberId;

	private  Date memberStartDate;
    
	private  Date memberEndDate;
 	
	private  Date lastTobaccoUseDate;

	private  Date autoDisenrollEffDate;

	private  Date autoDisenrollSchDate;	

	private  Date autoDisenrollCancelledDate;

	private  String issuerMemberId;

	private  AnswerTypeEnum isSubscriber;

	private  String relationshipToSubscriber;

	private  AnswerTypeEnum isMemberTobaccoUse;

	private  String enrollmentPeriodType;

	private  String sepReasonCode;

	private  String cancelationTermReasonCode;

	private  AnswerTypeEnum isAutoDisenrollPending;

	private  String autoDisenrollReason;

	private  AnswerTypeEnum isAutoDisenrollCancelledByContact;

	private  ExistingPolicy existingPolicy;
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getExchMemberId() {
		return exchMemberId;
	}

	public void setExchMemberId(String exchMemberId) {
		this.exchMemberId = exchMemberId;
	}

	public String getIssuerMemberId() {
		return issuerMemberId;
	}

	public void setIssuerMemberId(String issuerMemberId) {
		this.issuerMemberId = issuerMemberId;
	}

	public AnswerTypeEnum getIsSubscriber() {
		return isSubscriber;
	}

	public void setIsSubscriber(AnswerTypeEnum isSubscriber) {
		this.isSubscriber = isSubscriber;
	}

	public String getRelationshipToSubscriber() {
		return relationshipToSubscriber;
	}

	public void setRelationshipToSubscriber(String relationshipToSubscriber) {
		this.relationshipToSubscriber = relationshipToSubscriber;
	}

	public AnswerTypeEnum getIsMemberTobaccoUse() {
		return isMemberTobaccoUse;
	}

	public void setIsMemberTobaccoUse(AnswerTypeEnum isMemberTobaccoUse) {
		this.isMemberTobaccoUse = isMemberTobaccoUse;
	}

	public String getEnrollmentPeriodType() {
		return enrollmentPeriodType;
	}

	public void setEnrollmentPeriodType(String enrollmentPeriodType) {
		this.enrollmentPeriodType = enrollmentPeriodType;
	}

	public String getSepReasonCode() {
		return sepReasonCode;
	}

	public void setSepReasonCode(String sepReasonCode) {
		this.sepReasonCode = sepReasonCode;
	}

	public String getCancelationTermReasonCode() {
		return cancelationTermReasonCode;
	}

	public void setCancelationTermReasonCode(String cancelationTermReasonCode) {
		this.cancelationTermReasonCode = cancelationTermReasonCode;
	}

	public AnswerTypeEnum getIsAutoDisenrollPending() {
		return isAutoDisenrollPending;
	}

	public void setIsAutoDisenrollPending(AnswerTypeEnum isAutoDisenrollPending) {
		this.isAutoDisenrollPending = isAutoDisenrollPending;
	}

	public String getAutoDisenrollReason() {
		return autoDisenrollReason;
	}

	public void setAutoDisenrollReason(String autoDisenrollReason) {
		this.autoDisenrollReason = autoDisenrollReason;
	}

	public AnswerTypeEnum getIsAutoDisenrollCancelledByContact() {
		return isAutoDisenrollCancelledByContact;
	}

	public void setIsAutoDisenrollCancelledByContact(
			AnswerTypeEnum isAutoDisenrollCancelledByContact) {
		this.isAutoDisenrollCancelledByContact = isAutoDisenrollCancelledByContact;
	}

	public ExistingPolicy getExistingPolicy() {
		return existingPolicy;
	}

	public void setExistingPolicy(ExistingPolicy existingPolicy) {
		this.existingPolicy = existingPolicy;
	}

	public Date getMemberStartDate() {
		return memberStartDate;
	}

	public void setMemberStartDate(Date memberStartDate) {
		this.memberStartDate = memberStartDate;
	}

	public Date getMemberEndDate() {
		return memberEndDate;
	}

	public void setMemberEndDate(Date memberEndDate) {
		this.memberEndDate = memberEndDate;
	}

	public Date getLastTobaccoUseDate() {
		return lastTobaccoUseDate;
	}

	public void setLastTobaccoUseDate(Date lastTobaccoUseDate) {
		this.lastTobaccoUseDate = lastTobaccoUseDate;
	}

	public Date getAutoDisenrollEffDate() {
		return autoDisenrollEffDate;
	}

	public void setAutoDisenrollEffDate(Date autoDisenrollEffDate) {
		this.autoDisenrollEffDate = autoDisenrollEffDate;
	}

	public Date getAutoDisenrollSchDate() {
		return autoDisenrollSchDate;
	}

	public void setAutoDisenrollSchDate(Date autoDisenrollSchDate) {
		this.autoDisenrollSchDate = autoDisenrollSchDate;
	}

	public Date getAutoDisenrollCancelledDate() {
		return autoDisenrollCancelledDate;
	}

	public void setAutoDisenrollCancelledDate(
			Date autoDisenrollCancelledDate) {
		this.autoDisenrollCancelledDate = autoDisenrollCancelledDate;
	}

    
 

	 
	
}
