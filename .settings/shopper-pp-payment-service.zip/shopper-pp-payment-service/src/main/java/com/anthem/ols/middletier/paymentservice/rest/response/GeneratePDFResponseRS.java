package com.anthem.ols.middletier.paymentservice.rest.response;
public class GeneratePDFResponseRS extends BaseResponseRS {
	/**	 * 	 */	private static final long serialVersionUID = 3055222357213389856L;	private  String pdfString;	public String getPdfString() {		return pdfString;	}	public void setPdfString(String pdfString) {		this.pdfString = pdfString;	}}
