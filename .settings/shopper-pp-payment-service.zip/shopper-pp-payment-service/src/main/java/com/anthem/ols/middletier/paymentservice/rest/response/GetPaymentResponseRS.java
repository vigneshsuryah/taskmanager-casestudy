package com.anthem.ols.middletier.paymentservice.rest.response;

import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentSelection;
import com.anthem.ols.middletier.paymentservice.rest.bo.Plan;

public class GetPaymentResponseRS extends BaseResponseRS{

    /**
	 * 
	 */
	private static final long serialVersionUID = -8164361991844424247L;
	private PaymentSelection paymentSelection;
    private String acn;
    private Plan[] plan;
    private int planLength;

    public PaymentSelection getPaymentSelection() {
        return paymentSelection;
    }

    public void setPaymentSelection(PaymentSelection value) {
        this.paymentSelection = value;
    }
    
    public String getAcn() {
        return acn;
    }

    public void setAcn(String value) {
        this.acn = value;
    }

	public Plan[] getPlan() {
        if (this.plan == null) {
			return new Plan[0];
		}
        Plan[] retVal = new Plan[this.plan.length];
		System.arraycopy(this.plan, 0, retVal, 0,
				this.plan.length);
		return (retVal);
	}

	public void setPlan(Plan[] values) {       
        if (values != null) {
			int len = values.length;
			this.plan = ((Plan[]) new Plan[len]);
			for (int i = 0; (i < len); i++) {
				this.plan[i] = values[i];
			}
		} else {
			this.plan = null;
		}
	}
	
	public int getPlanLength() {
        if (this.plan == null) {
            return 0;
        }
        return this.plan.length;
    }

	public void setPlanLength(int planLength) {
		this.planLength = planLength;
	}
}
