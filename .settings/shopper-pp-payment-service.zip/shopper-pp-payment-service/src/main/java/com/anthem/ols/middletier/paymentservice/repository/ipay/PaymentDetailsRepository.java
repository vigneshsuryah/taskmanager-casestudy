package com.anthem.ols.middletier.paymentservice.repository.ipay;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.ols.middletier.paymentservice.entity.PaymentDetails;

@Repository
public interface PaymentDetailsRepository extends MongoRepository<PaymentDetails, String>{
	
	@Query(value = "{ 'acn' : ?0}")
	PaymentDetails getPaymentForAcn(String acn);
	
	@Query(value = "{ 'exchconsumerid' : ?0}")
	PaymentDetails getPaymentForExchConsumerId(String exchConsumerId);
	
	@Query(value = "{ 'transactions.anthem_orderid' : ?0}")
	PaymentDetails getPaymentDetailsByOrderId(String anthemOrderId);
	
	@Query(value = "{ 'acn' : ?0}, 'partnerid' : ?1")
	PaymentDetails getPaymentDetailsByAcnAndPartnerId(String acn, String partnerId);

}
