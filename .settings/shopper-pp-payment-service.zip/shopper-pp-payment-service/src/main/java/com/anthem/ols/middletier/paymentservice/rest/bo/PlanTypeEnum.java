package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum PlanTypeEnum
{
	
	CIA,
	EPO,
	HIA,
	HIAPLUS,
	HMO,
	HSA,
	INDEMNITY,
	POS,
	PPO,
	TERM_LIFE,
	VISION;
	
	public String value() {
		return name();
	}

	public static PlanTypeEnum fromValue(String v) {
		return valueOf(v);
	}
}