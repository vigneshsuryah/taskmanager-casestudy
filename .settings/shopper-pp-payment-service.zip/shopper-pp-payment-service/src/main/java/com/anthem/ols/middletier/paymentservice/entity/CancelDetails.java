package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CancelDetails {

	@Field("is_csr")
	private boolean isCsr;
	@Field("payment_channel")
	private String paymentChannel;
	@Field("cancelled_by")
	private String cancelledBy;
	@Field("cancelled_dt")
	private Date cancelledDt;
	//Auth Reversal Changes
	@Field("account_number")
	private String accountNumber;
	@Field("MOP")
	private String MOP;
	@Field("response_date")
	private String responseDate;
	@Field("avsaav")
	private String avsaav;
	@Field("card_security_value")
	private String cardSecurityValue;
	@Field("cavv")
	private String cavv;
	@Field("expiration_date")
	private String expirationDate;
	@Field("payment_advice_code")
	private String paymentAdviceCode;
	@Field("recurring_payment_advice_code")
	private String recurringPaymentAdviceCode;
	@Field("cc_token_number")
	private String tokenNumber;
	
}
