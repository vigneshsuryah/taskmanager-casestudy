package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ExistingPolicy implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 6070846912717039898L;

	private  int id;

    private  ActionTypeEnum action;

    private  String exchPolicyNo;
    
    private  String issuerPolicyNo;
    
	private  Date startDate;

    private  String enrollmentStatus;
    
    private  String issuerId;
    
    private  String assignedQHPId;
    
    private  double totalPremiumAmount;
    
    private  double maxEnrollmentGroupEligAPTC;
    
    private  double pctElectedAPTC;
    
    private  double aptcAppliedAmount;
    
    private  double totalIndvResponsibilityAmount;
    
    private  String exchConsumerId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getExchPolicyNo() {
		return exchPolicyNo;
	}

	public void setExchPolicyNo(String exchPolicyNo) {
		this.exchPolicyNo = exchPolicyNo;
	}

	public String getIssuerPolicyNo() {
		return issuerPolicyNo;
	}

	public void setIssuerPolicyNo(String issuerPolicyNo) {
		this.issuerPolicyNo = issuerPolicyNo;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}



	public String getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(String enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public String getAssignedQHPId() {
		return assignedQHPId;
	}

	public void setAssignedQHPId(String assignedQHPId) {
		this.assignedQHPId = assignedQHPId;
	}



	public double getTotalPremiumAmount() {
		return totalPremiumAmount;
	}

	public void setTotalPremiumAmount(double totalPremiumAmount) {
		this.totalPremiumAmount = totalPremiumAmount;
	}

	public double getMaxEnrollmentGroupEligAPTC() {
		return maxEnrollmentGroupEligAPTC;
	}

	public void setMaxEnrollmentGroupEligAPTC(double maxEnrollmentGroupEligAPTC) {
		this.maxEnrollmentGroupEligAPTC = maxEnrollmentGroupEligAPTC;
	}

	public double getPctElectedAPTC() {
		return pctElectedAPTC;
	}

	public void setPctElectedAPTC(double pctElectedAPTC) {
		this.pctElectedAPTC = pctElectedAPTC;
	}

	public double getAptcAppliedAmount() {
		return aptcAppliedAmount;
	}

	public void setAptcAppliedAmount(double aptcAppliedAmount) {
		this.aptcAppliedAmount = aptcAppliedAmount;
	}

	public double getTotalIndvResponsibilityAmount() {
		return totalIndvResponsibilityAmount;
	}

	public void setTotalIndvResponsibilityAmount(
			double totalIndvResponsibilityAmount) {
		this.totalIndvResponsibilityAmount = totalIndvResponsibilityAmount;
	}
	public String getExchConsumerId() {
		return exchConsumerId;
	}

	public void setExchConsumerId(String exchConsumerId) {
		this.exchConsumerId = exchConsumerId;
	}
}
