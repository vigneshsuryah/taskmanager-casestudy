package com.anthem.ols.middletier.paymentservice.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document(collection = "app_source")
public class PaymentAppSource {

	@Id
	public ObjectId _id;

	@Field("partner_id")
	private String partnerId;
	@Field("agent_type")
	private String agentType;
	@Field("app_origin_type")
	private String appOriginType;
	@Field("transfer_flag")
	private String transferFlag;
	@Field("app_source")
	private String appSource;
	@Field("agent_submitted")
	private String agentSubmitted;
}
