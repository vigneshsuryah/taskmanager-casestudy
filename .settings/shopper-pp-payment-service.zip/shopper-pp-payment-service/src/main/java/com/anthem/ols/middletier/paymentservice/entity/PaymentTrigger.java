package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTrigger {

	@Field("trigger_date")
	private Date triggerDate;
	@Field("trigger_id")
	private String triggerId;
	@Field("trigger_code")
	private String triggerCode;
	@Field("trigger_status")
	private String triggerStatus;

}
