
package com.anthem.ols.middletier.paymentservice.rest.bo;


public enum AddressTypeEnum {
	
	NONE,
	HOME,
	MAILING,
	BILLING;
	
	public String value() {
		return name();
	}

	public static AddressTypeEnum fromValue(String v) {
		return valueOf(v);
	}

}