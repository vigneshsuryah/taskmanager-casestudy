/**
* VersionResponse.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 01/08/2020  1.0      Cognizant       Initial Version
*/
package com.anthem.ols.middletier.paymentservice.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class VersionResponse {
	private String applicationVersion;

}
