package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum BankAcctTypeEnum {
	
	NONE,
	PERSONALCHECKING,
	PERSONALSAVINGS,
	BUSCHECKING,
	BUSSAVINGS;
	
	public String value() {
		return name();
	}

	public static BankAcctTypeEnum fromValue(String v) {
		return valueOf(v);
	}

}