package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Demographic extends Person implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1396009084225261755L;

	private  int id;

    private  String alternatePhNo;

    private  String emailAddress;

    private  AnswerTypeEnum isUseTobacco;

    private  AnswerTypeEnum isUSResident;

    private  String spokenLangPref;

    private  String primaryPhNo;

    private  RelationshipTypeEnum relationshipType;

    private  String writtenLangPref;

    private  MaritalStatusEnum maritalStatus;

    private  ActionTypeEnum action;

    private  String maidenName;

    private  CommunicationMethodTypeEnum communicationMethod;

    private  AnswerTypeEnum isLiveOutsideUSFor3Months;

    private  AnswerTypeEnum isUSCitizen;

    private  int yrResideInUS;

    private  int monthResideInUS;

    private  AnswerTypeEnum isWantEmailNotification;
    
    private  String tobaccoFrequency;

    private  String otherWrittenLangPref;
    
    private  String otherRelationship;
    
    private  String otherSpokenLangPerf;

	private  Date lastTobaccoUseDate;


    /**

     * Gets the value of the id property.

     * 

     */

    public int getId() {

        return id;

    }



    /**

     * Sets the value of the id property.

     * 

     */

    public void setId(int value) {

        this.id = value;

    }



    /**

     * Gets the value of the alternatePhNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAlternatePhNo() {

        return alternatePhNo;

    }



    /**

     * Sets the value of the alternatePhNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAlternatePhNo(String value) {

        this.alternatePhNo = value;

    }



    /**

     * Gets the value of the emailAddress property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getEmailAddress() {

        return emailAddress;

    }



    /**

     * Sets the value of the emailAddress property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setEmailAddress(String value) {

        this.emailAddress = value;

    }



    /**

     * Gets the value of the isUseTobacco property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsUseTobacco() {

        return isUseTobacco;

    }



    /**

     * Sets the value of the isUseTobacco property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsUseTobacco(AnswerTypeEnum value) {

        this.isUseTobacco = value;

    }



    /**

     * Gets the value of the isUSResident property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsUSResident() {

        return isUSResident;

    }



    /**

     * Sets the value of the isUSResident property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsUSResident(AnswerTypeEnum value) {

        this.isUSResident = value;

    }



    /**

     * Gets the value of the spokenLangPref property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getSpokenLangPref() {

        return spokenLangPref;

    }



    /**

     * Sets the value of the spokenLangPref property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setSpokenLangPref(String value) {

        this.spokenLangPref = value;

    }



    /**

     * Gets the value of the primaryPhNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getPrimaryPhNo() {

        return primaryPhNo;

    }



    /**

     * Sets the value of the primaryPhNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setPrimaryPhNo(String value) {

        this.primaryPhNo = value;

    }



    /**

     * Gets the value of the relationshipType property.

     * 

     * @return

     *     possible object is

     *     {@link RelationshipTypeEnum }

     *     

     */

    public RelationshipTypeEnum getRelationshipType() {

        return relationshipType;

    }



    /**

     * Sets the value of the relationshipType property.

     * 

     * @param value

     *     allowed object is

     *     {@link RelationshipTypeEnum }

     *     

     */

    public void setRelationshipType(RelationshipTypeEnum value) {

        this.relationshipType = value;

    }



    /**

     * Gets the value of the writtenLangPref property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getWrittenLangPref() {

        return writtenLangPref;

    }



    /**

     * Sets the value of the writtenLangPref property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setWrittenLangPref(String value) {

        this.writtenLangPref = value;

    }



    /**

     * Gets the value of the maritalStatus property.

     * 

     * @return

     *     possible object is

     *     {@link MaritalStatusEnum }

     *     

     */

    public MaritalStatusEnum getMaritalStatus() {

        return maritalStatus;

    }



    /**

     * Sets the value of the maritalStatus property.

     * 

     * @param value

     *     allowed object is

     *     {@link MaritalStatusEnum }

     *     

     */

    public void setMaritalStatus(MaritalStatusEnum value) {

        this.maritalStatus = value;

    }



    /**

     * Gets the value of the action property.

     * 

     * @return

     *     possible object is

     *     {@link ActionTypeEnum }

     *     

     */

    public ActionTypeEnum getAction() {

        return action;

    }



    /**

     * Sets the value of the action property.

     * 

     * @param value

     *     allowed object is

     *     {@link ActionTypeEnum }

     *     

     */

    public void setAction(ActionTypeEnum value) {

        this.action = value;

    }



    /**

     * Gets the value of the maidenName property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getMaidenName() {

        return maidenName;

    }



    /**

     * Sets the value of the maidenName property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setMaidenName(String value) {

        this.maidenName = value;

    }


    /**

     * Gets the value of the communicationMethod property.

     * 

     * @return

     *     possible object is

     *     {@link CommunicationMethodTypeEnum }

     *     

     */

    public CommunicationMethodTypeEnum getCommunicationMethod() {

        return communicationMethod;

    }



    /**

     * Sets the value of the communicationMethod property.

     * 

     * @param value

     *     allowed object is

     *     {@link CommunicationMethodTypeEnum }

     *     

     */

    public void setCommunicationMethod(CommunicationMethodTypeEnum value) {

        this.communicationMethod = value;

    }



    /**

     * Gets the value of the isLiveOutsideUSFor3Months property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsLiveOutsideUSFor3Months() {

        return isLiveOutsideUSFor3Months;

    }



    /**

     * Sets the value of the isLiveOutsideUSFor3Months property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsLiveOutsideUSFor3Months(AnswerTypeEnum value) {

        this.isLiveOutsideUSFor3Months = value;

    }



    /**

     * Gets the value of the isUSCitizen property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsUSCitizen() {

        return isUSCitizen;

    }



    /**

     * Sets the value of the isUSCitizen property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsUSCitizen(AnswerTypeEnum value) {

        this.isUSCitizen = value;

    }



    /**

     * Gets the value of the yrResideInUS property.

     * 

     */

    public int getYrResideInUS() {

        return yrResideInUS;

    }



    /**

     * Sets the value of the yrResideInUS property.

     * 

     */

    public void setYrResideInUS(int value) {

        this.yrResideInUS = value;

    }



    /**

     * Gets the value of the monthResideInUS property.

     * 

     */

    public int getMonthResideInUS() {

        return monthResideInUS;

    }



    /**

     * Sets the value of the monthResideInUS property.

     * 

     */

    public void setMonthResideInUS(int value) {

        this.monthResideInUS = value;

    }



    /**

     * Gets the value of the isWantEmailNotification property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsWantEmailNotification() {

        return isWantEmailNotification;

    }



    /**

     * Sets the value of the isWantEmailNotification property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsWantEmailNotification(AnswerTypeEnum value) {

        this.isWantEmailNotification = value;

    }
    
    public String getTobaccoFrequency() {
		return tobaccoFrequency;
	}



	public void setTobaccoFrequency(String tobaccoFrequency) {
		this.tobaccoFrequency = tobaccoFrequency;
	}



	public String getOtherWrittenLangPref() {
		return otherWrittenLangPref;
	}



	public void setOtherWrittenLangPref(String otherWrittenLangPref) {
		this.otherWrittenLangPref = otherWrittenLangPref;
	}



	public String getOtherRelationship() {
		return otherRelationship;
	}



	public void setOtherRelationship(String otherRelationship) {
		this.otherRelationship = otherRelationship;
	}



	public String getOtherSpokenLangPerf() {
		return otherSpokenLangPerf;
	}



	public void setOtherSpokenLangPerf(String otherSpokenLangPerf) {
		this.otherSpokenLangPerf = otherSpokenLangPerf;
	}


	public Date getLastTobaccoUseDate() {
		return lastTobaccoUseDate;
	}



	public void setLastTobaccoUseDate(Date lastTobaccoUseDate) {
		this.lastTobaccoUseDate = lastTobaccoUseDate;
	}


}