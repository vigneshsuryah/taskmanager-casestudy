package com.anthem.ols.middletier.paymentservice.rest.bo;

public class PMCreditCard {

	private String creditCardNumber;

	private String expirationMonth;
	
	private String expirationYear;

	private String integrityCheck;
	
	private String keyID;
	
	private String phaseID;
	
	private String creditCardNumberUI;
	
	private String creditCardFirstSix;
	
	private String creditCardLastFour;

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public String getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear = expirationYear;
	}

	public String getIntegrityCheck() {
		return integrityCheck;
	}

	public void setIntegrityCheck(String integrityCheck) {
		this.integrityCheck = integrityCheck;
	}

	public String getKeyID() {
		return keyID;
	}

	public void setKeyID(String keyID) {
		this.keyID = keyID;
	}

	public String getPhaseID() {
		return phaseID;
	}

	public void setPhaseID(String phaseID) {
		this.phaseID = phaseID;
	}

	public String getCreditCardNumberUI() {
		return creditCardNumberUI;
	}

	public void setCreditCardNumberUI(String creditCardNumberUI) {
		this.creditCardNumberUI = creditCardNumberUI;
	}

	public String getCreditCardFirstSix() {
		return creditCardFirstSix;
	}

	public void setCreditCardFirstSix(String creditCardFirstSix) {
		this.creditCardFirstSix = creditCardFirstSix;
	}

	public String getCreditCardLastFour() {
		return creditCardLastFour;
	}

	public void setCreditCardLastFour(String creditCardLastFour) {
		this.creditCardLastFour = creditCardLastFour;
	}
	
	
}
