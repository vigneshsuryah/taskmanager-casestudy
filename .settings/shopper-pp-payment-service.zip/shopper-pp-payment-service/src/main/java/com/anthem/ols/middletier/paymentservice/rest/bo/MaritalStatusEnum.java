package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum MaritalStatusEnum {
    NONE,
    SINGLE,
    MARRIED,
    DOMESTICPARTNER,        CIVILUNION;
    public String value() {        return name();    }
    public static MaritalStatusEnum fromValue(String v) {        return valueOf(v);    }}
