package com.anthem.ols.middletier.paymentservice.db2.dao;

import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.anthem.ols.middletier.paymentservice.rest.bo.AdvancedCsrSearchBean;

public interface MAPSPaymentDAO {
	
    public Map<String, Object> getMAPSPaymentUMUPAY5(String csrSearch) throws DataAccessException;

	public Map<String, Object> getMAPSPaymentUMUPAYQ(AdvancedCsrSearchBean csrSearch) throws DataAccessException;
}
