package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;
import java.util.Map;

public class ContactAttributes implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8764929300631802827L;
	
	private Map<String, String> SubscriberAttributes;

	public Map<String, String> getSubscriberAttributes() {
		return SubscriberAttributes;
	}

	public void setSubscriberAttributes(Map<String, String> subscriberAttributes) {
		SubscriberAttributes = subscriberAttributes;
	}
	
	
	
}
