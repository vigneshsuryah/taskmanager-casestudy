package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum ApplicationOriginTypeEnum {
    ELECTRONIC,
    FAX,
    PAPER;
    public String value() {        return name();    }
    public static ApplicationOriginTypeEnum fromValue(String v) {        return valueOf(v);    }
}
