package com.anthem.ols.middletier.paymentservice.rest.response;


public class CancelPaymentsResponseRS extends BaseResponseRS{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 751855426584825729L;

	private  String partnerId;

    private  String userId;

    private  String acn;

    private boolean paymentCancelStatus;
    
	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public boolean isPaymentCancelStatus() {
		return paymentCancelStatus;
	}

	public void setPaymentCancelStatus(boolean paymentCancelStatus) {
		this.paymentCancelStatus = paymentCancelStatus;
	}
}
