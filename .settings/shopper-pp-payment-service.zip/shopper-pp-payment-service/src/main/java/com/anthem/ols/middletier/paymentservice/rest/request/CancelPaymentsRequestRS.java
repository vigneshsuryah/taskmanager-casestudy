package com.anthem.ols.middletier.paymentservice.rest.request;


public class CancelPaymentsRequestRS extends BaseRequestRS {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1625560788947115073L;

	private String partnerId;

	private String userId;

	private String acn;

	private String paymentTrackingId;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public String getPaymentTrackingId() {
		return paymentTrackingId;
	}

	public void setPaymentTrackingId(String paymentTrackingId) {
		this.paymentTrackingId = paymentTrackingId;
	}
}
