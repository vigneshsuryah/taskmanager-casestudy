package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum AppCovTypeEnum {
    NEWAPP,
    CHANGEOFCOV,
    ADDDEPENDENT,
    NONE;
    public String value() {        return name();    }
    public static AppCovTypeEnum fromValue(String v) {        return valueOf(v);    }

}
