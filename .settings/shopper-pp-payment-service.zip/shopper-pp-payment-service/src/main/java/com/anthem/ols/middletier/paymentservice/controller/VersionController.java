/**
* VersionController.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 01/08/2020  1.0      Cognizant       Initial Version
*/
package com.anthem.ols.middletier.paymentservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.ols.middletier.paymentservice.response.VersionResponse;
import com.anthem.ols.middletier.paymentservice.utils.IppServiceConstants;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class VersionController implements IppServiceConstants {

	private final static Logger LOGGER = LoggerFactory.getLogger(VersionController.class);

	@Value("${application.version}")
	private String version;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(path = "/version", method = RequestMethod.GET)
	@ApiOperation(value = "Get Application version", notes = "The api call is used to check the application version")
	@ApiResponses({ @ApiResponse(code = 200, message = MSG_SUCCESS, response = VersionResponse.class),
			@ApiResponse(code = 400, message = MSG_BAD_REQUEST, response = VersionResponse.class),
			@ApiResponse(code = 500, message = MSG_SERVICE_NOT_AVAILABLE, response = VersionResponse.class) })

	public ResponseEntity<VersionResponse> getVersion() {
		LOGGER.info("VersionController: Inside show version - start");
		VersionResponse response = new VersionResponse();
		response.setApplicationVersion(version);
		LOGGER.info("VersionController: Inside show version - end");
		return new ResponseEntity(response, HttpStatus.OK);
	}

}
