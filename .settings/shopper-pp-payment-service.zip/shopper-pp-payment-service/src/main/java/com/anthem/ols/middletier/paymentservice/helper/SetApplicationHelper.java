package com.anthem.ols.middletier.paymentservice.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anthem.ols.middletier.paymentservice.entity.FundAccountOwnerFullAddress;
import com.anthem.ols.middletier.paymentservice.entity.PaymentDetails;
import com.anthem.ols.middletier.paymentservice.entity.Transaction;
import com.anthem.ols.middletier.paymentservice.exception.BusinessException;
import com.anthem.ols.middletier.paymentservice.rest.bo.AccessControl;
import com.anthem.ols.middletier.paymentservice.rest.bo.AccessTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Address;
import com.anthem.ols.middletier.paymentservice.rest.bo.AnswerTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Applicant;
import com.anthem.ols.middletier.paymentservice.rest.bo.Application;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.BankAccount;
import com.anthem.ols.middletier.paymentservice.rest.bo.BillingFrequencyTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.CreditCard;
import com.anthem.ols.middletier.paymentservice.rest.bo.Demographic;
import com.anthem.ols.middletier.paymentservice.rest.bo.LanguageEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Payment;
import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentSelection;
import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.RelationshipTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Shopper;
import com.anthem.ols.middletier.paymentservice.rest.bo.ShopperRoleEnum;
import com.anthem.ols.middletier.paymentservice.utils.ServiceUtils;

@Component
public class SetApplicationHelper {

	@Autowired
	private ServiceUtils serviceUtils;

	private void constructPaymentSelection(PaymentDetails payDetails, Application application) {
		PaymentSelection paySelection = new PaymentSelection();
		List<Payment> payments = new ArrayList<>();
		for (Transaction transaction : payDetails.getTransactions()) {
			Payment payment = new Payment();
			if (null != payDetails.getPaymentMethod()) {
				if ("ACH".equalsIgnoreCase(payDetails.getPaymentMethod().getPaymentType())) {
					BankAccount bankAcc = new BankAccount();
					bankAcc.setAccountHolderName(payDetails.getPaymentMethod().getNameOnFundingAccount());
					bankAcc.setAccountNo(payDetails.getPaymentMethod().getBankAccountNumber());
					bankAcc.setAccountType(
							serviceUtils.convertBankAccType(payDetails.getPaymentMethod().getPaymentSubType()));
					bankAcc.setRoutingNo(payDetails.getPaymentMethod().getBankRoutingnumber());
					payment.setBankAcct(bankAcc);
					payment.setPaymentType(PaymentTypeEnum.ECHECK);
				} else if ("CC".equalsIgnoreCase(payDetails.getPaymentMethod().getPaymentType())) {
					CreditCard creditCard = new CreditCard();
					creditCard.setCardHolderName(payDetails.getPaymentMethod().getNameOnFundingAccount());
					creditCard.setCardNo(payDetails.getPaymentMethod().getCreditCardNumber());
					creditCard.setCardType(
							serviceUtils.convertCardType(payDetails.getPaymentMethod().getPaymentSubType()));
					creditCard.setExpDate(payDetails.getPaymentMethod().getCcExpDate());
					payment.setCreditCard(creditCard);
					payment.setPaymentType(PaymentTypeEnum.CREDITCARD);
				}

				FundAccountOwnerFullAddress fundAddr = payDetails.getPaymentMethod().getFundAccountOwnerFullAddress();
				if (null != fundAddr) {
					Address address = new Address();
					address.setAddressLine1(fundAddr.getAddress1());
					address.setAddressLine2(fundAddr.getAddress2());
					address.setCity(fundAddr.getCity());
					address.setState(fundAddr.getState());
					address.setPostalCode(fundAddr.getZipcode());
					address.setCounty(fundAddr.getCounty());
					address.setCountyCode(fundAddr.getCountyCode());
					payment.setBillingAddr(address);
				}
				payment.setBillingPerson(payDetails.getPaymentMethod().getNameOnFundingAccount());

			}
			payment.setBillingFrequency(BillingFrequencyTypeEnum.fromValue(transaction.getBillingFrequency()));
			payment.setWithdrawDay(Integer.parseInt(transaction.getWithDrawDay()));
			payment.setPaymentAmt(transaction.getPremiumAmount());
			payment.setPaymentTrackingId(transaction.getAnthemOrderId());
			payments.add(payment);
		}
		paySelection.setInitialPayment(payments.stream().toArray(Payment[]::new));
		paySelection.setApplicationLanguage(payDetails.getLangPref());
		// paySelection.setApplicationStatus(payDetails.get);
		paySelection.setComputedMRAAmount(Double.valueOf(payDetails.getTransactions()[0].getComputedMRAAmount()));
		paySelection.setCsrIdentifier(payDetails.getPayerId().getId());
		paySelection.setEmailAddress(payDetails.getTransactions()[0].getPaymentConfirmationEmailAddress());
		paySelection.setIsRecvPaperlessBillInfo(
				AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvPaperlessBillingFlag()));
		paySelection.setRetroInd(payDetails.getTransactions()[0].getRetroIndc());
		paySelection.setRetroPayToDate(payDetails.getTransactions()[0].getRetroPayToDate());
		paySelection.setIsRecvElectronicCOC(
				AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvElectronicCocFlag()));
		paySelection.setIsReceivePaymentConf(
				AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvPaymentConfFlag()));
		application.setPaymentSelection(paySelection);
	}

	public void validateApplicantRelationShip(Application application) throws BusinessException {
		if (null != application.getApplicant() && application.getApplicant().length > 0) {
			Applicant[] applicantDataBeanColl = application.getApplicant();

			boolean applicantExists = false;
			boolean spouseExists = false;
			boolean domesticPartnerExists = false;

			for (Applicant applicant : applicantDataBeanColl) {
				Demographic demographicDataBean = applicant.getDemographic();
				if (null != demographicDataBean.getRelationshipType()
						&& demographicDataBean.getRelationshipType() == RelationshipTypeEnum.APPLICANT) {
					if (applicantExists) {
						throw new BusinessException("Application cannot have more than one relation of type Applicant");
					} else {
						applicantExists = true;
					}
				}
				if (null != demographicDataBean.getRelationshipType()
						&& demographicDataBean.getRelationshipType() == RelationshipTypeEnum.SPOUSE) {
					if (spouseExists) {
						throw new BusinessException("Application cannot have more than one relation of type Spouse");
					} else {
						spouseExists = true;
					}
				}
				if (null != demographicDataBean.getRelationshipType()
						&& demographicDataBean.getRelationshipType() == RelationshipTypeEnum.DOMESTICPARTNER) {

					if (domesticPartnerExists) {
						throw new BusinessException(
								"Application cannot have more than one relation of type DomesticPartner");
					} else {
						domesticPartnerExists = true;
					}
				}
			}

		}
	}

	public Application convertPayDetailsToApplication(PaymentDetails payDetails) {
		Application application = new Application();
		// application.setAction(ActionTypeEnum.NONE);
		application.setAcn(payDetails.getAcn());
		application.setApplicationVersion(payDetails.getApplicationVersion());
		application.setState(payDetails.getState());
		// application.setFormNo(payDetail);
		// application.setVersionNo(value);
		// application.setAdeCustomerId(value);
		// application.setIsMGA(value);
		// application.setIsAgentAssisted(value);
		// application.setIsAgentSubmitted(value);
		// application.setIsApplyingForOthers(value);
		// application.setIsFamilyElect(value);
		// application.setCampaignId(value);
		// application.setBrandName(value);
		application.setApplicationType(ApplicationTypeEnum.fromValue(payDetails.getApplicationType()));
		application.setReqEffDate(payDetails.getReqEffDate());
		// application.setFutureReqEffDate(value);
		// application.setLastUpdatedId(value);
		// application.setLastUpdatedTS(value);
		// application.setLastPageAccessed(value);

		AccessControl[] accessControlArr = new AccessControl[1];
		AccessControl accessControl = new AccessControl();
		accessControl.setAccessType(AccessTypeEnum.fromValue(payDetails.getAccessType()));
		Shopper shopper = new Shopper();
		shopper.setShopperRole(ShopperRoleEnum.fromValue(payDetails.getUserRole()));
		shopper.setUserId(payDetails.getUserId());
		accessControl.setUser(shopper);
		accessControlArr[0] = accessControl;
		application.setAccessControlList(accessControlArr);

		Applicant[] applicants = new Applicant[1];
		Applicant applicant = new Applicant();
		Date dob = serviceUtils.convertStringToDate(payDetails.getDateOfBirth(), "MM-dd-yyyy");
		applicant.setAge(serviceUtils.getDateOfBirth(dob));
		Demographic demographic = new Demographic();

		demographic.setDateOfBirth(dob);
		// demographic.setEmailAddress(value); //have to check
		demographic.setFirstName(payDetails.getApplicantFirstName());
		demographic.setLastName(payDetails.getApplicantLastName());
		demographic.setMi(payDetails.getApplicantMiddleName());
		applicant.setDemographic(demographic);
		applicant.setHCID(payDetails.getHcid());
		applicant.setMemberCode(Integer.parseInt(payDetails.getMemberCode()));
		applicants[0] = applicant;
		application.setApplicant(applicants);

		// application.setApplicationStatus(value);
		// application.setPin(value);
		// application.setSubmissionMessage(value);
		// application.setIsAgentRecall(value);
		// application.setIsWorkingWithAgent(value);
		// application.setIsApplyingForOthers(value);
		application.setPremiumAmt(payDetails.getSettleAmount());
		application.setAppSource(payDetails.getAppSource());
		// application.setAppRecvDateLocalTZ(value);
		// application.setIsElectronicOptIn(value);
		// application.setAppCreatedDate(value);
		// application.setMbu(value);
		// application.setDocNumber(value);
		// application.setAppCovType(value);
		// application.setCurrPolicyNo(value);
		// application.setIsEstablishHSA(value);
		// application.setIsDentalCov(value);
		// application.setIsAllFamilyMbrsInOneBill(value);
		// application.setIsLegalUSResident(value);
		// application.setIsUSCitizen(value);
		// application.setAdditionalInfo(value);
		// application.setIsAddDependents(value);
		// application.setIsAddSpouse(value);
		// application.setIsClaimDepOnIncomeTax(value);
		// application.setIsAutoUW(value);
		// application.setIsAdditionalInfo(value);
		// application.setCIDPhone(phone);
		// application.setQuoteSource(quoteSource);
		// application.setVendorLeadId(vendorLeadId);
		application.setExchSubscriberId(payDetails.getExchSubscriberId());
		application.setExchTransactionId(payDetails.getExchTransactionId());
		// application.setExchTotalAmtOwed(exchTotalAmtOwed);
		application.setExchAPTCAmt(Double.valueOf(payDetails.getExchaptcAmt()));
		// application.setExchQHPId(exchQHPId);
		// application.setExchTotPremiumAmt(exchTotPremiumAmt);
		application.setApplicationLanguage(LanguageEnum.fromValue(payDetails.getLangPref()));
		// application.setOwnership(ownership);
		// application.setTransferActivity(transferActivity);
		application.setHcid(payDetails.getHcid());
		// application.setPrefWrittenLang(prefWrittenLang);
		// application.setPrefSpokenLang(prefSpokenLang);
		// application.setIsUseTobacco(isUseTobacco);
		// application.setIsActiveDutyChild(isActiveDutyChild);
		// application.setIsOtherHealthCovDisability(isOtherHealthCovDisability);
		// application.setIsReplCovPolicyInForce(isReplCovPolicyInForce);
		// application.setIsEligibleForMedicare(isEligibleForMedicare);
		// application.setReplCovCancelDate(replCovCancelDate);
		// application.setIsReplCovPolicyInReplace(isReplCovPolicyInReplace);
		// application.setIsAgentCanSubmit(isAgentCanSubmit);
		// application.setIsFullAPTCUsed(isFullAPTCUsed);
		// application.setIsApplyLeftOverAPTCToOtherEnrollGroup(isApplyLeftOverAPTCToOtherEnrollGroup);
		// application.setExchCSRLevel(exchCSRLevel);
		application.setExchConsumerId(payDetails.getExchConsumerId());
		// application.setIsSubsidyEligible(isSubsidyEligible);
		// application.setAppliedAPTCAmount(appliedAPTCAmount);
		// application.setWlpAssignedConsumerId(wlpAssignedConsumerId);
		// application.setExchCSRLevelPct(exchCSRLevelPct);
		// application.setCustomerReferenceNo(customerReferenceNo);
		// application.setIsIncarceration(isIncarceration);

		application.setwLPConsumerId(payDetails.getWlpConsumerId());
		application.setCreatePartnerId(payDetails.getPartnerId());
		// application.setExchStateCode(payDetails.getState());
		application.setIpAddress(payDetails.getIpAddress());
		// application.setInitialPremium(payDetails.getSettleAmount());
		// application.setOwnership();

		if (null != payDetails.getTransactions() && payDetails.getTransactions().length > 0) {
			constructPaymentSelection(payDetails, application);
		}

		return application;

	}
}
