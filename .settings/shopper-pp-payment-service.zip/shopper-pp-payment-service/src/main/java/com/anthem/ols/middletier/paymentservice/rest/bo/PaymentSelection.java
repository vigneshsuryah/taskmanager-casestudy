
package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class PaymentSelection implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1572961152765325968L;

	private int id;

	private Payment[] initialPayment;

	private Payment[] ongoingPayment;

	private AnswerTypeEnum isNoInitPayment;

	private ThirdPartyDesignee thirdPartyDesignee;

	private ActionTypeEnum action;

	private String paymentExceptionMsg;

	private AnswerTypeEnum isRecvPaperlessBillInfo;

	private AnswerTypeEnum isRecvElectronicCOC;

	private String paymentIdentifier;

	private AnswerTypeEnum isReceivePaymentConf;

	private String emailAddress;

	private String applicationLanguage;

	private ValidationErrors validationErrors;

	private double monthlyPremium;

	private Double computedMRAAmount;

	private String retroInd;

	private Date retroPayToDate;

	private String policyId;

	private String paymentTransactionId;

	private String sepIndicator;

	private String sepDocsReceived;

	private String stateCode;

	private String exchangeTypeCode;
	
	private Date wemRequestedEffectiveDate ;
	
	private ApplicationStatusEnum applicationStatus;
	
	private String csrIdentifier;
	
	private int initialPaymentLength;
	private int ongoingPaymentLength;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Payment[] getInitialPayment() {
		if (this.initialPayment == null) {
			return new Payment[0];
		}
		Payment[] retVal = new Payment[this.initialPayment.length];
		System.arraycopy(this.initialPayment, 0, retVal, 0,
				this.initialPayment.length);
		return (retVal);
	}

	public void setInitialPayment(Payment[] values) {
		if (values != null) {
			int len = values.length;
			this.initialPayment = ((Payment[]) new Payment[len]);
			for (int i = 0; (i < len); i++) {
				this.initialPayment[i] = values[i];
			}
		} else {
			this.initialPayment = null;
		}
	}

	public Payment[] getOngoingPayment() {
		if (this.ongoingPayment == null) {
			return new Payment[0];
		}
		Payment[] retVal = new Payment[this.ongoingPayment.length];
		System.arraycopy(this.ongoingPayment, 0, retVal, 0,
				this.ongoingPayment.length);
		return (retVal);
	}

	public void setOngoingPayment(Payment[] values) {
		if (values != null) {
			int len = values.length;
			this.ongoingPayment = ((Payment[]) new Payment[len]);
			for (int i = 0; (i < len); i++) {
				this.ongoingPayment[i] = values[i];
			}
		} else {
			this.ongoingPayment = null;
		}
	}

	public AnswerTypeEnum getIsNoInitPayment() {
		return isNoInitPayment;
	}

	public void setIsNoInitPayment(AnswerTypeEnum isNoInitPayment) {
		this.isNoInitPayment = isNoInitPayment;
	}

	public ThirdPartyDesignee getThirdPartyDesignee() {
		return thirdPartyDesignee;
	}

	public void setThirdPartyDesignee(ThirdPartyDesignee thirdPartyDesignee) {
		this.thirdPartyDesignee = thirdPartyDesignee;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getPaymentExceptionMsg() {
		return paymentExceptionMsg;
	}

	public void setPaymentExceptionMsg(String paymentExceptionMsg) {
		this.paymentExceptionMsg = paymentExceptionMsg;
	}

	public AnswerTypeEnum getIsRecvPaperlessBillInfo() {
		return isRecvPaperlessBillInfo;
	}

	public void setIsRecvPaperlessBillInfo(AnswerTypeEnum isRecvPaperlessBillInfo) {
		this.isRecvPaperlessBillInfo = isRecvPaperlessBillInfo;
	}

	public AnswerTypeEnum getIsRecvElectronicCOC() {
		return isRecvElectronicCOC;
	}

	public void setIsRecvElectronicCOC(AnswerTypeEnum isRecvElectronicCOC) {
		this.isRecvElectronicCOC = isRecvElectronicCOC;
	}

	public String getPaymentIdentifier() {
		return paymentIdentifier;
	}

	public void setPaymentIdentifier(String paymentIdentifier) {
		this.paymentIdentifier = paymentIdentifier;
	}

	public AnswerTypeEnum getIsReceivePaymentConf() {
		return isReceivePaymentConf;
	}

	public void setIsReceivePaymentConf(AnswerTypeEnum isReceivePaymentConf) {
		this.isReceivePaymentConf = isReceivePaymentConf;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getApplicationLanguage() {
		return applicationLanguage;
	}

	public void setApplicationLanguage(String applicationLanguage) {
		this.applicationLanguage = applicationLanguage;
	}

	public ValidationErrors getValidationErrors() {
		return validationErrors;
	}

	public void setValidationErrors(ValidationErrors validationErrors) {
		this.validationErrors = validationErrors;
	}

	public double getMonthlyPremium() {
		return monthlyPremium;
	}

	public void setMonthlyPremium(double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}

	public Double getComputedMRAAmount() {
		return computedMRAAmount;
	}

	public void setComputedMRAAmount(Double computedMRAAmount) {
		this.computedMRAAmount = computedMRAAmount;
	}

	public String getRetroInd() {
		return retroInd;
	}

	public void setRetroInd(String retroInd) {
		this.retroInd = retroInd;
	}

	public Date getRetroPayToDate() {
		return retroPayToDate;
	}

	public void setRetroPayToDate(Date retroPayToDate) {
		this.retroPayToDate = retroPayToDate;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getPaymentTransactionId() {
		return paymentTransactionId;
	}

	public void setPaymentTransactionId(String paymentTransactionId) {
		this.paymentTransactionId = paymentTransactionId;
	}

	public String getSepIndicator() {
		return sepIndicator;
	}

	public void setSepIndicator(String sepIndicator) {
		this.sepIndicator = sepIndicator;
	}

	public String getSepDocsReceived() {
		return sepDocsReceived;
	}

	public void setSepDocsReceived(String sepDocsReceived) {
		this.sepDocsReceived = sepDocsReceived;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getExchangeTypeCode() {
		return exchangeTypeCode;
	}

	public void setExchangeTypeCode(String exchangeTypeCode) {
		this.exchangeTypeCode = exchangeTypeCode;
	}

	public Date getWemRequestedEffectiveDate() {
		return wemRequestedEffectiveDate;
	}

	public void setWemRequestedEffectiveDate(
			Date wemRequestedEffectiveDate) {
		this.wemRequestedEffectiveDate = wemRequestedEffectiveDate;
	}

	public ApplicationStatusEnum getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(ApplicationStatusEnum applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getCsrIdentifier() {
		return csrIdentifier;
	}

	public void setCsrIdentifier(String csrIdentifier) {
		this.csrIdentifier = csrIdentifier;
	}
	
	public int getOngoingPaymentLength() {
		if (this.ongoingPayment == null) {
			return 0;
		}
		return this.ongoingPayment.length;

	}
	
	public int getInitialPaymentLength() {
		if (this.initialPayment == null) {
			return 0;
		}
		return this.initialPayment.length;
	}

	public void setInitialPaymentLength(int initialPaymentLength) {
		this.initialPaymentLength = initialPaymentLength;
	}

	public void setOngoingPaymentLength(int ongoingPaymentLength) {
		this.ongoingPaymentLength = ongoingPaymentLength;
	}
	
}