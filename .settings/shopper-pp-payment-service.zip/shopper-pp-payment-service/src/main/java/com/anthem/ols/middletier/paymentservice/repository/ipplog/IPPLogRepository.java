package com.anthem.ols.middletier.paymentservice.repository.ipplog;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.anthem.ols.middletier.paymentservice.entity.IPPLogDetails;

public interface IPPLogRepository extends MongoRepository<IPPLogDetails, String>{

}
