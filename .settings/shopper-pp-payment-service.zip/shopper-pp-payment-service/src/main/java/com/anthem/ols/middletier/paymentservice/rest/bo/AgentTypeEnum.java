package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum AgentTypeEnum {
    BROKER,
    DIRECTSALES,
    CAPTIVEAGENT,
    NONE;
    /**     * @return     */    public String value() {        return name();    }
    /**     * @param v     * @return     */    public static AgentTypeEnum fromValue(String v) {        return valueOf(v);    }}
