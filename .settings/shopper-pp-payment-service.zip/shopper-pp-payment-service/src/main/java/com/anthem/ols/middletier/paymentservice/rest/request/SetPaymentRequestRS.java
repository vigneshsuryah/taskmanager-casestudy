package com.anthem.ols.middletier.paymentservice.rest.request;import com.anthem.ols.middletier.paymentservice.rest.bo.Application;import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentSelection;
public class SetPaymentRequestRS extends BaseRequestRS{
    /**	 * 	 */	private static final long serialVersionUID = 6333945789503797148L;	private  String partnerId;
    private  String userId;
    private  String acn;
    private  PaymentSelection paymentSelection;        private  Application application;	public String getPartnerId() {		return partnerId;	}	public void setPartnerId(String partnerId) {		this.partnerId = partnerId;	}	public String getUserId() {		return userId;	}	public void setUserId(String userId) {		this.userId = userId;	}	public String getAcn() {		return acn;	}	public void setAcn(String acn) {		this.acn = acn;	}	public PaymentSelection getPaymentSelection() {		return paymentSelection;	}	public void setPaymentSelection(PaymentSelection paymentSelection) {		this.paymentSelection = paymentSelection;	}	/**	 * @return the application	 */	public Application getApplication() {		return application;	}	/**	 * @param application the application to set	 */	public void setApplication(Application application) {		this.application = application;	}
}
