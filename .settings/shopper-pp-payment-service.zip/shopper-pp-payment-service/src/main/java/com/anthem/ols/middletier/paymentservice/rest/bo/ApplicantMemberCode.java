package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class ApplicantMemberCode implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 2103350136178933552L;	private  int memberCode;
    private  String firstName;
    private  String lastName;
    private  String mi;
    private  Date dateOfBirth;

    /**
     * Gets the value of the memberCode property.
     * 
     */
    public int getMemberCode() {
        return memberCode;
    }

    /**
     * Sets the value of the memberCode property.
     * 
     */
    public void setMemberCode(int value) {
        this.memberCode = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the mi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMi() {
        return mi;
    }

    /**
     * Sets the value of the mi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMi(String value) {
        this.mi = value;
    }

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setDateOfBirth(Date value) {
        this.dateOfBirth = value;
    }

}
