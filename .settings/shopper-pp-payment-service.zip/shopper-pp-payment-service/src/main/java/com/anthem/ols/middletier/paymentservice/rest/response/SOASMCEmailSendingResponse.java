package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;
import java.util.List;

public class SOASMCEmailSendingResponse extends SMCBaseResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5554371064045457313L;
	private String requestId;
	private List<SMCResponse> responses;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public List<SMCResponse> getResponses() {
		return responses;
	}
	public void setResponses(List<SMCResponse> responses) {
		this.responses = responses;
	}
	
}