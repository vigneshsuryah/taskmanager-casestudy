package com.anthem.ols.middletier.paymentservice.utils;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * MongoSSLUtils.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 01/08/2020  1.0       Cognizant      Initial Version
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mongodb.MongoClientOptions;

@Component
public class MongoSSLUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MongoSSLUtils.class);


    private static SSLSocketFactory buildSslSocketFactory() {
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[] { new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException { }
                @Override
                public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException { }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            } }, new SecureRandom());
        } catch (NoSuchAlgorithmException | KeyManagementException excep) {
            LOGGER.error("MongoConfig buildSslSocketFactory",excep);
        }
        assert sslContext != null;
        return sslContext.getSocketFactory();
    }

    public MongoClientOptions.Builder customMongoBuilder() {
        // Mongo database client options to override the default behavior
        MongoClientOptions.Builder builder = MongoClientOptions.builder();
        builder.sslEnabled(true);
        builder.socketFactory(buildSslSocketFactory());
        return builder;
    }
}
