/**
* PaymentRestController.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 01/10/2020   1.0       Cognizant      Initial
*/
package com.anthem.ols.middletier.paymentservice.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.ols.middletier.paymentservice.exception.BusinessException;
import com.anthem.ols.middletier.paymentservice.rest.request.CancelPaymentsRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.CancelPaymentsResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogRequest;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogResponse;
import com.anthem.ols.middletier.paymentservice.rest.request.ValidateZipCodeRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.ValidateZipCodeResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.service.ApplicationPaymentService;

@RestController
public class PaymentRestController {

	@Autowired
	private ApplicationPaymentService paymentServiceImpl;

	@PostMapping(value = "getApplication", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetApplicationResponseRS getApplication(@RequestBody GetApplicationRequestRS request,
			HttpServletRequest httpRequest) {
		GetApplicationResponseRS response = new GetApplicationResponseRS();
		try {
			response = paymentServiceImpl.getApplication(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "setApplication", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetApplicationResponseRS setApplication(@RequestBody SetApplicationRequestRS request,
			HttpServletRequest httpRequest) {
		SetApplicationResponseRS response = new SetApplicationResponseRS();
		try {
			response = paymentServiceImpl.setApplication(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "getPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody GetPaymentResponseRS getPayment(@RequestBody GetPaymentRequestRS request,
			HttpServletRequest httpRequest) {
		GetPaymentResponseRS response = new GetPaymentResponseRS();
		try {
			response = paymentServiceImpl.getPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "setPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetPaymentResponseRS setPayment(@RequestBody SetPaymentRequestRS request,
			HttpServletRequest httpRequest) {
		SetPaymentResponseRS response = new SetPaymentResponseRS();
		try {
			response = paymentServiceImpl.setPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "cancelPayment", headers = "Accept=*/*", consumes = { "application/json",
			"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody CancelPaymentsResponseRS cancelPayment(@RequestBody CancelPaymentsRequestRS request,
			HttpServletRequest httpRequest) {
		CancelPaymentsResponseRS response = new CancelPaymentsResponseRS();
		try {
			response = paymentServiceImpl.cancelPayment(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}

	@PostMapping(value = "validateZipCode", headers = "Accept=*/*", consumes = { "application/json","application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody ValidateZipCodeResponseRS validateZipCode(@RequestBody ValidateZipCodeRequestRS request, HttpServletRequest httpRequest) {
		ValidateZipCodeResponseRS response = new ValidateZipCodeResponseRS();
		try {
			response = paymentServiceImpl.validateZipCode(request);
		} catch (BusinessException e) {
			response.setBusinessError(e.getBusinessError());
		}
		return response;
	}
	
	@PostMapping(value = "setExchangeTransLog", headers = "Accept=*/*", consumes = { "application/json","application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody SetExchangeTransLogResponse setExchangeTransLog(@RequestBody SetExchangeTransLogRequest request, HttpServletRequest httpRequest) throws BusinessException {
		SetExchangeTransLogResponse response = null;
		try {
			response = paymentServiceImpl.setExchangeTransLog(request);
		} catch (Exception e) {
			BusinessException bex = new BusinessException("Invalid Input");
			throw bex;
		}
		return response;
	}

}
