package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum MessageTypeEnum {
    PARSERERROR,
    SEVEREERROR,
    ERROR;
    public String value() {        return name();    }
    public static MessageTypeEnum fromValue(String v) {        return valueOf(v);    }}
