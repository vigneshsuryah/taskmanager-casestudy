package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class PlanSelection implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 3102579310436071119L;	private  int id;
    private  Plan[] plan;
    private  PlanRider[] optRider;
    private  ActionTypeEnum action;        private int planLength;        private int optRiderLength;    

    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

 
    /**
     * 
     * 
     * @return
     *     array of
     *     {@link Plan }
     *     
     */
    public Plan[] getPlan() {
        if (this.plan == null) {
            return new Plan[ 0 ] ;
        }
        Plan[] retVal = new Plan[this.plan.length] ;
        System.arraycopy(this.plan, 0, retVal, 0, this.plan.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link Plan }
     *     
     */
    public Plan getPlan(int idx) {
        if (this.plan == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.plan[idx];
    }

    public int getPlanLength() {
        if (this.plan == null) {
            return  0;
        }
        return this.plan.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link Plan }
     *     
     */
    public void setPlan(Plan[] values) {
        int len = values.length;
        this.plan = ((Plan[]) new Plan[len] );
        for (int i = 0; (i<len); i ++) {
            this.plan[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link Plan }
     *     
     */
    public Plan setPlan(int idx, Plan value) {
        return this.plan[idx] = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link PlanRider }
     *     
     */
    public PlanRider[] getOptRider() {
        if (this.optRider == null) {
            return new PlanRider[ 0 ] ;
        }
        PlanRider[] retVal = new PlanRider[this.optRider.length] ;
        System.arraycopy(this.optRider, 0, retVal, 0, this.optRider.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link PlanRider }
     *     
     */
    public PlanRider getOptRider(int idx) {
        if (this.optRider == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.optRider[idx];
    }

    public int getOptRiderLength() {
        if (this.optRider == null) {
            return  0;
        }
        return this.optRider.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link PlanRider }
     *     
     */
    public void setOptRider(PlanRider[] values) {    	if(values!=null){
	        int len = values.length;	
	        this.optRider = ((PlanRider[]) new PlanRider[len] );	
	        for (int i = 0; (i<len); i ++) {	
	            this.optRider[i] = values[i];	
	        }    	}else{    		 this.optRider=null;    	}
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link PlanRider }
     *     
     */
    public PlanRider setOptRider(int idx, PlanRider value) {
        return this.optRider[idx] = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }	public void setPlanLength(int planLength) {		this.planLength = planLength;	}	public void setOptRiderLength(int optRiderLength) {		this.optRiderLength = optRiderLength;	}


}
