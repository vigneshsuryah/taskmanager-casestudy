package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Application implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 3704336989138617513L;

	private String acn;

    private String applicationVersion;

    private String state;

    private String formNo;

    private String versionNo;

    private String releaseNo;

    private AnswerTypeEnum isMGA;

    private AnswerTypeEnum isAgentAssisted;

    private AnswerTypeEnum isAgentSubmitted;

    private AnswerTypeEnum isApplyingForOthers;

    private AnswerTypeEnum isAgentRecall;

    private AnswerTypeEnum isFamilyElect;

    private String rateTier;

    private double premiumAmt;

    private String campaignId;

    private BrandNameEnum brandName;

    private ApplicationTypeEnum applicationType;

    private Date reqEffDate;

    private Date futureReqEffDate;

    private AccessControl[] accessControlList;

    private String lastUpdatedId;

    private Date lastUpdatedTS;

    private String lastPageAccessed;

    private Agent agent;

    private Applicant[] applicant;

    private AuthorizedRep enrollingPerson;

    private PaymentSelection paymentSelection;

    private AttestationOfEligibility attestationOfEligibility;

    private ApplicationStatus applicationStatus;

    private String enrollmentName;

    private AnswerTypeEnum isWorkingWithAgent;

    private TermsAndConditions termsAndConditions;

    private String adeCustomerId;

    private AnswerTypeEnum isReadAccompanyingMaterial;

    private QuotedPlan[] quotedPlans;

    private String submissionMessage;

    private int pin;

    private ActionTypeEnum action;

    private AdminApplication adminApplication;

    private AnswerTypeEnum isElectronicOptIn;

    private PlanMaterialLanguageEnum planMaterialLanguage;

    private PlanMaterialTypeEnum planMaterialFormat;

    private String emoAppId;

    private String appSource;

    private String createPartnerId;

    private String submitPartnerId;

    private ApplicationOriginTypeEnum applicationOrigin;

    private String appRecvDateLocalTZ;

    private String overflowLeadId;

    private Date appCreatedDate;

    private AnswerTypeEnum isAutoUW;

    private String uwStatus;

    private String docNumber;

    private String caseId;

    private MbuTypeEnum mbu;

    private AppCovTypeEnum appCovType;

    private String currPolicyNo;

    private AnswerTypeEnum isReadWriteEnglish;

    private AnswerTypeEnum isEstablishHSA;

    private AnswerTypeEnum isEnrollAllEligible;

    private AnswerTypeEnum isAllFamilyMbrsInOneBill;

    private String diffLastNameExplanation;

    private AnswerTypeEnum isLiveOutsideUSFor3Months;

    private AnswerTypeEnum isLegalUSResident;

    private AnswerTypeEnum isUSCitizen;

    private StatementOfAccountability statementOfAccountability;

    private String additionalInfo;

    private AnswerTypeEnum isDentalCov;

    private AnswerTypeEnum isAddSpouse;

    private AnswerTypeEnum isAddDependents;

    private double initialPremium;

    private AnswerTypeEnum isClaimDepOnIncomeTax;

    private AnswerTypeEnum isAdditionalInfo;

    private String cIDPhone;

    private String quoteSource;

    private String vendorLeadId;

    private String exchSubscriberId;
    
    private String exchTransactionId;
    
    private double exchTotalAmtOwed;
        
    private double exchAPTCAmt;
        
    private String applicationId;
        
    private int applicationSeqId;
        
    private String exchQHPId;
	
    private double exchTotPremiumAmt;
	
    private LanguageEnum applicationLanguage;
	
    private OwnershipEnum ownership;
	
    private String transferActivity;
	
	private AnswerTypeEnum isSubsidyEligible;
	 
	 private String hCID;
	 
	 private String prefWrittenLang;
	 
	 private String prefSpokenLang;
     
     private AnswerTypeEnum isUseTobacco;
     
     private AnswerTypeEnum isActiveDutyChild;
     
 	 private String wlpAssignedConsumerId;
 	
 	 private String exchAssignedConsumerId;
 	
 	 private String exchStateCode;
 	 
 	 private APTCAttestationPerson[] aptcAttestationPersons;
 
 	 private String wLPConsumerId;

 	 private String exchConsumerId;
	 
 	 private String suffix;
	 
 	 private int electedAPTCPercentage;
	 
 	 private double appliedAPTCAmount;
	 
 	 private int rateAreaId;
	 
 	 private AnswerTypeEnum unsubscribeReminderEmailFlag;
	 
 	 private String exchCSRLevel;
	 
	 private int exchTransLogId;	

	 private double exchAPTCPct;
	 
	 private AnswerTypeEnum isOtherHealthCovDisability;
	 
	 private AnswerTypeEnum isReplCovPolicyInForce;
	 
	 private AnswerTypeEnum isEligibleForMedicare;
	 
	 private Date replCovCancelDate;
	  
	 private AnswerTypeEnum isReplCovPolicyInReplace;
	 	 
	 private AnswerTypeEnum isAgentCanSubmit;
	 
	 private AnswerTypeEnum isFullAPTCUsed;

	 private AnswerTypeEnum isApplyLeftOverAPTCToOtherEnrollGroup;
	 
	 private AnswerTypeEnum isPrimaryTaxFiler;

	 private String exchCSRLevelPct;

	private String customerReferenceNo;
    
    private AnswerTypeEnum isIncarceration;
    
    private int accessControlListLength;
    
    private int applicantLength;
    
    private int quotedPlansLength;
    
    private String ipAddress;



	/**

     * Gets the value of the acn property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAcn() {

        return acn;

    }



    /**

     * Sets the value of the acn property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAcn(String value) {

        this.acn = value;

    }



    /**

     * Gets the value of the applicationVersion property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getApplicationVersion() {

        return applicationVersion;

    }



    /**

     * Sets the value of the applicationVersion property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setApplicationVersion(String value) {

        this.applicationVersion = value;

    }



    /**

     * Gets the value of the state property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getState() {

        return state;

    }



    /**

     * Sets the value of the state property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setState(String value) {

        this.state = value;

    }



    /**

     * Gets the value of the formNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getFormNo() {

        return formNo;

    }



    /**

     * Sets the value of the formNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setFormNo(String value) {

        this.formNo = value;

    }



    /**

     * Gets the value of the versionNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getVersionNo() {

        return versionNo;

    }



    /**

     * Sets the value of the versionNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setVersionNo(String value) {

        this.versionNo = value;

    }



    /**

     * Gets the value of the releaseNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getReleaseNo() {

        return releaseNo;

    }



    /**

     * Sets the value of the releaseNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setReleaseNo(String value) {

        this.releaseNo = value;

    }



    /**

     * Gets the value of the isMGA property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsMGA() {

        return isMGA;

    }



    /**

     * Sets the value of the isMGA property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsMGA(AnswerTypeEnum value) {

        this.isMGA = value;

    }



    /**

     * Gets the value of the isAgentAssisted property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAgentAssisted() {

        return isAgentAssisted;

    }



    /**

     * Sets the value of the isAgentAssisted property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAgentAssisted(AnswerTypeEnum value) {

        this.isAgentAssisted = value;

    }



    /**

     * Gets the value of the isAgentSubmitted property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAgentSubmitted() {

        return isAgentSubmitted;

    }



    /**

     * Sets the value of the isAgentSubmitted property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAgentSubmitted(AnswerTypeEnum value) {

        this.isAgentSubmitted = value;

    }



    /**

     * Gets the value of the isApplyingForOthers property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsApplyingForOthers() {

        return isApplyingForOthers;

    }



    /**

     * Sets the value of the isApplyingForOthers property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsApplyingForOthers(AnswerTypeEnum value) {

        this.isApplyingForOthers = value;

    }



    /**

     * Gets the value of the isAgentRecall property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAgentRecall() {

        return isAgentRecall;

    }



    /**

     * Sets the value of the isAgentRecall property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAgentRecall(AnswerTypeEnum value) {

        this.isAgentRecall = value;

    }



    /**

     * Gets the value of the isFamilyElect property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsFamilyElect() {

        return isFamilyElect;

    }



    /**

     * Sets the value of the isFamilyElect property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsFamilyElect(AnswerTypeEnum value) {

        this.isFamilyElect = value;

    }



    /**

     * Gets the value of the rateTier property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getRateTier() {

        return rateTier;

    }



    /**

     * Sets the value of the rateTier property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setRateTier(String value) {

        this.rateTier = value;

    }



    /**

     * Gets the value of the premiumAmt property.

     * 

     */

    public double getPremiumAmt() {

        return premiumAmt;

    }



    /**

     * Sets the value of the premiumAmt property.

     * 

     */

    public void setPremiumAmt(double value) {

        this.premiumAmt = value;

    }



    /**

     * Gets the value of the campaignId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getCampaignId() {

        return campaignId;

    }



    /**

     * Sets the value of the campaignId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setCampaignId(String value) {

        this.campaignId = value;

    }



    /**

     * Gets the value of the brandName property.

     * 

     * @return

     *     possible object is

     *     {@link BrandNameEnum }

     *     

     */

    public BrandNameEnum getBrandName() {

        return brandName;

    }



    /**

     * Sets the value of the brandName property.

     * 

     * @param value

     *     allowed object is

     *     {@link BrandNameEnum }

     *     

     */

    public void setBrandName(BrandNameEnum value) {

        this.brandName = value;

    }



    /**

     * Gets the value of the applicationType property.

     * 

     * @return

     *     possible object is

     *     {@link ApplicationTypeEnum }

     *     

     */

    public ApplicationTypeEnum getApplicationType() {

        return applicationType;

    }



    /**

     * Sets the value of the applicationType property.

     * 

     * @param value

     *     allowed object is

     *     {@link ApplicationTypeEnum }

     *     

     */

    public void setApplicationType(ApplicationTypeEnum value) {

        this.applicationType = value;

    }



    /**

     * Gets the value of the reqEffDate property.

     * 

     * @return

     *     possible object is

     *     {@link Date }

     *     

     */

    public Date getReqEffDate() {

        return reqEffDate;

    }



    /**

     * Sets the value of the reqEffDate property.

     * 

     * @param value

     *     allowed object is

     *     {@link Date }

     *     

     */
    public void setReqEffDate(Date value) {

        this.reqEffDate = value;

    }



    /**

     * Gets the value of the futureReqEffDate property.

     * 

     * @return

     *     possible object is

     *     {@link Date }

     *     

     */

    public Date getFutureReqEffDate() {

        return futureReqEffDate;

    }



    /**

     * Sets the value of the futureReqEffDate property.

     * 

     * @param value

     *     allowed object is

     *     {@link Date }

     *     

     */

    public void setFutureReqEffDate(Date value) {

        this.futureReqEffDate = value;

    }



    /**

     * 

     * 

     * @return

     *     array of

     *     {@link AccessControl }

     *     

     */

    public AccessControl[] getAccessControlList() {

        if (this.accessControlList == null) {

            return new AccessControl[ 0 ] ;

        }

        AccessControl[] retVal = new AccessControl[this.accessControlList.length] ;

        System.arraycopy(this.accessControlList, 0, retVal, 0, this.accessControlList.length);

        return (retVal);

    }



    /**

     * 

     * 

     * @return

     *     one of

     *     {@link AccessControl }

     *     

     */

    public AccessControl getAccessControlList(int idx) {

        if (this.accessControlList == null) {

            throw new IndexOutOfBoundsException();

        }

        return this.accessControlList[idx];

    }



    public int getAccessControlListLength() {

        if (this.accessControlList == null) {

            return  0;

        }

        return this.accessControlList.length;

    }



    /**

     * 

     * 

     * @param values

     *     allowed objects are

     *     {@link AccessControl }

     *     

     */

    public void setAccessControlList(AccessControl[] values) {

        int len = values.length;

        this.accessControlList = ((AccessControl[]) new AccessControl[len] );

        for (int i = 0; (i<len); i ++) {

            this.accessControlList[i] = values[i];

        }

    }



    /**

     * 

     * 

     * @param value

     *     allowed object is

     *     {@link AccessControl }

     *     

     */

    public AccessControl setAccessControlList(int idx, AccessControl value) {

        return this.accessControlList[idx] = value;

    }



    /**

     * Gets the value of the lastUpdatedId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getLastUpdatedId() {

        return lastUpdatedId;

    }



    /**

     * Sets the value of the lastUpdatedId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setLastUpdatedId(String value) {

        this.lastUpdatedId = value;

    }



    /**

     * Gets the value of the lastUpdatedTS property.

     * 

     * @return

     *     possible object is

     *     {@link Date }

     *     

     */

    public Date getLastUpdatedTS() {

        return lastUpdatedTS;

    }



    /**

     * Sets the value of the lastUpdatedTS property.

     * 

     * @param value

     *     allowed object is

     *     {@link Date }

     *     

     */

    public void setLastUpdatedTS(Date value) {

        this.lastUpdatedTS = value;

    }



    /**

     * Gets the value of the lastPageAccessed property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getLastPageAccessed() {

        return lastPageAccessed;

    }



    /**

     * Sets the value of the lastPageAccessed property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setLastPageAccessed(String value) {

        this.lastPageAccessed = value;

    }



    /**

     * Gets the value of the agent property.

     * 

     * @return

     *     possible object is

     *     {@link Agent }

     *     

     */

    public Agent getAgent() {

        return agent;

    }



    /**

     * Sets the value of the agent property.

     * 

     * @param value

     *     allowed object is

     *     {@link Agent }

     *     

     */

    public void setAgent(Agent value) {

        this.agent = value;

    }



    /**

     * 

     * 

     * @return

     *     array of

     *     {@link Applicant }

     *     

     */

    public Applicant[] getApplicant() {

        if (this.applicant == null) {

            return new Applicant[ 0 ] ;

        }

        Applicant[] retVal = new Applicant[this.applicant.length] ;

        System.arraycopy(this.applicant, 0, retVal, 0, this.applicant.length);

        return (retVal);

    }



    /**

     * 

     * 

     * @return

     *     one of

     *     {@link Applicant }

     *     

     */

    public Applicant getApplicant(int idx) {

        if (this.applicant == null) {

            throw new IndexOutOfBoundsException();

        }

        return this.applicant[idx];

    }



    public int getApplicantLength() {

        if (this.applicant == null) {

            return  0;

        }

        return this.applicant.length;

    }



    /**

     * 

     * 

     * @param values

     *     allowed objects are

     *     {@link Applicant }

     *     

     */

    public void setApplicant(Applicant[] values) {

        int len = values.length;

        this.applicant = ((Applicant[]) new Applicant[len] );

        for (int i = 0; (i<len); i ++) {

            this.applicant[i] = values[i];

        }

    }



    /**

     * 

     * 

     * @param value

     *     allowed object is

     *     {@link Applicant }

     *     

     */

    public Applicant setApplicant(int idx, Applicant value) {

        return this.applicant[idx] = value;

    }



    /**

     * Gets the value of the enrollingPerson property.

     * 

     * @return

     *     possible object is

     *     {@link AuthorizedRep }

     *     

     */

    public AuthorizedRep getEnrollingPerson() {

        return enrollingPerson;

    }



    /**

     * Sets the value of the enrollingPerson property.

     * 

     * @param value

     *     allowed object is

     *     {@link AuthorizedRep }

     *     

     */

    public void setEnrollingPerson(AuthorizedRep value) {

        this.enrollingPerson = value;

    }



    /**

     * Gets the value of the paymentSelection property.

     * 

     * @return

     *     possible object is

     *     {@link PaymentSelection }

     *     

     */

    public PaymentSelection getPaymentSelection() {

        return paymentSelection;

    }



    /**

     * Sets the value of the paymentSelection property.

     * 

     * @param value

     *     allowed object is

     *     {@link PaymentSelection }

     *     

     */

    public void setPaymentSelection(PaymentSelection value) {

        this.paymentSelection = value;

    }



    /**

     * Gets the value of the attestationOfEligibility property.

     * 

     * @return

     *     possible object is

     *     {@link AttestationOfEligibility }

     *     

     */

    public AttestationOfEligibility getAttestationOfEligibility() {

        return attestationOfEligibility;

    }



    /**

     * Sets the value of the attestationOfEligibility property.

     * 

     * @param value

     *     allowed object is

     *     {@link AttestationOfEligibility }

     *     

     */

    public void setAttestationOfEligibility(AttestationOfEligibility value) {

        this.attestationOfEligibility = value;

    }



    /**

     * Gets the value of the applicationStatus property.

     * 

     * @return

     *     possible object is

     *     {@link ApplicationStatus }

     *     

     */

    public ApplicationStatus getApplicationStatus() {

        return applicationStatus;

    }



    /**

     * Sets the value of the applicationStatus property.

     * 

     * @param value

     *     allowed object is

     *     {@link ApplicationStatus }

     *     

     */

    public void setApplicationStatus(ApplicationStatus value) {

        this.applicationStatus = value;

    }



    /**

     * Gets the value of the enrollmentName property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getEnrollmentName() {

        return enrollmentName;

    }



    /**

     * Sets the value of the enrollmentName property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setEnrollmentName(String value) {

        this.enrollmentName = value;

    }



    /**

     * Gets the value of the isWorkingWithAgent property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsWorkingWithAgent() {

        return isWorkingWithAgent;

    }



    /**

     * Sets the value of the isWorkingWithAgent property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsWorkingWithAgent(AnswerTypeEnum value) {

        this.isWorkingWithAgent = value;

    }

   
    /**

     * Gets the value of the termsAndConditions property.

     * 

     * @return

     *     possible object is

     *     {@link TermsAndConditions }

     *     

     */

    public TermsAndConditions getTermsAndConditions() {

        return termsAndConditions;

    }



    /**

     * Sets the value of the termsAndConditions property.

     * 

     * @param value

     *     allowed object is

     *     {@link TermsAndConditions }

     *     

     */

    public void setTermsAndConditions(TermsAndConditions value) {

        this.termsAndConditions = value;

    }



    /**

     * Gets the value of the adeCustomerId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAdeCustomerId() {

        return adeCustomerId;

    }



    /**

     * Sets the value of the adeCustomerId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAdeCustomerId(String value) {

        this.adeCustomerId = value;

    }



    /**

     * Gets the value of the isReadAccompanyingMaterial property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsReadAccompanyingMaterial() {

        return isReadAccompanyingMaterial;

    }



    /**

     * Sets the value of the isReadAccompanyingMaterial property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsReadAccompanyingMaterial(AnswerTypeEnum value) {

        this.isReadAccompanyingMaterial = value;

    }



    /**

     * 

     * 

     * @return

     *     array of

     *     {@link QuotedPlan }

     *     

     */

    public QuotedPlan[] getQuotedPlans() {

        if (this.quotedPlans == null) {

            return new QuotedPlan[ 0 ] ;

        }

        QuotedPlan[] retVal = new QuotedPlan[this.quotedPlans.length] ;

        System.arraycopy(this.quotedPlans, 0, retVal, 0, this.quotedPlans.length);

        return (retVal);

    }



    /**

     * 

     * 

     * @return

     *     one of

     *     {@link QuotedPlan }

     *     

     */

    public QuotedPlan getQuotedPlans(int idx) {

        if (this.quotedPlans == null) {

            throw new IndexOutOfBoundsException();

        }

        return this.quotedPlans[idx];

    }



    public int getQuotedPlansLength() {

        if (this.quotedPlans == null) {

            return  0;

        }

        return this.quotedPlans.length;

    }



    /**

     * 

     * 

     * @param values

     *     allowed objects are

     *     {@link QuotedPlan }

     *     

     */

    public void setQuotedPlans(QuotedPlan[] values) {

    	 if(values!=null){
	    	int len = values.length;
	
	        this.quotedPlans = ((QuotedPlan[]) new QuotedPlan[len] );
	
	        for (int i = 0; (i<len); i ++) {
	
	            this.quotedPlans[i] = values[i];
	
	        }
    	 }else {
         	this.quotedPlans = null;
         }

    }



    /**

     * 

     * 

     * @param value

     *     allowed object is

     *     {@link QuotedPlan }

     *     

     */

    public QuotedPlan setQuotedPlans(int idx, QuotedPlan value) {

        return this.quotedPlans[idx] = value;

    }



    /**

     * Gets the value of the submissionMessage property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getSubmissionMessage() {

        return submissionMessage;

    }



    /**

     * Sets the value of the submissionMessage property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setSubmissionMessage(String value) {

        this.submissionMessage = value;

    }



    /**

     * Gets the value of the pin property.

     * 

     */

    public int getPin() {

        return pin;

    }



    /**

     * Sets the value of the pin property.

     * 

     */

    public void setPin(int value) {

        this.pin = value;

    }


    /**

     * Gets the value of the action property.

     * 

     * @return

     *     possible object is

     *     {@link ActionTypeEnum }

     *     

     */

    public ActionTypeEnum getAction() {

        return action;

    }



    /**

     * Sets the value of the action property.

     * 

     * @param value

     *     allowed object is

     *     {@link ActionTypeEnum }

     *     

     */

    public void setAction(ActionTypeEnum value) {

        this.action = value;

    }



    /**

     * Gets the value of the adminApplication property.

     * 

     * @return

     *     possible object is

     *     {@link AdminApplication }

     *     

     */

    public AdminApplication getAdminApplication() {

        return adminApplication;

    }



    /**

     * Sets the value of the adminApplication property.

     * 

     * @param value

     *     allowed object is

     *     {@link AdminApplication }

     *     

     */

    public void setAdminApplication(AdminApplication value) {

        this.adminApplication = value;

    }



    /**

     * Gets the value of the isElectronicOptIn property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsElectronicOptIn() {

        return isElectronicOptIn;

    }



    /**

     * Sets the value of the isElectronicOptIn property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsElectronicOptIn(AnswerTypeEnum value) {

        this.isElectronicOptIn = value;

    }



    /**

     * Gets the value of the planMaterialLanguage property.

     * 

     * @return

     *     possible object is

     *     {@link PlanMaterialLanguageEnum }

     *     

     */

    public PlanMaterialLanguageEnum getPlanMaterialLanguage() {

        return planMaterialLanguage;

    }



    /**

     * Sets the value of the planMaterialLanguage property.

     * 

     * @param value

     *     allowed object is

     *     {@link PlanMaterialLanguageEnum }

     *     

     */

    public void setPlanMaterialLanguage(PlanMaterialLanguageEnum value) {

        this.planMaterialLanguage = value;

    }



    /**

     * Gets the value of the planMaterialFormat property.

     * 

     * @return

     *     possible object is

     *     {@link PlanMaterialTypeEnum }

     *     

     */

    public PlanMaterialTypeEnum getPlanMaterialFormat() {

        return planMaterialFormat;

    }



    /**

     * Sets the value of the planMaterialFormat property.

     * 

     * @param value

     *     allowed object is

     *     {@link PlanMaterialTypeEnum }

     *     

     */

    public void setPlanMaterialFormat(PlanMaterialTypeEnum value) {

        this.planMaterialFormat = value;

    }



    /**

     * Gets the value of the emoAppId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getEmoAppId() {

        return emoAppId;

    }



    /**

     * Sets the value of the emoAppId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setEmoAppId(String value) {

        this.emoAppId = value;

    }



    /**

     * Gets the value of the appSource property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAppSource() {

        return appSource;

    }



    /**

     * Sets the value of the appSource property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAppSource(String value) {

        this.appSource = value;

    }



    /**

     * Gets the value of the createPartnerId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getCreatePartnerId() {

        return createPartnerId;

    }



    /**

     * Sets the value of the createPartnerId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setCreatePartnerId(String value) {

        this.createPartnerId = value;

    }



    /**

     * Gets the value of the submitPartnerId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getSubmitPartnerId() {

        return submitPartnerId;

    }



    /**

     * Sets the value of the submitPartnerId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setSubmitPartnerId(String value) {

        this.submitPartnerId = value;

    }



    /**

     * Gets the value of the applicationOrigin property.

     * 

     * @return

     *     possible object is

     *     {@link ApplicationOriginTypeEnum }

     *     

     */

    public ApplicationOriginTypeEnum getApplicationOrigin() {

        return applicationOrigin;

    }



    /**

     * Sets the value of the applicationOrigin property.

     * 

     * @param value

     *     allowed object is

     *     {@link ApplicationOriginTypeEnum }

     *     

     */

    public void setApplicationOrigin(ApplicationOriginTypeEnum value) {

        this.applicationOrigin = value;

    }



    /**

     * Gets the value of the appRecvDateLocalTZ property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAppRecvDateLocalTZ() {

        return appRecvDateLocalTZ;

    }



    /**

     * Sets the value of the appRecvDateLocalTZ property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAppRecvDateLocalTZ(String value) {

        this.appRecvDateLocalTZ = value;

    }



    /**

     * Gets the value of the overflowLeadId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getOverflowLeadId() {

        return overflowLeadId;

    }



    /**

     * Sets the value of the overflowLeadId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setOverflowLeadId(String value) {

        this.overflowLeadId = value;

    }



    /**

     * Gets the value of the appCreatedDate property.

     * 

     * @return

     *     possible object is

     *     {@link Date }

     *     

     */

    public Date getAppCreatedDate() {

        return appCreatedDate;

    }



    /**

     * Sets the value of the appCreatedDate property.

     * 

     * @param value

     *     allowed object is

     *     {@link Date }

     *     

     */

    public void setAppCreatedDate(Date value) {

        this.appCreatedDate = value;

    }



    /**

     * Gets the value of the isAutoUW property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAutoUW() {

        return isAutoUW;

    }



    /**

     * Sets the value of the isAutoUW property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAutoUW(AnswerTypeEnum value) {

        this.isAutoUW = value;

    }



    /**

     * Gets the value of the uwStatus property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getUwStatus() {

        return uwStatus;

    }



    /**

     * Sets the value of the uwStatus property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setUwStatus(String value) {

        this.uwStatus = value;

    }



    /**

     * Gets the value of the docNumber property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getDocNumber() {

        return docNumber;

    }



    /**

     * Sets the value of the docNumber property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setDocNumber(String value) {

        this.docNumber = value;

    }



    /**

     * Gets the value of the caseId property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getCaseId() {

        return caseId;

    }



    /**

     * Sets the value of the caseId property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setCaseId(String value) {

        this.caseId = value;

    }



    /**

     * Gets the value of the mbu property.

     * 

     * @return

     *     possible object is

     *     {@link MbuTypeEnum }

     *     

     */

    public MbuTypeEnum getMbu() {

        return mbu;

    }



    /**

     * Sets the value of the mbu property.

     * 

     * @param value

     *     allowed object is

     *     {@link MbuTypeEnum }

     *     

     */

    public void setMbu(MbuTypeEnum value) {

        this.mbu = value;

    }



    /**

     * Gets the value of the appCovType property.

     * 

     * @return

     *     possible object is

     *     {@link AppCovTypeEnum }

     *     

     */

    public AppCovTypeEnum getAppCovType() {

        return appCovType;

    }



    /**

     * Sets the value of the appCovType property.

     * 

     * @param value

     *     allowed object is

     *     {@link AppCovTypeEnum }

     *     

     */

    public void setAppCovType(AppCovTypeEnum value) {

        this.appCovType = value;

    }



    /**

     * Gets the value of the currPolicyNo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getCurrPolicyNo() {

        return currPolicyNo;

    }



    /**

     * Sets the value of the currPolicyNo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setCurrPolicyNo(String value) {

        this.currPolicyNo = value;

    }



    /**

     * Gets the value of the isReadWriteEnglish property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsReadWriteEnglish() {

        return isReadWriteEnglish;

    }



    /**

     * Sets the value of the isReadWriteEnglish property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsReadWriteEnglish(AnswerTypeEnum value) {

        this.isReadWriteEnglish = value;

    }



    /**

     * Gets the value of the isEstablishHSA property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsEstablishHSA() {

        return isEstablishHSA;

    }



    /**

     * Sets the value of the isEstablishHSA property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsEstablishHSA(AnswerTypeEnum value) {

        this.isEstablishHSA = value;

    }


    /**

     * Gets the value of the isEnrollAllEligible property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsEnrollAllEligible() {

        return isEnrollAllEligible;

    }



    /**

     * Sets the value of the isEnrollAllEligible property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsEnrollAllEligible(AnswerTypeEnum value) {

        this.isEnrollAllEligible = value;

    }


    /**

     * Gets the value of the isAllFamilyMbrsInOneBill property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAllFamilyMbrsInOneBill() {

        return isAllFamilyMbrsInOneBill;

    }



    /**

     * Sets the value of the isAllFamilyMbrsInOneBill property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAllFamilyMbrsInOneBill(AnswerTypeEnum value) {

        this.isAllFamilyMbrsInOneBill = value;

    }



    /**

     * Gets the value of the diffLastNameExplanation property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getDiffLastNameExplanation() {

        return diffLastNameExplanation;

    }



    /**

     * Sets the value of the diffLastNameExplanation property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setDiffLastNameExplanation(String value) {

        this.diffLastNameExplanation = value;

    }



    /**

     * Gets the value of the isLiveOutsideUSFor3Months property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsLiveOutsideUSFor3Months() {

        return isLiveOutsideUSFor3Months;

    }



    /**

     * Sets the value of the isLiveOutsideUSFor3Months property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsLiveOutsideUSFor3Months(AnswerTypeEnum value) {

        this.isLiveOutsideUSFor3Months = value;

    }



    /**

     * Gets the value of the isLegalUSResident property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsLegalUSResident() {

        return isLegalUSResident;

    }



    /**

     * Sets the value of the isLegalUSResident property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsLegalUSResident(AnswerTypeEnum value) {

        this.isLegalUSResident = value;

    }



    /**

     * Gets the value of the isUSCitizen property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsUSCitizen() {

        return isUSCitizen;

    }



    /**

     * Sets the value of the isUSCitizen property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsUSCitizen(AnswerTypeEnum value) {

        this.isUSCitizen = value;

    }



    /**

     * Gets the value of the statementOfAccountability property.

     * 

     * @return

     *     possible object is

     *     {@link StatementOfAccountability }

     *     

     */

    public StatementOfAccountability getStatementOfAccountability() {

        return statementOfAccountability;

    }



    /**

     * Sets the value of the statementOfAccountability property.

     * 

     * @param value

     *     allowed object is

     *     {@link StatementOfAccountability }

     *     

     */

    public void setStatementOfAccountability(StatementOfAccountability value) {

        this.statementOfAccountability = value;

    }



    /**

     * Gets the value of the additionalInfo property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getAdditionalInfo() {

        return additionalInfo;

    }



    /**

     * Sets the value of the additionalInfo property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setAdditionalInfo(String value) {

        this.additionalInfo = value;

    }



    /**

     * Gets the value of the isDentalCov property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsDentalCov() {

        return isDentalCov;

    }



    /**

     * Sets the value of the isDentalCov property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsDentalCov(AnswerTypeEnum value) {

        this.isDentalCov = value;

    }



    /**

     * Gets the value of the isAddSpouse property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAddSpouse() {

        return isAddSpouse;

    }



    /**

     * Sets the value of the isAddSpouse property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAddSpouse(AnswerTypeEnum value) {

        this.isAddSpouse = value;

    }



    /**

     * Gets the value of the isAddDependents property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAddDependents() {

        return isAddDependents;

    }



    /**

     * Sets the value of the isAddDependents property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAddDependents(AnswerTypeEnum value) {

        this.isAddDependents = value;

    }



    /**

     * Gets the value of the initialPremium property.

     * 

     */

    public double getInitialPremium() {

        return initialPremium;

    }



    /**

     * Sets the value of the initialPremium property.

     * 

     */

    public void setInitialPremium(double value) {

        this.initialPremium = value;

    }



    /**

     * Gets the value of the isClaimDepOnIncomeTax property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsClaimDepOnIncomeTax() {

        return isClaimDepOnIncomeTax;

    }



    /**

     * Sets the value of the isClaimDepOnIncomeTax property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsClaimDepOnIncomeTax(AnswerTypeEnum value) {

        this.isClaimDepOnIncomeTax = value;

    }



    /**

     * Gets the value of the isAdditionalInfo property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsAdditionalInfo() {

        return isAdditionalInfo;

    }



    /**

     * Sets the value of the isAdditionalInfo property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsAdditionalInfo(AnswerTypeEnum value) {

        this.isAdditionalInfo = value;

    }



	public String getCIDPhone() {

		return cIDPhone;

	}



	public void setCIDPhone(String phone) {

		cIDPhone = phone;

	}



	public String getQuoteSource() {

		return quoteSource;

	}



	public void setQuoteSource(String quoteSource) {

		this.quoteSource = quoteSource;

	}



	public String getVendorLeadId() {

		return vendorLeadId;

	}



	public void setVendorLeadId(String vendorLeadId) {

		this.vendorLeadId = vendorLeadId;

	}

	public void setExchSubscriberId(String exchSubscriberId) {
		this.exchSubscriberId = exchSubscriberId;
	}

	public String getExchSubscriberId() {
		return exchSubscriberId;
	}

	
    public double getExchTotalAmtOwed() {
		return exchTotalAmtOwed;
	}

	public void setExchTotalAmtOwed(double exchTotalAmtOwed) {
		this.exchTotalAmtOwed = exchTotalAmtOwed;
	}

	
    public double getExchAPTCAmt() {
		return exchAPTCAmt;
	}

	public void setExchAPTCAmt(double exchAPTCAmt) {
		this.exchAPTCAmt = exchAPTCAmt;
	}

	
    public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	
 
    public int getApplicationSeqId() {
		return applicationSeqId;
	}

	public void setApplicationSeqId(int applicationSeqId) {
		this.applicationSeqId = applicationSeqId;
	}
	
	public String getExchQHPId() {
		return exchQHPId;
	}

	public void setExchQHPId(String exchQHPId) {
		this.exchQHPId = exchQHPId;
	}
	
	public LanguageEnum getApplicationLanguage() {
		return applicationLanguage;
	}

	public void setApplicationLanguage(LanguageEnum applicationLanguage) {
		this.applicationLanguage = applicationLanguage;
	}
	
	public OwnershipEnum getOwnership() {
		return ownership;
	}

	public void setOwnership(OwnershipEnum ownership) {
		this.ownership = ownership;
	}
	
	public String getTransferActivity() {
		return transferActivity;
	}

	public void setTransferActivity(String transferActivity) {
		this.transferActivity = transferActivity;
	}
	
	
	


	public AnswerTypeEnum getIsSubsidyEligible() {
		return isSubsidyEligible;
	}


	public void setIsSubsidyEligible(AnswerTypeEnum isSubsidyEligible) {
		this.isSubsidyEligible = isSubsidyEligible;
	}



	public double getExchTotPremiumAmt() {
		return exchTotPremiumAmt;
	}



	public void setExchTotPremiumAmt(double exchTotPremiumAmt) {
		this.exchTotPremiumAmt = exchTotPremiumAmt;
	}



	public String getHcid() {
		return hCID;
	}



	public void setHcid(String hCID) {
		this.hCID = hCID;
	}

	public String getPrefWrittenLang() {
		return prefWrittenLang;
	}



	public void setPrefWrittenLang(String prefWrittenLang) {
		this.prefWrittenLang = prefWrittenLang;
	}



	public String getPrefSpokenLang() {
		return prefSpokenLang;
	}



	public void setPrefSpokenLang(String prefSpokenLang) {
		this.prefSpokenLang = prefSpokenLang;
	}



	public AnswerTypeEnum getIsUseTobacco() {
		return isUseTobacco;
	}



	public void setIsUseTobacco(AnswerTypeEnum isUseTobacco) {
		this.isUseTobacco = isUseTobacco;
	}



	public AnswerTypeEnum getIsActiveDutyChild() {
		return isActiveDutyChild;
	}



	public void setIsActiveDutyChild(AnswerTypeEnum isActiveDutyChild) {
		this.isActiveDutyChild = isActiveDutyChild;
	}
	
	public String getWlpAssignedConsumerId() {
		return wlpAssignedConsumerId;
	}

	public void setWlpAssignedConsumerId(String wlpAssignedConsumerId) {
		this.wlpAssignedConsumerId = wlpAssignedConsumerId;
	}

	public String getExchAssignedConsumerId() {
		return exchAssignedConsumerId;
	}

	public void setExchAssignedConsumerId(String exchAssignedConsumerId) {
		this.exchAssignedConsumerId = exchAssignedConsumerId;
	}
	
	public String getExchStateCode() {
		return exchStateCode;
	}



	public void setExchStateCode(String exchStateCode) {
		this.exchStateCode = exchStateCode;
	}
	
	public APTCAttestationPerson[] getAptcAttestationPersons() {
		return aptcAttestationPersons;
	}



	public void setAptcAttestationPersons(
			APTCAttestationPerson[] aptcAttestationPersons) {
		this.aptcAttestationPersons = cloneArray(aptcAttestationPersons);
	}
	 
	public String getwLPConsumerId() {
			return wLPConsumerId;
		}



		public void setwLPConsumerId(String wLPConsumerId) {
			this.wLPConsumerId = wLPConsumerId;
		}



		public String getExchConsumerId() {
			return exchConsumerId;
		}



		public void setExchConsumerId(String exchConsumerId) {
			this.exchConsumerId = exchConsumerId;
		}



		public String getSuffix() {
			return suffix;
		}



		public void setSuffix(String suffix) {
			this.suffix = suffix;
		}



		public int getElectedAPTCPercentage() {
			return electedAPTCPercentage;
		}



		public void setElectedAPTCPercentage(int electedAPTCPercentage) {
			this.electedAPTCPercentage = electedAPTCPercentage;
		}



		public double getAppliedAPTCAmount() {
			return appliedAPTCAmount;
		}



		public void setAppliedAPTCAmount(double appliedAPTCAmount) {
			this.appliedAPTCAmount = appliedAPTCAmount;
		}



		public int getRateAreaId() {
			return rateAreaId;
		}



		public void setRateAreaId(int rateAreaId) {
			this.rateAreaId = rateAreaId;
		}



		public AnswerTypeEnum getUnsubscribeReminderEmailFlag() {
			return unsubscribeReminderEmailFlag;
		}



		public void setUnsubscribeReminderEmailFlag(
				AnswerTypeEnum unsubscribeReminderEmailFlag) {
			this.unsubscribeReminderEmailFlag = unsubscribeReminderEmailFlag;
		}



		public String getExchCSRLevel() {
			return exchCSRLevel;
		}



		public void setExchCSRLevel(String exchCSRLevel) {
			this.exchCSRLevel = exchCSRLevel;
		}
		
		public int getExchTransLogId() {
			return exchTransLogId;
		}



	public void setExchTransLogId(int exchTransLogId) {
		this.exchTransLogId = exchTransLogId;
	}

	public double getExchAPTCPct() {
		return exchAPTCPct;
	}

	public void setExchAPTCPct(double exchAPTCPct) {
		this.exchAPTCPct = exchAPTCPct;
	}
	
	public String getExchTransactionId() {
		return exchTransactionId;
	}



	public void setExchTransactionId(String exchTransactionId) {
		this.exchTransactionId = exchTransactionId;
	}
	public AnswerTypeEnum getIsOtherHealthCovDisability() {
		return isOtherHealthCovDisability;
	}



	public void setIsOtherHealthCovDisability(
			AnswerTypeEnum isOtherHealthCovDisability) {
		this.isOtherHealthCovDisability = isOtherHealthCovDisability;
	}



	public AnswerTypeEnum getIsReplCovPolicyInForce() {
		return isReplCovPolicyInForce;
	}



	public void setIsReplCovPolicyInForce(AnswerTypeEnum isReplCovPolicyInForce) {
		this.isReplCovPolicyInForce = isReplCovPolicyInForce;
	}



	public AnswerTypeEnum getIsEligibleForMedicare() {
		return isEligibleForMedicare;
	}



	public void setIsEligibleForMedicare(AnswerTypeEnum isEligibleForMedicare) {
		this.isEligibleForMedicare = isEligibleForMedicare;
	}
	
	public Date getReplCovCancelDate() {
		return replCovCancelDate;
	}



	public void setReplCovCancelDate(Date replCovCancelDate) {
		this.replCovCancelDate = replCovCancelDate;
	}
	
	public AnswerTypeEnum getIsReplCovPolicyInReplace() {
		return isReplCovPolicyInReplace;
	}



	public void setIsReplCovPolicyInReplace(AnswerTypeEnum isReplCovPolicyInReplace) {
		this.isReplCovPolicyInReplace = isReplCovPolicyInReplace;
	}



	public AnswerTypeEnum getIsAgentCanSubmit() {
		return isAgentCanSubmit;
	}



	public void setIsAgentCanSubmit(AnswerTypeEnum isAgentCanSubmit) {
		this.isAgentCanSubmit = isAgentCanSubmit;
	}
	
	public AnswerTypeEnum getIsFullAPTCUsed() {
		return isFullAPTCUsed;
	}



	public void setIsFullAPTCUsed(AnswerTypeEnum isFullAPTCUsed) {
		this.isFullAPTCUsed = isFullAPTCUsed;
	}



	public AnswerTypeEnum getIsApplyLeftOverAPTCToOtherEnrollGroup() {
		return isApplyLeftOverAPTCToOtherEnrollGroup;
	}



	public void setIsApplyLeftOverAPTCToOtherEnrollGroup(
			AnswerTypeEnum isApplyLeftOverAPTCToOtherEnrollGroup) {
		this.isApplyLeftOverAPTCToOtherEnrollGroup = isApplyLeftOverAPTCToOtherEnrollGroup;
	}

	public AnswerTypeEnum getIsPrimaryTaxFiler() {
		return isPrimaryTaxFiler;
	}



	public void setIsPrimaryTaxFiler(AnswerTypeEnum isPrimaryTaxFiler) {
		this.isPrimaryTaxFiler = isPrimaryTaxFiler;
	}



	public String getExchCSRLevelPct() {
		return exchCSRLevelPct;
	}



	public void setExchCSRLevelPct(String exchCSRLevelPct) {
		this.exchCSRLevelPct = exchCSRLevelPct;
	}
	
	public String getCustomerReferenceNo() {
		return customerReferenceNo;
	}



	public void setCustomerReferenceNo(String customerReferenceNo) {
		this.customerReferenceNo = customerReferenceNo;
	}
	
	

	public AnswerTypeEnum getIsIncarceration() {
		return isIncarceration;
	}

	public void setIsIncarceration(AnswerTypeEnum isIncarceration) {
		this.isIncarceration = isIncarceration;
	}
	
	private APTCAttestationPerson[] cloneArray(APTCAttestationPerson[] aptcAttestationPersons){
		APTCAttestationPerson[] nArr = new APTCAttestationPerson[aptcAttestationPersons.length];
		int i=0;
		for(APTCAttestationPerson person:aptcAttestationPersons){
			nArr[i++]=clonePerson(person);
		}
		return nArr;
	}



	private APTCAttestationPerson clonePerson(APTCAttestationPerson person) {
		APTCAttestationPerson per = new APTCAttestationPerson();
		per.setAction(person.getAction());
		per.seteSigFName(person.geteSigFName());
		per.seteSigLName(person.geteSigLName());
		per.seteSigMI(person.geteSigMI());
		per.setFirstName(person.getFirstName());
		per.setId(person.getId());
		per.setIsAPTCAttestation(person.getIsAPTCAttestation());
		per.setIsAPTCReadUnderstand(person.getIsAPTCReadUnderstand());
		per.setLastName(person.getLastName());
		person.setMi(person.getMi());
		return per;
		
	}

	public void setAccessControlListLength(int accessControlListLength) {
		this.accessControlListLength = accessControlListLength;
	}

	public void setApplicantLength(int applicantLength) {
		this.applicantLength = applicantLength;
	}

	public void setQuotedPlansLength(int quotedPlansLength) {
		this.quotedPlansLength = quotedPlansLength;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
}
