package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class Messages implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = -7940097138447986205L;	private  Message[] message;	private int messageLength;

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link Message }
     *     
     */
    public Message[] getMessage() {
        if (this.message == null) {
            return new Message[ 0 ] ;
        }
        Message[] retVal = new Message[this.message.length] ;
        System.arraycopy(this.message, 0, retVal, 0, this.message.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link Message }
     *     
     */
    public Message getMessage(int idx) {
        if (this.message == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.message[idx];
    }

    public int getMessageLength() {
        if (this.message == null) {
            return  0;
        }
        return this.message.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link Message }
     *     
     */
    public void setMessage(Message[] values) {
        int len = values.length;
        this.message = ((Message[]) new Message[len] );
        for (int i = 0; (i<len); i ++) {
            this.message[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link Message }
     *     
     */
    public Message setMessage(int idx, Message value) {
        return this.message[idx] = value;
    }	public void setMessageLength(int messageLength) {		this.messageLength = messageLength;	}

}
