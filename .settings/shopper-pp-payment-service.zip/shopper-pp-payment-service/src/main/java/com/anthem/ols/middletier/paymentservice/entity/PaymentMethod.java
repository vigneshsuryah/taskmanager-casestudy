package com.anthem.ols.middletier.paymentservice.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentMethod {

	@Field("payment_type")
	private String paymentType;
	@Field("payment_sub_type")
	private String paymentSubType;
	@Field("credit_card_number")
	private String creditCardNumber;
	@Field("credit_card_number_ui")
	private String creditCardNumberUI;
	@Field("credit_card_first_six")
	private String creditCardFirstSix;
	@Field("credit_card_last_four")
	private String creditCardLastFour;
	@Field("token_id")
	private String tokenId;
	@Field("cc_authorization_number")
	private String ccAuthorizationNumber;
	@Field("interchange_qualification_code")
	private String interchangeQualificationCode;
	@Field("bank_routing_number")
	private String bankRoutingnumber;
	@Field("bank_account_number")
	private String bankAccountNumber;
	@Field("name_on_funding_account")
	private String nameOnFundingAccount;
	@Field("fund_account_owner_full_address")
	private FundAccountOwnerFullAddress fundAccountOwnerFullAddress;
	@Field("action_code")
	private String actionCode;
	@Field("cc_exp_date")
	private String ccExpDate;
	@Field("response_reason_code")
	private String responseReasonCode;
	@Field("token_response_date")
	private String tokenDate;
	@Field("is_level3")
	private String isLevelThree;
	@Field("AVSAAV")
	private String aVSAAV;
	// chase certification changes
	@Field("messageType")
	private String messageType;
	@Field("originalTransactionAmount")
	private String originalTransactionAmount;
	@Field("recordType")
	private String recordType;
	@Field("submittedTransactionID")
	private String submittedTransactionID;
	@Field("responseTransactionID")
	private String responseTransactionID;
	@Field("storedCredentialFlag")
	private String storedCredentialFlag;
	@Field("chase_reject_code")
	private String chaseRejectCode;
	@Field("chase_reject_message")
	private String chaseRejectMessage;
	@Field("key_id")
	private String keyId;
	@Field("phase_id")
	private String phaseId;
	@Field("integrity_check")
	private String integrityCheck;

}
