package com.anthem.ols.middletier.paymentservice.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionStatus {

	@Field("echofailed")
	private TransactionStatus echofailed;

	@Field("ediaccepted")
	private TransactionStatus ediaccepted;

	@Field("submitted")
	private TransactionStatus submitted;

	@Field("accepted")
	private TransactionStatus accepted;

	@Field("completed")
	private PaymentCompleted completed;

	@Field("trigger")
	private PaymentTrigger[] trigger;

}
