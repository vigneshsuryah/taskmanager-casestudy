package com.anthem.ols.middletier.paymentservice.rest.request;import com.anthem.ols.middletier.paymentservice.rest.bo.Application;
public class GetPaymentRequestRS extends BaseRequestRS{
    /**	 * 	 */	private static final long serialVersionUID = 663432285260240191L;	private  String acn;
    private  String partnerId;        private  Application application;
    public String getAcn() {        return acn;    }
    public void setAcn(String value) {        this.acn = value;    }        public String getPartnerId() {        return partnerId;    }
    public void setPartnerId(String value) {        this.partnerId = value;    }	public Application getApplication() {		return application;	}	public void setApplication(Application application) {		this.application = application;	}}
