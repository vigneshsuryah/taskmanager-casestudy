package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum MbuTypeEnum {
    INDIVIDUAL,
    SENIOR,
    NONE;

    public String value() {        return name();    }
    public static MbuTypeEnum fromValue(String v) {        return valueOf(v);    }}
