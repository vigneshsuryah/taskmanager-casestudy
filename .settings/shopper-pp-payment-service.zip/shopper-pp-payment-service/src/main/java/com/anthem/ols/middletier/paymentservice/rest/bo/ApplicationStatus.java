package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class ApplicationStatus implements Serializable{	/**	 * 	 */	private static final long serialVersionUID = -8403360247964779440L;	private  ApplicationStatusEnum applicationStatus;
    private  String statusReason;    private  Date statusChangeDate;	/**
     * Gets the value of the applicationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationStatusEnum }
     *     
     */
    public ApplicationStatusEnum getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Sets the value of the applicationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationStatusEnum }
     *     
     */
    public void setApplicationStatus(ApplicationStatusEnum value) {
        this.applicationStatus = value;
    }

    /**
     * Gets the value of the statusReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusReason() {
        return statusReason;
    }

    /**
     * Sets the value of the statusReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusReason(String value) {
        this.statusReason = value;
    }        public Date getStatusChangeDate() {		return statusChangeDate;	}	public void setStatusChangeDate(Date statusChangeDate) {		this.statusChangeDate = statusChangeDate;	}

}
