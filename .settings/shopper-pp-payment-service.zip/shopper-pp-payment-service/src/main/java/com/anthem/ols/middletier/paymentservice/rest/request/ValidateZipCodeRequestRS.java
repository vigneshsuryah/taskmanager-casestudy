package com.anthem.ols.middletier.paymentservice.rest.request;


public class ValidateZipCodeRequestRS extends BaseRequestRS {

	private static final long serialVersionUID = 1L;
	private String zipCode;
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
}
