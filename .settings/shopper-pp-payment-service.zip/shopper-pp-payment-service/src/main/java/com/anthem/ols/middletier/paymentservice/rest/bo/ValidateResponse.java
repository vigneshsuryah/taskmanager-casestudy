 package com.anthem.ols.middletier.paymentservice.rest.bo;
 
 
 
 
 public class ValidateResponse 
 {
 
   private ZipCode zipCode;
 
   private ResponseMessage responseMessage;

	public ZipCode getZipCode() {
		return zipCode;
	}
	
	public void setZipCode(ZipCode zipCode) {
		this.zipCode = zipCode;
	}
	
	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}
	
	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}
   
   
 
  
 }

