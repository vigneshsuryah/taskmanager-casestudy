package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum AnswerTypeEnum
{
	NONE,
	YES,
	NO,
	ANSWERLATER;
	
	public String value() {
        return name();
    }

    public static AnswerTypeEnum fromValue(String v) {
        return valueOf(v);
    }
}