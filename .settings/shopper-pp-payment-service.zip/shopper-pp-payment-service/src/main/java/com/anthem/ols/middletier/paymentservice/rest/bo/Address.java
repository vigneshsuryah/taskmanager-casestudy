
package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Address implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5142680637159662615L;

	private int id;

	private String addressLine1;

	private String addressLine2;
	
	private String city;

	private String county;

	private String state;

	private String postalCode;

	private AddressTypeEnum addressType;

	private String careOf;

	private ActionTypeEnum action;

	private String personalMailBoxNo;

	private String countyCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public AddressTypeEnum getAddressType() {
		return addressType;
	}

	public void setAddressType(AddressTypeEnum addressType) {
		this.addressType = addressType;
	}

	public String getCareOf() {
		return careOf;
	}

	public void setCareOf(String careOf) {
		this.careOf = careOf;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getPersonalMailBoxNo() {
		return personalMailBoxNo;
	}

	public void setPersonalMailBoxNo(String personalMailBoxNo) {
		this.personalMailBoxNo = personalMailBoxNo;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

}