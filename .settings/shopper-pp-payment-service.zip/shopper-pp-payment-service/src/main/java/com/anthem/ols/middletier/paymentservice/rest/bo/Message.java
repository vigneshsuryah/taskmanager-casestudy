package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class Message implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 5157165367880939231L;	private  String messageNo;
    private  String message;
    private  MessageTypeEnum messageType;
    /**
     * Gets the value of the messageNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageNo() {
        return messageNo;
    }

    /**
     * Sets the value of the messageNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageNo(String value) {
        this.messageNo = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the messageType property.
     * 
     * @return
     *     possible object is
     *     {@link MessageTypeEnum }
     *     
     */
    public MessageTypeEnum getMessageType() {
        return messageType;
    }

    /**
     * Sets the value of the messageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageTypeEnum }
     *     
     */
    public void setMessageType(MessageTypeEnum value) {
        this.messageType = value;
    }

}
