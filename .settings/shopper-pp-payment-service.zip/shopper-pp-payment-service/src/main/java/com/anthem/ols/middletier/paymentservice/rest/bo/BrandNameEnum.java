package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum BrandNameEnum {
    BCC,
    BCBSGA,
    ANTHEM,
    EMPBC,
    EMPBCBS,
    BCBSKS,
    BCBSKC,
    UNICARE,
    CFBCBS;

    public String value() {
        return name();
    }

    public static BrandNameEnum fromValue(String v) {
        return valueOf(v);
    }

}
