package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;

public class SMCBaseRequest implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 4311300198052308500L;
	
	private String acn;
	private String requestingSystem;
	
	public String getAcn() {
		return acn;
	}
	public void setAcn(String acn) {
		this.acn = acn;
	}
	public String getRequestingSystem() {
		return requestingSystem;
	}
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
}
