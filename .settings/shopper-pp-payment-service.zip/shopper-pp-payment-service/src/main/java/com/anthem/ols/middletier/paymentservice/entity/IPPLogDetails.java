package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@Document(collection = "restlog")
public class IPPLogDetails {
	
	@Id
	public ObjectId _id;
	
	@Field("transId")
	private int transId;
	
	@Field("exchStateCode")
	private String exchStateCode;
	
	@Field("wlpConsumerId")
	private String wlpConsumerId;
	
	@Field("requestXML")
	private String requestXML;
	
	@Field("responseXML")
	private String responseXML;
	
	@Field("requestTS")
	private Date requestTS;
	
	@Field("responseTS")
	private Date responseTS;
	
	@Field("isBusinessFault")
	private String isBusinessFault;
	
	@Field("isSystemFault")
	private String isSystemFault;
	
	@Field("updateDt")
	private Date updateDt;
	
	@Field("createDt")
	private Date createDt;
	
	@Field("updateId")
	private String updateId;
	
	@Field("createId")
	private String createId;
	
	@Field("opName")
	private String opName;
	
	@Field("exchConsumerId")
	private String exchConsumerId;
	
	@Field("requestingSystem")
	private String requestingSystem;
	
	@Field("acn")
	private String acn;
	
}
