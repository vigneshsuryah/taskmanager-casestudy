package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@Document(collection = "restlog")
public class IPPLogDetails {
	
	@Id
	public ObjectId _id;
	
	@Field("transId")
	private int transId;
	
	@Field("opName")
	private String opName;
	
	@Field("requestingSystem")
	private String requestingSystem;
	
	@Field("requestXML")
	private String requestXML;
	
	@Field("responseXML")
	private String responseXML;
	
	@Field("requestTS")
	private Date requestTS;
	
	@Field("responseTS")
	private Date responseTS;
	
	@Field("createDt")
	private Date createDt;
	
	@Field("createId")
	private String createId;
	
	@Field("updateDt")
	private Date updateDt;
	
	@Field("updateId")
	private String updateId;
	
	@Field("exchStateCode")
	private String exchStateCode;
	
	@Field("exchConsumerId")
	private String exchConsumerId;
	

}
