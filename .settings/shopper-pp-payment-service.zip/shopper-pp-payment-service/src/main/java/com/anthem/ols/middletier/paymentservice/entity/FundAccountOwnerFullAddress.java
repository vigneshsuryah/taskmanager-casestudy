package com.anthem.ols.middletier.paymentservice.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FundAccountOwnerFullAddress {

	@Field("address1")
	private String address1;
	@Field("address2")
	private String address2;
	@Field("city")
	private String city;
	@Field("state")
	private String state;
	@Field("zipcode")
	private String zipcode;
	@Field("county")
	private String county;
	@Field("countyCode")
	private String countyCode;

}
