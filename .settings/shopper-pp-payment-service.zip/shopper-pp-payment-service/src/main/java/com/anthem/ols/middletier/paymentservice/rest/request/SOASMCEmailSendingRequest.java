package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;

public class SOASMCEmailSendingRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private SMCTo To;

	public SMCTo getTo() {
		return To;
	}

	public void setTo(SMCTo to) {
		To = to;
	}
}
