package com.anthem.ols.middletier.paymentservice.rest.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SetExchangeTransLogResponse {
	
	private int transId;

}
