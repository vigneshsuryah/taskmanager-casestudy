package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.List;

public class BusinessError implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5879595143497905600L;
	private List<BusinessErrorLine> error;

	public List<BusinessErrorLine> getError() {
		return error;
	}

	public void setError(List<BusinessErrorLine> error) {
		this.error = error;
	}
	
}
