package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnthemBankDetails {

	@Field("anthem_deposting_bank")
	private String anthemDepostingBank;
	@Field("business_unit")
	private String businessUnit;
	@Field("anthem_bank_account")
	private String anthemBankAccount;
	@Field("transaction_division")
	private String transactionDivision;
	@Field("chase_batch_submission")
	private String chaseBatchSubmission;
	@Field("chase_record_Reference")
	private String chaseRecordReference;
	@Field("pay_date")
	private Date payDate;
	@Field("other_chase_fields")
	private String otherChaseFields;

}
