package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ApplicantEligibility implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -2570326229968586433L;

	private  int id;

    private  ActionTypeEnum action;

	private  int exchRelationshipCode;

	private  Date eligibilityChangeEffDate;

	private  AnswerTypeEnum isMedicaidEligible;

	private  AnswerTypeEnum isCHIPEligible;

	private  AnswerTypeEnum isQHPEligible;

	private  Date qhpEligStartDate;
	
	private  Date qhpEligEndDate;
	
	private  AnswerTypeEnum isAPTCEligible;

	private  Date aptcEligStartDate;

	private  Date aptcEligEndDate;
	
    private  double monthlyAPTCAmt;
	
	private  AnswerTypeEnum isCSREligible;

	private  String csrLevel;
	
	private  String qhpEligStatusChange;
	
	private  String aptcEligStatusChange;
	
	private  String csrEligStatusChange;
	
	private  AnswerTypeEnum isIEPAEPEligible;
	
	private  String iepAEPType;

 	private  Date iepAEPEarliestQHPEffDate;

 	private  Date iepAEPLatestQHPEffDate;
	
    public Date getIepAEPEarliestQHPEffDate() {
		return iepAEPEarliestQHPEffDate;
	}

	public void setIepAEPEarliestQHPEffDate(
			Date iepAEPEarliestQHPEffDate) {
		this.iepAEPEarliestQHPEffDate = iepAEPEarliestQHPEffDate;
	}

	public Date getIepAEPLatestQHPEffDate() {
		return iepAEPLatestQHPEffDate;
	}

	public void setIepAEPLatestQHPEffDate(
			Date iepAEPLatestQHPEffDate) {
		this.iepAEPLatestQHPEffDate = iepAEPLatestQHPEffDate;
	}

	
	private  AnswerTypeEnum isSEPEligible;
	
	private  String sepEligReason;

 	private  Date sepStartDate;
 
 	private  Date sepEndDate;
 
	
	public Date getSepStartDate() {
		return sepStartDate;
	}

	public void setSepStartDate(Date sepStartDate) {
		this.sepStartDate = sepStartDate;
	}

	public Date getSepEndDate() {
		return sepEndDate;
	}

	public void setSepEndDate(Date sepEndDate) {
		this.sepEndDate = sepEndDate;
	}


	private  Date activityDate;
	
	private  String qHPEligStatusCode;
	
	private  String aPTCEligStatusCode;
	
	private  String sEPEligStatusCode;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public int getExchRelationshipCode() {
		return exchRelationshipCode;
	}

	public void setExchRelationshipCode(int exchRelationshipCode) {
		this.exchRelationshipCode = exchRelationshipCode;
	}

	public Date getEligibilityChangeEffDate() {
		return eligibilityChangeEffDate;
	}

	public void setEligibilityChangeEffDate(
			Date eligibilityChangeEffDate) {
		this.eligibilityChangeEffDate = eligibilityChangeEffDate;
	}

	public AnswerTypeEnum getIsMedicaidEligible() {
		return isMedicaidEligible;
	}

	public void setIsMedicaidEligible(AnswerTypeEnum isMedicaidEligible) {
		this.isMedicaidEligible = isMedicaidEligible;
	}

	public AnswerTypeEnum getIsCHIPEligible() {
		return isCHIPEligible;
	}

	public void setIsCHIPEligible(AnswerTypeEnum isCHIPEligible) {
		this.isCHIPEligible = isCHIPEligible;
	}



	public AnswerTypeEnum getIsQHPEligible() {
		return isQHPEligible;
	}

	public void setIsQHPEligible(AnswerTypeEnum isQHPEligible) {
		this.isQHPEligible = isQHPEligible;
	}

	public Date getQhpEligStartDate() {
		return qhpEligStartDate;
	}

	public void setQhpEligStartDate(Date qhpEligStartDate) {
		this.qhpEligStartDate = qhpEligStartDate;
	}

	public Date getQhpEligEndDate() {
		return qhpEligEndDate;
	}

	public void setQhpEligEndDate(Date qhpEligEndDate) {
		this.qhpEligEndDate = qhpEligEndDate;
	}

	public AnswerTypeEnum getIsAPTCEligible() {
		return isAPTCEligible;
	}

	public void setIsAPTCEligible(AnswerTypeEnum isAPTCEligible) {
		this.isAPTCEligible = isAPTCEligible;
	}

	public double getMonthlyAPTCAmt() {
		return monthlyAPTCAmt;
	}

	public void setMonthlyAPTCAmt(double monthlyAPTCAmt) {
		this.monthlyAPTCAmt = monthlyAPTCAmt;
	}

	public AnswerTypeEnum getIsCSREligible() {
		return isCSREligible;
	}

	public void setIsCSREligible(AnswerTypeEnum isCSREligible) {
		this.isCSREligible = isCSREligible;
	}

	public String getCsrLevel() {
		return csrLevel;
	}

	public void setCsrLevel(String csrLevel) {
		this.csrLevel = csrLevel;
	}

	public String getQhpEligStatusChange() {
		return qhpEligStatusChange;
	}

	public void setQhpEligStatusChange(String qhpEligStatusChange) {
		this.qhpEligStatusChange = qhpEligStatusChange;
	}

	public String getAptcEligStatusChange() {
		return aptcEligStatusChange;
	}

	public void setAptcEligStatusChange(String aptcEligStatusChange) {
		this.aptcEligStatusChange = aptcEligStatusChange;
	}

	public String getCsrEligStatusChange() {
		return csrEligStatusChange;
	}

	public void setCsrEligStatusChange(String csrEligStatusChange) {
		this.csrEligStatusChange = csrEligStatusChange;
	}

	public AnswerTypeEnum getIsIEPAEPEligible() {
		return isIEPAEPEligible;
	}

	public void setIsIEPAEPEligible(AnswerTypeEnum isIEPAEPEligible) {
		this.isIEPAEPEligible = isIEPAEPEligible;
	}

	public String getIepAEPType() {
		return iepAEPType;
	}

	public void setIepAEPType(String iepAEPType) {
		this.iepAEPType = iepAEPType;
	}

	public AnswerTypeEnum getIsSEPEligible() {
		return isSEPEligible;
	}

	public void setIsSEPEligible(AnswerTypeEnum isSEPEligible) {
		this.isSEPEligible = isSEPEligible;
	}

	public String getSepEligReason() {
		return sepEligReason;
	}

	public void setSepEligReason(String sepEligReason) {
		this.sepEligReason = sepEligReason;
	}

	public Date getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(Date activityDate) {
		this.activityDate = activityDate;
	}

	public String getQHPEligStatusCode() {
		return qHPEligStatusCode;
	}

	public void setQHPEligStatusCode(String eligStatusCode) {
		qHPEligStatusCode = eligStatusCode;
	}

	public String getAPTCEligStatusCode() {
		return aPTCEligStatusCode;
	}

	public void setAPTCEligStatusCode(String eligStatusCode) {
		aPTCEligStatusCode = eligStatusCode;
	}

	public String getSEPEligStatusCode() {
		return sEPEligStatusCode;
	}

	public void setSEPEligStatusCode(String eligStatusCode) {
		sEPEligStatusCode = eligStatusCode;
	}

	public Date getAptcEligStartDate() {
		return aptcEligStartDate;
	}

	public void setAptcEligStartDate(Date aptcEligStartDate) {
		this.aptcEligStartDate = aptcEligStartDate;
	}

	public Date getAptcEligEndDate() {
		return aptcEligEndDate;
	}

	public void setAptcEligEndDate(Date aptcEligEndDate) {
		this.aptcEligEndDate = aptcEligEndDate;
	}
	
 

}
