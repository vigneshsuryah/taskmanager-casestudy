package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum PaymentTypeEnum {

	NONE,
	AUTOBANKDRAFT,
	CREDITCARD,
	ECHECK,
	BILLING,
	CHECKING,
	SAVINGS,
	NOINITIALPAYMENT,
	DEBITCARD;
	
	public String value() {
		return name();
	}

	public static PaymentTypeEnum fromValue(String v) {
		return valueOf(v);
	}
}