package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum ProductTypeEnum
{
	
	DRUG,
	LIFE,
	MEDICAL,
	CIA,
	VISION,
	DENTAL;
	
	public String value() {
		return name();
	}

	public static ProductTypeEnum fromValue(String v) {
		return valueOf(v);
	}
}