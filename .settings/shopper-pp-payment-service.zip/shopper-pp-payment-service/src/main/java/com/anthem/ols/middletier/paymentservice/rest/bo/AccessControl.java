package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class AccessControl implements Serializable{
	/**	 * 	 */	private static final long serialVersionUID = 8827262076007011277L;	private  AccessTypeEnum accessType;
    private  Shopper user;
    /**
     * Gets the value of the accessType property.
     * 
     * @return
     *     possible object is
     *     {@link AccessTypeEnum }
     *     
     */
    public AccessTypeEnum getAccessType() {
        return accessType;
    }

    /**
     * Sets the value of the accessType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessTypeEnum }
     *     
     */
    public void setAccessType(AccessTypeEnum value) {
        this.accessType = value;
    }

    /**
     * Gets the value of the user property.
     * 
     * @return
     *     possible object is
     *     {@link Shopper }
     *     
     */
    public Shopper getUser() {
        return user;
    }

    /**
     * Sets the value of the user property.
     * 
     * @param value
     *     allowed object is
     *     {@link Shopper }
     *     
     */
    public void setUser(Shopper value) {
        this.user = value;
    }

}
