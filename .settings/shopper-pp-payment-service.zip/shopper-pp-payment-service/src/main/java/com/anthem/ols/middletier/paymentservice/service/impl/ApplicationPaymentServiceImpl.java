package com.anthem.ols.middletier.paymentservice.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.anthem.ols.middletier.paymentservice.entity.IPPLogDetails;
import com.anthem.ols.middletier.paymentservice.entity.CancelDetails;
import com.anthem.ols.middletier.paymentservice.entity.PayerId;
import com.anthem.ols.middletier.paymentservice.entity.PaymentAppSource;
import com.anthem.ols.middletier.paymentservice.entity.PaymentDetails;
import com.anthem.ols.middletier.paymentservice.entity.Transaction;
import com.anthem.ols.middletier.paymentservice.entity.ZipCodeDetails;
import com.anthem.ols.middletier.paymentservice.exception.BusinessException;
import com.anthem.ols.middletier.paymentservice.helper.SetApplicationHelper;
import com.anthem.ols.middletier.paymentservice.helper.SetPaymentHelper;
import com.anthem.ols.middletier.paymentservice.repository.ipay.PaymentAppSourceRepository;
import com.anthem.ols.middletier.paymentservice.repository.ipay.PaymentDetailsRepository;
import com.anthem.ols.middletier.paymentservice.repository.ipay.ZipCodeRepository;
import com.anthem.ols.middletier.paymentservice.repository.ipplog.IPPLogRepository;
import com.anthem.ols.middletier.paymentservice.rest.bo.AccessControl;
import com.anthem.ols.middletier.paymentservice.rest.bo.Agent;
import com.anthem.ols.middletier.paymentservice.rest.bo.AgentTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Application;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationOriginTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Plan;
import com.anthem.ols.middletier.paymentservice.rest.bo.Shopper;
import com.anthem.ols.middletier.paymentservice.rest.bo.ShopperRoleEnum;
import com.anthem.ols.middletier.paymentservice.rest.request.CancelPaymentsRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.bo.ValidateResponse;
import com.anthem.ols.middletier.paymentservice.rest.request.GetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogRequest;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogResponse;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.CancelPaymentsResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.request.ValidateZipCodeRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.ValidateZipCodeResponseRS;
import com.anthem.ols.middletier.paymentservice.service.ApplicationPaymentService;
import com.anthem.ols.middletier.paymentservice.utils.IppServiceConstants;
import com.anthem.ols.middletier.paymentservice.utils.ServiceUtils;


@Service
public class ApplicationPaymentServiceImpl implements ApplicationPaymentService, IppServiceConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationPaymentServiceImpl.class);

	@Autowired
	private PaymentDetailsRepository paymentDetailsRepository;

	@Autowired
	private ServiceUtils serviceUtils;

	@Autowired
	private SetPaymentHelper setPaymentHelper;

	@Autowired
	private SetApplicationHelper setApplicationHelper;

	@Autowired
	private MongoTemplate iPayDbTemplate;

	@Autowired
	private PaymentAppSourceRepository paymentAppSourceRepository;

	@Autowired
	private ZipCodeRepository zipCodeRepository;
	
	@Autowired
	private IPPLogRepository ippLogRepository;

	@Override
	public GetApplicationResponseRS getApplication(GetApplicationRequestRS request) throws BusinessException {
		GetApplicationResponseRS response = new GetApplicationResponseRS();
		try {
			if (null != request.getAcn()) {
				PaymentDetails payment = paymentDetailsRepository.getPaymentForAcn(request.getAcn());
				if (null != payment) {
					Application appObj = setApplicationHelper.convertPayDetailsToApplication(payment);
					response.setApplication(appObj);
				}
			}
		} catch (Exception e) {

		}
		return response;
	}

	@Override
	public SetApplicationResponseRS setApplication(SetApplicationRequestRS request) throws BusinessException {

		SetApplicationResponseRS response = null;
		try {

			String acn = null;
			PaymentDetails payment = null;
			// Throws BussinessException when the setApplication is called and the user is
			// not the owner of the application.
			if ((null != request.getApplication().getAcn() && !request.getApplication().getAcn().isEmpty())
					&& null != request.getUser().getUserId()) {
				payment = paymentDetailsRepository.getPaymentForAcn(request.getApplication().getAcn());
				if (!serviceUtils.checkApplicationOwner(payment, request.getUser().getUserId())) {
					throw new BusinessException(
							"Cannot update the Application, Requested user is not the OWNER of this application");
				}
			}

			if (request.getApplication() != null
					&& request.getApplication().getApplicationType() != ApplicationTypeEnum.PAYMENT) {
				throw new BusinessException("Cannot update the Application, The Application Type is not PAYMENT");
			}
			// UI is mapped to ExchAssignedConsumerId- Need to remove after UI corrected the
			// mapping

			if (request.getApplication() != null && request.getApplication().getExchAssignedConsumerId() != null) {
				request.getApplication().setExchConsumerId(request.getApplication().getExchAssignedConsumerId());
			}
			String applicationId = request.getApplication().getExchConsumerId();
			if (request.getApplication().getAcn() == null && request.getUser().getUserId() != null
					&& ("CAEXCH".equalsIgnoreCase(request.getPartnerId())
							|| "HIP".equalsIgnoreCase(request.getPartnerId())
							|| "KYH".equalsIgnoreCase(request.getPartnerId())
							|| "KYHCSR".equalsIgnoreCase(request.getPartnerId()))
					&& applicationId != null) {
				PaymentDetails paymentDet = paymentDetailsRepository.getPaymentForExchConsumerId(applicationId);
				String paymentTrackingId = "";
				if (null != paymentDet && null != paymentDet.getTransactions()
						&& paymentDet.getTransactions().length > 0) {
					for (Transaction transaction : paymentDet.getTransactions()) {
						if (paymentTrackingId.isEmpty()) {
							paymentTrackingId = transaction.getAnthemOrderId();
						} else {
							paymentTrackingId = paymentTrackingId + "," + transaction.getAnthemOrderId();
						}
					}
				}

				if (null != paymentDet && null != paymentTrackingId) {
					String language = payment.getLangPref();
					String paymentExceptionMsg = "";
					if (null != language && language.equalsIgnoreCase("SPANISH")) {
						paymentExceptionMsg = "DUPLICATE:Nuestros archivos indican que ya pagaste tu primera prima. El n�mero de referencia de tu pago es "
								+ paymentTrackingId
								+ ".  Tu solicitud est� siendo procesada y recibir�s tus tarjetas de identificaci�n en el correo una vez que se complete tu inscripci�n.";
					} else {
						paymentExceptionMsg = "DUPLICATE:Our records indicate you already paid your initial premium.  Your Payment Reference ID number is "
								+ paymentTrackingId
								+ ".  Your application is being processed and you will receive identification cards in the mail once your enrollment is complete.";
					}
					// DO GetApplication
					if (null != payment.getAcn()) {

						// Existing Application
						response = new SetApplicationResponseRS();

						if (null != payment) {
							Application appObj = setApplicationHelper.convertPayDetailsToApplication(paymentDet);
							if (appObj.getPaymentSelection() != null) {
								appObj.getPaymentSelection().setPaymentExceptionMsg(paymentExceptionMsg);
							}
							response.setApplication(appObj);
						}

						return response;
					}

				}
			}

			// Generate ACN if it is not passed in the request -OR- not found in Db
			if (request.getApplication().getAcn() == null || request.getApplication().getAcn().equals("")) {

				request.getApplication().setAcn(serviceUtils.generateACN());
			}

			// Throws BusinessException when the SetApplication is called and the
			// application status is not INPROGRESS OR SUBMITREJECT.
			if (serviceUtils.checkApplicationStatus(payment)) {
				throw new BusinessException("Cannot update the Application which is not in INPROGRESS status");
			}

			if (acn == null) {
				// New Application
				response = new SetApplicationResponseRS();
				String operationName = "setApplication";
				Application application = request.getApplication();
				if ("KYH".equalsIgnoreCase(request.getPartnerId())
						|| "KYHCSR".equalsIgnoreCase(request.getPartnerId())) {
					operationName = "setApplicationKYH";
				} else {
				}
				// Validate / Prevent applications with multiple applicants with same
				// relationship type
				// (APPLICANT/SPOUSE/DOMESTICPARTNER).
				setApplicationHelper.validateApplicantRelationShip(application);

				PaymentDetails savedObj = persistPayDetailsAppData(request, application);
				if (null != savedObj) {
					Application appObj = setApplicationHelper.convertPayDetailsToApplication(savedObj);
					response.setApplication(appObj);
				}
			}

		} catch (Exception e) {

		}
		return null;
	}

	private PaymentDetails persistPayDetailsAppData(SetApplicationRequestRS request, Application application)
			throws BusinessException {
		String userId = request.getUser().getUserId();
		String reqAcn = application.getAcn();
		String partnerId = null;
		if (request.getPartnerId() == null) {
			throw new BusinessException("Partner Id cannot be empty");
		} else {
			partnerId = request.getPartnerId();
		}

		if (!serviceUtils.validatePartnerId(partnerId)) {
			LOGGER.error("persistPayDetailsAppData -- Invalid partner");
			throw new BusinessException("Invalid partner");
		}

		String appSource = application.getAppSource();
		String transferFlag = "N";
		if (application.getAppSource() == null || application.getAppSource().equalsIgnoreCase("")) {
			appSource = getAppSource(application, transferFlag, partnerId, request.getUser());
		}
		PaymentDetails paymentDetail = new PaymentDetails();
		Transaction[] transactions = null;
		if (null != application.getApplicant() && application.getApplicant().length > 0
				&& null != application.getApplicant()[0].getPlanSelection()
				&& application.getApplicant()[0].getPlanSelection().getPlanLength() > 0) {
			transactions = new Transaction[application.getApplicant()[0].getPlanSelection().getPlanLength()];
		}
		paymentDetail.setAcn(reqAcn);
		paymentDetail.setCreatorRole(request.getUser().getShopperRole().name());
		if (null != application.getAccessControlList() && application.getAccessControlList().length > 0) {
			AccessControl accessControl = application.getAccessControlList()[0];
			paymentDetail.setAccessType(accessControl.getAccessType().name());
			if (null != accessControl.getUser()) {
				paymentDetail.setUserId(accessControl.getUser().getUserId());
				paymentDetail.setUserRole(accessControl.getUser().getShopperRole().name());
			}
		}
		// paymentDetail.setAnthemOrderId(generateOrderId(""));
		if (null != application.getApplicant() && application.getApplicant().length > 0) {
			if (null != application.getApplicant()[0].getDemographic()) {
				paymentDetail.setApplicantFirstName(application.getApplicant()[0].getDemographic().getFirstName());
				paymentDetail.setApplicantLastName(application.getApplicant()[0].getDemographic().getLastName());
				paymentDetail.setApplicantMiddleName(application.getApplicant()[0].getDemographic().getMi());
				paymentDetail.setDateOfBirth(serviceUtils.convertDateToString(
						application.getApplicant()[0].getDemographic().getDateOfBirth(), "MM-dd-yyyy"));
				paymentDetail.setMemberCode(Integer.toString(application.getApplicant()[0].getMemberCode()));
				paymentDetail
						.setRelationship(application.getApplicant()[0].getDemographic().getRelationshipType().name());
			}
			if (null != application.getApplicant()[0].getPlanSelection()
					&& application.getApplicant()[0].getPlanSelection().getPlanLength() > 0) {
				int count = 0;
				for (Plan plan : application.getApplicant()[0].getPlanSelection().getPlan()) {
					Transaction transaction = new Transaction();
					transaction.setPlanId(plan.getPlanId());
					transaction.setPlanName(plan.getPlanName());
					transaction.setPlanType(plan.getPlanType().name());
					transaction.setProductType(plan.getProductType().name());
					transaction.setContractCode(plan.getContractCode());
					if ("CAEXCH".equals(request.getPartnerId()) && null == application.getExchQHPId()) {
						transaction.setQhpid(plan.getPlanId());
					}
					transaction.setQhpvariation(plan.getqHPVariation());
					transaction.setEbhflag(plan.geteBHFlag().name());
					transaction.setRatingServiceArea(plan.getRatingServiceArea());
					transaction.setCompanyDescr(plan.getCompanyDescr());
					transaction.setEreAppliedAPTC(plan.getEreAppliedAPTC());
					transaction.setCreatedDt(serviceUtils.mongoDateConverter(new Date()));
					transaction.setCreatedId(userId);
					transactions[count] = transaction;
				}
				paymentDetail.setTransactions(transactions);
			}
		}

		if (application.getApplicationType() == null || application.getApplicationType().toString().equals("")) {
			paymentDetail.setApplicationType("OFFEXCHANGE");
		} else {
			paymentDetail.setApplicationType(application.getApplicationType().name());
		}
		paymentDetail.setApplicationVersion(application.getApplicationVersion());
		paymentDetail.setAppSource(appSource);
		paymentDetail.setBrandName(application.getBrandName().name());
		paymentDetail.setCreatorRole(request.getUser().getShopperRole().name());
		paymentDetail.setPartnerId(partnerId);
		paymentDetail.setLangPref("ENGLISH");
		paymentDetail.setState(application.getState());
		paymentDetail.setReqEffDate(application.getReqEffDate());
		paymentDetail.setSystem("");
		paymentDetail.setLegalEntity("");
		paymentDetail.setMarketSegment("");
		paymentDetail.setDivisionCode("");
		paymentDetail.setTransactionDivisionCode("");
		// paymentDetail.setSettleAmount(application.getPremiumAmt());
		paymentDetail.setExchSubscriberId(application.getExchSubscriberId());
		paymentDetail.setExchaptcAmt(Double.toString(application.getExchAPTCAmt()));
		paymentDetail.setIpAddress(application.getIpAddress());
		paymentDetail.setExchTransactionId(application.getExchTransactionId());
		paymentDetail.setExchConsumerId(application.getExchConsumerId());
		paymentDetail.setWlpConsumerId(application.getwLPConsumerId());
		if (null != application.getPaymentSelection()) {
			PayerId payer = new PayerId();
			if (null != application.getPaymentSelection().getCsrIdentifier()
					&& !application.getPaymentSelection().getCsrIdentifier().isEmpty()) {
				payer.setId(application.getPaymentSelection().getCsrIdentifier());
				payer.setType("CSR");
			} else {
				payer.setId("PPORT");
				payer.setType("PPORT");
			}
			paymentDetail.setPayerId(payer);
		}
		PaymentDetails savedObj = paymentDetailsRepository.save(paymentDetail);
		return savedObj;
	}

	public String getAppSource(Application application, String transferFlag, String partnerId, Shopper user)
			throws BusinessException {
		String appSource = null;

		String agentType = AgentTypeEnum.NONE.toString();
		Agent agent = application.getAgent();
		if (agent != null && agent.getAgentType() != null && agent.getAgentType() != AgentTypeEnum.NONE) {
			agentType = agent.getAgentType().name();
		}

		String appOriginType = ApplicationOriginTypeEnum.ELECTRONIC.toString();
		if (application.getApplicationOrigin() != null) {
			appOriginType = application.getApplicationOrigin().toString();
		}

		String agentSubmittedFlag = null;
		if (application.getIsAgentSubmitted() == null) {
			agentSubmittedFlag = "N";
		} else {
			agentSubmittedFlag = application.getIsAgentSubmitted().toString().substring(0, 1);
		}
		PaymentAppSource appSourceDataBean = paymentAppSourceRepository.getAppSource(partnerId, agentType,
				appOriginType, transferFlag, agentSubmittedFlag);

		if (appSourceDataBean != null) {
			appSource = appSourceDataBean.getAppSource();
		}
		if (appSource == null) {
			StringBuffer msg = new StringBuffer(
					"SetApplication,execute() -- Unable to determine AppSource for the given partnerId:");
			msg.append(partnerId);
			msg.append("AgentType:");
			if (application.getAgent() != null && application.getAgent().getAgentType() != null)
				msg.append(application.getAgent().getAgentType().name());
			else
				msg.append("null");
			msg.append(", AppOrigin:");
			msg.append(application.getApplicationOrigin());
			msg.append(", transferFlag:");
			msg.append(transferFlag);
			msg.append(" and AgentSubmittedFlag:");
			msg.append(application.getIsAgentSubmitted());
			LOGGER.error(msg.toString());
			throw new BusinessException(
					"Error In SetApplication, Unable to determine AppSource for the given partnerId, AgentType, AppOrigin, transferFlag and AgentSubmittedFlag");
		}

		// AgentConnect but the shopper role is not consumer but broker then set it to
		// APE-EB.
		if ("APE-AC".equalsIgnoreCase(appSource) && null != user.getShopperRole()
				&& user.getShopperRole() == ShopperRoleEnum.BROKER) {
			appSource = "APE-EB";
		}
		return appSource;
	}

	@Override
	public GetPaymentResponseRS getPayment(GetPaymentRequestRS request) throws BusinessException {

		return null;
	}

	@Override
	public SetPaymentResponseRS setPayment(SetPaymentRequestRS request) throws BusinessException {

		Application application = request.getApplication();
		boolean flag = true;

		if (null != application) {
			if (null != application.getApplicationType()
					&& (application.getApplicationType().equals(ApplicationTypeEnum.ONEXCHANGE)
							|| application.getApplicationType().equals(ApplicationTypeEnum.OFFEXCHANGE))) {
				flag = false;
			}
		}

		if (flag) {

			PaymentDetails payment = paymentDetailsRepository.getPaymentForAcn(request.getAcn());

			// Throws BussinessException when the SetAgent is called and the user is not the
			// owner of the application.
			if (!serviceUtils.checkApplicationOwner(payment, request.getUserId())) {
				throw new BusinessException(
						"Cannot update the Application, Requested user is not the OWNER of this application");
			}

			// Throws BussinessException when the SetPayment is called and the application
			// status is not INPROGRESS OR SUBMITREJECT.
			if (serviceUtils.checkApplicationStatus(payment)) {
				throw new BusinessException("Cannot update the Application which is not in INPROGRESS status");
			}

		}

		SetPaymentResponseRS response = null;
		Object objRes = null;

		try {

			// Save/Update Payment

			String operationName = "setPayment";
			String partnerId = request.getPartnerId();
			if ("KYH".equalsIgnoreCase(request.getPartnerId()) || "KYHCSR".equalsIgnoreCase(request.getPartnerId())) {
				operationName = "setPaymentKYH";
			}
			if (null != partnerId) {
				if (partnerId.equalsIgnoreCase("HIP")) {
					objRes = setPaymentHelper.setPayment(request, operationName, false);
				}

				response = (SetPaymentResponseRS) objRes;
			}

		} catch (Exception ex) {
			throw new BusinessException(ex.getMessage());
		}

		return response;

	}

	@Override
	public CancelPaymentsResponseRS cancelPayment(CancelPaymentsRequestRS request) throws BusinessException {

		CancelPaymentsResponseRS response = new CancelPaymentsResponseRS();
		String acn = request.getAcn();
		String partnerId = request.getPartnerId();
		String userId = request.getUserId();
		String trackingId = request.getPaymentTrackingId();
		boolean isPaymentCancelled = false;
		try {
			if (trackingId != null && trackingId.length() > 0) {
				PaymentDetails paymentDetails = paymentDetailsRepository.getPaymentDetailsByOrderId(trackingId);
				if (null != paymentDetails.getTransactions() && paymentDetails.getTransactions().length > 0) {
					isPaymentCancelled = cancelPayment(userId, trackingId, paymentDetails);
				}
			} else {
				PaymentDetails paymentDetails = paymentDetailsRepository.getPaymentDetailsByAcnAndPartnerId(acn,
						partnerId);
				if (null != paymentDetails.getTransactions() && paymentDetails.getTransactions().length > 0) {
					isPaymentCancelled = cancelPayment(userId, "", paymentDetails);
				}
			}
		} catch (Exception ex) {
			throw new BusinessException(ex.getMessage());
		}
		response.setAcn(acn);
		response.setPartnerId(partnerId);
		response.setUserId(userId);
		response.setPaymentCancelStatus(isPaymentCancelled);
		return response;
	}

	private boolean cancelPayment(String userId, String trackingId, PaymentDetails paymentDetailsByOrderId) {
		boolean isPaymentCancelled = false;
		int count = 0;
		for (Transaction transaction : paymentDetailsByOrderId.getTransactions()) {
			String transactionStatus = transaction.getTransactionStatus();
			String transactionType = transaction.getTransactionType();
			if (null != transactionStatus && null != transactionType && "PAYMENT".equalsIgnoreCase(transactionType)
					&& "PENDING".equalsIgnoreCase(transactionStatus)) {

				transaction.setTransactionStatus("CANCELLED");

				Date cancelledDate = serviceUtils.mongoDateConverter(new Date());
				transaction.setUpdatedDt(cancelledDate);

				Query query = new Query();
				if (!trackingId.isEmpty()) {
					query.addCriteria(
							Criteria.where("transactions").elemMatch(Criteria.where("anthem_orderId").is(trackingId)
									.and("transaction_type").is("PAYMENT").and("transaction_status").is("PENDING")));
				} else {
					query.addCriteria(Criteria.where("transactions").elemMatch(
							Criteria.where("transaction_type").is("PAYMENT").and("transaction_status").is("PENDING")));
				}

				Update update = new Update();
				update.set("transactions." + count + ".transaction_status", transaction.getTransactionStatus());
				update.set("transactions." + count + ".updated_dt", transaction.getUpdatedDt());

				CancelDetails cancelDetails = new CancelDetails();
				cancelDetails.setCancelledDt(cancelledDate);
				cancelDetails.setCancelledBy(userId);

				update.set("transactions." + count + ".cancelDetails", cancelDetails);
				iPayDbTemplate.findAndModify(query, update, PaymentDetails.class);
				isPaymentCancelled = true;
				if (!trackingId.isEmpty()) {
					break;
				}
			}
			count++;
		}
		return isPaymentCancelled;
	}

	@Override
	public ValidateZipCodeResponseRS validateZipCode(ValidateZipCodeRequestRS request) throws BusinessException {

		ValidateZipCodeResponseRS response = new ValidateZipCodeResponseRS();
		try{
			try {				
				LOGGER.info("Inside validateZipCode getZipCodeInformation() - Start");
				List<ZipCodeDetails> zipCodeDetailsList = zipCodeRepository.getZipCodeInformation(request.getZipCode());
				ValidateResponse validateResponse = new ValidateResponse();
				validateResponse.setResponseMessage(serviceUtils.getZipCodeAckMessage(zipCodeDetailsList));
				validateResponse.setZipCode(serviceUtils.getZipCodeInformation(zipCodeDetailsList));
				response.setZipCodeResponse(validateResponse);			
				LOGGER.info("Inside validateZipCode getZipCodeInformation() - End");
			} catch (Exception e) {	
				LOGGER.error("Exception in validateZipCode - getZipCodeInformation()" + e.getMessage());
			}
		}catch(Exception ex){
			
		}
		return response;
	}

	@Override
	public SetExchangeTransLogResponse setExchangeTransLog(SetExchangeTransLogRequest request) throws BusinessException {
		
		LOGGER.info("Inside ApplicationPaymentServiceImpl setExchangeTransLog - Start");
		IPPLogDetails ippLogDetails = new IPPLogDetails();
		ippLogDetails.setTransId(request.getId());
		ippLogDetails.setOpName(request.getOpName());
		ippLogDetails.setRequestingSystem("IPP");
		
		if(request.getRequestXML() != null && !request.getRequestXML().isEmpty()){
			ippLogDetails.setRequestXML(serviceUtils.getEncodedText(request.getRequestXML()));
		}
		
		if(request.getResponseXML() != null && !request.getResponseXML().isEmpty()){
			ippLogDetails.setResponseXML(serviceUtils.getEncodedText(request.getResponseXML()));
		}
		
		ippLogDetails.setRequestTS(Calendar.getInstance(Locale.US).getTime());
		ippLogDetails.setResponseTS(Calendar.getInstance(Locale.US).getTime());
		ippLogDetails.setCreateDt(Calendar.getInstance(Locale.US).getTime());
		ippLogDetails.setCreateId(request.getWLPConsumerId());
		ippLogDetails.setUpdateId(request.getWLPConsumerId());
		ippLogDetails.setUpdateDt(Calendar.getInstance(Locale.US).getTime());
		
		IPPLogDetails response = new IPPLogDetails();
		SetExchangeTransLogResponse setExchangeTransLogResponse = new SetExchangeTransLogResponse();
		
		try{
			response = ippLogRepository.save(ippLogDetails);
			if(null != response && response.getTransId() != 0){
				setExchangeTransLogResponse.setTransId(response.getTransId());
			}
		} catch (Exception ex){
			LOGGER.error("Exception in saving setExchangeTransLog::"+ ex.getMessage());
		}
		LOGGER.info("Inside ApplicationPaymentServiceImpl setExchangeTransLog - End");
		return setExchangeTransLogResponse;
	}

}
