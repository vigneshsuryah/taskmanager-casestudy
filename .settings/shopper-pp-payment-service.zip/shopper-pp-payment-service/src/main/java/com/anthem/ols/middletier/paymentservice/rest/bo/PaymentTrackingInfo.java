package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PaymentTrackingInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3147565908900342045L;

	private String paymentTrackingID;
    
    private double totalOwed ;
    
    private double paidAmount ;

	private double paymentDue ;
    
    private String paymentStatus ;
    
	private Date paymentCancelDate ;
    
	private Date paymentDate ;

	private String paymentType; 

	private String paymentSource;

	public String getPaymentTrackingID() {
		return paymentTrackingID;
	}

	public void setPaymentTrackingID(String paymentTrackingID) {
		this.paymentTrackingID = paymentTrackingID;
	}

	public double getTotalOwed() {
		return totalOwed;
	}

	public void setTotalOwed(double totalOwed) {
		this.totalOwed = totalOwed;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public double getPaymentDue() {
		return paymentDue;
	}

	public void setPaymentDue(double paymentDue) {
		this.paymentDue = paymentDue;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Date getPaymentCancelDate() {
		return paymentCancelDate;
	}

	public void setPaymentCancelDate(Date paymentCancelDate) {
		this.paymentCancelDate = paymentCancelDate;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	} 
}

