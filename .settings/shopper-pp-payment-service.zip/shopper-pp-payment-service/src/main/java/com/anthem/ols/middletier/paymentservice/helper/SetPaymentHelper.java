package com.anthem.ols.middletier.paymentservice.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.anthem.ols.middletier.paymentservice.entity.PayerId;
import com.anthem.ols.middletier.paymentservice.entity.PaymentDetails;
import com.anthem.ols.middletier.paymentservice.rest.bo.AccessControl;
import com.anthem.ols.middletier.paymentservice.rest.bo.Applicant;
import com.anthem.ols.middletier.paymentservice.rest.bo.Application;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationStatus;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationStatusEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.ApplicationTypeEnum;
import com.anthem.ols.middletier.paymentservice.rest.bo.Demographic;
import com.anthem.ols.middletier.paymentservice.rest.bo.Payment;
import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentSelection;
import com.anthem.ols.middletier.paymentservice.rest.bo.PlanSelection;
import com.anthem.ols.middletier.paymentservice.rest.bo.ValidationErrors;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;

@Component
public class SetPaymentHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(SetPaymentHelper.class);
	
	
	public Object setPayment(SetPaymentRequestRS objReq, String operationName, boolean isForSetApplication) {
		SetPaymentResponseRS response = new SetPaymentResponseRS();
		
		PlanSelection planSelection = null;
		boolean isSplitRequired = false;
		
		int splitValue = 0;

		ValidationErrors validationErrors = null;

		String paymentExceptionMsg = null;

		String acn = "";
		String userId = "";
		PaymentSelection paymentSelection = null;
		String partnerId = "";
		String applicationType = "";
		
		// SetPayment can only be called with either setPaymentRequest or setApplicationRequest
		
		if (!isForSetApplication) {
			// For SetPayment flow
			SetPaymentRequestRS request = (SetPaymentRequestRS) objReq;
			acn = request.getAcn();
			userId = request.getUserId();
			partnerId = request.getPartnerId();
			
			if(null != request.getApplication() && null != request.getApplication().getApplicationType()){
				if(request.getApplication().getApplicationType().equals(ApplicationTypeEnum.ONEXCHANGE) || request.getApplication().getApplicationType().equals(ApplicationTypeEnum.OFFEXCHANGE)){
					if(request.getApplication().getApplicationType().equals(ApplicationTypeEnum.OFFEXCHANGE)){
						if(null == request.getApplication().getApplicationStatus()){
							ApplicationStatus inProgressStatus = new ApplicationStatus();
							inProgressStatus.setApplicationStatus(ApplicationStatusEnum.INPROGRESS);
							request.getApplication().setApplicationStatus(inProgressStatus);
						}
					}
					//ApplicationDataBean applicationDataBeanRequest = (ApplicationDataBean)context.getTransformationManager().transform(request.getApplication(), ApplicationDataBean.class);
					//applicationDAO.updateOnOffExchangeApplicationData(acn, partnerId, userId, applicationDataBeanRequest);
				}
			}
			
		}else {
			// For SetApplication flow
			
		}
		
		
		return response;
	}
	
	public PaymentDetails convertApplicationtoPaymentDetails(Application application) {
		PaymentDetails paymentDetails = new PaymentDetails();
		
		paymentDetails.setAcn(application.getAcn());
		paymentDetails.setApplicationVersion(application.getApplicationVersion());
		paymentDetails.setState(application.getState());
		paymentDetails.setApplicationType(application.getApplicationType().value());
		paymentDetails.setReqEffDate(application.getReqEffDate());

		AccessControl accessControl = application.getAccessControlList()[0];
		if(null != accessControl) {
			paymentDetails.setAccessType(accessControl.getAccessType().value());
			if(null != accessControl.getUser()) {
				paymentDetails.setUserId(accessControl.getUser().getUserId());
				paymentDetails.setUserRole(accessControl.getUser().getShopperRole().value());
			}
		}

		Applicant applicant = application.getApplicant()[0];
		Demographic demographic = applicant.getDemographic();
		paymentDetails.setApplicantFirstName(demographic.getFirstName());
		paymentDetails.setApplicantLastName(demographic.getLastName());
		paymentDetails.setApplicantMiddleName(demographic.getMi());
		paymentDetails.setMemberCode(String.valueOf(applicant.getMemberCode()));

		paymentDetails.setSettleAmount(application.getPremiumAmt());
		paymentDetails.setAppSource(application.getAppSource());
		paymentDetails.setExchSubscriberId(application.getExchSubscriberId());
		paymentDetails.setExchTransactionId(application.getExchTransactionId());
		
		paymentDetails.setExchaptcAmt(String.valueOf(application.getExchAPTCAmt()));
		paymentDetails.setLangPref(application.getApplicationLanguage().value());
		paymentDetails.setExchConsumerId(application.getExchConsumerId());
		paymentDetails.setWlpConsumerId(application.getwLPConsumerId());
		paymentDetails.setPartnerId(application.getCreatePartnerId());
		paymentDetails.setIpAddress(application.getIpAddress());
		
		PaymentSelection paymentSelection = application.getPaymentSelection();
		if(null != paymentSelection.getCsrIdentifier()) {
			PayerId payerId = new PayerId();
			payerId.setId(paymentSelection.getCsrIdentifier());
			payerId.setType("CSR");
		}else {
			PayerId payerId = new PayerId();
			payerId.setId("PPORT");
			payerId.setType("PPORT");
		}
		
		/*Transaction[] transactions = new 
		Payment[] payments = paymentSelection.getInitialPayment();
		
		for(Payment payment : payments) {
			
		}
		
		paymentDetails.setTransactions(transactions);
		
		if(null != payDetails.getTransactions() && payDetails.getTransactions().length > 0) {
            PaymentSelection paySelection = new PaymentSelection();
            List<Payment> payments = new ArrayList<>();
            for(Transaction transaction : payDetails.getTransactions()) {
                  Payment payment = new Payment();
                  if(null != payDetails.getPaymentMethod()) {
                         if("ACH".equalsIgnoreCase(payDetails.getPaymentMethod().getPaymentType())){
                                BankAccount bankAcc = new BankAccount();
                                bankAcc.setAccountHolderName(payDetails.getPaymentMethod().getNameOnFundingAccount());
                                bankAcc.setAccountNo(payDetails.getPaymentMethod().getBankAccountNumber());
                            bankAcc.setAccountType(convertBankAccType(payDetails.getPaymentMethod().getPaymentSubType()));
                                bankAcc.setRoutingNo(payDetails.getPaymentMethod().getBankRoutingnumber());
                                payment.setBankAcct(bankAcc);
                                payment.setPaymentType(PaymentTypeEnum.ECHECK);
                         }else if("CC".equalsIgnoreCase(payDetails.getPaymentMethod().getPaymentType())) {
                                CreditCard creditCard = new CreditCard();
                                creditCard.setCardHolderName(payDetails.getPaymentMethod().getNameOnFundingAccount());
                                creditCard.setCardNo(payDetails.getPaymentMethod().getCreditCardNumber());
                               creditCard.setCardType(convertCardType(payDetails.getPaymentMethod().getPaymentSubType()));
                                creditCard.setExpDate(payDetails.getPaymentMethod().getCcExpDate());
                                payment.setCreditCard(creditCard);
                                payment.setPaymentType(PaymentTypeEnum.CREDITCARD);
                         }
                  
                         FundAccountOwnerFullAddress fundAddr = payDetails.getPaymentMethod().getFundAccountOwnerFullAddress();
                         if(null != fundAddr) {
                                Address address = new Address();
                                address.setAddressLine1(fundAddr.getAddress1());
                                address.setAddressLine2(fundAddr.getAddress2());
                                address.setCity(fundAddr.getCity());
                                address.setState(fundAddr.getState());
                                address.setPostalCode(fundAddr.getZipcode());
                                address.setCounty(fundAddr.getCounty());
                                address.setCountyCode(fundAddr.getCountyCode());
                                payment.setBillingAddr(address);
                         }
                         payment.setBillingPerson(payDetails.getPaymentMethod().getNameOnFundingAccount());
                         
                  }
            payment.setBillingFrequency(BillingFrequencyTypeEnum.fromValue(transaction.getBillingFrequency()));
                   payment.setWithdrawDay(Integer.parseInt(transaction.getWithDrawDay()));
                  payment.setPaymentAmt(transaction.getPremiumAmount());
                  payment.setPaymentTrackingId(payDetails.getAnthemOrderId());
                  payments.add(payment);
            }
            paySelection.setInitialPayment(payments.stream().toArray(Payment[]::new));
            paySelection.setApplicationLanguage(payDetails.getLangPref());
            //paySelection.setApplicationStatus(payDetails.get);
     paySelection.setComputedMRAAmount(Double.valueOf(payDetails.getTransactions()[0].getComputedMRAAmount()));
     paySelection.setEmailAddress(payDetails.getTransactions()[0].getPaymentConfirmationEmailAddress());
     paySelection.setIsRecvPaperlessBillInfo(AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvPaperlessBillingFlag()));
            paySelection.setRetroInd(payDetails.getTransactions()[0].getRetroIndc());
            paySelection.setRetroPayToDate(payDetails.getTransactions()[0].getRetroPayToDate());
     paySelection.setIsRecvElectronicCOC(AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvElectronicCocFlag()));
     paySelection.setIsReceivePaymentConf(AnswerTypeEnum.fromValue(payDetails.getTransactions()[0].getRecvPaymentConfFlag()));
            application.setPaymentSelection(paySelection);
     }*/


        
		return paymentDetails;
	}
	
	
}
