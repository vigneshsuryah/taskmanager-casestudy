package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;
public class ValidationError implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 1156428345627252839L;	private  String fieldName;
    private  String[] errorMessages;	public String getFieldName() {		return fieldName;	}	public void setFieldName(String fieldName) {		this.fieldName = fieldName;	}	public String[] getErrorMessages() {		return errorMessages;	}	public void setErrorMessages(String[] errorMessages) {		this.errorMessages = errorMessages;	}
}
