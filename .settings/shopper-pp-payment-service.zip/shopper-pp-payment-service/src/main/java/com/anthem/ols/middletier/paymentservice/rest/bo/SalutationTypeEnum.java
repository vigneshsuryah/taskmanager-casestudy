package com.anthem.ols.middletier.paymentservice.rest.bo;
public enum SalutationTypeEnum {
    NONE,
    MR,
    MRS,
    MS;
    public String value() {        return name();    }
    public static SalutationTypeEnum fromValue(String v) {        return valueOf(v);    }
}
