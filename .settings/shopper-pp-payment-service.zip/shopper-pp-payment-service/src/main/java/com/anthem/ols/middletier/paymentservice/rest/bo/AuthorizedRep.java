package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class AuthorizedRep extends Person implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 5983152024368729287L;	private  int id;
    private  Address address;
    private  String phoneNo;
    private  String relationship;
    private  String otherRelationship;
    private  ESignature eSignature;
    private  ActionTypeEnum action;
    private  String email;
	/**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the phoneNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneNo() {
        return phoneNo;
    }

    /**
     * Sets the value of the phoneNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneNo(String value) {
        this.phoneNo = value;
    }

    /**
     * Gets the value of the relationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationship() {
        return relationship;
    }

    /**
     * Sets the value of the relationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationship(String value) {
        this.relationship = value;
    }

    /**
     * Gets the value of the otherRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherRelationship() {
        return otherRelationship;
    }

    /**
     * Sets the value of the otherRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherRelationship(String value) {
        this.otherRelationship = value;
    }

    /**
     * Gets the value of the eSignature property.
     * 
     * @return
     *     possible object is
     *     {@link ESignature }
     *     
     */
    public ESignature getESignature() {
        return eSignature;
    }

    /**
     * Sets the value of the eSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link ESignature }
     *     
     */
    public void setESignature(ESignature value) {
        this.eSignature = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }
    public String getEmail() {		return email;	}	public void setEmail(String email) {		this.email = email;	}
}
