package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum ApplicationStatusEnum {
	
	INPROGRESS,
	CANCELLED,
	SUBMITTED,
	SUBMITREJECT,
	APPROVED,
	DENIED,
	PENDING,
	PENDATTESTATION,
	PAYMTPENDING,
	CLOSED,
	ADDLINFO,
	PAYMTSUBMITTED,
	EXPIRED,
	ACTIVE,
	SUBMITTING,
	ELIGRECV,
	INELIGIBLE,
	EXCHACCEPTED,
	CONTINUEONFFM,
	ENROLLPENDING,
	PAYMENTPROCESSING,
	PAYMENTFAILED;
	
	public String value() {
		return name();
	}

	public static ApplicationStatusEnum fromValue(String v) {
		return valueOf(v);
	}

}