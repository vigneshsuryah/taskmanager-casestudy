package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class PriorCoverage implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 6602533659975764368L;	private  int id;
    private  AnswerTypeEnum isReplaceMedSupPolicyStatement;
    private  AnswerTypeEnum isAnyMedicareCovInvolTerminated;
    private  AnswerTypeEnum isInsCovInThePastInvolTerminated;
    private  ActionTypeEnum action;
    private  AnswerTypeEnum isOtherHealthCovDisability;
    private  String otherHealthCovDisabilityReason;
    private  AnswerTypeEnum isReplCovPolicyInForce;
    private  AnswerTypeEnum isReplCovPolicyInReplace;    private  HealthInsCoverage anthemPolicy;
    private  HealthInsCoverage otherHealthCovPolicy;        private  AnswerTypeEnum isEligibleForMedicare;        private  Date replCovCancelDate;        private  Date otherHealthCovStartDate;        private  Date otherHealthCovEndDate;    	/**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

	/**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the isReplaceMedSupPolicyStatement property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsReplaceMedSupPolicyStatement() {
        return isReplaceMedSupPolicyStatement;
    }

    /**
     * Sets the value of the isReplaceMedSupPolicyStatement property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsReplaceMedSupPolicyStatement(AnswerTypeEnum value) {
        this.isReplaceMedSupPolicyStatement = value;
    }

    /**
     * Gets the value of the isAnyMedicareCovInvolTerminated property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsAnyMedicareCovInvolTerminated() {
        return isAnyMedicareCovInvolTerminated;
    }

    /**
     * Sets the value of the isAnyMedicareCovInvolTerminated property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsAnyMedicareCovInvolTerminated(AnswerTypeEnum value) {
        this.isAnyMedicareCovInvolTerminated = value;
    }

    /**
     * Gets the value of the isInsCovInThePastInvolTerminated property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsInsCovInThePastInvolTerminated() {
        return isInsCovInThePastInvolTerminated;
    }

    /**
     * Sets the value of the isInsCovInThePastInvolTerminated property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsInsCovInThePastInvolTerminated(AnswerTypeEnum value) {
        this.isInsCovInThePastInvolTerminated = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }


   /* *//**
     * Gets the value of the isOtherHealthCovCov63Or90Days property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     *//**
     * Sets the value of the isOtherHealthCovCov63Or90Days property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */

    /**
     * Gets the value of the isOtherHealthCovDisability property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsOtherHealthCovDisability() {
        return isOtherHealthCovDisability;
    }

    /**
     * Sets the value of the isOtherHealthCovDisability property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsOtherHealthCovDisability(AnswerTypeEnum value) {
        this.isOtherHealthCovDisability = value;
    }

    /**
     * Gets the value of the otherHealthCovDisabilityReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherHealthCovDisabilityReason() {
        return otherHealthCovDisabilityReason;
    }

    /**
     * Sets the value of the otherHealthCovDisabilityReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherHealthCovDisabilityReason(String value) {
        this.otherHealthCovDisabilityReason = value;
    }

  

    /**
     * Gets the value of the isReplCovPolicyInForce property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsReplCovPolicyInForce() {
        return isReplCovPolicyInForce;
    }

    /**
     * Sets the value of the isReplCovPolicyInForce property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsReplCovPolicyInForce(AnswerTypeEnum value) {
        this.isReplCovPolicyInForce = value;
    }

   
    /**
     * Gets the value of the isReplCovPolicyInReplace property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsReplCovPolicyInReplace() {
        return isReplCovPolicyInReplace;
    }

    /**
     * Sets the value of the isReplCovPolicyInReplace property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsReplCovPolicyInReplace(AnswerTypeEnum value) {
        this.isReplCovPolicyInReplace = value;
    }

    /**
     * Gets the value of the anthemPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link HealthInsCoverage }
     *     
     */
    public HealthInsCoverage getAnthemPolicy() {
        return anthemPolicy;
    }

    /**
     * Sets the value of the anthemPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link HealthInsCoverage }
     *     
     */
    public void setAnthemPolicy(HealthInsCoverage value) {
        this.anthemPolicy = value;
    }

    /**
     * Gets the value of the otherHealthCovPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link HealthInsCoverage }
     *     
     */
    public HealthInsCoverage getOtherHealthCovPolicy() {
        return otherHealthCovPolicy;
    }

    /**
     * Sets the value of the otherHealthCovPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link HealthInsCoverage }
     *     
     */
    public void setOtherHealthCovPolicy(HealthInsCoverage value) {
        this.otherHealthCovPolicy = value;
    }        public AnswerTypeEnum getIsEligibleForMedicare() {		return isEligibleForMedicare;	}	public void setIsEligibleForMedicare(AnswerTypeEnum isEligibleForMedicare) {		this.isEligibleForMedicare = isEligibleForMedicare;	}
	public Date getReplCovCancelDate() {		return replCovCancelDate;	}	public void setReplCovCancelDate(Date replCovCancelDate) {		this.replCovCancelDate = replCovCancelDate;	}		public Date getOtherHealthCovStartDate() {		return otherHealthCovStartDate;	}	public void setOtherHealthCovStartDate(			Date otherHealthCovStartDate) {		this.otherHealthCovStartDate = otherHealthCovStartDate;	}	public Date getOtherHealthCovEndDate() {		return otherHealthCovEndDate;	}	public void setOtherHealthCovEndDate(Date otherHealthCovEndDate) {		this.otherHealthCovEndDate = otherHealthCovEndDate;	}

}
