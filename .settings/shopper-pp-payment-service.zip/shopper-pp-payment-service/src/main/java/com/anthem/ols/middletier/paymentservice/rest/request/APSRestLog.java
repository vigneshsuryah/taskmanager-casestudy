package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;
import java.util.Date;

public class APSRestLog implements Serializable {
	private static final long serialVersionUID = 1L;
	private String transId;
	private String opName;
	private String requestingSystem;
	private String requestXML;
	private String responseXML;
	private Date requestTS;
	private Date responseTS;
	private Date createDt;
	private String createId;
	private Date updateDt;
	private String updateId;

	public String getOpName() {
		return opName;
	}

	public void setOpName(String opName) {
		this.opName = opName;
	}

	public String getRequestingSystem() {
		return requestingSystem;
	}

	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}

	public String getRequestXML() {
		return requestXML;
	}

	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}

	public String getResponseXML() {
		return responseXML;
	}

	public void setResponseXML(String responseXML) {
		this.responseXML = responseXML;
	}

	public Date getRequestTS() {
		return requestTS;
	}

	public void setRequestTS(Date requestTS) {
		this.requestTS = requestTS;
	}

	public Date getResponseTS() {
		return responseTS;
	}

	public void setResponseTS(Date responseTS) {
		this.responseTS = responseTS;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Date getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}
}
