package com.anthem.ols.middletier.paymentservice.service;

import com.anthem.ols.middletier.paymentservice.exception.BusinessException;
import com.anthem.ols.middletier.paymentservice.rest.request.CancelPaymentsRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.GetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetApplicationRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetPaymentRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogRequest;
import com.anthem.ols.middletier.paymentservice.rest.request.SetExchangeTransLogResponse;
import com.anthem.ols.middletier.paymentservice.rest.request.ValidateZipCodeRequestRS;
import com.anthem.ols.middletier.paymentservice.rest.response.CancelPaymentsResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.GetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetApplicationResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.SetPaymentResponseRS;
import com.anthem.ols.middletier.paymentservice.rest.response.ValidateZipCodeResponseRS;

public interface ApplicationPaymentService {
	
	public GetApplicationResponseRS getApplication(GetApplicationRequestRS request) throws BusinessException;
	
	public SetApplicationResponseRS setApplication(SetApplicationRequestRS request) throws BusinessException;
	
	public GetPaymentResponseRS getPayment(GetPaymentRequestRS request) throws BusinessException;
	
	public SetPaymentResponseRS setPayment(SetPaymentRequestRS request) throws BusinessException;

	public CancelPaymentsResponseRS cancelPayment(CancelPaymentsRequestRS request) throws BusinessException;
	
    public ValidateZipCodeResponseRS validateZipCode(ValidateZipCodeRequestRS request) throws BusinessException;
	
	public SetExchangeTransLogResponse setExchangeTransLog(SetExchangeTransLogRequest request) throws BusinessException;
}