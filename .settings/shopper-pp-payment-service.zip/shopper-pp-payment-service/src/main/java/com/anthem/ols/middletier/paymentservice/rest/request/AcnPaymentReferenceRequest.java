package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;
import java.util.Date;

public class AcnPaymentReferenceRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	private String acn;
	private String paymentId;
	private Date createdDate;


	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "AcnPaymentReferenceRequest [acn=" + acn + ", paymentId=" + paymentId + ", createdDate=" + createdDate + "]";
	}
}
