package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;

public class BaseRequestRS implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7482789656068465873L;

}
