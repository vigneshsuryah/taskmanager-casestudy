package com.anthem.ols.middletier.paymentservice.rest.request;

public class GeneratePDFRequestRS extends BaseRequestRS{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7661736096345938967L;

	private  String partnerId;

	private  String acn;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}


}
