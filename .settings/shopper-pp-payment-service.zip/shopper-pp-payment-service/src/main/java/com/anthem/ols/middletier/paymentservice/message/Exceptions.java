/**
* Exceptions.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 03/08/2017   1.0       Cognizant      Initial Version
*/
package com.anthem.ols.middletier.paymentservice.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Exceptions {
	
	private String code;
	
	private String message;

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
