package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum PlanMaterialLanguageEnum {
    NONE,
    SPANISH,
    CHINESE;
    public String value() {        return name();    }

    public static PlanMaterialLanguageEnum fromValue(String v) {        return valueOf(v);    }
}
