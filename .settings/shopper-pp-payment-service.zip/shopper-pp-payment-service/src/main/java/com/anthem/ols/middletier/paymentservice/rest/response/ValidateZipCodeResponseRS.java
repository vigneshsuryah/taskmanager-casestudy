package com.anthem.ols.middletier.paymentservice.rest.response;

import com.anthem.ols.middletier.paymentservice.rest.bo.ValidateResponse;

public class ValidateZipCodeResponseRS extends BaseResponseRS
{
 
	private static final long serialVersionUID = -8988732216797985619L;	
	
	
	private ValidateResponse zipCodeResponse;

	public ValidateResponse getZipCodeResponse() {
		return zipCodeResponse;
	}

	public void setZipCodeResponse(ValidateResponse zipCodeResponse) {
		this.zipCodeResponse = zipCodeResponse;
	}
	
	

  
}