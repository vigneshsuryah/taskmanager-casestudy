package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRARequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetComputedMRAResponse;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsRequest;
import com.anthem.ols.middletier.paymentservice.hcentive.GetEnrollmentDetailsResponse;


@MessagingGateway
public interface PaymentIntegrationGateway {

	@Gateway(requestChannel = "getComputedMRARequestChannel", replyChannel = "getComputedMRAResponseChannel")
	public GetComputedMRAResponse getComputedMRADetails(GetComputedMRARequest request);
	
	@Gateway(requestChannel = "getEnrollmentDetailsRequestChannel", replyChannel = "getEnrollmentDetailsResponseChannel")
	public GetEnrollmentDetailsResponse getEnrollmentDetails(GetEnrollmentDetailsRequest request);
}
