package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway
public interface PaymentIntegrationGateway {

}
