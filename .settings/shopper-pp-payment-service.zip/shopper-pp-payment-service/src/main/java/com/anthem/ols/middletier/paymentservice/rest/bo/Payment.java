package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class Payment implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1978024387320716978L;

	private  int id;

    private  int withdrawDay;

    private  AnswerTypeEnum isUseHomeAddrForBilling;

    private  AnswerTypeEnum isUseMailOrBillAddrForBilling;

    private  String paymentTrackingId;

    private  double paymentAmt;

    private  PaymentTypeEnum paymentType;

    private  BillingFrequencyTypeEnum billingFrequency;

    private  String billingPerson;

    private  Address billingAddr;

    private  CreditCard creditCard;

    private  BankAccount bankAcct;

    private  String employerGroupNo;

    private  AnswerTypeEnum isAuthorizeMonthlyAcctDed;

    private  AnswerTypeEnum isAuthorizeCCUse;

    private  AnswerTypeEnum isAuthorizeCCCharge;

    private  ActionTypeEnum action;
    
    private  AnswerTypeEnum isUseCCAddrForBilling;
    
    private  String paymentIdentifier;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWithdrawDay() {
		return withdrawDay;
	}

	public void setWithdrawDay(int withdrawDay) {
		this.withdrawDay = withdrawDay;
	}

	public AnswerTypeEnum getIsUseHomeAddrForBilling() {
		return isUseHomeAddrForBilling;
	}

	public void setIsUseHomeAddrForBilling(AnswerTypeEnum isUseHomeAddrForBilling) {
		this.isUseHomeAddrForBilling = isUseHomeAddrForBilling;
	}

	public AnswerTypeEnum getIsUseMailOrBillAddrForBilling() {
		return isUseMailOrBillAddrForBilling;
	}

	public void setIsUseMailOrBillAddrForBilling(
			AnswerTypeEnum isUseMailOrBillAddrForBilling) {
		this.isUseMailOrBillAddrForBilling = isUseMailOrBillAddrForBilling;
	}

	public String getPaymentTrackingId() {
		return paymentTrackingId;
	}

	public void setPaymentTrackingId(String paymentTrackingId) {
		this.paymentTrackingId = paymentTrackingId;
	}

	public double getPaymentAmt() {
		return paymentAmt;
	}

	public void setPaymentAmt(double paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	public PaymentTypeEnum getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentTypeEnum paymentType) {
		this.paymentType = paymentType;
	}

	public BillingFrequencyTypeEnum getBillingFrequency() {
		return billingFrequency;
	}

	public void setBillingFrequency(BillingFrequencyTypeEnum billingFrequency) {
		this.billingFrequency = billingFrequency;
	}

	public String getBillingPerson() {
		return billingPerson;
	}

	public void setBillingPerson(String billingPerson) {
		this.billingPerson = billingPerson;
	}

	public Address getBillingAddr() {
		return billingAddr;
	}

	public void setBillingAddr(Address billingAddr) {
		this.billingAddr = billingAddr;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public BankAccount getBankAcct() {
		return bankAcct;
	}

	public void setBankAcct(BankAccount bankAcct) {
		this.bankAcct = bankAcct;
	}

	public String getEmployerGroupNo() {
		return employerGroupNo;
	}

	public void setEmployerGroupNo(String employerGroupNo) {
		this.employerGroupNo = employerGroupNo;
	}

	public AnswerTypeEnum getIsAuthorizeMonthlyAcctDed() {
		return isAuthorizeMonthlyAcctDed;
	}

	public void setIsAuthorizeMonthlyAcctDed(
			AnswerTypeEnum isAuthorizeMonthlyAcctDed) {
		this.isAuthorizeMonthlyAcctDed = isAuthorizeMonthlyAcctDed;
	}

	public AnswerTypeEnum getIsAuthorizeCCUse() {
		return isAuthorizeCCUse;
	}

	public void setIsAuthorizeCCUse(AnswerTypeEnum isAuthorizeCCUse) {
		this.isAuthorizeCCUse = isAuthorizeCCUse;
	}

	public AnswerTypeEnum getIsAuthorizeCCCharge() {
		return isAuthorizeCCCharge;
	}

	public void setIsAuthorizeCCCharge(AnswerTypeEnum isAuthorizeCCCharge) {
		this.isAuthorizeCCCharge = isAuthorizeCCCharge;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public AnswerTypeEnum getIsUseCCAddrForBilling() {
		return isUseCCAddrForBilling;
	}

	public void setIsUseCCAddrForBilling(AnswerTypeEnum isUseCCAddrForBilling) {
		this.isUseCCAddrForBilling = isUseCCAddrForBilling;
	}

	public String getPaymentIdentifier() {
		return paymentIdentifier;
	}

	public void setPaymentIdentifier(String paymentIdentifier) {
		this.paymentIdentifier = paymentIdentifier;
	}
    
}