package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.math.BigDecimal;

import com.anthem.ols.middletier.paymentservice.domain.BaseBusinessObject;


public class ZipCode extends BaseBusinessObject
{  
  private String zipCode;  
  private String stateCode;
  private double longitude;
  private double latitude;
  private CountyList countyList;
  private String timeZone;
  private BigDecimal gMTOffset;
  private String currentDateTimeInZoneValue;
  
public String getZipCode() {
	return zipCode;
}
public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}
public String getStateCode() {
	return stateCode;
}
public void setStateCode(String stateCode) {
	this.stateCode = stateCode;
}
public double getLongitude() {
	return longitude;
}
public void setLongitude(double longitude) {
	this.longitude = longitude;
}
public double getLatitude() {
	return latitude;
}
public void setLatitude(double latitude) {
	this.latitude = latitude;
}
public CountyList getCountyList() {
	return countyList;
}
public void setCountyList(CountyList countyList) {
	this.countyList = countyList;
}
public String getTimeZone() {
	return timeZone;
}
public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
}
public BigDecimal getgMTOffset() {
	return gMTOffset;
}
public void setgMTOffset(BigDecimal gMTOffset) {
	this.gMTOffset = gMTOffset;
}
public String getCurrentDateTimeInZoneValue() {
	return currentDateTimeInZoneValue;
}
public void setCurrentDateTimeInZoneValue(String currentDateTimeInZoneValue) {
	this.currentDateTimeInZoneValue = currentDateTimeInZoneValue;
}
  
  
  
}

  