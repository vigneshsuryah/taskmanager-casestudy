package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class SubmissionMessage implements Serializable{
  	/**	 * 	 */	private static final long serialVersionUID = 621295526540599360L;	private  String acn;
    private  String applicantFName;
    private  String applicantMI;
    private  String applicantLName;
    private  String submissionMessage;
    private  String uwStatus;
    private  String hcid;
    private  Date effectiveDate;
    private  ValidationErrors[] validationErrors;    private int validationErrorsLength;
    /**
     * Gets the value of the acn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcn() {
        return acn;
    }

    /**
     * Sets the value of the acn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcn(String value) {
        this.acn = value;
    }

    /**
     * Gets the value of the applicantFName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantFName() {
        return applicantFName;
    }

    /**
     * Sets the value of the applicantFName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantFName(String value) {
        this.applicantFName = value;
    }

    /**
     * Gets the value of the applicantMI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantMI() {
        return applicantMI;
    }

    /**
     * Sets the value of the applicantMI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantMI(String value) {
        this.applicantMI = value;
    }

    /**
     * Gets the value of the applicantLName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantLName() {
        return applicantLName;
    }

    /**
     * Sets the value of the applicantLName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantLName(String value) {
        this.applicantLName = value;
    }

    /**
     * Gets the value of the submissionMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubmissionMessage() {
        return submissionMessage;
    }

    /**
     * Sets the value of the submissionMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubmissionMessage(String value) {
        this.submissionMessage = value;
    }

    /**
     * Gets the value of the uwStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUwStatus() {
        return uwStatus;
    }

    /**
     * Sets the value of the uwStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUwStatus(String value) {
        this.uwStatus = value;
    }

    /**
     * Gets the value of the hcid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHcid() {
        return hcid;
    }

    /**
     * Sets the value of the hcid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHcid(String value) {
        this.hcid = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setEffectiveDate(Date value) {
        this.effectiveDate = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link ValidationErrors }
     *     
     */
    public ValidationErrors[] getValidationErrors() {
        if (this.validationErrors == null) {
            return new ValidationErrors[ 0 ] ;
        }
        ValidationErrors[] retVal = new ValidationErrors[this.validationErrors.length] ;
        System.arraycopy(this.validationErrors, 0, retVal, 0, this.validationErrors.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link ValidationErrors }
     *     
     */
    public ValidationErrors getValidationErrors(int idx) {
        if (this.validationErrors == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.validationErrors[idx];
    }

    public int getValidationErrorsLength() {
        if (this.validationErrors == null) {
            return  0;
        }
        return this.validationErrors.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link ValidationErrors }
     *     
     */
    public void setValidationErrors(ValidationErrors[] values) {
        int len = values.length;
        this.validationErrors = ((ValidationErrors[]) new ValidationErrors[len] );
        for (int i = 0; (i<len); i ++) {
            this.validationErrors[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link ValidationErrors }
     *     
     */
    public ValidationErrors setValidationErrors(int idx, ValidationErrors value) {
        return this.validationErrors[idx] = value;
    }	public void setValidationErrorsLength(int validationErrorsLength) {		this.validationErrorsLength = validationErrorsLength;	}
}
