package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SearchPayment implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 3792891779938075923L;

	private String firstName;
    
	private String lastName;
    
	private String middleInitial;
    
	private String ssn; 
    
	private String dob; 
    
	private String hcid; 
    
	private String acn; 
    
	private String wemId;
    
	private String exchangeSubscriberId; 
    
	private Address address;
    
	private double paymentdue; 
    
	private String appSource; 
    
	private String enrollmentStatus; 
   
	private PaymentTrackingInfo[] paymentTrackingInfoList;
	
	private int paymentTrackingInfoListLength;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getHcid() {
		return hcid;
	}

	public void setHcid(String hcid) {
		this.hcid = hcid;
	}

	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public String getWemId() {
		return wemId;
	}

	public void setWemId(String wemId) {
		this.wemId = wemId;
	}

	public String getExchangeSubscriberId() {
		return exchangeSubscriberId;
	}

	public void setExchangeSubscriberId(String exchangeSubscriberId) {
		this.exchangeSubscriberId = exchangeSubscriberId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public double getPaymentdue() {
		return paymentdue;
	}

	public void setPaymentdue(double paymentdue) {
		this.paymentdue = paymentdue;
	}

	public String getAppSource() {
		return appSource;
	}

	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	public String getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(String enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	public PaymentTrackingInfo[] getPaymentTrackingInfoList() {
		if (this.paymentTrackingInfoList == null) {
            return new PaymentTrackingInfo[ 0 ] ;
        }
        PaymentTrackingInfo[] retVal = new PaymentTrackingInfo[this.paymentTrackingInfoList.length] ;
        System.arraycopy(this.paymentTrackingInfoList, 0, retVal, 0, this.paymentTrackingInfoList.length);
        return (retVal);
	}

	public void setPaymentTrackingInfoList(
			PaymentTrackingInfo[] values) {
		int len = values.length;
        this.paymentTrackingInfoList = ((PaymentTrackingInfo[]) new PaymentTrackingInfo[len] );
        for (int i = 0; (i<len); i ++) {
            this.paymentTrackingInfoList[i] = values[i];
        }
	}
	
	public int getPaymentTrackingInfoListLength() {
        if (this.paymentTrackingInfoList == null) {
            return  0;
        }
        return this.paymentTrackingInfoList.length;
    }

	public void setPaymentTrackingInfoListLength(
			int paymentTrackingInfoListLength) {
		this.paymentTrackingInfoListLength = paymentTrackingInfoListLength;
	}
}
