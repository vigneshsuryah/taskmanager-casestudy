/**
 * WebServiceConfig.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 05/03/2019  1.0       Cognizant      Initial Version
 */
package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;
import org.springframework.ws.transport.http.CommonsHttpMessageSender;

import com.anthem.ols.middletier.paymentservice.utils.HcentiveInterceptor;
import com.anthem.ols.middletier.paymentservice.utils.WsTracingInterceptor;

@EnableWs
@Configuration
public class WebServiceConfig {
	
	@Autowired
	private ApplicationProperties applicationProperties;
	
	@Autowired private WsTracingInterceptor wsTracingInterceptor;
	
	@Autowired
	private HcentiveInterceptor hcentiveInterceptor;
	
	@Bean
	public Jaxb2Marshaller hcentiveMarshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("com.anthem.ols.middletier.paymentservice.hcentive");
		return marshaller;
	}
		
	@Bean(name="hcentiveWebServiceTemplate")
	public WebServiceTemplate hcentiveWebServiceTemplate() {
		SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory();
		messageFactory.afterPropertiesSet();
		
		WebServiceTemplate client = new WebServiceTemplate(messageFactory);
		client.setDefaultUri(applicationProperties.getStringProperty("hcentive.endpoint", ""));
		client.setMarshaller(hcentiveMarshaller());
		client.setUnmarshaller(hcentiveMarshaller());
		client.setMessageSender(hcentiveHttpComponentsMessageSender());
		
		client.setCheckConnectionForFault(false);
		client.setInterceptors(new ClientInterceptor[] {hcentiveSecurityInterceptor(),hcentiveInterceptor, wsTracingInterceptor});
		return client;
	}
	
	@Bean
	public Wss4jSecurityInterceptor hcentiveSecurityInterceptor() {
		Wss4jSecurityInterceptor interceptor = new Wss4jSecurityInterceptor();
		interceptor.setSecurementActions("UsernameToken");
		interceptor.setSecurementUsername(applicationProperties.getStringProperty("hcentive.security.username", ""));
		interceptor.setSecurementPassword(applicationProperties.getStringProperty("hcentive.security.password", ""));
		interceptor.setSecurementPasswordType("PasswordText");
		return interceptor;
	}
	
	
	@Bean
	public CommonsHttpMessageSender hcentiveHttpComponentsMessageSender() {    
		CommonsHttpMessageSender sender =  new CommonsHttpMessageSender();
	    String timeOutVal = applicationProperties.getStringProperty("hcentive.socket.timeout.value.milliseconds", "10000");
	    sender.setReadTimeout(Integer.parseInt(timeOutVal));
	    sender.setConnectionTimeout(Integer.parseInt(timeOutVal));
	    return sender;
	} 
	
}
