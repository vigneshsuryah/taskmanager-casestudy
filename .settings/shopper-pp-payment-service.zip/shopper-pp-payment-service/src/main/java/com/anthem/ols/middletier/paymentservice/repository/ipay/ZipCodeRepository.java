package com.anthem.ols.middletier.paymentservice.repository.ipay;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.ols.middletier.paymentservice.entity.ZipCodeDetails;

@Repository
public interface ZipCodeRepository extends MongoRepository<ZipCodeDetails, String>{
	
	@Query(value = "{ 'zipCode' : ?0}")
	List<ZipCodeDetails> getZipCodeInformation(String zipCode);

}
