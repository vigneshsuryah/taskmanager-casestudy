package com.anthem.ols.middletier.paymentservice.rest.bo;
public enum CommunicationMethodTypeEnum {
    EMAIL,
    FAX,
    MAIL,
    NONE;
    public String value() {        return name();    }
    public static CommunicationMethodTypeEnum fromValue(String v) {        return valueOf(v);    }}
