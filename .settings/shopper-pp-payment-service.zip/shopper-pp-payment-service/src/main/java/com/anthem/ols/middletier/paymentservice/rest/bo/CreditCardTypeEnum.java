package com.anthem.ols.middletier.paymentservice.rest.bo;


public enum CreditCardTypeEnum {
	
	NONE,
	MASTERCARD,
	VISA,
	DISCOVER;
	
	public String value() {
		return name();
	}

	public static CreditCardTypeEnum fromValue(String v) {
		return valueOf(v);
	}
}