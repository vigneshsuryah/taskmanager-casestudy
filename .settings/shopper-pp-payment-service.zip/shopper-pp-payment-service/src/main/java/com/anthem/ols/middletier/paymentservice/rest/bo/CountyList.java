 package com.anthem.ols.middletier.paymentservice.rest.bo;
 
 import java.util.ArrayList;
import java.util.List;
 
 
 public class CountyList 
 {
 
   private List<County> county;
   private int countyLength;   
 
   public void setCountyLength(int countyLength) {
	this.countyLength = countyLength;
}

public County[] getCounty()
   {
    if (this.county == null) {
      return new County[0];
     }
    return (County[])(County[])this.county.toArray(new County[this.county.size()]);
   }
 
   public County getCounty(int idx)
   {
     if (this.county == null) {
       throw new IndexOutOfBoundsException();
     }
    return (County)this.county.get(idx);
   }
 
   public int getCountyLength() {
     if (this.county == null) {
       return 0;
     }
     return this.county.size();
   }
 
   public void setCounty(County[] values)
   {
     getCountyTemp().clear();
     int len = values.length;
     for (int i = 0; i < len; i++)
      this.county.add(values[i]);
   }
 
   protected List<County> getCountyTemp()
   {
     if (this.county == null) {
       this.county = new ArrayList();
     }
    return this.county;
   }
 
   public County setCounty(int idx, County value)
   {
     return (County)this.county.set(idx, value);
   }
 }

