package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;

import com.anthem.ols.middletier.paymentservice.rest.request.SMCExceptions;

public class SMCBaseResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7211461323370220840L;
	private SMCExceptions exceptions;
	public SMCExceptions getExceptions() {
		return exceptions;
	}
	public void setExceptions(SMCExceptions exceptions) {
		this.exceptions = exceptions;
	}
	
}
