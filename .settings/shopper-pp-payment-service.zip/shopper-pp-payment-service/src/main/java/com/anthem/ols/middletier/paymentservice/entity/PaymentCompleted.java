package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentCompleted {

	@Field("auth_code")
	private String authCode;
	@Field("auth_date")
	private String authDate;
	@Field("auth_resp_code")
	private String authRespCode;
	@Field("report_date")
	private String reportDate;
	@Field("submission_date")
	private Date submissionDate;
	@Field("trace_no")
	private String traceNo;
	@Field("updated_dt")
	private String updatedDt;

}
