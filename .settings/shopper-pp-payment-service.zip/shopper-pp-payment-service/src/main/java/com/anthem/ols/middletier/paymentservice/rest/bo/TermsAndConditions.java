package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;import java.util.Date;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;@JsonInclude(Include.NON_NULL)
public class TermsAndConditions implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = 3941938106165282430L;	private  int id;
    private  AnswerTypeEnum isCancelPresentCovIfEnrolled;
    private  String presentIndvCovPolicyNo;
    private  AnswerTypeEnum isPresentCovProvideBenefits;
    private  HouseholdMember[] householdMember;
    private  AuthorizedRep authorizedForPHI;
    private  AnswerTypeEnum isSendPolicyAsPaperDoc;
    private  Date thirdPartyBillingAuthExpDate;
    private  ActionTypeEnum action;
    private int householdMemberLength;
    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the isCancelPresentCovIfEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsCancelPresentCovIfEnrolled() {
        return isCancelPresentCovIfEnrolled;
    }

    /**
     * Sets the value of the isCancelPresentCovIfEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsCancelPresentCovIfEnrolled(AnswerTypeEnum value) {
        this.isCancelPresentCovIfEnrolled = value;
    }

    /**
     * Gets the value of the presentIndvCovPolicyNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPresentIndvCovPolicyNo() {
        return presentIndvCovPolicyNo;
    }

    /**
     * Sets the value of the presentIndvCovPolicyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPresentIndvCovPolicyNo(String value) {
        this.presentIndvCovPolicyNo = value;
    }

    /**
     * Gets the value of the isPresentCovProvideBenefits property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsPresentCovProvideBenefits() {
        return isPresentCovProvideBenefits;
    }

    /**
     * Sets the value of the isPresentCovProvideBenefits property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsPresentCovProvideBenefits(AnswerTypeEnum value) {
        this.isPresentCovProvideBenefits = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link HouseholdMember }
     *     
     */
    public HouseholdMember[] getHouseholdMember() {
        if (this.householdMember == null) {
            return new HouseholdMember[ 0 ] ;
        }
        HouseholdMember[] retVal = new HouseholdMember[this.householdMember.length] ;
        System.arraycopy(this.householdMember, 0, retVal, 0, this.householdMember.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link HouseholdMember }
     *     
     */
    public HouseholdMember getHouseholdMember(int idx) {
        if (this.householdMember == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.householdMember[idx];
    }

    public int getHouseholdMemberLength() {
        if (this.householdMember == null) {
            return  0;
        }
        return this.householdMember.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link HouseholdMember }
     *     
     */
    public void setHouseholdMember(HouseholdMember[] values) {
        int len = values.length;
        this.householdMember = ((HouseholdMember[]) new HouseholdMember[len] );
        for (int i = 0; (i<len); i ++) {
            this.householdMember[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link HouseholdMember }
     *     
     */
    public HouseholdMember setHouseholdMember(int idx, HouseholdMember value) {
        return this.householdMember[idx] = value;
    }

    /**
     * Gets the value of the authorizedForPHI property.
     * 
     * @return
     *     possible object is
     *     {@link AuthorizedRep }
     *     
     */
    public AuthorizedRep getAuthorizedForPHI() {
        return authorizedForPHI;
    }

    /**
     * Sets the value of the authorizedForPHI property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuthorizedRep }
     *     
     */
    public void setAuthorizedForPHI(AuthorizedRep value) {
        this.authorizedForPHI = value;
    }

    /**
     * Gets the value of the isSendPolicyAsPaperDoc property.
     * 
     * @return
     *     possible object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public AnswerTypeEnum getIsSendPolicyAsPaperDoc() {
        return isSendPolicyAsPaperDoc;
    }

    /**
     * Sets the value of the isSendPolicyAsPaperDoc property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnswerTypeEnum }
     *     
     */
    public void setIsSendPolicyAsPaperDoc(AnswerTypeEnum value) {
        this.isSendPolicyAsPaperDoc = value;
    }

    /**
     * Gets the value of the thirdPartyBillingAuthExpDate property.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getThirdPartyBillingAuthExpDate() {
        return thirdPartyBillingAuthExpDate;
    }

    /**
     * Sets the value of the thirdPartyBillingAuthExpDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setThirdPartyBillingAuthExpDate(Date value) {
        this.thirdPartyBillingAuthExpDate = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link ActionTypeEnum }
     *     
     */
    public ActionTypeEnum getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionTypeEnum }
     *     
     */
    public void setAction(ActionTypeEnum value) {
        this.action = value;
    }	public void setHouseholdMemberLength(int householdMemberLength) {		this.householdMemberLength = householdMemberLength;	}

}
