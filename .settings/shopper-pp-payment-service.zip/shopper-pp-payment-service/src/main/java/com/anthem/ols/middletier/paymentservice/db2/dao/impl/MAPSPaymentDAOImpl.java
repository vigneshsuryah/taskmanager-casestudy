package com.anthem.ols.middletier.paymentservice.db2.dao.impl;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.anthem.ols.middletier.paymentservice.db2.dao.MAPSPaymentDAO;
import com.anthem.ols.middletier.paymentservice.rest.bo.AdvancedCsrSearchBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MAPSPaymentDAOImpl implements MAPSPaymentDAO {

	private static final String UMUPAY5_SP = "UMUPAY5(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?)";
	private static final String UMUPAYQ_SP = "UMUPAYQ(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	@Autowired
	private DataSource dataSourceHixius;

	protected abstract class MapsPaymentStoredProcedure extends StoredProcedure {

		protected MapsPaymentStoredProcedure(DataSource ds, String sp) {
			setDataSource(ds);
			setFunction(false);
			setSql(sp);
		}
	}

	@Override
	public Map<String, Object> getMAPSPaymentUMUPAY5(String hcid) throws DataAccessException {
		Map<String, Object> inParams = new HashMap<String, Object>();

		inParams.put("HCID", hcid);
		Map<String, Object> paymentInfo = null;
		SelectUMUPAY5Query selectUMUPAY5Query = new SelectUMUPAY5Query(dataSourceHixius);
		try {
			paymentInfo = selectUMUPAY5Query.executeSelectUMUPAY5Query(inParams);
		} catch (Exception e) {
			log.error("Maps Stored procedure Exception while pulling amount", e);
			int count = 3;
			while (count != 0) {
				try {
					paymentInfo = selectUMUPAY5Query.executeSelectUMUPAY5Query(inParams);
					count = 0;
				} catch (Exception ex) {
					if (paymentInfo == null) {
						count--;
						try {
							Thread.sleep(3000);
						} catch (InterruptedException e1) {
						}
					} else {
						count = 0;
					}
				}
			}
		}

		return paymentInfo;
	}

	protected class SelectUMUPAY5Query extends MapsPaymentStoredProcedure {

		protected SelectUMUPAY5Query(DataSource ds) {

			super(ds, UMUPAY5_SP);

			declareParameter(new SqlParameter("HCID", Types.CHAR));

			declareParameter(new SqlOutParameter("PARAMOUT", Types.CHAR));
			declareParameter(new SqlOutParameter("RETURN_STS", Types.CHAR));
			declareParameter(new SqlOutParameter("OUT_CODE", Types.SMALLINT));
			declareParameter(new SqlOutParameter("OUT_RSN", Types.CHAR));
			declareParameter(new SqlOutParameter("MED_ID", Types.CHAR));
			declareParameter(new SqlOutParameter("MED_AMT", Types.DECIMAL));
			declareParameter(new SqlOutParameter("DTL_ID", Types.CHAR));
			declareParameter(new SqlOutParameter("DTL_AMT", Types.DECIMAL));
			declareParameter(new SqlOutParameter("VSN_ID", Types.CHAR));
			declareParameter(new SqlOutParameter("VSN_AMT", Types.DECIMAL));
			declareParameter(new SqlOutParameter("LFE_ID", Types.CHAR));
			declareParameter(new SqlOutParameter("LFE_AMT", Types.DECIMAL));

		}

		protected SelectUMUPAY5Query(String procedureName, List<SqlParameter> params, DataSource ds) {
			super(ds, procedureName);

			for (SqlParameter param : params) {
				declareParameter(param);
			}
		}

		@SuppressWarnings("unchecked")
		public Map<String, Object> executeSelectUMUPAY5Query(Map inParams) {

			@SuppressWarnings({ "unchecked", "rawtypes" })
			Map outParams = execute(inParams);

			Map<String, Object> returnVal = new HashMap<String, Object>();

			returnVal.putAll(outParams);

			return returnVal;
		}
	}
	
	
	@Override
    public Map<String, Object> getMAPSPaymentUMUPAYQ(AdvancedCsrSearchBean csrSearch) throws DataAccessException {
    	 Map<String, Object> inParams = new HashMap<String, Object>();
         
    	 // Set inParams
         inParams.put("APPLNEID", csrSearch.getApplneId());
         inParams.put("HCID",csrSearch.getHcid());
         inParams.put("FNME", csrSearch.getFnme());
         inParams.put("LNME", csrSearch.getLnme());
         inParams.put("MNME", csrSearch.getMnme());
         inParams.put("BDATE", csrSearch.getBdate());
         inParams.put("STATE", csrSearch.getState());
         
    	SelectUMUPAYQQuery selectUMUPAYQQuery = new SelectUMUPAYQQuery(dataSourceHixius);
        Map<String, Object> paymentInfo = selectUMUPAYQQuery.executeSelectUMUPAYQQuery(inParams);

        return paymentInfo;
    }


    protected class SelectUMUPAYQQuery extends MapsPaymentStoredProcedure {

        protected SelectUMUPAYQQuery(DataSource ds) {

            super(ds, UMUPAYQ_SP);

             
            declareParameter(new SqlParameter("APPLNEID", Types.CHAR));
            declareParameter(new SqlParameter("HCID", Types.CHAR));
            declareParameter(new SqlParameter("FNME", Types.CHAR));
            declareParameter(new SqlParameter("LNME", Types.CHAR));
            declareParameter(new SqlParameter("MNME", Types.CHAR));
            declareParameter(new SqlParameter("BDATE", Types.DATE));
            declareParameter(new SqlParameter("STATE", Types.CHAR));
            

            declareParameter(new SqlOutParameter("PARAMOUT", Types.CHAR));
            declareParameter(new SqlOutParameter("RETURN_STS", Types.CHAR));
            declareParameter(new SqlOutParameter("OUT_CODE", Types.SMALLINT));
            declareParameter(new SqlOutParameter("OUT_RSN", Types.CHAR));
        }


        protected SelectUMUPAYQQuery(String procedureName, List<SqlParameter> params, DataSource ds) {
            super(ds, procedureName);

            for (SqlParameter param : params) {
                declareParameter(param);
            }
        }

        
        
        @SuppressWarnings("unchecked")
        public Map<String, Object> executeSelectUMUPAYQQuery(Map inParams) {
           
            @SuppressWarnings({"unchecked", "rawtypes"})
            Map outParams = execute(inParams);

            Map<String, Object> returnVal = new HashMap<String, Object>();

            returnVal.putAll(outParams);

            return returnVal;
        }
    }

}
