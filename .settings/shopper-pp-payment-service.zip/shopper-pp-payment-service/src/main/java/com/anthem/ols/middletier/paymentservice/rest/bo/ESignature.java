package com.anthem.ols.middletier.paymentservice.rest.bo;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ESignature implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8389417581869471807L;

	private int id;

	private String firstName;

	private String lastName;

	private String mi;

	private String firstNameConfirm;

	private String lastNameConfirm;

	private String miConfirm;

	private String voiceId;

	private String city;

	private String state;

	private Date signatureDate;

	private String county;

	private AnswerTypeEnum isAgreeWithAgreement;

	private AnswerTypeEnum isAgreeToAuthorizeCC;

	private AnswerTypeEnum isReadCompletedApp;

	private AnswerTypeEnum isReadUnderstandEnrollForm;

	private AnswerTypeEnum isReadBindingArbitration;

	private AnswerTypeEnum isReadMedSuppGuaranteeIssue;

	private AnswerTypeEnum isAgreeToAuthorizeABD;

	private AnswerTypeEnum isAgreeToProvideOriginalApp;

	private AnswerTypeEnum isAssistApplicantSubmitApp;

	private AnswerTypeEnum isNoIterationsWithApplicant;

	private AnswerTypeEnum isAgreeToAuthorizePHI;

	private AnswerTypeEnum isGiveMedicareGuide;

	private ActionTypeEnum action;

	private String eSigInitial;

	private AnswerTypeEnum isTranslatedAppContent;

	private AnswerTypeEnum isDisclosedByApplicant;

	private AnswerTypeEnum isTranslatedAppUnderstandings;

	private AnswerTypeEnum isAgreeToWaitingPeriod;

	private AnswerTypeEnum isAgreeToProvideWetSignature;

	private AnswerTypeEnum isAgreeToElectronicSignature;

	private AnswerTypeEnum isAttestToBOGOAnswers;

	private AnswerTypeEnum isMeetBOGODefinitions;

	private AnswerTypeEnum isAgreeToBindingArbitration;

	private AnswerTypeEnum isAgreeToHIPAA;

	private AnswerTypeEnum isAgreeToHIPAATerm;
	
	private AnswerTypeEnum isReadAndAgreeToReplOfIns;
	
	private AnswerTypeEnum isAgreeAndReadPlanDetails;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMi() {
		return mi;
	}

	public void setMi(String mi) {
		this.mi = mi;
	}

	public String getFirstNameConfirm() {
		return firstNameConfirm;
	}

	public void setFirstNameConfirm(String firstNameConfirm) {
		this.firstNameConfirm = firstNameConfirm;
	}

	public String getLastNameConfirm() {
		return lastNameConfirm;
	}

	public void setLastNameConfirm(String lastNameConfirm) {
		this.lastNameConfirm = lastNameConfirm;
	}

	public String getMiConfirm() {
		return miConfirm;
	}

	public void setMiConfirm(String miConfirm) {
		this.miConfirm = miConfirm;
	}

	public String getVoiceId() {
		return voiceId;
	}

	public void setVoiceId(String voiceId) {
		this.voiceId = voiceId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getSignatureDate() {
		return signatureDate;
	}

	public void setSignatureDate(Date signatureDate) {
		this.signatureDate = signatureDate;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public AnswerTypeEnum getIsAgreeWithAgreement() {
		return isAgreeWithAgreement;
	}

	public void setIsAgreeWithAgreement(AnswerTypeEnum isAgreeWithAgreement) {
		this.isAgreeWithAgreement = isAgreeWithAgreement;
	}

	public AnswerTypeEnum getIsAgreeToAuthorizeCC() {
		return isAgreeToAuthorizeCC;
	}

	public void setIsAgreeToAuthorizeCC(AnswerTypeEnum isAgreeToAuthorizeCC) {
		this.isAgreeToAuthorizeCC = isAgreeToAuthorizeCC;
	}

	public AnswerTypeEnum getIsReadCompletedApp() {
		return isReadCompletedApp;
	}

	public void setIsReadCompletedApp(AnswerTypeEnum isReadCompletedApp) {
		this.isReadCompletedApp = isReadCompletedApp;
	}

	public AnswerTypeEnum getIsReadUnderstandEnrollForm() {
		return isReadUnderstandEnrollForm;
	}

	public void setIsReadUnderstandEnrollForm(
			AnswerTypeEnum isReadUnderstandEnrollForm) {
		this.isReadUnderstandEnrollForm = isReadUnderstandEnrollForm;
	}

	public AnswerTypeEnum getIsReadBindingArbitration() {
		return isReadBindingArbitration;
	}

	public void setIsReadBindingArbitration(AnswerTypeEnum isReadBindingArbitration) {
		this.isReadBindingArbitration = isReadBindingArbitration;
	}

	public AnswerTypeEnum getIsReadMedSuppGuaranteeIssue() {
		return isReadMedSuppGuaranteeIssue;
	}

	public void setIsReadMedSuppGuaranteeIssue(
			AnswerTypeEnum isReadMedSuppGuaranteeIssue) {
		this.isReadMedSuppGuaranteeIssue = isReadMedSuppGuaranteeIssue;
	}

	public AnswerTypeEnum getIsAgreeToAuthorizeABD() {
		return isAgreeToAuthorizeABD;
	}

	public void setIsAgreeToAuthorizeABD(AnswerTypeEnum isAgreeToAuthorizeABD) {
		this.isAgreeToAuthorizeABD = isAgreeToAuthorizeABD;
	}

	public AnswerTypeEnum getIsAgreeToProvideOriginalApp() {
		return isAgreeToProvideOriginalApp;
	}

	public void setIsAgreeToProvideOriginalApp(
			AnswerTypeEnum isAgreeToProvideOriginalApp) {
		this.isAgreeToProvideOriginalApp = isAgreeToProvideOriginalApp;
	}

	public AnswerTypeEnum getIsAssistApplicantSubmitApp() {
		return isAssistApplicantSubmitApp;
	}

	public void setIsAssistApplicantSubmitApp(
			AnswerTypeEnum isAssistApplicantSubmitApp) {
		this.isAssistApplicantSubmitApp = isAssistApplicantSubmitApp;
	}

	public AnswerTypeEnum getIsNoIterationsWithApplicant() {
		return isNoIterationsWithApplicant;
	}

	public void setIsNoIterationsWithApplicant(
			AnswerTypeEnum isNoIterationsWithApplicant) {
		this.isNoIterationsWithApplicant = isNoIterationsWithApplicant;
	}

	public AnswerTypeEnum getIsAgreeToAuthorizePHI() {
		return isAgreeToAuthorizePHI;
	}

	public void setIsAgreeToAuthorizePHI(AnswerTypeEnum isAgreeToAuthorizePHI) {
		this.isAgreeToAuthorizePHI = isAgreeToAuthorizePHI;
	}

	public AnswerTypeEnum getIsGiveMedicareGuide() {
		return isGiveMedicareGuide;
	}

	public void setIsGiveMedicareGuide(AnswerTypeEnum isGiveMedicareGuide) {
		this.isGiveMedicareGuide = isGiveMedicareGuide;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String geteSigInitial() {
		return eSigInitial;
	}

	public void seteSigInitial(String eSigInitial) {
		this.eSigInitial = eSigInitial;
	}

	public AnswerTypeEnum getIsTranslatedAppContent() {
		return isTranslatedAppContent;
	}

	public void setIsTranslatedAppContent(AnswerTypeEnum isTranslatedAppContent) {
		this.isTranslatedAppContent = isTranslatedAppContent;
	}

	public AnswerTypeEnum getIsDisclosedByApplicant() {
		return isDisclosedByApplicant;
	}

	public void setIsDisclosedByApplicant(AnswerTypeEnum isDisclosedByApplicant) {
		this.isDisclosedByApplicant = isDisclosedByApplicant;
	}

	public AnswerTypeEnum getIsTranslatedAppUnderstandings() {
		return isTranslatedAppUnderstandings;
	}

	public void setIsTranslatedAppUnderstandings(
			AnswerTypeEnum isTranslatedAppUnderstandings) {
		this.isTranslatedAppUnderstandings = isTranslatedAppUnderstandings;
	}

	public AnswerTypeEnum getIsAgreeToWaitingPeriod() {
		return isAgreeToWaitingPeriod;
	}

	public void setIsAgreeToWaitingPeriod(AnswerTypeEnum isAgreeToWaitingPeriod) {
		this.isAgreeToWaitingPeriod = isAgreeToWaitingPeriod;
	}

	public AnswerTypeEnum getIsAgreeToProvideWetSignature() {
		return isAgreeToProvideWetSignature;
	}

	public void setIsAgreeToProvideWetSignature(
			AnswerTypeEnum isAgreeToProvideWetSignature) {
		this.isAgreeToProvideWetSignature = isAgreeToProvideWetSignature;
	}

	public AnswerTypeEnum getIsAgreeToElectronicSignature() {
		return isAgreeToElectronicSignature;
	}

	public void setIsAgreeToElectronicSignature(
			AnswerTypeEnum isAgreeToElectronicSignature) {
		this.isAgreeToElectronicSignature = isAgreeToElectronicSignature;
	}

	public AnswerTypeEnum getIsAttestToBOGOAnswers() {
		return isAttestToBOGOAnswers;
	}

	public void setIsAttestToBOGOAnswers(AnswerTypeEnum isAttestToBOGOAnswers) {
		this.isAttestToBOGOAnswers = isAttestToBOGOAnswers;
	}

	public AnswerTypeEnum getIsMeetBOGODefinitions() {
		return isMeetBOGODefinitions;
	}

	public void setIsMeetBOGODefinitions(AnswerTypeEnum isMeetBOGODefinitions) {
		this.isMeetBOGODefinitions = isMeetBOGODefinitions;
	}

	public AnswerTypeEnum getIsAgreeToBindingArbitration() {
		return isAgreeToBindingArbitration;
	}

	public void setIsAgreeToBindingArbitration(
			AnswerTypeEnum isAgreeToBindingArbitration) {
		this.isAgreeToBindingArbitration = isAgreeToBindingArbitration;
	}

	public AnswerTypeEnum getIsAgreeToHIPAA() {
		return isAgreeToHIPAA;
	}

	public void setIsAgreeToHIPAA(AnswerTypeEnum isAgreeToHIPAA) {
		this.isAgreeToHIPAA = isAgreeToHIPAA;
	}

	public AnswerTypeEnum getIsAgreeToHIPAATerm() {
		return isAgreeToHIPAATerm;
	}

	public void setIsAgreeToHIPAATerm(AnswerTypeEnum isAgreeToHIPAATerm) {
		this.isAgreeToHIPAATerm = isAgreeToHIPAATerm;
	}

	public AnswerTypeEnum getIsReadAndAgreeToReplOfIns() {
		return isReadAndAgreeToReplOfIns;
	}

	public void setIsReadAndAgreeToReplOfIns(
			AnswerTypeEnum isReadAndAgreeToReplOfIns) {
		this.isReadAndAgreeToReplOfIns = isReadAndAgreeToReplOfIns;
	}

	public AnswerTypeEnum getIsAgreeAndReadPlanDetails() {
		return isAgreeAndReadPlanDetails;
	}

	public void setIsAgreeAndReadPlanDetails(
			AnswerTypeEnum isAgreeAndReadPlanDetails) {
		this.isAgreeAndReadPlanDetails = isAgreeAndReadPlanDetails;
	}

}