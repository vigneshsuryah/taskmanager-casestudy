/**
* BaseAPIResponseRS.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 03/08/2017   1.0       Cognizant      Initial Version
*/
package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;

import com.anthem.ols.middletier.paymentservice.message.Exceptions;

public class BaseAPIResponseRS implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1702126225561304777L;

	private Exceptions exceptions;
	
	/**
	 * @return the exceptions
	 */
	public Exceptions getExceptions() {
		return exceptions;
	}

	/**
	 * @param exceptions the exceptions to set
	 */
	public void setExceptions(Exceptions exceptions) {
		this.exceptions = exceptions;
	}
	
}
