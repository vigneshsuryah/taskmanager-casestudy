package com.anthem.ols.middletier.paymentservice.db2.dao;

import org.springframework.dao.DataAccessException;

import com.anthem.ols.middletier.paymentservice.rest.bo.ProductDataBean;

public interface OlsProductDAO {
	
	public ProductDataBean getProductByContractCode(String contractCode, String planYear) throws DataAccessException;
}
