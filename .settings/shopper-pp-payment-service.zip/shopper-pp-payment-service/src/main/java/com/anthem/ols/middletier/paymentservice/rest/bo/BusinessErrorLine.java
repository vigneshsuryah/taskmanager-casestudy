package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

public class BusinessErrorLine implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3927661551991089114L;

	private String code;

	private String description;

	public String getCode()
	{
		return this.code;
	}

	public void setCode(String value)
	{
		this.code = value;
	}

	public String getDescription()
	{
		return this.description;
	}

	public void setDescription(String value)
	{
		this.description = value;
	}
}
