package com.anthem.ols.middletier.paymentservice.rest.request;

import java.io.Serializable;
import java.util.List;

import com.anthem.ols.middletier.paymentservice.rest.bo.Token;


public class SaveInitialPaymentMethodRequest extends BaseRequestRS implements Serializable {

	private static final long serialVersionUID = 1L;

	private String acn;
	
	private Token token;
	
	private String partnerId;

	private String withdrawDay;

	private String paymentAmt;
	
	private String transactionDivisionCode;
	
	private List<String> paymentIdentifier;
	
	
	public String getAcn() {
		return acn;
	}

	public void setAcn(String acn) {
		this.acn = acn;
	}

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getWithdrawDay() {
		return withdrawDay;
	}

	public void setWithdrawDay(String withdrawDay) {
		this.withdrawDay = withdrawDay;
	}

	public String getPaymentAmt() {
		return paymentAmt;
	}

	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	public List<String> getPaymentIdentifier() {
		return paymentIdentifier;
	}

	public void setPaymentIdentifier(List<String> paymentIdentifier) {
		this.paymentIdentifier = paymentIdentifier;
	}

	public String getTransactionDivisionCode() {
		return transactionDivisionCode;
	}

	public void setTransactionDivisionCode(String transactionDivisionCode) {
		this.transactionDivisionCode = transactionDivisionCode;
	}
	
	
}
