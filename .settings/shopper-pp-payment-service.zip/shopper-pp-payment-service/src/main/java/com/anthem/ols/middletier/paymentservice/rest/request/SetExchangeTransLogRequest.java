package com.anthem.ols.middletier.paymentservice.rest.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SetExchangeTransLogRequest {

	private int id;
	private String exchStateCode;
	private String wLPConsumerId;
	private String exchConsumerId;
	private String requestXML;
	private String responseXML;
	private String isBusinessFault;
	private String isSystemFault;
	private String opName;
	
}
