
package com.anthem.ols.middletier.paymentservice.rest.bo;
import java.io.Serializable;

public class ValidationErrors implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -9184963938475006189L;
	private  ValidationError[] validationError;
	private int validationErrorLength;

	public ValidationError[] getValidationError() {
		if (this.validationError == null) {
            return new ValidationError[0] ;
        }
        ValidationError[] retVal = new ValidationError[this.validationError.length] ;
        System.arraycopy(this.validationError, 0, retVal, 0, this.validationError.length);
        return (retVal);
	}

	public void setValidationError(ValidationError[] values) {
		if(values!=null){
			int len = values.length;
			this.validationError = ((ValidationError[]) new ValidationError[len]);
			for (int i = 0; (i < len); i++) {
				this.validationError[i] = values[i];
			}
		} else {
			this.validationError = null;
		}
	}
	
	public int getValidationErrorLength() {
        if (this.validationError == null) {
            return  0;
        }
        return this.validationError.length;
    }

	public void setValidationErrorLength(int validationErrorLength) {
		this.validationErrorLength = validationErrorLength;
	}
}
