package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum ShopperRoleEnum {
    CONSUMER,
    AGENT,
    BROKER,
    ASSISTANT;

    public String value() {        return name();    }
    public static ShopperRoleEnum fromValue(String v) {        return valueOf(v);    }
}
