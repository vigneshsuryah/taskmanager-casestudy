package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum AccessTypeEnum {
    OWNER,
    REVIEWER,
    NOACCESS;
    public String value() {        return name();    }
    public static AccessTypeEnum fromValue(String v) {        return valueOf(v);    }}
