package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;
import java.util.List;

public class SMCResponse implements Serializable{

	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 8385267543738915315L;
	private String recipientSendId;
	private Boolean hasErrors;
	private List<String> messages;
	
	public String getRecipientSendId() {
		return recipientSendId;
	}
	public void setRecipientSendId(String recipientSendId) {
		this.recipientSendId = recipientSendId;
	}
	public Boolean getHasErrors() {
		return hasErrors;
	}
	public void setHasErrors(Boolean hasErrors) {
		this.hasErrors = hasErrors;
	}
	public List<String> getMessages() {
		return messages;
	}
	public void setMessages(List<String> messages) {
		this.messages = messages;
	}
	
}
