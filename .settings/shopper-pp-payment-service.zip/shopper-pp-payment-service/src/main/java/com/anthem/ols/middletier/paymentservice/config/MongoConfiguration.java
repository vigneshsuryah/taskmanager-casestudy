/**
 * MongoConfiguration.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ----------  -------   ------------   --------------------------------------
 * 01/08/2020  1.0       Cognizant      Initial Version
 */
package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.anthem.ols.middletier.paymentservice.utils.MongoSSLUtils;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoClientURI;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class MongoConfiguration {

	@Value("${mongodb.ipplog.uri}")
	private String ippLogDb;

	@Value("${mongodb.ipaydb.uri}")
	private String iPayDb;

	@Value("${mongodb.iwallet.uri}")
	private String iWalletDb;

	private final MongoSSLUtils mongoSSLUtils;

	@Bean(name = "ippLogFactory")
	public MongoDbFactory ippLogFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClientURI(ippLogDb, customMongoBuilder()));
	}

	@Bean(name = "ippLogTemplate")
	public MongoTemplate ippMongoTemplate() throws Exception {
		return new MongoTemplate(ippLogFactory());
	}

	public Builder customMongoBuilder() {
		MongoClientOptions.Builder builder = MongoClientOptions.builder();
		builder.sslInvalidHostNameAllowed(true);
		return builder;
	}

	@Bean(name = "iWalletTemplate")
	public MongoTemplate iWalletTemplate() throws Exception {
		return new MongoTemplate(iWalletDbFactory());
	}

	@Bean(name = "iWalletFactory")
	public MongoDbFactory iWalletDbFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClientURI(iWalletDb, mongoSSLUtils.customMongoBuilder()));
	}

	@Bean(name = "iPayDbTemplate")
	public MongoTemplate iPayDbTemplate() throws Exception {
		return new MongoTemplate(iPayDbFactory());
	}

	@Bean(name = "iPayDbFactory")
	public MongoDbFactory iPayDbFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClientURI(iPayDb, mongoSSLUtils.customMongoBuilder()));
	}
}
