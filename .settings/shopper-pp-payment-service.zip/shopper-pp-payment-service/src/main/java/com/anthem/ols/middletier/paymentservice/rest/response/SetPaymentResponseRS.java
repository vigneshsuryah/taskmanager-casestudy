package com.anthem.ols.middletier.paymentservice.rest.response;import com.anthem.ols.middletier.paymentservice.rest.bo.PaymentSelection;import com.anthem.ols.middletier.paymentservice.rest.bo.ValidationErrors;
public class SetPaymentResponseRS extends BaseResponseRS{

    /**	 * 	 */	private static final long serialVersionUID = -371294855255583093L;	private  String acn;
    private  PaymentSelection paymentSelection;
    private  ValidationErrors validationErrors;	public String getAcn() {		return acn;	}	public void setAcn(String acn) {		this.acn = acn;	}	public PaymentSelection getPaymentSelection() {		return paymentSelection;	}	public void setPaymentSelection(PaymentSelection paymentSelection) {		this.paymentSelection = paymentSelection;	}	public ValidationErrors getValidationErrors() {		return validationErrors;	}	public void setValidationErrors(ValidationErrors validationErrors) {		this.validationErrors = validationErrors;	}
}
