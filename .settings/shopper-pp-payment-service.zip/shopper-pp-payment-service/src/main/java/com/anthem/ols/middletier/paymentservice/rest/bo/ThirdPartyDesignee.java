
package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ThirdPartyDesignee implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8179746994881161553L;

	private int id;
	
	private String firstName;

	private String mi;

	private String lastName;

	private Address billingAddr;

	private ESignature eSignature;

	private ActionTypeEnum action;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMi() {
		return mi;
	}

	public void setMi(String mi) {
		this.mi = mi;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getBillingAddr() {
		return billingAddr;
	}

	public void setBillingAddr(Address billingAddr) {
		this.billingAddr = billingAddr;
	}

	public ESignature geteSignature() {
		return eSignature;
	}

	public void seteSignature(ESignature eSignature) {
		this.eSignature = eSignature;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

}