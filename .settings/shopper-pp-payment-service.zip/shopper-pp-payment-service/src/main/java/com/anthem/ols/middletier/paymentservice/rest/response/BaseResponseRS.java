package com.anthem.ols.middletier.paymentservice.rest.response;

import java.io.Serializable;

import com.anthem.ols.middletier.paymentservice.rest.bo.BusinessError;
import com.anthem.ols.middletier.paymentservice.rest.bo.SystemError;

public class BaseResponseRS implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1702126225561304777L;


	private SystemError systemError;
	
	private BusinessError businessError;

	public SystemError getSystemError() {
		return systemError;
	}

	public void setSystemError(SystemError systemError) {
		this.systemError = systemError;
	}

	public BusinessError getBusinessError() {
		return businessError;
	}

	public void setBusinessError(BusinessError businessError) {
		this.businessError = businessError;
	}
	
}
