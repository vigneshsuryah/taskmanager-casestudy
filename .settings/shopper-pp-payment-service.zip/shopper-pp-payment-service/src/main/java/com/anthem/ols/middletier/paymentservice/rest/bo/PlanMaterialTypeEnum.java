package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum PlanMaterialTypeEnum {
    NONE,
    LARGEPRINT,
    BRAILLE;

    public String value() {        return name();    }
    public static PlanMaterialTypeEnum fromValue(String v) {        return valueOf(v);    }
}
