package com.anthem.ols.middletier.paymentservice.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Plan {

	@Field("planId")
	private String planId;
	@Field("planType")
	private String planType;
	@Field("productType")
	private String productType;
	@Field("contractCode")
	private String contractCode;
	@Field("premiumAmt")
	private double premiumAmt;
	@Field("planName")
	private String planName;
	@Field("qhpid")
	private String qhpid;
	@Field("qhpvariation")
	private String qhpvariation;
	@Field("ebhflag")
	private String ebhflag;
	@Field("ratingServiceArea")
	private String ratingServiceArea;
	@Field("companyDescr")
	private String companyDescr;
	@Field("ereAppliedAPTC")
	private double ereAppliedAPTC;
}
