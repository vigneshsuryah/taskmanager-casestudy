package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class APTCAttestationPerson implements Serializable{
    

	/**
	 * 
	 */
	private static final long serialVersionUID = -6084889579043920495L;

	private int id;

    private ActionTypeEnum action;

    private String firstName;

    private String lastName;
    
    private String mi;
    
    private AnswerTypeEnum isAPTCAttestation;  
    
    private AnswerTypeEnum isAPTCReadUnderstand;
	
    private String eSigFName;
	
    private String eSigMI;
	
    private String eSigLName;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMi() {
		return mi;
	}

	public void setMi(String mi) {
		this.mi = mi;
	}  
	public AnswerTypeEnum getIsAPTCAttestation() {
		return isAPTCAttestation;
	}

	public void setIsAPTCAttestation(AnswerTypeEnum isAPTCAttestation) {
		this.isAPTCAttestation = isAPTCAttestation;
	}

	public AnswerTypeEnum getIsAPTCReadUnderstand() {
		return isAPTCReadUnderstand;
	}

	public void setIsAPTCReadUnderstand(AnswerTypeEnum isAPTCReadUnderstand) {
		this.isAPTCReadUnderstand = isAPTCReadUnderstand;
	}

	public String geteSigFName() {
		return eSigFName;
	}

	public void seteSigFName(String eSigFName) {
		this.eSigFName = eSigFName;
	}

	public String geteSigMI() {
		return eSigMI;
	}

	public void seteSigMI(String eSigMI) {
		this.eSigMI = eSigMI;
	}

	public String geteSigLName() {
		return eSigLName;
	}

	public void seteSigLName(String eSigLName) {
		this.eSigLName = eSigLName;
	}

	
}

