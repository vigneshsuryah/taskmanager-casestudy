package com.anthem.ols.middletier.paymentservice.repository.ipay;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.anthem.ols.middletier.paymentservice.entity.PaymentAppSource;

@Repository
public interface PaymentAppSourceRepository extends MongoRepository<PaymentAppSource, String> {

	@Query(value = "{ 'partner_id' : ?0}, 'agent_type' : ?1, 'app_origin_type' : ?2, 'transfer_flag' : ?3, 'agent_submitted' : ?4")
	PaymentAppSource getAppSource(String partnerId, String agentType, String appOriginType, String transferFlag,
			String agentSubmittedFlag);

}
