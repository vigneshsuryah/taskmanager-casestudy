package com.anthem.ols.middletier.paymentservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.integration.config.EnableIntegration;

@Configuration
@EnableIntegration
public class PaymentIntegrationConfig {

}
