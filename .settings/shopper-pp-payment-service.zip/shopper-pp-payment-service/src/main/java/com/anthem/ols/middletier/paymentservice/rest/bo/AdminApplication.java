package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.anthem.ols.middletier.paymentservice.domain.BaseBusinessObject;


public class AdminApplication extends BaseBusinessObject implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -7535654059600920946L;
	private  Application[] application;
    private  String[] applicationXml;
    private  Messages errorMessage;
    private int applicationLength;
    private int applicationXmlLength;
    
    /**
     * 
     * 
     * @return
     *     array of
     *     {@link Application }
     *     
     */
    public Application[] getApplication() {
        if (this.application == null) {
            return new Application[ 0 ] ;
        }
        Application[] retVal = new Application[this.application.length] ;
        System.arraycopy(this.application, 0, retVal, 0, this.application.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link Application }
     *     
     */
    public Application getApplication(int idx) {
        if (this.application == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.application[idx];
    }

    public int getApplicationLength() {
        if (this.application == null) {
            return  0;
        }
        return this.application.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link Application }
     *     
     */
    public void setApplication(Application[] values) {
        int len = values.length;
        this.application = ((Application[]) new Application[len] );
        for (int i = 0; (i<len); i ++) {
            this.application[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link Application }
     *     
     */
    public Application setApplication(int idx, Application value) {
        return this.application[idx] = value;
    }

    /**
     * 
     * 
     * @return
     *     array of
     *     {@link String }
     *     
     */
    public String[] getApplicationXml() {
        if (this.applicationXml == null) {
            return new String[ 0 ] ;
        }
        String[] retVal = new String[this.applicationXml.length] ;
        System.arraycopy(this.applicationXml, 0, retVal, 0, this.applicationXml.length);
        return (retVal);
    }

    /**
     * 
     * 
     * @return
     *     one of
     *     {@link String }
     *     
     */
    public String getApplicationXml(int idx) {
        if (this.applicationXml == null) {
            throw new IndexOutOfBoundsException();
        }
        return this.applicationXml[idx];
    }

    public int getApplicationXmlLength() {
        if (this.applicationXml == null) {
            return  0;
        }
        return this.applicationXml.length;
    }

    /**
     * 
     * 
     * @param values
     *     allowed objects are
     *     {@link String }
     *     
     */
    public void setApplicationXml(String[] values) {
        int len = values.length;
        this.applicationXml = ((String[]) new String[len] );
        for (int i = 0; (i<len); i ++) {
            this.applicationXml[i] = values[i];
        }
    }

    /**
     * 
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public String setApplicationXml(int idx, String value) {
        return this.applicationXml[idx] = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link Messages }
     *     
     */
    public Messages getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Messages }
     *     
     */
    public void setErrorMessage(Messages value) {
        this.errorMessage = value;
    }

	public void setApplicationXmlLength(int applicationXmlLength) {
		this.applicationXmlLength = applicationXmlLength;
	}

}
