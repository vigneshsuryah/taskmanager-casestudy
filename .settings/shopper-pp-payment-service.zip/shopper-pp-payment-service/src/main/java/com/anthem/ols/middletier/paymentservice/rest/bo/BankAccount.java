package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BankAccount implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1264296494285111446L;

	private int id;

	private String accountNo;

	private String confirmAcctNo;

	private String routingNo;

	private BankAcctTypeEnum accountType;

	private String bankName;

	private String accountHolderName;

	private Address bankAddress;

	private ActionTypeEnum action;

	private String checkNo;
	
	private AnswerTypeEnum isRecurring;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getConfirmAcctNo() {
		return confirmAcctNo;
	}

	public void setConfirmAcctNo(String confirmAcctNo) {
		this.confirmAcctNo = confirmAcctNo;
	}

	public String getRoutingNo() {
		return routingNo;
	}

	public void setRoutingNo(String routingNo) {
		this.routingNo = routingNo;
	}

	public BankAcctTypeEnum getAccountType() {
		return accountType;
	}

	public void setAccountType(BankAcctTypeEnum accountType) {
		this.accountType = accountType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public Address getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(Address bankAddress) {
		this.bankAddress = bankAddress;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public AnswerTypeEnum getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(AnswerTypeEnum isRecurring) {
		this.isRecurring = isRecurring;
	}
}