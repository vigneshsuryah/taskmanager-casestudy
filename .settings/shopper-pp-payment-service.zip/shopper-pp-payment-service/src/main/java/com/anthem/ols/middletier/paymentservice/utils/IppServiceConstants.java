/**
* IppServiceConstants.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 01/08/2020  1.0      Cognizant       Initial Version
*/
package com.anthem.ols.middletier.paymentservice.utils;

public interface IppServiceConstants {

	String MSG_SUCCESS = "SUCCESS";
	String MSG_BAD_REQUEST = "BAD REQUEST";
	String MSG_SERVICE_NOT_AVAILABLE = "SERVICE NOT AVAILABLE";
	String HEADER_ACCEPT = "Accept=*/*";
	String APPLICATION_TYPE_JSON = "application/json";
	String APP_PRODUCE_TYPE_1 = "application/json; charset=UTF-8";
	String APP_PRODUCE_TYPE_2 = "text/html;charset=UTF-8";
	
	String ZIPCODE_TRUE = "VALIDTZIP000";
	String ZIPCODE_TRUE_MSG = "SUCCESSFULLY FETCHED";
	String ZIPCODE_FALSE = "VALIDTZIP003";
	String ZIPCODE_FALSE_MSG = "INVALID ZIPCODE";
	String PPORT = "PPORT";
	
}
