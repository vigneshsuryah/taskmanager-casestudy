package com.anthem.ols.middletier.paymentservice.rest.bo;import java.io.Serializable;import com.fasterxml.jackson.annotation.JsonInclude;import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class Shopper implements Serializable{
    /**	 * 	 */	private static final long serialVersionUID = -932149260924797854L;	private  String userId;
    private  ShopperRoleEnum shopperRole;
    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the shopperRole property.
     * 
     * @return
     *     possible object is
     *     {@link ShopperRoleEnum }
     *     
     */
    public ShopperRoleEnum getShopperRole() {
        return shopperRole;
    }

    /**
     * Sets the value of the shopperRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShopperRoleEnum }
     *     
     */
    public void setShopperRole(ShopperRoleEnum value) {
        this.shopperRole = value;
    }

}
