package com.anthem.ols.middletier.paymentservice.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayerId {

	@Field("type")
	private String type;
	@Field("id")
	private String id;

}
