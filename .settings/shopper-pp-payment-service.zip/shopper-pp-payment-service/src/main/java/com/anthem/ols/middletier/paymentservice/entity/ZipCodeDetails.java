package com.anthem.ols.middletier.paymentservice.entity;

import lombok.Getter;
import lombok.Setter;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@Document(collection = "geography")
public class ZipCodeDetails {

	@Id
	public ObjectId _id;

	@Field("zip_code")
	private String zipCode;
	@Field("state_code")
	private String stateCode;
	@Field("longitude")
	private String longitude;
	@Field("latitude")
	private String latitude;
	@Field("county_name")
	private String countyName;
	@Field("time_zone")
	private String timeZone;
	@Field("gmt_offset")
	private String gmtOffset;
	@Field("daylight_saving_flag")
	private String daylightSavingFlag;
	@Field("county_code")
	private String countyCode;
	
}
