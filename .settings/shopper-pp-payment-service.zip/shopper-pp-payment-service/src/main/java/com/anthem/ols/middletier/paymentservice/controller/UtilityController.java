/**
* UtilityController.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 01/08/2020  1.0      Cognizant       Initial Version
*/
package com.anthem.ols.middletier.paymentservice.controller;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.anthem.ols.middletier.paymentservice.config.ApplicationProperties;
import com.anthem.ols.middletier.paymentservice.request.LoggingChangeRequest;
import com.anthem.ols.middletier.paymentservice.response.LoggingChangeResponse;
import com.anthem.ols.middletier.paymentservice.utils.IppServiceConstants;

@Controller
public class UtilityController implements IppServiceConstants {
	private static final Logger LOGGER = LoggerFactory.getLogger(UtilityController.class);

	@Autowired
	private ApplicationProperties applicationProperties;
	
	@Autowired
	private ResourceLoader resourceLoader;
	
	@RequestMapping(value = "changeMessageBundlePropsValue", method = RequestMethod.POST, headers = HEADER_ACCEPT, consumes = {
			APPLICATION_TYPE_JSON }, produces = { APP_PRODUCE_TYPE_1, APP_PRODUCE_TYPE_2 })
	public @ResponseBody LoggingChangeResponse changeMessageBundlePropsValue(
			@RequestBody LoggingChangeRequest request) {
		LoggingChangeResponse response = new LoggingChangeResponse();
		response.setChangeStatus("Value Not Changed. Error Occured.");
		try {
			String key = request.getPropsKey();
			String value = request.getPropsValue();
			LOGGER.info("Inside changeMessageBundlePropsValue() of IPPService : key and value changed");

			String path = "classpath:application.properties";
			Properties props = new Properties();

			//FileInputStream configStream = new FileInputStream(path);
			Resource resource = resourceLoader.getResource(path);
	        InputStream configStream = resource.getInputStream();
			props.load(configStream);
			configStream.close();

			String existingValue = props.getProperty(key, "NOTFOUND");
			if (existingValue != null && !existingValue.isEmpty() && !existingValue.equals("NOTFOUND")) {
				props.setProperty(key, value);
				FileOutputStream output = new FileOutputStream(path);
				props.store(output, "Archaius - Dynamic Loading Property file.");
				output.close();
				response.setChangeStatus("Value Changed");
				applicationProperties.updatePropertiesFile();
			} else {
				response.setChangeStatus("New Key - Not Added");
			}
		} catch (Exception e) {
			LOGGER.error("Exception in changeMessageBundlePropsValue() of IPPService : " + e);
		}
		return response;
	}

}
