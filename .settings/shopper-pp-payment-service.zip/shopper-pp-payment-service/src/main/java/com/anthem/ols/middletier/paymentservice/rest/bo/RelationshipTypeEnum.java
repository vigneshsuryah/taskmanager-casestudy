package com.anthem.ols.middletier.paymentservice.rest.bo;
public enum RelationshipTypeEnum {
    APPLICANT,
    SPOUSE,
    DOMESTICPARTNER,        CHILD,		STEPCHILD,		OTHER,
    NONE;
    public String value() {        return name();    }
    public static RelationshipTypeEnum fromValue(String v) {        return valueOf(v);    }}
