package com.anthem.ols.middletier.paymentservice.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.anthem.ols.middletier.paymentservice.rest.bo.Plan;
import com.anthem.ols.middletier.paymentservice.rest.bo.SearchPayment;

@JsonInclude(Include.NON_NULL)
public class SearchPaymentResponseRS extends BaseResponseRS{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3179485125162811260L;
	private SearchPayment[] payments;
	private int paymentsLength;
	
	public SearchPayment[] getPayments() {
        if (this.payments == null) {
			return new SearchPayment[0];
		}
        SearchPayment[] retVal = new SearchPayment[this.payments.length];
		System.arraycopy(this.payments, 0, retVal, 0,
				this.payments.length);
		return (retVal);
	}

	public void setPayments(SearchPayment[] values) {
        if (values != null) {
			int len = values.length;
			this.payments = ((SearchPayment[]) new SearchPayment[len]);
			for (int i = 0; (i < len); i++) {
				this.payments[i] = values[i];
			}
		} else {
			this.payments = null;
		}
	}
	
	public int getPaymentsLength() {
        if (this.payments == null) {
            return  0;
        }
        return this.payments.length;
    }

	public void setPaymentsLength(int paymentsLength) {
		this.paymentsLength = paymentsLength;
	}
	
}
