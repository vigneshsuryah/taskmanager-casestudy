package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

public class Plan implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3843624495493327369L;

	private int id;

	private String planId;

	private PlanTypeEnum planType;

	private ProductTypeEnum productType;

	private ActionTypeEnum action;

	private String contractCode;

	private double premiumAmt;

	private String planName;

	private AnswerTypeEnum isExpired;

	private AnswerTypeEnum eBHFlag;
	
	private AnswerTypeEnum onExchangeFlag;

	private String qHPId;
	
	private String qHPVariation;
	
	private String ratingServiceArea;
	
	private String companyDescr;

	private double ereAppliedAPTC;
	
	private String exchPlanId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public PlanTypeEnum getPlanType() {
		return planType;
	}

	public void setPlanType(PlanTypeEnum planType) {
		this.planType = planType;
	}

	public ProductTypeEnum getProductType() {
		return productType;
	}

	public void setProductType(ProductTypeEnum productType) {
		this.productType = productType;
	}

	public ActionTypeEnum getAction() {
		return action;
	}

	public void setAction(ActionTypeEnum action) {
		this.action = action;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	public double getPremiumAmt() {
		return premiumAmt;
	}

	public void setPremiumAmt(double premiumAmt) {
		this.premiumAmt = premiumAmt;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public AnswerTypeEnum getIsExpired() {
		return isExpired;
	}

	public void setIsExpired(AnswerTypeEnum isExpired) {
		this.isExpired = isExpired;
	}

	public AnswerTypeEnum geteBHFlag() {
		return eBHFlag;
	}

	public void seteBHFlag(AnswerTypeEnum eBHFlag) {
		this.eBHFlag = eBHFlag;
	}

	public AnswerTypeEnum getOnExchangeFlag() {
		return onExchangeFlag;
	}

	public void setOnExchangeFlag(AnswerTypeEnum onExchangeFlag) {
		this.onExchangeFlag = onExchangeFlag;
	}

	public String getqHPId() {
		return qHPId;
	}

	public void setqHPId(String qHPId) {
		this.qHPId = qHPId;
	}

	public String getqHPVariation() {
		return qHPVariation;
	}

	public void setqHPVariation(String qHPVariation) {
		this.qHPVariation = qHPVariation;
	}

	public String getRatingServiceArea() {
		return ratingServiceArea;
	}

	public void setRatingServiceArea(String ratingServiceArea) {
		this.ratingServiceArea = ratingServiceArea;
	}

	public String getCompanyDescr() {
		return companyDescr;
	}

	public void setCompanyDescr(String companyDescr) {
		this.companyDescr = companyDescr;
	}

	public double getEreAppliedAPTC() {
		return ereAppliedAPTC;
	}

	public void setEreAppliedAPTC(double ereAppliedAPTC) {
		this.ereAppliedAPTC = ereAppliedAPTC;
	}

	public String getExchPlanId() {
		return exchPlanId;
	}

	public void setExchPlanId(String exchPlanId) {
		this.exchPlanId = exchPlanId;
	}

}