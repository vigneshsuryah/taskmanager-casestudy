/**
 * 
 */
package com.anthem.ols.middletier.paymentservice.exception;



/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author rishi.tank
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SystemException extends RuntimeException {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private SystemError systemError;

	/** 
	 * @return the systemError
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SystemError getSystemError() {
		// begin-user-code
		return systemError;
		// end-user-code
	}

	/** 
	 * @param systemError the systemError to set
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSystemError(SystemError systemError) {
		// begin-user-code
		this.systemError = systemError;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param message
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SystemException(String message) {
		// begin-user-code
		// TODO Auto-generated constructor stub
		super(message);
		// end-user-code
	}
	
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param message
	 * @param cause
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SystemException(String message, Throwable cause) {
		// begin-user-code
		// TODO Auto-generated constructor stub
		super(message, cause);
		// end-user-code
	}
}