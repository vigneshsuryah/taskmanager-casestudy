/**
* PaymentException.java
*
*
* Modification History
*
* Date         Version   Developer      Description
* ----------   -------   ------------   --------------------------------------
* 03/08/2017   1.0       Cognizant      Initial Version
*/
package com.anthem.ols.middletier.paymentservice.rest.exception;

import java.io.Serializable;

public class PaymentException extends Exception implements Serializable
{	
	
	private static final long serialVersionUID = 801004911005017016L;
	private String errorCode;
	private String errorMessage;
	private int returnStatus;
	private Throwable exception;
	private String operationName;
	
	public PaymentException(String errorCode, String errorMessage, int returnStatus)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.returnStatus = returnStatus;
	}
	
	public PaymentException(String errorCode, String errorMessage, int returnStatus, String opName)
	{
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.returnStatus = returnStatus;
		this.operationName = opName;
	}

	public PaymentException()
	{

	}

	public PaymentException(String message)
	{
		this.errorMessage = message;
	}

	public PaymentException(Throwable exception, String message)
	{
		this.errorMessage = message;
		this.exception =exception;
	}
	
	public String getErrorCode()
	{
		return errorCode;
	}

	public void setErrorCode(String errorCode)
	{
		this.errorCode = errorCode;
	}

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
	
	public int getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(int returnStatus) {
		this.returnStatus = returnStatus;
	}

	public Throwable getException()
	{
		return exception;
	}

	public void setException(Throwable exception)
	{
		this.exception = exception;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
}