package com.anthem.ols.middletier.paymentservice.exception;

import com.anthem.ols.middletier.paymentservice.domain.SystemErrorCodeEnum;

import java.io.Serializable;
import java.util.List;

public class SystemError implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6551441248474089502L;
	private SystemErrorCodeEnum code;
	private String description;
	private List<String> trace;
	public SystemErrorCodeEnum getCode() {
		return code;
	}
	public void setCode(SystemErrorCodeEnum code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getTrace() {
		return trace;
	}
	public void setTrace(List<String> trace) {
		this.trace = trace;
	}

}
