package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Applicant implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 4795269100289481616L;

	private  int id;

    private  int memberCode;

    private  Demographic demographic;

    private  AnswerTypeEnum isBillingAddrSameAsHomeAddr;

    private  Address[] address;

    private  ESignature eSignature;

    private  PlanSelection planSelection;

    private  AnswerTypeEnum isHavePCP;

    private  Provider provider;

    private  PriorCoverage[] priorCoverage;

    private  Integer age;

    private  ActionTypeEnum action;

    private  String rateType;

    private  String diffLastNameExplanation;

    private  AnswerTypeEnum isInsuredByAnthem;
    
    private  String isToMeetEHP;

    private  String hCID;

    private  AnswerTypeEnum isExistingPatient;
    
    private  String exchAssignedApplicantId;

    private  PolicyMember policyMember;

    private  ApplicantEligibility applicantEligibility;
 	
	 private  AnswerTypeEnum useFullAPTCAmtFlag;
	 
	 private  AnswerTypeEnum aPTCAttestationFlag;
	 
	 private  String relationshipToSubsCode;
	 
	 private  int existingPolicyId;
	 
	 private long sequenceNo;
	 
	 private  AnswerTypeEnum isFinancialAssistance;
	 
	 private  AnswerTypeEnum isStudent;
	 
	 private  String applicantRefName;

	 private String salesForceId;
	 
	 private int addressLength;
	 
	 private int priorCoverageLength;

	/**

     * Gets the value of the id property.

     * 

     */

    public int getId() {

        return id;

    }



    /**

     * Sets the value of the id property.

     * 

     */

    public void setId(int value) {

        this.id = value;

    }


    
    public String getHCID() {
		return hCID;
	}



	public void setHCID(String hcid) {
		hCID = hcid;
	}

    /**

     * Gets the value of the memberCode property.

     * 

     */

    public int getMemberCode() {

        return memberCode;

    }



    /**

     * Sets the value of the memberCode property.

     * 

     */

    public void setMemberCode(int value) {

        this.memberCode = value;

    }



    /**

     * Gets the value of the demographic property.

     * 

     * @return

     *     possible object is

     *     {@link Demographic }

     *     

     */

    public Demographic getDemographic() {

        return demographic;

    }



    /**

     * Sets the value of the demographic property.

     * 

     * @param value

     *     allowed object is

     *     {@link Demographic }

     *     

     */

    public void setDemographic(Demographic value) {

        this.demographic = value;

    }



    /**

     * Gets the value of the isBillingAddrSameAsHomeAddr property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsBillingAddrSameAsHomeAddr() {

        return isBillingAddrSameAsHomeAddr;

    }



    /**

     * Sets the value of the isBillingAddrSameAsHomeAddr property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsBillingAddrSameAsHomeAddr(AnswerTypeEnum value) {

        this.isBillingAddrSameAsHomeAddr = value;

    }



    /**

     * 

     * 

     * @return

     *     array of

     *     {@link Address }

     *     

     */

    public Address[] getAddress() {

        if (this.address == null) {

            return new Address[ 0 ] ;

        }

        Address[] retVal = new Address[this.address.length] ;

        System.arraycopy(this.address, 0, retVal, 0, this.address.length);

        return (retVal);

    }



    /**

     * 

     * 

     * @return

     *     one of

     *     {@link Address }

     *     

     */

    public Address getAddress(int idx) {

        if (this.address == null) {

            throw new IndexOutOfBoundsException();

        }

        return this.address[idx];

    }



    public int getAddressLength() {

        if (this.address == null) {

            return  0;

        }

        return this.address.length;

    }



    /**

     * 

     * 

     * @param values

     *     allowed objects are

     *     {@link Address }

     *     

     */

    public void setAddress(Address[] values) {

        int len = values.length;

        this.address = ((Address[]) new Address[len] );

        for (int i = 0; (i<len); i ++) {

            this.address[i] = values[i];

        }

    }



    /**

     * 

     * 

     * @param value

     *     allowed object is

     *     {@link Address }

     *     

     */

    public Address setAddress(int idx, Address value) {

        return this.address[idx] = value;

    }



    /**

     * Gets the value of the eSignature property.

     * 

     * @return

     *     possible object is

     *     {@link ESignature }

     *     

     */

    public ESignature getESignature() {

        return eSignature;

    }



    /**

     * Sets the value of the eSignature property.

     * 

     * @param value

     *     allowed object is

     *     {@link ESignature }

     *     

     */

    public void setESignature(ESignature value) {

        this.eSignature = value;

    }



    /**

     * Gets the value of the planSelection property.

     * 

     * @return

     *     possible object is

     *     {@link PlanSelection }

     *     

     */

    public PlanSelection getPlanSelection() {

        return planSelection;

    }



    /**

     * Sets the value of the planSelection property.

     * 

     * @param value

     *     allowed object is

     *     {@link PlanSelection }

     *     

     */

    public void setPlanSelection(PlanSelection value) {

        this.planSelection = value;

    }



    /**

     * Gets the value of the isHavePCP property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsHavePCP() {

        return isHavePCP;

    }



    /**

     * Sets the value of the isHavePCP property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsHavePCP(AnswerTypeEnum value) {

        this.isHavePCP = value;

    }



    /**

     * Gets the value of the provider property.

     * 

     * @return

     *     possible object is

     *     {@link Provider }

     *     

     */

    public Provider getProvider() {

        return provider;

    }



    /**

     * Sets the value of the provider property.

     * 

     * @param value

     *     allowed object is

     *     {@link Provider }

     *     

     */

    public void setProvider(Provider value) {

        this.provider = value;

    }



    /**

     * 

     * 

     * @return

     *     array of

     *     {@link PriorCoverage }

     *     

     */

    public PriorCoverage[] getPriorCoverage() {

        if (this.priorCoverage == null) {

            return new PriorCoverage[ 0 ] ;

        }

        PriorCoverage[] retVal = new PriorCoverage[this.priorCoverage.length] ;

        System.arraycopy(this.priorCoverage, 0, retVal, 0, this.priorCoverage.length);

        return (retVal);

    }



    /**

     * 

     * 

     * @return

     *     one of

     *     {@link PriorCoverage }

     *     

     */

    public PriorCoverage getPriorCoverage(int idx) {

        if (this.priorCoverage == null) {

            throw new IndexOutOfBoundsException();

        }

        return this.priorCoverage[idx];

    }



    public int getPriorCoverageLength() {

        if (this.priorCoverage == null) {

            return  0;

        }

        return this.priorCoverage.length;

    }



    /**

     * 

     * 

     * @param values

     *     allowed objects are

     *     {@link PriorCoverage }

     *     

     */

    public void setPriorCoverage(PriorCoverage[] values) {

        if(values!=null){
	    	int len = values.length;
	        
	        this.priorCoverage = ((PriorCoverage[]) new PriorCoverage[len] );
	
	        for (int i = 0; (i<len); i ++) {
	
	            this.priorCoverage[i] = values[i];
	
	        }
        }else {
        	this.priorCoverage = null;
        }

    }



    /**

     * 

     * 

     * @param value

     *     allowed object is

     *     {@link PriorCoverage }

     *     

     */

    public PriorCoverage setPriorCoverage(int idx, PriorCoverage value) {

        return this.priorCoverage[idx] = value;

    }


    



    /**

     * Gets the value of the age property.

     * 

     * @return

     *     possible object is

     *     {@link Integer }

     *     

     */

    public Integer getAge() {

        return age;

    }



    /**

     * Sets the value of the age property.

     * 

     * @param value

     *     allowed object is

     *     {@link Integer }

     *     

     */

    public void setAge(Integer value) {

        this.age = value;

    }



    /**

     * Gets the value of the action property.

     * 

     * @return

     *     possible object is

     *     {@link ActionTypeEnum }

     *     

     */

    public ActionTypeEnum getAction() {

        return action;

    }



    /**

     * Sets the value of the action property.

     * 

     * @param value

     *     allowed object is

     *     {@link ActionTypeEnum }

     *     

     */

    public void setAction(ActionTypeEnum value) {

        this.action = value;

    }



    /**

     * Gets the value of the rateType property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getRateType() {

        return rateType;

    }



    /**

     * Sets the value of the rateType property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setRateType(String value) {

        this.rateType = value;

    }


    /**

     * Gets the value of the diffLastNameExplanation property.

     * 

     * @return

     *     possible object is

     *     {@link String }

     *     

     */

    public String getDiffLastNameExplanation() {

        return diffLastNameExplanation;

    }



    /**

     * Sets the value of the diffLastNameExplanation property.

     * 

     * @param value

     *     allowed object is

     *     {@link String }

     *     

     */

    public void setDiffLastNameExplanation(String value) {

        this.diffLastNameExplanation = value;

    }



    /**

     * Gets the value of the isInsuredByAnthem property.

     * 

     * @return

     *     possible object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public AnswerTypeEnum getIsInsuredByAnthem() {

        return isInsuredByAnthem;

    }



    /**

     * Sets the value of the isInsuredByAnthem property.

     * 

     * @param value

     *     allowed object is

     *     {@link AnswerTypeEnum }

     *     

     */

    public void setIsInsuredByAnthem(AnswerTypeEnum value) {

        this.isInsuredByAnthem = value;

    }
    
    
    public String getIsToMeetEHP() {
		return isToMeetEHP;
	}



	public void setIsToMeetEHP(String isToMeetEHP) {
		this.isToMeetEHP = isToMeetEHP;
	}


 
	
	public AnswerTypeEnum getIsExistingPatient() {
		return isExistingPatient;
	}



	public void setIsExistingPatient(AnswerTypeEnum isExistingPatient) {
		this.isExistingPatient = isExistingPatient;
	}
	
	public String getExchAssignedApplicantId() {
		return exchAssignedApplicantId;
	}



	public void setExchAssignedApplicantId(String exchAssignedApplicantId) {
		this.exchAssignedApplicantId = exchAssignedApplicantId;
	}
	
	public PolicyMember getPolicyMember() {
		return policyMember;
	}



	public void setPolicyMember(PolicyMember policyMember) {
		this.policyMember = policyMember;
	}
	 
	public ApplicantEligibility getApplicantEligibility() {
		return applicantEligibility;
	}



	public void setApplicantEligibility(ApplicantEligibility applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	} 
	
	public AnswerTypeEnum getUseFullAPTCAmtFlag() {
		return useFullAPTCAmtFlag;
	}



	public void setUseFullAPTCAmtFlag(AnswerTypeEnum useFullAPTCAmtFlag) {
		this.useFullAPTCAmtFlag = useFullAPTCAmtFlag;
	}



	public AnswerTypeEnum getaPTCAttestationFlag() {
		return aPTCAttestationFlag;
	}



	public void setaPTCAttestationFlag(AnswerTypeEnum aPTCAttestationFlag) {
		this.aPTCAttestationFlag = aPTCAttestationFlag;
	}



	public String getRelationshipToSubsCode() {
		return relationshipToSubsCode;
	}



	public void setRelationshipToSubsCode(String relationshipToSubsCode) {
		this.relationshipToSubsCode = relationshipToSubsCode;
	}

	public int getExistingPolicyId() {
		return existingPolicyId;
	}



	public void setExistingPolicyId(int existingPolicyId) {
		this.existingPolicyId = existingPolicyId;
	}



	public long getSequenceNo() {
		return sequenceNo;
	}



	public void setSequenceNo(long sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	
	public AnswerTypeEnum getIsFinancialAssistance() {
		return isFinancialAssistance;
	}



	public void setIsFinancialAssistance(AnswerTypeEnum isFinancialAssistance) {
		this.isFinancialAssistance = isFinancialAssistance;
	}



	public AnswerTypeEnum getIsStudent() {
		return isStudent;
	}



	public void setIsStudent(AnswerTypeEnum isStudent) {
		this.isStudent = isStudent;
	}

	
	
	
	public String getApplicantRefName() {
		return applicantRefName;
	}



	public void setApplicantRefName(String applicantRefName) {
		this.applicantRefName = applicantRefName;
	}



	public String getSalesForceId() {
		return salesForceId;
	}



	public void setSalesForceId(String salesForceId) {
		this.salesForceId = salesForceId;
	}



	public void setPriorCoverageLength(int priorCoverageLength) {
		this.priorCoverageLength = priorCoverageLength;
	}



	public void setAddressLength(int addressLength) {
		this.addressLength = addressLength;
	}


}