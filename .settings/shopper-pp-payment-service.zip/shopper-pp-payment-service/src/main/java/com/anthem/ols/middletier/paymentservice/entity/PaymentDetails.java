package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import com.anthem.ols.middletier.paymentservice.rest.bo.AnswerTypeEnum;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document(collection = "initial_payment_details")
public class PaymentDetails {

	@Id
	public ObjectId _id;

	@Field("acn")
	private String acn;
	@Field("applicant_firstname")
	private String applicantFirstName;
	@Field("applicant_middlename")
	private String applicantMiddleName;
	@Field("applicant_lastname")
	private String applicantLastName;
	@Field("application_version")
	private String applicationVersion;
	@Field("member_code")
	private String memberCode;
	@Field("brand_name")
	private String brandName;
	@Field("relationship")
	private String relationship;
	@Field("date_of_birth")
	private String dateOfBirth;
	@Field("system")
	private String system;
	@Field("legal_entity")
	private String legalEntity;
	@Field("market_segment")
	private String marketSegment;
	@Field("division_code")
	private String divisionCode;
	@Field("transaction_division_code")
	private String transactionDivisionCode;
	@Field("settle_amount")
	private double settleAmount;
	@Field("state")
	private String state;
	@Field("hcid")
	private String hcid;
	@Field("langPref")
	private String langPref;
	@Field("partnerid")
	private String partnerId;
	@Field("exchsubscriberid")
	private String exchSubscriberId;
	@Field("exchaptc_amt")
	private String exchaptcAmt;
	@Field("exchtransactionid")
	private String exchTransactionId;
	@Field("exchconsumerid")
	private String exchConsumerId;
	@Field("ip_address")
	private String ipAddress;
	@Field("wlpconsumer_id")
	private String wlpConsumerId;
	@Field("applicationType")
	private String applicationType;
	@Field("user_role")
	private String userRole;
	@Field("access_type")
	private String accessType;
	@Field("user_id")
	private String userId;
	@Field("creator_role")
	private String creatorRole;
	@Field("app_source")
	private String appSource;
	@Field("req_eff_date")
	private Date reqEffDate;
	@Field("payer_id")
	private PayerId payerId;
	@Field("payment_method")
	private PaymentMethod paymentMethod;
	@Field("transactions")
	private Transaction[] transactions;
	@Field("is_agent_submitted")
	private AnswerTypeEnum isAgentSubmitted;
	@Field("application_receivedt")
	private String applicationReceiveDt;

	@Override
	public String toString () {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
