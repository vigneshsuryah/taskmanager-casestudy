package com.anthem.ols.middletier.paymentservice.rest.bo;
public enum BillingFrequencyTypeEnum {
    NONE,
    MONTHLY,
    BIMONTHLY,
    QUARTERLY,
    BIANNUALLY,
    ANNUALLY;
    public String value() {
        return name();
    }
    public static BillingFrequencyTypeEnum fromValue(String v) {
        return valueOf(v);
    }
}
