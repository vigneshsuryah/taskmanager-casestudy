package com.anthem.ols.middletier.paymentservice.rest.bo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AttestationOfEligibility implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 5387943171207100356L;

	private  int id;
 
    private  AnswerTypeEnum isInvoluntaryLossOfEHB;
    
    private  AnswerTypeEnum isLossEHBDueToMarriage;
    
    private  AnswerTypeEnum isMarriage;
    
    private  AnswerTypeEnum isAdoption;
    
    private  AnswerTypeEnum isBirth;
    
    private  Date  dateOfQualifyingEvent;
	
    private  ActionTypeEnum action;
    
    private  AnswerTypeEnum isOther;
    
    private  String otherEvent;


	/**

     * Gets the value of the id property.

     * 

     */

    public int getId() {

        return id;

    }



    /**

     * Sets the value of the id property.

     * 

     */

    public void setId(int value) {

        this.id = value;

    }   

    
    

    public AnswerTypeEnum getIsInvoluntaryLossOfEHB() {
		return isInvoluntaryLossOfEHB;
	}



	public void setIsInvoluntaryLossOfEHB(AnswerTypeEnum isInvoluntaryLossOfEHB) {
		this.isInvoluntaryLossOfEHB = isInvoluntaryLossOfEHB;
	}



	public AnswerTypeEnum getIsLossEHBDueToMarriage() {
		return isLossEHBDueToMarriage;
	}



	public void setIsLossEHBDueToMarriage(AnswerTypeEnum isLossEHBDueToMarriage) {
		this.isLossEHBDueToMarriage = isLossEHBDueToMarriage;
	}



	public AnswerTypeEnum getIsMarriage() {
		return isMarriage;
	}



	public void setIsMarriage(AnswerTypeEnum isMarriage) {
		this.isMarriage = isMarriage;
	}



	public AnswerTypeEnum getIsAdoption() {
		return isAdoption;
	}



	public void setIsAdoption(AnswerTypeEnum isAdoption) {
		this.isAdoption = isAdoption;
	}



	public AnswerTypeEnum getIsBirth() {
		return isBirth;
	}



	public void setIsBirth(AnswerTypeEnum isBirth) {
		this.isBirth = isBirth;
	}



	public Date getDateOfQualifyingEvent() {
		return dateOfQualifyingEvent;
	}



	public void setDateOfQualifyingEvent(Date dateOfQualifyingEvent) {
		this.dateOfQualifyingEvent = dateOfQualifyingEvent;
	}



	/**

     * Gets the value of the action property.

     * 

     * @return

     *     possible object is

     *     {@link ActionTypeEnum }

     *     

     */

    public ActionTypeEnum getAction() {

        return action;

    }



    /**

     * Sets the value of the action property.

     * 

     * @param value

     *     allowed object is

     *     {@link ActionTypeEnum }

     *     

     */

    public void setAction(ActionTypeEnum value) {

        this.action = value;

    }
    
    public AnswerTypeEnum getIsOther() {
		return isOther;
	}



	public void setIsOther(AnswerTypeEnum isOther) {
		this.isOther = isOther;
	}



	public String getOtherEvent() {
		return otherEvent;
	}



	public void setOtherEvent(String otherEvent) {
		this.otherEvent = otherEvent;
	}



}

