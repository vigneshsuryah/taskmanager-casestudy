package com.anthem.ols.middletier.paymentservice.rest.bo;

public enum OwnershipEnum {
	
	OWNER, 
	
	REVIEWER,
	
	NONE;							


}
