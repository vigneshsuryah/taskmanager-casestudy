package com.anthem.ols.middletier.paymentservice.entity;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionStatus {

	@Field("status_code")
	private String statusCode;

	@Field("status_description")
	private String statusDescription;

	@Field("updated_dt")
	private Date updatedTs;

}
