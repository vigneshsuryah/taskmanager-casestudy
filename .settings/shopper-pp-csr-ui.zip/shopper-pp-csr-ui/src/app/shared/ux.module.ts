import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DropDownComponent } from './directives/dropdownCmp';
import { ButtonDropDownComponent } from './directives/btnDropdownCmp';
import { RadioInputComponent } from './directives/radioInputCmp';
import {FieldSetWrapperComponent} from './directives/fieldsetWrapperCmp';
import {CheckboxInputComponent} from './directives/checkboxInputCmp';
import { UxHelper } from './ux.helper';

@NgModule({
  imports: [CommonModule,FormsModule],
  declarations: [DropDownComponent,ButtonDropDownComponent,RadioInputComponent,FieldSetWrapperComponent,CheckboxInputComponent],
  entryComponents: [DropDownComponent,ButtonDropDownComponent,RadioInputComponent,FieldSetWrapperComponent,CheckboxInputComponent],
  providers: [UxHelper],
  exports: [DropDownComponent,ButtonDropDownComponent,RadioInputComponent,FieldSetWrapperComponent,CheckboxInputComponent]
})
export class UxModule { }
