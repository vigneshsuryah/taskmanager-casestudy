export class Ippcsr {
   premiumAmt: string;
   applicationResponse: any = {};
   channel: string;
   applicantId: string;
   searchPaymentResponse : any = {};
}