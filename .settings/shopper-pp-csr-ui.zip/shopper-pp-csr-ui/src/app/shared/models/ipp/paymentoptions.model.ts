export class PaymentOptionsModel {

    paymentOptions: string;
    paymentType: string;
    creditCardNumber: string;
    cvvCode: string;
    expiryDate: string;
    nameOnCard: string;
    isChecked: string;
    addrType: string;
    cardHolderAddr1: string;
    cardHolderAddr2: string;
    city: string;
    state: string;
    county: string;
    zip: string;
    ccConfimationMail: string;
    accHolderName: string;
    bankRoutingNbr: string;
    accountNbr: string;
    accountType: string;
    isEChecked: string;
    ecConfimationMail: string;
    mpconfimationMail: string;
    sendMailInfo: string;
    emailAddress: string;
    withdrawalDay: string;
    sendPolicyInfo: string;
}