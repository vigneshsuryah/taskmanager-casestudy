export class User {
    username: string;
    userDn: string;
    token: string;
    firstName: string;
    lastName: string;
    userRole: string[];
}