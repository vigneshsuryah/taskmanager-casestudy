import { Application } from './application.model';

export class SetApplicationRequest {
  partnerId: string;
  user: {
    userId: string,
    shopperRole: string
  };
  application = new Application();
}
