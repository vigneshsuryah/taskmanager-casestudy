export class Demographic {
  id: number;
  action: string;
  relationshipType: string;
  lastName: string;
  firstName: string;
  dateOfBirth: string;
}
