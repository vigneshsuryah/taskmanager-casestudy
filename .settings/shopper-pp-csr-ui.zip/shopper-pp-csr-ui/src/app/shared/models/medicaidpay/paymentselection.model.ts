import { Payment } from './payment.model';

export class PaymentSelection {
  id: number;
  action: string;
  paymentIdentifier: string;
  isNoInitPayment: string;
  isRecvElectronicCOC: string;
  emailAddress: string;
  csrIdentifier: string;
  paymentExceptionMsg: string;
  initialPayment: Payment[] = [];
  ongoingPayment: Payment[] = [];
  validationErrors: {
    validationErrorLength: number
    validationError: {
      fieldName: string,
      errorMessages: string[]
    }[],
  };
}
