import { Bank } from './bank.model';
import { Card } from './card.model';

export class Payment {
  id: number;
  withdrawDay: number;
  paymentAmt: number;
  paymentType: string;
  billingFrequency: string;
  paymentTrackingId: string;
  action: string;
  billingAddr: any;
  bankAcct: Bank;
  creditCard: Card;
}
