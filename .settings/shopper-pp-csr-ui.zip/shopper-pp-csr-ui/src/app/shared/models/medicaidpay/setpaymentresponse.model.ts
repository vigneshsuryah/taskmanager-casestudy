import { PaymentSelection } from './paymentselection.model';

export class SetPaymentResponse {
  acn: string;
  paymentSelection = new PaymentSelection();
}
