export class Kyhpportcsr {
   healthCardId: string;
   paymentOption: string;
   editRecurringPayment: string;
}