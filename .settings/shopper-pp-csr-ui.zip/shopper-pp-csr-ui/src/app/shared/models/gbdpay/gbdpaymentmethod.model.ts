export class GBDSubmitTransaction {
    healthCardId  ?: string;
    memberpaySubmitPayments ?: Array<MemberPaySubmitPayment>;
    newPaymentMethod ?: boolean;
    payMetFutureUse ?: boolean;
    paymentType ?: string;
    bankAccountDetails ?: BankAccountDetails;
    creditCardDetails ?: CreditCardDetails;
    paymentDate ?: Date;
}

export class MemberPaySubmitPayment{
    childHealthCardId ?: string;
    planID ?: string;
    paymentAmount ?: string;
    confirmationNumber ?: string;
    message ?: Message;
    status ?: string;
}

export class BankAccountDetails{
    bankAccountType ?: string;
    routingNumber ?: string;
    bankAccountNumber ?: string;
    accountHolderName ?: string;
    accountAddress1 ?: string;
    accountAddress2 ?: string;
    accountCity ?: string;
    accountState ?: string;
    accountPostalCode ?: string;
    accountNickname ?: string;
}
export class CreditCardDetails{
    creditCardNumber ?: string;
    creditCardType ?: string;
    expirationMonth ?: string;
    expirationYear ?: string;
    accountHolderName ?: string;
    accountAddress1 ?: string;
    accountAddress2 ?: string;
    accountCity ?: string;
    accountState ?: string;
    accountPostalCode ?: string;
    accountNickname ?: string;

    formatID ?: string;
    integrityCheck ?: string;
    keyID ?: string;
    phaseID ?: string;
}

export class Message{
    messageCode ?: string;
    messageText ?: string;
}

export class GBDSubmitTransactionResponse{
    memberpaySubmitPayments ?: Array<MemberPaySubmitPayment>;
    successEmailLst ?: Array<string>;
    healthCardId ?: string;
    paymentMethodSaved ?: boolean;
    paymentDate ?: Date;
}

export class CancelPaymentUIDetails{
    subscriberName: string;
    accountName : string;
    planName : string;
    billDate : Date;
    minDue : string;
    totalDue : number;
    dueDate : Date;
    paymentDate : Date;
    paidAmount : string;
    accountTypeKey : string;
    accountTypeValue : string;
    confirmationNumber : string;
    paymentStatus: string;
    disabledStatus: boolean;
    accountHolderName: string;
    notes: any;
    showNotes: boolean;
}