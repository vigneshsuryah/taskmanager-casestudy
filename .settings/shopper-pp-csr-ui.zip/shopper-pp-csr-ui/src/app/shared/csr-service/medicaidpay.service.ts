import { IppHttpService } from './ipphttp.service';
import { Injectable } from '@angular/core';
import { Application } from '../models/medicaidpay/application.model';
import { PayEntry } from '../models/medicaidpay/payentry.model';
import { SetApplicationRequest } from '../models/medicaidpay/setapplicationrequest.model';

@Injectable()
export class MedicaidPayService {
  state: string;
  partnerId: string;
  acn: string;
  application: Application;
  payEntry: PayEntry;
  csrId: string;

  constructor(private ippHttpService: IppHttpService) {}

  callSetApplication(app: Application) {
    const request = new SetApplicationRequest();
    request.application = app;
    request.partnerId = app.createPartnerId;
    request.user = {
      userId: 'OLS',
      shopperRole: 'CONSUMER'
    };
    return this.ippHttpService.setApplication(request);
  }
}
