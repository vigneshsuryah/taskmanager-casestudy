import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';

import { Config } from '..';
import { User } from '../models/user';
import { Observable } from 'rxjs';
import { RefundModel } from '../models/refund/refund.model';

@Injectable()
export class RefundService {

  orderId: string; 
  lob: string;
  idType: string;
  transactionStatus: string;
  backToList: boolean;
  refundModel: RefundModel;
  memberInfo: any = {};

  constructor(private http: Http, private currentUser: User) {}
  
  getRefundResultsMock(jsonPath){
    return this.http.get(jsonPath)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  getConfirmationDetailsMock(jsonPath){
    return this.http.get(jsonPath)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
  }

  getRefundResults(inputParam:{}, endpoint, lob) {
    let headers = new Headers({
      'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username,
      'meta-endpoint' : endpoint,
      'csrId': this.currentUser.username,
      'lob': lob
    });
    let options = new RequestOptions({headers: headers});
    return this.http.post(Config.API+"csr/secure/payment/paymod/refund", inputParam, options)
                    .map((res:Response)=> res.json())
                    .catch(this.handleErrorNoChange.bind(this));
    }

  private handleErrorNoChange (error: any) {
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';

    this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
    return Observable.throw(errMsg);
  }

  public consoleLog(message : string){
    if(Config.loggingflag){
      console.log(message);
    }
  }

}
