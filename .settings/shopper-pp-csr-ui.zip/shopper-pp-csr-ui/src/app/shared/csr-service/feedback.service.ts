import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Config } from '../index';
import { User } from '../models/user';
import { QueryModel } from '../models/reports/query.model';

@Injectable()
export class FeedbackService {

    searchCriteria: QueryModel;
    isEdit: boolean = false;
    orderId: string;
    transactionStatus: string;

    constructor(private http: Http, private currentUser: User) {}

    setFeedback (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username });    
        let options = new RequestOptions({ headers: headers });    
        return this.http.post(Config.NodeAPI+"setFeedback", inputParam, options)
        .map((res: Response) => res.json())
        .catch(this.handleErrorNoChange.bind(this));
    }

    private handleErrorNoChange (error: any) {
        let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';

        this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
        return Observable.throw(errMsg);
    }

    public consoleLog(message : string){
        if(Config.loggingflag){
            console.log(message);
        }
    }
}