import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Config } from '../index';
import { AuthenticationService } from './authentication.service';
import { RouterModule , Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { Subject } from 'rxjs/Subject';
import {GBDAccountSummary} from '../models/gbdpay/accountsummaryresponse.model';


@Injectable()
export class KyhpportcsrService {
    hcid:string;
    gbdAcntSummaryRefresh:boolean;
    gbdAccountSummary:GBDAccountSummary;
    memberPaymentOptions:string;
    constructor(private http: Http, private authenticationService: AuthenticationService, private currentUser: User) {
    }

    getRecurring (inputParam:{}) : Observable<string[]> {
        let headers = new Headers({ 'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});    
        let options = new RequestOptions({ headers: headers });    
        return this.http.post(Config.API+"csr/secure/v1/gbd/payments/getrecurring", inputParam, options)
        .map((res: Response) => res.json())
        .catch(this.handleErrorNoChange.bind(this));
    }
  
    updateRecurring (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "csr/secure/v1/gbd/payments/updaterecurring",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    getSummary (inputParam:{}) : Observable<GBDAccountSummary> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR', 'csrId':this.currentUser.username });
      let options = new RequestOptions({ headers: headers });

      return this.http.post(Config.API+"csr/secure/v1/gbd/bills/getsummary", inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
    }
    cancelPayment = (inputParam:{}): Observable<string[]>=>{
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR', 'csrId':this.currentUser.username});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+"csr/secure/v1/gbd/payments/canceltransaction", inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
    };
    submitPayment = (inputParam:{}): Observable<string[]>=>{
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR', 'csrId':this.currentUser.username});
      let options = new RequestOptions({ headers: headers });
        return this.http.post(Config.API+"csr/secure/v1/gbd/payments/submittransaction", inputParam, options)
                    .map((res: Response) => res.json())
                    .catch(this.handleErrorNoChange.bind(this));
    };
    // this.http.get('assets/data/CancelPayment.json').map((res: Response) => res.json()).catch(this.handleErrorNoChange.bind(this));
    // submitCCPayment = (inputParam:{}): Observable<string[]> => this.http.get('assets/data/SubmitCCPayment.json').map((res:Response)=> res.json()).catch(this.handleErrorNoChange.bind(this));
    // submitBAPayment = (inputParam:{}): Observable<string[]> => this.http.get('assets/data/SubmitBAPayment.json').map((res:Response)=> res.json()).catch(this.handleErrorNoChange.bind(this));
    getValidationBankDetails(inputParam:{}, endpoint) {
      let response : any= {};
      let headers = new Headers({
        'Authorization': 'Bearer ' +
        this.currentUser.token, 'UserName': this.currentUser.username,
        'meta-endpoint' : endpoint,
        'csrId': this.currentUser.username
      });
      let options = new RequestOptions({headers: headers});
      return this.http.post(Config.API+"csr/secure/v1/payments/validateRoutingNumber", inputParam, options)
                      .map((res:Response)=> res.json())
                      .catch(this.handleErrorNoChange.bind(this));
      }
    getPaymentMethods (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "csr/secure/v1/gbd/payments/getmethods",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    getPaymentHistory (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "csr/secure/v1/gbd/bills/history",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    validateMember (inputParam:{}) : Observable<string[]> {
      let headers = new Headers({ 'Authorization': 'Bearer ' +
      this.currentUser.token, 'UserName': this.currentUser.username ,'meta-senderapp': 'KYPPCSR'});
      let options = new RequestOptions({ headers: headers });
      return this.http.post(Config.API+ "csr/secure/v1/gbd/bills/checkhohmember",inputParam,options)
                      .map((res: Response) => res.json())
                      .catch(this.handleErrorNoChange.bind(this));
    }

    private handleErrorNoChange (error: any) {

      let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    
      this.consoleLog('Error handleErrorNoChange csr-service: ' + error);
      return Observable.throw(errMsg);
    }
    public consoleLog(message : string){
      if(Config.loggingflag){
        console.log(message);
      }
    }

}
