import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[name-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => NameValidatorDirective), multi: true }
  ]
})
export class NameValidatorDirective implements Validator {

  validate(c: FormControl) {
    if (!c.value || typeof c.value === 'undefined') {
        return null;
    }

    let result: any = {};

    if (this.validateNoNumbers(c)) {
      result.validateNoNumbers = true;
    }     
    
    return result;
    }

    private validateNoNumbers(c: FormControl): any {
      return /[\d]/g.test(c.value) ? true : false;
    }

}
