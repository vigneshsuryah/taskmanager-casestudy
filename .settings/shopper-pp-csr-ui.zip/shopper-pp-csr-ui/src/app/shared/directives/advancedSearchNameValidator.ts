import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[adv-search-name-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => advancedSearchNameValidator), multi: true }
  ]
})
export class advancedSearchNameValidator implements Validator {

  validate(c: FormControl) {
    if (!c.value || typeof c.value === 'undefined') {
        return null;
    }

    let result: any = {};

    if (this.validateNoNumbers(c)) {
      result.invalidName = true;
    }     

    if (this.validateNoSpecialChar(c)) {
      result.invalidName = true;
    }

    return result;
    }

    private validateNoNumbers(c: FormControl): any {
      return /[\d]/g.test(c.value) ? true : false;
    }

    private validateNoSpecialChar(c: FormControl): any {
      return /[~#&^*()[\]\\\"?><|]+/g.test(c.value) ? true : false;
    }
}
