import { DatePipe } from '@angular/common';
import { PersonDetails } from './../../../shared/models/gbdpay/accountsummaryresponse.model';
import { MSMAServiceObject, MedicareMember, MedicareBill, OTPScreen, MedicarePayment } from './../../../shared/models/msma/msmaaccountsummary.model';
import { MsmaCsrHttpService } from './../../../shared/csr-service/msma.service';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
declare var PIE: any;
import { User } from '../../../shared/models/user';
import { NgForm } from '@angular/forms';
import { CancelPaymentUIDetails } from '../../../shared/models/gbdpay/gbdpaymentmethod.model';

@Component({
  moduleId: module.id,
  selector: 'csr-msmaaccountsummary',
  templateUrl: 'msmaaccountsummary.component.html',
  styleUrls: ['msmaaccountsummary.component.css']
})
export class MSMAAccountSummaryComponent  {

    hcidEntered : string = '';
    selectedMethod: string;
    screenLoader: boolean = true;
    techerror: boolean  = false;
    inputParam : any;
    errorMessage: string = '';
    serviceerror: boolean  = false;
    linkedBillsList: Array<MedicareMember>;
    subscriberName: string = '';
    selectedPlansForPayment: any = [];
    enteredAmount: number;
    paymentAmount: string;
    hasBills : boolean = false;
    selectedCancelPaymentMethodDetail: CancelPaymentUIDetails;
    selectedMemberPayForViewPay: any = {};
    totalAmtPaidPerBilAcc: number = 0;
    paymentTrackingNo: string = '';
    otpScreen:OTPScreen = {};
    isMedicareAdavtage : boolean = false;
    paymentDueAmounts:any = [];
    enablePaymentCheckBox : boolean = false;
    isMemberInSSAWithDueAmt : boolean = false;
    isMemberInRRBWithDueAmt : boolean = false;
    showNotesSection: boolean = false;
    showPayAllButton: boolean = false;
    payAllButtonFlag: boolean = false;
    
    
    pendingPayMessage: string = 'A Payment is already pending or submitted for this account';
    autoPayMessage: string = 'This account has already been scheduled for automatic monthly withdrawals';

    listOfAllowedPaymentStatus = ['Pay Now', 'Enrolled in SSA', 'Enrolled in RRB', 'Automatic monthly withdrawals are on'];

		@ViewChild('submitPaymentForm') submitPaymentForm: NgForm;
		
    constructor(public _router: Router, private _user: User, private _service : MsmaCsrHttpService){

			if(this._user.userRole === undefined){
        this._router.navigate(['']);
      }
    }

    ngOnInit() {
      this.selectedMemberPayForViewPay.paymentMethod = {};
      this.selectedCancelPaymentMethodDetail = new CancelPaymentUIDetails();
      this.selectedPlansForPayment = [];
      this.hcidEntered = this._service.hcid;
      let getKeyUrl = 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/' + 64100000000181 + '/getkey.js';
      this.loadScript(getKeyUrl);
      this.inputParam = {};
      this._service.lob = '';
      this.serviceerror = false;
      this.techerror = false;
      this.enablePaymentCheckBox = false;
      this.getSummary();
      this.selectedMethod = 'AS';     
      this.isMemberInSSAWithDueAmt = false;
      this.isMemberInRRBWithDueAmt = false;
    }

    getSummary() {
      this.screenLoader = true;
      var inputParam = {
        "healthCardId": this.hcidEntered
      };
      this._service.getdetailsforcsr(inputParam, 'getAccountSummary').subscribe((data: MSMAServiceObject) => {
        if (data && data.medicareMemberList) {
          this._service.accountSummaryObject = data;
          this.processMapping();
          this.screenLoader = false;
        }
      }, (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
    }

    processMapping() {
      var count = 0;
      this.showPayAllButton = false;
      if (this._service.accountSummaryObject) {
        this.linkedBillsList = this._service.accountSummaryObject.medicareMemberList;
        for (let bill of this.linkedBillsList) {
          if (bill && bill.medicareBillDetails && bill.medicareBillDetails.length > 0) {
            for (let billAcnt of bill.medicareBillDetails) {
              this.checkMemberInSSAOrRRBWithDue(billAcnt);
              this.updateLineOfBusiness(billAcnt.lineOfBusiness);
              this.checkPendingDueAmount(billAcnt);
              
              this.hasBills = true;
              count = count + 1;
              billAcnt.errorFlag = true;
              billAcnt.errorMessage = 'Required Field';
              billAcnt.isTouched = false;
            }
          }
        }
      }

      if(count > 1){
        this.showPayAllButton = true;
      }
    } 

    checkMemberInSSAOrRRBWithDue(billDetails: any) {
      console.log('inRRB block', billDetails);
      if (billDetails.paymentMethod == 'SSA' && billDetails.billNetDue > 0) {
        this.isMemberInSSAWithDueAmt = true;
      } else if (billDetails.paymentMethod == 'RRB' && billDetails.billNetDue > 0) {
        this.isMemberInRRBWithDueAmt = true;
      }
    }

    updateLineOfBusiness(lineOfBusiness: string) {
      console.log(lineOfBusiness);
      if (lineOfBusiness == 'MA') {
        this.isMedicareAdavtage = true;
        this._service.lob = 'MA';
      } else {
        this.isMedicareAdavtage = false;
        this._service.lob = 'MEDSUPP';
      }
    }

    checkPendingDueAmount(billDetails: any) {
      if (this.listOfAllowedPaymentStatus.indexOf(billDetails.paymentStatus) > -1
        && billDetails.billNetDue > 0) {
        billDetails.enablePaymentCheckBox = false;
      } else {
        billDetails.enablePaymentCheckBox = true;
      }
    }

    redirectToOneTimePay(bill: any) {
      this._service.selectedMethod = 'AS';
      //this._service.accountSummaryObject.selectedBillToPay = bill;
      this._service.accountSummaryObject.selectedBillToPay.push(bill);
      this._router.navigate(['/gbdmsma/onetimepayment']);
    }
    
    validateAmountEntered(bill: any) {
      bill.isTouched = true;
      this.payAllButtonFlag = false;
      this.paymentDueAmounts = [];
      if (bill.paymentAmt === undefined || bill.paymentAmt === '') {
        bill.errorFlag = true;
        bill.errorMessage = "Required Field";
      } else if (this.validatePattern(bill.paymentAmt) && !this.validateNoSpaces(bill.paymentAmt)
        && !this.validateNoSpecialChar(bill.paymentAmt) && !this.validateNoLetter(bill.paymentAmt)) {
        if (bill.paymentAmt !== undefined && bill.paymentAmt !== '') {
          if (bill.paymentAmt.indexOf('$') == -1 && bill.paymentAmt.indexOf('.') == -1) {
            bill.paymentAmt = '$' + bill.paymentAmt;
          } else if (bill.paymentAmt.length == 1 && (bill.paymentAmt == '$' || bill.paymentAmt == ".")) {
            bill.paymentAmt = '';
          }
          if (bill.paymentAmt.indexOf('$') >= 0) {
            this.enteredAmount = +bill.paymentAmt.slice(1);
          } else {
            this.enteredAmount = +bill.paymentAmt;
          }
          if(bill.billMinDue != undefined && bill.billNetDue != undefined) {
            this.paymentDueAmounts.push(bill.billMinDue);
            this.paymentDueAmounts.push(bill.billNetDue);
          }
          if (this.paymentDueAmounts.indexOf(this.enteredAmount) > -1) {
            bill.errorFlag = false;
          } else {
            bill.errorFlag = true;
            bill.errorMessage = 'Payment amount should be Minimum Due or Total Due Amount';
          }
         } else {
          bill.errorFlag = true;
          bill.errorMessage = "Required Field";
        }
      } else {
        bill.errorFlag = true;
        bill.errorMessage = "Please enter valid amount";
      }

      var count = 0;
      for (let bill of this.linkedBillsList) {
        if (bill && bill.medicareBillDetails && bill.medicareBillDetails.length > 0) {
          for (let billAcnt of bill.medicareBillDetails) {
            if(!billAcnt.errorFlag){
              count = count + 1;
            }
          }
        }
      }
      if(count > 1){
        this.payAllButtonFlag = true;
      }

    }

    private validateNoSpaces(amt: string) {
      return /\s/g.test(amt) ? true : false;
    }

    private validateNoSpecialChar(amt: string) {
      return /[-~{}!#%&*()+[\]^_`\\":;'@?>=<,/|]+/g.test(amt) ? true : false;
    }

    private validateNoLetter(amt: string) {
      return (/[a-zA-Z]/g.test(amt) ) ? true : false;
    }

    private validatePattern(amt: string) {
      return (/^\$?[0-9][0-9\,]*(\.\d{1,2})?$|^\$?[\.]([\d][\d]?)$/g.test(amt)) ? true : false;
    }

    redirectToMemberSearch() {
      this._router.navigate(['/gbdmsma/home']);
    }

		loadScript(url) {
			let node = document.createElement('script');
			node.src = url;
			node.type = 'text/javascript';
			document.getElementById('script-load-div').appendChild(node);       
 		}
		
    viewPaymentDetails(bills: MedicareMember, billAccount: MedicareBill, memberPayment: MedicarePayment) {
      this.selectedCancelPaymentMethodDetail.subscriberName = bills.firstName + " " + bills.lastName;
      if(memberPayment.paymentMethod.maskedAccountNumber.length>6){
        this.selectedCancelPaymentMethodDetail.accountTypeKey = "Card Type";
      } else {
        this.selectedCancelPaymentMethodDetail.accountTypeKey = "Account Type";
      }
      this.selectedCancelPaymentMethodDetail.accountTypeValue = memberPayment.paymentMethod.bankAccountType;
      this.selectedCancelPaymentMethodDetail.planName = billAccount.productDescription;
      this.selectedCancelPaymentMethodDetail.billDate = new Date(memberPayment.paymentDate);
      this.selectedCancelPaymentMethodDetail.confirmationNumber = memberPayment.paymentTrackingNo;
      this.selectedCancelPaymentMethodDetail.notes = memberPayment.notes;
      this.selectedCancelPaymentMethodDetail.dueDate = new Date(billAccount.billDueDate);
      this.selectedCancelPaymentMethodDetail.minDue = billAccount.billMinDue+'';
      this.selectedCancelPaymentMethodDetail.paidAmount = memberPayment.paymentAmount+'';
      this.selectedCancelPaymentMethodDetail.paymentDate = new Date(memberPayment.paymentDate);
      this.selectedCancelPaymentMethodDetail.paymentStatus = billAccount.paymentStatus;
      this.selectedCancelPaymentMethodDetail.totalDue = billAccount.billNetDue;
      if(memberPayment.paymentTrackingNo){
        let numericRegex =  /^[0-9]+$/;
        if (memberPayment.paymentTrackingNo.match(numericRegex)) {
          this.showNotesSection = false;
        } else {
          this.showNotesSection = true;
        }
        this.selectedCancelPaymentMethodDetail.disabledStatus = false;
      }else{
        this.selectedCancelPaymentMethodDetail.disabledStatus = true;
      }


      jQuery("#viewPaymentDetailModalOpener").click();
    }

    closePayDetails(selected: string) {
      this._service.selectedMethod = selected;
      jQuery("#viewPaymentDetailModalOpener").click();
      this._router.navigate(['/gbdmsma/paymentmethod']);
   }

   goBack(selected: string){
      this._service.selectedMethod = selected;
      jQuery("#viewPaymentDetailModalOpener").click();
      this._router.navigate(['/gbdmsma/paymentmethod']);
   }

   cancelPayment(paymentTrackingNo: string, selected: string) {
      this._service.selectedMethod = selected;
      jQuery("#notes").val("");
      jQuery('#count_message').html(150 + ' characters remaining');
      let numericRegex =  /^[0-9]+$/;
      if (paymentTrackingNo.match(numericRegex)) {
        this.showNotesSection = false;
      } else {
        this.showNotesSection = true;
      }
      jQuery("#viewPaymentDetailModalOpener").click();
      jQuery("#cancelPaymentModalOpener").click();
      this.paymentTrackingNo = paymentTrackingNo;
      this._router.navigate(['/gbdmsma/paymentmethod']);
   }

   redirectToHome(selected: string) {
      this._service.selectedMethod = selected;
      jQuery("#cancelPaymentModalOpener").click();
      this._router.navigate(['/gbdmsma/paymentmethod']);
   }

   confirmCancelPayment(selected: string) {
      this._service.selectedMethod = selected;
      jQuery("#cancelPaymentModalOpener").click();
      var inputParam = {
          "healthCardId": this.hcidEntered,
          "paymentConfirmationNo" : this.paymentTrackingNo,
          "notes": jQuery("#notes").val(),
          "paymentAmt" : this.selectedCancelPaymentMethodDetail.paidAmount
      };
      this._service.getdetailsforcsr(inputParam, 'cancelPayment').subscribe((data:any) => {
          if(data && data.paymentCancelStatus && 'Success' === data.paymentCancelStatus) {
              jQuery("#cancelConfirmationModalOpener").click(); 
          } else if(data && data.exceptions){
              jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
              this.techerror = true;
          } else if(data && data.message){
            this.errorMessage = data.message.messageText;
          }
      },
      (err: any) => {
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
      this.selectedMethod = 'AS'; 
   }

   success(selected:string){
     this._service.selectedMethod = selected;
     jQuery("#cancelConfirmationModalOpener").click();
     this.getSummary();
   }

   onKeyUp(event: any) {
    var text_length = event.target.value.length;
    var text_remaining = 150 - text_length;
    jQuery('#count_message').html(text_remaining + ' characters remaining');
  }
  
}
