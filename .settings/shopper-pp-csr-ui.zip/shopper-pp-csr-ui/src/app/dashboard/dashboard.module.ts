import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './home/dashboard.component';
import { routes } from './dashboard.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),    
    RouterModule.forChild(routes)
  ],
  declarations: [DashboardComponent]
})
export class DashboardModule { 

}
