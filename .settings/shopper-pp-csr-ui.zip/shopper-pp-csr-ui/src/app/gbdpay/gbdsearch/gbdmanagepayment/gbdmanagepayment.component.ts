import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { Kyhpportcsr } from '../../../shared/models/gbdpay/kyhpportcsr';
import { GbdPayMethodService } from './gbdpaymethod.service';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdmanagepayment',
  templateUrl: 'gbdmanagepayment.component.html',
  styleUrls: ['gbdmanagepayment.component.css']
})
export class GBDManagePaymentComponent implements OnInit {

  content : any ={};
  selectedMethod: string;

  hasKYHCSRSUBMIT: boolean = false;
  hasKYHPPORTCSR: boolean = false;

  constructor(public router: Router, public kyhpportcsr : Kyhpportcsr, private gbdPayMethodService: GbdPayMethodService, private currentUser: User){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
    if (this.currentUser && this.currentUser.userRole) {
      if (this.currentUser.userRole.indexOf('KYHCSRSUBMIT') > -1) {
        this.hasKYHCSRSUBMIT = true;
      }
      if (this.currentUser.userRole.indexOf('KYHPPORTCSR') > -1) {
        this.hasKYHPPORTCSR = true;
      }
    } else {
      this.router.navigate(['/roothome']);
    }
  }

   ngOnInit() {
     if (this.gbdPayMethodService.hcid === undefined || this.gbdPayMethodService.hcid === '') {
       this.router.navigate(['/gbdpay/gbdsearch']);
     }
     if (this.gbdPayMethodService.memberPaymentOptions !== undefined) {
       this.selectedMethod = this.gbdPayMethodService.memberPaymentOptions;
     } else {
       this.selectedMethod = this.kyhpportcsr.paymentOption;
     }
   }

   changePaymentMethod(selectedMethod: string){
    if(selectedMethod ==='AS'){
      this.selectedMethod = 'AS';
      this.gbdPayMethodService.memberPaymentOptions = undefined;
    }else if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
        this.gbdPayMethodService.memberPaymentOptions = this.selectedMethod;
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
        this.gbdPayMethodService.memberPaymentOptions = undefined;
      }
   }

}
