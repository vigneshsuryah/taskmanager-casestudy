import { Injectable } from '@angular/core';
import { PaymentMethod } from '../../../shared/models/gbdpay/paymentmethod.model';
import { GetPayMethodResponse } from '../../../shared/models/gbdpay/getpayresponse.model';
import { GetPayRequest } from '../../../shared/models/gbdpay/getpayrequest.model';
import { UpdatePayRequest } from '../../../shared/models/gbdpay/updatepayrequest.model';
import { MemberAddress } from '../../../shared/models/gbdpay/memberaddress.model';
import { GbdPayService } from '../../../shared/csr-service/gbdpay.service';
import { User } from '../../../shared/models';

@Injectable()
export class GbdPayMethodService {
  hcid: string;
  memberPayAddress: MemberAddress;
  paymentMethodEdit: PaymentMethod;
  memberPaymentOptions: string;
  existingNickNames: string[] = [];

  constructor(private gbdPayService: GbdPayService, private user: User) { }

  getPaymentMethodList() {
    const getPaymentRequest = new GetPayRequest();
    getPaymentRequest.healthCardId = this.hcid;
    return this.gbdPayService.getPayMethodList(getPaymentRequest);
  }

  addPaymentMethod(paymentMethod: PaymentMethod) {
    const request = new UpdatePayRequest();
    request.healthCardId = this.hcid;
    request.action = 'CREATE';
    request.csrUserId = this.user.username;
    if (paymentMethod.bankAccountNumber === undefined) {
      request.creditCardDetails = paymentMethod;
    } else {
      request.bankAccountDetails = paymentMethod;
    }
    return this.gbdPayService.updatePaymentMethods(request);
  }

  editPaymentMethod(paymentMethod: PaymentMethod, action: string) {
    const request = new UpdatePayRequest();
    request.healthCardId = this.hcid;
    request.action = action;
    request.csrUserId = this.user.username;
    if (paymentMethod.bankAccountNumber === undefined) {
      request.creditCardDetails = paymentMethod;
    } else {
      request.bankAccountDetails = paymentMethod;
    }
    return this.gbdPayService.updatePaymentMethods(request);
  }

  deletePaymentMethod(tokenToDelete: string) {
    const request = new UpdatePayRequest();
    request.healthCardId = this.hcid;
    request.action = 'DELETE';
    request.csrUserId = this.user.username;
    const pay = new PaymentMethod();
    pay.tokenId = tokenToDelete;
    request.bankAccountDetails = pay;
    return this.gbdPayService.updatePaymentMethods(request);
  }

  isSubcriberAddress(inputAdd: PaymentMethod) {
    if (inputAdd !== undefined && this.memberPayAddress !== undefined) {
      if (inputAdd.accountAddress1 === this.memberPayAddress.addressLine1
        && inputAdd.accountCity === this.memberPayAddress.city
        && inputAdd.accountPostalCode === this.memberPayAddress.postalCode
        && inputAdd.accountState === this.memberPayAddress.state) {
        return true;
      }
    }
    return false;
  }


}
