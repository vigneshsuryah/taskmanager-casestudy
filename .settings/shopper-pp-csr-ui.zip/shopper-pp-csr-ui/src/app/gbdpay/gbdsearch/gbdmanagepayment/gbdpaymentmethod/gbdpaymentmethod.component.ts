import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { PaymentMethod } from '../../../../shared/models/gbdpay/paymentmethod.model';
import { GetPayMethodResponse } from '../../../../shared/models/gbdpay/getpayresponse.model';
import { GbdPayMethodService } from '../gbdpaymethod.service';
import { UpdatePayResponse } from '../../../../shared/models/gbdpay/updatepayresponse.model';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdpaymentmethod',
  templateUrl: 'gbdpaymentmethod.component.html',
  styleUrls: ['gbdpaymentmethod.component.css']
})
export class GBDPaymentMethodComponent implements OnInit {

  hcid: string;
  content: any ={};
  tokenDelete: string;
  creditPayList: PaymentMethod[];
  bankPayList: PaymentMethod[];
  selectedPayMethod = 'Credit/Debit';
  countPay = 0;
  ccCountPay = 0;
  baCountPay = 0;
  screenLoader: boolean = false;
  techerror: boolean = false;

  constructor(public router: Router, private gbdPayMethodService: GbdPayMethodService, private currentUser: User) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
     if (this.gbdPayMethodService.hcid === undefined) {
      this.router.navigate(['/gbdpay/gbdsearch']);
     }
     this.hcid = this.gbdPayMethodService.hcid;
     this.getPaymentList();
   }

   getPaymentList() {
    this.techerror = false;
    this.screenLoader = true;
    this.countPay = 0;
    this.ccCountPay = 0
    this.baCountPay = 0
    this.gbdPayMethodService.getPaymentMethodList()
     .subscribe((data: GetPayMethodResponse) => {
       const nicknames: string[] = [];
       this.bankPayList = data.bankAccountDetails;
       this.creditPayList = data.creditCardDetails;
       if (this.bankPayList !== undefined) {
         this.baCountPay += this.bankPayList.length;
         for (const entryPay of this.bankPayList) {
           const accountNickname = entryPay.accountNickname;
           if (accountNickname !== undefined && accountNickname !== '') {
             nicknames.push(accountNickname);
           }
         }
       }
       if (this.creditPayList !== undefined) {
        this.ccCountPay += this.creditPayList.length;
        for (const entryPay of this.creditPayList) {
          const accountNickname = entryPay.accountNickname;
          if (accountNickname !== undefined && accountNickname !== '') {
            nicknames.push(accountNickname);
          }
        }
      }
      this.gbdPayMethodService.existingNickNames = nicknames;
      this.gbdPayMethodService.memberPayAddress = data.memberPayAddress;
      this.screenLoader = false;
      this.countPay = this.ccCountPay + this.baCountPay;
     },
    (error) => {
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
      this.screenLoader = false;
    });
  }

   redirectToaddNewPaymentMethod (){
    this.router.navigate(['/gbdpay/gbdaddpaymentmethod']);
   }

   redirectToHome() {
      this.router.navigate(['/gbdpay/gbdsearch']);
   }

   changePayMethod(payMethod: string) {
     this.selectedPayMethod = payMethod;
   }

   cancelDelete(selected: string){
      this.gbdPayMethodService.memberPaymentOptions = selected;
      jQuery("#confirmationModalOpener").click();
      this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

  confirmDelete(selected: string) {
    this.screenLoader = true;
    this.gbdPayMethodService.deletePaymentMethod(this.tokenDelete).subscribe(
      (data: UpdatePayResponse) => {
        this.screenLoader = false;
        jQuery("#confirmationModalOpener").click();
        jQuery("#deleteConfirmationModalOpener").click();
        this.getPaymentList();
      },
      (error) => {
        jQuery("#confirmationModalOpener").click();
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.screenLoader = false;
        this.techerror = true;
      }
    );
    this.gbdPayMethodService.memberPaymentOptions = selected;
   }

   delete(index: string){
    if (this.selectedPayMethod === 'Credit/Debit') {
      this.tokenDelete = this.creditPayList[index].tokenId;
    } else {
     this.tokenDelete = this.bankPayList[index].tokenId;
    }
    jQuery("#confirmationModalOpener").click();
   }

   edit(index: string) {
     if (this.selectedPayMethod === 'Credit/Debit') {
       this.gbdPayMethodService.paymentMethodEdit = this.creditPayList[index];
     } else {
      this.gbdPayMethodService.paymentMethodEdit = this.bankPayList[index];
     }
     this.router.navigate(['/gbdpay/gbdeditpaymentmethod']);
   }

   success(selected:string){
     this.gbdPayMethodService.memberPaymentOptions = selected;
     jQuery("#deleteConfirmationModalOpener").click();
     this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

}
