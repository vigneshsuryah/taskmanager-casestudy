import { Component, OnInit } from '@angular/core';
import {KyhpportcsrService} from '../../../shared/csr-service';
import {User} from '../../../shared/models';
import {Router} from '@angular/router';
import {BillAccount, GBDAccountSummary, LinkedBill, MemberPayment} from '../../../shared/models/gbdpay/accountsummaryresponse.model';
import {CancelPaymentUIDetails} from '../../../shared/models/gbdpay/gbdpaymentmethod.model';
import {Kyhpportcsr} from "../../../shared/models/gbdpay/kyhpportcsr";

declare var PIE: any;
declare var jQuery: any;
@Component({
  moduleId: module.id,
  selector: 'csr-gbdaccountsummary',
  templateUrl: './gbdaccountsummary.component.html',
  styleUrls: ['./gbdaccountsummary.component.css']
})
export class GbdAccountSummaryComponent implements OnInit {

  constructor(public _router: Router, private _user: User, private _service: KyhpportcsrService, private  _ser: Kyhpportcsr) { }
  paymentType:string = '';
  hcidEntered: string;
  hasBills: boolean = false;
  linkedBillsList: Array<LinkedBill>;
  serviceerror:boolean = false;
  selectedPlan: string = '';
  enteredAmount: number;
  techerror:boolean = false;
  screenLoader: boolean = false;
  min: number = 1;
  max: number = 5;
  errorMessage: string = '';
  isTouched: boolean = false;
  selectedPlansForPayment: Array<any> = [];
  paymentTrackingNo: string = '';
  subscriberName: string='';
  selectedMethod: string;
  showViewDetailsLink: boolean = false;
  selectedCancelPaymentMethodDetail: CancelPaymentUIDetails;
  showNotesSection: boolean = false;
  
  
  pendingPayMessage: string = 'A Payment is already pending or submitted for this account, do you want to proceed anyway?';
  paidInfullMessage: string = 'This account has already been paid in full, do you want to proceed anyway?';
  autoPayMessage: string = 'This account has already been scheduled for automatic monthly withdrawals, do you want to proceed anyway?';
  noPayDueMessage: string = 'The member doesn\'t have any outstanding bills, do you want to proceed anyway?';
  ngOnInit() {
    let getKeyUrl = 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/' + 64100000000181 + '/getkey.js';
    this.loadScript(getKeyUrl);
    this.selectedCancelPaymentMethodDetail = new CancelPaymentUIDetails();
    this.linkedBillsList = new Array<LinkedBill>();
    if (!this._ser.healthCardId) {
      this._router.navigate(['/gbdpay/gbdsearch']);
    }
    if (this._ser.healthCardId) {
      this.hcidEntered = this._ser.healthCardId;
      this._service.hcid = this._ser.healthCardId;
    }
      this.callAccountSummary();
  }

  private callAccountSummary = () => {
    this.screenLoader = true;

    let inputParam = {
      "healthCardId": this.hcidEntered
    };
    this._service.getSummary(inputParam).subscribe((data: GBDAccountSummary) => {
        if (data && data.message.messageCode==='0') {
          this._service.gbdAccountSummary = data;
          this._service.gbdAcntSummaryRefresh = false;
          this.processData();
          this.screenLoader = false;
        }
      },
      (err: any) => {
        this._service.gbdAcntSummaryRefresh = true;
        this.screenLoader = false;
        this.techerror = true;
      });
  };
   private processData = () => {
    if (this._service.gbdAccountSummary) {
      this.linkedBillsList = this._service.gbdAccountSummary.linkedBills;
      for (let bill of this.linkedBillsList) {
        if (null !== bill && null !== bill.billAccounts && undefined !== bill.billAccounts && bill.billAccounts.length > 0) {
          for (let billAcnt of bill.billAccounts) {
            this.hasBills = true;
            billAcnt.paymentAmt = null;
            billAcnt.errorFlag = true;
            billAcnt.errorMessage = 'Required Field';
            billAcnt.isTouched = false;
            if (billAcnt && billAcnt.totalDue && parseFloat(billAcnt.totalDue) < 0) {
              billAcnt.totalDue = '0.00';
            }
            if(billAcnt && billAcnt.minDue && parseFloat(billAcnt.minDue)<0){
              billAcnt.minDue = '0.00';
            }
          }
        }
      }
    }
  };
  viewPaymentDetails = (bills: LinkedBill, billAccount: BillAccount, memberPayment: MemberPayment) => {
    
    this.selectedCancelPaymentMethodDetail.accountName = bills.personDetails.firstName + ' '+ bills.personDetails.lastName;
    if(memberPayment.paymentMethod && memberPayment.paymentMethod.bankAccountDetails){
      this.selectedCancelPaymentMethodDetail.accountTypeKey ="Account Type";
      this.selectedCancelPaymentMethodDetail.accountTypeValue = memberPayment.paymentMethod.bankAccountDetails[0].bankAccountType;
    } else if(memberPayment.paymentMethod && memberPayment.paymentMethod.creditCardDetails){
      this.selectedCancelPaymentMethodDetail.accountTypeKey = "Card Type";
      this.selectedCancelPaymentMethodDetail.accountTypeValue = memberPayment.paymentMethod.creditCardDetails[0].creditCardType;
    } else{
      this.selectedCancelPaymentMethodDetail.accountTypeKey = "Payment Method";
      this.selectedCancelPaymentMethodDetail.accountTypeValue = "Cash";
    }
    if(memberPayment.notes){
      this.selectedCancelPaymentMethodDetail.showNotes = true;
      this.selectedCancelPaymentMethodDetail.notes = memberPayment.notes;
    } else{
      this.selectedCancelPaymentMethodDetail.showNotes = false;
      this.selectedCancelPaymentMethodDetail.notes = undefined;
    }
    this.selectedCancelPaymentMethodDetail.billDate = billAccount.billDate;
    this.selectedCancelPaymentMethodDetail.confirmationNumber = memberPayment.paymentTrackingNo;
    this.selectedCancelPaymentMethodDetail.dueDate = billAccount.billToDt;
    this.selectedCancelPaymentMethodDetail.minDue = billAccount.minDue;
    this.selectedCancelPaymentMethodDetail.paidAmount = memberPayment.paymentAmount;
    this.selectedCancelPaymentMethodDetail.paymentDate = memberPayment.paymentDate;
    this.selectedCancelPaymentMethodDetail.paymentStatus = billAccount.paymentStatus.payNowStatus;
    this.selectedCancelPaymentMethodDetail.planName = billAccount.planName;
    this.selectedCancelPaymentMethodDetail.subscriberName = bills.personDetails.firstName+ ' '+bills.personDetails.lastName;
    this.selectedCancelPaymentMethodDetail.totalDue = parseFloat(billAccount.totalDue);
    this.selectedCancelPaymentMethodDetail.disabledStatus = !memberPayment.paymentTrackingNo;
    this.showViewDetailsLink = true;
    jQuery("#viewPaymentDetailModalOpener").click();
  };
  closePayDetails = (selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#viewPaymentDetailModalOpener").click();
    this._router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
  };
  goBack = (selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#viewPaymentDetailModalOpener").click();
    this._router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
  };
  cancelPayment = (paymentTrackingNo: string, selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#notes").val("");
    jQuery('#count_message').html(150 + ' characters remaining');
    let numericRegex =  /^[0-9]+$/;
      if (paymentTrackingNo.match(numericRegex)) {
        this.showNotesSection = false;
      } else {
        this.showNotesSection = true;
      }
    jQuery("#viewPaymentDetailModalOpener").click();
    jQuery("#cancelPaymentModalOpener").click();
    this.paymentTrackingNo = paymentTrackingNo;
    this._router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
  };

  redirectToHome = (selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#cancelPaymentModalOpener").click();
    this._router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
  };

  confirmCancelPayment = (selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#cancelPaymentModalOpener").click();
    this.screenLoader = true;
    let inputParam = {
      "healthCardId": this.hcidEntered,
      "paymentConfirmationNo": this.paymentTrackingNo, 
      "notes": jQuery("#notes").val()
    };
    this._service.cancelPayment(inputParam).subscribe((data: any) => {
        if (null !== data && undefined !== data && null !== data.paymentCancelStatus && undefined !== data.paymentCancelStatus
          && 'Success' === data.paymentCancelStatus) {
          this.screenLoader = false;
          jQuery("#cancelConfirmationModalOpener").click();
        } else {
          this.screenLoader = false;
          this.serviceerror = true;
          this.errorMessage = data.message.messageText;
        }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
    this.selectedMethod = 'AS';
  };

  success = (selected: string) => {
    this._service.memberPaymentOptions = selected;
    jQuery("#cancelConfirmationModalOpener").click();
    this.callAccountSummary();
  };
  loadScript = url => {
    let node = document.createElement('script');
    node.src = url;
    node.type = 'text/javascript';
    document.getElementById('script-load-div').appendChild(node);
  };

  private validateNoSpaces = (amt: string) => /\s/g.test(amt);

  private validateNoSpecialChar = (amt: string) => /[-~{}!#%&*()+[\]^_`\\":;'@?>=<,/|]+/g.test(amt);

  private validateNoLetter = (amt: string) => (/[a-zA-Z]/g.test(amt));

  private validatePattern = (amt: string) => (/^\$?[0-9][0-9,]*(\.\d{1,2})?$|^\$?[.]([\d][\d]?)$/g.test(amt));

  validateAmountEntered(bill: any) {
    bill.errorMessage = undefined;
    bill.amtWarningMessage = undefined;
    bill.warningFlag = false;
    bill.errorFlag = false;
    bill.isTouched = false;
    this.selectedPlan = bill.subGroupId;
    bill.isTouched = true;
    if (bill.paymentAmt === undefined || bill.paymentAmt === '') {
      bill.errorFlag = true;
      bill.errorMessage = "Required Field";
    } else if (this.validatePattern(bill.paymentAmt) && !this.validateNoSpaces(bill.paymentAmt) && !this.validateNoSpecialChar(bill.paymentAmt) && !this.validateNoLetter(bill.paymentAmt)) {
      if (bill.paymentAmt !== undefined && bill.paymentAmt !== '') {
        if (bill.paymentAmt.indexOf('$') == -1 && bill.paymentAmt.indexOf('.') == -1) {
          bill.paymentAmt = '$' + bill.paymentAmt;
        } else if (bill.paymentAmt.length == 1 && (bill.paymentAmt == '$' || bill.paymentAmt == ".")) {
          bill.paymentAmt = '';
        }
        if (bill.paymentAmt.indexOf('$') >= 0) {
          this.enteredAmount = +bill.paymentAmt.slice(1);
        } else {
          this.enteredAmount = +bill.paymentAmt;
        }
        bill.errorFlag = false;
        if (this.enteredAmount < 1 || this.enteredAmount > 450.00) {
          bill.errorFlag = true;
          bill.errorMessage = "Amount should not be less than $1 and greater than $450.00";
        }
        if (this.enteredAmount > bill.totalDue) {
          bill.warningFlag = true;
          bill.amtWarningMessage = "Entered amount exceeds current Amount Due";
        }
      } else {
        bill.errorFlag = true;
        bill.errorMessage = "Required Field";
      }
    } else {
      bill.errorFlag = true;
      bill.errorMessage = "Please enter valid amount";
    }
  };

  paySelectedPlan = (bill: BillAccount, amount: string) => {
    this._service.gbdAccountSummary.linkedBills[0].billAccounts[0].paymentAmt = bill.paymentAmt;
    this._router.navigate(['/gbdpay/gbdonetimepayment']);
  };

  redirectToMemberSearch = () => {
    this._router.navigate(['/gbdpay/gbdsearch']);
  };
  onKeyUp(event: any) {
    var text_length = event.target.value.length;
    var text_remaining = 150 - text_length;
    jQuery('#count_message').html(text_remaining + ' characters remaining');
  }

}
