import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { GbdINPayService } from '../../../shared/csr-service/gbdinpay.service';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdinmanagepayment',
  templateUrl: 'gbdinmanagepayment.component.html',
  styleUrls: ['gbdinmanagepayment.component.css']
})
export class GBDINManagePaymentComponent implements OnInit {

  content : any ={};
  selectedMethod: string;

  hasGBDCSRSUBMIT: boolean = false;
  hasGBDPPORTCSR: boolean = false;
  
  constructor(public router: Router, private gbdINPayService: GbdINPayService, private user: User){
    if(this.user.userRole === undefined){
      this.router.navigate(['']);
    }
    if (this.user && this.user.userRole) {
      if (this.user.userRole.indexOf('GBDCSRSUBMIT') > -1) {
        this.hasGBDCSRSUBMIT = true;
      }
      if (this.user.userRole.indexOf('GBDPPORTCSR') > -1) {
        this.hasGBDPPORTCSR = true;
      }
    } else {
      this.router.navigate(['/roothome']);
    }
  }

   ngOnInit() {
     if (this.gbdINPayService.hcid === undefined || this.gbdINPayService.hcid === '') {
       this.router.navigate(['/gbdpay/gbdinsearch']);
     }
     if (this.gbdINPayService.memberPaymentOptions !== undefined) {
       this.selectedMethod = this.gbdINPayService.memberPaymentOptions;
     } else {
       this.selectedMethod = this.gbdINPayService.memberPaymentOptions;
     }
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
        this.gbdINPayService.memberPaymentOptions = this.selectedMethod;
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
        this.gbdINPayService.memberPaymentOptions = undefined;
      } else if(selectedMethod === 'AS'){
        this.selectedMethod = 'AS';
      }
   }

}
