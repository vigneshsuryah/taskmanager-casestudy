import {ValidateRoutingNo} from './../../../../shared/models/indvmemberpay/validateRoutingNo.model';
import {PaymentMethodModel} from './../../../../shared/models/paymentmethod.model';
import {BankAccountDetails, CreditCardDetails, GBDSubmitTransaction} from './../../../../shared/models/gbdpay/gbdpaymentmethod.model';
import {GbdINPayService} from './../../../../shared/csr-service/gbdinpay.service';
import {User} from './../../../../shared/models/user';
import {content} from '../../../../shared/constants/constants';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {DatePipe} from '@angular/common';

declare var PIE: any;
declare var jQuery: any;
declare var ProtectPANandCVV: Function;
@Component({
  selector: 'csr-gbdinonetimepayment',
  templateUrl: './gbdinonetimepayment.component.html',
  styleUrls: ['./gbdinonetimepayment.component.css']
})
export class GBDINOneTimePaymentComponent implements OnInit {
  creditCardDetails: CreditCardDetails = {};
  bankAccountDetails: BankAccountDetails = {};
  value: string = '';
  hcidEntered: string = '';
  selectedMethod: string = '';
  errorMessage: string = '';
  totalAmount: number = 0;
  screenLoader: boolean = false;
  techerror: boolean = false;
  serviceerror: boolean = false;
  selectedPlansForPayment: any = [];
  memberpaySubmitPayments: any = [];
  memberpaySubmitPaymentsList: any = [];
  submittedPaymentsHasFailure: boolean = false;
  memberSubmitPaymentResp: any = {};
  inputParam: any = {};
  paymentMethodModel: any = {};
  content: any = {};
  billAddr: any = {};
  encryptionData: any = {};
  paymentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  minDueDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
  currentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
  constructDatePicker: boolean = false;
  enteredEmailIdIsValid: boolean = true;
  csrEnteredEmailId: string = '';

  public routingNoValidations:Array<string>=[];
  datePickerObj = {
    format: 'mm/dd/yyyy',
    startDate: '0D',
    endDate: '0D',
    autoclose: true,
    orientation: 'bottom auto',
    forceParse: false
  };

  constructor(public router: Router, private currentUser: User, private datePipe: DatePipe, public gbdINPayService: GbdINPayService) {
    if (this.currentUser.userRole === undefined) {
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    console.log('2 : ' + JSON.stringify(PIE));
    this.inputParam = {};
    this.content = content;
    this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
    this.paymentMethodModel.paymentMethod = 'Banking';
    this.value = "Banking";
    this.hcidEntered = this.gbdINPayService.hcid;
    this.serviceerror = false;
    this.techerror = false;
    this.billAddr = {};
    this.totalAmount = parseFloat(this.gbdINPayService.gbdAccountSummary.linkedBills[0].billAccounts[0].paymentAmt.slice(1));
    // this.totalAmount = parseFloat(this.gbdINPayService.gbdAccountSummary.linkedBills[0].billAccounts[0].paymentAmt);
    var addrInputParam = {
      "healthCardId": this.hcidEntered
    }
    if (null !== this.minDueDate && undefined !== this.minDueDate) {
      if (new Date(this.minDueDate).getTime() <= new Date(this.currentDate).getTime()) {
        this.minDueDate = this.currentDate;
      }
    }
    this.datePickerObj.endDate = this.minDueDate;
    this.constructDatePicker = true;
    this.gbdINPayService.getPaymentMethods(addrInputParam).subscribe((data: any) => {
      if (data && data.memberPayAddress) {
        if(data.memberPayAddress.postalCode.length>5){
          data.memberPayAddress.postalCode = data.memberPayAddress.postalCode.substring(0,5);
        }      
        this.billAddr = data.memberPayAddress;
        this.changeAddr('SubscriberAddr');
        this.screenLoader = false;
      }
    },
      (err: any) => {
        this.screenLoader = false;
      });
  }

  submitPayment(paymentMethodModel: GBDSubmitTransaction) {
    this.paymentMethodModel = new GBDSubmitTransaction();
    this.paymentMethodModel = paymentMethodModel;
    jQuery("#notes").val("");
    jQuery('#count_message').html(150 + ' characters remaining');
    document.getElementById('confirmationModalOpener').click();
  }

  changePaymentMethod(paymentMethod: string) {
    this.paymentMethodModel = {};
    this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
    this.changeAddr('SubscriberAddr');
    if (paymentMethod == 'CreditDebit') {
      this.paymentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
      this.value = "CreditDebit";
      this.paymentMethodModel.paymentMethod = 'CreditDebit';
    } else {
      this.value = "Banking";
      this.paymentMethodModel.paymentMethod = 'Banking';
    }
  }
  validateBankDetails(paymentMethodModel: PaymentMethodModel){
       // getValidationBankDetails
       this.paymentMethodModel = new PaymentMethodModel();
       this.paymentMethodModel = paymentMethodModel;
       if(null !== this.paymentMethodModel.routingNumber && undefined !== this.paymentMethodModel.routingNumber && this.paymentMethodModel.routingNumber !== '' && this.paymentMethodModel.routingNumber.length == 9){
        this.inputParam = {
          "routingNumber": this.paymentMethodModel.routingNumber,
        }
        this.gbdINPayService.getValidationBankDetails(this.inputParam, 'v1/validateRoutingNumber').subscribe((data: ValidateRoutingNo) => {
            this.routingNoValidations = [];
            if (data && data.exceptions) {
                data.exceptions.forEach(x => {
                    this.routingNoValidations.push(x.message);
                });
            } else if (data && data.valid === false) {
                this.routingNoValidations.push('Please enter a valid bank routing number');
            }
        });
       }       
  }
  confirmSubmitPayment() {
    document.getElementById('confirmationModalOpener').click();
    this.selectedMethod = 'AS';
    this.screenLoader = true;
    this.serviceerror = false;
    this.techerror = false;
    this.memberpaySubmitPayments = [];
    this.memberpaySubmitPaymentsList = [];
    this.submittedPaymentsHasFailure = false;
    if (this.paymentMethodModel.paymentMethod === 'Banking') {
      this.bankAccountDetails = this.constructBankingReq(this.paymentMethodModel);
      this.inputParam = {
        "healthCardId": this.hcidEntered,
        // "csrId": this.currentUser.username,
        "memberpaySubmitPayments": [{
          "childHealthCardId": this.hcidEntered,
          "planID": this.gbdINPayService.gbdAccountSummary.linkedBills[0].billAccounts[0].planId,
          "paymentAmount": this.totalAmount + ''
        }],
        "paymentType": "BANKINGACCOUNT",
        "newPaymentMethod": true,
        "payMetFutureUse": false,
        "bankAccountDetails": this.bankAccountDetails,
        "paymentDate": this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
        "notes": jQuery("#notes").val(),
        "csrEnteredEmailId" : jQuery("#csrEnteredEmailId").val()
      }
    } else if (this.paymentMethodModel.paymentMethod === 'CreditDebit') {
      console.log(this.datePipe.transform(this.paymentDate, 'MM/dd/yyyy'));
      this.creditCardDetails = this.constructCreditDebitReq(this.paymentMethodModel);
      this.inputParam = {
        "healthCardId": this.hcidEntered,
        // "csrId": this.currentUser.username,
        "memberpaySubmitPayments": [
          {
            "childHealthCardId": this.hcidEntered,
            "planID": this.gbdINPayService.gbdAccountSummary.linkedBills[0].billAccounts[0].planId,
            "paymentAmount": this.totalAmount + ''
          }
        ],
        "newPaymentMethod": true,
        "payMetFutureUse": false,
        "paymentType": "CREDITDEBITCARD",

        
        "creditCardDetails": this.creditCardDetails,
        "paymentDate": this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
        "notes": jQuery("#notes").val(),
        "csrEnteredEmailId" : jQuery("#csrEnteredEmailId").val()
      };
    }
    this.gbdINPayService.submitPayment(this.inputParam).subscribe((data: any) => {
      console.log(data);
      if (null !== data && undefined !== data && null !== data.message && undefined !== data.memberpaySubmitPayments
        && data.memberpaySubmitPayments.length > 0) {
        this.memberpaySubmitPaymentsList = data.memberpaySubmitPayments;
        this.memberSubmitPaymentResp = data;
        for(let memPaySubmitPayment of this.memberpaySubmitPaymentsList){
            if(memPaySubmitPayment.message.messageCode !== '0'){
                this.submittedPaymentsHasFailure = true;
            }
        }
        this.screenLoader = false;
        document.getElementById('successModalOpener').click();
      } else {
        this.screenLoader = false;
        this.serviceerror = true;
        this.errorMessage = data.message.messageText;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
  }

  constructBankingReq(paymentMethodModel: PaymentMethodModel) {
    return {
      "bankAccountType": paymentMethodModel.accountType,
      "routingNumber": paymentMethodModel.routingNumber,
      "bankAccountNumber": paymentMethodModel.confirmAccountNo,
      "accountHolderName": paymentMethodModel.accountName,
      "accountAddress1": paymentMethodModel.address1,
      "accountAddress2": paymentMethodModel.address2,
      "accountCity": paymentMethodModel.city,
      "accountState": paymentMethodModel.state,
      "accountPostalCode": paymentMethodModel.zipCode
    };
  }

  constructCreditDebitReq(paymentMethodModel: PaymentMethodModel) {
    this.encryptionData = this.doEncryption(paymentMethodModel.confirmAccountNo);
    return {
      "creditCardNumber": this.encryptionData.encryptccno,
      "creditCardType": (null !== paymentMethodModel.accountType && undefined !== paymentMethodModel.accountType && 'MC' === paymentMethodModel.accountType) ? 'MASTERCARD' : 'VISA',
      "expirationMonth": paymentMethodModel.expiration.split('/')[0],
      "expirationYear": paymentMethodModel.expiration.split('/')[1],
      "accountHolderName": paymentMethodModel.accountName,
      "accountAddress1": paymentMethodModel.address1,
      "accountAddress2": paymentMethodModel.address2,
      "accountCity": paymentMethodModel.city,
      "accountState": paymentMethodModel.state,
      "accountPostalCode": paymentMethodModel.zipCode,
      "formatID": "64",
      "integrityCheck": this.encryptionData.integritycheck,
      "keyID": this.encryptionData.keyid,
      "phaseID": this.encryptionData.phase+''
    };
  }

  changeAddr(addrType: string) {
    if (addrType === 'SubscriberAddr') {
      this.paymentMethodModel.address1 = this.billAddr.addressLine1;
      this.paymentMethodModel.address2 = this.billAddr.addressLine2;
      this.paymentMethodModel.city = this.billAddr.city;
      this.paymentMethodModel.state = this.billAddr.state;
      this.paymentMethodModel.zipCode = this.billAddr.postalCode;
    } else {
      this.paymentMethodModel.address1 = '';
      this.paymentMethodModel.address2 = '';
      this.paymentMethodModel.city = '';
      this.paymentMethodModel.state = '';
      this.paymentMethodModel.zipCode = '';
    }
  }

  doEncryption(ccno) {
    this.encryptionData = {};
    this.encryptionData.ccno = ccno;
    var result = ProtectPANandCVV(ccno, "", true);
    console.log('result : ' + JSON.stringify(result));
    if (result != null && result != undefined) {
      this.encryptionData.encryptccno = result[0];
      if (result.length > 2) {
        this.encryptionData.integritycheck = result[2];
      }
    } else {
      alert("Error: ProtectPANandCVV call returned null. You may have entered an invalid card number.");
    }
    this.encryptionData.keyid = PIE.key_id;
    this.encryptionData.phase = PIE.phase;
    return this.encryptionData;
  }

  getSelectedDate(date) {
    //console.log("getSelectedDate");
    this.paymentDate = this.datePipe.transform(date, 'MM/dd/yyyy');
  }

  bankAccNbrFieldOnChange(flag: boolean) {
    if (flag) {
      this.paymentMethodModel.reEnterbankAccountNbr = '';
    }
  }

  redirectToHome(selected: string) {
    this.gbdINPayService.memberPaymentOptions = 'AS';
    jQuery("#successModalOpener").click();
    this.gbdINPayService.gbdAcntSummaryRefresh = true;
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);

  }

  cancel(selected: string) {
    this.gbdINPayService.gbdAcntSummaryRefresh = false;
    this.gbdINPayService.memberPaymentOptions = selected;
    this.router.navigate(['/gbdpay/gbdinmanagepaymentmethod']);
  }

  onKeyUp(event: any) {
      var text_length = event.target.value.length;
      var text_remaining = 150 - text_length;
      jQuery('#count_message').html(text_remaining + ' characters remaining');
  }

  validateEmail(event: any) {
    let csrEnteredEmailId = event.target.value;
    this.enteredEmailIdIsValid = true;
      if(csrEnteredEmailId !== "" && csrEnteredEmailId !== null){
        if(!this.checkEmailRegex(csrEnteredEmailId)){
          this.enteredEmailIdIsValid = false;
         }
      }
  }

  checkEmailRegex(csrEnteredEmailId : string) {
      var emailRegex = /^[A-Za-z0-9][A-Za-z0-9._%+-]+@[A-Za-z]+\.[A-Za-z]{1,63}$/;
      if(emailRegex.test(csrEnteredEmailId)){
        return true;
      }else{
        return false;
      }
  }
}
