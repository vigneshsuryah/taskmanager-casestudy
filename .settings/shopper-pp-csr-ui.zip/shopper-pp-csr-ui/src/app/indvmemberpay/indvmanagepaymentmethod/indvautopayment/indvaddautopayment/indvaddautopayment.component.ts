import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { AutoPaymentModel } from '../../../../shared/models/indvmemberpay/autopayment.model';
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvaddautopayment',
  templateUrl: 'indvaddautopayment.component.html',
  styleUrls: ['indvaddautopayment.component.css']
})
export class IndvAddAutoPaymentComponent implements OnInit {

  hcidEntered : string = '';
  tokenId: string = '';
  paymentType: string = '';
  productId: string = '';
  subscriberName: string = '';
  brand: string = '';
  emailAddressTxt: string = '';
  brandText: string = '';
  responseLength: any = 0;
  planError: boolean;
  screenLoader: boolean;
  techerror: boolean = false;
  isCC: boolean = false;
  isBA: boolean = false;
  //hasNoProducts: boolean;
  emailAddressChecked: boolean = false;
  paymentMethods: any = [];
  paymentMethodsListComposed: any = [];
  ccList: any = [];
  bnkList: any = [];
  getSummaryResponseList: any =[];
  linkedBillsList: any = [];
  subGroupIdList: any = [];
  recurringSubGroupIdList: any = [];
  billAccountsList: any = [];
  selectedBillAccountToAdd: any = [];
  recurringPaymentDetails: any = [];
  content : any = {};
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  ccResponse: any = {};
  baResponse: any = {};
  inputParam: any = {};
  billAccounts: any = {};
  personDetails: any = {};
  paymentDetailsMap: any = {};
  autoPaymentModel = new AutoPaymentModel();
  
  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService: MwpCsrHttpService){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
    this.hcidEntered = mwpCsrHttpService.hcid;
  }

  ngOnInit() {
    this.content = content;
    jQuery(".sb-checkbox-font").find(".pcLabel").addClass('pcLabelFontOverride');
    this.inputParam = {
       "hcids" : [
         this.hcidEntered
        ]
    }
    this.recurringSubGroupIdList = this.mwpCsrHttpService.recurringSubGroupIdList;
    this.getSummary();
  }

  getSummary(){
    this.screenLoader = true;
    this.getSummaryResponseList = [];
    this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getSummary').subscribe((data:any) => {
      if(undefined !== data && null !== data && undefined !== data.memberpayMember && null !== data.memberpayMember){
        this.getSummaryResponseList = data.memberpayMember.linkedBills;
        if(this.getSummaryResponseList.length > 0){
           for(let linkedBills of this.getSummaryResponseList){
            this.subscriberName = linkedBills.personDetails.firstName+' '+linkedBills.personDetails.lastName;
            this.brand = linkedBills.personDetails.brand;
            let billAccountsList = linkedBills.billAccounts;
            if(billAccountsList.length > 0){
              for(let billAccounts of billAccountsList){
                if(this.recurringSubGroupIdList.length > 0){
                  if(this.recurringSubGroupIdList.indexOf(billAccounts.subGroupId) < 0){
                    this.subGroupIdList.push(billAccounts.subGroupId);
                  }
                } else {
                  this.subGroupIdList.push(billAccounts.subGroupId);
                }
              }
              if(this.subGroupIdList.length > 0){
                 for(let billAccounts of billAccountsList){
                   for(let subGroupIds of this.subGroupIdList){
                     if(subGroupIds === billAccounts.subGroupId){
                        billAccounts.summaryOrHCID = null != linkedBills.personDetails.summaryBillNo ? linkedBills.personDetails.summaryBillNo : linkedBills.personDetails.hcid;
                        this.linkedBillsList.push(billAccounts);
                     }
                   }
                  }
                }
              }
          } 

          // if(this.linkedBillsList.length === 0){
          //   this.hasNoProducts = true;
          //   this.screenLoader = false;
          // } else {
          //   this.hasNoProducts = false;
          //   this.getPaymentMethods();
          // }

          this.screenLoader = false;
          this.getPaymentMethods();

        }  
      }
      this.getBrandName(this.brand);
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
  }

  getPaymentMethods(){
    this.screenLoader = true;
    this.paymentMethods = [];
    this.paymentMethodsListComposed = [];
    this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getPaymentMethods').subscribe((data:any) => {
    if(null !== data && undefined !== data && null !== data.memberpayPaymentMethods && undefined !== data.memberpayPaymentMethods && 
        data.memberpayPaymentMethods.length > 0){
          this.paymentMethods = data.memberpayPaymentMethods;
          this.ccList = [];
          this.bnkList = [];
          for(var i=0; i<=this.paymentMethods.length-1;i++){
              if (this.paymentMethods[i].paymentType === 'CREDITDEBITCARD'){
                this.ccList.push(this.paymentMethods[i]);
              }
              if (this.paymentMethods[i].paymentType === 'BANKINGACCOUNT') {
                this.bnkList.push(this.paymentMethods[i]);
              }
          }

          if (this.ccList.length === 0 && this.bnkList.length === 0) {
            this.responseLength = 0;
          } else {
            if (this.ccList.length > 0) {
              this.responseLength += this.ccList.length;
              for(var i = 0; i <= this.ccList.length-1; i++){
                var labelString = '';
                this.creditCardBankAccNbrMap[this.ccList[i].tokenId] = this.ccList[i].creditCardNumber;
                this.paymentTypeMap[this.ccList[i].tokenId] = 'CreditDebitCard';

                if(this.ccList[i].bankAccountType == "MASTERCARD"){
                  labelString = "Mastercard ending in ";
                }else if(this.ccList[i].bankAccountType == "VISA"){
                  labelString = "VISA ending in ";
                }
                labelString = labelString + this.ccList[i].confirmAccountNo.slice(-4) + (("" !== this.ccList[i].accNickName && null !== this.ccList[i].accNickName) ? (' - ' + this.ccList[i].accNickName) : '');
                var tempCCItem = {
                  label : labelString,
                  value : this.ccList[i].tokenId
                }
                this.paymentMethodsListComposed.push(tempCCItem);
                }
            }

            if (this.bnkList.length > 0) {
              this.responseLength += this.bnkList.length;
              for(var i = 0; i <= this.bnkList.length-1; i++){
                var labelString = '';
                this.creditCardBankAccNbrMap[this.bnkList[i].tokenId] = this.bnkList[i].bankAccountNumber;
                this.paymentTypeMap[this.bnkList[i].tokenId] = 'Banking';
                this.bankAccountTypeMap[this.bnkList[i].tokenId] = this.bnkList[i].bankAccountType;

                if(this.bnkList[i].bankAccountType == "BUSSAVINGS" || this.bnkList[i].bankAccountType == "PERSONALSAVINGS"){
                  labelString = "Savings ending in ";
                }else if(this.bnkList[i].bankAccountType == "BUSCHECKING" || this.bnkList[i].bankAccountType == "PERSONALCHECKING"){
                  labelString = "Checking ending in ";
                }
                labelString = labelString + this.bnkList[i].confirmAccountNo.slice(-4) + (("" !== this.bnkList[i].accNickName && null !== this.bnkList[i].accNickName) ? (' - ' + this.bnkList[i].accNickName) : '');
                var tempBnkItem = {
                  label : labelString,
                  value : this.bnkList[i].tokenId
                }
                this.tokenId = this.bnkList[i].tokenId; 
                this.paymentMethodsListComposed.push(tempBnkItem);
              }            
            }
          }

          if(null !== this.tokenId && undefined !== this.tokenId){
            this.selectedPaymentMethod(this.tokenId);
            this.autoPaymentModel.paymentMethod = this.tokenId;   
          }  
       } else {
         var tempItem = {
            label : 'No Saved payment method',
            value : ''
         }
         this.paymentMethodsListComposed.push(tempItem);
       }
       this.screenLoader = false;
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
    this.content.paymentMethodsList = this.paymentMethodsListComposed;
  }

  getBrandName(brand: string){
    if(brand === 'ABC'){
      this.brandText = 'Anthem BlueCross';
    } else if(brand === 'ABCBS'){
      this.brandText = 'Anthem Blue Cross and Blue Shield';
    } else if(brand === 'BCBSGA'){
      this.brandText = 'BlueCross BlueShield of Georgia';
    } else if(brand === 'EBCBS'){
      this.brandText = 'Empire BlueCross BlueShield';
    } else if(brand === 'EBC'){
      this.brandText = 'Empire BlueCross';
    }
  }

  selectedPaymentMethod(selectedPayment: string){
     if(this.paymentTypeMap[selectedPayment] === 'CreditDebitCard'){
       this.isCC = true;
       this.isBA = false;
       for(let creditCardDetails of this.ccList){
         if(creditCardDetails.tokenId === selectedPayment){
            this.ccResponse = creditCardDetails;
            break;
         }
       }
       this.paymentType = "CREDITDEBITCARD"; 
     } else if(this.paymentTypeMap[selectedPayment] === 'Banking'){
       this.isBA = true;
       this.isCC = false;
        for(let bankAccountDetails of this.bnkList){
           if(bankAccountDetails.tokenId === selectedPayment){
            this.baResponse = bankAccountDetails;
            break;
         }
        }
        this.paymentType = "BANKINGACCOUNT";
     }
   }

   formatAccountType(accountType: string){
     if(accountType === 'BUSSAVINGS'){
       return accountType = 'Business Savings';
     }else if(accountType === 'PERSONALSAVINGS'){
       return accountType = 'Personal Savings';
     }else if(accountType === 'BUSCHECKING'){
       return accountType = 'Business Checking';
     }else if(accountType === 'PERSONALCHECKING'){
       return accountType = 'Personal Checking';
     }else if(accountType === 'MASTERCARD'){
        return accountType = 'Master Card';
     }else if(accountType === 'VISA'){
        return accountType = 'VISA';
     }
   }

   selectedBill(bills: any){
     var subGroupId = bills.subGroupId;
     if(jQuery("#isBillChecked"+subGroupId).prop('checked') == true){
        this.selectedBillAccountToAdd.push(subGroupId);
     }else{
       for(var i = 0; i < this.selectedBillAccountToAdd.length; i++){
          if ( this.selectedBillAccountToAdd[i] === subGroupId) {
            this.selectedBillAccountToAdd.splice(i, 1);
          }
       }
     }
   }

  formatPayDate(dayOfMonth: string){
    var payDay;
     if (dayOfMonth == "01") {
           payDay = "1st"; 
        } else if (dayOfMonth == "02") {
           payDay = "2nd";
        } else if (dayOfMonth == "03") {
           payDay = "3rd";
        } else {
           payDay = dayOfMonth.slice(-1) + "th";
        }
        this.mwpCsrHttpService.dayOfMonth = payDay;
        return payDay;
   }

   saveAutoPaymentMethod (autoPaymentModel: any){
     this.planError = false;
     this.screenLoader = true;
     if(this.selectedBillAccountToAdd.length > 0){
        let recurringToAdd = [];    
        for(let linkedBills of this.getSummaryResponseList){
          for(let billAccounts of linkedBills.billAccounts){
            if(this.selectedBillAccountToAdd.indexOf(billAccounts.subGroupId) > -1){
              let hcidOrSummaryBillNo = null != linkedBills.personDetails.summaryBillNo ? linkedBills.personDetails.summaryBillNo : linkedBills.personDetails.hcid;
              let contractIndicator = (null !== hcidOrSummaryBillNo && undefined !== hcidOrSummaryBillNo && hcidOrSummaryBillNo.length === 6) ? 'SUMMARY_BILLED_MEMBER' : null;
                var tempAddRec = {
                    "productId": billAccounts.subGroupId,
                    "paymentMethods": {
                      "tokenId": autoPaymentModel.paymentMethod,
                      "paymentType": this.paymentType,
                      "bankAccountType": this.paymentType === 'BANKINGACCOUNT' ? this.baResponse.bankAccountType : this.ccResponse.bankAccountType
                    },
                    "memberDetails": {
                      "hcid": this.hcidEntered,
                      "linkedBills": [{
                        "linkRelationship": 'SUBSCRIBER',     
                        "contractIndicators": contractIndicator,
                        "personDetails": {
                          "hcid": this.hcidEntered,
                          "brand": this.brand,
                          "summaryBillNo": contractIndicator === 'SUMMARY_BILLED_MEMBER' ? linkedBills.personDetails.summaryBillNo : null
                        },
                        "billAccounts": [{
                          "paidToDate": billAccounts.paidToDate,
                          "subGroupId": billAccounts.subGroupId
                        }]
                      }]
                    },
                    "authMode": autoPaymentModel.authorization,
                    "payDate": this.formatPayDate(autoPaymentModel.dayOfMonth),
                    "createdBy": this.currentUser.username,
                    "emailId": this.emailAddressChecked && null != this.emailAddressTxt && this.emailAddressTxt !== '' ? this.emailAddressTxt: null
                  };
                  recurringToAdd.push(tempAddRec);
              }
            }
          }
  
          this.inputParam = {
                "hcid": this.hcidEntered,
                "action": "ADD",
                "recurringPaymentDetails": recurringToAdd
          }

          this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'updateRecurringPayment').subscribe((data:any) => {
          if(undefined !== data && null !== data && undefined !== data.recurringPaymentDetails && null !== data.recurringPaymentDetails){
            let recurringPaymentDetailsList = data.recurringPaymentDetails;
            this.paymentDetailsMap = {};
            for(let recurringPaymentDetails of recurringPaymentDetailsList){
              for(let billAccounts of this.linkedBillsList){
                  billAccounts.subscriberName = this.subscriberName;
                  if(billAccounts.subGroupId === recurringPaymentDetails.productId && recurringPaymentDetails.confirmStatus === 'Confirmed'){
                    billAccounts.status = 'Confirmed';
                    this.paymentDetailsMap[recurringPaymentDetails.productId] = billAccounts;
                  } else if (billAccounts.subGroupId === recurringPaymentDetails.productId && recurringPaymentDetails.confirmStatus === 'Failed'){
                    billAccounts.status = 'Failed';
                    billAccounts.errorMessage = recurringPaymentDetails.errorMessage;
                    this.paymentDetailsMap[recurringPaymentDetails.productId] = billAccounts;
                  }
                }  
            }
            this.mwpCsrHttpService.paymentDetailsMap = this.paymentDetailsMap;
            this.screenLoader = false;
            this.router.navigate(['/memberpay/confirmautopayment']);
          }
        },
        (err: any) => {
          this.screenLoader = false;
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
        });
      } else {
        this.screenLoader = false;
        this.planError = true;
      }
   }

   redirectToHome(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   redirectToAutoPay(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery("#confirmationModalOpener").click();   
     this.router.navigate(['/memberpay/paymentmethod']);
   }

}
