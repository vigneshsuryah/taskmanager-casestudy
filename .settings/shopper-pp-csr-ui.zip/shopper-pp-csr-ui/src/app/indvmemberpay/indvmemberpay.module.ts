import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndvHomeComponent } from './home/indvhome.component';
import { IndvManagePaymentMethodComponent } from './indvmanagepaymentmethod/indvmanagepaymentmethod.component';
import { IndvPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indvpaymentmethod.component';
import { IndvAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvautopayment.component';
import { IndvEmailComponent } from './indvmanagepaymentmethod/indvemail/indvemail.component';
import { IndvpaymentHistoryComponent } from './indvmanagepaymentmethod/indvpaymenthistory/indvpaymenthistory.component';
import { IndvAddPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indvaddpaymentmethod/indvaddpaymentmethod.component';
import { IndvEditPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indveditpaymentmethod/indveditpaymentmethod.component';
import { IndvAddAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvaddautopayment/indvaddautopayment.component';
import { IndvConfirmAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvconfirmautopayment/indvconfirmautopayment.component';
import { IndvDeleteAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvdeleteautopayment/indvdeleteautopayment.component';
import { IndvEditAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indveditautopayment/indveditautopayment.component'; 
import { IndvPDFBillComponent } from './indvmanagepaymentmethod/indvpdfbill/indvpdfbill.component';
import { MwpCsrHttpService } from '../shared/csr-service/mwp.csr.service';
import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { IndvAccountSummaryComponent } from './indvmanagepaymentmethod/indvaccountsummary/indvaccountsummary.component';
import { IndvOneTimePaymentComponent } from './indvmanagepaymentmethod/indvaccountsummary/indvonetimepayment/indvonetimepayment.component';

import { routes } from './indvmemberpay.routing';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { CommonutilsModule } from '../commonutils/commonutils.module';
import { UxModule } from '../shared/ux.module';
import { DatePipe } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),    
    RouterModule.forChild(routes)
  ],
  providers: [
    DatePipe,
    MwpCsrHttpService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [IndvHomeComponent, IndvManagePaymentMethodComponent, IndvPaymentMethodComponent, IndvAutoPaymentComponent, IndvEmailComponent, IndvAddPaymentMethodComponent, IndvEditPaymentMethodComponent, 
    IndvAddAutoPaymentComponent, IndvConfirmAutoPaymentComponent, IndvDeleteAutoPaymentComponent, IndvEditAutoPaymentComponent, IndvpaymentHistoryComponent, IndvPDFBillComponent,
    IndvAccountSummaryComponent, IndvOneTimePaymentComponent]
})
export class IndvMemberPayModule { 

}
