import { Routes } from '@angular/router';

import { IndvHomeComponent } from './home/indvhome.component';
import { IndvManagePaymentMethodComponent } from './indvmanagepaymentmethod/indvmanagepaymentmethod.component';
import { IndvPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indvpaymentmethod.component';
import { IndvAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvautopayment.component';
import { IndvEmailComponent } from './indvmanagepaymentmethod/indvemail/indvemail.component';
import { IndvAddPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indvaddpaymentmethod/indvaddpaymentmethod.component';
import { IndvEditPaymentMethodComponent } from './indvmanagepaymentmethod/indvpaymentmethod/indveditpaymentmethod/indveditpaymentmethod.component';
import { IndvAddAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvaddautopayment/indvaddautopayment.component';
import { IndvConfirmAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvconfirmautopayment/indvconfirmautopayment.component';
import { IndvDeleteAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indvdeleteautopayment/indvdeleteautopayment.component';
import { IndvEditAutoPaymentComponent } from './indvmanagepaymentmethod/indvautopayment/indveditautopayment/indveditautopayment.component';
import { IndvpaymentHistoryComponent } from './indvmanagepaymentmethod/indvpaymenthistory/indvpaymenthistory.component';
import { IndvPDFBillComponent } from './indvmanagepaymentmethod/indvpdfbill/indvpdfbill.component';
import { IndvAccountSummaryComponent } from './indvmanagepaymentmethod/indvaccountsummary/indvaccountsummary.component';
import { IndvOneTimePaymentComponent } from './indvmanagepaymentmethod/indvaccountsummary/indvonetimepayment/indvonetimepayment.component';
import { TechnicalErrorComponent } from '../commonutils/technicalerror/technicalerror.component';

export const routes: Routes = [ 
    { path: '', component: IndvHomeComponent },
    { path: 'home', component: IndvHomeComponent },
    { path: 'paymentmethod', component: IndvManagePaymentMethodComponent },
    { path: 'managepaymentmethod', component: IndvPaymentMethodComponent },
    { path: 'addnewpaymentmethod', component: IndvAddPaymentMethodComponent },
    { path: 'editpaymentmethod', component: IndvEditPaymentMethodComponent },
    { path: 'addnewautopayment', component: IndvAddAutoPaymentComponent },
    { path: 'manageautopayment', component: IndvAutoPaymentComponent },
    { path: 'email', component: IndvEmailComponent }, 
    { path: 'confirmautopayment', component: IndvConfirmAutoPaymentComponent },
    { path: 'deleteautopayment', component: IndvDeleteAutoPaymentComponent },
    { path: 'editautopayment', component: IndvEditAutoPaymentComponent },  
    { path: 'paymenthistory', component: IndvpaymentHistoryComponent },
    { path: 'pdfbill', component: IndvPDFBillComponent },
    { path: 'accountsummary', component: IndvAccountSummaryComponent },
    { path: 'onetimepayment', component: IndvOneTimePaymentComponent },
    { path: 'error', component: TechnicalErrorComponent}
];