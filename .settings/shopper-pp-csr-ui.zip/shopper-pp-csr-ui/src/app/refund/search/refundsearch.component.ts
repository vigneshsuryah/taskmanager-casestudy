import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { User } from '../../shared/models/user';

import { RefundService } from '../../shared/csr-service/refund.service';
import { RefundModel } from '../../shared/models/refund/refund.model';
declare var jQuery:any;

@Component({
  templateUrl: './refundsearch.component.html',
  styleUrls: ['./refundsearch.component.css']
})
export class RefundSearchComponent implements OnInit {
    
    refundModel: RefundModel;
    dateError: boolean;
    screenLoader: boolean;
    techError: boolean;
    showResults: boolean;
    isHCID: boolean;
    isConfNoOrOrderID: boolean;
    hasEntered: boolean;
    serviceError: boolean;
    refundResultsMap: any = {};
    serviceErrorMsg: string;
    paymentDetails: any = {};
    paymentDetailsList: any = [];

    constructor(private route: ActivatedRoute, private datePipe: DatePipe, private refundService: RefundService, private router: Router, private currentUser: User) {
        if(this.currentUser.userRole === undefined){
            this.router.navigate(['']);
        }
     }

    ngOnInit() {
        this.paymentDetails = {};
        this.serviceError = false;
        this.refundModel = new RefundModel();
        this.refundModel.payFromDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        this.refundModel.payToDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        this.refundService.transactionStatus = "";
        this.route.queryParams
            .filter(params => params.lob)
            .subscribe(params => {
                this.refundService.lob = params.lob;
        });

        if(this.refundService.backToList){
            this.refundModel = this.refundService.refundModel;
            this.refundSearch(this.refundModel);
            this.enterId(this.refundModel);
        }
    }

    compareDates(){
        if(new Date(this.refundModel.payFromDt) > new Date(this.refundModel.payToDt)){
            this.dateError = true;
        } else { 
            this.dateError = false;
        }
    }
    
    updateFromDate(date) {
        this.refundModel.payFromDt = this.datePipe.transform(date, 'MM/dd/yyyy');
        this.compareDates();
    }

    updateToDate(date) {
        this.refundModel.payToDt = this.datePipe.transform(date, 'MM/dd/yyyy');
        this.compareDates();
    }

    refundSearch(refundModel: RefundModel) {
        this.refundService.refundModel = refundModel;
        this.screenLoader = true;
        this.serviceError = false;
        this.techError = false;
        this.showResults = false;
        if (undefined !== refundModel.confNoOrOrderID && '' !== refundModel.confNoOrOrderID) {
            this.refundService.idType = "ORDERID";
            this.refundService.orderId = refundModel.confNoOrOrderID;
            let inputParams = {
                "orderId": refundModel.confNoOrOrderID,
            }
            this.refundService.getRefundResults(inputParams, 'v1/refundSearch', this.refundService.lob).subscribe((result: any) => {
                if (undefined !== result.paymentDetails && result.paymentDetails.length > 0) {
                    //this.paymentDetails = result.paymentDetails[0];
                    console.log("result.paymentDetails"+JSON.stringify(result.paymentDetails));
                    for(let paymentDetails of result.paymentDetails){
                        if(this.isValidTran(paymentDetails)) {
                            this.router.navigate(['/refund/paymentdetails'], { queryParams: { lob: this.refundService.lob } });
                        } else{
                            this.screenLoader = false;
                            this.serviceError = true;
                            this.serviceErrorMsg = "Sorry, the transaction cannot be refunded if its not complete.";
                        }
                    }
                } else {
                    this.screenLoader = false;
                    this.serviceError = true;
                    this.serviceErrorMsg = result.exceptions[0].message;
                }
            },
            (err: any) => {
                this.screenLoader = false;
                jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
                this.techError = true;
            });
        } else if(undefined !== refundModel.hcid && '' !== refundModel.hcid) {
            this.refundService.idType = "HCID";
            let inputParams = {
                "hcid": refundModel.hcid,
	            "depositFromDt": refundModel.payFromDt + '  00:00:00',
	            "depositToDt": refundModel.payToDt + '  23:59:59'
            }
            this.refundService.getRefundResults(inputParams, 'v1/refundSearch', this.refundService.lob).subscribe((result:any) => {
                this.screenLoader = false;
                this.paymentDetailsList = [];
                if (undefined !== result.paymentDetails && result.paymentDetails.length > 0) {
                    this.paymentDetailsList = result.paymentDetails;
                    for (let payment of this.paymentDetailsList) {
                         if (this.isValidTran(payment)) {
                            for (let transactions of payment.transactions) {
                                if (transactions.transactionType === 'PAYMENT') {
                                    transactions.anthemOrderId = payment.anthemOrderId;
                                    transactions.memberBillingId = payment.memberBillingId;
                                    transactions.paymentType = payment.paymentMethod.paymentType;
                                    transactions.lastFour = this.getLastFourFunding(payment);
                                    transactions.payDate = undefined !== transactions.paidDate ? transactions.paidDate.substring(5, 7) + '/' + transactions.paidDate.substring(8, 10) + '/' + transactions.paidDate.substring(0, 4) + ' ET' : "";
                                    this.refundResultsMap[payment.anthemOrderId] = transactions;
                                }
                            }
                        } 
                    }
                    if(Object.keys(this.refundResultsMap).length !== 0){
                        this.showResults = true;
                        setTimeout(()=>{
                            if (jQuery.fn.dataTable.isDataTable('#refund-table')) {
                                jQuery('#refund-table').DataTable();
                            } else {
                                jQuery('#refund-table').DataTable({
                                    "pagingType": "full_numbers",
                                    "lengthMenu": [5, 10, 15, 20],
                                    "dom": '<"table-div-wrapper"t><"clear"lip>',
                                    "language": {
                                        "paginate": {
                                        "previous": "Previous",
                                        "next": "Next",
                                        "first": "First",
                                        "last": "Last"
                                        }
                                    }
                                });
                            }
                            
                            // setting width internally
                            var widthOfTable = jQuery("#reports-table_wrapper").width();
                            jQuery(".table-div-wrapper").width(widthOfTable);
                        },100);
              
                        jQuery('html,body').animate({ scrollTop: jQuery("#refund-div").offset().top - jQuery("#refund-div").height()}, 'slow');
                    } else {
                        this.screenLoader = false;
                        this.serviceError = true;
                        this.serviceErrorMsg = "Sorry, the transaction cannot be refunded if its not complete.";
                    }
                    
                } else if(undefined !== result.exceptions && null !== result.exceptions) {
                    this.serviceError = true;
                    this.serviceErrorMsg = result.exceptions[0].message;
                }  
            },
            (err: any) => {
              this.screenLoader = false;
              jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
              this.techError = true;
            });
        }
        
    }

    isValidTran(paymentDetails: any) {
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if(transaction.transactionType == "PAYMENT" || transaction.transactionType == "REFUND") {
                    if(transaction.transactionStatus == "COMPLETED" || transaction.transactionStatus == "RETURNED" ) {
                        return true;
                    } else {
                      return false;
                    }   
                }
            }
        }
    }

    getLastFourFunding(payment : any) {
        if(undefined !== payment.paymentMethod) {
            if(payment.paymentMethod.paymentType == "CC") {
                return payment.paymentMethod.creditCardLastFour;
            } else if(payment.paymentMethod.paymentType == "ACH") {
                let bankAccount = payment.paymentMethod.bankAccountNumber;
                return bankAccount.slice(-4);
            } else {
                return '';
            }
        }  
    }

    getConfirmationDetails(orderId: string, transactionStatus: string){
        this.refundService.orderId = orderId;
        this.refundService.transactionStatus = transactionStatus;
        this.router.navigate(['/refund/paymentdetails'], { queryParams: { lob: this.refundService.lob } });
    }

    clearSearch(){
        this.refundModel.hcid = '';
        this.refundModel.confNoOrOrderID = '';
        this.refundModel.payFromDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        this.refundModel.payToDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        this.showResults = false;
        this.techError = false;
        this.hasEntered = false;
        this.dateError = false;
        this.serviceError = false;
        jQuery("#payFromDtDiv").children().prop('disabled',false);
        jQuery("#payToDtDiv").children().prop('disabled',false);
    }

    enterId(refundModel: RefundModel){
        this.hasEntered = true;
        if("" !== refundModel.hcid && undefined !== refundModel.hcid){
            this.isHCID = true;
        } else {
            this.isHCID = false;
        } 
        if("" !== refundModel.confNoOrOrderID && undefined !== refundModel.confNoOrOrderID){
            this.isConfNoOrOrderID = true;
            jQuery("#payFromDtDiv").children().prop("disabled",true);
            jQuery("#payToDtDiv").children().prop("disabled",true);
            refundModel.payFromDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
            refundModel.payToDt = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        } else {
            jQuery("#payFromDtDiv").children().prop('disabled',false);
            jQuery("#payToDtDiv").children().prop('disabled',false);
            this.isConfNoOrOrderID = false;
        }
        if("" === refundModel.hcid && "" === refundModel.confNoOrOrderID){
            this.hasEntered = false;
            jQuery("#payFromDtDiv").children().prop('disabled',false);
            jQuery("#payToDtDiv").children().prop('disabled',false);
        }
    }

}
