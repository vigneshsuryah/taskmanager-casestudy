import { Routes } from '@angular/router';
import { RefundHomeComponent } from './home/refundhome.component';
import { RefundSearchComponent } from './search/refundsearch.component';
import { RefundPaymentDetailsComponent } from './paymentdetails/refundpaymentdetails.component';
import { RefundRequestComponent } from './request/refundrequest.component';

export const routes: Routes = [
    { path: 'home', component: RefundHomeComponent },
    { path: 'search', component: RefundSearchComponent },
    { path: 'paymentdetails', component: RefundPaymentDetailsComponent },
    { path: 'request', component: RefundRequestComponent }
];
