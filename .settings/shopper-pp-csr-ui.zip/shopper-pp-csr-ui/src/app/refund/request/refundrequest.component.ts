import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { RefundService } from '../../shared/csr-service/refund.service';
import { User } from '../../shared/models/user';
import { RefundModel } from '../../shared/models/refund/refund.model';
declare var jQuery: any;

@Component({
  templateUrl: './refundrequest.component.html',
  styleUrls: ['./refundrequest.component.css']
})
export class RefundRequestComponent implements OnInit {
  
  orderId: string;
  refundAmount: string;
  techError: boolean = false;
  screenLoader: boolean = false;
  refundModel: RefundModel;
  serviceError: boolean;
  serviceErrorMsg: string;
  refundConfirmationData: any = {};
  refundDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');

  constructor(private router: Router, private datePipe: DatePipe, private currentUser: User, private refundService: RefundService) { 
    if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.orderId = this.refundService.orderId;
    this.refundConfirmationData = this.refundService.memberInfo;
    this.refundModel = new RefundModel();
  }

  submitRefund(refundModel) {
    this.techError = false;
    this.serviceError = false;
    this.screenLoader = true;
    let amount = 0;
    if(refundModel.refundAmount.indexOf("$") > -1){
      amount = refundModel.refundAmount.substring(1);
    } else {
      amount = refundModel.refundAmount;
    }
    let inputParams = {
      "orderId": this.orderId,
      "refundAmount": amount,
      "refundReason": refundModel.notes
    }
    this.refundService.getRefundResults(inputParams, '/v1/refundPayment', this.refundService.lob).subscribe((result: any) => {
      if (undefined !== result && result.status == "SUCCESS") {
        this.screenLoader = false;
        document.getElementById('refundModalOpener').click();
      } else {
        this.screenLoader = false;
        this.serviceError = true;
        this.serviceErrorMsg = result.exceptions[0].message;
      }
    },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techError = true;
      });
  }

  backToPaymentDetails(){
    this.router.navigate(['/refund/paymentdetails'], { queryParams: { lob: this.refundService.lob } });
  }

  backToSearch(){
    document.getElementById('refundModalOpener').click();
    this.router.navigate(['/refund/search'], { queryParams: { lob: this.refundService.lob } });
  }

}
