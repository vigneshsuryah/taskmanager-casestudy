import { FeedbackService } from '../shared/csr-service/feedback.service';
import { NgModule } from '@angular/core';
import { CommonModule} from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';

import { TokenInterceptor } from '../shared/interceptor/token.interceptor';
import { UxModule } from '../shared/ux.module';
import { CommonutilsModule } from '../commonutils/commonutils.module';

import { FeedbackComponent } from './home/feedback.component';
import { routes } from './feedback.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UxModule,
    CommonutilsModule.forRoot(),
    RouterModule.forChild(routes)
  ],
  providers: [
    FeedbackService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }
  ],
  declarations: [
    FeedbackComponent
  ]
})
export class FeedbackModule {}
