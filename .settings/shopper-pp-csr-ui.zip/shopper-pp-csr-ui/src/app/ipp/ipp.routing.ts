import { Routes } from '@angular/router';

import { IPPHomeComponent } from './home/ipphome.component';
import { PaymentOptionsComponent } from './paymentoptions/paymentoptions.component';
import { ApplicationPdfComponent } from './applicationpdf/applicationpdf.component';

export const routes: Routes = [
    { path: 'home', component: IPPHomeComponent },
    { path: 'paymentoptions', component: PaymentOptionsComponent },
    { path: 'applicationpdf', component: ApplicationPdfComponent }
];