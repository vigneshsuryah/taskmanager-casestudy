import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { User } from '../../shared/models/user';
import { ReportsService } from '../../shared/csr-service/reports.service';
import { DatePipe } from '@angular/common'; 

@Component({
  moduleId: module.id,
  selector: 'csr-tppayers',
  templateUrl: 'tppayers.component.html',
  styleUrls: ['tppayers.component.css']
})
export class TPPayersComponent implements OnInit {

  tppayers = {  
    'fromdate': this.datePipe.transform(new Date(), 'MM-dd-yyyy') ,
    'todate': this.datePipe.transform(new Date(), 'MM-dd-yyyy') ,
    'lobSelected': ''
  }

  options = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Third Party Payers List',
    useBom: false,
    noDownload: false,
    headers: []
  };
  
  noResults: boolean = true;
  techerror: boolean = false; 
  screenLoader: boolean = false;
  showTable: boolean = false;
  inputParam : any = {};
  tppMemberDetails : any = [];
  relOrgNameHeaderVal: string = 'Relationship Name';
  relOrgTypeHeaderVal: string = 'Relationship Type';
  csvHeaderCOMM = ['No.','TPP Unique ID', 'First Name', 'Last Name', 'Email ID', 'Phone Number', 'Registration Date', 'Relationship Name', 'Relationship Type'];
  csvHeaderGBD = ['No.','TPP Unique ID', 'First Name', 'Last Name', 'Email ID', 'Phone Number', 'Registration Date', 'Organization Name', 'Organization Type'];

  lineOfBusiness = [{
    label: 'Commercial / Individual Third Party',
    value: 'COMM'
  },{
    label: 'Indiana Medicaid Third Party',
    value: 'GBDIN'
  },{
    label: 'Kentucky Medicaid Third Party',
    value: 'GBDKY'
  }];

  relTypeMap = {
    "WHIP_TPG":"Employer",
    "WHIP_TPS":"State Agency",
    "WHIP_TPN":"Non-Profit",
    "WPNT_TPS":"Federal or State Program",
    "WPNT_TRL":"Relative\\Legal guardian of subscriber",
    "WPNT_TRB":"Indian tribes, tribal organizations or urban Indian organizations",
    "WPNT_TRW":"The Ryan White HIV/AIDS Program"
  }

  constructor(public router: Router, private currentUser: User, private reportsService : ReportsService, private datePipe: DatePipe ) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
        this.noResults = true;
        this.techerror = false;
        this.tppMemberDetails = [];
        this.tppayers.lobSelected = 'COMM';
        jQuery.fn.datepicker.defaults.autoclose = true;
        jQuery.fn.datepicker.defaults.format = "mm-dd-yyyy";
        jQuery.fn.datepicker.defaults.endDate = "0d";
        jQuery.fn.datepicker.defaults.orientation = "bottom auto";       
   }
 
   getTppMemberDetails(){
     
      this.tppMemberDetails = [];
      this.noResults = true;
      this.screenLoader = true;
      this.techerror = false;
      this.inputParam = {
        "fromDate": this.datePipe.transform(jQuery('#fromDate').val(), 'yyyy-MM-dd'),
        "toDate":this.datePipe.transform(jQuery('#toDate').val(), 'yyyy-MM-dd'),
        "lob": this.tppayers.lobSelected
      }
      
      if(this.tppayers.lobSelected === 'COMM'){
        this.relOrgNameHeaderVal = 'Relationship Name';
        this.relOrgTypeHeaderVal = 'Relationship Type';
        this.options.headers = this.csvHeaderCOMM;
      } else if(this.tppayers.lobSelected === 'GBDIN' || this.tppayers.lobSelected === 'GBDKY'){
        this.relOrgNameHeaderVal = 'Organization Name';
        this.relOrgTypeHeaderVal = 'Organization Type';
        this.options.headers = this.csvHeaderGBD;
      }

      this.tppMemberDetails = [];

    this.reportsService.getThirdPartyPayerDetails(this.inputParam).subscribe((data:any) => {
      this.screenLoader = false;
      this.showTable = true;
      let sNo =  1;
      if(null !== data && undefined !== data && null !== data.tppmemberDetail && undefined !== data.tppmemberDetail && data.tppmemberDetail.length > 0){
      
        data.tppmemberDetail.sort(function(a: any,b: any){ 
          return new Date(b.createdDate.substring(0,10)).getTime() - new Date(a.createdDate.substring(0,10)).getTime();
        });

        for (let tppPayer of data.tppmemberDetail) {
          var temp = {
            'sNo': sNo++,
            'uniqueId': tppPayer.uniqueId,
            'firstName': tppPayer.firstName,
            'lastName': tppPayer.lastName,
            'emailId': tppPayer.emailId,
            'phoneNumber': tppPayer.phoneNumber,
            'createdDate': this.datePipe.transform(tppPayer.createdDate.substring(0,10),'MM/dd/yyyy'),
            'relName': tppPayer.relName,
            'relType': this.relTypeMap[tppPayer.relType]
          };
          this.tppMemberDetails.push(temp);
        }
          this.noResults = false;
       }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });

   }

   downloadTppMemberDetails(){
    new Angular5Csv(this.tppMemberDetails, "third-party-payers-list-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.options);
   }

}
