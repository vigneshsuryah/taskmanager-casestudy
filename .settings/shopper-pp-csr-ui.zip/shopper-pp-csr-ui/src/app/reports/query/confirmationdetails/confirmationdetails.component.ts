import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ReportsService } from '../../../shared/csr-service/reports.service';
import { User } from '../../../shared/models/user';
declare var jQuery:any;

@Component({
  moduleId: module.id,
  templateUrl: 'confirmationdetails.component.html',
  styleUrls: ['confirmationdetails.component.css']
})
export class ConfirmationDetailsComponent implements OnInit {

    confirmationNo: string;
    screenLoader: boolean;
    searchCriteria: any = {};
    transactionDetails: any = {};
    orderId : string;
    transactionStatus: string;
    isACH: boolean;
    techerror: boolean = false;

    constructor(public router: Router, private currentUser: User, private reportsService: ReportsService) {
        if(this.currentUser.userRole === undefined){
            this.router.navigate(['']);
        }
    }

    ngOnInit() {
        this.searchCriteria = this.reportsService.searchCriteria;
        this.transactionStatus = this.reportsService.transactionStatus;
        this.orderId = this.reportsService.orderId;
        this.getConfirmationDetails();
    }

    getConfirmationDetails() {
        this.screenLoader = true;
        this.reportsService.getConfirmationDetails(this.orderId, this.transactionStatus).subscribe((result: any) => {
            this.screenLoader = false;
            if (result.success) {
                if (result.data.transaction_info.payment_type === 'ACH') {
                    this.isACH = true;
                } else {
                    this.isACH = false;
                }
                this.transactionDetails = result.data;
            } else {
                jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
                this.techerror = true;
            }
        },
            (err: any) => {
                this.screenLoader = false;
                jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
                this.techerror = true;
            });
    }

    backToSearch(){
        this.reportsService.isEdit = false;
        this.router.navigate(['/reports/home'], { queryParams: { page: 'QUERY' } });
    }

    editSearch(searchCriteria: any): any {
        this.reportsService.searchCriteria = searchCriteria;
        this.reportsService.isEdit = true;
        this.router.navigate(['/reports/home'], { queryParams: { page: 'QUERY' } });
    }

    backToList(){
        this.router.navigate(['/reports/searchresult'])
    }

}
