import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'; 

import { User } from '../../shared/models/user';
import { ReportsService } from '../../shared/csr-service/reports.service';
import { content } from '../../shared/constants/constants';
import { QueryModel } from '../../shared/models/reports/query.model';

@Component({
  moduleId: module.id,
  selector: 'csr-query',
  templateUrl: 'query.component.html',
  styleUrls: ['query.component.css']
})
export class QueryComponent implements OnInit {

  techerror: boolean = false; 
  screenLoader: boolean = false;
  dateError: boolean = false;
  hasDateType: boolean = false;
  fieldError: boolean;
  content : any = {};
  queryResult: any = [];
  queryModel: QueryModel;
  tempQuery: QueryModel;
  
  constructor(public router: Router, private currentUser: User, private reportsService : ReportsService, private datePipe: DatePipe ) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.clearSearchResults();
    this.content = content;
    if(undefined !== this.reportsService.isEdit && this.reportsService.isEdit === true){
      this.queryModel = this.reportsService.searchCriteria;
      this.fieldError = false;
      this.hasDateType = true;
      this.dateError = false;
    }
  }

  changePayType(payType : string){
    if(payType === 'achType'){
        this.queryModel.achType = 'achType';
        this.queryModel.ccType = '';
        this.queryModel.ccBinNo = '';
        this.queryModel.ccLastFourDigits = '';
    }else{
        this.queryModel.achType = '';
        this.queryModel.ccType = 'ccType';
        this.queryModel.accountNo = '';
        this.queryModel.routingNo = '';
    }
    this.emptyCheck(this.queryModel);
  }

  getQueryResults(queryModel: QueryModel){
    this.reportsService.searchCriteria = queryModel;
    this.router.navigate(['/reports/searchresult']);
  }
    
  compareDates(){
    if(new Date(this.queryModel.fromdate) > new Date(this.queryModel.todate)){
      this.dateError = true;
    } else { 
      this.dateError = false;
    }
  }
  
  updateFromDate(date) {
    this.queryModel.fromdate = this.datePipe.transform(date, 'MM/dd/yyyy');
    this.compareDates();
  }

  updateToDate(date) {
    this.queryModel.todate = this.datePipe.transform(date, 'MM/dd/yyyy');
    this.compareDates();
  }

  enterBankDetails(queryModel: QueryModel){
    if((queryModel.routingNo !== null && queryModel.routingNo !== '') || (queryModel.accountNo !== null && queryModel.accountNo !== '')){
      this.changePayType('achType');
    } else {
      this.queryModel.achType = '';
    }
    this.emptyCheck(queryModel);
  }

  enterCCDetails(queryModel: QueryModel){
    if((queryModel.ccBinNo !== null && queryModel.ccBinNo !== '') || (queryModel.ccLastFourDigits !== null && queryModel.ccLastFourDigits !== '')){
      this.changePayType('ccType');
    } else {
      this.queryModel.ccType = '';
    }
    this.emptyCheck(queryModel);
  }

  emptyCheck(queryModel: QueryModel){
    this.tempQuery = new QueryModel();
    this.tempQuery.fromdate = queryModel.fromdate;
    this.tempQuery.todate = queryModel.todate;
    this.tempQuery.achType = queryModel.achType;
    this.tempQuery.ccType = queryModel.ccType;
    this.tempQuery.dateType = queryModel.dateType;
    if(JSON.stringify(this.tempQuery) !== JSON.stringify(queryModel)){
      this.fieldError = false;
    } else {
      this.fieldError = true;
    }
  }

  clearSearchResults(){
    this.queryModel = new QueryModel();
    this.queryModel.fromdate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
    this.queryModel.todate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
    this.techerror = false;    
    this.dateError = false;
    this.fieldError = true;
    this.hasDateType = false;
  }

  selectDateType(){
    this.hasDateType = true;
  }

}
