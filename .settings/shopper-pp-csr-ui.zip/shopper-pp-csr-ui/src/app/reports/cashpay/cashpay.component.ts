import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { ReportsService } from '../../shared/csr-service/reports.service';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DatePipe } from '@angular/common'; 

@Component({
  moduleId: module.id,
  selector: 'csr-cashpay',
  templateUrl: 'cashpay.component.html',
  styleUrls: ['cashpay.component.css']
})
export class CashPayDetailsComponent implements OnInit {

  cashPay = {  
    'hcid': ''
  }
  noResults: boolean = true;
  techerror: boolean = false;
  screenLoader: boolean = false;
  showTable: boolean = false;
  cashPayMemberDetails : any = [];
  inputParam : any = {};
  options = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true, 
    showTitle: false,
    title: 'Cash Pay Details',
    useBom: false,
    noDownload: false,
    headers: ['Barcode Number','Sub Group ID','Summary Bill No','Payment Amount','Payment Date','Payment Status','LOB','Created Date','Retailer Name','Retailer Location','CashTie Reference Number']
  };

  constructor(public router: Router, private currentUser: User, private reportsService : ReportsService, private datePipe: DatePipe) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
       this.noResults = true;
       this.techerror = false;
       this.cashPayMemberDetails = [];
   }

   getCashPayDetails(){
       if(null == this.cashPay.hcid || "" == this.cashPay.hcid){
         return true;
       }
       this.screenLoader = true;
       this.noResults = true;
       this.techerror = false;
       this.cashPayMemberDetails = [];
       this.inputParam = {
        "hcid": this.cashPay.hcid
      }
      this.reportsService.getCashPaymentDetails(this.inputParam).subscribe((data:any) => {
      this.screenLoader = false;
      this.showTable = true;
      if(null !== data && undefined !== data && null !== data.cashPayMemberDetails && undefined !== data.cashPayMemberDetails && data.cashPayMemberDetails.length > 0){
        data.cashPayMemberDetails.sort(function(a: any,b: any){ 
          return new Date(b.paymentDate.substring(0,10)).getTime() - new Date(a.paymentDate.substring(0,10)).getTime();
        });
         
         for (let cashPayment of data.cashPayMemberDetails) {
          var temp = {
            'barCode': "'"+cashPayment.barCode+"'",
            'subGroupId': null !== cashPayment.subGroupId ? cashPayment.subGroupId : "",
            'summaryBillNo': null !== cashPayment.summaryBillNo ? cashPayment.summaryBillNo : "",
            'paymentAmount': ".00" === cashPayment.paymentAmount ? "0.00" :  cashPayment.paymentAmount, 
            'paymentDate': this.datePipe.transform(cashPayment.paymentDate.substring(0,10),'MM/dd/yyyy'),
            'paymentStatus': cashPayment.paymentStatus,
            'lob': cashPayment.lob,
            'createdDate': this.datePipe.transform(cashPayment.createdDate.substring(0,10),'MM/dd/yyyy'),
            'retailerName': cashPayment.retailerName,
            'location': cashPayment.location,
            'confirmationNo': "'"+cashPayment.confirmationNo+"'"
          };
          this.cashPayMemberDetails.push(temp);
        }
        
      
        this.noResults = false;
       }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
   }

   downloadCashPayDetails(){
    new Angular5Csv(this.cashPayMemberDetails, "cash-pay-member-details-"+this.datePipe.transform(new Date(),'yyyy-MM-dd-HH-mm-ss-SSS'), this.options);
   }

   removeSingleQuotes(barcode : string){
     return barcode.replace(/'/g, '');
   }

}
