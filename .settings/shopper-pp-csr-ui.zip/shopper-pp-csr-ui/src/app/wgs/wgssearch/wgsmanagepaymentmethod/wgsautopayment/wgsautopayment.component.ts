import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { WgsService } from '../../../../shared/csr-service/wgs.service';
import { Wgscsr } from '../../../../shared/models/wgs/wgscsr';

@Component({
  moduleId: module.id,
  selector: 'csr-wgsautopayment',
  templateUrl: 'wgsautopayment.component.html',
  styleUrls: ['wgsautopayment.component.css']
})
export class WgsAutoPaymentComponent implements OnInit {

  content: any ={};
  selectedMethod: string;
  hcid: string;
  getRecurringResponse: any = {};
  getRecurringPaymentsList: any = [];
  updatedRecurringPaymentsList: any = [];
  screenLoader: boolean = false;
  responseCode: string;
  updateRecurringResponse: any = {};
  deleteRecurringPayment: any = {};
  hasRecurring: boolean = true;
  getPaymentMethodResponse: any = {};
  hasPaymentMethods: boolean = true;
  responseLength: any = 0;
  isDeleted: boolean = true;
  techerror: boolean = false;
  hasThirdParty: boolean = false;

  constructor(public router: Router, public wgscsr : Wgscsr, public wgsService : WgsService, private currentUser: User){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

   ngOnInit() {
     this.hasPaymentMethods = false;
     this.techerror = false;
     this.hcid = this.wgscsr.healthCardId;
     this.getPaymentMethods();
     this.getRecurringDetails();
   }

   redirectToHome() {
     this.router.navigate(['/wgs/wgssearch']);
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      }
   }

   addAutoPayments(){
     this.router.navigate(['/wgs/wgsaddautopayment']);
   }

   edit(recurringPayments: any){
     this.wgscsr.editRecurringPayment = recurringPayments;
     this.router.navigate(['/wgs/wgseditautopayment']);
   }

   delete(recurringPayments: any){
    this.deleteRecurringPayment = recurringPayments;
    jQuery("#confirmationModalOpener").click();
   }

   cancelDelete(selected: string){
      this.wgscsr.paymentOption = selected;
      jQuery("#confirmationModalOpener").click();
      this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   confirmDelete(){
    this.deleteRecurringDetails();
   }

   success(selected: string){
     jQuery("#deleteConfirmationModalOpener").click();
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   formatPayDate(payDate: string){
     if (payDate == "01") {
           return payDate = "1st";
        } else if (payDate == "02") {
            return payDate = "2nd";
        } else if (payDate == "03") {
            return payDate = "3rd";
        } else {
            return payDate = payDate.slice(-1) + "th";
        }
   }

    getRecurringDetails(){
      this.screenLoader = true;
      this.getRecurringResponse = {};
      this.getRecurringPaymentsList = [];
      var inputParams = {
        "healthCardId" : this.wgscsr.healthCardId
      }   
      this.wgsService.getRecurring(inputParams).subscribe((data: any) => {
      this.screenLoader = false;
      this.getRecurringResponse = data;
      this.getRecurringPaymentsList = this.getRecurringResponse.memberpayRecurringPayments;
      if(null !== this.getRecurringPaymentsList && undefined !== this.getRecurringPaymentsList){
        this.hasRecurring = true;
        for (let recurringPayments of this.getRecurringPaymentsList) {
          if ( recurringPayments && recurringPayments.createdBy && recurringPayments.createdBy !== '') {
            this.hasThirdParty = true;
          }
        }
      } else {
        this.hasRecurring = false;
      }
      
    },
    (err: any) => {
      this.screenLoader = false;
      this.techerror = true;
      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
    });
    }

    deleteRecurringDetails(){
      this.screenLoader = true;
      var inputParams = {
        "healthCardId": this.wgscsr.healthCardId,
        "recurringPaymentDetails": [{
        "planID": this.deleteRecurringPayment.memberPayBillAcount.planId,
        "productID": this.deleteRecurringPayment.memberPayBillAcount.productId,
        "payDate": this.deleteRecurringPayment.payDate,
        "createdBy": this.deleteRecurringPayment.createdBy,
        "authMode": "PPD",
        "tokenID": this.deleteRecurringPayment.tokenID,
        "paymentType": this.deleteRecurringPayment.paymentType.toUpperCase()
      }],
      "action": "DELETE",
      "csrFlag": true,
      "csrUserId": this.currentUser.username
      }
      this.wgsService.updateRecurring(inputParams).subscribe((data: any) => {
          this.screenLoader = false;
          if(data.message.messageCode === "0"){
            this.isDeleted = true;
            jQuery("#confirmationModalOpener").click();
            jQuery("#deleteConfirmationModalOpener").click();
            this.getRecurringDetails();
          }
      },
      (err: any) => {
          this.screenLoader = false;
          jQuery("#confirmationModalOpener").click();
          this.isDeleted = false;
          jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      }
      );
      this.deleteRecurringPayment = {};
    }

    formatType(paymentType: string){
      if(paymentType === 'BankAccount'){
        return paymentType = 'Bank Account';
      } else if (paymentType === 'CreditCard'){
        return paymentType = 'Credit Card';
      }
    }

    getPaymentMethods(){
     var inputParams = {
        "memberId" : this.wgscsr.healthCardId
      }
      this.screenLoader = true;
      this.hasPaymentMethods = false;
      this.wgsService.getPaymentMethods(inputParams).subscribe((data: any) => {
        this.screenLoader = false;
        this.getPaymentMethodResponse = data;
        if (this.getPaymentMethodResponse.bankAccountDetails !== undefined && this.getPaymentMethodResponse.bankAccountDetails.length > 0)  {
        this.hasPaymentMethods = true;
        }   
    },
    (err: any) => {
      this.techerror = true;
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      });
    }
}
