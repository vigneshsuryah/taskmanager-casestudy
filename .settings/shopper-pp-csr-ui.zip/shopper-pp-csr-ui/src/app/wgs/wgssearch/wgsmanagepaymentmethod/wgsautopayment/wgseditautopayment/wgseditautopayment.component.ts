import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../../shared/models/user';
import { content } from '../../../../../shared/constants/constants';
import { Wgscsr } from '../../../../../shared/models/wgs/wgscsr';
import { WgsService } from '../../../../../shared/csr-service/wgs.service';

@Component({
  moduleId: module.id,
  selector: 'csr-wgseditautopayment',
  templateUrl: 'wgseditautopayment.component.html',
  styleUrls: ['wgseditautopayment.component.css']
})
export class WgsEditAutoPaymentComponent implements OnInit {

  wgscsrModel = {  
    'authorization': '',
    'paymentMethod': '',
    'dayOfMonth': '',
  }
  content : any ={};
  editRecurringPayment: any = {};
  screenLoader: boolean = false;
  getPaymentMethodResponse: any = {};
  responseLength: any = 0;
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  ccResponse: any = {};
  baResponse: any = {};
  isCC: boolean;
  isBA: boolean;
  paymentType: string;
  techerror: boolean = false;
  paymentmethodReqError : boolean = false;
  tokenMatched : boolean = false;

  constructor(public router: Router, public wgsService: WgsService, private currentUser: User, private wgscsr : Wgscsr){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.screenLoader = true;
    this.tokenMatched = false;
    var paymentMethodsListComposed: any = [];
    this.paymentmethodReqError = false;
    this.content = content;
    this.editRecurringPayment = this.wgscsr.editRecurringPayment;
    this.wgscsrModel.dayOfMonth = this.editRecurringPayment.payDate;
    this.getPaymentMethods();
    setTimeout(()=>{
        jQuery("#dayOfMonth").find(".psButton").prop('disabled',true);  
        jQuery("#dayOfMonth").find(".psOption").prop('disabled',true);
        jQuery(".sb-checkbox-font").find(".pcLabel").addClass('pcLabelFontOverride');
    },100);
  }

  getPaymentMethods(){
      var paymentMethodsListComposed: any = [];
      this.tokenMatched = false;
      var inputParams = {
        "memberId" : this.wgscsr.healthCardId
      }
      this.screenLoader = true;
      this.wgsService.getPaymentMethods(inputParams).subscribe((data: any) => {
        this.screenLoader = false;
        this.getPaymentMethodResponse = data;
        if ((this.getPaymentMethodResponse.creditCardDetails !== undefined && this.getPaymentMethodResponse.creditCardDetails.length == 0)
          || (this.getPaymentMethodResponse.bankAccountDetails !== undefined && this.getPaymentMethodResponse.bankAccountDetails.length == 0)) {
           this.responseLength = 0;
           let tempBnkItem = {
              label : 'No Saved Payment method',
              value : 'No Saved Payment method'
            }
           paymentMethodsListComposed.push(tempBnkItem);
        } else {
          if (this.getPaymentMethodResponse.creditCardDetails !== undefined){
            var ccList = this.getPaymentMethodResponse.creditCardDetails;
            this.responseLength += ccList.length;
            for(var i = 0; i <= ccList.length-1; i++){
              var labelString = '';
              this.creditCardBankAccNbrMap[ccList[i].tokenId] = ccList[i].creditCardNumber;
              this.paymentTypeMap[ccList[i].tokenId] = 'CreditDebitCard';

              if(ccList[i].creditCardType == "MC"){
                labelString = "Mastercard ending in ";
              }else if(ccList[i].creditCardType == "VISA"){
                labelString = "VISA ending in ";
              }
              labelString = labelString + ccList[i].creditCardNumber.slice(-4);
              var tempCCItem = {
                label : labelString,
                value : ccList[i].tokenId
              }
              paymentMethodsListComposed.push(tempCCItem);
              }
          }

          if (this.getPaymentMethodResponse.bankAccountDetails !== undefined) {
            var bnkList = this.getPaymentMethodResponse.bankAccountDetails;
            this.responseLength += bnkList.length;
            for(var i = 0; i <= bnkList.length-1; i++){
              var labelString = '';
              this.creditCardBankAccNbrMap[bnkList[i].tokenId] = bnkList[i].bankAccountNumber;
              this.paymentTypeMap[bnkList[i].tokenId] = 'Banking';
              this.bankAccountTypeMap[bnkList[i].tokenId] = bnkList[i].bankAccountType;

              if(bnkList[i].bankAccountType == "BUSINESS_SAVINGS" || bnkList[i].bankAccountType == "PERSONAL_SAVINGS"){
                labelString = "Savings ending in ";
              }else if(bnkList[i].bankAccountType == "BUSINESS_CHECKING" || bnkList[i].bankAccountType == "PERSONAL_CHECKING"){
                labelString = "Checking ending in ";
              }
              labelString = labelString + bnkList[i].bankAccountNumber.slice(-4);
              var tempBnkItem = {
                label : labelString,
                value : bnkList[i].tokenId
              }
              paymentMethodsListComposed.push(tempBnkItem);
              }
          }
        }
        if(undefined !== this.editRecurringPayment.tokenID && "" !== this.editRecurringPayment.tokenID){
          this.selectedPaymentMethod(this.editRecurringPayment.tokenID);
          if(this.tokenMatched){
            this.wgscsrModel.paymentMethod = this.editRecurringPayment.tokenID;
          }else{
             let payMethodCount = 0;
             for(let payMethod of paymentMethodsListComposed){
                 if(payMethod.label !== 'No Saved Payment method'){
                       payMethodCount++;
                 }
             }
             if(payMethodCount == 0){
                this.wgscsrModel.paymentMethod = 'No Saved Payment method';
             }
          }
        }        
    },
    (err: any) => {
      this.screenLoader = false;
      this.techerror = true;
      let tempBnkItem = {
              label : 'No Saved Payment method',
              value : 'No Saved Payment method'
            }
      paymentMethodsListComposed.push(tempBnkItem);
      this.wgscsrModel.paymentMethod = 'No Saved Payment method';
      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      });
      this.content.paymentMethodsList = paymentMethodsListComposed;  
  }

   editAutoPaymentMethod (wgscsrModel: any){
      this.paymentmethodReqError = false;
      if(wgscsrModel.paymentMethod === ''){
          this.paymentmethodReqError = true;
          return;
      }
      this.screenLoader = true;
      var inputParams = {
        "healthCardId": this.wgscsr.healthCardId,
        "recurringPaymentDetails": [{
          "planID": this.editRecurringPayment.memberPayBillAcount.planId,
          "productID": this.editRecurringPayment.memberPayBillAcount.productId,
          "payDate": wgscsrModel.dayOfMonth,
          "createdBy": this.wgscsr.healthCardId,
          "authMode": "PPD",
          "tokenID": wgscsrModel.paymentMethod,
          "paymentType": this.paymentType
        }],
        "action": "UPDATE",
        "csrFlag": true,
        "csrUserId": this.currentUser.username
      }    

      this.wgsService.updateRecurring(inputParams).subscribe((data: any) => {
          this.screenLoader = false;
          if(data.message.messageCode === "0"){
          jQuery("#confirmationModalOpener").click();
          } 
      },
      (err: any) => {
          this.techerror = true;
          this.screenLoader = false;
          jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');
      }
      ); 
   }

   cancel(selected: string){
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   redirectToAutoPay(selected: string){
     this.wgscsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   formatDate(inputDate: string){
     var dateArr  = [];
     if(null !== inputDate && undefined !== inputDate){
        dateArr = inputDate.split("-");
        if(dateArr.length === 3){
          inputDate = dateArr[1] + "/" + dateArr[2] + "/" + dateArr[0];
        }
     }
     return inputDate;
   }

   formatAmount(inputAmt: string){
     if(null !== inputAmt && inputAmt.length > 0 && undefined !== inputAmt){
       inputAmt = "$" + inputAmt;
     }
     return inputAmt;
   }

   selectedPaymentMethod(selectedPayment: string){
     if(this.paymentTypeMap[selectedPayment] === 'CreditDebitCard'){
       this.isCC = true;
       this.isBA = false;
       for(let creditCardDetails of this.getPaymentMethodResponse.creditCardDetails){
         if(creditCardDetails.tokenId === selectedPayment){
            this.ccResponse = creditCardDetails;
            this.tokenMatched = true;
            break;
         }
       }
       this.paymentType = "CREDITCARD"; 
     } else if(this.paymentTypeMap[selectedPayment] === 'Banking'){
       this.isBA = true;
       this.isCC = false;
        for(let bankAccountDetails of this.getPaymentMethodResponse.bankAccountDetails){
           if(bankAccountDetails.tokenId === selectedPayment){
            this.baResponse = bankAccountDetails;
            this.tokenMatched = true;
            break;
         }
        }
        this.paymentType = "BANKACCOUNT";
     }
   }
   
   formatType(accountType: string){
     if(accountType === 'BUSINESS_SAVINGS'){
       return accountType = 'Business Savings';
     }else if(accountType === 'PERSONAL_SAVINGS'){
       return accountType = 'Personal Savings';
     }else if(accountType === 'BUSINESS_CHECKING'){
       return accountType = 'Business Checking';
     }else if(accountType === 'PERSONAL_CHECKING'){
       return accountType = 'Personal Checking';
     }else if(accountType === 'MC'){
        return accountType = 'Master Card';
     }else if(accountType === 'VISA'){
        return accountType = 'VISA';
     }
   }

   removePayMethodError(){
     this.paymentmethodReqError = false;
   }

   getMaskedAccountNumber(bankAccountNumber: string){
      let maskedNumber = '';
      let indexVal = bankAccountNumber.length - 4;
      let accountNumber = bankAccountNumber.substring(indexVal);
      for(let i=0; i < indexVal; i++){
        maskedNumber = maskedNumber + '*';
      }
      return maskedNumber + accountNumber;
    }

}
