export const environment = {
  production: true,
  API:'https://payment-internal.perf1.va.anthem.com/paymentgateway/',
  NodeAPI: 'https://perf-phub-njs-internal.anthem.com/payments/',
  loggingflag: false,
  environment: 'PERF'
};
