export const environment = {
  production: true,
  API:'http://va10n10114.wellpoint.com:9080/paymentgateway/',
  NodeAPI: 'https://va10tlvwbs490.wellpoint.com:7576/payments/',
  loggingflag: false,
  environment: 'DEV'
};
