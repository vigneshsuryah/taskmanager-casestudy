export const environment = {
  production: true,
  API:'https://payment.uat2.va.anthem.com/paymentgateway/',
  NodeAPI: 'https://va10dlvwbs339.wellpoint.com:7576/payments/',
  loggingflag: false,
  environment: 'UAT'
};
