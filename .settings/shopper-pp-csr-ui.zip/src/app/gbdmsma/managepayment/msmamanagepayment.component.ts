import { MsmaCsrHttpService } from './../../shared/csr-service/msma.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';

@Component({
  moduleId: module.id,
  selector: 'csr-msmamanagepayment',
  templateUrl: 'msmamanagepayment.component.html',
  styleUrls: ['msmamanagepayment.component.css']
})
export class MSMAManagePaymentComponent implements OnInit {

  content : any ={};
  selectedMethod: string;
  hasMSMACSRSUBMIT: boolean = false;

  constructor(public router: Router, private _service: MsmaCsrHttpService, private user: User){
    if (this.user && this.user.userRole) {
      if (this.user.userRole.indexOf('MSCSRSUBMIT') > -1 || this.user.userRole.indexOf('MACSRSUBMIT') > -1) {
        this.hasMSMACSRSUBMIT = true;
      }
    } else {
      this.router.navigate(['/roothome']);
    }
  }

  ngOnInit() {
    this.selectedMethod = 'AS';
    if (null != this._service.selectedMethod && undefined !== this._service.selectedMethod && this._service.selectedMethod !== '') {
      this.selectedMethod = this._service.selectedMethod;
    }
  }

}
