import { Routes } from '@angular/router';

import { TechnicalErrorComponent } from '../commonutils/technicalerror/technicalerror.component';

import { MSMAHomeComponent } from './home/msmahome.component';
import { MSMAManagePaymentComponent } from './managepayment/msmamanagepayment.component';
import { MSMAAccountSummaryComponent } from './managepayment/msmaaccountsummary/msmaaccountsummary.component';
import { MSMAOneTimePaymentComponent } from './managepayment/msmaaccountsummary/msmaonetimepayment/msmaonetimepayment.component';

export const routes: Routes = [ 
    { path: '', component: MSMAHomeComponent },
    { path: 'home', component: MSMAHomeComponent },
    { path: 'paymentmethod', component: MSMAManagePaymentComponent },
    { path: 'accountsummary', component: MSMAAccountSummaryComponent },
    { path: 'onetimepayment', component: MSMAOneTimePaymentComponent },
    { path: 'error', component: TechnicalErrorComponent}
];