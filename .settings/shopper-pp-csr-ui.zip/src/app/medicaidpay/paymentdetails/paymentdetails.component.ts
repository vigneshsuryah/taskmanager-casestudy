import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { Subscription } from 'rxjs/Subscription';
import { content } from '../../shared/constants/constants';
import { PaymentDetailsModel } from '../../shared/models/medicaidpay/paymentdetails.model';
import { MedicaidPayService } from '../../shared/csr-service/medicaidpay.service';
import { SetApplicationResponse } from '../../shared/models/medicaidpay/setapplicationresponse.model';
import { PaymentSelection} from '../../shared/models/medicaidpay/paymentselection.model';
import { IppHttpService } from '../../shared/csr-service/ipphttp.service';
import { MedicaidHomeComponent } from '../home/medicaidhome.component';
import { NgModel } from '@angular/forms';
import { Payment } from '../../shared/models/medicaidpay/payment.model';
import { Card } from '../../shared/models/medicaidpay/card.model';
import { Bank } from '../../shared/models/medicaidpay/bank.model';

@Component({
  moduleId: module.id,
  selector: 'csr-paymentdetails',
  templateUrl: 'paymentdetails.component.html',
  styleUrls: ['paymentdetails.component.css']
})
export class PaymentDetailsComponent implements OnInit {
  @ViewChild('creditCardNumber') creditCardNumber: NgModel;
  @ViewChild('bankRoutingNbr') bankRoutingNbr: NgModel;
  @ViewChild('accountNbr') accountNbr: NgModel;
  screenLoader: boolean = false;
  techerror: boolean = false;
  private acn: string;
  response: any = {};
  submitResponse: any = {};
  isPaymentServiceDown: boolean = false;
  errorMsg = {
    systemUnavailable: 'Payment service is unavailable. Please try again later.'
  };
  payContent = {
    welcomeKY: 'Welcome to <strong>Anthem Medicaid</strong>. Please provide your payment method details.',
    welcomeIN: 'Welcome to <strong>Anthem Blue Cross and Blue Shield</strong>. Please provide your payment method details.'
  };
  welcome = this.payContent.welcomeKY;
  payError = this.errorMsg.systemUnavailable;
  counties = [];

  paymentDetailsModel = {
    'paymentOptions':'',
    'paymentType':'',
    'creditCardNumber':'',
    'cvvCode':'',
    'expiryDate':'',
    'nameOnCard':'',
    'isChecked':'',
    'addrType':'',
    'accaddrType': '',
    'accHolderAddr': '',
    'accHolderAddr2':'',
    'acccity': '',
    'accstate':'',
    'acccounty':'',
    'acczip':'',
    'cardHolderAddr':'',
    'cardHolderAddr2':'',
    'city':'',
    'state':'',
    'county':'',
    'zip':'',
    'ccConfimationMail':'',
    'accHolderName':'',
    'bankRoutingNbr':'',
    'accountNbr':'',
    'accountType':'',
    'isEChecked':'',
    'ecConfimationMail':'',
    'confimationMail':'',
    'sendMailInfo':'',
    'Email': '',
    'accEmail' : ''
  }
  content : any ={};
  monthlyPay : string = '$174.42';
  amtToPay : number;
  paymentTrackid : number;

  constructor(public router: Router, private medicaidPayService: MedicaidPayService, private ippHttpService: IppHttpService )
  {
    
  }

  ngOnInit() {
    if (this.medicaidPayService.state === undefined) {
      this.router.navigate(['/medicaidpay']);
    } else if (this.medicaidPayService.state === 'KY') {
      this.welcome = this.payContent.welcomeKY;
    } else if (this.medicaidPayService.state === 'IN') {
      this.welcome = this.payContent.welcomeIN;
    }
    this.content = content;
    this.paymentDetailsModel.paymentOptions = 'CD';
    this.paymentDetailsModel.paymentType = 'VISA';
    this.paymentDetailsModel.addrType = 'CardHolderAddr';
    this.paymentDetailsModel.accountType = 'PERSONALCHECKING';
    this.paymentDetailsModel.ccConfimationMail = 'No';
    this.paymentDetailsModel.ecConfimationMail = 'No';
    this.paymentDetailsModel.confimationMail = 'Yes';
    this.paymentDetailsModel.sendMailInfo = 'Yes';
    this.amtToPay = this.medicaidPayService.payEntry.amount;
  }

  changePaymentOptions(paymentOption: string){
    if(paymentOption === 'CD'){
      this.paymentDetailsModel.paymentOptions = 'CD';
    } else if(paymentOption === 'EC') {
      this.paymentDetailsModel.paymentOptions = 'EC';
    } else if(paymentOption === 'MP'){
      this.paymentDetailsModel.paymentOptions = 'MP';
    }
  }

  updateCardType(cardType) {
    this.paymentDetailsModel.paymentType = cardType;
  }

  updateCardTypeOnCardNo(cardno) {
    if (cardno) {
      if (cardno.startsWith('4')) {
        this.paymentDetailsModel.paymentType = 'VISA';
      } else {
       this.paymentDetailsModel.paymentType = 'MASTERCARD';
      }
    }
  }

submitPayment (paymentDetailsModel: any){
  this.screenLoader = true;
  this.techerror = false;
  this.payError = this.errorMsg.systemUnavailable;

  const paySelect = new PaymentSelection();
  paySelect.action = 'UPDATE';
  paySelect.csrIdentifier = this.medicaidPayService.csrId;
  paySelect.paymentIdentifier = this.medicaidPayService.payEntry.paymentId;
  paySelect.emailAddress = paymentDetailsModel.Email;

  if (this.paymentDetailsModel.paymentOptions === 'CD') {
    const payCC = new Payment();
    payCC.action = 'UPDATE';
    payCC.paymentAmt = this.medicaidPayService.payEntry.amount;
    payCC.paymentType = 'CREDITCARD';
    payCC.billingAddr = {
      "addressLine1": paymentDetailsModel.cardHolderAddr,
      "addressLine2": paymentDetailsModel.cardHolderAddr2,
      "city": paymentDetailsModel.city,
      "county": paymentDetailsModel.county,
      "state": paymentDetailsModel.state,
      "postalCode": paymentDetailsModel.zip,
      "action": "UPDATE"
    };
    const cc = new Card();
    cc.cardNo = paymentDetailsModel.creditCardNumber;
    cc.expDate = paymentDetailsModel.expiryDate;
    cc.cardType = paymentDetailsModel.paymentType;
    cc.cardHolderName = paymentDetailsModel.nameOnCard;
    payCC.creditCard = cc;
    paySelect.initialPayment = [payCC];
  } else if (this.paymentDetailsModel.paymentOptions === 'EC') {
    const payBank = new Payment();
    payBank.action = 'UPDATE';
    payBank.paymentAmt = this.medicaidPayService.payEntry.amount;
    payBank.paymentType = 'ECHECK';
    payBank.billingAddr = {
      "addressLine1": paymentDetailsModel.accHolderAddr,
      "addressLine2": paymentDetailsModel.accHolderAddr2,
      "city": paymentDetailsModel.acccity,
      "county": paymentDetailsModel.acccounty,
      "state": paymentDetailsModel.accstate,
      "postalCode": paymentDetailsModel.acczip,
      "action": "UPDATE"
    };
    const echeck = new Bank();
    echeck.action = 'UPDATE';
    echeck.accountNo = paymentDetailsModel.accountNbr;
    echeck.routingNo = paymentDetailsModel.bankRoutingNbr;
    echeck.accountHolderName = paymentDetailsModel.accHolderName;
    echeck.accountType = paymentDetailsModel.accountType;
    echeck.isRecurring = 'NO';
    payBank.bankAcct = echeck;
    paySelect.initialPayment = [payBank];
  }

  const inputParams = {
    partnerId: this.medicaidPayService.partnerId,
    userId: 'OLS',
    acn: this.medicaidPayService.acn,
    paymentSelection: paySelect
  };

  this.ippHttpService.setPayment(inputParams).subscribe(
    (data: any) => {
      this.response = data;
      if (data && !this.hasPaymentException(data.paymentSelection)
          && !this.hasValidationError(data.paymentSelection)
          && this.hasPaymentTrackingId(data.paymentSelection)) {
        const inputParams1 = {
          partnerId: this.medicaidPayService.partnerId,
          userId: 'OLS',
          acn: this.medicaidPayService.acn
        };
        this.ippHttpService.submitPayment(inputParams1).subscribe(
          (data1: any) => {
            jQuery("#confirmationModalOpener").click();
            this.submitResponse = data1;
            this.screenLoader = false;
          },
          (err: any) => {
            this.screenLoader = false;
            this.isPaymentServiceDown = true;
          }
        );
        this.screenLoader = false;
      } else {
        this.screenLoader = false;
        this.techerror = true;
      }
    },
    (err: any) => {
      this.screenLoader = false;
      this.techerror = true;
    }
  );


}

  hasPaymentTrackingId (paySelection: PaymentSelection): boolean {
    console.log(paySelection);
    if (paySelection && paySelection.initialPayment && paySelection.initialPayment.length > 0) {
      const payment = paySelection.initialPayment[0];
      console.log(payment.paymentTrackingId);
      console.log(payment && payment.paymentTrackingId && payment.paymentTrackingId !== '');
      console.log(payment.paymentTrackingId && payment.paymentTrackingId !== '');
      if (payment && payment.paymentTrackingId !== undefined && payment.paymentTrackingId !== null && payment.paymentTrackingId !== '') {
        this.paymentTrackid = Number.parseInt(payment.paymentTrackingId);
        return true;
      }
    }
    return false;
  }

  hasPaymentException (paySelection: PaymentSelection): boolean {
    if (paySelection && paySelection.paymentExceptionMsg) {
      if (paySelection.paymentExceptionMsg.indexOf('DUPLICATE:') >= 0) {
        this.payError = paySelection.paymentExceptionMsg.split(':')[1];
        return true;
      }
    }
    return false;
  }

  hasValidationError(data: PaymentSelection): boolean {
    if (data && data.validationErrors && data.validationErrors.validationError
      && data.validationErrors.validationErrorLength
      && data.validationErrors.validationErrorLength > 0) {
        let message = '';
        for (let fieldErr of data.validationErrors.validationError) {
          if (fieldErr['fieldName'].indexOf('cardNo') >= 0) {
            let fieldmsg = this.getFieldErrorMsgs(fieldErr['errorMessages']);
            this.creditCardNumber.control.setErrors({'serviceerror': fieldmsg});
            message = message + fieldmsg;
          } else if (fieldErr['fieldName'].indexOf('routingNo') >= 0)  {
            let fieldmsg = this.getFieldErrorMsgs(fieldErr['errorMessages']);
            this.bankRoutingNbr.control.setErrors({'serviceerror': fieldmsg});
            message = message + fieldmsg;
          } else if (fieldErr['fieldName'].indexOf('accountNo') >= 0)  {
            let fieldmsg = this.getFieldErrorMsgs(fieldErr['errorMessages']);
            this.accountNbr.control.setErrors({'serviceerror': fieldmsg});
            message = message + fieldmsg;
          } else {
            message = message + this.getFieldErrorMsgs(fieldErr['errorMessages']);
          }
        }
        if (message !== '') {
          this.payError = message;
        }
        return true;
    }
    return false;
  }

  getFieldErrorMsgs(msgs: string[]) {
    let fieldmsg = '';
    for (let entry of msgs) {
      fieldmsg = fieldmsg + entry + '\n';
    }
    return fieldmsg;
  }

  cancel() {
    this.router.navigate(['/medicaidpay/makepayment']);
  }

  redirectToHome() {
    this.router.navigate(['/medicaidpay/']);
  }

  populateZipData(zip: string, isEC: boolean) {
    if (zip && zip.length > 4) {
      this.counties = [];
      this.paymentDetailsModel.acccounty = null;
      this.paymentDetailsModel.county = null;
      this.ippHttpService.validateZip({zipCode: zip}).subscribe((data:any) => {
        if (data && data.zipCodeResponse && data.zipCodeResponse.zipCode
        && data.zipCodeResponse.responseMessage && data.zipCodeResponse.responseMessage.message === 'SUCCESSFULLY FETCHED') {
          const zipData = data.zipCodeResponse.zipCode;
          if (zipData.stateCode) {
            if (isEC) {
              this.paymentDetailsModel.accstate = zipData.stateCode;
            } else {
              this.paymentDetailsModel.state = zipData.stateCode;
            }
          }
          if (zipData.countyList && zipData.countyList.county) {
            for (let county of zipData.countyList.county) {
              if (county && county.countyName) {
                this.counties.push({
                  label: county.countyName,
                  value: county.countyName
                });
                if (zipData.countyList.countyLength === 1) {
                  if (isEC) {
                    this.paymentDetailsModel.acccounty = county.countyName;
                  } else {
                    this.paymentDetailsModel.county = county.countyName;
                  }
                }
              }
            }
          }
        }
      });
    }
  }

}
