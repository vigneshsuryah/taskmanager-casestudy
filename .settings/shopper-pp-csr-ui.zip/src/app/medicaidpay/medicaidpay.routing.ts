import { Routes } from '@angular/router';

import { MedicaidHomeComponent } from './home/medicaidhome.component';
import { PaymentDetailsComponent } from './paymentdetails/paymentdetails.component';
import { StartpaymentComponent } from './startpayment/startpayment.component';

export const routes: Routes = [
    { path: '', component: MedicaidHomeComponent },
    { path: 'makepayment', component: StartpaymentComponent },
    { path: 'paymentdetails', component: PaymentDetailsComponent }
];
