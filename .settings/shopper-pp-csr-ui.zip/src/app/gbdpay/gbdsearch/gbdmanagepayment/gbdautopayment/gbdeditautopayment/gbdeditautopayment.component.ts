import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../../shared/models/user';
import { content } from '../../../../../shared/constants/constants';
import { KyhpportcsrModel } from '../../../../../shared/models/gbdpay/kyhpportcsr.model';
import { Kyhpportcsr } from '../../../../../shared/models/gbdpay/kyhpportcsr';
import { KyhpportcsrService } from '../../../../../shared/csr-service/kyhpportcsr-service';

@Component({
  moduleId: module.id,
  selector: 'csr-gbdeditautopayment',
  templateUrl: 'gbdeditautopayment.component.html',
  styleUrls: ['gbdeditautopayment.component.css']
})
export class GBDEditAutoPaymentComponent implements OnInit {

  kyhpportcsrModel = {  
    'authorization': '',
    'paymentMethod': '',
    'dayOfMonth': '',
  }
  content : any ={};
  editRecurringPayment: any = {};
  screenLoader: boolean = false;
  getPaymentMethodResponse: any = {};
  responseLength: any = 0;
  creditCardBankAccNbrMap: any = {};
  paymentTypeMap: any = {};
  bankAccountTypeMap: any = {};
  ccResponse: any = {};
  baResponse: any = {};
  isCC: boolean;
  isBA: boolean;
  paymentType: string;
  techerror: boolean = false;

  constructor(public router: Router, public kyhpportcsrService: KyhpportcsrService, private currentUser: User, private kyhpportcsr : Kyhpportcsr){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.screenLoader = true;
    var paymentMethodsListComposed: any = [];
    this.content = content;
    this.editRecurringPayment = this.kyhpportcsr.editRecurringPayment;
    this.kyhpportcsrModel.dayOfMonth = this.editRecurringPayment.payDate;
    this.getPaymentMethods();
    setTimeout(()=>{
        jQuery("#dayOfMonth").find(".psButton").prop('disabled',true);  
        jQuery("#dayOfMonth").find(".psOption").prop('disabled',true);
        jQuery(".sb-checkbox-font").find(".pcLabel").addClass('pcLabelFontOverride');
    },100);
  }

  getPaymentMethods(){
      var inputParams = {
        "healthCardId" : this.kyhpportcsr.healthCardId
      }
      var paymentMethodsListComposed: any = [];
      var inputParams = {
        "healthCardId" : this.kyhpportcsr.healthCardId
      }
      this.screenLoader = true;
      this.kyhpportcsrService.getPaymentMethods(inputParams).subscribe((data: any) => {
        this.screenLoader = false;
        this.getPaymentMethodResponse = data;
        if (!this.getPaymentMethodResponse.creditCardDetails && !this.getPaymentMethodResponse.bankAccountDetails) {
          this.responseLength = 0;
        } else {
          if (this.getPaymentMethodResponse.creditCardDetails !== undefined){
            var ccList = this.getPaymentMethodResponse.creditCardDetails;
            this.responseLength += ccList.length;
            for(var i = 0; i <= ccList.length-1; i++){
              var labelString = '';
              this.creditCardBankAccNbrMap[ccList[i].tokenId] = ccList[i].creditCardNumber;
              this.paymentTypeMap[ccList[i].tokenId] = 'CreditDebitCard';

              if(ccList[i].creditCardType == "MC"){
                labelString = "Mastercard ending in ";
              }else if(ccList[i].creditCardType == "VISA"){
                labelString = "VISA ending in ";
              }
              labelString = labelString + ccList[i].creditCardNumber.slice(-4);
              var tempCCItem = {
                label : labelString,
                value : ccList[i].tokenId
              }
              paymentMethodsListComposed.push(tempCCItem);
              }
          }

          if (this.getPaymentMethodResponse.bankAccountDetails !== undefined) {
            var bnkList = this.getPaymentMethodResponse.bankAccountDetails;
            this.responseLength += bnkList.length;
            for(var i = 0; i <= bnkList.length-1; i++){
              var labelString = '';
              this.creditCardBankAccNbrMap[bnkList[i].tokenId] = bnkList[i].bankAccountNumber;
              this.paymentTypeMap[bnkList[i].tokenId] = 'Banking';
              this.bankAccountTypeMap[bnkList[i].tokenId] = bnkList[i].bankAccountType;

              if(bnkList[i].bankAccountType == "BUSINESS_SAVINGS" || bnkList[i].bankAccountType == "PERSONAL_SAVINGS"){
                labelString = "Savings ending in ";
              }else if(bnkList[i].bankAccountType == "BUSINESS_CHECKING" || bnkList[i].bankAccountType == "PERSONAL_CHECKING"){
                labelString = "Checking ending in ";
              }
              labelString = labelString + bnkList[i].bankAccountNumber.slice(-4);
              var tempBnkItem = {
                label : labelString,
                value : bnkList[i].tokenId
              }
              paymentMethodsListComposed.push(tempBnkItem);
              }
          }
        }
        if(undefined !== this.editRecurringPayment.tokenID && "" !== this.editRecurringPayment.tokenID){
          this.selectedPaymentMethod(this.editRecurringPayment.tokenID);
          this.kyhpportcsrModel.paymentMethod = this.editRecurringPayment.tokenID;
        }        
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
      });
    this.content.paymentMethodsList = paymentMethodsListComposed;  
  }

   editAutoPaymentMethod (kyhpportcsrModel: any){
      this.screenLoader = true;
      var inputParams = {
        "healthCardId": this.kyhpportcsr.healthCardId,
        "recurringPaymentDetails": [{
          "planID": this.editRecurringPayment.memberPayBillAcount.planId,
          "productID": this.editRecurringPayment.memberPayBillAcount.productId,
          "payDate": kyhpportcsrModel.dayOfMonth,
          "createdBy": this.kyhpportcsr.healthCardId,
          "authMode": "PPD",
          "tokenID": kyhpportcsrModel.paymentMethod,
          "paymentType": this.paymentType
        }],
        "action": "UPDATE",
        "csrFlag": true,
        "csrUserId": this.currentUser.username
      }    

      this.kyhpportcsrService.updateRecurring(inputParams).subscribe((data: any) => {
          this.screenLoader = false;
          if(data.message.messageCode === "0"){
          jQuery("#confirmationModalOpener").click();
          } 
      },
      (err: any) => {
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
          this.screenLoader = false;
      }
      ); 
   }

   cancel(selected: string){
     this.kyhpportcsr.paymentOption = selected;
     this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

   redirectToAutoPay(selected: string){
     this.kyhpportcsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/gbdpay/gbdmanagepaymentmethod']);
   }

   formatDate(inputDate: string){
     var dateArr  = [];
     if(null !== inputDate && undefined !== inputDate){
        dateArr = inputDate.split("-");
        if(dateArr.length === 3){
          inputDate = dateArr[1] + "/" + dateArr[2] + "/" + dateArr[0];
        }
     }
     return inputDate;
   }

   formatAmount(inputAmt: string){
     if(null !== inputAmt && inputAmt.length > 0 && undefined !== inputAmt){
       inputAmt = "$" + inputAmt;
     }
     return inputAmt;
   }

   selectedPaymentMethod(selectedPayment: string){
     if(this.paymentTypeMap[selectedPayment] === 'CreditDebitCard'){
       this.isCC = true;
       this.isBA = false;
       for(let creditCardDetails of this.getPaymentMethodResponse.creditCardDetails){
         if(creditCardDetails.tokenId === selectedPayment){
            this.ccResponse = creditCardDetails;
            break;
         }
       }
       this.paymentType = "CREDITCARD"; 
     } else if(this.paymentTypeMap[selectedPayment] === 'Banking'){
       this.isBA = true;
       this.isCC = false;
        for(let bankAccountDetails of this.getPaymentMethodResponse.bankAccountDetails){
           if(bankAccountDetails.tokenId === selectedPayment){
            this.baResponse = bankAccountDetails;
            break;
         }
        }
        this.paymentType = "BANKACCOUNT";
     }
   }
   
   formatType(accountType: string){
     if(accountType === 'BUSINESS_SAVINGS'){
       return accountType = 'Business Savings';
     }else if(accountType === 'PERSONAL_SAVINGS'){
       return accountType = 'Personal Savings';
     }else if(accountType === 'BUSINESS_CHECKING'){
       return accountType = 'Business Checking';
     }else if(accountType === 'PERSONAL_CHECKING'){
       return accountType = 'Personal Checking';
     }else if(accountType === 'MC'){
        return accountType = 'Master Card';
     }else if(accountType === 'VISA'){
        return accountType = 'VISA';
     }
   }

}
