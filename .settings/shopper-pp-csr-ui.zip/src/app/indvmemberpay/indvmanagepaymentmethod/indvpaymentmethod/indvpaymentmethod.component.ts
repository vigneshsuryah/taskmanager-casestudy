import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../shared/models/user';
import { MwpCsrHttpService } from '../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvpaymentmethod',
  templateUrl: 'indvpaymentmethod.component.html',
  styleUrls: ['indvpaymentmethod.component.css']
})
export class IndvPaymentMethodComponent implements OnInit {

  content : any ={};
  selectedMethod: string;
  hcidEntered : string = '';
  screenLoader: boolean = false;
  showTable: boolean = false;
  techerror: boolean  = false;
  paymentMethods : any = [];
  errorMessage: string = '';
  serviceerror: boolean  = false;
  deleteTokenId: string = '';
  showAddButton: boolean = false;
  selectedPayMethod = 'Credit/Debit';
  ccCountPay = 0;
  baCountPay = 0;

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService : MwpCsrHttpService){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
    this.hcidEntered = mwpCsrHttpService.hcid;
  }

  ngOnInit() {
    this.ccCountPay = 0;
    this.baCountPay = 0;
    var inputParam = {
       "hcids" : [
         this.hcidEntered
        ]
    }
    this.screenLoader = true;
    this.showAddButton = true;
    this.paymentMethods = [];
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'v2/getPaymentMethods').subscribe((data:any) => {
      this.screenLoader = false;
      this.showTable = true;
      if(null !== data && undefined !== data){
        if(null !== data.exceptions && undefined !== data.exceptions && data.exceptions.length > 0){
          this.router.navigate(['/memberpay/error'], { queryParams: { 'errorMsg': data.exceptions[0].message, 'url': '/memberpay/home' } });
        }
        if(null !== data.memberpayPaymentMethods && undefined !== data.memberpayPaymentMethods){
          if(data.memberpayPaymentMethods.length > 0){
            this.paymentMethods = data.memberpayPaymentMethods;
            if(this.paymentMethods.length >= 5) { 
                this.showAddButton = false;
            }
            for(let paymentMethods of this.paymentMethods){
              if(paymentMethods.paymentType === 'BANKINGACCOUNT'){
                this.baCountPay++;
              } else if (paymentMethods.paymentType === 'CREDITDEBITCARD'){
                this.ccCountPay++;
              }
            }
          }
        }       
      }          
    },
    (err: any) => {
      this.screenLoader = false;
      jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
      this.techerror = true;
    });
     this.selectedMethod = 'MPM';
   }

   redirectToaddNewPaymentMethod (){
    this.mwpCsrHttpService.hcid = this.hcidEntered;
    this.mwpCsrHttpService.payMethodsList = this.paymentMethods;
    this.router.navigate(['/memberpay/addnewpaymentmethod']);
   }

   redirectToHome(selected: string) {
     this.mwpCsrHttpService.selectedMethod = selected;
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   changePaymentMethod(selectedMethod: string){
      if(selectedMethod === 'MPM'){
        this.selectedMethod = 'MPM';
      } else if(selectedMethod === 'MAM'){
        this.selectedMethod = 'MAM';
      } else if(selectedMethod === 'EM'){
        this.selectedMethod = 'EM';
      }
   } 

   cancelDelete(selected: string){
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#confirmationModalOpener").click();
      this.router.navigate(['/memberpay/paymentmethod']);
   }

   confirmDelete(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery("#confirmationModalOpener").click();
     this.screenLoader = true;
     var inputParam = {
        "action" : 'DELETE',
        "hcid" : this.hcidEntered,
        "paymentMethod" : {
            "tokenId" : this.deleteTokenId,
        }
     };
     this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'updatePaymentMethod').subscribe((data:any) => {
        if(null !== data && undefined !== data && null !== data.message && undefined !== data.message 
                      && null !== data.message.messageText && undefined !== data.message.messageText
                      &&  0 === data.message.messageCode) {
            this.screenLoader = false;
            jQuery("#deleteConfirmationModalOpener").click(); 
        } else {
            this.screenLoader = false;
            this.serviceerror = true;
            this.errorMessage = data.message.messageText;
        }
     },
     (err: any) => {
       this.screenLoader = false;
       jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
       this.techerror = true;
     });
     this.selectedMethod = 'MPM';    
   }

   delete(tokenId: string){
     this.deleteTokenId = tokenId;
     jQuery("#confirmationModalOpener").click();    
   }

   edit(payMethod: any){
     this.mwpCsrHttpService.payMethod = payMethod;
     this.mwpCsrHttpService.nickName = this.nickNameCheck(payMethod.accNickName);
     this.router.navigate(['/memberpay/editpaymentmethod']);   
   }

   success(selected:string){
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery("#deleteConfirmationModalOpener").click();
     //this.router.navigate(['/memberpay/paymentmethod']);
     this.ngOnInit();
   }
   
   nickNameCheck(...args:any[]):any{
    var temp:any = [];
    let response = this.paymentMethods;
    if(null != response && undefined !== response && args.length>0 && args[0] !== undefined && args[0] !== ""){
      for(var i=0;i<=response.length-1; i++){
        if((response[i].accNickName != args[0]) && response[i].accNickName !== "" && args[0] !== undefined && args[0] !== "" && response[i].accNickName !== undefined){
          temp.push(response[i].accNickName);
        }
      }
    }else{
      if(null !== response && undefined !== response){
        for(var i=0;i<=response.length-1; i++){
          if(response[i].accNickName !== "")
          temp.push(response[i].accNickName);
        }
      }
    }
    return temp;
  }

  redirectToMemberSearch() {
      this.router.navigate(['/memberpay/home']);
  }
  
  changePayMethod(payMethod: string) {
    this.selectedPayMethod = payMethod;
  }
}
