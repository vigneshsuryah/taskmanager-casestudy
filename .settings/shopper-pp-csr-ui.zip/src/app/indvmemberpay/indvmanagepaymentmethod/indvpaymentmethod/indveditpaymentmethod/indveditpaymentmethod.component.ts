import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../shared/models/paymentmethod.model'
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indveditpaymentmethod',
  templateUrl: 'indveditpaymentmethod.component.html',
  styleUrls: ['indveditpaymentmethod.component.css']
})
export class IndvEditPaymentMethodComponent implements OnInit {

  paymentMethodModel: any = {};
  content : any ={};
  hcidEntered : string = '';
  selectedMethod: string;
  screenLoader: boolean = false;
  techerror: boolean  = false;
  inputParam : any;
  value: string = '';
  errorMessage: string = '';
  serviceerror: boolean  = false;
  nickNameError: boolean = false;

  constructor(public router: Router, private currentUser: User, private mwpCsrHttpService : MwpCsrHttpService){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.content = content;
    this.hcidEntered = this.mwpCsrHttpService.hcid;
    this.paymentMethodModel = this.mwpCsrHttpService.payMethod;
    
    if(this.paymentMethodModel.paymentType === 'BANKINGACCOUNT') {
        this.value = 'Banking';
        this.paymentMethodModel.accountType = this.getBankAccTypeNode(this.paymentMethodModel.bankAccountType); 
    } else if(this.paymentMethodModel.paymentType === 'CREDITDEBITCARD') {
        this.value = 'CreditDebit';
        this.paymentMethodModel.accountType = this.getCCardTypeNode(this.paymentMethodModel.bankAccountType);
    }
    setTimeout(()=>{
        jQuery("#paymentMethod").find(".psButton").prop('disabled',true);  
        jQuery("#paymentMethod").find(".psOption").prop('disabled',true);
        jQuery("#accountType").find(".psButton").prop('disabled',true);  
        jQuery("#accountType").find(".psOption").prop('disabled',true);
    },100);
    this.paymentMethodModel.paymentMethod = this.value;
  }

   savePaymentMethod (paymentMethodModel: PaymentMethodModel){
     this.screenLoader = true;
     this.serviceerror = false;
     this.techerror = false;
     this.nickNameError = false;

     if(null !== this.mwpCsrHttpService.nickName && undefined !== this.mwpCsrHttpService.nickName 
     //   && this.mwpCsrHttpService.nickName !== "" && this.mwpCsrHttpService.nickName.indexOf(paymentMethodModel.accNickName) >= 0 ){
        && this.mwpCsrHttpService.nickName !== ""  ){
            for(let nick of this.mwpCsrHttpService.nickName)
            {
                 var temp = '';
                 temp = nick;            
                 if(temp.toLowerCase() === paymentMethodModel.accNickName.toLocaleLowerCase())
                    {
                        this.nickNameError = true;
                        this.screenLoader = false;
                        return;
                    }
            }         
     }
     if(paymentMethodModel.paymentMethod === 'Banking') {
          this.inputParam = this.constructBankingReq(paymentMethodModel);
     } else if(paymentMethodModel.paymentMethod === 'CreditDebit') {
          this.inputParam = this.constructCreditDebitReq(paymentMethodModel);
     }
     this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'updatePaymentMethod').subscribe((data:any) => {
        if(null !== data && undefined !== data && null !== data.message && undefined !== data.message 
                      && null !== data.message.messageText && undefined !== data.message.messageText
                      &&  0 === data.message.messageCode) {
            this.screenLoader = false;
            document.getElementById('confirmationModalOpener').click();
        } else {
            this.screenLoader = false;
            this.serviceerror = true;
            this.errorMessage = data.message.messageText;
        }
     },
     (err: any) => {
       this.screenLoader = false;
       //jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
       this.techerror = true;
     });
     this.selectedMethod = 'MPM';
   }

   redirectToHome(selected: string) {
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   cancel(selected: string){
     this.mwpCsrHttpService.selectedMethod = selected;
     this.router.navigate(['/memberpay/paymentmethod']);
   }

   constructBankingReq(paymentMethodModel: PaymentMethodModel) {
      return {
        "action" : 'MODIFY',
        "hcid" : this.hcidEntered,
        "paymentMethod" : {
            "tokenId" : paymentMethodModel.tokenId,
            "accNickName" : paymentMethodModel.accNickName,
            "accountName" : paymentMethodModel.accountName,
            "routingNumber" : paymentMethodModel.routingNumber,
            "paymentType" : 'BANKINGACCOUNT',
            "billingAddress" : {
                "addressLine1" : paymentMethodModel.billingAddress.addressLine1,
                "addressLine2" : paymentMethodModel.billingAddress.addressLine2,
                "city" : paymentMethodModel.billingAddress.city,
                "state" : paymentMethodModel.billingAddress.state,
                "postalCode" : paymentMethodModel.billingAddress.postalCode
            },
            "bankAccountType" : this.paymentMethodModel.bankAccountType,
            "confirmAccountNo" : paymentMethodModel.confirmAccountNo,
            "maskedAccountNumber" : paymentMethodModel.confirmAccountNo
        }
     };
   }

   constructCreditDebitReq(paymentMethodModel: PaymentMethodModel) {
        return {
        "action" : 'MODIFY',
        "hcid" : this.hcidEntered,
        "paymentMethod" : {
            "tokenId" : paymentMethodModel.tokenId,
            "accNickName" : paymentMethodModel.accNickName,
            "accountName" : paymentMethodModel.accountName,
            "paymentType" : 'CREDITDEBITCARD',
            "billingAddress" : {
                "addressLine1" : paymentMethodModel.billingAddress.addressLine1,
                "addressLine2" : paymentMethodModel.billingAddress.addressLine2,
                "city" : paymentMethodModel.billingAddress.city,
                "state" : paymentMethodModel.billingAddress.state,
                "postalCode" : paymentMethodModel.billingAddress.postalCode
            },
            "bankAccountType" : this.paymentMethodModel.bankAccountType,
            "expiration" : paymentMethodModel.expiration,
            "maskedAccountNumber" : paymentMethodModel.confirmAccountNo
        }
     };
   }

   getBankAccTypeNode(accType : string) {
      if(null !== accType && undefined !== accType) {
          if(accType === 'PERSONALCHECKING') {
              return 'PERSONAL_CHECKING';
          } else if(accType === 'PERSONALSAVINGS') {
              return 'PERSONAL_SAVINGS';
          } else if(accType === 'BUSCHECKING') {
              return 'BUSINESS_CHECKING';
          } else if(accType === 'BUSSAVINGS') {
              return 'BUSINESS_SAVINGS';
          }
      }
   }

   getCCardTypeNode(accType : string) {
      if(null !== accType && undefined !== accType) {
          if(accType === 'VISA') {
              return 'VISA';
          } else if(accType === 'MASTERCARD') {
              return 'MC';
          }
      }
   }
}