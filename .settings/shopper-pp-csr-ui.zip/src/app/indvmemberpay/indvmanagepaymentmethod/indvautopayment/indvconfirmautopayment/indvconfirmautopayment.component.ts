import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { User } from '../../../../shared/models/user';
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

@Component({
  moduleId: module.id,
  selector: 'csr-indvconfirmautopayment',
  templateUrl: 'indvconfirmautopayment.component.html',
  styleUrls: ['indvconfirmautopayment.component.css']
})
export class IndvConfirmAutoPaymentComponent implements OnInit {
  
  dayOfMonth: string = '';
  hasFailed: boolean = false;
  paymentDetailsMap: any = {};
  subscriberNameMap: any = {};
  subGroupIdList: any = [];
  
  constructor(public router: Router, private mwpCsrHttpService: MwpCsrHttpService){}

  ngOnInit() {
    this.dayOfMonth = this.mwpCsrHttpService.dayOfMonth;
    this.paymentDetailsMap = this.mwpCsrHttpService.paymentDetailsMap;
    
    this.subGroupIdList = Object.keys(this.paymentDetailsMap);
    for(let subGroupIds of this.subGroupIdList){
      let values = this.paymentDetailsMap[subGroupIds];
      if(values.status === 'Failed'){
        this.hasFailed = true;
        break;
      } 
    }
  }
  
  confirmAutoPaymentMethod(){ 
    if(this.hasFailed){
      this.router.navigate(['/memberpay/paymentmethod']);     
    } else {
      jQuery("#confirmationModalOpener").click();  
    }
  }

  redirectToAutoPay(selected: string){
    jQuery("#confirmationModalOpener").click();   
    this.router.navigate(['/memberpay/paymentmethod']);
  }

  getValuesFromMap(map: any, key :string){
    return map[key];
  }

}
