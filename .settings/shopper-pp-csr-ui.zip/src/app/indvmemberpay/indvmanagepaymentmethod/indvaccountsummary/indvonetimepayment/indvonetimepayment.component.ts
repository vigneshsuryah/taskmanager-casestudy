import { ValidateRoutingNo } from './../../../../shared/models/indvmemberpay/validateRoutingNo.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

import { User } from '../../../../shared/models/user';
import { content } from '../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../shared/models/paymentmethod.model'
import { MwpCsrHttpService } from '../../../../shared/csr-service/mwp.csr.service';

declare var jQuery:any;
declare var PIE:any;
declare var ProtectPANandCVV:Function; 

@Component({
  moduleId: module.id,
  selector: 'csr-indvonetimepayment',
  templateUrl: 'indvonetimepayment.component.html',
  styleUrls: ['indvonetimepayment.component.css']
})
export class IndvOneTimePaymentComponent implements OnInit {

    value : string = '';
    hcidEntered : string = '';
    selectedMethod: string = '';
    errorMessage: string = '';
    totalAmount: number = 0;
    screenLoader: boolean = false;
    techerror: boolean  = false;
    serviceerror: boolean  = false;
    selectedPlansForPayment : any = [];
    memberpaySubmitPayments: any = [];
    memberpaySubmitPaymentsList: any = [];
    submittedPaymentsHasFailure: boolean = false;
    inputParam : any = {};
    paymentMethodModel: any = {};
    content : any = {};
    billAddr : any = {};
    encryptionData : any = {};
    paymentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
    minDueDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
    currentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
    allDueDates: any = [];
    constructDatePicker : boolean = false;
    enteredEmailIdIsValid: boolean = true;
    csrEnteredEmailId: string = '';
    public routingNoValidations:Array<string>=[];
    
    datePickerObj = {
        format: 'mm/dd/yyyy',
        startDate: '0D',
        endDate: '0D',
        autoclose: true,
        orientation : 'bottom auto',
        forceParse: false          
    };

    constructor(public router: Router, private currentUser: User, private mwpCsrHttpService : MwpCsrHttpService, private datePipe: DatePipe){
        if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
        }
    }

    ngOnInit() {
        console.log('2 : ' + JSON.stringify(PIE));
        this.inputParam = {};
        this.content = content;
        this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        this.paymentMethodModel.paymentMethod = 'Banking';
        this.value = "Banking";
        this.hcidEntered = this.mwpCsrHttpService.hcid;
        this.serviceerror = false;
        this.techerror = false;
        this.billAddr = {};
        
        var addrInputParam = {
            "hcid" : this.hcidEntered
        }

        this.selectedPlansForPayment = this.mwpCsrHttpService.selectedPlansForPayment;
        var payAmtActual = 0;
        for(let selectedPlans of this.selectedPlansForPayment){
            let payAmt = parseFloat(selectedPlans.paymentAmount.substring(1));
            var tempMinDueDates = {
                minDue : this.datePipe.transform(selectedPlans.dueDate, 'MM/dd/yyyy')
            }
            this.allDueDates.push(tempMinDueDates);
            payAmtActual = payAmtActual + payAmt;
        }
        
        this.allDueDates.sort(function(a: any,b: any){ 
          return new Date(a.minDue).getTime() - new Date(b.minDue).getTime();
        });
        
        this.minDueDate = this.allDueDates[0].minDue;
        this.totalAmount = payAmtActual;
        
        if(null !== this.minDueDate && undefined !== this.minDueDate) {
            if(new Date(this.minDueDate).getTime() <= new Date(this.currentDate).getTime()) {
                this.minDueDate = this.currentDate;
            }
        }
        
        this.datePickerObj.endDate = this.minDueDate;
        this.constructDatePicker = true;
        this.mwpCsrHttpService.getdetailsforcsr(addrInputParam, 'getBillingAddress ').subscribe((data:any) => {
            if(null !== data && undefined !== data && null !== data.billingAddress && undefined !== data.billingAddress){
                this.billAddr = data.billingAddress;
                this.changeAddr('SubscriberAddr');
                this.screenLoader = false;
            }
        },
        (err: any) => {
            this.screenLoader = false;
        });    
    }

    submitPayment(paymentMethodModel: PaymentMethodModel){
        this.paymentMethodModel = new PaymentMethodModel();
        this.paymentMethodModel = paymentMethodModel;
        jQuery("#notes").val("");
        jQuery('#count_message').html(150 + ' characters remaining');
        document.getElementById('confirmationModalOpener').click();
    }
    validateBankDetails(paymentMethodModel: PaymentMethodModel){
        // getValidationBankDetails
        this.paymentMethodModel = new PaymentMethodModel();
        this.paymentMethodModel = paymentMethodModel;
        if(null !== this.paymentMethodModel.routingNumber && undefined !== this.paymentMethodModel.routingNumber && this.paymentMethodModel.routingNumber !== '' && this.paymentMethodModel.routingNumber.length == 9){
            this.inputParam = {
                "routingNumber": this.paymentMethodModel.routingNumber,
            }
            this.mwpCsrHttpService.getValidationBankDetails(this.inputParam, 'v1/validateRoutingNumber').subscribe((data: ValidateRoutingNo) => {
                this.routingNoValidations = [];
                if (data && data.exceptions) {
                    data.exceptions.forEach(x => {
                        this.routingNoValidations.push(x.message);
                    });
                } else if (data && data.valid === false) {
                    this.routingNoValidations.push('Please enter a valid bank routing number');
                }
            });
        }
    }
    confirmSubmitPayment(){
        document.getElementById('confirmationModalOpener').click();
        this.selectedMethod = 'AS';
        this.screenLoader = true;
        this.serviceerror = false;
        this.techerror = false;
        this.memberpaySubmitPayments = [];
        this.memberpaySubmitPaymentsList = [];
        this.submittedPaymentsHasFailure = false;
        if(this.paymentMethodModel.paymentMethod === 'Banking') {
            this.memberpaySubmitPayments = this.constructBankingReq(this.paymentMethodModel);
        } else if(this.paymentMethodModel.paymentMethod === 'CreditDebit') {
            this.memberpaySubmitPayments = this.constructCreditDebitReq(this.paymentMethodModel);
        }
        this.inputParam = {
            "hcid": this.hcidEntered,
            "memberpaySubmitPayments": this.memberpaySubmitPayments,
            "newPaymentMethod": true,
            "payMetFutureUse": false,
            "notes": jQuery("#notes").val(),
            "csrEnteredEmailId" : jQuery("#csrEnteredEmailId").val()
        };
        this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'memberPaySubmitPayment').subscribe((data:any) => {
            if(null !== data && undefined !== data && null !== data.message && undefined !== data.memberpaySubmitPayments 
                && data.memberpaySubmitPayments.length > 0) {
                    this.memberpaySubmitPaymentsList = data.memberpaySubmitPayments;
                    for(let memPaySubmitPayment of this.memberpaySubmitPaymentsList){
                        if(memPaySubmitPayment.message.messageCode !== 0){
                            this.submittedPaymentsHasFailure = true;
                        }
                    }
                    this.screenLoader = false;
                    document.getElementById('successModalOpener').click();
            } else {
                this.screenLoader = false;
                this.serviceerror = true;
                this.errorMessage = data.message.messageText;
            }
        },
        (err: any) => {
            this.screenLoader = false;
            jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
            this.techerror = true;
        });
    }  

    redirectToHome(selected: string) {
        this.mwpCsrHttpService.selectedMethod = selected;
        jQuery("#successModalOpener").click();
        this.router.navigate(['/memberpay/paymentmethod']);
    }

    cancel(selected: string){
        this.mwpCsrHttpService.selectedMethod = selected;
        this.router.navigate(['/memberpay/paymentmethod']);
    }

    changePaymentMethod(paymentMethod: string){
        this.paymentMethodModel = {};
        this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        this.changeAddr('SubscriberAddr');
        if(paymentMethod == 'CreditDebit') {
            this.paymentDate = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
            this.value = "CreditDebit";
            this.paymentMethodModel.paymentMethod = 'CreditDebit';
        } else {
            this.value = "Banking";
            this.paymentMethodModel.paymentMethod = 'Banking';
        }
    }

    constructBankingReq(paymentMethodModel: PaymentMethodModel) {
        for(let selectedPlan of this.selectedPlansForPayment){
            let payments = {
                "submittedHcid" : this.hcidEntered,
                "paymentHcid" : this.hcidEntered,
                "contractCode" : selectedPlan.subGroupId,
                "paymentAmount" : selectedPlan.paymentAmount.substring(1),
                "routingNumber" : paymentMethodModel.routingNumber,
                "paymentDate" : this.paymentDate,
                "nameOfAccount" : paymentMethodModel.accountName,
                
                "paymentType" : "BANKINGACCOUNT",
                "billingAddress" : {
                    "addressLine1" : paymentMethodModel.address1,
                    "addressLine2" : paymentMethodModel.address2,
                    "city" : paymentMethodModel.city,
                    "state" : paymentMethodModel.state,
                    "postalCode" : paymentMethodModel.zipCode,
                } ,
                "bankAccountType" : this.constructBankAccTypeNode(paymentMethodModel.accountType),
                "confirmAccountNo" : paymentMethodModel.confirmAccountNo,
                "subGroupId" : selectedPlan.subGroupId,
                "firstName" : selectedPlan.firstName,
                "lastName" : selectedPlan.lastName,
                "brand" : selectedPlan.brand,
                "mamStatusCode" : selectedPlan.mamStatusCode,
                "whetherSummaryBillNo" : null === selectedPlan.summaryBillNo ? false : true,
                "summaryBillNo" : selectedPlan.summaryBillNo,
                "subscriberId" : selectedPlan.subscriberId,
                "memberSequenceNumber" : selectedPlan.memberSequenceNumber,
                "groupName" : selectedPlan.groupName,
                "groupNumber" : selectedPlan.groupNumber,
                "subGroupName": selectedPlan.planName,
                "subGroupNumber": selectedPlan.subGroupId
            };
            this.memberpaySubmitPayments.push(payments);
        }
        return this.memberpaySubmitPayments;
    }

    constructBankAccTypeNode(accType : string) {
        if(null !== accType && undefined !== accType) {
            if(accType === 'PERSONAL_CHECKING') {
                return 'PERSONALCHECKING';
            } else if(accType === 'PERSONAL_SAVINGS') {
                return 'PERSONALSAVINGS';
            } else if(accType === 'BUSINESS_CHECKING') {
                return 'BUSCHECKING';
            } else if(accType === 'BUSINESS_SAVINGS') {
                return 'BUSSAVINGS';
            }
        }
    }
    
    constructCreditDebitReq(paymentMethodModel: PaymentMethodModel) {
        this.encryptionData = this.doEncryption(paymentMethodModel.confirmAccountNo);
        for(let selectedPlan of this.selectedPlansForPayment){
            let payments = {
                "submittedHcid" : this.hcidEntered,
                "paymentHcid" : this.hcidEntered,
                "contractCode" : selectedPlan.subGroupId,
                "paymentAmount" : selectedPlan.paymentAmount.substring(1),
                "expiration" : paymentMethodModel.expiration,
                "paymentDate" : this.paymentDate,
                "nameOfAccount" : paymentMethodModel.accountName,
                
                "paymentType" : "CREDITDEBITCARD",
                "billingAddress" : {
                    "addressLine1" : paymentMethodModel.address1,
                    "addressLine2" : paymentMethodModel.address2,
                    "city" : paymentMethodModel.city,
                    "state" : paymentMethodModel.state,
                    "postalCode" : paymentMethodModel.zipCode,
                },
                "bankAccountType" : (null !== paymentMethodModel.accountType && undefined !== paymentMethodModel.accountType && 'MC' === paymentMethodModel.accountType) ? 'MASTERCARD' : 'VISA',
                "confirmAccountNo" : this.encryptionData.encryptccno,
                "subGroupId" : selectedPlan.subGroupId,
                "firstName" : selectedPlan.firstName,
                "lastName" : selectedPlan.lastName,
                "brand" : selectedPlan.brand,
                "mamStatusCode" : selectedPlan.mamStatusCode,
                "whetherSummaryBillNo" : null === selectedPlan.summaryBillNo ? false : true,
                "summaryBillNo" : selectedPlan.summaryBillNo,
                "subscriberId" : selectedPlan.subscriberId,
                "memberSequenceNumber" : selectedPlan.memberSequenceNumber,
                "formatID":"64",
                "integrityCheck" : this.encryptionData.integritycheck,
                "keyID" : this.encryptionData.keyid,
                "phaseID" : this.encryptionData.phase+'',
                "groupName" : selectedPlan.groupName,
                "groupNumber" : selectedPlan.groupNumber,
                "subGroupName": selectedPlan.planName,
                "subGroupNumber": selectedPlan.subGroupId
            };
            this.memberpaySubmitPayments.push(payments);
        }
        return this.memberpaySubmitPayments;
    }

    changeAddr(addrType: string) {
        if(addrType === 'SubscriberAddr') {
            this.paymentMethodModel.address1 = this.billAddr.addressLine1;
            this.paymentMethodModel.address2 = this.billAddr.addressLine2;
            this.paymentMethodModel.city = this.billAddr.city;
            this.paymentMethodModel.state = this.billAddr.state;
            this.paymentMethodModel.zipCode = this.billAddr.postalCode;
        } else {
            this.paymentMethodModel.address1 = '';
            this.paymentMethodModel.address2 = '';
            this.paymentMethodModel.city = '';
            this.paymentMethodModel.state = '';
            this.paymentMethodModel.zipCode = '';
        }
    }

    doEncryption(ccno) {
        this.encryptionData={};
        this.encryptionData.ccno=ccno;
        var result=ProtectPANandCVV(ccno,"",true);
        //console.log('result : ' + JSON.stringify(result));
        if(result!=null && result!= undefined) {
            this.encryptionData.encryptccno=result[0];
            if(result.length >2){
                this.encryptionData.integritycheck = result[2];
            } 
        }else{
            alert("Error: ProtectPANandCVV call returned null. You may have entered an invalid card number.");
        }
        this.encryptionData.keyid = PIE.key_id;
        this.encryptionData.phase = PIE.phase;
        return this.encryptionData;
    } 

    getSelectedDate(date) {
      //console.log("getSelectedDate");
      this.paymentDate = this.datePipe.transform(date, 'MM/dd/yyyy');
    }

    bankAccNbrFieldOnChange(flag: boolean){
    if(flag){
      this.paymentMethodModel.reEnterbankAccountNbr = '';
    }
  }

    onKeyUp(event: any) {
        var text_length = event.target.value.length;
        var text_remaining = 150 - text_length;
        jQuery('#count_message').html(text_remaining + ' characters remaining');
    }

    validateEmail(event: any) {
    let csrEnteredEmailId = event.target.value;
    this.enteredEmailIdIsValid = true;
      if(csrEnteredEmailId !== "" && csrEnteredEmailId !== null){
        if(!this.checkEmailRegex(csrEnteredEmailId)){
          this.enteredEmailIdIsValid = false;
         }
      }
  }

  checkEmailRegex(csrEnteredEmailId : string) {
      var emailRegex = /^[A-Za-z0-9][A-Za-z0-9._%+-]+@[A-Za-z]+\.[A-Za-z]{1,63}$/;
      if(emailRegex.test(csrEnteredEmailId)){
        return true;
      }else{
        return false;
      }
  }
}
