import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
declare var PIE: any;
import { User } from '../../../shared/models/user';
import { content } from '../../../shared/constants/constants';
import { MwpCsrHttpService } from '../../../shared/csr-service/mwp.csr.service';
import { NgForm } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-indvaccountsummary',
  templateUrl: 'indvaccountsummary.component.html',
  styleUrls: ['indvaccountsummary.component.css']
})
export class IndvAccountSummaryComponent  {

    content : any ={};
    hcidEntered : string = '';
    selectedMethod: string;
    screenLoader: boolean = false;
    techerror: boolean  = false;
    inputParam : any;
    errorMessage: string = '';
    serviceerror: boolean  = false;
    linkedBillsList: any = [];
    selectedBillAccountToAdd: any = [];
    subGroupIdList: any = [];
    subscriberName: string = '';
    selectedPlansForPayment: any = [];
    selectedPlan: string ='';
    enteredAmount: number;
		min : number = 1;
		max: number = 5;
    showPayAllButton : boolean = false;
    hasBills : boolean = false;
    payAllHasError : boolean = false;
		payNowCount: number = 0;
    selectedBillAccForViewPay: any = {};
    selectedMemberPayForViewPay: any = {};
    totalAmtPaidPerBilAcc: number = 0;
    paymentTrackingNo: string = '';
    pendingPayMessage: string = 'A Payment is already pending or submitted for this account, do you want to proceed anyway?';
    paidInfullMessage: string = 'This account has already been paid in full, do you want to proceed anyway?';
    autoPayMessage: string = 'This account has already been scheduled for automatic monthly withdrawals, do you want to proceed anyway?';
    noPayDueMessage: string = 'The member doesn\'t have any outstanding bills, do you want to proceed anyway?';
    showNotesSection: boolean = false;
    
    


		@ViewChild('submitPaymentForm') submitPaymentForm: NgForm;
		
    constructor(public router: Router, private currentUser: User, private mwpCsrHttpService : MwpCsrHttpService){

			if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
      }
    }

    ngOnInit() {
      // console.log('1 : ' + JSON.stringify(PIE));
      this.selectedMemberPayForViewPay.paymentMethod = {
        "bankAccountType" : ''
      };
      this.selectedBillAccForViewPay.paymentStatus = {};
      this.mwpCsrHttpService.selectedPlansForPayment = null;
			this.selectedPlansForPayment = [];
      this.hasBills = false;
			this.hcidEntered = this.mwpCsrHttpService.hcid;
			let getKeyUrl = 'https://safetechpageencryptionvar.chasepaymentech.com/pie/v1/' + 64100000000181 + '/getkey.js';
			this.loadScript(getKeyUrl);
      this.inputParam = {};
      this.content = content;
      this.showPayAllButton = false;
      this.serviceerror = false;
      this.techerror = false;

      this.inputParam = {
        "hcids" : [
          this.hcidEntered
          ]
      }   
      this.payNowCount = 0;
      this.getSummary();
			this.selectedMethod = 'AS';
    }
    
    getSummary(){
      this.screenLoader = true;
		  this.mwpCsrHttpService.getdetailsforcsr(this.inputParam, 'v2/getSummary').subscribe((data:any) => {
        if(undefined !== data && null !== data && undefined !== data.memberpayMember && null !== data.memberpayMember) {
          this.linkedBillsList = data.memberpayMember.linkedBills;
          
          for (let bill of this.linkedBillsList) {
              if(null !== bill && null !== bill.billAccounts && undefined !== bill.billAccounts && bill.billAccounts.length > 0) {
                  for(let billAcc of bill.billAccounts){
                    this.totalAmtPaidPerBilAcc = 0;
                    this.hasBills = true;
                    this.payNowCount += this.payNowCount + 1;
                    billAcc.errorFlag = true;
                    billAcc.errorMessage = "Required Field";
                    billAcc.isTouched = false;
                    /*if(billAcc.paymentStatus !== null && billAcc.paymentStatus !== undefined){
                      if(null !== billAcc.paymentStatus.showContent && undefined !== billAcc.paymentStatus.showContent && 'Pay Now' === billAcc.paymentStatus.shortContent) {
                        this.payNowCount += this.payNowCount + 1;
                      }
                        billAcc.errorFlag = true;
                        billAcc.errorMessage = "Required Field";
                        billAcc.isTouched = false;
                    }*/
                  }
              }
          }
          
          if(this.payNowCount > 1){
            this.showPayAllButton = true;
          }

        } else if(null !== data && undefined !== data && null !== data.exceptions) {
          this.screenLoader = false;
          jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
          this.techerror = true;
        }
        this.screenLoader = false;
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
    }

    redirectToOneTimePay() {
      this.mwpCsrHttpService.selectedMethod = 'AS';
      this.payAllHasError = false;
      for (let bill of this.linkedBillsList) {
          if(null !== bill && null !== bill.billAccounts && undefined !== bill.billAccounts && bill.billAccounts.length > 0) {
              for(let billAcc of bill.billAccounts){
                //if(billAcc.paymentStatus !== null && billAcc.paymentStatus !== undefined){
                  //if(billAcc.paymentStatus.payNowStatus !== null && billAcc.paymentStatus.payNowStatus !== undefined && billAcc.paymentStatus.payNowStatus === 'Yes'){
                    if(billAcc.errorFlag){
                      this.payAllHasError = true;
                      break;
                    }
                  //}
                //}
              }
          }
      }
      if(!this.payAllHasError){
        if (null !== this.linkedBillsList && undefined !== this.linkedBillsList && this.linkedBillsList.length > 0) {
          for (let linkedBill of this.linkedBillsList) {
            if (null != linkedBill.billAccounts && undefined != linkedBill.billAccounts && linkedBill.billAccounts.length > 0) {
              for (let billAccount of linkedBill.billAccounts) {
                //if (null !== billAccount.paymentStatus && undefined !== billAccount.paymentStatus && billAccount.paymentStatus.payNowStatus === 'Yes') {
                  let selectedPlanDet = {
                    "subGroupId": billAccount.subGroupId,
                    "paymentAmount": billAccount.paymentAmt,
                    "firstName": linkedBill.personDetails.firstName,
                    "lastName": linkedBill.personDetails.lastName,
                    "brand": linkedBill.personDetails.brand,
                    "paymentStatus": (null !== billAccount.paymentStatus && undefined !== billAccount.paymentStatus) ? billAccount.paymentStatus.mamStatusCode : null,
                    "summaryBillNo": (null !== linkedBill.contractIndicators && linkedBill.contractIndicators == 'SUMMARY_BILLED_MEMBER') ? linkedBill.groupId : null,
                    "subscriberId": linkedBill.personDetails.alternateId,
                    "memberSequenceNumber": linkedBill.memberSequenceNo,
                    "groupName": billAccount.subGroupName,
                    "groupNumber": linkedBill.groupId,
                    "planName": billAccount.planName,
                    "dueDate": billAccount.dueDate
                  }
                  this.selectedPlansForPayment.push(selectedPlanDet);
                //}
              }
            }
          }
        }
        this.mwpCsrHttpService.selectedPlansForPayment = this.selectedPlansForPayment;
        this.router.navigate(['/memberpay/onetimepayment']);
      }
    }

    validateAmountEntered(bill: any) {
      this.selectedPlan = bill.subGroupId;
      bill.isTouched = true;
      if (bill.paymentAmt === undefined || bill.paymentAmt === '') {
        bill.errorFlag = true;
        bill.errorMessage = "Required Field";
      } else if (this.validatePattern(bill.paymentAmt) && !this.validateNoSpaces(bill.paymentAmt) && !this.validateNoSpecialChar(bill.paymentAmt) && !this.validateNoLetter(bill.paymentAmt)) {
        if (bill.paymentAmt !== undefined && bill.paymentAmt !== '') {
          if (bill.paymentAmt.indexOf('$') == -1 && bill.paymentAmt.indexOf('.') == -1) {
            bill.paymentAmt = '$' + bill.paymentAmt;
          } else if (bill.paymentAmt.length == 1 && (bill.paymentAmt == '$' || bill.paymentAmt == ".")) {
            bill.paymentAmt = '';
          }
          if (bill.paymentAmt.indexOf('$') >= 0) {
            this.enteredAmount = +bill.paymentAmt.slice(1);
          } else {
            this.enteredAmount = +bill.paymentAmt;
          }
          bill.errorFlag = false;
          bill.warningFlag = false;
          bill.warningGreaterAmtFlag = false;
          if (this.enteredAmount < 1) {
            bill.errorFlag = true;
            bill.errorMessage = "Amount should not be less than $1";
          }
          if (this.enteredAmount > 9999.99) {
            bill.warningGreaterAmtFlag = true;
            bill.amtGreaterWarningMessage = "This payment exceeds $9,999.99. Do you want to proceed anyway?";
          }
          if (this.enteredAmount > bill.totalDue) {
            bill.warningFlag = true;
            bill.amtWarningMessage = "Entered amount exceeds current Amount Due";
          }
        } else {
          bill.errorFlag = true;
          bill.errorMessage = "Required Field";
        }
      } else {
        bill.errorFlag = true;
        bill.errorMessage = "Please enter valid amount";
      }
    }

    private validateNoSpaces(amt: string) {
      return /\s/g.test(amt) ? true : false;
    }

    private validateNoSpecialChar(amt: string) {
      return /[-~{}!#%&*()+[\]^_`\\":;'@?>=<,/|]+/g.test(amt) ? true : false;
    }

    private validateNoLetter(amt: string) {
      return (/[a-zA-Z]/g.test(amt) ) ? true : false;
    }

    private validatePattern(amt: string) {
      //return (/[\$]?(\d)+(\.\d{1,2})?$/g.test(amt)) ? true : false;
      return (/^\$?[0-9][0-9\,]*(\.\d{1,2})?$|^\$?[\.]([\d][\d]?)$/g.test(amt)) ? true : false;
    }

		paySelectedPlan(bill: any, subgroupId: string) {
  
      if (null !== bill.billAccounts && undefined !== bill.billAccounts && bill.billAccounts.length > 0) {
        for (let billAccount of bill.billAccounts) {
          if (billAccount.subGroupId == subgroupId) {
            let selectedPlanDet = {
              "subGroupId": billAccount.subGroupId,
              "paymentAmount": billAccount.paymentAmt,
              "firstName": bill.personDetails.firstName,
              "lastName": bill.personDetails.lastName,
              "brand": bill.personDetails.brand,
              "paymentStatus": (null !== billAccount.paymentStatus && undefined !== billAccount.paymentStatus) ? billAccount.paymentStatus.mamStatusCode : null,
              "summaryBillNo": (null !== bill.contractIndicators && bill.contractIndicators == 'SUMMARY_BILLED_MEMBER') ? bill.groupId : null,
              "subscriberId": bill.personDetails.alternateId,
              "memberSequenceNumber": bill.memberSequenceNo,
              "groupName": billAccount.subGroupName,
              "groupNumber": bill.groupId,
              "planName": billAccount.planName,
              "dueDate": billAccount.dueDate
            }
            this.selectedPlansForPayment.push(selectedPlanDet);
            break;
          }
        }
      }
      this.mwpCsrHttpService.selectedPlansForPayment = this.selectedPlansForPayment;
      this.router.navigate(['/memberpay/onetimepayment']);
		}

    redirectToMemberSearch() {
      this.router.navigate(['/memberpay/home']);
    }

		loadScript(url) {
			
			let node = document.createElement('script');
			node.src = url;
			node.type = 'text/javascript';
			//document.getElementsByTagName('head')[0].appendChild(node);
			document.getElementById('script-load-div').appendChild(node);       
			/*setTimeout(()=>{
				console.log('PIE value : ' + JSON.stringify(PIE));
      },500);*/
 		}
		
    viewPaymentDetails(bills: any, billAccount: any, memberPayment: any) {
      this.subscriberName = bills.personDetails.firstName + " " + bills.personDetails.lastName;
      this.selectedBillAccForViewPay = billAccount;
      this.selectedMemberPayForViewPay = memberPayment;
      jQuery("#viewPaymentDetailModalOpener").click();
    }

    closePayDetails(selected: string) {
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#viewPaymentDetailModalOpener").click();
      this.router.navigate(['/memberpay/paymentmethod']);
   }

   goBack(selected: string){
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#viewPaymentDetailModalOpener").click();
      this.router.navigate(['/memberpay/paymentmethod']);
   }

   cancelPayment(paymentTrackingNo: string, selected: string) {
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#notes").val("");
      jQuery('#count_message').html(150 + ' characters remaining');
      let numericRegex =  /^[0-9]+$/;
      if (paymentTrackingNo.match(numericRegex)) {
        this.showNotesSection = false;
      } else {
        this.showNotesSection = true;
      }
      jQuery("#viewPaymentDetailModalOpener").click();
      jQuery("#cancelPaymentModalOpener").click();
      this.paymentTrackingNo = paymentTrackingNo;
      this.router.navigate(['/memberpay/paymentmethod']);
   }

   redirectToHome(selected: string) {
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#cancelPaymentModalOpener").click();
      this.router.navigate(['/memberpay/paymentmethod']);
   }

   confirmCancelPayment(selected: string){
      this.mwpCsrHttpService.selectedMethod = selected;
      jQuery("#cancelPaymentModalOpener").click();
      this.screenLoader = true;
      var inputParam = {
          "paymentTrackingNo" : this.paymentTrackingNo,
          "notes": jQuery("#notes").val()
      };
      this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'cancelPaymentMemberPay').subscribe((data:any) => {
          if(null !== data && undefined !== data && null !== data.paymentCancelStatus && undefined !== data.paymentCancelStatus
                        &&  'Success' === data.paymentCancelStatus) {
              this.screenLoader = false;
              jQuery("#cancelConfirmationModalOpener").click(); 
          } else {
              this.screenLoader = false;
              this.serviceerror = true;
              this.errorMessage = data.message.messageText;
          }
      },
      (err: any) => {
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
        this.techerror = true;
      });
      this.selectedMethod = 'AS'; 
   }

   success(selected:string){
     this.mwpCsrHttpService.selectedMethod = selected;
     jQuery("#cancelConfirmationModalOpener").click();
     //this.router.navigate(['/memberpay/paymentmethod']);
     this.ngOnInit();
   }

    onKeyUp(event: any) {
        var text_length = event.target.value.length;
        var text_remaining = 150 - text_length;
        jQuery('#count_message').html(text_remaining + ' characters remaining');
    }

}
