import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MwpCsrHttpService } from '../../shared/csr-service/mwp.csr.service';
declare var jQuery: any;
declare var PIE: any;
/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'csr-indvhome',
  templateUrl: 'indvhome.component.html'
})
export class IndvHomeComponent implements OnInit {

  memberPaySearchModel = {
    'hcid': '',
    'id': '',
    'firstname': '',
    'lastname': '',
    'dob': '',
    'amt': ''
  }
  isExactLength: boolean = true;
  hasHcid: boolean = true;
  screenLoader: boolean;
  techerror: boolean = false;

  constructor(public router: Router, private mwpCsrHttpService: MwpCsrHttpService) { }

  ngOnInit() {
    if(undefined !== PIE && null !== PIE){
      PIE = {}; 
    }
    this.mwpCsrHttpService.automaticPayments = null;
    this.mwpCsrHttpService.hcid = null;
    this.mwpCsrHttpService.selectedMethod = null;
    this.mwpCsrHttpService.selectProductId = null;
    this.mwpCsrHttpService.selectedPlansForPayment = null;
  }

  memberPaySearch(hcid: string) {
    if(hcid.length == 0){
      this.hasHcid = false;
      this.isExactLength = true;
      this.techerror = false;
    } else if(hcid.length > 9 || hcid.length < 9){
      this.isExactLength = false;
      this.hasHcid = true;
      this.techerror = false;
    } else {
      this.isExactLength = true;
      this.hasHcid = true;
      this.validateMember(hcid);
    }
  }

  validateMember(hcid: string){
    this.screenLoader = true;
    this.techerror = false;
    let inputParam = {
      "hcids" : [
        hcid
       ]
    }
    this.mwpCsrHttpService.getdetailsforcsr(inputParam, 'v2/getSummary').subscribe((data:any) => {
      if(undefined !== data && null !== data){
        if(null !== data.exceptions && undefined !== data.exceptions && data.exceptions.length > 0){
          this.router.navigate(['/memberpay/error'], { queryParams: { 'errorMsg': data.exceptions[0].message, 'url': '/memberpay/home' } });
        } else {
           this.mwpCsrHttpService.hcid = hcid;
           this.router.navigate(['/memberpay/paymentmethod']);
        }
      }
    },
    (err: any) => {
        this.screenLoader = false;
        this.techerror = true;
    });
  }

  clearHcid(){
    jQuery("#hcid").val("");  
    this.hasHcid = true;
    this.isExactLength = true;
    this.techerror = false;
  }

}
