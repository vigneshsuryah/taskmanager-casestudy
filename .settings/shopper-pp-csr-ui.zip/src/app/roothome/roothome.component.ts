import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../shared/models/user';
import { AuthenticationService } from '../shared/csr-service/authentication.service';
declare var jQuery:any;

@Component({
  selector: 'csr-roothome',
  templateUrl: './roothome.component.html',
  styleUrls: ['./roothome.component.css']
})
export class RootHomeLoadingComponent implements OnInit{

    constructor (public router : Router, private authenticationService: AuthenticationService, private currentUser: User){
      if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
      }
    }

    ngOnInit(){
      
    }

}

