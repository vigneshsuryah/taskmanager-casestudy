import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../../shared/models/user';
import { RefundService } from '../../shared/csr-service/refund.service';

declare var jQuery: any;

@Component({
    templateUrl: 'refundpaymentdetails.component.html',
    styleUrls: ['refundpaymentdetails.component.css']
})
export class RefundPaymentDetailsComponent implements OnInit {

    confirmationNo: string;
    screenLoader: boolean;
    searchCriteria: any = {};
    paymentDetails: any = {};
    orderId: string;
    idType: string;
    transactionStatus: string;
    isACH: boolean;
    techError: boolean = false;
    trasanctionInfo: any = {};
    remitInfo: any = {};
    refundInfo: any = {};
    isRefundAvilable : boolean = false;
    isrefundEligible : boolean = true;

    constructor(public router: Router, private refundService: RefundService, private currentUser: User) {
        if (this.currentUser.userRole === undefined) {
            this.router.navigate(['']);
        }
    }

    ngOnInit() {
        this.paymentDetails = {};
        this.isRefundAvilable = false;
        this.isrefundEligible = true;
        this.orderId = this.refundService.orderId;
        this.idType = this.refundService.idType;
        this.refundService.memberInfo = {};
        this.getConfirmationDetails();
    }

    getConfirmationDetails() {
        this.techError = false;
        this.screenLoader = true;
        let inputParams = {
            "orderId": this.orderId,
        }
        this.refundService.getRefundResults(inputParams, 'v1/refundSearch', this.refundService.lob).subscribe((result: any) => {
            if (undefined !== result.paymentDetails && result.paymentDetails.length > 0) {
                for(let paymentDetails of result.paymentDetails){
                    for(let transactions of paymentDetails.transactions){
                        if(transactions.transactionType === 'PAYMENT' && transactions.transactionStatus === 'COMPLETED'){
                            if (paymentDetails.paymentMethod.paymentType === 'ACH') {
                                this.isACH = true;
                            } else {
                                this.isACH = false;
                            }
                            this.paymentDetails = paymentDetails;
                            this.populateTransactionInfo(this.paymentDetails);
                            this.populateRemitInformation(this.paymentDetails);
                            this.populateRefundInfomation(this.paymentDetails);
                            this.checkRefundEligibilty(this.paymentDetails);
                            this.screenLoader = false;
                            break;
                        }
                    }
                }
            } else {
                jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
                this.screenLoader = false;
                this.techError = true;
            }
        },
        (err: any) => {
            this.screenLoader = false;
            jQuery('html,body').animate({ scrollTop: jQuery("#tech-error").offset().top - jQuery("#tech-error").height() + 100 }, 'slow');
            this.techError = true;
        });
   }

    populateTransactionInfo(paymentDetails) {
        this.trasanctionInfo = {
            'initiated': this.getCompletedDateTime(paymentDetails),
            'payment_channel': this.getTransactionArrayField(paymentDetails, "paymentChannel"),
            'loginId': this.getTransactionArrayField(paymentDetails, "createdId").toUpperCase(),
            'premium': this.getTransactionArrayField(paymentDetails, "premiumAmount"),
            'fee': this.getTransactionArrayField(paymentDetails, "feeAmount"),
            'total': this.getTotalAmount(paymentDetails),
            'transaction_status': this.getTransactionArrayField(paymentDetails, "transactionStatus"),
            'email': this.getTransactionArrayField(paymentDetails, "paymentConfirmationEmailAddress"),
            'notification': this.getTransactionArrayField(paymentDetails, "notificationIndicator"),
            'thirdParty': this.getPaymentDocumentField(paymentDetails, 'thirdPartyName'),
            'notes': this.getNotes(paymentDetails),
            'payment_type': this.getPaymentMethodField(paymentDetails, "paymentType"),
            'payment_sub_type': this.getPaymentMethodField(paymentDetails, "paymentSubType"),
            'bank_routing_number': this.getPaymentMethodField(paymentDetails, "bankRoutingnumber"),
            'bank_account_number': this.getPaymentMethodField(paymentDetails, "bankAccountNumber"),
            'credit_card_first_six': this.getPaymentMethodField(paymentDetails, "creditCardFirstSix"),
            'credit_card_last_four': this.getPaymentMethodField(paymentDetails, "creditCardLastFour"),
            'cc_token': this.getPaymentMethodField(paymentDetails, "creditCardNumber"),
            'cc_authorization_number': this.getPaymentMethodField(paymentDetails, "ccAuthorizationNumber"),
            'name_on_funding_account': this.getPaymentMethodField(paymentDetails, "nameOnFundingAccount"),
            'fund_account_owner_full_address': this.getPaymentMethodField(paymentDetails, "fundAccountOwnerFullAddress"),
            'product_code': this.getPaymentDocumentField(paymentDetails, "productIdentifier"),
        };
    }

    populateRemitInformation(paymentDetails) {
        this.remitInfo = {
            'member_billing_name': this.getPaymentDocumentField(paymentDetails, "memberBillingName"),
			'member_billing_id': this.getPaymentDocumentField(paymentDetails, "memberBillingId"),
			'group_number': this.getPaymentDocumentField(paymentDetails, "groupNumber"),
			'anthem_divison': this.getAnthemDivison(paymentDetails),
			'product_identifier': this.getPaymentDocumentField(paymentDetails, "productIdentifier"),
			'invoice_number': this.getPaymentDocumentField(paymentDetails, "invoiceNumber"),
        }
    }

    populateRefundInfomation(paymentDetails) {
        this.refundInfo = {
 			'refund_date': this.getRefundedDate(paymentDetails),
			'refund_status': this.getRefundArrayField(paymentDetails, "transactionStatus"),
			'refund_amount': this.getRefundArrayField(paymentDetails, "premiumAmount"),
			'refund_reason_code': this.getRefundDetails(paymentDetails, "refundReasonCode"),
			'refund_reason_description': this.getRefundDetails(paymentDetails, "refundReasondescription"),
			'login_id': this.getRefundArrayField(paymentDetails, "createdId").toUpperCase(),
        }
    }

    getCompletedDateTime(paymentDetails: any) {
        let date = '';
        date = this.getTransactionArrayField(paymentDetails, "createdDt");
        if('' !== date && undefined !== date) {
            date = date.substring(5, 7) + '/' + date.substring(8, 10) + '/' + date.substring(0, 4) + ' ' + date.substring(11, 19) +' ET';
        }
        return date;
    }

    getTotalAmount(paymentDetails: any) {
        let totalAmount = 0.0;
        let premiumAmount = parseFloat(this.getTransactionArrayField(paymentDetails, "premiumAmount"));
        let feeAmount = parseFloat(this.getTransactionArrayField(paymentDetails, "feeAmount"));
        if (premiumAmount > 0 && feeAmount > 0) {
             totalAmount = premiumAmount + feeAmount;
        } else if(premiumAmount > 0) {
            totalAmount = premiumAmount;
        } else if (feeAmount > 0){
            totalAmount = feeAmount;
        }
        return totalAmount.toFixed(2);
    }

    getNotes(paymentDetails: any) {
        let value = '';
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if (transaction.transactionStatus == "COMPLETED"
                    && transaction.transactionType == "PAYMENT") {
                    if (transaction.notes != null && transaction.notes.length > 0) {
                        for (let note of transaction.notes) {
                            if (note.action == "submit") {
                                if (undefined !== note.noteDesc) {
                                    value = note.noteDesc;
                                }
                            }
                        }
                    }
                }
            }
        }
        return value;
    }

    getTransactionArrayField(paymentDetails: any, fieldName: string) {
        let value = '';
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if (transaction.transactionStatus == "COMPLETED"
                    && transaction.transactionType == "PAYMENT") {
                    if (undefined !== transaction[fieldName] 
                        && null !== transaction[fieldName]) {
                        value = transaction[fieldName];
                    }
                }
            }
        }
        return value;
    }

    getPaymentDocumentField(paymentDetails: any, fieldName: string) {
        let value = '';
        if (undefined !== paymentDetails[fieldName] && null !== paymentDetails[fieldName]) {
            value = paymentDetails[fieldName];
        }
        return value;
    }

    getPaymentMethodField(paymentDetails: any, fieldName: string) {
        let value = '';
        if (undefined !== paymentDetails.paymentMethod
            && null !== paymentDetails.paymentMethod) {
            if (undefined !== paymentDetails.paymentMethod[fieldName]
                && null !== paymentDetails.paymentMethod[fieldName]) {
                value = paymentDetails.paymentMethod[fieldName];
            }
        }
        return value;
    }

    getAnthemDivison(paymentDetails: any) {
        let system = this.getPaymentDocumentField(paymentDetails, "system");
        let legal_entity = this.getPaymentDocumentField(paymentDetails, "legalEntity");
        let market_segment = this.getPaymentDocumentField(paymentDetails, "marketSegment");
        return system + legal_entity + market_segment;
    }

    getRefundArrayField(paymentDetails: any, fieldName: string) {
        let value = '';
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if (transaction.transactionType == "REFUND") {
                    this.isRefundAvilable = true;
                    if (undefined !== transaction[fieldName] 
                        && null !== transaction[fieldName]) {
                        value = transaction[fieldName];
                    }
                } 
            }
        }
        return value;
    }

    getRefundDetails(paymentDetails: any, fieldName: string) {
        let value = '';
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if (transaction.transactionType == "REFUND"
                    && transaction.transactionStatus == "COMPLETED") {
                    if (undefined !== transaction.refund
                        && null !== transaction.refund) {
                        if (undefined !== transaction.refund[fieldName]
                            && null !== transaction.refund[fieldName]) {
                            value = transaction.refund[fieldName];
                        }
                    }
                } 
            }
        }
        return value;
    }

    getRefundedDate(paymentDetails: any) {
        let date = '';
        date = this.getRefundArrayField(paymentDetails, "createdDt");
        if('' !== date && undefined !== date) {
            date = date.substring(5, 7) + '/' + date.substring(8, 10) + '/' + date.substring(0, 4) +' ET';
        }
        return date;
    }

    checkRefundEligibilty(paymentDetails: any) {
        this.isrefundEligible = true;
        if (paymentDetails.transactions != null && paymentDetails.transactions.length > 0) {
            for (let transaction of paymentDetails.transactions) {
                if(transaction.transactionType == "REFUND") {
                    if(transaction.transactionStatus == "COMPLETED") {
                        this.isrefundEligible = true;
                    } else {
                        this.isrefundEligible = false;
                        break;
                    }   
                }
            }
        }
    }

    backToSearch() {
        this.refundService.backToList = false;
        this.router.navigate(['/refund/search'], { queryParams: { lob: this.refundService.lob } });
    }

    requestRefund() { 
        let temp = {
            'member_billing_name': this.paymentDetails.memberBillingName,
            'member_billing_id': this.paymentDetails.memberBillingId,
            'payment_type': this.paymentDetails.paymentMethod.paymentType
        }
        this.refundService.memberInfo = temp;
        this.router.navigate(['/refund/request'], { queryParams: { lob: this.refundService.lob } });
    }

    backToList() {
        this.refundService.backToList = true;
        this.router.navigate(['/refund/search'], { queryParams: { lob: this.refundService.lob } });
    }

}
