import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../../shared/models/user';

@Component({
  templateUrl: './refundhome.component.html',
  styleUrls: ['./refundhome.component.css']
})
export class RefundHomeComponent implements OnInit {
  
  constructor(private router: Router, private currentUser: User) { 
    if(this.currentUser.userRole === undefined){
        this.router.navigate(['']);
    }
  }

  ngOnInit() {
    
  }

  redirectToHCIDSearch(lob: string){
    this.router.navigate(['/refund/search'], { queryParams: { 'lob': lob } });
  }
  

}
