import { PaymentMethod } from './paymentmethod.model';

export class UpdatePayRequest {
  healthCardId: string;
  action: string;
  bankAccountDetails: PaymentMethod;
  creditCardDetails: PaymentMethod;
  csrFlag = true;
  csrUserId: string;
}
