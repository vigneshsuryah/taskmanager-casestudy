import { BankAccountDetails, CreditCardDetails } from "./gbdpaymentmethod.model";



export class GBDAccountSummary{
    message ?: MessageDetails;
    healthCardId ?: string;
    minDueAmount ?: string;
    totalDueAmount ?: string;
    linkedBills ?: Array<LinkedBill>;
    paymentAmt ?: string;
}

export class MessageDetails {
    messageCode ?: string;
    messageText ?: string;
}

export class LinkedBill{
    linkRelationship ?: string;
    personDetails ?: PersonDetails;
    billAccounts ?: Array<BillAccount>;
    healthCardId ?: string;
}
export class PersonDetails {
    firstName ?: string;
    lastName ?:string;
    healthCardId ?:string;
    state ?:string;
    brand ?:string;
    dateOfBirth ?: Date;
    middleName ?:string;
    medicaidId ?:string;
    market ?:string;
    originalEffectiveDate ?: Date;
    sex ?:string;
    recertificationDate ?: Date;
}
export class BillAccount {
    billDate ?: Date;
    dueDate ?: Date;
    minDue ?: string;
    totalDue ?: string;
    billFrequency ?: string;
    paymentStatus ?: PaymentStatus;
    billCoveragePeriod ?: string;
    billFromDt ?: Date;
    billToDt ?: Date;
    billOverDueInd ?: string;
    coverageStatus ?: string;
    sbrUid ?: string;
    classId ?: string;
    planId ?: string;
    type ?: string;
    productDescription ?: string;
    dateEffective ?: Date;
    dateTermination ?: Date;
    brand ?: string;
    planName ?: string;
    productId ?: string;
    medicareDiscount ?: string;
    federalSubsidyAmt ?: string;
    stateSubsidyAmt ?: string;
    mbrResponsibilityAmt ?: string;
    daysBeforeDueDt ?: string;
    billOverDueDays ?: string;
    errorFlag ?: boolean;
    errorMessage ?: string;
    isTouched ?: boolean;
    paymentAmt ?: string;
    totalAmtToPay ?:number;
    memberPayments ?: Array<MemberPayment>;
}

export class MemberPayment{
    paymentDate ?: Date;
    paymentAmount ?: string;
    paymentTrackingNo ?: string;
    paymentType ?: string;
    paymentMethod ?: PaymentMethod;
    notes ?: any;
}
export class PaymentStatus{
    paymentProcess: string;
    payNowStatus: string;
    shortContent: string;
    showContent: string;
    mamStatusCode: string;
    canPayBillInd: string;
    recurringPaymentInd: string;
}
export class PaymentMethod{
    bankAccountDetails ?: Array<BankAccountDetails>;
    creditCardDetails ?: Array<CreditCardDetails>;
}