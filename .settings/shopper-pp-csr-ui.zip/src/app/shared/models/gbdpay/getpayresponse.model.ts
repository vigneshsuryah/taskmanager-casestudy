import { PaymentMethod } from './paymentmethod.model';
import { MemberAddress } from './memberaddress.model';

export class GetPayMethodResponse {
  message: {
    messageCode: string,
    messageText: string
  };

  bankAccountDetails: PaymentMethod[];
  creditCardDetails: PaymentMethod[];
  memberPayAddress: MemberAddress;
}
