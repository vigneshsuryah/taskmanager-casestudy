export class AutoPaymentModel {
    authorization: string;
    summaryBill: string;
    paymentMethod: string;
    dayOfMonth: string;
    isBillChecked: boolean;
    confirmEmail: string;
    confimationMail?: string;
}