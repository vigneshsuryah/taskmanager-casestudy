export class RefundModel { 
    hcid ?: string;
    confNoOrOrderID ?: string;
    payFromDt ?: string;
    payToDt ?: string;
    refundAmount ?: string;
    notes ?: string;
}