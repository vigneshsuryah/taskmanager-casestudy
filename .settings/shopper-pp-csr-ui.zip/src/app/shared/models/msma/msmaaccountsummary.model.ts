export class MSMAServiceObject {
    paymentCancelStatus?: string;
    paymentConfirmationNo ?: string;
    message: Message;
    errorFlag ?: boolean;
    payNowCount ?: number;
    totalBillsAvailableCount ?: number;
    totalAmountDue ?: number;
    minDueAmount ?: number;
    bankingAllowed ?: boolean;
    creditDebitAllowed ?: boolean;
    todayDate ?: Date;
    medicareMemberList ?: Array<MedicareMember>;
    exceptions ?: Array<Exeception>;
    paymentAmt?: string;
    memberpaySubmitPayments ?:Array<MemberPaySubmitPayment>;
    healthCardId?:string;
    paymentMethodSaved ?: boolean;
    paymentDate ?: Date;
    selectedBillToPay ?: any;
}
export class MemberPaySubmitPayment {
    childHealthCardId ?: string;
    planID ?: string;
    paymentAmount ?: number;
    confirmationNumber ?: string;
    divisionCode ?: string;
    message ?: Message;
    status ?: string;
}
export class Message {
    messageCode ?: string;
    messageText ?: string;
}
export class Exeception {
    type ?: string;
    code ?: string;
    message ?: string;
    detail ?: string;
}
export class MedicareMember {
    firstName ?: string;
    lastName ?: string;
    dateOfBirth ?: Date;
    healthCardId ?: string;
    relationShip ?: string;
    state ?: string;
    brand ?: string;
    billingAddress ?: BillingAddress;
    medicareBillDetails ?: Array<MedicareBill>;
    effectiveDate ?: Date;
    selectedBillToPay ?: Array<MedicareBill>;
}

export class BillingAddress {
    addressLineOne ?: string;
    addressLineTwo ?: string;
    addressLineThree ?: string;
    city ?: string;
    county ?: string;
    phone ?: string;
    phoneExtension ?:string;
    state ?:string;
    zipCode ?:string;
}

export class MedicareBill {
    planId ?:string;
    billType ?:string;
    primaryMemberHcid ?: string;
    billDueDate ?: string;
    paidStatus ?:string;
    divisionCode ?: string;
    lineOfBusiness ?: string;
    billProcessedDate ?: Date;
    billMinDue ?: number;
    billNetDue ?: number;
    paymentMethod ?: string;
    productDescription ?: string;
    subgroupId ?: string;
    paymentStatus ?: string;
    showToolTip ?: boolean;
    toolTipDescription ?: string;
    medicarePayPayments ?: Array<MedicarePayment>;
    classId ?: string;
    groupId ?: string;
    brandEmailMatrix ?: BrandEmailMatrix;
    pdfAvailable ?: boolean;
    errorFlag ?: boolean;
    errorMessage ?: string;
    isTouched ?: boolean;
}

export class MedicarePayment {
    paymentDate ?: string;
    paymentAmount ?: string;
    paymentTrackingNo ?: string;
    paymentMethod ?: PaymentMethod;
    notes?: Array<string>;
}

export class PaymentMethod {
    accNickName ?: string;
    bankAccountType ?: string;
    tokenId ?: string;
    maskedAccountNumber ?: string;
    forFutureUse ?: boolean;
    selectedForPayment ?: boolean;
}

export class BrandEmailMatrix {
    imageName ?: string;
    planWebsiteUrl ?: string;
    msgCenterLink ?: string;
    customerServiceText ?:string;
    ttyUserText ?: string;
    companyName ?: string;
    brandName ?: string;
    alternateLangLink ?: string;
    federalContractStmt ?:string;
    privacyPolicyLink ?: string;
    taglineText ?: string;
    returnAddress ?: string;
    showPartBPremium ?: string;
    autoPayPdfName ?: string;
    invoiceMaterialId ?: string;
    payReturnMaterialId ?: string;
    linkAccMaterialId ?: string;
    unLinkAccMaterialId ?: string;
    invoiceComplianceCode ?: string;
    payReturnComplianceCode ?: string;
    linkAccComplianceCode ?: string;
    unLinkAccComplianceCode ?: string;
    brandId ?: string;
    brandAbbr ?: string;
}

export interface OTPScreen {
    lob ?: string;
    productDescription ?: string;
    planId ?: string;
    subscriberName ?: string;
    groupID ?: string;
    invoice ?: string;
    billDate ?: string;
    minimumDue ?: number;
    totalDue ?: number;
    dueDate ?: string;
    paymentAmount ?: string;
    payNowStatus ?: string;
    showTableInd ?: boolean;
    errorFlag ?:boolean;
    errorMessage?: string;
    isTouched ?:boolean;
    warningFlag ?:boolean;
    amtWarningMessage ?: string;
    pendingPayMessage ?:string;
    shortContent?: string;
    showToolTip ?: boolean;
    memberPayments ?: Array<MedicarePayment>;
}