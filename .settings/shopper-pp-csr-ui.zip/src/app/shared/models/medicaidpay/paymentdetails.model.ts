export class PaymentDetailsModel {

    paymentDetails: string;
    paymentType: string;
    creditCardNumber: string;
    cvvCode: string;
    expiryDate: string;
    nameOnCard: string;
    isChecked: string;
    addrType: string;
    cardHolderAddr: string;
    city: string;
    state: string;
    country: string;
    zip: string;
    ccConfimationMail: string;
    accHolderName: string;
    bankRoutingNbr: string;
    accountNbr: string;
    accountType: string;
    isEChecked: string;
    ecConfimationMail: string;
    confimationMail: string;
    sendMailInfo: string;
    
}