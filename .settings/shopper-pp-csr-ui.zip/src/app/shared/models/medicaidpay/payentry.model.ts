export class PayEntry {
  paymentId: string;
  firstName: string;
  lastName: string;
  dob: string;
  amount: number;
}
