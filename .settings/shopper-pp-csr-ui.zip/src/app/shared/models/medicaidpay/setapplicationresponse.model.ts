import { Application } from './application.model';

export class SetApplicationResponse {
  acn: string;
  application = new Application();
}
