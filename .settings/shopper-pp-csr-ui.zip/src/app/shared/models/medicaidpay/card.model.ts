export class Card {
  id: number;
  action: string;
  cardNo: string;
  expDate: string;
  cardType: string;
  cardHolderName: string;
}
