import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[confirm-emailaddress-valid-dir]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => ConfirmEmailAddressValidatorDirective), multi: true }
  ]
})
export class ConfirmEmailAddressValidatorDirective implements Validator {
  @Input('emailAddressEntered') emailAddressEntered: string;

  constructor() { }

  validate(c: FormControl) {
    if (typeof c.value === 'undefined') {
      return null;
    }

    let result: any = {};
    if (this.validateEmailAddressMatch(c)) {
      result.validateEmailAddressMatch = true;
    }

    return result;
  }

  private validateEmailAddressMatch(c: FormControl): any {
    let result = false;
    if((typeof this.emailAddressEntered === 'undefined') || (typeof c.value === 'undefined') ||
       (this.emailAddressEntered === null) || (c.value === null)){
      return result;
    }else{
      let value = c.value.toLowerCase(); 
      if ((this.emailAddressEntered || '').toLowerCase() === value.toLowerCase()) {
        result = false;
      }else{
        result = true;
      }
    }
  
    return result;
  }

}
