export interface IDropdown {
  label: string;
}
