export interface ICheckboxInput {
  label: string;
  id: string;
  name: string;
  trueValue: any;
  falseValue: any;
  ariaLabelledBy?: string;
  disabled : any;
}
