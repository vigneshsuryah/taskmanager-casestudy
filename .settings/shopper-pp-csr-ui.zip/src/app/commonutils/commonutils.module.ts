import { NgModule, ModuleWithProviders } from '@angular/core';

import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UxModule } from '../shared/ux.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { LoaderComponent } from './loader/loader.component';
import { ScreenFreezeComponent } from './screenfreeze/screenfreeze.component';
import { TechErrSectionComponent } from './techerrsection/techerrsection.component';
import { PasswordValidatorDirective } from '../shared/directives/passwordValidatorDir';
import { ConfirmPasswordValidatorDirective } from '../shared/directives/confirmPasswordValidatorDir';
import { EmailValidatorDirective } from '../shared/directives/emailValidatorDir';
import { NameValidatorDirective } from '../shared/directives/nameFieldValidator';
import { ExpirationDateValidatorDirective } from '../shared/directives/expirationDateValidator';
import { ButtonDropdownItemDirective } from '../shared/directives/btnDropdownItemCmp';
import { ConfirmEmailAddressValidatorDirective } from '../shared/directives/confirmEmailValidatorDir';
import { AuthenticationService } from '../shared/csr-service/authentication.service';
import { AllowOnlyNumber } from '../shared/directives/allowOnlyNumber';
import { AllowOnlyNumberAndChar } from '../shared/directives/allowOnlyNumberAndChar';
import { AmountPipe } from '../shared/directives/amountFilter';
import { CurrencyPipe  } from "@angular/common";
import { IterateMapPipe } from '../shared/directives/iterateMap';
import { TechnicalErrorComponent } from './technicalerror/technicalerror.component';
import { EqualValidator } from './directives/equalValidator';
import { NickNameValidator } from './directives/nickNameValidator';
import { PayIdValidator } from './directives/payIdValidator';
import { ShowerrorComponent } from './showerror/showerror.component';
import { AmountValidator } from './directives/amountValidator';
import { MydatepickerDirective } from './directives/mydatepicker.directive';
import { advancedSearchNameValidator } from '../shared/directives/advancedSearchNameValidator';

@NgModule({
  imports: [CommonModule, RouterModule, FormsModule, UxModule],
  declarations: [HeaderComponent, FooterComponent,
    LoaderComponent,ScreenFreezeComponent, TechErrSectionComponent,
    PasswordValidatorDirective,ConfirmPasswordValidatorDirective,EmailValidatorDirective,
    NameValidatorDirective,ExpirationDateValidatorDirective,ButtonDropdownItemDirective,
    ConfirmEmailAddressValidatorDirective, AllowOnlyNumber, AllowOnlyNumberAndChar, AmountPipe, IterateMapPipe, TechnicalErrorComponent,
    EqualValidator, NickNameValidator, PayIdValidator, ShowerrorComponent, AmountValidator, MydatepickerDirective, advancedSearchNameValidator],
  exports: [HeaderComponent, FooterComponent, LoaderComponent, ScreenFreezeComponent, TechErrSectionComponent,
    CommonModule, FormsModule, RouterModule, PasswordValidatorDirective,ConfirmPasswordValidatorDirective,
    EmailValidatorDirective,NameValidatorDirective, ExpirationDateValidatorDirective,ButtonDropdownItemDirective,
    ConfirmEmailAddressValidatorDirective, AllowOnlyNumber, AllowOnlyNumberAndChar, AmountPipe, IterateMapPipe, TechnicalErrorComponent,
    EqualValidator, NickNameValidator, PayIdValidator, ShowerrorComponent, AmountValidator, MydatepickerDirective, advancedSearchNameValidator],
    providers: [AuthenticationService,CurrencyPipe]
})

export class CommonutilsModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CommonutilsModule,
    };
  }
}
