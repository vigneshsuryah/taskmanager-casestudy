import { Component,ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { AuthenticationService } from '../../shared/csr-service/authentication.service';

@Component({
  moduleId: module.id,
  selector: 'csr-header',
  templateUrl: 'header.component.html' ,
  styleUrls: ['header.component.css']
})

export class HeaderComponent implements OnInit {

  selectedApp: string;
  menuSelectedValue: string = "";

  constructor(public router: Router,  @Inject(DOCUMENT) private document: any, private currentUser: User, private authenticationService: AuthenticationService) {

  }

  ngOnInit() {
    this.selectedApp = 'IPP';
    jQuery("#hide-wgs-footer").show();

    jQuery("#sidebar").mCustomScrollbar({
      theme: "minimal"
    });

    jQuery('#dismiss, .overlay-portal').on('click', function () {
      jQuery('#sidebar').removeClass('active');
      jQuery('.overlay-portal').fadeOut();
    });

    jQuery('#sidebarCollapse').on('click', function () {
      jQuery('#sidebar').addClass('active');
      jQuery('.overlay-portal').fadeIn();
      jQuery('.collapse.in').toggleClass('in');
      jQuery('a[aria-expanded=true]').attr('aria-expanded', 'false');
    });
  }

  changePaymentApp(payAppType: string, menuSelectedValue: string){
    if(payAppType === 'IPP'){
      this.selectedApp = 'IPP';
    } else if(payAppType === 'MEDP'){
      this.selectedApp = 'MEDP';
    } else if(payAppType === 'INDVMP'){
      this.selectedApp = 'INDVMP';
    } else if(payAppType === 'GBDMP'){
      this.selectedApp = 'GBDMP';
    } else if(payAppType === 'DASHBOARD'){
      this.selectedApp = 'DASHBOARD';
    } else if(payAppType === 'REPORTS'){
      this.selectedApp = 'REPORTS';
    } else if(payAppType === 'WGS'){
      this.selectedApp = 'WGS';
    } else if(payAppType = 'GBDMSMA'){
      this.selectedApp = 'GBDMSMA';
    } else if(payAppType = 'REFUND'){
      this.selectedApp = 'REFUND';
    } else if(payAppType = 'FEEDBACK'){
      this.selectedApp = 'FEEDBACK';
    }
    
    this.menuSelectedValue = menuSelectedValue;
    if(this.selectedApp === 'WGS' || this.selectedApp === 'IPP'){
      jQuery("#hide-wgs-footer").show();
    }else{
      jQuery("#hide-wgs-footer").hide();
    }
    jQuery('#dismiss').click();
  }

  toLogOut(){
    jQuery("#logout-submit").click();
  }
}

