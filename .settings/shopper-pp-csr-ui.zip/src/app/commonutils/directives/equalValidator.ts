import { Validator, NG_VALIDATORS, AbstractControl, FormControl } from '@angular/forms';
import { Directive, forwardRef, Attribute, Input } from '@angular/core';

@Directive({
  selector: '[equalValidator]',
  providers: [
      { provide: NG_VALIDATORS, useExisting: EqualValidator, multi: true }
  ]
})
export class EqualValidator implements Validator {
  @Input() validateCompare: string;

  validate(c: AbstractControl): {[key: string]: any} {
    if (c !== undefined && c.value !== undefined && c.value !== ''
      && this.validateCompare !== undefined && this.validateCompare !== ''
      && this.validateCompare === c.value) {
      return null;
    }
    return {'notequal': {value: c.value}};
  }

}
