import { Component,ViewEncapsulation, OnInit, Input } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'csr-techerrsection',
  templateUrl: 'techerrsection.component.html'
})

export class TechErrSectionComponent implements OnInit {
  @Input() errorMsg = 'Sorry, our system isn\'t working the way it should. Please try again later.';

  ngOnInit() {

  }

}

