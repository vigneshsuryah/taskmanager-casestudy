import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { FeedbackService } from '../../shared/csr-service/feedback.service';
import { Http } from '@angular/http';


@Component({
  moduleId: module.id,
  selector: 'csr-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  techerror: boolean = false;
  enableSubmitButton: boolean = false;
  screenLoader:boolean = false;
  comments:String = "";
  commentsModel = {"comments":"","created_id":""};

  constructor(public router: Router, private currentUser: User, private feedbackService : FeedbackService, private http: Http) {
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
   }

  ngOnInit() {
    this.techerror = false;
    this.enableSubmitButton = false;
    this.commentsModel.created_id=this.currentUser.username;
    this.comments = "";
  }

  setFeedback(comments){
    this.screenLoader = true;
    this.commentsModel.comments=comments;
    this.feedbackService.setFeedback(this.commentsModel).subscribe((result:any) => {
        this.screenLoader = false;
        if(result.success){
          this.comments = "";
          document.getElementById("feedbackModalOpener").click(); 
        }else {
          this.techerror = true;
        }
      },
      (err: any) => {
        this.screenLoader = false;
        this.techerror = true;
      });
  }

  onCommentChange(event:any){
    if(event.target.value.length>=1)
      this.enableSubmitButton=true;
    else
      this.enableSubmitButton=false;
    }

    redirectToHome(){
      this.router.navigate(['/roothome']);
    }
  }
