import { Routes } from '@angular/router';

import { TechnicalErrorComponent } from '../commonutils/technicalerror/technicalerror.component';

import { FeedbackComponent } from './home/feedback.component';


export const routes: Routes = [ 
    { path: 'home', component: FeedbackComponent },
    { path: 'error', component: TechnicalErrorComponent}
];