import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { NgForm } from '@angular/forms';
declare var jQuery:any;
import { User } from '../../shared/models/user';
import { Subscription } from 'rxjs/Subscription';
import { content } from '../../shared/constants/constants';
import { PaymentOptionsModel } from '../../shared/models/ipp/paymentoptions.model';
import { AppBillAddressModel } from '../../shared/models/ipp/appbilladdress.model';
import { AppHomeAddressModel } from '../../shared/models/ipp/apphomeaddress.model';
import { Ippcsr } from '../../shared/models/ipp/ippcsr';
import { CsrPaymentService } from '../../shared/csr-service/csrpayment.service';

@Component({
  moduleId: module.id,
  selector: 'csr-paymentoptions',
  templateUrl: 'paymentoptions.component.html',
  styleUrls: ['paymentoptions.component.css']
})
export class PaymentOptionsComponent implements OnInit {

  @ViewChild('paymentForm') payForm: NgForm;
  paymentOptionsModel = {
    'paymentOptions':'',
    'paymentType':'',
    'creditCardNumber':'',
    'cvvCode':'',
    'expiryDate':'',
    'nameOnCard':'',
    'isChecked':'',
    'addrType':'',
    'cardHolderAddr1':'',
    'cardHolderAddr2':'',
    'city':'',
    'state':'',
    'county':'',
    'zip':'',
    'ccConfimationMail':'',
    'accHolderName':'',
    'bankRoutingNbr':'',
    'accountNbr':'',
    'accountType':'',
    'isEChecked':'',
    'ecConfimationMail':'',
    'mpconfimationMail':'',
    'sendMailInfo':'',
    'sendPolicyInfo':'',
    'emailAddress': '',
    'withdrawalDay':''
  };

  appBillAddressModel = {
    'addressLine1':'',
    'addressLine2':'',
    'city':'',
    'state':'',
    'county':'',
    'postalCode':'',
  };

  appHomeAddressModel = {
    'addressLine1':'',
    'addressLine2':'',
    'city':'',
    'state':'',
    'county':'',
    'postalCode':'',
  };

  screenLoader: boolean = false;
  hasCounties: boolean = false;
  hasMailPayment: boolean = false;
  isServiceValidationErr : boolean;
  isPaymentException : boolean;
  isTechError : boolean = false;
  isEmpire: boolean = false;
  isCA: boolean = false;
  showMail: boolean = false;

  amtToPay : string;
  amtToPayConfirmation: string;
  applicationStatus: string;
  applicationType: string;
  coverageDate: string;
  wemRequestedEffectiveDate: string;
  retroPayToDate: string;
  lastUpdatedTS: string;
  brandName: string;
  paymentExceptionMsg : string;
  techErrorMsg : string = 'We\'re sorry, but we\'ve encountered a technical error and could not show the requested page.';  
  retroPayToMonth: string = '';
  retroPayToDay: string = '';
  channel: string = '';
  applicantId: string = '';

  inputParams: any = {};
  content : any = {};
  applicationResponse: any = {};
  searchPaymentResponse : any = {};
  getPaymentResponse: any = {};
  setPaymentResponse : any = {};    
  ccPaymentDetails : any = {};
  ecPaymentDetails : any = {};
  counties: any = [];
  serviceValidationErrMsg : any [];

  constructor(public router: Router, private currentUser: User, private ippcsr: Ippcsr, private datepipe: DatePipe, private csrPaymentService : CsrPaymentService){
    if(this.currentUser.userRole === undefined){
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    
    this.content = content;
    this.isTechError = false;
    this.hasCounties = false;
    this.isServiceValidationErr = false;
    this.isPaymentException = false;

    this.coverageDate = '';
    this.applicationStatus = '';
    this.applicationType = '';
    this.applicationResponse = null
    this.setPaymentResponse = null;
    this.getPaymentResponse = null;

    this.searchPaymentResponse = this.ippcsr.searchPaymentResponse[0];
    this.channel = this.ippcsr.channel; 
    this.applicantId = this.ippcsr.applicantId; 
    this.amtToPay = this.ippcsr.premiumAmt;
    this.amtToPayConfirmation = this.amtToPay.replace(' ','');

    if (this.channel === 'ONLINE') {
        this.applicationResponse = this.ippcsr.applicationResponse;
        if(null !== this.applicationResponse && undefined !== this.applicationResponse){
            this.applicationType = this.applicationResponse.applicationType;
            this.applicationStatus = this.applicationResponse.applicationStatus;
            this.applicationResponse.reqEffDate = (null !== this.applicationResponse.reqEffDate && undefined !== this.applicationResponse.reqEffDate) ? this.datepipe.transform(this.applicationResponse.reqEffDate, 'yyyy-MM-ddTHH:mm:ss.SSS') : null;
            this.applicationResponse.lastUpdatedTS = (null !== this.applicationResponse.lastUpdatedTS && undefined !== this.applicationResponse.lastUpdatedTS) ? this.datepipe.transform(this.applicationResponse.lastUpdatedTS, 'yyyy-MM-ddTHH:mm:ss.SSS') : null;

            this.wemRequestedEffectiveDate = (null !== this.applicationResponse.paymentSelection.wemRequestedEffectiveDate && undefined !== this.applicationResponse.paymentSelection.wemRequestedEffectiveDate) ? this.datepipe.transform(this.applicationResponse.paymentSelection.wemRequestedEffectiveDate, 'MM/dd/yyyy') : null;
            this.retroPayToDate = (null !== this.applicationResponse.paymentSelection.retroPayToDate && undefined !== this.applicationResponse.paymentSelection.retroPayToDate) ? this.datepipe.transform(this.applicationResponse.paymentSelection.retroPayToDate, 'MM/dd/yyyy') : null;       
            
            if(null !== this.applicationResponse.applicant.demographic.dateOfBirth && undefined !== this.applicationResponse.applicant.demographic.dateOfBirth){
                this.applicationResponse.applicant.demographic.dateOfBirth = this.datepipe.transform(this.applicationResponse.applicant.demographic.dateOfBirth, 'yyyy-MM-ddTHH:mm:ss.SSS');
            } 

            if(null !== this.applicationResponse.applicant.address && undefined !== this.applicationResponse.applicant.address && this.applicationResponse.applicant.address.length > 0){
               for(var i=0; i < this.applicationResponse.applicant.address.length; i++){
                if(this.applicationResponse.applicant.address[i].addressType !== null && this.applicationResponse.applicant.address[i].addressType !== undefined && this.applicationResponse.applicant.address[i].state !== null && this.applicationResponse.applicant.address[i].state !== undefined){
                  if(this.applicationResponse.applicant.address[i].addressType === 'HOME' || this.applicationResponse.applicant.isBillingAddrSameAsHomeAddr === 'YES' 
                    || this.applicationResponse.applicant.isBillingAddrSameAsHomeAddr === null){
                            this.appHomeAddressModel.addressLine1 = this.applicationResponse.applicant.address[i].addressLine1;
                            this.appHomeAddressModel.addressLine2 = this.applicationResponse.applicant.address[i].addressLine2;
                            this.appHomeAddressModel.city = this.applicationResponse.applicant.address[i].city;
                            this.appHomeAddressModel.county = this.applicationResponse.applicant.address[i].county;
                            this.appHomeAddressModel.state = this.applicationResponse.applicant.address[i].state;
                            this.appHomeAddressModel.postalCode = this.applicationResponse.applicant.address[i].postalCode;
                          } else if(this.applicationResponse.applicant.address[i].addressType === 'BILLING'){
                            this.appBillAddressModel.addressLine1 = this.applicationResponse.applicant.address[i].addressLine1;
                            this.appBillAddressModel.addressLine2 = this.applicationResponse.applicant.address[i].addressLine2;
                            this.appBillAddressModel.city = this.applicationResponse.applicant.address[i].city;
                            this.appBillAddressModel.county = this.applicationResponse.applicant.address[i].county;
                            this.appBillAddressModel.state = this.applicationResponse.applicant.address[i].state;
                            this.appBillAddressModel.postalCode = this.applicationResponse.applicant.address[i].postalCode;
                          }
                        }
                  }
            }
      
            this.coverageDate = this.getCoverageDate(this.applicationResponse.reqEffDate);
            this.brandName = this.getBrandName(this.applicationResponse.state);
            this.retroPayToMonth = this.getRetroPayToMonth(this.applicationResponse.reqEffDate);
            this.getMailDetails(this.applicationResponse);
        }
    } else if (this.channel === 'ENROLL' || this.channel === 'PAPER'){
        this.screenLoader = true;
        var inputParam = {
           "acn": this.applicantId,
           "partnerId": this.channel === 'ENROLL' ? 'HCENTIVE' : 'MAPS'
        }
        this.getPaymentDetails(inputParam);
    } 
  
    this.paymentOptionsModel.paymentOptions = 'CD';
    this.paymentOptionsModel.paymentType = 'VISA';
    this.paymentOptionsModel.addrType = 'CardHolderAddr';
    this.paymentOptionsModel.accountType = 'PERSONALCHECKING';
    this.paymentOptionsModel.withdrawalDay = '1';
  }

  changePaymentOptions(paymentOption: string){
    this.isServiceValidationErr = false;
    this.isPaymentException = false;
    this.isTechError = false;
    if(paymentOption === 'CD'){
      this.paymentOptionsModel.paymentOptions = 'CD';
    } else if(paymentOption === 'EC') {
      this.paymentOptionsModel.paymentOptions = 'EC';
    } else if(paymentOption === 'MP'){
      this.paymentOptionsModel.paymentOptions = 'MP';
    }
  }

   submitPayment (paymentOptionsModel: PaymentOptionsModel){
     this.screenLoader = true;
     if(paymentOptionsModel.isEChecked || paymentOptionsModel.isChecked){
       this.retroPayToDay = this.getRetroPayToDay(paymentOptionsModel.withdrawalDay);
     }
     
     if(this.paymentOptionsModel.paymentOptions === 'CD' || this.paymentOptionsModel.paymentOptions === 'EC'){
       if(this.channel === 'ONLINE'){
          this.constructSetPayMentReq(paymentOptionsModel);
          this.invokeSubmitPayService();
       } else if (this.channel === 'ENROLL' || this.channel === 'PAPER'){
          this.constructSetApplicationReq(paymentOptionsModel);
          this.submitEnrollPaperPayment();
       }
     } else if (this.paymentOptionsModel.paymentOptions === 'MP'){
       jQuery('#mpConfirmationModalOpener').click();
     }
   }

   redirectToHome() {
     this.router.navigate(['/ipp/home']);
   }

   changeAddressType(addressType: string){
     if(this.channel === 'ONLINE'){
       if (addressType === 'AppHomeAddr' || this.applicationResponse.applicant.isBillingAddrSameAsHomeAddr === 'YES' 
          || this.applicationResponse.applicant.isBillingAddrSameAsHomeAddr === null){
          this.paymentOptionsModel.cardHolderAddr1 = this.appHomeAddressModel.addressLine1;
          this.paymentOptionsModel.cardHolderAddr2 = this.appHomeAddressModel.addressLine2;
          this.paymentOptionsModel.city = this.appHomeAddressModel.city;
          this.paymentOptionsModel.county = this.appHomeAddressModel.county;
          this.paymentOptionsModel.state = this.appHomeAddressModel.state;
          this.paymentOptionsModel.zip = this.appHomeAddressModel.postalCode;
        } else if (addressType === 'AppBillAddr'){
          this.paymentOptionsModel.cardHolderAddr1 = this.appBillAddressModel.addressLine1;
          this.paymentOptionsModel.cardHolderAddr2 = this.appBillAddressModel.addressLine2;
          this.paymentOptionsModel.city = this.appBillAddressModel.city;
          this.paymentOptionsModel.county = this.appBillAddressModel.county;
          this.paymentOptionsModel.state = this.appBillAddressModel.state;
          this.paymentOptionsModel.zip = this.appBillAddressModel.postalCode;
        }   
     } else if ((this.channel === 'ENROLL' || this.channel === 'PAPER') && (addressType === 'AppHomeAddr' || addressType === 'AppBillAddr')){
        if(null !== this.searchPaymentResponse && undefined !== this.searchPaymentResponse && null !== this.searchPaymentResponse.address && undefined !== this.searchPaymentResponse.address){ 
          this.paymentOptionsModel.cardHolderAddr1 = this.searchPaymentResponse.address.addressLine1;
          this.paymentOptionsModel.cardHolderAddr2 = this.searchPaymentResponse.address.addressLine2;
          this.paymentOptionsModel.city = this.searchPaymentResponse.address.city;
          if(null !== this.searchPaymentResponse.address.county && undefined !== this.searchPaymentResponse.address.county){
            this.paymentOptionsModel.county = this.searchPaymentResponse.address.county;
          } else {
            this.populateStateAndCountyFromZip(this.searchPaymentResponse.address.postalCode);
          }
          this.paymentOptionsModel.state = this.searchPaymentResponse.address.state;
          this.paymentOptionsModel.zip = this.searchPaymentResponse.address.postalCode;   
        }
     }

     if(addressType === 'CardHolderAddr') {
          this.hasCounties = false;
          this.paymentOptionsModel.cardHolderAddr1 = '';
          this.paymentOptionsModel.cardHolderAddr2 = '';
          this.paymentOptionsModel.city = '';
          this.paymentOptionsModel.county = '';
          this.paymentOptionsModel.state = '';
          this.paymentOptionsModel.zip = '';
          this.payForm.controls['cardHolderAddr1'].markAsUntouched();
          this.payForm.controls['cardHolderAddr1'].markAsPristine();
          this.payForm.controls['city'].markAsUntouched();
          this.payForm.controls['city'].markAsPristine();
          this.payForm.controls['county'].markAsUntouched();
          this.payForm.controls['county'].markAsPristine();
          this.payForm.controls['state'].markAsUntouched();
          this.payForm.controls['state'].markAsPristine();
          this.payForm.controls['zip'].markAsUntouched();
          this.payForm.controls['zip'].markAsPristine();
     }
   }

   populateStateAndCountyFromZip(zip: string){
     if(zip && zip.length === 5){
      this.screenLoader = true;
      this.counties = [];
      this.paymentOptionsModel.county = null;
      this.csrPaymentService.validateZip({zipCode: zip}).subscribe((data:any) => {
        if (data && data.zipCodeResponse && data.zipCodeResponse.zipCode
        && data.zipCodeResponse.responseMessage && data.zipCodeResponse.responseMessage.message === 'SUCCESSFULLY FETCHED') {
          const zipData = data.zipCodeResponse.zipCode;
          if (zipData.stateCode) {
              this.paymentOptionsModel.state = zipData.stateCode;
          }
          if (zipData.countyList && zipData.countyList.county) {
            for (let county of zipData.countyList.county) {
              if (county && county.countyName) {
                this.counties.push({
                  label: county.countyName,
                  value: county.countyName
                });
                if (zipData.countyList.countyLength === 1) {
                    this.paymentOptionsModel.county = county.countyName;
                }
              }
            }
          }
          if(this.counties.length > 1){
            this.hasCounties = true;
          } else {
            this.hasCounties = false;
          }
        } else {
          this.hasCounties = false;
        }
        this.screenLoader = false;
      });
     } else {
        this.hasCounties = false;
        this.paymentOptionsModel.county = '';
        this.paymentOptionsModel.state = '';
        this.payForm.controls['state'].markAsUntouched();
        this.payForm.controls['state'].markAsPristine();
     }
   }

   getPaymentMethod(paymentOptions: string){
     if(paymentOptions === 'CD'){
        return 'CREDITCARD';
     } else if (paymentOptions === 'EC') {
        return 'ECHECK';
     }
   }

   constructSetPayMentReq(paymentOptionsModel: PaymentOptionsModel) {

     this.getCCPaymentDetails(paymentOptionsModel);
     this.getECPaymentDetails(paymentOptionsModel);

     this.inputParams = {  
          "partnerId" : "OLS",
          "userId" : this.getUserId(),
          "acn" : this.applicationResponse.acn,
          "paymentSelection" : {  
              "initialPayment" : [  
                {  
                    "withdrawDay" : (paymentOptionsModel.isChecked || paymentOptionsModel.isEChecked) ? paymentOptionsModel.withdrawalDay : 0,
                    "paymentAmt" : parseFloat(this.amtToPay.substring(1)),
                    "paymentType" : this.getPaymentMethod(paymentOptionsModel.paymentOptions),
                    "billingFrequency" : (paymentOptionsModel.isChecked || paymentOptionsModel.isEChecked) ? 'MONTHLY' : 'NONE',
                    "billingAddr" : this.getBillingAddress(paymentOptionsModel),
                    "creditCard" : this.ccPaymentDetails,
                    "bankAcct" : this.ecPaymentDetails,
                    "action" : 'UPDATE',
                    "isUseCCAddrForBilling" : paymentOptionsModel.addrType === 'CardHolderAddr' ? 'YES' : 'NO'
                }
              ],
              "action" : 'UPDATE',
              "paymentIdentifier" : this.applicationResponse.acn,
              "isReceivePaymentConf" : this.getEmailAddressFlag(paymentOptionsModel),
              "emailAddress" : this.getEmailAddress(paymentOptionsModel),
              //"monthlyPremium" : null !== this.applicationResponse.paymentSelection.monthlyPremium ? this.applicationResponse.paymentSelection.monthlyPremium : 0.0,
              //"computedMRAAmount" : null !== this.applicationResponse.paymentSelection.computedMRAAmount ? this.applicationResponse.paymentSelection.computedMRAAmount : 0.0,
              "initialPaymentLength" : 1,
              "isRecvPaperlessBillInfo" : this.getNodeValue(paymentOptionsModel.sendMailInfo),
              "isRecvElectronicCOC" : this.getNodeValue(paymentOptionsModel.sendPolicyInfo)
          },
          "application" : {  
              "acn" : this.applicationResponse.acn,
              "applicationVersion" : this.applicationResponse.applicationVersion,
              "state" : this.applicationResponse.state,
              "formNo" : this.applicationResponse.formNo,
              "versionNo" : this.applicationResponse.versionNo,
              "premiumAmt" : parseFloat(this.amtToPay.substring(1)),
              "applicationType" : this.applicationResponse.applicationType,
              "reqEffDate" : this.applicationResponse.reqEffDate,
              "accessControlList" : this.applicationResponse.accessControlList,
              "lastUpdatedId" : this.applicationResponse.lastUpdatedId,
              "lastUpdatedTS" : this.applicationResponse.lastUpdatedTS,
              "applicant" : [  
                {  
                    "memberCode" : this.applicationResponse.applicant.memberCode,
                    "demographic" : {  
                        "relationshipType" : this.applicationResponse.applicant.demographic.relationshipType,
                        "yrResideInUS" : this.applicationResponse.applicant.demographic.yrResideInUS,
                        "monthResideInUS" : this.applicationResponse.applicant.demographic.monthResideInUS,
                        "lastName" : this.applicationResponse.applicant.demographic.lastName,
                        "firstName" : this.applicationResponse.applicant.demographic.firstName,
                        "mi" : this.applicationResponse.applicant.demographic.mi,
                        "dateOfBirth" : this.applicationResponse.applicant.demographic.dateOfBirth
                    },
                    "planSelection" : this.applicationResponse.applicant.planSelection
                }
              ],
              "quotedPlans" : [
              ]
          }
        }
   }

   getUserId() {
     if(null !== this.applicationResponse.accessControlList && this.applicationResponse.accessControlList.length > 0
          && null !== this.applicationResponse.accessControlList[0].user) {
            return this.applicationResponse.accessControlList[0].user.userId;
     }
   }

   getCCPaymentDetails(paymentOptionsModel: PaymentOptionsModel) {
     this.ccPaymentDetails = {};
     if(null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'CD'){
       this.ccPaymentDetails = {  
               "cardNo":paymentOptionsModel.creditCardNumber,
               "expDate":paymentOptionsModel.expiryDate,
               "cardType":paymentOptionsModel.paymentType,
               "cardHolderName":paymentOptionsModel.nameOnCard,
               "action":'UPDATE'
            };
        }
   }

   getECPaymentDetails(paymentOptionsModel: PaymentOptionsModel) {
     this.ecPaymentDetails = {};
     if(null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'EC'){
       this.ecPaymentDetails = {  
               "accountNo":paymentOptionsModel.accountNbr,
               "routingNo":paymentOptionsModel.bankRoutingNbr,
               "accountType":paymentOptionsModel.accountType,
               "accountHolderName":paymentOptionsModel.accHolderName,
               "action":'UPDATE',
               "isRecurring":paymentOptionsModel.isEChecked ? 'YES' : 'NO'
            };
        }
   }

   getEmailAddress(paymentOptionsModel: PaymentOptionsModel) {
        if(null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'CD') {
            if(null !== this.paymentOptionsModel.ccConfimationMail && 'Yes' === this.paymentOptionsModel.ccConfimationMail) {
                return this.paymentOptionsModel.emailAddress;
            } else {
              return null;
            }
        } else if(null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'EC') {
            if(null !== this.paymentOptionsModel.ecConfimationMail && 'Yes' === this.paymentOptionsModel.ecConfimationMail) {
                return this.paymentOptionsModel.emailAddress;
            } else {
              return null;
            }
        } else {
            return null;
        }
   }

   getEmailAddressFlag(paymentOptionsModel: PaymentOptionsModel){
      if(paymentOptionsModel.ccConfimationMail === 'Yes' || paymentOptionsModel.ecConfimationMail === 'Yes'){
        return 'YES';
      } else {
        return 'NO';
      }
   }

   getBillingAddress(paymentOptionsModel: PaymentOptionsModel){
     if(null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'CD'){
       return {  
                "addressLine1" : paymentOptionsModel.cardHolderAddr1,
                "addressLine2" : paymentOptionsModel.cardHolderAddr2,
                "city" : paymentOptionsModel.city,
                "county" : paymentOptionsModel.county,
                "state" : paymentOptionsModel.state,
                "postalCode" : paymentOptionsModel.zip,
                "action" : 'UPDATE'
              }
     } else if (null !== this.paymentOptionsModel.paymentOptions && this.paymentOptionsModel.paymentOptions === 'EC'){
       return {
                "addressLine1" : null !== this.appHomeAddressModel.addressLine1 ? this.appHomeAddressModel.addressLine1 : 'test',
                "addressLine2" : null !== this.appHomeAddressModel.addressLine2 ? this.appHomeAddressModel.addressLine2 : '',
                "city" : this.appHomeAddressModel.city,
                "county" : this.appHomeAddressModel.county,
                "state" : this.appHomeAddressModel.state,
                "postalCode" : this.appHomeAddressModel.postalCode,
                "action" : 'UPDATE'
              }
     } 
   }

   invokeSubmitPayService() {
       this.isServiceValidationErr = false;
       this.isPaymentException = false;
       this.isTechError = false;
       //setPayment service call
       this.csrPaymentService.setPayment(this.inputParams).subscribe((data: any) => {  
          if(null !== data.businessError || null !== data.systemError) {
              this.isTechError = true;
              this.screenLoader = false;
              jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
          } else {
              this.setPaymentResponse = data;
              if(null !== data && data !== undefined) {
                  if(null !== data.paymentSelection.validationErrors && undefined !== data.paymentSelection.validationErrors
                        && null !== data.paymentSelection.validationErrors.validationError && undefined !== data.paymentSelection.validationErrors.validationError
                        && data.paymentSelection.validationErrors.validationError.length > 0 && data.paymentSelection.validationErrors.validationErrorLength > 0) {
                        //display validation error message
                        this.isServiceValidationErr = true;
                        this.serviceValidationErrMsg = data.paymentSelection.validationErrors.validationError;
                        this.screenLoader = false;
                  } else if(null !== data.paymentSelection.paymentExceptionMsg && undefined !== data.paymentSelection.paymentExceptionMsg && data.paymentSelection.paymentExceptionMsg !== '') {
                      //display paymentExceptionMsg message
                      this.isPaymentException = true;
                      if(data.paymentSelection.paymentExceptionMsg.startsWith('DUPLICATE')) {
                        var payErrMsg = data.paymentSelection.paymentExceptionMsg.split(':');
                        this.paymentExceptionMsg = payErrMsg[1];
                      } else {
                        this.paymentExceptionMsg = data.paymentSelection.paymentExceptionMsg;
                      }     
                      this.screenLoader = false;
                      jQuery('#duplicatePaymentErrModalOpener').click();
                  } else {
                      if(null !== data.paymentSelection.initialPayment && data.paymentSelection.initialPayment.length > 0) {
                          for(var i = 0; i < data.paymentSelection.initialPayment.length; i++) {
                            if(null !== data.paymentSelection.initialPayment[i] 
                              && (null === data.paymentSelection.initialPayment[i].paymentTrackingId
                              || undefined === data.paymentSelection.initialPayment[i].paymentTrackingId
                              || data.paymentSelection.initialPayment[i].paymentTrackingId === '')) {
                              this.isPaymentException = true;
                              this.paymentExceptionMsg = 'Payment System Unavailable. Please try again';
                              break;
                            }
                          }                    
                      }
                      if(!this.isPaymentException) {
                          //invoke enrollment sevice
                          this.inputParams = {
                                "partnerId":"OLS",
                                "userId":"OLS",
                                "acn":this.applicationResponse.acn,
                                "language":this.applicationResponse.applicationLanguage
                          }
                          this.csrPaymentService.submitPaymentEnrollmentService(this.inputParams).subscribe((data: any) => {
                              if(null !== data && data !== undefined && null !== data.applicationStatus 
                                    && null !== data.applicationStatus.applicationStatus && 'SUBMITTED' === data.applicationStatus.applicationStatus) {
                                  this.screenLoader = false;
                                  if(this.paymentOptionsModel.paymentOptions === 'CD' || this.paymentOptionsModel.paymentOptions === 'EC'){
                                    jQuery('#ccEcConfirmationModalOpener').click();
                                  } 
                              } else {
                                  this.isPaymentException = true;
                                  this.paymentExceptionMsg = 'Payment System Unavailable. Please try again';
                                  this.screenLoader = false;
                              }                     
                          },
                          (err: any) => {
                            this.isTechError = true;
                            this.screenLoader = false;
                            jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
                          });
                      } else {
                        this.screenLoader = false;
                      }
                  } 
                }
          } 
        },
        (err: any) => {
          this.isTechError = true;
          this.screenLoader = false;
          jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
        });  
   }

   getBrandName(state: string){
     this.isEmpire = false;
     this.isCA = false;
     if(state === 'CA'){
       this.isCA = true;
       return 'Anthem Blue Cross';
     } else if (state === 'NY'){
       this.isEmpire = true;
       return 'Empire Blue Cross and Blue Shield';
     } else {
       return 'Anthem Blue Cross and Blue Shield';
     }
   }

   getNodeValue(value : string) {
      if(null !== value && undefined !== value && value !== '') {
            if(value === 'Yes') {
                return 'YES';
            } else if(value === 'No') {
                return 'NO';
            }
      } else {
          return 'NONE';
      }
   } 

   getCoverageDate(reqEffDate: string){
     if((this.applicationStatus === 'PAYMENTFAILED' && this.applicationType === 'OFFEXCHANGE') || (this.applicationType === 'ONEXCHANGE' && this.wemRequestedEffectiveDate === null)){
          return (null !== reqEffDate && undefined !== reqEffDate) ? this.datepipe.transform(reqEffDate, 'MM/dd/yyyy') : '';
        } else if (this.wemRequestedEffectiveDate === null){
          return 'your coverage effective date';
        } else {
          return this.wemRequestedEffectiveDate;
        }
   } 

   getMailDetails(response: any){
     if(response.createPartnerId !== 'KYH' && response.applicationType !== 'OFFEXCHANGE' && 
          !(response.state === 'IN' && response.createPartnerId === 'HIP')){ 
        this.hasMailPayment = true;
      } else {
        this.hasMailPayment = false;
      }

      if(response.applicationType === 'OFFEXCHANGE' || response.applicationType === 'ONEXCHANGE'){
        this.showMail = false;
      } else {
        this.showMail = true;
      }
   }

   getRetroPayToMonth(reqEffDate: string){
      var paymentMonth = '';
      if(null !== this.retroPayToDate && undefined !== this.retroPayToDate){
        paymentMonth = (parseInt(this.retroPayToDate.split('/')[0]) + 1).toString();
      } else if (null !== reqEffDate && undefined !== reqEffDate) {
        paymentMonth = (parseInt(this.datepipe.transform(reqEffDate, "MM/dd/yyyy").split('/')[0]) + 1).toString();
      }
      if(paymentMonth === '01' || paymentMonth === '13'){
        return 'January';
      } else if(paymentMonth === '02'){
        return 'February';
      } else if(paymentMonth === '03'){
        return 'March';
      } else if(paymentMonth === '04'){
        return 'April';
      } else if(paymentMonth === '05'){
        return 'May';
      } else if(paymentMonth === '06'){
        return 'June';
      } else if(paymentMonth === '07'){
        return 'July';
      } else if(paymentMonth === '08'){
        return 'August';
      } else if(paymentMonth === '09'){
        return 'September';
      } else if(paymentMonth === '10'){
        return 'October';
      } else if(paymentMonth === '11'){
        return 'November';
      } else if(paymentMonth === '12'){
        return 'December';
      } else {
        return '';
      }
   }

   getRetroPayToDay(withdrawalDay: string){
     if(withdrawalDay === '1'){
       return '1st';
     } else if (withdrawalDay === '2'){
       return '2nd';
     } else if (withdrawalDay === '3'){
       return '3rd';
     } else if (withdrawalDay === '4'){
       return '4th';
     } else if (withdrawalDay === '5'){
       return '5th';
     } else if (withdrawalDay === '6'){
       return '6th';
     }
   }

   getPaymentDetails(inputParam: any){
     this.csrPaymentService.getPayment(inputParam).subscribe((data: any) => {  
        if(null !== data && undefined !== data && null !== data.paymentSelection && undefined !== data.paymentSelection) {
          this.getPaymentResponse = data;
              if(null !== data.paymentSelection.paymentExceptionMsg && undefined !== data.paymentSelection.paymentExceptionMsg && '' !== data.paymentSelection.paymentExceptionMsg){
                    if(data.paymentSelection.paymentExceptionMsg.startsWith('DUPLICATE')) {
                        var payErrMsg = data.paymentSelection.paymentExceptionMsg.split(':');
                        this.paymentExceptionMsg = payErrMsg[1];
                    } else {
                        this.paymentExceptionMsg = data.paymentSelection.paymentExceptionMsg;
                    }
                    this.screenLoader = false;
                    jQuery('#duplicatePaymentErrModalOpener').click();
              } else {
                    this.wemRequestedEffectiveDate = (null !== data.paymentSelection.wemRequestedEffectiveDate && undefined !== data.paymentSelection.wemRequestedEffectiveDate) ? this.datepipe.transform(data.paymentSelection.wemRequestedEffectiveDate, 'MM/dd/yyyy') : null;
                    this.retroPayToDate = (null !== data.paymentSelection.retroPayToDate && undefined !== data.paymentSelection.retroPayToDate) ? this.datepipe.transform(data.paymentSelection.retroPayToDate, 'MM/dd/yyyy') : null;
                    this.coverageDate = this.getCoverageDate(data.reqEffDate);
                    this.brandName = this.getBrandName(data.paymentSelection.initialPayment[0].billingAddr.state);
                    this.retroPayToMonth = this.getRetroPayToMonth(null);
                    this.getMailDetails(data);
                    this.screenLoader = false;
              }
        } else {
            this.paymentExceptionMsg = 'Unable to locate an application. Please provide another Applicant Id or use the Advanced Search option to find an application.';
            this.screenLoader = false;
            jQuery('#duplicatePaymentErrModalOpener').click();
        }
        
      },
      (err: any) => {
          this.paymentExceptionMsg = 'We\'re sorry, but we\'ve encountered a technical error and could not show the requested page.';
          this.screenLoader = false;
          jQuery('#duplicatePaymentErrModalOpener').click();
      });
   }
  
  constructSetApplicationReq(paymentOptionsModel: PaymentOptionsModel) {
        this.getCCPaymentDetails(paymentOptionsModel);
        this.getECPaymentDetails(paymentOptionsModel);
        this.inputParams = {
              "partnerId": this.channel === 'ENROLL' ? 'HCENTIVE' : 'MAPS',
              "user": {
                  "userId": 'OLS',
                  "shopperRole": 'CONSUMER'
              },
              "application": {
                  "state": this.searchPaymentResponse.address.state,
                  "premiumAmt": parseFloat(this.amtToPay.substring(1)),
                  "brandName": this.searchPaymentResponse.address.state === 'NY' ? 'EMPIRE' : 'ANTHEM',
                  "applicationType": 'PAYMENT',
                  "reqEffDate": '2016-01-02T07:58:47.000',
                  "accessControlList": [{
                      "accessType": 'OWNER',
                      "user": {
                          "userId": 'OLS',
                          "shopperRole": 'CONSUMER'
                      }
                  }],
                  "applicant": [{
                      "demographic": {
                        "relationshipType": 'APPLICANT',
                        "action": 'UPDATE',
                        "yrResideInUS": 0,
                        "monthResideInUS": 0,
                        "lastName": this.searchPaymentResponse.lastName,
                        "firstName": this.searchPaymentResponse.firstName
                      },
                      "address": [{
                        "addressLine1": this.searchPaymentResponse.address.addressLine1,
                        "city": this.searchPaymentResponse.address.city,
                        "county": this.searchPaymentResponse.address.county,
                        "state": this.searchPaymentResponse.address.state,
                        "postalCode": this.searchPaymentResponse.address.postalCode,
                        "addressType": this.searchPaymentResponse.address.addressType,
                        "action": 'NONE'
                      }],
                      "planSelection": {
                        "plan": [],
                        "optRider": [],
                        "planLength": 0,
                        "optRiderLength": 0
                      },
                      "priorCoverage": [],
                      "action": 'UPDATE',
                      "existingPolicyId": 0,
                      "sequenceNo": 0,
                      "addressLength": 1,
                      "priorCoverageLength": 0
                  }],
                  "paymentSelection": {
                    "initialPayment": [{
                      "withdrawDay" : (paymentOptionsModel.isChecked || paymentOptionsModel.isEChecked) ? paymentOptionsModel.withdrawalDay : 0,
                      "paymentAmt" : parseFloat(this.amtToPay.substring(1)),
                      "paymentType" : this.getPaymentMethod(paymentOptionsModel.paymentOptions),
                      "billingAddr" : this.getBillingAddress(paymentOptionsModel),
                      "creditCard" : this.ccPaymentDetails,
                      "bankAcct" : this.ecPaymentDetails,
                      "action": 'UPDATE'
                    }],
                    "isNoInitPayment": 'NO',
                    "action": 'UPDATE',
                    "isRecvPaperlessBillInfo": this.getNodeValue(paymentOptionsModel.sendMailInfo),
                    "isRecvElectronicCOC": this.getNodeValue(paymentOptionsModel.sendPolicyInfo),
                    "paymentIdentifier": this.searchPaymentResponse.hcid,
                    "isReceivePaymentConf": this.getEmailAddressFlag(paymentOptionsModel),
                    "emailAddress": this.getEmailAddress(paymentOptionsModel),
                    //"monthlyPremium": 0.0,
                    //"computedMRAAmount": 0.0,
                    "initialPaymentLength": 1
                  },
                  "quotedPlans": [],
                  "action": 'UPDATE',
                  "createPartnerId": this.channel === 'ENROLL' ? 'HCENTIVE' : 'MAPS',
                  "initialPremium": 0.0,
                  "exchTotalAmtOwed": 0.0,
                  "exchAPTCAmt": 0.0,
                  "applicationSeqId": 0,
                  "exchTotPremiumAmt": 0.0,
                  "aptcAttestationPersons": [],
                  "electedAPTCPercentage": 0,
                  "appliedAPTCAmount": 0.0,
                  "rateAreaId": 0,
                  "exchTransLogId": 0,
                  "exchAPTCPct": 0.0,
                  "accessControlListLength": 1,
                  "applicantLength": 1,
                  "quotedPlansLength": 0
              }
        }
   }

   submitEnrollPaperPayment() {
       this.isServiceValidationErr = false;
       this.isPaymentException = false;
       this.isTechError = false;
       //setPayment service call
       this.csrPaymentService.setApplication(this.inputParams).subscribe((data: any) => {  
          if(null !== data.businessError || null !== data.systemError) {
              this.isTechError = true;
              this.screenLoader = false;
              jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
          } else {
              this.setPaymentResponse = data;
              if(null !== data && data !== undefined && null !== data.application && undefined !== data.application) {
                  if(null !== data.application.paymentSelection && undefined !== data.application.paymentSelection
                        && null !== data.application.paymentSelection.validationErrors && undefined !== data.application.paymentSelection.validationErrors
                        && null !== data.application.paymentSelection.validationErrors.validationError && undefined !== data.application.paymentSelection.validationErrors.validationError
                        && data.application.paymentSelection.validationErrors.validationError.length > 0 && data.application.paymentSelection.validationErrors.validationErrorLength > 0) {
                        //display validation error message
                        this.isServiceValidationErr = true;
                        this.serviceValidationErrMsg = data.application.paymentSelection.validationErrors.validationError;
                        this.screenLoader = false;
                  } else if(null !== data.application.paymentSelection.paymentExceptionMsg && undefined !== data.application.paymentSelection.paymentExceptionMsg 
                      && data.application.paymentSelection.paymentExceptionMsg !== '') {
                      //display paymentExceptionMsg message
                      this.isPaymentException = true;
                      if(data.application.paymentSelection.paymentExceptionMsg.startsWith('DUPLICATE')) {
                        var payErrMsg = data.application.paymentSelection.paymentExceptionMsg.split(':');
                        this.paymentExceptionMsg = payErrMsg[1];
                      } else {
                        this.paymentExceptionMsg = data.application.paymentSelection.paymentExceptionMsg;
                      }     
                      this.screenLoader = false;
                      jQuery('#duplicatePaymentErrModalOpener').click();
                  } else {
                      if(null !== data.application.paymentSelection.initialPayment && data.application.paymentSelection.initialPayment.length > 0) {
                          for(var i = 0; i < data.application.paymentSelection.initialPayment.length; i++) {
                            if(null !== data.application.paymentSelection.initialPayment[i] 
                              && (null === data.application.paymentSelection.initialPayment[i].paymentTrackingId
                              || undefined === data.application.paymentSelection.initialPayment[i].paymentTrackingId
                              || data.application.paymentSelection.initialPayment[i].paymentTrackingId === '')) {
                              this.isPaymentException = true;
                              this.paymentExceptionMsg = 'Payment System Unavailable. Please try again';
                              break;
                            }
                          }                    
                      }
                      if(!this.isPaymentException) {
                          //invoke enrollment sevice
                          this.inputParams = {
                                "partnerId": this.channel === 'ENROLL' ? 'HCENTIVE' : 'MAPS',
                                "userId":"OLS",
                                "acn":this.applicationResponse.acn,
                                "language":this.applicationResponse.applicationLanguage
                          }
                          this.csrPaymentService.submitPayment(this.inputParams).subscribe((data: any) => {
                              if(null !== data && data !== undefined && null !== data.applicationStatus 
                                    && null !== data.applicationStatus.applicationStatus && undefined !== data.applicationStatus.applicationStatus 
                                    && 'PAYMTSUBMITTED' === data.applicationStatus.applicationStatus) {
                                  this.screenLoader = false;
                                  if(this.paymentOptionsModel.paymentOptions === 'CD' || this.paymentOptionsModel.paymentOptions === 'EC'){
                                    jQuery('#ccEcConfirmationModalOpener').click();
                                  }
                              } else {
                                  this.isPaymentException = true;
                                  this.paymentExceptionMsg = 'Payment System Unavailable. Please try again';
                                  this.screenLoader = false;
                              }                     
                          },
                          (err: any) => {
                            this.isTechError = true;
                            this.screenLoader = false;
                            jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
                          });
                      } else {
                        this.screenLoader = false;
                      }
                    } 
                }
            } 
        },
        (err: any) => {
          this.isTechError = true;
          this.screenLoader = false;
          jQuery('html,body').animate({ scrollTop: jQuery('#custom-error').offset().top - jQuery('#custom-error').height() + 10 }, 'slow');
        });
   }
  
}