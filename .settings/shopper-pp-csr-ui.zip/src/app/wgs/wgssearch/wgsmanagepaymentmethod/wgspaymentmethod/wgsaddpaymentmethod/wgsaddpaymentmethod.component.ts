import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
import { content } from '../../../../../shared/constants/constants';
import { PaymentMethodModel } from '../../../../../shared/models/paymentmethod.model';
import { SubscriberAddressModel } from '../../../../../shared/models/wgs/subscriberaddress.model';
import { WgsService } from '../../../../../shared/csr-service/wgs.service';
import { Wgscsr } from '../../../../../shared/models/wgs/wgscsr';
import { NgForm } from '@angular/forms';

@Component({
  moduleId: module.id,
  selector: 'csr-wgsaddpaymentmethod',
  templateUrl: 'wgsaddpaymentmethod.component.html',
  styleUrls: ['wgsaddpaymentmethod.component.css']
})
export class WgsAddPaymentMethodComponent implements OnInit {

  @ViewChild('addNewPaymentForm') addForm: NgForm;
  nickNameError: boolean = false;
  routingNumberError: boolean = false;
  updateError: boolean = false;
  paymentMethodModel = {
    'paymentMethod': '',
    'nickName': '',
    'accountType': '',
    'bankRoutingNbr': '',
    'bankAccountNbr': '',
    'reEnterbankAccountNbr': '',
    'accountHolderName': '',
    'addressOnAccount': '',
    'address1': '',
    'address2': '',
    'city': '',
    'state': '',
    'zipCode': '',
    'cardNumber':'',
    'cvvCode':'',
    'expiryDate':'',
    'cardName':''
  }
  subscriberAddressModel = {
    'address1': 'SubscriberAddr One',
    'address2': 'SubscriberAddr Two',
    'city': 'Subscriber City',
    'state': 'KY',
    'zipcode': '90001'
  }
  accountTypeList: any;
  content : any = {};
  screenLoader: boolean = false;
  techerror: boolean = false;
  updatePaymentMethodResponse: any = {};
  routingNumberResponse: any = {};
  usedNickNames:string[]=[];
  constructor(public router: Router, public wgsService : WgsService, public wgscsr : Wgscsr){}

  ngOnInit() {
    this.content = content;
    this.accountTypeList = [{
      label: 'Personal Checking',
      value: 'PERSONALCHECKING'
    }, {
      label: 'Personal Savings',
      value: 'PERSONALSAVINGS'
    }, {
      label: 'Business Checking',
      value: 'BUSCHECKING'
    }, {
      label: 'Business Savings',
      value: 'BUSSAVINGS'
    }];
    setTimeout(() => {
      this.changeAddressOnAccount('SubscriberAddr');
    }, 100);
    this.usedNickNames = this.wgscsr.existingNickNames;
  }

   savePaymentMethod (paymentMethodModel: PaymentMethodModel){
     this.techerror = false;
     this.routingNumberError = false;
     this.updateError = false;
     this.screenLoader = true;
     this.nickNameError = false;

     if(this.usedNickNames.indexOf(paymentMethodModel.nickName) > -1){
        this.nickNameError = true;
        this.screenLoader = false;
        jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
      } else {
          var routingInputParams = {
              "number" : paymentMethodModel.bankRoutingNbr
          }
          this.wgsService.validateRoutingNumber(routingInputParams).subscribe((data: any) => {
              this.screenLoader = false;
              this.routingNumberResponse = data;
              if (this.routingNumberResponse.valid === true) {
                  var inputParams = {
                      "hcid": this.wgscsr.healthCardId,
                      "action": "CREATE",
                      "paymentMethod": {
                        "accNickName": paymentMethodModel.nickName,
                        "routingNumber":paymentMethodModel.bankRoutingNbr,
                        "accountName": paymentMethodModel.accountHolderName,
                        "paymentType": "BANKINGACCOUNT",
                        "billingAddress": {
                            "addressLine1": paymentMethodModel.address1,
                            "addressLine2": paymentMethodModel.address2,
                            "city": paymentMethodModel.city,
                            "state": paymentMethodModel.state,
                            "postalCode": paymentMethodModel.zipCode
                        },
                        "bankAccountType": paymentMethodModel.accountType,
                        "confirmAccountNo": paymentMethodModel.bankAccountNbr,
                        "maskedAccountNumber": paymentMethodModel.bankAccountNbr
                      }
                  }                 
                  this.wgsService.updatePaymentMethods(inputParams).subscribe((data: any) => {
                    this.screenLoader = false;
                    this.updatePaymentMethodResponse = data;
                    if (this.updatePaymentMethodResponse.message !== undefined && this.updatePaymentMethodResponse.message.messageText !== undefined &&
                      this.updatePaymentMethodResponse.message.messageText === 'Success') {
                      jQuery("#confirmationModalOpener").click();
                    } else {
                      jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                      this.updateError = true;
                    }
                  },
                  (err: any) => {
                    jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
                    this.techerror = true;
                    this.screenLoader = false;
                  });
              } else {
                this.routingNumberError = true;
                jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow');   
              }
            },
            (err: any) => {
              jQuery('html,body').animate({ scrollTop: jQuery("#custom-error").offset().top - 200 }, 'slow'); 
              this.techerror = true;
              this.screenLoader = false;
            });
      }

     
   }

   redirectToHome(selected: string) {
     this.wgscsr.paymentOption = selected;
     jQuery("#confirmationModalOpener").click();
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   cancel(selected: string){
     this.wgscsr.paymentOption = selected;
     this.router.navigate(['/wgs/wgsmanagepaymentmethod']);
   }

   changeAddressOnAccount(addressType: string){
     if(addressType === 'SubscriberAddr'){
        this.paymentMethodModel.addressOnAccount = 'SubscriberAddr';
        this.paymentMethodModel.address1 = this.subscriberAddressModel.address1;
        this.paymentMethodModel.address2 = this.subscriberAddressModel.address2;
        this.paymentMethodModel.city = this.subscriberAddressModel.city;
        this.paymentMethodModel.state = this.subscriberAddressModel.state;
        this.paymentMethodModel.zipCode = this.subscriberAddressModel.zipcode;
        this.addForm.controls['address1'].markAsTouched();
        this.addForm.controls['city'].markAsTouched();
        this.addForm.controls['state'].markAsTouched();
        this.addForm.controls['zipCode'].markAsTouched();
     } else {
        this.paymentMethodModel.addressOnAccount = 'AlternativeAddr';
        this.paymentMethodModel.address1 = '';
        this.paymentMethodModel.address2 = '';
        this.paymentMethodModel.city = '';
        this.paymentMethodModel.state = '';
        this.paymentMethodModel.zipCode = '';
        this.addForm.controls['address1'].markAsPristine();
        this.addForm.controls['city'].markAsPristine();
        this.addForm.controls['state'].markAsPristine();
        this.addForm.controls['zipCode'].markAsPristine();
        this.addForm.controls['address1'].markAsUntouched();
        this.addForm.controls['city'].markAsUntouched();
        this.addForm.controls['state'].markAsUntouched();
        this.addForm.controls['zipCode'].markAsUntouched();
     }
   }

   bankAccountFieldOnChange(flag: boolean){
     if(flag){
      this.paymentMethodModel.reEnterbankAccountNbr = '';
      this.addForm.controls['reEnterbankAccountNbr'].markAsPristine();
      this.addForm.controls['reEnterbankAccountNbr'].markAsUntouched();
    }
   }

}
