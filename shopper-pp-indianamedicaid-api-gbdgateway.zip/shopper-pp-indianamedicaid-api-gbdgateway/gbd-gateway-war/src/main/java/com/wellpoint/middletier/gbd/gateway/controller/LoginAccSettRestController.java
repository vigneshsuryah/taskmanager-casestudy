package com.wellpoint.middletier.gbd.gateway.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.wellpoint.memberpay.request.BaseRequest;
import com.wellpoint.middletier.gbd.gateway.bo.DeleteUserAccountRestRequestKYTPPLoginService;
import com.wellpoint.middletier.gbd.gateway.bo.DeleteUserAccountRestRequestKYTPPService;
import com.wellpoint.middletier.gbd.gateway.bo.DeleteUserAccountRestResponse;
import com.wellpoint.middletier.gbd.gateway.bo.LoginResponse;
import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.exception.GbdException;
import com.wellpoint.middletier.gbd.gateway.request.SearchUserDetailsRestRequest;
import com.wellpoint.middletier.gbd.gateway.response.SearchUserDetailsRestResponse;
import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;
import com.wellpoint.midletier.gbd.gateway.util.GbdHelperUtils;
import com.wellpoint.midletier.gbd.gateway.util.GbdUtil;

@Controller  
public class LoginAccSettRestController implements GbdConstants {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginAccSettRestController.class);
	@Autowired
	private ApplicationPropertiesUI applicationProperties;	
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private GbdUtil gbdUtil;
	@Autowired
	private GbdHelperUtils gbdHelperUtils;
	
	public String getSecureRestPath() {
		return applicationProperties.getStringProperty("gbd.setting.rest.service.endpoint");
	}

	@RequestMapping(value = "/login/generateTokenWithSMHeaders", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody LoginResponse generateTokenWithSMHeaders(HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in generateTokenWithSMHeaders() of GbdGatewayRestController");
		LoginResponse response = new LoginResponse();
		try{
			String userName = httpRequest.getHeader("SM_USER");
			String userDn = httpRequest.getHeader("SM_USERDN");
			if(null == userName || userName.isEmpty()){
				throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
			}else{
				String jwtToken=gbdUtil.getJWTToken(userName, applicationProperties.getStringProperty("gbd.setting.member.jwt.secret.key"));
				
				SearchUserDetailsRestRequest searchUserDetailsRestRequest = new SearchUserDetailsRestRequest();
				searchUserDetailsRestRequest.setUserName(userName);
				HttpEntity<Object> requestEntity = new HttpEntity<Object>(searchUserDetailsRestRequest,getTPPLoginHttpHeaders(httpRequest));			
				SearchUserDetailsRestResponse searchUserDetailsRestResponse = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/getRegisterUserDetails",requestEntity, SearchUserDetailsRestResponse.class);
				
				response.setAuthToken(jwtToken);
				response.setUserDn(userDn);
				if(null != searchUserDetailsRestResponse.getUser()){
					response.setOrgType(searchUserDetailsRestResponse.getUser().getOrgType());
					response.setOrgName(searchUserDetailsRestResponse.getUser().getOrgName());
					response.setUserName(searchUserDetailsRestResponse.getUser().getUsername());
					response.setAuthFlag(searchUserDetailsRestResponse.getUser().isAuthFlag());
				}else{
					response.setUserName(userName);
				}
				
				String aciEnableFlag = getAciEnableFlag();
				if(null != aciEnableFlag && !aciEnableFlag.isEmpty() && aciEnableFlag.equalsIgnoreCase("true")){
					response.setAciFlag(true);
				}else{
					response.setAciFlag(false);
				}
				String recurringEnableFlag = getRecurringFlag();
				if(null != recurringEnableFlag && !recurringEnableFlag.isEmpty() && recurringEnableFlag.equalsIgnoreCase("true")){
					response.setRecurringFlag(true);
				}else{
					response.setRecurringFlag(false);
				}
			}
		}catch(Exception e){
			LOGGER.error("Exception in getToken() of Gateway "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}	
	
	private String getRecurringFlag() {
		return applicationProperties.getStringProperty("tpp.setting.recurring.sections.enable.flag");
	}

	public String getAciEnableFlag() {
		return applicationProperties.getStringProperty("tpp.setting.aci.sections.enable.flag");
	}

	@RequestMapping(value = "/loginservices/v1/gbd/register/createuser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object createuser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in createuser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/createuser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in createuser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/register/getSecretQuestions", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getSecretQuestions(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getSecretQuestions() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/getSecretQuestions",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getSecretQuestions() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/register/validateSecretAnswerForForgotPassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateSecretAnswerForForgotPassword(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateSecretAnswerForForgotPassword() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/validateSecretAnswerForForgotPassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotPassword() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/register/validateSecretAnswerForForgotUserName", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateSecretAnswerForForgotUserName(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateSecretAnswerForForgotUserName() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/validateSecretAnswerForForgotUserName",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateSecretAnswerForForgotUserName() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/deleteUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object deleteUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in deleteUser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/deleteUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in deleteUser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object searchUserSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in searchUser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/searchUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in searchUser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/authenticateUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object authenticateUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in authenticateUser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/authenticateUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in authenticateUser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/modifyUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object modifyUser(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in modifyUser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/modifyUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in modifyUser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object changePasswordSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in changePasswordSecure() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/changePassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in changePasswordSecure() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object changePasswordUnSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in changePasswordUnSecure() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/changePassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in changePasswordUnSecure() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object searchUserUnSecure(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in searchUser() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/searchUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in searchUser() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}	
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/getUserIdDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getUserIdDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in getUserIdDetails() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/getUserIdFromEmailId",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in getUserIdDetails() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}	
	
	
	/*2fa change for TPP/KYTPP starts here*/
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/validateLoginInformation", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateLoginInformation(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateLoginInformation() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/validateLoginInformation",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateLoginInformation() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/validateRegisterUserDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object validateRegisterUserDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in validateRegisterUserDetails() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/validateRegisterUserDetails",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in validateRegisterUserDetails() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/otp/attemptsRemaining", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object attemptsRemaining(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/attemptsRemaining() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/attemptsRemaining",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/attemptsRemaining() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/users/profile", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object usersProfile(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in users/profile() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/users/profile",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in users/profile() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/threatapi", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object threatapi(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in threatapi() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/threatapi",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in threatapi() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/dfp/save", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object dfpSave(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in dfp/save() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/dfp/save",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in dfp/save() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/getChannelDetails", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object getChannelDetails(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in dfp/save() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/getChannelDetails",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in dfp/save() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/otp/send", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object otpSend(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/send() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/send",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/send() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/loginservices/v1/gbd/account/otp/validate", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object otpValidate(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in otp/validate() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/otp/validate",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in otp/validate() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundhip/secure/v1/gbd/account/updateAuthFlag", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateAuthFlag(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateAuthFlag() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/updateAuthFlag",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in updateAuthFlag() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	private HttpHeaders get2FAHttpHeaders(HttpServletRequest httpRequest){
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		if(null == senderApp){
			senderApp = "TPP";
		}
		String senderAppKey = applicationProperties.getStringProperty("gbd.meta.senderapp.secretkey." + senderApp);
		senderAppKey = GbdUtil.getDecodedText(senderAppKey);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", senderApp);
		headers.add("meta-senderapp-key", senderAppKey);
		String ipaddress = getHeaderValueFromRequest(httpRequest, "ipaddress");
		if(!ipaddress.isEmpty()) {
			headers.add("ipaddress", getIpAddress(httpRequest));
		}
		String senderapp = getHeaderValueFromRequest(httpRequest, "senderapp");
		if(!senderapp.isEmpty()) {
			headers.add("senderapp", senderapp);
		}
		String webguid = getHeaderValueFromRequest(httpRequest, "webguid");
		if(!webguid.isEmpty()) {
			headers.add("webguid", webguid);
		}
		String module = getHeaderValueFromRequest(httpRequest, "module");
		if(!module.isEmpty()) {
			headers.add("module", module);
		}
		String usernm = getHeaderValueFromRequest(httpRequest, "usernm");
		if(!usernm.isEmpty()) {
			headers.add("usernm", usernm);
		}
		return headers;
	}

	public static String getHeaderValueFromRequest(HttpServletRequest httpRequest, String headerName) {
        String value = "";
        try
        {
        	value = httpRequest.getHeader(headerName);
        }catch(Exception e)
        {
        	LOGGER.error("Error occured in fetching header - " + headerName + " - value");
        }
        return value == null ? "":value;
    }
	
	public static String getIpAddress(HttpServletRequest request) {
        String xffStr = StringUtils.defaultString(request.getHeader("x-forwarded-for"));
        if (StringUtils.isEmpty(xffStr)) {
            xffStr = StringUtils.defaultString(request.getRemoteAddr());
        }
        return xffStr;
    }

	
	/*2fa change for TPP/KYTPP ends here*/
	
	
	private HttpHeaders getTPPLoginHttpHeaders(HttpServletRequest httpRequest){
		
		String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
		if(null == senderApp){
			senderApp = "TPP";
		}
		String senderAppKey = applicationProperties.getStringProperty("gbd.meta.senderapp.secretkey." + senderApp);
		senderAppKey = GbdUtil.getDecodedText(senderAppKey);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", senderApp);
		headers.add("meta-senderapp-key", senderAppKey);
		return headers;
	}
	
	
	private HttpHeaders getKYTPPServiceHttpHeaders(String senderApp, String orgType){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.add("meta-senderapp", senderApp);
		headers.add("meta-orgType", orgType);
		headers.add("meta-src-envrmt", applicationProperties.getStringProperty("gbd.meta.src.envrmt.value"));
		return headers;
	}
	
	/*gbd ky tpp changes starts here*/

	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/deleteUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object deleteUserKYTPP(@RequestBody DeleteUserAccountRestRequestKYTPPLoginService request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in deleteUserKYTPP() of LoginAccSettRestController");
		Object response = null;
		Boolean deleteUserAccountResponse = false;
		try{
			//login delete service request
			HttpEntity<Object> requestEntityLogin = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));
			
			//gbd delete service request
			String senderApp = GbdUtil.getMetaSenderAppValue(httpRequest);
			String orgType = GbdUtil.getMetaOrgTypeValue(httpRequest);
			DeleteUserAccountRestRequestKYTPPService requestService = new DeleteUserAccountRestRequestKYTPPService();
			requestService.setUserName(request.getUserName());
			requestService.setRequestHeader(((BaseRequest) gbdHelperUtils.getRequestInstance(BaseRequest.class, senderApp))
					.getRequestHeader());
			HttpEntity<Object> requestEntityService = new HttpEntity<Object>(requestService,getKYTPPServiceHttpHeaders(senderApp, orgType));
			
			//gbd delete service call
			deleteUserAccountResponse = (Boolean) restTemplate.postForObject(getSecureRestPath()+"/gbdpaymentsvc/v1/gbd/payments/deleteallrecurring",requestEntityService, Object.class);
			
			if(deleteUserAccountResponse) {
				//login delete service call
				response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/deleteUser",requestEntityLogin, Object.class);
			}else {
				response = new DeleteUserAccountRestResponse();
				((DeleteUserAccountRestResponse) response).setDeleteUserStatus(false);
			}
		}catch(Exception e){
			LOGGER.error("Exception in deleteUserKYTPP() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/searchUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object searchUserSecureKYTPP(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in searchUserSecureKYTPP() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/searchUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in searchUserSecureKYTPP() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/authenticateUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object authenticateUserKYTPP(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in authenticateUserKYTPP() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/authenticateUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in authenticateUserKYTPP() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/modifyUser", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object modifyUserKYTPP(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in modifyUserKYTPP() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/account/modifyUser",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in modifyUserKYTPP() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/changePassword", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object changePasswordSecureKYTPP(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in changePasswordSecureKYTPP() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,getTPPLoginHttpHeaders(httpRequest));			
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/gbd/register/changePassword",requestEntity, Object.class);			
		}catch(Exception e){
			LOGGER.error("Exception in changePasswordSecureKYTPP() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}
	
	@RequestMapping(value = "/gofundkyhp/secure/v1/gbd/account/updateAuthFlag", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody Object updateKYTPPAuthFlag(@RequestBody Object request, HttpServletRequest httpRequest) throws GbdException{
		LOGGER.info("in updateAuthFlag() of LoginAccSettRestController");
		Object response = null;
		
		try{
			HttpEntity<Object> requestEntity = new HttpEntity<Object>(request,get2FAHttpHeaders(httpRequest));
			response = restTemplate.postForObject(getSecureRestPath()+"/gbdloginsvc/soaservices/v1/tpp/2fa/updateAuthFlag",requestEntity, Object.class);
		}catch(Exception e){
			LOGGER.error("Exception in updateAuthFlag() of LoginAccSettRestController "+e);
			throw new GbdException(ERROR_TYPE, TECHNICAL_ERR_CD, TECHNICAL_ERR_MSG, REST_ERROR_500);
		}
		return response;
	}

	/*gbd ky tpp changes ends here*/
}
