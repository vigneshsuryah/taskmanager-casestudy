package com.wellpoint.middletier.gbd.gateway.bo;

import com.wellpoint.memberpay.request.RequestHeader;

public class DeleteUserAccountRestRequestKYTPPLoginService {

	private String dn;
	private String comments;
	private String relationShipType;
	private String userName;
	private String endPointName;
	private String requestingSystem;
	
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getRelationShipType() {
		return relationShipType;
	}
	public void setRelationShipType(String relationShipType) {
		this.relationShipType = relationShipType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEndPointName() {
		return endPointName;
	}
	public void setEndPointName(String endPointName) {
		this.endPointName = endPointName;
	}
	public String getRequestingSystem() {
		return requestingSystem;
	}
	public void setRequestingSystem(String requestingSystem) {
		this.requestingSystem = requestingSystem;
	}
}
