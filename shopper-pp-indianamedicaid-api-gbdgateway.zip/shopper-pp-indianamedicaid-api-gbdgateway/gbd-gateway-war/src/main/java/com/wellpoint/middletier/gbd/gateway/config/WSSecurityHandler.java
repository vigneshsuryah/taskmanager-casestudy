package com.wellpoint.middletier.gbd.gateway.config;

import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.PortInfo;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class WSSecurityHandler implements SOAPHandler<SOAPMessageContext>,
        javax.xml.ws.handler.HandlerResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(WSSecurityHandler.class);

    @SuppressWarnings("unchecked")
    private List<Handler> handlerChain = new ArrayList<Handler>();

    private String username;
    private String password;

    public WSSecurityHandler() {
        handlerChain.add(this);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Handler> getHandlerChain(PortInfo portInfo) {
        return handlerChain;
    }
    @Override
    public Set<QName> getHeaders() {
        return new TreeSet<QName>();
    }

    public boolean handleMessage(SOAPMessageContext context) {
        Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        final javax.xml.soap.SOAPMessage message = context.getMessage();
        if (BooleanUtils.isTrue(outboundProperty)) {
            try {
                SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
                SOAPFactory factory = SOAPFactory.newInstance();
                String prefix = "wsse";
                String uri = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

                // <wsse:Username>
                SOAPElement usernameElement = factory.createElement("Username", prefix, uri);
                usernameElement.addTextNode(username);

                // <wsse:Password
                // Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">
                final String PASSWORD_TYPE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText"; 
                SOAPElement passwordElement = factory.createElement("Password", prefix, uri);
                passwordElement.addAttribute(new QName("Type"), PASSWORD_TYPE);
                passwordElement.addTextNode(password);

                // <wsse:UsernameToken wsu:Id="unt_20"
                // xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
                SOAPElement usernameTokenElement = factory.createElement("UsernameToken", prefix, uri);
                usernameTokenElement.addChildElement(usernameElement);
                usernameTokenElement.addChildElement(passwordElement);

                // <wsse:Security soapenv:mustUnderstand="1"
                // xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
                SOAPElement securityElement = factory.createElement("Security", prefix, uri);

                Name name = factory.createName("mustUnderstand", "senv", "http://schemas.xmlsoap.org/soap/envelope/");
                securityElement.addAttribute(name, "1");
                securityElement.addChildElement(usernameTokenElement);

                SOAPHeader header = envelope.addHeader();
                header.addChildElement(securityElement);

                trace(context, false);
            } catch (Exception e) {
                LOGGER.error("Exception in WSSecurityHandler handler: " + e);
            }
        }

        return true;
    }

    public boolean handleFault(SOAPMessageContext context) {
        trace(context,true);
        return true;
    }

    private void trace(SOAPMessageContext context, boolean isError) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            context.getMessage().writeTo(out);
        } catch (SOAPException e) {
        	LOGGER.error("WSSecurityHandler SOAPException"+e);
        } catch (IOException e) {
        	  LOGGER.error("WSSecurityHandler IOException"+e);
        }
        //String strMsg = new String(out.toByteArray());
    }
    @Override
    //This method is not required for the functionality 
    public void close(MessageContext context) {
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
