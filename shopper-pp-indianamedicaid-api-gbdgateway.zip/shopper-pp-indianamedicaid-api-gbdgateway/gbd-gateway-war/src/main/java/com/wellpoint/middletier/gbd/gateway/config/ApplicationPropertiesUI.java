/**
* ApplicationPropertiesUI.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 08/30/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.config;

import java.util.Properties;

import org.apache.commons.configuration.AbstractConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.config.ConcurrentCompositeConfiguration;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicConfiguration;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicPropertyUpdater;
import com.netflix.config.DynamicStringProperty;
import com.netflix.config.PollResult;

@Component
public class ApplicationPropertiesUI {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationPropertiesUI.class);
	
	private ConcurrentCompositeConfiguration finalConfig = new ConcurrentCompositeConfiguration();
	private DynamicPropertyUpdater dynamicPropertyUpdater = new DynamicPropertyUpdater();

	public static String getStringProperty(String key, String defaultValue) {
		final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, defaultValue);
		return property.get();
	}
	
	public String getStringProperty(String key) {
		return getStringProperty(key, null);
	}

	public void updateProperty(String key, String value) {
		finalConfig.setOverrideProperty(key, value);
	}

	public Properties listAll() {
		return finalConfig.getProperties();
	}
	
	public void updateProperties() {
		try {
			AbstractConfiguration config= ConfigurationManager.getConfigInstance();
			if (config instanceof DynamicConfiguration) {
				PollResult result = ((DynamicConfiguration) config).getSource().poll(false, null);
				dynamicPropertyUpdater.updateProperties(result, config, false);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in updateProperties() of ApplicationPropertiesUI :"+e);
		}
	}
}
