package com.wellpoint.middletier.gbd.gateway.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;
import com.wellpoint.middletier.gbd.gateway.request.LoggingChangeRequest;
import com.wellpoint.middletier.gbd.gateway.response.LoggingChangeResponse;

@Controller
public class UtilityController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UtilityController.class);
	
	@Autowired
	private ApplicationPropertiesUI applicationProperties;	
	
	
	@RequestMapping(value = "/changeLoggingLevel", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	LoggingChangeResponse changeLoggingLevel(@RequestBody LoggingChangeRequest request)
	{
		LoggingChangeResponse response= new LoggingChangeResponse();
		try
		{
			String changeLevel = request.getLoggingLevel();
			response.setChangeStatus("NOT CHANGED");
			LOGGER.info("Inside changeLoggingLevel() of gbd-gateway-war");
			org.apache.log4j.Logger root = org.apache.log4j.Logger.getRootLogger();
			if(changeLevel != null && !changeLevel.isEmpty())
			{
				if(changeLevel.equalsIgnoreCase("ALL"))
				{
					root.setLevel(Level.ALL);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("TRACE"))
				{
					root.setLevel(Level.TRACE);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("DEBUG"))
				{
					root.setLevel(Level.DEBUG);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("INFO"))
				{
					root.setLevel(Level.INFO);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("WARN"))
				{
					root.setLevel(Level.WARN);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("ERROR"))
				{
					root.setLevel(Level.ERROR);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("FATAL"))
				{
					root.setLevel(Level.FATAL);
					response.setChangeStatus("CHANGED");
				}else if(changeLevel.equalsIgnoreCase("OFF"))
				{
					root.setLevel(Level.OFF);
					response.setChangeStatus("CHANGED");
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in changeLoggingLevel() of gbd-gateway-war");
		}
		return response;
	}
	
	@RequestMapping(value = "/changeMessageBundlePropsValue", method = RequestMethod.POST, headers = "Accept=*/*", consumes = { "application/json",
	"application/xml" }, produces = { "application/json; charset=UTF-8", "text/html;charset=UTF-8" })
	public @ResponseBody
	LoggingChangeResponse changeMessageBundlePropsValue(@RequestBody LoggingChangeRequest request)
	{
		LoggingChangeResponse response= new LoggingChangeResponse();
		response.setChangeStatus("Value Not Changed. Error Occured.");
		try
		{
			String key = request.getPropsKey();
			String value = request.getPropsValue();
			
			LOGGER.info("Inside changeMessageBundlePropsValue() of gbd-gateway-war");
			String path = "/wsapps/eox/deployment/config/memberpay/gbd/gateway/gateway-app.properties";
			Properties props = new Properties();
			  
		      FileInputStream configStream = new FileInputStream(path);
		      props.load(configStream);
		      configStream.close();
		      
		      String existingValue = props.getProperty(key, "NOTFOUND");
		      if( existingValue != null && !existingValue.isEmpty() && !existingValue.equals("NOTFOUND"))
		      {
		    	  props.setProperty(key, value);
		    	  FileOutputStream output = new FileOutputStream(path);
			      props.store(output, "Archaius - Dynamic Loading Property file.");
			      output.close();
		    	  response.setChangeStatus("Value Changed");
		    	  applicationProperties.updateProperties();
		      }else
		      {
		    	  response.setChangeStatus("New Key - Not Added");
		      }
		} catch (Exception e)
		{
			LOGGER.error("Exception in changeMessageBundlePropsValue() of gbd-gateway-war : " + e);
		}
		return response;
	}	
	
	
}
