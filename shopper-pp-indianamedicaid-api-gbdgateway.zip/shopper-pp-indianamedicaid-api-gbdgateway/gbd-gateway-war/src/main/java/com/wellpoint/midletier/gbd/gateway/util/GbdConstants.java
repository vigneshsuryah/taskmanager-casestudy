/**
* GbdConstants
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 07/01/2016  1.0      Cognizant       Initial Version
* 05/16/2017  1.1      Cognizant	   Modified by Cognizant for TPP change July 2017
* 08/09/2018  1.2      Cognizant	   Modified by Cognizant for IPP change Aug 2018
*/
package com.wellpoint.midletier.gbd.gateway.util;


public interface GbdConstants {
	
	String ERROR_TYPE = "E";
	int REST_ERROR_200 = 200;
	int REST_ERROR_400 = 400;	
	String TECHNICAL_ERR_CD = "GBD1000";
	String TECHNICAL_ERR_MSG = "Technical Error";
	int REST_ERROR_500 = 500;
	String REQ_PARAM_MSG_ERR_CD = "GBD1002";
	String REQ_PARAM_MSG_ERR_MSG = "One or more of the request parameters are missing/wrong. Please correct the request.";	
	
	//Modified by Cognizant for TPP change July 2017 - Start
	String TPP_SENDER_APP = "TPP";
	String KYTPP_SENDER_APP = "KYTPP";
	String KYPP_SENDER_APP = "KYPPCSR";
	String EMPTY = "";
	String CN = "CN=";
	String COMMA = ",";
	String GBDPPORTCSR = "GBDPPORTCSR";
	String MACAPPADMIN = "MACAPPADMIN";
	String PPORTCSR = "PPORTCSR";
	String CSRPAYMENT = "CSRPAYMENT";
	String HIPCSRPAYMENT = "HIPCSRPAYMENT";
	String KYHCSRPAYMENT = "KYHCSRPAYMENT";
	String KYHPPORTCSR = "KYHPPORTCSR";
	String PPCSRADMIN = "PPCSRADMIN";
	String WGSCSRPAYMENT  = "WGSCSRPAYMENT";
	String GBDCSRSUBMIT = "GBDCSRSUBMIT";
	String KYHCSRSUBMIT = "KYHCSRSUBMIT";
	String MACSRSUBMIT = "MACSRSUBMIT";
	String MSCSRSUBMIT = "MSCSRSUBMIT";
	String PPORTCSRSUBMIT = "PPORTCSRSUBMIT";
	String REPORTSADMIN = "REPORTSADMIN";
	String MSMACSRSUBMIT = "MSMACSRSUBMIT";
	String WGSCSRSUBMIT = "WGSCSRSUBMIT";
	String ADHOCREPORT = "ADHOCREPORT";
	String REFUNDSADMIN = "REFUNDSADMIN";
	
	//Modified by Cognizant for TPP change July 2017 - End
	
	//Added by Cognizant for IPP CSR Rest wrapper class for Enrollment service - Start
	String IPP_TECH_ERROR_CODE = "IPP1000";
	String IPP_INVALID_INPUT = "IPP1001";
	//Added by Cognizant for IPP CSR Rest wrapper class for Enrollment service - Start
}
