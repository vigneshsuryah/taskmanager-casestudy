package com.wellpoint.middletier.gbd.gateway.bo;

import java.io.Serializable;

public class LoginRequest implements Serializable{

	
	private static final long serialVersionUID = -5967972240526769345L;
	
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
