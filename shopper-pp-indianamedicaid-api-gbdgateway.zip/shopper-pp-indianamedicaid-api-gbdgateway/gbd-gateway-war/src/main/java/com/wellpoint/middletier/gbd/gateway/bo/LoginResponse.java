package com.wellpoint.middletier.gbd.gateway.bo;

import java.io.Serializable;
import java.util.List;

public class LoginResponse implements Serializable{
	private static final long serialVersionUID = -2427907274251651099L;
	
	
	private String authToken;
	
	private String userName;
	private String userDn;
	private String orgType;
	private String orgName;
	private boolean aciFlag;
	private boolean recurringFlag;
	private String relShpType;
	private String relShpName;
	private List<String> userRole;
	private String firstName;
	private String lastName;
	private boolean authFlag;
	private List<String> rules;

	public String getAuthToken() {
		return authToken;
	}


	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserDn() {
		return userDn;
	}


	public void setUserDn(String userDn) {
		this.userDn = userDn;
	}


	public String getOrgType() {
		return orgType;
	}


	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}


	public String getOrgName() {
		return orgName;
	}


	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}


	public boolean isAciFlag()
	{
		return aciFlag;
	}


	public void setAciFlag(boolean aciFlag)
	{
		this.aciFlag = aciFlag;
	}


	public String getRelShpType()
	{
		return relShpType;
	}


	public void setRelShpType(String relShpType)
	{
		this.relShpType = relShpType;
	}


	public String getRelShpName()
	{
		return relShpName;
	}


	public void setRelShpName(String relShpName)
	{
		this.relShpName = relShpName;
	}


	public List<String> getUserRole() {
		return userRole;
	}


	public void setUserRole(List<String> userRole) {
		this.userRole = userRole;
	}


	public boolean isRecurringFlag() {
		return recurringFlag;
	}


	public void setRecurringFlag(boolean recurringFlag) {
		this.recurringFlag = recurringFlag;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public boolean isAuthFlag() {
		return authFlag;
	}


	public void setAuthFlag(boolean authFlag) {
		this.authFlag = authFlag;
	}


	public List<String> getRules() {
		return rules;
	}


	public void setRules(List<String> rules) {
		this.rules = rules;
	}

}
