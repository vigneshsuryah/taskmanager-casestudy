/**
 * SearchUserDetailsRestResponse.java
 *
 *
 * Modification History
 *
 * Date        Version   Developer      Description
 * ---------   -------   ------------   --------------------------------------
 * 24/05/2017  1.0      Cognizant       Initial Version
 */
package com.wellpoint.middletier.gbd.gateway.response;

public class SearchUserDetailsRestResponse extends BaseResponse {
	
	private User user;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
}
