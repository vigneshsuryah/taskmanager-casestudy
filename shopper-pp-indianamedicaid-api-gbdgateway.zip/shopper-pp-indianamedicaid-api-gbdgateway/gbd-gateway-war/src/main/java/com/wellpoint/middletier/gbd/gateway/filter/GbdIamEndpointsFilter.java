package com.wellpoint.middletier.gbd.gateway.filter;

import java.io.IOException;
import java.net.URL;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.filter.GenericFilterBean;

import com.wellpoint.middletier.gbd.gateway.config.ApplicationPropertiesUI;

public class GbdIamEndpointsFilter extends GenericFilterBean {

	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res,
			final FilterChain chain) throws IOException, ServletException {

		final HttpServletRequest request = (HttpServletRequest) req;

		try {
			String domain = new URL(request.getRequestURL().toString()).getHost();
			if (!authorizeDomain(domain)) {
				throw new ServletException("Invalid Domain");
			}
		} catch (Exception e) {
			throw new ServletException("Invalid Domain");
		}

		chain.doFilter(req, res);
		
	}
	
	private boolean authorizeDomain(String domain){
		boolean flag = false;
		 
		String allowedDomainKeywordListString = ApplicationPropertiesUI.getStringProperty("gbd.setting.iam.endpoints.allow.domain.keyword",null);
		String[] allowedDomainKeywordList = allowedDomainKeywordListString.split(",");
		
		for(String allowedDomain: allowedDomainKeywordList){
			if(null != domain && domain.contains(allowedDomain)){
				flag = true;
				break;
			}
		}
		
		return flag;
	}
}
