/**
* MacAppExceptionHandler.java
*
*
* Modification History
*
* Date        Version   Developer      Description
* ---------   -------   ------------   --------------------------------------
* 07/01/2016  1.0      Cognizant       Initial Version
*/
package com.wellpoint.middletier.gbd.gateway.exception;


import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wellpoint.midletier.gbd.gateway.util.GbdConstants;

/**
 * This class is common exception handler for all the rest calls
 * @author CTS
 *
 */
@ControllerAdvice
public class GbdExceptionHandler implements GbdConstants
{
	private static final Logger LOGGER = LoggerFactory.getLogger(GbdExceptionHandler.class);
	/**
	 * This method is used to handle all the exceptions raised in the application
	 * @param ex
	 * @param response
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public @ResponseBody RestError handleCustomException (Exception ex, HttpServletResponse response) {
		LOGGER.debug("Inside handleCustomException " + ex.getMessage());
		response.setHeader("Content-Type", "application/json");
		if(ex instanceof GbdException){
			response.setStatus(((GbdException) ex).getReturnStatus());
			return ((GbdException) ex).transformException();
		}else if(ex instanceof PaymentModException){
			response.setStatus(((PaymentModException) ex).getReturnStatus());
			return ((PaymentModException) ex).transformException();
		}else
		{
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			RestError restError = returnRestErrorMA1002();
			return restError;
		}
		
	}
	
	/**
	 * this is used to construct exception for request parameter missing scenario
	 * @return
	 */
	public RestError returnRestErrorMA1002()
	{
		RestError restError = new RestError();
		Exceptions exception = new Exceptions();
		exception.setType(ERROR_TYPE);
		exception.setCode(REQ_PARAM_MSG_ERR_CD);
		exception.setMessage(REQ_PARAM_MSG_ERR_MSG);
		exception.setDetail(REQ_PARAM_MSG_ERR_MSG);
		Exceptions exceptions[] = new Exceptions[1];
		exceptions[0] = exception;
		restError.setExceptions(exceptions);
		return restError;
	}
}
